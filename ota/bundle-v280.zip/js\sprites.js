// PETQ.sprites — pixel art 16x16 per razza/sottorazza/stadio/corpo + overlay sporco.
// Nessun modulo ES, nessuna libreria: si aggancia a window.PETQ. Vedi docs/SPEC-MODULI-1-2-3.md sezione [B].
window.PETQ = window.PETQ || {};

(function () {
  "use strict";

  // Risoluzione dello SPAZIO-COORDINATE del pet renderizzato (Strada 1, 8 lug 2026: raddoppio
  // risoluzione arte per far spazio a facce/dettagli — es. "la toque finiva in faccia"). Il pet
  // finale vive su una griglia 32x32; l'arte SORGENTE puo' essere ancora 16x16 (autorata a mano,
  // compatta) e viene raddoppiata al volo da up2() al momento di risolvere il frame. Cosi' la
  // migrazione e' incrementale e LOSSLESS: finche' un corpo resta 16, up2 lo raddoppia (resa a
  // schermo identica al pixel); quando un corpo viene RIDISEGNATO nativo 32x32, up2 lo lascia
  // passare intatto e quel corpo guadagna dettaglio, senza toccare il resto del motore.
  var SIZE = 32;
  var SIZE_ART = 16; // griglia di autoraggio "legacy" (corpi non ancora ridisegnati a 32)

  // Raddoppia un frame 16x16 -> 32x32 (ogni cella diventa un blocco 2x2). Se il frame e' gia'
  // alla risoluzione piena (SIZE, cioe' nativo 32) lo restituisce invariato: passthrough.
  function up2(frame) {
    if (!frame || !frame.length || frame[0].length >= SIZE) return frame;
    var out = [];
    for (var y = 0; y < frame.length; y++) {
      var row = frame[y], dbl = "";
      for (var x = 0; x < row.length; x++) { dbl += row[x] + row[x]; }
      out.push(dbl, dbl);
    }
    return out;
  }

  // ===== Palette =====
  // Blob alieno: canone dalla spec. Variante colore = pelle "b" + guancia "c".
  var PAL_BLOB = [
    { "#": "#2d4a38", b: "#7fd8a4", e: "#ffffff", p: "#33475c", c: "#f09bb0" }, // verde menta (canone)
    { "#": "#4a2d3a", b: "#e8a4c4", e: "#ffffff", p: "#33475c", c: "#f0d29b" }, // rosa
    { "#": "#38304a", b: "#c4a4e8", e: "#ffffff", p: "#2d3347", c: "#f09bcf" },  // lilla
    // ---- varianti sbloccabili (indici 3+): NON escono alla nascita, v. pet.js generate ----
    { "#": "#3a4a58", b: "#d8e8f0", e: "#ffffff", p: "#5a6a80", c: "#b8d0e0" }, // Fantasma
    { "#": "#5a4418", b: "#f0cc58", e: "#fffbe8", p: "#4a3810", c: "#f8e8a0" }, // Oro
    { "#": "#141428", b: "#3a3a6a", e: "#a0f0ff", p: "#141428", c: "#7a5ae8" }, // Notte Neon
    { "#": "#3a1410", b: "#e8603a", e: "#fff0d8", p: "#3a1410", c: "#f8c060" }, // Lava
    { "#": "#4a5a6a", b: "#eef6fa", e: "#ffffff", p: "#3a4a5a", c: "#b8dcf0" }  // Ghiaccio
  ];
  // Insettoide (mantide-folk umanoide): outline "#", corpo "b", occhio "e", pupilla "i",
  // braccia raptatorie "m", antenne "n", astucci alari teen "w".
  var PAL_INS = [
    { "#": "#1f3a22", b: "#7fc95c", e: "#d8f07a", i: "#1a2a14", m: "#4a8c3a", n: "#2f5c2a", w: "#3f7030" }, // verde mantide
    { "#": "#3a1f2e", b: "#e8b4cc", e: "#f8ecb0", i: "#2a141f", m: "#c05a88", n: "#8a3a5c", w: "#a04a70" }, // mantide orchidea
    { "#": "#332a14", b: "#c2a45a", e: "#f0e0a8", i: "#2a2214", m: "#8a6c32", n: "#5c4a22", w: "#6e5628" },  // mantide secca
    // ---- varianti sbloccabili (indici 3+) ----
    { "#": "#42506a", b: "#d0dce8", e: "#f0f8ff", i: "#3a4458", m: "#a8b8cc", n: "#8898b0", w: "#bccadc" }, // Fantasma
    { "#": "#5a4418", b: "#e8c458", e: "#fff4c0", i: "#3a2c10", m: "#b8902c", n: "#8a6c1e", w: "#c8a83c" }, // Oro
    { "#": "#101020", b: "#34346a", e: "#8af0d0", i: "#101020", m: "#4a4a8a", n: "#2a2a52", w: "#3e3e78" }, // Notte Neon
    { "#": "#3a1208", b: "#d8542a", e: "#ffd070", i: "#2a0e06", m: "#a83c1c", n: "#7a2c14", w: "#c04824" }, // Lava
    { "#": "#40586a", b: "#cfe6f2", e: "#eaffff", i: "#2a3e50", m: "#9cc2d8", n: "#7aa4bc", w: "#b4d6e8" }  // Ghiaccio
  ];
  // Rettiliano (lizardfolk umanoide): outline "#", squame "b", ventre/muso chiaro "v",
  // occhio giallo "y", fessura pupilla "s", cresta+coda "r", artigli "c".
  var PAL_REP = [
    { "#": "#1f3a24", b: "#54a848", v: "#c8e8a0", y: "#f0d84a", s: "#141410", r: "#2f6e3a", c: "#e8e4d0" }, // verde
    { "#": "#3a2a14", b: "#e8a84a", v: "#f8e4c0", y: "#f8f0a0", s: "#201808", r: "#a86428", c: "#fff8ec" }, // sabbia
    { "#": "#16262e", b: "#4a9ab8", v: "#b8e0e8", y: "#f0d84a", s: "#0e141a", r: "#2e6480", c: "#e8f4f0" },  // teal
    // ---- varianti sbloccabili (indici 3+) ----
    { "#": "#3a4a58", b: "#c8d8e4", v: "#eef4f8", y: "#d8e8f0", s: "#3a4a58", r: "#a0b4c4", c: "#f0f6fa" }, // Fantasma
    { "#": "#5a4418", b: "#e0b840", v: "#f8e8b0", y: "#fff0a0", s: "#2a2008", r: "#b8902c", c: "#fff8e0" }, // Oro
    { "#": "#0e0e1c", b: "#2e2e5c", v: "#6a6ab0", y: "#7af0c8", s: "#0e0e1c", r: "#1e1e40", c: "#a0a0e0" }, // Notte Neon
    { "#": "#2a0e08", b: "#c8441c", v: "#f0a050", y: "#ffe070", s: "#1a0804", r: "#8a2c10", c: "#ffd8a0" }, // Lava
    { "#": "#3a5464", b: "#a8d8e8", v: "#e8f8ff", y: "#f0fbff", s: "#2a3e4a", r: "#7ab4cc", c: "#ffffff" }  // Ghiaccio
  ];
  // Robot: outline "#", corazza "b" (colorabile), scocca scura "k", visore "e", antenna "a", accento "h".
  var PAL_ROBOT = [
    { "#": "#37424c", b: "#c6cfd6", k: "#1e2830", e: "#3ee6d0", a: "#5aa8e8", h: "#e85a78" }, // grigio (canone)
    { "#": "#4c4237", b: "#e8d8b0", k: "#302819", e: "#3ee6d0", a: "#5aa8e8", h: "#e85a78" }, // crema
    { "#": "#374252", b: "#b8d4e8", k: "#1e2838", e: "#3ee6d0", a: "#5aa8e8", h: "#e85a78" },  // celeste
    // ---- varianti sbloccabili (indici 3+) ----
    { "#": "#48586a", b: "#e0eaf2", k: "#8a98a8", e: "#c8f0ff", a: "#a8c8e0", h: "#d0b8f0" }, // Fantasma
    { "#": "#5a4418", b: "#f0cc58", k: "#4a3810", e: "#fff0a0", a: "#f8e090", h: "#e8783a" }, // Oro
    { "#": "#0e0e18", b: "#2a2a3c", k: "#141420", e: "#ff4a8a", a: "#8a4af0", h: "#40f0e0" }, // Notte Neon
    { "#": "#2a1008", b: "#8a3a20", k: "#1a0a04", e: "#ff8a30", a: "#e85a20", h: "#f8d040" }, // Lava
    { "#": "#48607a", b: "#dff0fa", k: "#6a8098", e: "#8ae8ff", a: "#b8e0f8", h: "#5ac8f0" }  // Ghiaccio
  ];

  // ===== Dati sprite: alieno blob =====
  // Baby ridisegnato su direzione fondatore (regola stadi): tondo/informe, niente guance né bocca, antenna accennata.
  var A_BABY = ["................","................","................","................","................",".......#........",".....######.....","...##bbbbbb##...","..#bbbbbbbbbb#..","..#bbeeeeeebb#..","..#bbeeppeebb#..","..#bbeeeeeebb#..","..#bbbbbbbbbb#..","..#bbbbbbbbbb#..","...##bbbbbb##...",".....##..##....."];
  // Teen = canone dalla spec (antenne e sorriso pieno), NON toccato.
  var A_TEEN = ["................","...##......##...","....#......#....","....########....","...#bbbbbbbb#...","..#bbbbbbbbbb#..","..#bbeeeeeebb#..","..#bbeeppeebb#..","..#bbeeeeeebb#..","..#cbbbbbbbbc#..","..#bbb####bbb#..","..#bbbbbbbbbb#..",".##bbbbbbbbbb##.","..#bbbbbbbbbb#..","...##bbbbbb##...","....##....##...."];

  // ===== Dati sprite: insettoide = mantide-folk umanoide (testa triangolare, braccia "a preghiera") =====
  var INS_BABY = ["................","................","................","................","................","....n......n....",".#eee######eee#.","..#ei#bbbb#ie#..","...#e#bbbb#e#...","....##bbbb##....",".....#bbbb#.....","......#bb#......","....m#bbbb#m....",".....#bbbb#.....",".....#....#.....","....##....##...."];
  var INS_TEEN = ["...n........n...","..n..........n..","...n.######.n...",".#eee######eee#.","..#ei#bbbb#ie#..","...#e#bbbb#e#...","....##bbbb##....",".....#bbbb#.....","...w##bbbb##w...","..#ww#mbbm#ww#..","..#ww#mmmm#ww#..","..#ww#bbbb#ww#..","...w#bbbbbb#w...","....#bbbbbb#....","....#b#..#b#....","....##....##...."];

  // ===== Dati sprite: rettiliano = lizardfolk umanoide (cresta mohawk, muso chiaro, coda, artigli) =====
  var REP_BABY = ["................","................","................","................","................",".......r........","....########....","...#bbbbbbbb#...","...#bysbbysb#...","...#bbbbbbbb#...","...#bvvvvvvb#...","....########....","....#bvvvvb#....","....#bbbbbb#.rr.","....#b#..#b#....","....##....##...."];
  var REP_TEEN = [".....r.r.r.r....","....########....","...#bbbbbbbb#...","...#bysbbysb#...","...#bvvvvvvb#...","...#bvvvvvvb#...","....########....","..##bbbbbbbb##..",".#b#bvvvvvvb#b#.",".#b#bvvvvvvb#b#.","..##bvvvvvvb##..","...#bbbbbbbb#...","...#bbbbbbbb#rr.","...#bb#..#bb#.rr","...#bb#..#bb#...",".#ccbb#..#bbcc#."];

  // ===== Dati sprite: robot (canone per antenna 0 + testa 0; NON ridisegnato) =====
  var R_BABY = ["................","................","................","................",".......aa.......","........#.......","....########....","...#bbbbbbbb#...","...#bkkkkkkb#...","...#bkekkekb#...","...#bkkeekkb#...","...#bbbbbbbb#...","...#ba####ab#...","....########....",".....#....#.....","....##....##...."];
  var R_TEEN = ["................","................",".......aa.......","........#.......","...##########...","..#bbbbbbbbbb#..","..#bkkkkkkkkb#..","..#bkekkkkekb#..","..#bkkeeeekkb#..","..#bbbbbbbbbb#..","..############..",".##bbbbbbbbbb##.",".##bbbahhabbb##.","..#bbbbbbbbbb#..","..############..","...##......##..."];

  // Robot componibile: antenna (righe 0-1 baby / 0-1 teen dello slot, posizionate secondo canone),
  // testa (blocco testa+collo), piedi fissi. Antenna0+Testa0 = canone esatto.
  var ROBOT_ANTENNA_BABY = [
    [".......aa.......", "........#......."], // 0 pallina dritta (canone)
    ["......a..a......", "......#..#......"], // 1 doppia
    [".......aa.......", "......##........"]  // 2 piegata
  ];
  var ROBOT_ANTENNA_TEEN = [
    [".......aa.......", "........#......."], // 0 pallina dritta (canone)
    ["......a..a......", "......#..#......"], // 1 doppia
    [".......aa.......", "......##........"]  // 2 piegata
  ];
  var ROBOT_BABY_FEET = [".....#....#.....", "....##....##...."];
  var ROBOT_TEEN_FEET = ["..############..", "...##......##..."];

  var ROBOT_TESTA_BABY = [
    // 0 quadrata (canone)
    ["....########....", "...#bbbbbbbb#...", "...#bkkkkkkb#...", "...#bkekkekb#...", "...#bkkeekkb#...", "...#bbbbbbbb#...", "...#ba####ab#...", "....########...."],
    // 1 tonda
    ["....########....", "...#bbbbbbbb#...", "..#bbbbbbbbbb#..", "..#bkekkkkekb#..", "..#bkkkkkkkkb#..", "...#bbbbbbbb#...", "...#ba####ab#...", "....########...."],
    // 2 visiera larga
    ["....########....", "...#bbbbbbbb#...", "...#kkkkkkkk#...", "...#keeeeeek#...", "...#kkkkkkkk#...", "...#bbbbbbbb#...", "...#ba####ab#...", "....########...."]
  ];
  var ROBOT_TESTA_TEEN = [
    // 0 quadrata (canone)
    ["...##########...", "..#bbbbbbbbbb#..", "..#bkkkkkkkkb#..", "..#bkekkkkekb#..", "..#bkkeeeekkb#..", "..#bbbbbbbbbb#..", "..############..", ".##bbbbbbbbbb##.", ".##bbbahhabbb##.", "..#bbbbbbbbbb#.."],
    // 1 tonda
    ["...##########...", "..#bbbbbbbbbb#..", ".#bbbbbbbbbbbb#.", ".#bkekkkkkkekb#.", ".#bkkkkkkkkkkb#.", "..#bbbbbbbbbb#..", "..############..", ".##bbbbbbbbbb##.", ".##bbbahhabbb##.", "..#bbbbbbbbbb#.."],
    // 2 visiera larga
    ["...##########...", "..#bbbbbbbbbb#..", "..#kkkkkkkkkk#..", "..#keeeeeeeek#..", "..#kkkkkkkkkk#..", "..#bbbbbbbbbb#..", "..############..", ".##bbbbbbbbbb##.", ".##bbbahhabbb##.", "..#bbbbbbbbbb#.."]
  ];

  function buildRobotBaby(antenna, testa) {
    var a = ROBOT_ANTENNA_BABY[antenna] || ROBOT_ANTENNA_BABY[0];
    var t = ROBOT_TESTA_BABY[testa] || ROBOT_TESTA_BABY[0];
    return ["................", "................", "................", "................"]
      .concat(a, t, ROBOT_BABY_FEET);
  }
  function buildRobotTeen(antenna, testa) {
    var a = ROBOT_ANTENNA_TEEN[antenna] || ROBOT_ANTENNA_TEEN[0];
    var t = ROBOT_TESTA_TEEN[testa] || ROBOT_TESTA_TEEN[0];
    return ["................", "................"]
      .concat(a, t, ROBOT_TEEN_FEET);
  }

  // ===== Varianti corpo (solo stadio teen): righe "sicure" senza landmark laterali (braccia/coda) =====
  function applyBodyVariant(frame, corpo, rowMap) {
    if (corpo === "normale" || !rowMap) return frame;
    var out = frame.slice();
    for (var idx in rowMap) {
      if (Object.prototype.hasOwnProperty.call(rowMap, idx)) {
        out[idx] = rowMap[idx][corpo];
      }
    }
    return out;
  }

  // righe modificabili per corpo, per sottorazza teen (indice riga -> {magro, ciccione})
  var BLOB_TEEN_ROWS = {
    9:  { magro: "...#cbbbbbbc#...", ciccione: ".#cbbbbbbbbbbc#." },
    10: { magro: "...#bbb##bbb#...", ciccione: ".#bbbbb##bbbbb#." },
    11: { magro: "...#bbbbbbbb#...", ciccione: "#bbbbbbbbbbbbbb#" },
    12: { magro: "...#bbbbbbbb#...", ciccione: "#bbbbbbbbbbbbbb#" },
    13: { magro: "...#bbbbbbbb#...", ciccione: ".#bbbbbbbbbbbb#." }
  };
  // mantide-folk: cambia l'addome; le righe con braccia raptatorie (9-10) restano intatte
  var INS_TEEN_ROWS = {
    11: { magro: "...#w#bbbb#w#...", ciccione: ".#ww#bbbbbb#ww#." },
    12: { magro: "....#bbbbbb#....", ciccione: "..w#bbbbbbbb#w.." },
    13: { magro: ".....#bbbb#.....", ciccione: "...#bbbbbbbb#..." }
  };
  // lizardfolk: cambia spalle/busto/fianchi; coda (righe 12-13) e gambe restano intatte
  // Ciccione v2 rettiliano (playtest 8 lug 2026, "migliorali"): non solo corpo piu' largo ma
  // PANCIONE chiaro ('v') esteso su tutte e 5 le righe — la differenza si vede a colpo d'occhio.
  var REP_TEEN_ROWS = {
    7:  { magro: "...##bbbbbb##...", ciccione: ".##bvvvvvvvvb##." },
    8:  { magro: "..#b#bvvvvb#b#..", ciccione: "#b#vvvvvvvvvv#b#" },
    9:  { magro: "..#b#bvvvvb#b#..", ciccione: "#b#vvvvvvvvvv#b#" },
    10: { magro: "...##bvvvvb##...", ciccione: ".##vvvvvvvvvv##." },
    11: { magro: "....#bbbbbb#....", ciccione: "..#bvvvvvvvvb#.." }
  };

  // ===== RETTILIANO v3 "lucertola slanciata" (P3, 3a iterazione con feedback fondatore) =====
  // v1 = redraw dettagliato (slop) · v2 = testa larga bold ("quasi non si capisce e' una
  // lucertola") · v3 = i MARCATORI della lucertola: occhi a BULBO che sporgono FUORI dalla
  // silhouette (geco), MUSO sporgente con scaglie, collo sottile, corpo SNELLO ("slanciala un
  // minimo"), coda lunga che risale sul fianco dx, cresta, artigli. Baby v2 APPROVATO e
  // invariato. Disegnato a 16 e raddoppiato (up2), palette invariata (b y s v r c).
  var REP_TEEN32 = {
    normale: ["..........rrrr....rrrr..........","..........rrrr....rrrr..........","........################........","........################........","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","....##yyyy##bbbbbbbb##yyyy##....","....##yyyy##bbbbbbbb##yyyy##....","....##yyss##bbbbbbbb##ssyy##....","....##yyss##bbbbbbbb##ssyy##....","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","........##bbvvvvvvvvbb##........","........##bbvvvvvvvvbb##........","........################........","........################........","..........##bbvvvvbb##..........","..........##bbvvvvbb##..........","......##bb##bbvvvvbb##bb##......","......##bb##bbvvvvbb##bb##......","......##bb##bbvvvvbb##bb##......","......##bb##bbvvvvbb##bb##......","........####bbvvvvbb####..rrrr..","........####bbvvvvbb####..rrrr..","........##bbbbbbbbbbbb##rrrr....","........##bbbbbbbbbbbb##rrrr....","........##bb##....##bb##rrrr....","........##bb##....##bb##rrrr....","........##bb##....##bb##rrrr....","........##bb##....##bb##rrrr....","....##ccccbb##....##bbcccc##....","....##ccccbb##....##bbcccc##...."],
    magro: ["..........rrrr....rrrr..........","..........rrrr....rrrr..........","........################........","........################........","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","....##yyyy##bbbbbbbb##yyyy##....","....##yyyy##bbbbbbbb##yyyy##....","....##yyss##bbbbbbbb##ssyy##....","....##yyss##bbbbbbbb##ssyy##....","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","........##bbvvvvvvvvbb##........","........##bbvvvvvvvvbb##........","........################........","........################........","..........##bbvvvvbb##..........","..........##bbvvvvbb##..........","......##bb####vvvv####bb##......","......##bb####vvvv####bb##......","......##bb####vvvv####bb##......","......##bb####vvvv####bb##......","........####bbvvvvbb####..rrrr..","........####bbvvvvbb####..rrrr..","........##bbbbbbbbbbbb##rrrr....","........##bbbbbbbbbbbb##rrrr....","........##bb##....##bb##rrrr....","........##bb##....##bb##rrrr....","........##bb##....##bb##rrrr....","........##bb##....##bb##rrrr....","....##ccccbb##....##bbcccc##....","....##ccccbb##....##bbcccc##...."],
    ciccione: ["..........rrrr....rrrr..........","..........rrrr....rrrr..........","........################........","........################........","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","....##yyyy##bbbbbbbb##yyyy##....","....##yyyy##bbbbbbbb##yyyy##....","....##yyss##bbbbbbbb##ssyy##....","....##yyss##bbbbbbbb##ssyy##....","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","........##bbvvvvvvvvbb##........","........##bbvvvvvvvvbb##........","........################........","........################........","........##bbvvvvvvvvbb##........","........##bbvvvvvvvvbb##........","..##bb##bbvvvvvvvvvvvvbb##bb##..","..##bb##bbvvvvvvvvvvvvbb##bb##..","..##bb##vvvvvvvvvvvvvvvv##bb##..","..##bb##vvvvvvvvvvvvvvvv##bb##..","....####bbvvvvvvvvvvvvbb##rrrr..","....####bbvvvvvvvvvvvvbb##rrrr..","......##bbbbbbbbbbbbbbbb##rrrr..","......##bbbbbbbbbbbbbbbb##rrrr..","........##bb##....##bb##rrrr....","........##bb##....##bb##rrrr....","........##bb##....##bb##rrrr....","........##bb##....##bb##rrrr....","....##ccccbb##....##bbcccc##....","....##ccccbb##....##bbcccc##...."]
  };

  // ===== ALTRI CORPI NATIVI 32x32 (Strada 1 Tappa 2, rollout 8 lug 2026) =====
  // Blob, mantide-folk e rettiliano-baby ridisegnati alla risoluzione piena (volti
  // dettagliati). Teen = full-frame per stato corpo; baby = griglia singola. up2 passthrough.
  var A_BABY32 = ["................................","................................","................................","................................","................................","................................","................................","................................","................................","........##............##........",".........#............#.........",".........#............#.........","..........############..........","..........############..........","......####bbbbbbbbbbbb####......","......####bbbbbbbbbbbb####......","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbeeeeeeeebbbbbb##....","....##bbbbbbeeppppeebbbbbb##....","....##bbbbbbeeeeeeeebbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","......####bbbbbbbbbbbb####......","......####bbbbbbbbbbbb####......","..........####....####..........","..........####....####.........."];
  var A_TEEN32 = { normale: ["................................","................................","......####............####......","......####............####......","........##............##........","........##............##........","........################........","........################........","......##bbbbbbbbbbbbbbbb##......","......##bbbbbbbbbbbbbbbb##......","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbeeeeeeeebbbbbb##....","....##bbbbbbeeppppeebbbbbb##....","....##bbbbbbeeeeeeeebbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##ccbbbbbbbbbbbbbbbbcc##....","....##ccbbbbbbbbbbbbbbbbcc##....","....##bbbbbb########bbbbbb##....","....##bbbbbb########bbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","..####bbbbbbbbbbbbbbbbbbbb####..","..####bbbbbbbbbbbbbbbbbbbb####..","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","......####bbbbbbbbbbbb####......","......####bbbbbbbbbbbb####......","........####........####........","........####........####........"],
    magro: ["................................","................................","......####............####......","......####............####......","........##............##........","........##............##........","........################........","........################........","......##bbbbbbbbbbbbbbbb##......","......##bbbbbbbbbbbbbbbb##......","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbeeeeeeeebbbbbb##....","....##bbbbbbeeppppeebbbbbb##....","....##bbbbbbeeeeeeeebbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","......##ccbbbbbbbbbbbbcc##......","......##ccbbbbbbbbbbbbcc##......","......##bbbbbb####bbbbbb##......","......##bbbbbb####bbbbbb##......","......##bbbbbbbbbbbbbbbb##......","......##bbbbbbbbbbbbbbbb##......","......##bbbbbbbbbbbbbbbb##......","......##bbbbbbbbbbbbbbbb##......","......##bbbbbbbbbbbbbbbb##......","......##bbbbbbbbbbbbbbbb##......","......####bbbbbbbbbbbb####......","......####bbbbbbbbbbbb####......","........####........####........","........####........####........"],
    ciccione: ["................................","................................","......####............####......","......####............####......","........##............##........","........##............##........","........################........","........################........","......##bbbbbbbbbbbbbbbb##......","......##bbbbbbbbbbbbbbbb##......","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbeeeeeeeebbbbbb##....","....##bbbbbbeeppppeebbbbbb##....","....##bbbbbbeeeeeeeebbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","..##ccbbbbbbbbbbbbbbbbbbbbcc##..","..##ccbbbbbbbbbbbbbbbbbbbbcc##..","..##bbbbbbbbbb####bbbbbbbbbb##..","..##bbbbbbbbbb####bbbbbbbbbb##..","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","......####bbbbbbbbbbbb####......","......####bbbbbbbbbbbb####......","........####........####........","........####........####........"] };
  var INS_BABY32 = ["................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","........nn............nn........","........nn............nn........","..##eeieee############eeeiee##..","..##eeeeee############eeeeee##..","....##eeii##bbbbbbbb##iiee##....","....##eeii##bbbbbbbb##iiee##....","......##ee##bbbbbbbb##ee##......","......##ee##bbbbbbbb##ee##......","........####bbbbbbbb####........","........####bbbbbbbb####........","..........##bbbbbbbb##..........","..........##bbbbbbbb##..........","............##bbbb##............","............##bbbb##............","........mm##bbbbbbbb##mm........","........mm##bbbbbbbb##mm........","..........##bbbbbbbb##..........","..........##bbbbbbbb##..........","..........##........##..........","..........##........##..........","........####........####........","........####........####........"];
  var INS_TEEN32 = { normale: ["......nn................nn......","......nn................nn......","....nn....................nn....","....nn....................nn....","......nn..############..nn......","......nn..############..nn......","..##eeieee############eeeiee##..","..##eeeeee############eeeeee##..","....##eeii##bbbbbbbb##iiee##....","....##eeii##bbbbbbbb##iiee##....","......##ee##bbbbbbbb##ee##......","......##ee##bbbbbbbb##ee##......","........####bbbbbbbb####........","........####bbbbbbbb####........","..........##bb#..#bb##..........","..........##b#....#b##..........","......ww####bbbbbbbb####ww......","......ww####bbbbbbbb####ww......","....##wwww##mmbbbbmm##wwww##....","....##wwww##mmbbbbmm##wwww##....","....##wwww##mmmmmmmm##wwww##....","....##wwww##mmmmmmmm##wwww##....","....##wwww##bbbbbbbb##wwww##....","....##wwww##bbbbbbbb##wwww##....","......ww##bbbbbbbbbbbb##ww......","......ww##bbbbbbbbbbbb##ww......","........##bbbbbbbbbbbb##........","........##bbbbbbbbbbbb##........","........##bb##....##bb##........","........##bb##....##bb##........","........####........####........","........####........####........"],
    magro: ["......nn................nn......","......nn................nn......","....nn....................nn....","....nn....................nn....","......nn..############..nn......","......nn..############..nn......","..##eeieee############eeeiee##..","..##eeeeee############eeeeee##..","....##eeii##bbbbbbbb##iiee##....","....##eeii##bbbbbbbb##iiee##....","......##ee##bbbbbbbb##ee##......","......##ee##bbbbbbbb##ee##......","........####bbbbbbbb####........","........####bbbbbbbb####........","..........##bb#..#bb##..........","..........##b#....#b##..........","......ww####bbbbbbbb####ww......","......ww####bbbbbbbb####ww......","....##wwww##mmbbbbmm##wwww##....","....##wwww##mmbbbbmm##wwww##....","....##wwww##mmmmmmmm##wwww##....","....##wwww##mmmmmmmm##wwww##....","......##ww##bbbbbbbb##ww##......","......##ww##bbbbbbbb##ww##......","........##bbbbbbbbbbbb##........","........##bbbbbbbbbbbb##........","..........##bbbbbbbb##..........","..........##bbbbbbbb##..........","........##bb##....##bb##........","........##bb##....##bb##........","........####........####........","........####........####........"],
    ciccione: ["......nn................nn......","......nn................nn......","....nn....................nn....","....nn....................nn....","......nn..############..nn......","......nn..############..nn......","..##eeieee############eeeiee##..","..##eeeeee############eeeeee##..","....##eeii##bbbbbbbb##iiee##....","....##eeii##bbbbbbbb##iiee##....","......##ee##bbbbbbbb##ee##......","......##ee##bbbbbbbb##ee##......","........####bbbbbbbb####........","........####bbbbbbbb####........","..........##bb#..#bb##..........","..........##b#....#b##..........","......ww####bbbbbbbb####ww......","......ww####bbbbbbbb####ww......","....##wwww##mmbbbbmm##wwww##....","....##wwww##mmbbbbmm##wwww##....","....##wwww##mmmmmmmm##wwww##....","....##wwww##mmmmmmmm##wwww##....","..##wwww##bbbbbbbbbbbb##wwww##..","..##wwww##bbbbbbbbbbbb##wwww##..","....ww##bbbbbbbbbbbbbbbb##ww....","....ww##bbbbbbbbbbbbbbbb##ww....","......##bbbbbbbbbbbbbbbb##......","......##bbbbbbbbbbbbbbbb##......","........##bb##....##bb##........","........##bb##....##bb##........","........####........####........","........####........####........"] };
  var REP_BABY32 = ["................................","................................","................................","................................","................................","................................","................................","................................","..........rrrr....rrrr..........","..........rrrr....rrrr..........","......####################......","......####################......","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbyyyybbbbbbbbyyyybb##....","....##bbyyyybbbbbbbbyyyybb##....","....##bbyyssbbbbbbbbyyssbb##....","....##bbyyssbbbbbbbbyyssbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","......####################......","......####################......","......##bbvvvvvvvvvvvvbb##......","......##bbvvvvvvvvvvvvbb##......","......##bbvvvvvvvvvvvvbb##......","......##bbvvvvvvvvvvvvbb##......","......##bbbbbbbbbbbbbbbb##rrrr..","......##bbbbbbbbbbbbbbbb##rrrr..","......##bbbb##....##bbbb##......","......##bbbb##....##bbbb##......","......######........######......","......######........######......"];

  // ===== ADULTI alieni (P3 batch 3b/3c, arte a mano del regista) =====
  // Disegnati a 16px e raddoppiati con up2: la grana retro e' garantita per costruzione,
  // stessa identita' del teen (faccia/occhi invariati), piu' massa e attributi da adulto.
  // Rettiliano: +1 punta di cresta, spalle larghe, artigli sulle mani, coda doppia, gambe 3px.
  // Blob: +1 di massa ovunque, antenne piu' alte, guance esterne, stance larga.
  // Mantide: ali lunghe fino in fondo, falci raptatorie grandi, torace largo, zampe doppie.
  var REP_ADULTO32 = {
    normale: ["......rrrr....rrrr....rrrr......","......rrrr....rrrr....rrrr......","........################........","........################........","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","....##yyyy##bbbbbbbb##yyyy##....","....##yyyy##bbbbbbbb##yyyy##....","....##yyss##bbbbbbbb##ssyy##....","....##yyss##bbbbbbbb##ssyy##....","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","........##bbvvvvvvvvbb##........","........##bbvvvvvvvvbb##........","........################........","........################........","........####bbvvvvbb####..rr....","........####bbvvvvbb####..rr....","..##bb####bbvvvvvvvvbb####bb##..","..##bb####bbvvvvvvvvbb####bb##..","..##bb##bbvvvvvvvvvvvvbb##bb##rr","..##bb##bbvvvvvvvvvvvvbb##bb##rr","..##cc##bbvvvvvvvvvvvvbb##cc##rr","..##cc##bbvvvvvvvvvvvvbb##cc##rr","....####bbvvvvvvvvvvvvbb##rrrr..","....####bbvvvvvvvvvvvvbb##rrrr..","......##bbbbbbbbbbbbbbbb##rrrr..","......##bbbbbbbbbbbbbbbb##rrrr..","......##bbbb##....##bbbb##rr....","......##bbbb##....##bbbb##rr....","..##ccccbbbb##....##bbbbcccc##..","..##ccccbbbb##....##bbbbcccc##.."],
    magro: ["......rrrr....rrrr....rrrr......","......rrrr....rrrr....rrrr......","........################........","........################........","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","....##yyyy##bbbbbbbb##yyyy##....","....##yyyy##bbbbbbbb##yyyy##....","....##yyss##bbbbbbbb##ssyy##....","....##yyss##bbbbbbbb##ssyy##....","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","........##bbvvvvvvvvbb##........","........##bbvvvvvvvvbb##........","........################........","........################........","..........##bbvvvvbb##....rr....","..........##bbvvvvbb##....rr....","....##bb####bbvvvvbb####bb##....","....##bb####bbvvvvbb####bb##....","....##bb##bbvvvvvvvvbb##bb##..rr","....##bb##bbvvvvvvvvbb##bb##..rr","....##cc##bbvvvvvvvvbb##cc##..rr","....##cc##bbvvvvvvvvbb##cc##..rr","......####bbvvvvvvvvbb####rrrr..","......####bbvvvvvvvvbb####rrrr..","........##bbbbbbbbbbbb##rrrr....","........##bbbbbbbbbbbb##rrrr....","........##bb##....##bb##rr......","........##bb##....##bb##rr......","....##ccccbb##....##bbcccc##....","....##ccccbb##....##bbcccc##...."],
    ciccione: ["......rrrr....rrrr....rrrr......","......rrrr....rrrr....rrrr......","........################........","........################........","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","....##yyyy##bbbbbbbb##yyyy##....","....##yyyy##bbbbbbbb##yyyy##....","....##yyss##bbbbbbbb##ssyy##....","....##yyss##bbbbbbbb##ssyy##....","....######bbbbbbbbbbbb######....","....######bbbbbbbbbbbb######....","........##bbvvvvvvvvbb##........","........##bbvvvvvvvvbb##........","........################........","........################........","........##bbvvvvvvvvbb##..rr....","........##bbvvvvvvvvbb##..rr....","##bb####bbvvvvvvvvvvvvbb####bb##","##bb####bbvvvvvvvvvvvvbb####bb##","##bb##vvvvvvvvvvvvvvvvvvvv##bb##","##bb##vvvvvvvvvvvvvvvvvvvv##bb##","##cc##vvvvvvvvvvvvvvvvvvvv##cc##","##cc##vvvvvvvvvvvvvvvvvvvv##cc##","..####bbvvvvvvvvvvvvvvvvbb##rrrr","..####bbvvvvvvvvvvvvvvvvbb##rrrr","....##bbbbbbbbbbbbbbbbbbbb##rrrr","....##bbbbbbbbbbbbbbbbbbbb##rrrr","......##bbbb##....##bbbb##rr....","......##bbbb##....##bbbb##rr....","..##ccccbbbb##....##bbbbcccc##..","..##ccccbbbb##....##bbbbcccc##.."]
  };
  var A_ADULTO32 = {
    normale: ["......####............####......","......####............####......","......####............####......","......####............####......","........##............##........","........##............##........","......####################......","......####################......","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##bbbbbbeeeeppppeeeebbbbbb##..","..##bbbbbbeeeeppppeeeebbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##ccbbbbbbbbbbbbbbbbbbbbcc##..","..##ccbbbbbbbbbbbbbbbbbbbbcc##..","..##bbbbbbbb########bbbbbbbb##..","..##bbbbbbbb########bbbbbbbb##..","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","####bbbbbbbbbbbbbbbbbbbbbbbb####","####bbbbbbbbbbbbbbbbbbbbbbbb####","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","....####bbbbbbbbbbbbbbbb####....","....####bbbbbbbbbbbbbbbb####....","......####............####......","......####............####......"],
    magro: ["......####............####......","......####............####......","......####............####......","......####............####......","........##............##........","........##............##........","......####################......","......####################......","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##bbbbbbeeeeppppeeeebbbbbb##..","..##bbbbbbeeeeppppeeeebbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","....##ccbbbbbbbbbbbbbbbbcc##....","....##ccbbbbbbbbbbbbbbbbcc##....","....##bbbbbb########bbbbbb##....","....##bbbbbb########bbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","..####bbbbbbbbbbbbbbbbbbbb####..","..####bbbbbbbbbbbbbbbbbbbb####..","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","......####bbbbbbbbbbbb####......","......####bbbbbbbbbbbb####......","......####............####......","......####............####......"],
    ciccione: ["......####............####......","......####............####......","......####............####......","......####............####......","........##............##........","........##............##........","......####################......","......####################......","....##bbbbbbbbbbbbbbbbbbbb##....","....##bbbbbbbbbbbbbbbbbbbb##....","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","..##bbbbbbbbbbbbbbbbbbbbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##bbbbbbeeeeppppeeeebbbbbb##..","..##bbbbbbeeeeppppeeeebbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","..##bbbbbbeeeeeeeeeeeebbbbbb##..","##ccbbbbbbbbbbbbbbbbbbbbbbbbcc##","##ccbbbbbbbbbbbbbbbbbbbbbbbbcc##","##bbbbbbbbbb########bbbbbbbbbb##","##bbbbbbbbbb########bbbbbbbbbb##","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","##bbbbbbbbbbbbbbbbbbbbbbbbbbbb##","..####bbbbbbbbbbbbbbbbbbbb####..","..####bbbbbbbbbbbbbbbbbbbb####..","......####............####......","......####............####......"]
  };
  var INS_ADULTO32 = {
    normale: ["....nn....................nn....","....nn....................nn....","....nn....................nn....","....nn....................nn....","......nn..############..nn......","......nn..############..nn......","..##eeeeee############eeeeee##..","..##eeeeee############eeeeee##..","....##eeii##bbbbbbbb##iiee##....","....##eeii##bbbbbbbb##iiee##....","......##ee##bbbbbbbb##ee##......","......##ee##bbbbbbbb##ee##......","........####bbbbbbbb####........","........####bbbbbbbb####........","..........##bbbbbbbb##..........","..........##bbbbbbbb##..........","....wwww####bbbbbbbb####wwww....","....wwww####bbbbbbbb####wwww....","..##wwww##mmmmbbbbmmmm##wwww##..","..##wwww##mmmmbbbbmmmm##wwww##..","..##wwww##mmmmmmmmmmmm##wwww##..","..##wwww##mmmmmmmmmmmm##wwww##..","..##wwww##bbbbbbbbbbbb##wwww##..","..##wwww##bbbbbbbbbbbb##wwww##..","..##wwww##bbbbbbbbbbbb##wwww##..","..##wwww##bbbbbbbbbbbb##wwww##..","....wwww##bbbbbbbbbbbb##wwww....","....wwww##bbbbbbbbbbbb##wwww....","......##bbbb##....##bbbb##......","......##bbbb##....##bbbb##......","......####............####......","......####............####......"],
    magro: ["....nn....................nn....","....nn....................nn....","....nn....................nn....","....nn....................nn....","......nn..############..nn......","......nn..############..nn......","..##eeeeee############eeeeee##..","..##eeeeee############eeeeee##..","....##eeii##bbbbbbbb##iiee##....","....##eeii##bbbbbbbb##iiee##....","......##ee##bbbbbbbb##ee##......","......##ee##bbbbbbbb##ee##......","........####bbbbbbbb####........","........####bbbbbbbb####........","..........##bbbbbbbb##..........","..........##bbbbbbbb##..........","....wwww####bbbbbbbb####wwww....","....wwww####bbbbbbbb####wwww....","..##wwww##mmmmbbbbmmmm##wwww##..","..##wwww##mmmmbbbbmmmm##wwww##..","..##wwww##mmmmmmmmmmmm##wwww##..","..##wwww##mmmmmmmmmmmm##wwww##..","....##wwww##bbbbbbbb##wwww##....","....##wwww##bbbbbbbb##wwww##....","....##wwww##bbbbbbbb##wwww##....","....##wwww##bbbbbbbb##wwww##....","......wwww##bbbbbbbb##wwww......","......wwww##bbbbbbbb##wwww......","......##bbbb##....##bbbb##......","......##bbbb##....##bbbb##......","......####............####......","......####............####......"],
    ciccione: ["....nn....................nn....","....nn....................nn....","....nn....................nn....","....nn....................nn....","......nn..############..nn......","......nn..############..nn......","..##eeeeee############eeeeee##..","..##eeeeee############eeeeee##..","....##eeii##bbbbbbbb##iiee##....","....##eeii##bbbbbbbb##iiee##....","......##ee##bbbbbbbb##ee##......","......##ee##bbbbbbbb##ee##......","........####bbbbbbbb####........","........####bbbbbbbb####........","..........##bbbbbbbb##..........","..........##bbbbbbbb##..........","....wwww####bbbbbbbb####wwww....","....wwww####bbbbbbbb####wwww....","..##wwww##mmmmbbbbmmmm##wwww##..","..##wwww##mmmmbbbbmmmm##wwww##..","..##wwww##mmmmmmmmmmmm##wwww##..","..##wwww##mmmmmmmmmmmm##wwww##..","##wwww##bbbbbbbbbbbbbbbb##wwww##","##wwww##bbbbbbbbbbbbbbbb##wwww##","##wwww##bbbbbbbbbbbbbbbb##wwww##","##wwww##bbbbbbbbbbbbbbbb##wwww##","..wwww##bbbbbbbbbbbbbbbb##wwww..","..wwww##bbbbbbbbbbbbbbbb##wwww..","......##bbbb##....##bbbb##......","......##bbbb##....##bbbb##......","......####............####......","......####............####......"]
  };

  // Robot CANONE (antenna0 + testa0) nativo 32x32 (Strada 1 Tappa 2 Batch B). Le altre
  // combo antenna/testa (1/2) restano 16 componibili (up2 le raddoppia) finche non
  // vengono ridisegnate: getRobotFrame usa questi full-frame SOLO per il canone 0/0.
  var R_BABY32 = ["................................","................................","................................",".............######.............",".............#aaaa#.............",".............#aaaa#.............","..............#aa#..............","...............##...............","..........############..........",".........#bbbbbbbbbbbb#.........",".........#bbkkkkkkkkbb#.........",".........#bkkkkkkkkkkb#.........",".........#bkkeeeeeekkb#.........",".........#bkeeeeeeeekb#.........",".........#bkkeeeeeekkb#.........",".........#bkkkkkkkkkkb#.........",".........#bkk######kkb#.........",".........#bkkkkkkkkkkb#.........",".........#bbbbbbbbbbbb#.........",".........#bbbhbbbbhbbb#.........",".........#bbbbbbbbbbbb#.........","..........############..........","...........#bb####bb#...........","..........#bbb####bbb#..........","..........#bbb####bbb#..........","..........####....####..........","..........#bb#....#bb#..........","..........#bb#....#bb#..........",".........#bbbb#..#bbbb#.........",".........######..######.........","................................","................................"];
  var R_TEEN32 = { normale: ["................................","................................",".............#aaaa#.............",".............#aaaa#.............","..............#aa#..............","...............##...............","..........############..........",".........#bbbbbbbbbbbb#.........",".........#bbkkkkkkkkbb#.........",".........#bkkeeeeeekkb#.........",".........#bkeeeeeeeekb#.........",".........#bkkeeeeeekkb#.........",".........#bbkkkkkkkkbb#.........",".........#bb########bb#.........","..........############..........","..........#kk#....#kk#..........","........################........",".......#bbbbbbbbbbbbbbbb#.......",".......#bbkkbbbbbbbbkkbb#.......",".......#bhhbbbbbbbbbbhhb#.......",".......#bhhbbbbbbbbbbhhb#.......",".......#bbkkbbbbbbbbkkbb#.......",".......#bbbbbbbbbbbbbbbb#.......","........################........","........######....######........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........","........####........####........","........#bbb#......#bbb#........",".......#bbbb#......#bbbb#.......",".......######......######......."],
    magro: ["................................","................................",".............#aaaa#.............",".............#aaaa#.............","..............#aa#..............","...............##...............","..........############..........",".........#bbbbbbbbbbbb#.........",".........#bbkkkkkkkkbb#.........",".........#bkkeeeeeekkb#.........",".........#bkeeeeeeeekb#.........",".........#bkkeeeeeekkb#.........",".........#bbkkkkkkkkbb#.........",".........#bb########bb#.........","..........############..........","..........#kk#....#kk#..........","...........##########...........","..........#bbbbbbbbbb#..........","..........#bbkbbbbkbb#..........","..........#bhbbbbbbhb#..........","..........#bhbbbbbbhb#..........","..........#bbkbbbbkbb#..........","..........#bbbbbbbbbb#..........","...........##########...........","........######....######........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........","........####........####........","........#bbb#......#bbb#........",".......#bbbb#......#bbbb#.......",".......######......######......."],
    ciccione: ["................................","................................",".............#aaaa#.............",".............#aaaa#.............","..............#aa#..............","...............##...............","..........############..........",".........#bbbbbbbbbbbb#.........",".........#bbkkkkkkkkbb#.........",".........#bkkeeeeeekkb#.........",".........#bkeeeeeeeekb#.........",".........#bkkeeeeeekkb#.........",".........#bbkkkkkkkkbb#.........",".........#bb########bb#.........","..........############..........","..........#kk#....#kk#..........","...##########################...","..#bbbbbbbbbbbbbbbbbbbbbbbbbb#..","..#bbkkbbbbbbbbbbbbbbbbbbkkbb#..","..#bhhbbbbbbbbbbbbbbbbbbbbhhb#..","..#bhhbbbbbbbbbbbbbbbbbbbbhhb#..","..#bhhbbbbbbbbbbbbbbbbbbbbhhb#..","..#bbkkbbbbbbbbbbbbbbbbbbkkbb#..","..#bbbbbbbbbbbbbbbbbbbbbbbbbb#..","........######....######........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........","........####........####........","........#bbb#......#bbb#........",".......#bbbb#......#bbbb#.......",".......######......######......."] };

  // ===== ROBOT COMPONIBILE NATIVO 32x32 (Strada 1 Tappa 2, varianti antenna/testa 8 lug 2026) =====
  // Il robot si assembla ANTENNA + TESTA + TORSO (come la vecchia versione a 16): la scelta
  // antenna/testa alla creazione torna a cambiare l aspetto. [0]=canone (pallina+quadrata),
  // [1]=doppia/tonda, [2]=piegata/visiera. Torso condiviso (teen ha le 3 varianti corpo).
  var ROBOT_ANTENNA32_TEEN = [["................................","................................",".............#aaaa#.............",".............#aaaa#.............","..............#aa#..............","...............##..............."],
    ["................................","............#a#..#a#............","............#a#..#a#............","............#a#..#a#............",".............#a##a#.............","...............##..............."],
    ["................................","...............#aa#.............","..............#aa#..............",".............#aa#...............","..............##................","...............##..............."]];
  var ROBOT_TESTA32_TEEN = [["..........############..........",".........#bbbbbbbbbbbb#.........",".........#bbkkkkkkkkbb#.........",".........#bkkeeeeeekkb#.........",".........#bkeeeeeeeekb#.........",".........#bkkeeeeeekkb#.........",".........#bbkkkkkkkkbb#.........",".........#bb########bb#.........","..........############..........","..........#kk#....#kk#.........."],
    ["..........############..........",".........#b#bbbbbbbb#b#.........",".........#bbkkkkkkkkbb#.........",".........#bkkeeeeeekkb#.........",".........#bkeeeeeeeekb#.........",".........#bkkeeeeeekkb#.........",".........#bbkkkkkkkkbb#.........",".........#b#bbbbbbbb#b#.........","..........############..........","..........#kk#....#kk#.........."],
    ["..........############..........",".........#bbbbbbbbbbbb#.........",".........#bbkkkkkkkkbb#.........",".........#kkeeeeeeeekk#.........",".........#kkeeeeeeeekk#.........",".........#kkeeeeeeeekk#.........",".........#bbkkkkkkkkbb#.........",".........#bb########bb#.........","..........############..........","..........#kk#....#kk#.........."]];
  var ROBOT_TORSO32_TEEN = { normale: ["..........############..........","..........#bbbbbbbbbb#..........",".......####bbbbbbbbbb####.......",".......#bb#bhhbbbbhhb#bb#.......",".......#bb#bhhbbbbhhb#bb#.......",".......#bb#bbkkbbkkbb#bb#.......",".......####bbbbbbbbbb####.......","..........#bbbbbbbbbb#..........","..........#bbbbbbbbbb#..........","..........#bbbbbbbbbb#..........","..........############..........","..........##........##..........","..........##........##..........",".........###........###.........","................................","................................"],
    magro: ["............########............","............#bbbbbb#............",".........####bbbbbb####.........",".........#bb#bhbbhb#bb#.........",".........#bb#bhbbhb#bb#.........",".........#bb#bkbbkb#bb#.........",".........####bbbbbb####.........","............#bbbbbb#............","............#bbbbbb#............","............#bbbbbb#............","............########............","..........##........##..........","..........##........##..........",".........###........###.........","................................","................................"],
    ciccione: ["......####################......","......#bbbbbbbbbbbbbbbbbb#......",".####bbbbbbbbbbbbbbbbbbbbbb####.",".#bb#bhhbbbbbbbbbbbbbbbbhhb#bb#.",".#bb#bhhbbbbbbbbbbbbbbbbhhb#bb#.",".#bb#bbkkbbbbbbbbbbbbbbkkbb#bb#.",".####bbbbbbbbbbbbbbbbbbbbbb####.","......#bbbbbbbbbbbbbbbbbb#......","......#bbbbbbbbbbbbbbbbbb#......","......#bbbbbbbbbbbbbbbbbb#......","......####################......","..........##........##..........","..........##........##..........",".........###........###.........","................................","................................"] };
  var ROBOT_ANTENNA32_BABY = [["................................","................................","................................",".............######.............",".............#aaaa#.............",".............#aaaa#.............","..............#aa#..............","...............##..............."],
    ["................................","................................","............#a#..#a#............","............#a#..#a#............","............#a#..#a#............",".............#a##a#.............","..............#..#..............","...............##..............."],
    ["................................","................................","...............#aa#.............","..............#aa#..............",".............#aa#...............","..............##................","..............##................","...............##..............."]];
  var ROBOT_TESTA32_BABY = [["..........############..........",".........#bbbbbbbbbbbb#.........",".........#bbkkkkkkkkbb#.........",".........#bkkkkkkkkkkb#.........",".........#bkkeeeeeekkb#.........",".........#bkeeeeeeeekb#.........",".........#bkkeeeeeekkb#.........",".........#bkkkkkkkkkkb#.........",".........#bkk######kkb#.........",".........#bkkkkkkkkkkb#.........",".........#bbbbbbbbbbbb#.........",".........#bbbhbbbbhbbb#.........",".........#bbbbbbbbbbbb#.........","..........############.........."],
    ["..........############..........",".........#b#bbbbbbbb#b#.........",".........#bbkkkkkkkkbb#.........",".........#bkkkkkkkkkkb#.........",".........#bkkeeeeeekkb#.........",".........#bkeeeeeeeekb#.........",".........#bkkeeeeeekkb#.........",".........#bkkkkkkkkkkb#.........",".........#bkk######kkb#.........",".........#bkkkkkkkkkkb#.........",".........#bbbbbbbbbbbb#.........",".........#bbbhbbbbhbbb#.........",".........#b#bbbbbbbb#b#.........","..........############.........."],
    ["..........############..........",".........#bbbbbbbbbbbb#.........",".........#bbkkkkkkkkbb#.........",".........#bkkkkkkkkkkb#.........",".........#kkeeeeeeeekk#.........",".........#kkeeeeeeeekk#.........",".........#kkeeeeeeeekk#.........",".........#bkkkkkkkkkkb#.........",".........#bkk######kkb#.........",".........#bkkkkkkkkkkb#.........",".........#bbbbbbbbbbbb#.........",".........#bbbhbbbbhbbb#.........",".........#bbbbbbbbbbbb#.........","..........############.........."]];
  var ROBOT_TORSO32_BABY = [".......###.##......##.###.......",".......#b#.##......##.#b#.......",".......###.##......##.###.......","..........###......###..........","................................","................................","................................","................................","................................","................................"];
  function buildRobot32Teen(antenna, testa, corpo) {
    var a = ROBOT_ANTENNA32_TEEN[antenna] || ROBOT_ANTENNA32_TEEN[0];
    var t = ROBOT_TESTA32_TEEN[testa] || ROBOT_TESTA32_TEEN[0];
    var tor = ROBOT_TORSO32_TEEN[corpo] || ROBOT_TORSO32_TEEN.normale;
    return a.concat(t, tor); // 6 + 10 + 16 = 32
  }
  function buildRobot32Baby(antenna, testa) {
    var a = ROBOT_ANTENNA32_BABY[antenna] || ROBOT_ANTENNA32_BABY[0];
    var t = ROBOT_TESTA32_BABY[testa] || ROBOT_TESTA32_BABY[0];
    return a.concat(t, ROBOT_TORSO32_BABY); // 8 + 14 + 10 = 32
  }

  // Torso ADULTO (P3 batch 3, arte a mano del regista — regola retro: stesso linguaggio visivo
  // del teen, MAI reinventare). L'adulto riusa ANTENNA e TESTA del teen (continuita' d'identita':
  // la faccia scelta alla nascita resta la sua per tutta la vita) e cambia SOLO il torso: +2px di
  // larghezza (spalle/petto 14 interno vs 12 del teen), braccia spostate 1px in fuori, riga
  // "cintura" k a meta' busto, gambe da 3px con piedi piu' grandi (il teen le ha da 2px). La linea
  // di terra e' IDENTICA al teen (piedi a riga 13 del torso, righe 14-15 vuote): niente sprofondi
  // ne' fluttuazioni cambiando stadio. Il ciccione e' gia' alla larghezza massima del canvas da
  // teen: da adulto guadagna la cintura (tirata) e i piedi grossi, non altra larghezza.
  var ROBOT_TORSO32_ADULTO = { normale: [".........##############.........",".........#bbbbbbbbbbbb#.........","......####bbbbbbbbbbbb####......","......#bb#bhhbbbbbbhhb#bb#......","......#bb#bhhbbbbbbhhb#bb#......","......#bb#bbkkbbbbkkbb#bb#......","......####bbbbbbbbbbbb####......",".........#bbbbbbbbbbbb#.........",".........#bbkkkkkkkkbb#.........",".........#bbbbbbbbbbbb#.........",".........##############.........",".........###........###.........",".........###........###.........","........####........####........","................................","................................"],
    magro: ["...........##########...........","...........#bbbbbbbb#...........","........####bbbbbbbb####........","........#bb#bhbbbbhb#bb#........","........#bb#bhbbbbhb#bb#........","........#bb#bkbbbbkb#bb#........","........####bbbbbbbb####........","...........#bbbbbbbb#...........","...........#bkkkkkkb#...........","...........#bbbbbbbb#...........","...........##########...........","..........##........##..........","..........##........##..........",".........###........###.........","................................","................................"],
    ciccione: ["......####################......","......#bbbbbbbbbbbbbbbbbb#......",".####bbbbbbbbbbbbbbbbbbbbbb####.",".#bb#bhhbbbbbbbbbbbbbbbbhhb#bb#.",".#bb#bhhbbbbbbbbbbbbbbbbhhb#bb#.",".#bb#bbkkbbbbbbbbbbbbbbkkbb#bb#.",".####bbbbbbbbbbbbbbbbbbbbbb####.","......#bbbbbbbbbbbbbbbbbb#......","......#bbkkkkkkkkkkkkkkbb#......","......#bbbbbbbbbbbbbbbbbb#......","......####################......",".........###........###.........",".........###........###.........","........####........####........","................................","................................"] };
  function buildRobot32Adulto(antenna, testa, corpo) {
    var a = ROBOT_ANTENNA32_TEEN[antenna] || ROBOT_ANTENNA32_TEEN[0];
    var t = ROBOT_TESTA32_TEEN[testa] || ROBOT_TESTA32_TEEN[0];
    var tor = ROBOT_TORSO32_ADULTO[corpo] || ROBOT_TORSO32_ADULTO.normale;
    return a.concat(t, tor); // 6 + 10 + 16 = 32
  }

  var ROBOT_TEEN_TORSO_ROWS = {
    10: { magro: "...##########...", ciccione: ".##############." },
    11: { magro: "...##bbbbbb##...", ciccione: "##bbbbbbbbbbbb##" },
    12: { magro: "...##bahhab##...", ciccione: "##bbaahhhhaabb##" },
    13: { magro: "...#bbbbbbbb#...", ciccione: ".#bbbbbbbbbbbb#." }
  };

  // ===== Selettori di frame =====
  // Tutti i corpi alieni sono ora arte NATIVA 32x32 (Strada 1 Tappa 2, rollout 8 lug 2026):
  // teen = full-frame per stato corpo (niente row-splice 16-indicizzato), baby = griglia singola.
  // Le vecchie griglie 16 (A_*, INS_*, REP_* + *_TEEN_ROWS) restano come riferimento E come
  // sorgente autoriale: teen/baby a 32 sono up2 fedeli di quelle griglie, gli adulto (P3) sono
  // disegnati a 16 e raddoppiati con lo stesso metodo (v. blocchi *_ADULTO32 sopra).
  function getAlienFrame(sottorazza, stadio, corpo) {
    if (sottorazza === "insettoide") {
      if (stadio === "adulto") return (INS_ADULTO32[corpo] || INS_ADULTO32.normale).slice();
      if (stadio === "teen") return (INS_TEEN32[corpo] || INS_TEEN32.normale).slice();
      return INS_BABY32.slice();
    }
    if (sottorazza === "rettiliano") {
      if (stadio === "adulto") return (REP_ADULTO32[corpo] || REP_ADULTO32.normale).slice();
      if (stadio === "teen") return (REP_TEEN32[corpo] || REP_TEEN32.normale).slice();
      return REP_BABY32.slice();
    }
    // blob default
    if (stadio === "adulto") return (A_ADULTO32[corpo] || A_ADULTO32.normale).slice();
    if (stadio === "teen") return (A_TEEN32[corpo] || A_TEEN32.normale).slice();
    return A_BABY32.slice();
  }

  function getRobotFrame(parts, stadio, corpo) {
    // Robot COMPONIBILE nativo 32x32 (Strada 1 Tappa 2, varianti antenna/testa): la scelta
    // antenna/testa alla creazione cambia di nuovo l'aspetto (assembla ANTENNA+TESTA+TORSO a 32).
    // antenna0/testa0 ricostruisce esattamente il canone (R_BABY32/R_TEEN32, ora solo riferimento).
    var antenna = (parts && parts.antenna) || 0;
    var testa = (parts && parts.testa) || 0;
    if (stadio === "adulto") return buildRobot32Adulto(antenna, testa, corpo);
    if (stadio === "teen") return buildRobot32Teen(antenna, testa, corpo);
    return buildRobot32Baby(antenna, testa);
  }

  // ===== LEGGENDE giocabili (P3 batch 6) =====
  // Gli 8 personaggi meme delle Grandi Imprese come PET: aspetto FISSO (non dipende da uovo/
  // razza/corpo — niente varianti ciccione/magro: l'icona e' l'icona), 3 stadi ciascuno,
  // NATIVI 32x32 (decisione fondatore 11 lug: per le leggende serve il DETTAGLIO — vivono di
  // riconoscibilita', il retro-16 non basta per un GigaChad credibile; up2 li lascia passare
  // intatti). Registry per id-Impresa
  // (m65..m72): si riempie una leggenda alla volta col feedback del fondatore; id mancanti
  // fanno fallback al frame alieno blob (mai crash). Giga Ciad e' VOLUTAMENTE in BIANCO E
  // NERO (palette dedicata): il meme e' in b/n, entra in scena cosi'.
  var PAL_LEGGENDA_BN = { "#": "#17171e", w: "#e8e8e8", b: "#9aa0a8", B: "#3c4048", e: "#17171e" };
  // Rocco Baldoria (m66): pelle calda, capelli neri, felpa grigia, GUANTONI ROSSI, cerotto.
  var PAL_LEGGENDA_ROCCO = { '#': '#17171e', w: '#ecc8a0', b: '#7a808c', B: '#282428', e: '#17171e', R: '#d83838', c: '#f4f4e8' };
  // Padre Maronno (m67, Maccio Capatonda): SAIO/COPERTA MARRONE B (cappuccio in testa) + BARBA h + volto beato.
  var PAL_LEGGENDA_MARONNO = { '#': '#17171e', w: '#e2c09e', b: '#bc966e', h: '#685c54', B: '#865c36', D: '#5c3e26', L: '#aa8052', e: '#17171e' };
  // Forrest Gampo (m68, Forrest Gump look-corsa): CAPPELLINO ROSSO R + capelli/barba h + camicia AZZURRA S + pantaloncini R + scarpe W.
  var PAL_LEGGENDA_FORREST = { '#': '#17171e', w: '#e6c29e', b: '#be9870', h: '#60422c', R: '#ce3630', r: '#962624', S: '#7ea8c8', s: '#5c84a8', W: '#eeeee8', e: '#17171e' };
  // Fabrice The Crown (m69, Fabrizio Corona post-carcere): capelli/barbone h, CORONCINA/catena ORO Y+y, torso pelle w, TATUAGGI t, pantaloni B.
  var PAL_LEGGENDA_FABRICE = { '#': '#17171e', w: '#ce9a66', b: '#aa784a', h: '#221c22', Y: '#e0b848', y: '#b08a2c', t: '#4e5c80', B: '#282632', K: '#12121a', e: '#17171e' };
  // Veggeta (m70, Vegeta): capelli h neri fiamma, armatura Saiyan corazza A/a beige, tuta blu S/s, guanti/stivali W, SCOUTER verde G.
  var PAL_LEGGENDA_VEGGETA = { '#': '#17171e', w: '#e8c098', b: '#c4986e', h: '#1a1820', A: '#ded6c4', a: '#aca492', S: '#36569c', s: '#263c74', W: '#eeeeec', G: '#50d678', e: '#17171e' };
  // Sceldon (m71, Sheldon Cooper): capelli castani h con riga, maglietta grafica T con FULMINE di Flash (cerchio rosso R + saetta gialla Y) sopra manica lunga U, pantaloni P, scarpe K, corpo lungo/magro.
  var PAL_LEGGENDA_SCELDON = { '#': '#17171e', w: '#ebc8a5', b: '#c8a078', h: '#6e4a2e', T: '#607692', U: '#d27838', R: '#ce3630', Y: '#eaca48', P: '#968462', K: '#2c2c36', e: '#17171e' };
  // Tonino Stark (m72, Iron Man / Tony Stark): capelli scuri h + BAFFI e PIZZETTO, armatura rossa R / oro G-g, guanti/stivali oro, REATTORE ARC azzurro (cyan C + nucleo bianco L) al centro del petto.
  var PAL_LEGGENDA_TONINO = { '#': '#17171e', w: '#e6be96', b: '#c4966e', h: '#2a221e', R: '#be2c2c', G: '#deb040', g: '#b08828', C: '#78d7eb', L: '#dcfaff', e: '#17171e' };
  var LEGGENDE = {
    m65: { nome: "Giga Ciad", pal: PAL_LEGGENDA_BN,
      baby: ["................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","..........############..........","..........#BBBBBBBBBB#..........","..........#wwwwwwwwww#..........","..........#wbeewweebw#..........",".......###wwwwwwwwwwww###.......",".......#wwwwwwwwwwwwwwww#.......",".......#BBBBBBBBBBBBBBBB#.......",".......#BBBBBbbbbbbBBBBB#.......",".......#BBBBBBBBBBBBBBBB#.......","........################........","..........#wwwwwwwwww#..........",".........#wwwwwwwwwwww#.........",".........#wwwwwwwwwwww#.........","..........#wwwwwwwwww#..........","...........##########...........","..........#ww#....#ww#..........","..........#ww#....#ww#..........",".........####......####........."],
      teen: ["................................","................................","................................","................................","........################........","........#BBBBBBBBBBBBBB#........","........#BwwwwwwwwwwwwB#........","........#wwwwwwwwwwwwww#........","........#wwBBBwwwwBBBww#........","........#wwbeewwwweebww#........","........#wwwwwwbbwwwwww#........",".....###wwwwwwwwwwwwwwww###.....",".....#wwwwwwwwwwwwwwwwwwww#.....",".....#BwwwwwwwwwwwwwwwwwwB#.....",".....#BBBBBBBBBBBBBBBBBBBB#.....",".....#BBBBBBBbbbbbbBBBBBBB#.....",".....#BBBBBBBBBBBBBBBBBBBB#.....",".....#BBBBBBBBBBBBBBBBBBBB#.....","......####################......",".........#wwwwwwwwwwww#.........","......###wwwwwwwwwwwwww###......","...##wwwwwwwwwwwwwwwwwwwwww##...","..#w#wwwwwwwwwwwwwwwwwwwwww#w#..","..#w#wwwwwwwwwwwwwwwwwwwwww#w#..","..#w#wwwwwwwwwwwwwwwwwwwwww#w#..","....#wwwwwwwwwwwwwwwwwwwwww#....","..........#ww#....#ww#..........","..........#ww#....#ww#..........","..........#ww#....#ww#..........","..........#ww#....#ww#..........","..........#ww#....#ww#..........",".........####......####........."],
      adulto: ["........################........","........#BBBBBBBBBBBBBB#........","........#BwwwwwwwwwwwwB#........","........#wwwwwwwwwwwwww#........","........#wwBBBwwwwBBBww#........","........#wwbeewwwweebww#........","........#wwwwwwbbwwwwww#........","........#wwwwwwbbwwwwww#........","....####wwwwwwwwwwwwwwww####....","....#wwwwwwwwwwwwwwwwwwwwww#....","....#BwwwwwwwwwwwwwwwwwwwwB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBBBBBbbbbbbBBBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....",".....######################.....",".........#wwwwwwwwwwww#.........",".........#wwwwwwwwwwww#.........",".....####wwwwwwwwwwwwww####.....",".###wwwwwwwwwwwwwwwwwwwwwwww###.","#www#wwwwwwwwwwwwwwwwwwwwww#www#","#www#wwwwwwwwwwwwwwwwwwwwww#www#","#www#wwwbbbbbwwwwwwbbbbbwww#www#",".#ww#wwwwwwwwwwbbwwwwwwwwww#ww#.",".#ww#wwbbwwwwwwbbwwwwwwbbww#ww#.","..###wwwwwwwwwwbbwwwwwwwwww###..",".....#wwwwwwwwwwwwwwwwwwww#.....","..........#ww#....#ww#..........","..........#ww#....#ww#..........","..........#ww#....#ww#..........",".........####......####........."] },

    m66: { nome: "Rocco Baldoria", pal: PAL_LEGGENDA_ROCCO,
      baby: ["................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","...........##########...........","..........#BBBBBBBBBB#..........","..........#wwwwwwwwww#..........","..........#wbeewweebw#..........","..........#wwwccccwww#..........","..........#wwbbwwbbww#..........",".#RRRR#...#wwwwwwwwww#...#RRRR#.","#RRRRRR#...##########...#RRRRRR#","#RRRRRR#..##bbbbbbbb##..#RRRRRR#","#RRRRRR#.#bbbbbbbbbbbb#.#RRRRRR#",".#RRRR#.#bbbbbbbbbbbbbb#.#RRRR#.","..####..#bbbbbbbbbbbbbb#..####..",".........#bbbbbbbbbbbb#.........","..........############..........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#BB#......#BB#.........","........####........####........"],
      teen: ["................................","................................","................................","................................","..........############..........",".........#BBBBBBBBBBBB#.........",".........#BwwwwwwwwwwB#.........",".........#wwwwwwwwwwww#.........",".........#wBBwwwwwwBBw#.........",".........#wbeewwwweebw#.........",".........#wwwwccccwwww#.........",".........#wwwbbwwbbwww#.........","..#RRR#..#wwwwwwwwwwww#..#RRR#..",".#RRRRR#..############..#RRRRR#.",".#RRRRR#...#wwwwwwww#...#RRRRR#.",".#RRRRR#.##bbbbbbbbbb##.#RRRRR#.","..#RRR#.#bbbbbbbbbbbbbb#.#RRR#..","...###..#bbbbbbbbbbbbbb#..###...","........#bbbbbbbbbbbbbb#........","........#bbbbbbbbbbbbbb#........",".........#bbbbbbbbbbbb#.........","..........############..........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#BB#......#BB#.........","........####........####........"],
      adulto: ["..........############..........",".........#BBBBBBBBBBBB#.........",".........#BBBBBBBBBBBB#.........",".........#BwwwwwwwwwwB#.........",".........#wwwwwwwwwwww#.........",".........#wBBwwwwwwBBw#.........",".........#wbeewwwweebw#.........",".........#wwwwccccwwww#.........",".........#wwwwwwwwwwww#.........",".........#wwwbbwwbbwww#.........",".#RRRR#..#wwwwwwwwwwww#..#RRRR#.","#RRRRRR#..############..#RRRRRR#","#RRRRRR#...#wwwwwwww#...#RRRRRR#","#RRRRRR#.##bbbbbbbbbb##.#RRRRRR#","#RRRRRR#bbbbbbbbbbbbbbbb#RRRRRR#",".#RRRR#bbbbbbbbbbbbbbbbbb#RRRR#.","..####.#bbbbbbbbbbbbbbbb#.####..",".......#bbbbbbbbbbbbbbbb#.......",".......#bbbbbbbbbbbbbbbb#.......",".......#bbbbbbbbbbbbbbbb#.......","........#bbbbbbbbbbbbbb#........","........#bbbbbbbbbbbbbb#........",".........##############.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#bb#......#bb#.........",".........#BB#......#BB#.........","........####........####........"] },
    m67: { nome: "Padre Maronno", pal: PAL_LEGGENDA_MARONNO,
      baby: ["................................","................................","................................","................................","................................","................................",".......#BBBBBBBBBBBBBBBB#.......","......#BBBBBBBBBBBBBBBBBB#......",".....#BBBBwwwwwwwwwwwwBBBB#.....",".....#BBBwwwwwwwwwwwwwwBBB#.....",".....#BBBwwweewwwweewwwBBB#.....",".....#BBBwwwwwbwwbwwwwwBBB#.....",".....#BBBhhhhhhhhhhhhhhBBB#.....","......#BBBhhhhhhhhhhhhBBB#......",".....#BBBBBBBBDBBDBBBBBBBB#.....",".....#BBBBBBBBBBBBBBBBBBBB#.....","....#BBLBBBBBBBBBBBBBBBBLBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBDBBBBBBBBBBBBDBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BLBBBBBBBBBBBBBBBBBBLB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBBBDBBBBBBBBDBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBDBBBBBBBBBBBBBBDBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#DDDDDDDDDDDDDDDDDDDDDD#....","....#DDDDDDDDDDDDDDDDDDDDDD#...."],
      teen: ["................................","................................","................................","......#BBBBBBBBBBBBBBBBBB#......",".....#BBBBBBBBBBBBBBBBBBBB#.....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBwwwwwwwwwwwwwwBBBB#....","....#BBBwwwwwwwwwwwwwwwwBBB#....","....#BBBwwweewwwwwweewwwBBB#....","....#BBBwwwwwwbwwbwwwwwwBBB#....","....#BBBhhwwwwwwwwwwwwhhBBB#....","....#BBBhhhhwwhhhhwwhhhhBBB#....","....#BBBhhhhhhhhhhhhhhhhBBB#....",".....#BBBhhhhhhhhhhhhhhBBB#.....","....#BBBBBBBBDBBBBDBBBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","...#BBLBBBBBBBBBBBBBBBBBBLBB#...","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#BBBBDBBBBBBBBBBBBBBDBBBB#...","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#BLBBBBBBBBBBBBBBBBBBBBLB#...","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#BBBBBBDBBBBBBBBBBDBBBBBB#...","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#BBBDBBBBBBBBBBBBBBBBDBBB#...","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#DDDDDDDDDDDDDDDDDDDDDDDD#...","...#DDDDDDDDDDDDDDDDDDDDDDDD#..."],
      adulto: ["......#BBBBBBBBBBBBBBBBBB#......",".....#BBBBBBBBBBBBBBBBBBBB#.....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBwwwwwwwwwwwwwwBBBB#....","....#BBBwwwwwwwwwwwwwwwwBBB#....","....#BBBwwweewwwwwweewwwBBB#....","....#BBBwwwwwwbwwbwwwwwwBBB#....","....#BBBhhwwwwwwwwwwwwhhBBB#....","....#BBBhhhhwwhhhhwwhhhhBBB#....","....#BBBhhhhhhhhhhhhhhhhBBB#....",".....#BBBhhhhhhhhhhhhhhBBB#.....","....#BBBBBBBBDDBBDDBBBBBBBB#....","...#BBBBBBBBBBBBBBBBBBBBBBBB#...","...#BBDDBBBBBBBBBBBBBBBBDDBB#...","..#BBBBBBBBBBBBBBBBBBBBBBBBBB#..","..#BBLLBBBBBBBBBBBBBBBBBBLLBB#..","..#BBBBBBBBDBBBBBBBBDBBBBBBBB#..",".#BBBBBBBBBBBBBBBBBBBBBBBBBBBB#.",".#BBLBBBBBBBBBBBBBBBBBBBBBBLBB#.",".#BBBBBBBDBBBBBBBBBBBBDBBBBBBB#.",".#BBBBBBBBBBBBBBBBBBBBBBBBBBBB#.",".#BLBBBBBBBBDBBBBBBDBBBBBBBBLB#.",".#BBBBBBBBBBBBBBBBBBBBBBBBBBBB#.",".#BBBBBDBBBBBBBBBBBBBBBBDBBBBB#.",".#BBBBBBBBBBBBBBBBBBBBBBBBBBBB#.",".#BBBLBBBBBBBBBBBBBBBBBBBBLBBB#.",".#BBBBBBBBBBBBBBBBBBBBBBBBBBBB#.",".#BBBBBBBBDBBBBBBBBBBDBBBBBBBB#.",".#BBBBBBBBBBBBBBBBBBBBBBBBBBBB#.",".#BBBBBBBBBBBBBBBBBBBBBBBBBBBB#.",".#DDDDDDDDDDDDDDDDDDDDDDDDDDDD#.",".#DDDDDDDDDDDDDDDDDDDDDDDDDDDD#."] },
    m68: { nome: "Forrest Gampo", pal: PAL_LEGGENDA_FORREST,
      baby: ["................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","................................","........#RRRRRRRRRRRRRR#........",".......#RRRRRRRRRRRRRRRR#.......","......#RRRRRRRRRRRRRRRRRR#......","......#hhhwwwwwwwwwwwwhhh#......","......#hhhwweewwwweewwhhh#......","......#hhhwwwwbwwbwwwwhhh#......","......#hhhhhhhhhhhhhhhhhh#......","......#hhhhhhhhhhhhhhhhhh#......",".......#hhhhhhwwwwhhhhhh#.......","......#SSSSSSSSSSSSSSSSSS#......","....#w.#SSSSSSSSSSSSSSSS#.w#....","....#w.#SSsSSSSSSSSSSsSS#.w#....",".......#SSSSSSSSSSSSSSSS#.......",".......#RRRRRRRRRRRRRRRR#.......",".......#RRrRRRRRRRRRRrRR#.......",".......#RRRRRRRRRRRRRRRR#.......",".........#ww#......#ww#.........",".........#ww#......#ww#.........",".........#WW#......#WW#.........","........#WWW#......#WWW#........","........#RRR#......#RRR#........"],
      teen: ["................................","................................",".......#RRRRRRRRRRRRRRRR#.......","......#RRRRRRRRRRRRRRRRRR#......",".....#RRRRRRRRRRRRRRRRRRRR#.....","....#RRRRRRRRRRRRRRRRRRRRRR#....","....#hhhwwwwwwwwwwwwwwwwhhh#....","....#hhhwwweewwwwwweewwwhhh#....","....#hhhwwwwwwbwwbwwwwwwhhh#....","....#hhhhhwwwwwwwwwwwwhhhhh#....","....#hhhhhhhwwhhhhwwhhhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....","......#hhhhhhwwwwwwhhhhhh#......",".....#SSSSSSSSSSSSSSSSSSSS#.....","...#ww#SSSSSSSSSSSSSSSSSS#ww#...","...#ww#SSsSSSSSSSSSSSSsSS#ww#...","....#w#SSSSSSSSSSSSSSSSSS#w#....","......#SSSSSSSSSSSSSSSSSS#......","......#RRRRRRRRRRRRRRRRRR#......","......#RRrRRRRRRRRRRRRrRR#......","......#RRRRRRRRRRRRRRRRRR#......","........#www#......#www#........","........#www#......#www#........","........#www#......#www#........","........#www#......#www#........","........#www#......#www#........","........#www#......#www#........","........#WWW#......#WWW#........","........#WWW#......#WWW#........",".......#WWWW#......#WWWW#.......",".......#RRRR#......#RRRR#......."],
      adulto: [".......#RRRRRRRRRRRRRRRR#.......","......#RRRRRRRRRRRRRRRRRR#......",".....#RRRRRRRRRRRRRRRRRRRR#.....","....#rRRRRRRRRRRRRRRRRRRRRr#....","....#RRRRRRRRRRRRRRRRRRRRRR#....","....#hhhwwwwwwwwwwwwwwwwhhh#....","....#hhhwwweewwwwwweewwwhhh#....","....#hhhwwwwwwbwwbwwwwwwhhh#....","....#hhhhhwwwwwwwwwwwwhhhhh#....","....#hhhhhhhwwhhhhwwhhhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....","......#hhhhhhwwwwwwhhhhhh#......","....#SSSSSSSSSSSSSSSSSSSSSS#....","...#SSSSSSSSSSSSSSSSSSSSSSSS#...","..#ww#SSSSSSSSSSSSSSSSSSSS#ww#..","..#ww#SSSsSSSSSSSSSSSSsSSS#ww#..","..#ww#SSSSSSSSSSSSSSSSSSSS#ww#..","...#w#SSSSSSsSSSSSSsSSSSSS#w#...",".....#SSSSSSSSSSSSSSSSSSSS#.....",".....#RRRRRRRRRRRRRRRRRRRR#.....",".....#RRrRRRRRRRRRRRRRRrRR#.....",".....#RRRRRRRRRRRRRRRRRRRR#.....","........#www#......#www#........","........#www#......#www#........","........#www#......#www#........","........#www#......#www#........","........#www#......#www#........","........#WWW#......#WWW#........","........#WWW#......#WWW#........",".......#WWWW#......#WWWW#.......",".......#RRRR#......#RRRR#......."] },
    m69: { nome: "Fabrice The Crown", pal: PAL_LEGGENDA_FABRICE,
      baby: ["................................","................................","................................","................................","................................","................................","................................","................................","................................","................................",".........Y...Y....Y...Y.........",".......#yYYYYYYYYYYYYYYy#.......","......#hhhhhhhhhhhhhhhhhh#......","......#hhhwweewwwweewwhhh#......","......#hhhwwwwbwwbwwwwhhh#......","......#hhhhhwwhhhhwwhhhhh#......","......#hhhhhhhhhhhhhhhhhh#......",".......#hhhhhhwwwwhhhhhh#.......","......#wwwwwwwwYYwwwwwwww#......",".....#wwwwtwwwwwwwwwwtwwww#.....","......#wwwwwbwwwwwwbwwwww#......",".......#BBBBBBBBBBBBBBBB#.......",".......#BBBBBBBYYBBBBBBB#.......",".......#BBBBBBBBBBBBBBBB#.......",".........#BB#......#BB#.........",".........#BB#......#BB#.........",".........#BB#......#BB#.........",".........#BB#......#BB#.........",".........#BB#......#BB#.........",".........#BB#......#BB#.........","........#KKK#......#KKK#........","........#KKK#......#KKK#........"],
      teen: ["................................","................................",".......Y...Y...YY...Y...Y.......",".....#yYYYYYYYYyyYYYYYYYYy#.....","....#hhhhhhhhhhhhhhhhhhhhhh#....","....#hhhhwwwwwwwwwwwwwwhhhh#....","....#hhhwwweewwwwwweewwwhhh#....","....#hhhwwwwwwbwwbwwwwwwhhh#....","....#hhhhhwwwwhhhhwwwwhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....",".....#hhhhhhhhwwwwhhhhhhhh#.....","......#hhhhhhwwwwwwhhhhhh#......",".....#wwwwwwwwwYYwwwwwwwww#.....",".....#wwwwwwbwwYYwwbwwwwww#.....",".....#wwwtwwwwwwwwwwwwtwww#.....","......#wwwwwbwwwwwwbwwwww#......","......#wtwwwwwwwwwwwwwwtw#......","......#BBBBBBBBBBBBBBBBBB#......","......#BBBBBBBBYYBBBBBBBB#......","......#BBBBBBBBBBBBBBBBBB#......","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........",".......#KKKK#......#KKKK#.......",".......#KKKK#......#KKKK#......."],
      adulto: [".......Y...Y...YY...Y...Y.......",".....#yYYYYYYYYyyYYYYYYYYy#.....","....#hhhhhhhhhhhhhhhhhhhhhh#....","....#hhhhwwwwwwwwwwwwwwhhhh#....","....#hhhwwwwwwwwwwwwwwwwhhh#....","....#hhhwwweewwwwwweewwwhhh#....","....#hhhwwwwwwbwwbwwwwwwhhh#....","....#hhhhhwwwwhhhhwwwwhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....","....#hhhhhhhhhhhhhhhhhhhhhh#....",".....#hhhhhhhhwwwwhhhhhhhh#.....","......#hhhhhhwwwwwwhhhhhh#......","....#wwwwwwwwwwYYwwwwwwwwww#....","...#bwwwwwwwwwwYYwwwwwwwwwwb#...","...#wwwwttwwbwwwwwwbwwttwwww#...","...#wwwwwwwbbwwwwwwbbwwwwwww#...","...#wwtwwwwwwtwwwwtwwwwwwtww#...","....#wwwbwwwwwwwwwwwwwwbwww#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","....#BBBBBBBBBBYYBBBBBBBBBB#....","....#BBBBBBBBBBBBBBBBBBBBBB#....","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........","........#BBB#......#BBB#........",".......#KKKK#......#KKKK#.......",".......#KKKK#......#KKKK#......."] },
    m70: { nome: "Veggeta", pal: PAL_LEGGENDA_VEGGETA,
      baby: ["................................","................................","................................","................................","................................","................................","................................","................................",".............hhhhhh.............","...........hhhhhhhhhh...........",".........hhhhhhhhhhhhhh.........","......#hhhhwwwwhhwwwwhhhh#......","......#hhhwwwwwwwwwwwwhhh#......","......#hhhwhhwwwwwwhhwhhh#......","......#hhhw#GG#wwweewwhhh#......","......#hhhwwwwbwwbwwwwhhh#......",".......#hhhwwwwwwwwwwhhh#.......","........#wwwwwwwwwwwwww#........","....#AAAAAAAAASSSSAAAAAAAAA#....",".....SSAAAAAAAAAAAAAAAAAASS.....",".....WWAAAAAAAAAAAAAAAAAAWW.....","......#ASSSSSSSSSSSSSSSSA#......","......#SSSSSSSSSSSSSSSSSS#......","......#SSSSSSSSSSSSSSSSSS#......",".........#SS#......#SS#.........",".........#SS#......#SS#.........",".........#SS#......#SS#.........",".........#SS#......#SS#.........",".........#WW#......#WW#.........",".........#WW#......#WW#.........","........#WWW#......#WWW#........","........#aaa#......#aaa#........"],
      teen: ["................................","..............hhhh..............",".............hhhhhh.............","...........hhhhhhhhhh...........",".........hhhhhhhhhhhhhh.........","......h.hhhhhhhhhhhhhhhh.h......",".....#hhhhwwwwhhhhwwwwhhhh#.....",".....#hhwwwwwwwwwwwwwwwwhh#.....",".....#hhwhhhwwwwwwwwhhhwhh#.....",".....#hhwww#GG#wwwweewwwhh#.....",".....#hhwwwwwwbwwbwwwwwwhh#.....","......#hhwwwwwwwwwwwwwwhh#......",".......#wwwwwwwwwwwwwwww#.......","...#aAAAAAAAAASSSSAAAAAAAAAa#...","....SSAAAAAAAAAAAAAAAAAAAASS....","....SSAAAaAAAAAAAAAAAAaAAASS....","....WWAAAAAAAAAAAAAAAAAAAAWW....",".....#AASSSSSSSSSSSSSSSSAA#.....",".....#SSSSSSSSSSSSSSSSSSSS#.....",".....#SSSSSSSSSSSSSSSSSSSS#.....",".....#SSSSSSSSSSSSSSSSSSSS#.....","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#WWW#......#WWW#........","........#WWW#......#WWW#........",".......#WWWW#......#WWWW#.......",".......#WWWW#......#WWWW#.......",".......#aaaa#......#aaaa#......."],
      adulto: ["..............hhhh..............","............hhhhhhhh............","..........hhhhhhhhhhhh..........",".........hhhhhhhhhhhhhh.........",".......h.hhhhhhhhhhhhhh.h.......","......hhhhhhhhhhhhhhhhhhhh......",".....#hhhhwwwwhhhhwwwwhhhh#.....",".....#hhwwwwwwwwwwwwwwwwhh#.....",".....#hhwhhhwwwwwwwwhhhwhh#.....",".....#hhwww#GG#wwwweewwwhh#.....",".....#hhwwwwwwbwwbwwwwwwhh#.....",".....#hhwwwwwwwbbwwwwwwwhh#.....","......#hhwwwwwwwwwwwwwwhh#......",".......#wwwwwwwwwwwwwwww#.......","..#aAAAAAAAAAASSSSAAAAAAAAAAa#..","...SSAAAAAAAAAAAAAAAAAAAAAASS...","...SSAAAAaaAAAAAAAAAAaaAAAASS...","...SSAAAAAAAAAAAAAAAAAAAAAASS...","...WWAAAAAAAAAAAAAAAAAAAAAAWW...","....#aAAASSSSSSSSSSSSSSAAAa#....","....#SSSSSSSSSSSSSSSSSSSSSS#....","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#SSS#......#SSS#........","........#WWW#......#WWW#........","........#WWW#......#WWW#........",".......#WWWW#......#WWWW#.......",".......#WWWW#......#WWWW#.......",".......#aaaa#......#aaaa#......."] },
    m71: { nome: "Sceldon", pal: PAL_LEGGENDA_SCELDON,
      baby: ["................................","................................","................................","................................","................................","................................","................................","................................","................................","......#hhhhhhhhhhhhhhhhhh#......","......#hhhwwwwwwwwwwwwhhh#......","......#hhhwweewwwweewwhhh#......","......#hhhwwwwbwwbwwwwhhh#......","......#hhhwwwbwwwwbwwwhhh#......",".......#hhhwwwwwwwwwwhhh#.......","........#wwwwwwwwwwwwww#........",".....UUTTTTTTTTTTTTTTTTTTUU.....",".....UUTTTTTTTRRRYTTTTTTTUU.....",".....UUTTTTTTRRRYYRTTTTTTUU.....",".....##wTTTTTRRYYRRTTTTTw##.....",".....#TTTTTTTTRYRRTTTTTTTT#.....","......#PPPPPPPPPPPPPPPPPP#......","......#PPPPPPPPPPPPPPPPPP#......",".........#PP#......#PP#.........",".........#PP#......#PP#.........",".........#PP#......#PP#.........",".........#PP#......#PP#.........",".........#PP#......#PP#.........",".........#PP#......#PP#.........",".........#KK#......#KK#.........","........#KKK#......#KKK#........","........#KKK#......#KKK#........"],
      teen: ["................................","................................",".....#hhhhhhhhhhhhhhhhhhhh#.....","....#hhhhhhhhhhbbhhhhhhhhhh#....","....#hhhhwwwwwwwwwwwwwwhhhh#....","....#hhhwwwwwwwwwwwwwwwwhhh#....","....#hhhwwweewwwwwweewwwhhh#....","....#hhhwwwwwwbwwbwwwwwwhhh#....","....#hhhwwwwbwwwwwwbwwwwhhh#....",".....#hhhwwwwwwwwwwwwwwhhh#.....","......#wwwwwwwwwwwwwwwwww#......","....UUTTTTTTTTTTTTTTTTTTTTUU....","....UUTTTTTTTTRRRYTTTTTTTTUU....","....UUTTTTTTTRRRYYRTTTTTTTUU....","....UUTTTTTTTRRYYRRTTTTTTTUU....","....#wTTTTTTTTRYRRTTTTTTTTw#....","....#TTTTTTTTTTTTTTTTTTTTTT#....",".....#PPPPPPPPPPPPPPPPPPPP#.....",".....#PPPPPPPPPPPPPPPPPPPP#.....","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#KKK#......#KKK#........",".......#KKKK#......#KKKK#.......",".......#KKKK#......#KKKK#.......",".......#KKKK#......#KKKK#......."],
      adulto: [".....#hhhhhhhhhhhhhhhhhhhh#.....","....#hhhhhhhhhhbbhhhhhhhhhh#....","....#hhhhwwwwwwwwwwwwwwhhhh#....","....#hhhwwwwwwwwwwwwwwwwhhh#....","....#hhhwwweewwwwwweewwwhhh#....","....#hhhwwwwwwbwwbwwwwwwhhh#....","....#hhhwwwwbwwwwwwbwwwwhhh#....",".....#hhhwwwwwwwwwwwwwwhhh#.....","......#wwwwwwwwwwwwwwwwww#......","...UUTTTTTTTTTTTTTTTTTTTTTTUU...","...UUTTTTTTTTTTTTTTTTTTTTTTUU...","...UUTTTTTTTTTRRRYTTTTTTTTTUU...","...UUTTTTTTTTRRRYYRTTTTTTTTUU...","...UUTTTTTTTTRRYYRRTTTTTTTTUU...","...#wTTTTTTTTTRYRRTTTTTTTTTw#...","...#TTTTTTTTTTTTTTTTTTTTTTTT#...","....#PPPPPPPPPPPPPPPPPPPPPP#....","....#PPPPPPPPPPPPPPPPPPPPPP#....","....#PPPPPPPPPPPPPPPPPPPPPP#....","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#PPP#......#PPP#........","........#KKK#......#KKK#........",".......#KKKK#......#KKKK#.......",".......#KKKK#......#KKKK#.......",".......#KKKK#......#KKKK#......."] },
    m72: { nome: "Tonino Stark", pal: PAL_LEGGENDA_TONINO,
      baby: ["................................","................................","................................","................................","................................","................................","................................","................................","................................","......#hhhhhhhhhhhhhhhhhh#......","......#hhhwwwwwwwwwwwwhhh#......","......#hhhwweewwwweewwhhh#......","......#hhhwwwwbwwbwwwwhhh#......",".......#wwwwwhhhhhhwwwww#.......",".......#wwwwwwhhhhwwwwww#.......","........#wwwwwwwwwwwwww#........","...GGRRRRRRRRRRRRRRRRRRRRRRGG...","...#RRRRRRRRRRRCCRRRRRRRRRRR#...","...#RRRRRRRRRRCLLCRRRRRRRRRR#...","...#GRRRRRRRRRCLLCRRRRRRRRRG#...","....GRRRRRRRRRRCCRRRRRRRRRRG....","....#GGGGGGGGGGGGGGGGGGGGGG#....",".........#RR#......#RR#.........",".........#RR#......#RR#.........",".........#RR#......#RR#.........",".........#RR#......#RR#.........",".........#RR#......#RR#.........",".........#RR#......#RR#.........",".........#GG#......#GG#.........",".........#GG#......#GG#.........","........#GGG#......#GGG#........","........#ggg#......#ggg#........"],
      teen: ["................................","................................","......#hhhhhhhhhhhhhhhhhh#......",".....#hhhhhhhhhhhhhhhhhhhh#.....",".....#hhhwwwwwwwwwwwwwwhhh#.....",".....#hhhwweewwwwwweewwhhh#.....",".....#hhhwwwwwbwwbwwwwwhhh#.....","......#wwwwwwhhhhhhwwwwww#......","......#wwwwwwwwbbwwwwwwww#......",".......#wwwwwwhhhhwwwwww#.......",".......#wwwwwwwhhwwwwwww#.......","..GGRRRRRRRRRRRRRRRRRRRRRRRRGG..","..#GRRRRRRRRRRRCCRRRRRRRRRRRG#..","..#RRRRRRRRRRRCLLCRRRRRRRRRRR#..","..#RRRRRRRRRRRCLLCRRRRRRRRRRR#..","..#GRRRRRRRRRRRCCRRRRRRRRRRRG#..","...GRRRRRRRRRRRRRRRRRRRRRRRRG...","...#GGGGGGGGGGGGGGGGGGGGGGGG#...","....#RRRRRRRRRRRRRRRRRRRRRR#....","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#GGG#......#GGG#........","........#GGG#......#GGG#........",".......#GGGG#......#GGGG#.......",".......#GGGG#......#GGGG#.......",".......#gggg#......#gggg#.......",".......#gggg#......#gggg#......."],
      adulto: ["......#hhhhhhhhhhhhhhhhhh#......",".....#hhhhhhhhhhhhhhhhhhhh#.....",".....#hhhwwwwwwwwwwwwwwhhh#.....",".....#hhhwweewwwwwweewwhhh#.....",".....#hhhwwwwwbwwbwwwwwhhh#.....","......#wwwwwwhhhhhhwwwwww#......","......#wwwwwwwwbbwwwwwwww#......",".......#wwwwwwhhhhwwwwww#.......",".......#wwwwwwwhhwwwwwww#.......","..GGRRRRRRRRRRRRRRRRRRRRRRRRGG..","..#GRRRRRRRRRRRRRRRRRRRRRRRRG#..","..#RRRRRRRRRRRRCCRRRRRRRRRRRR#..","..#RRRRRRRRRRRCLLCRRRRRRRRRRR#..","..#RRRRRRRRRRRCLLCRRRRRRRRRRR#..","..#GRRRRRRRRRRRCCRRRRRRRRRRRG#..","...GRRRRRRRRRRRRRRRRRRRRRRRRG...","...#GGGGGGGGGGGGGGGGGGGGGGGG#...","....#RRRRRRRRRRRRRRRRRRRRRR#....","....#RRRRRRRRRRRRRRRRRRRRRR#....","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#RRR#......#RRR#........","........#GGG#......#GGG#........","........#GGG#......#GGG#........",".......#GGGG#......#GGGG#.......",".......#GGGG#......#GGGG#.......",".......#gggg#......#gggg#.......",".......#gggg#......#gggg#......."] }
    // LEGGENDE COMPLETE 8/8 (m65-m72)
  };
  function getLeggendaFrame(leggendaId, stadio) {
    var reg = LEGGENDE[leggendaId];
    if (!reg) return null; // fallback gestito dal chiamante (resolvePet)
    var g = reg[stadio] || reg.baby;
    return g.slice();
  }
  function getLeggendaPalette(leggendaId) {
    var reg = LEGGENDE[leggendaId];
    return (reg && reg.pal) || PAL_LEGGENDA_BN;
  }

  function getPalette(razza, sottorazza, colore) {
    var idx = colore || 0;
    if (razza === "robot") return PAL_ROBOT[idx] || PAL_ROBOT[0];
    if (sottorazza === "insettoide") return PAL_INS[idx] || PAL_INS[0];
    if (sottorazza === "rettiliano") return PAL_REP[idx] || PAL_REP[0];
    return PAL_BLOB[idx] || PAL_BLOB[0];
  }

  // ===== Overlay sporco: macchie deterministiche (seed dalla forma) + 2 moschine animabili =====
  var DIRT_COLOR = "#8a6a42";
  var FLY_COLOR = "#141414";

  // hash semplice e deterministico da stringa (nessun random a runtime)
  function hashStr(s) {
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = (h * 16777619) >>> 0;
    }
    return h >>> 0;
  }

  function findBodyPixels(frame) {
    var pts = [];
    for (var y = 0; y < frame.length; y++) {
      var row = frame[y];
      for (var x = 0; x < row.length; x++) {
        if (row[x] !== "." && row[x] !== "#") pts.push([x, y]);
      }
    }
    return pts;
  }

  function drawDirtOverlay(ctx, frame, scale, ox, oy) {
    ox = ox || 0; oy = oy || 0;
    var seed = hashStr(frame.join("\n"));
    var pts = findBodyPixels(frame);
    if (pts.length === 0) return;
    var n = 4 + (seed % 3); // 4-6 macchie
    var used = {};
    ctx.fillStyle = DIRT_COLOR;
    var s = seed;
    for (var i = 0; i < n; i++) {
      s = (s * 1103515245 + 12345) >>> 0;
      var pick = s % pts.length;
      var key = pick;
      var tries = 0;
      while (used[key] && tries < pts.length) {
        pick = (pick + 1) % pts.length;
        key = pick;
        tries++;
      }
      used[key] = true;
      var p = pts[pick];
      ctx.fillRect(ox + p[0] * scale, oy + p[1] * scale, scale, scale);
    }
  }

  function drawFlies(ctx, frame, scale, flyFrame, ox, oy) {
    ox = ox || 0; oy = oy || 0;
    var seed = hashStr(frame.join("|") + "_flies");
    var w = frame[0].length, h = frame.length;
    // due posizioni fisse (deterministiche) appena sopra/lato al corpo, alternate su 2 frame
    var basePositions = [
      { x: (seed % (w - 2)) + 1, y: (Math.floor(seed / 7) % 3) },
      { x: ((seed >> 3) % (w - 2)) + 1, y: (Math.floor(seed / 11) % 3) + 1 }
    ];
    ctx.fillStyle = FLY_COLOR;
    basePositions.forEach(function (p, i) {
      var offset = flyFrame === 1 ? (i % 2 === 0 ? 1 : -1) : 0;
      var fx = Math.max(0, Math.min(w - 1, p.x + offset));
      var fy = p.y;
      ctx.fillRect(ox + fx * scale, oy + fy * scale, scale, scale);
    });
  }

  // ===== Draw pubblico =====
  // risolve petLike in frame+palette (condiviso tra draw e cartoline). "adulto" passa attraverso
  // (P3: getRobotFrame/getAlienFrame lo trattano gia' come placeholder = teen), solo "teen"/altro
  // sono normalizzati qui come prima.
  function resolvePet(petLike) {
    var stadio = (petLike.stadio === "teen" || petLike.stadio === "adulto") ? petLike.stadio : "baby";
    var corpo = petLike.corpo || "normale";
    var parts = petLike.parts || {};
    // Leggende (P3 batch 6): aspetto fisso per id, palette dedicata; id non ancora
    // disegnato -> fallback blob (mai crash, si vede il segnaposto).
    if (petLike.razza === "leggenda") {
      var frameLeg = getLeggendaFrame(petLike.leggendaId, stadio);
      if (frameLeg) return { frame: up2(frameLeg), palette: getLeggendaPalette(petLike.leggendaId) };
    }
    var razza = petLike.razza === "robot" ? "robot" : "alieno";
    var sottorazza = petLike.sottorazza || "blob";
    var frame = razza === "robot"
      ? getRobotFrame(parts, stadio, corpo)
      : getAlienFrame(sottorazza, stadio, corpo);
    // porta il frame allo spazio-coordinate 32 (up2 raddoppia i 16, lascia passare i 32 nativi)
    return { frame: up2(frame), palette: getPalette(razza, sottorazza, parts.colore) };
  }

  // dipinge un frame a griglia sul ctx, con offset in pixel destinazione
  function paintFrame(ctx, frame, palette, scale, ox, oy) {
    for (var y = 0; y < frame.length; y++) {
      var row = frame[y];
      for (var x = 0; x < row.length; x++) {
        var ch = row[x];
        if (ch === ".") continue;
        ctx.fillStyle = palette[ch] || "#ff00ff"; // magenta = carattere palette mancante (debug visivo)
        ctx.fillRect(ox + x * scale, oy + y * scale, scale, scale);
      }
    }
  }

  // ===== OVERLAY EQUIPAGGIAMENTO (PROTOTIPO 2, fase sprite): vestiti indossati + arma impugnata,
  // disegnati SOPRA il pet ai punti-ancora della sua razza/stadio. Stesso pattern di
  // drawDirtOverlay/drawFlies (dopo il frame, a scale/offset). Ancore in coord 16x16 verificate
  // sui frame reali (testaTop = cima testa; manoDx/manoSx = mani/lati; corpo = centro torso). =====
  // Ancore ritarate sui NUOVI corpi 32 (8 lug 2026): corpo.x = 8 (centro) per tutti cosi' i
  // vestiti-corpo si centrano (con ax = meta' larghezza griglia); corpo.y ABBASSATo perche' i
  // corpi 32 sono piu' alti (il torso sta piu' in basso: prima il vestito finiva sulla testa);
  // testaTop = cima della testa vera (sotto le antenne). manoDx/manoSx = lati all'altezza mani.
  var ANCHORS = {
    robot_baby:      { testaTop: [8, 4], manoDx: [12, 10], manoSx: [4, 10], corpo: [8, 8] },
    robot_teen:      { testaTop: [8, 3], manoDx: [12, 9],  manoSx: [4, 9],  corpo: [8, 10] },
    blob_baby:       { testaTop: [8, 7], manoDx: [13, 11], manoSx: [3, 11], corpo: [8, 11] },
    blob_teen:       { testaTop: [8, 3], manoDx: [13, 11], manoSx: [3, 11], corpo: [8, 12] },
    insettoide_baby: { testaTop: [8, 7], manoDx: [11, 12], manoSx: [5, 12], corpo: [8, 11] },
    insettoide_teen: { testaTop: [8, 4], manoDx: [11, 10], manoSx: [5, 10], corpo: [8, 11] },
    // Rettiliano v3 "lucertola slanciata": baby v2 (testa r5, pancia r11-12, fianchi r12);
    // teen = testa r1, braccia snelle interne (b a col 4 / col 11), petto r9-11;
    // adulto = braccia a due segmenti (b a col 2 / col 13), artigli r11, petto r9-12.
    rettiliano_baby: { testaTop: [8, 5], manoDx: [11, 12], manoSx: [4, 12], corpo: [8, 11] },
    rettiliano_teen: { testaTop: [8, 1], manoDx: [11, 9],  manoSx: [4, 9],  corpo: [8, 10] },
    // Ancore ADULTO (P3 batch 3): robot/mantide = geometrie teen (verificate: mani/testa cadono
    // giusti); blob = corpo +1 per lato.
    robot_adulto:      { testaTop: [8, 3], manoDx: [12, 9],  manoSx: [4, 9],  corpo: [8, 10] },
    blob_adulto:       { testaTop: [8, 3], manoDx: [14, 11], manoSx: [1, 11], corpo: [8, 12] },
    insettoide_adulto: { testaTop: [8, 4], manoDx: [11, 10], manoSx: [5, 10], corpo: [8, 11] },
    rettiliano_adulto: { testaTop: [8, 1], manoDx: [13, 10], manoSx: [2, 10], corpo: [8, 10] },
    // Leggende (batch 6): geometria di Giga Ciad, condivisa (si specializza se serve)
    leggenda_baby:   { testaTop: [8, 3], manoDx: [12, 10], manoSx: [3, 10], corpo: [8, 10] },
    leggenda_teen:   { testaTop: [8, 1], manoDx: [13, 9],  manoSx: [2, 9],  corpo: [8, 10] },
    leggenda_adulto: { testaTop: [8, 0], manoDx: [14, 9],  manoSx: [1, 9],  corpo: [8, 10] }
  };
  // Sprite equip: g = griglia pixel-string ('.'=trasparente), pal = palette, target = ancora a cui
  // agganciarsi, (ax,ay) = cella di riferimento della griglia che va sull'ancora.
  // Sprite equip v2 (playtest 8 lug 2026: "vestiti e armi poco visibili quando equipaggiati"):
  // forme piu' GRANDI + contorno scuro K (#17171e) per staccare dal pet e dallo sfondo, un
  // colore d'accento vivo per il riconoscimento a colpo d'occhio.
  var VESTITO_SPR = {
    // ===== COMPLETI (cosmetici puri, 29 lug 2026) — due pezzi: testa + corpo =====
    'Tuta Spaziale': { parti: [
      { target: 'testaTop', ax: 4, ay: 4, pal: { K: '#17171e', W: '#eef2f8', C: '#5cd8f0' },
        g: ['..KKKK..', '.KWWWWK.', 'KWCCCCWK', 'KWWWWWWK', '.KKKKKK.'] },
      { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', W: '#eef2f8', O: '#f08030', c: '#5cd8f0' },
        g: ['KW....WK', 'KWWWWWWK', 'KWOOOOWK', 'KWcWWcWK', '.KWWWWK.', '.KKKKKK.'] }
    ] },
    'Armatura del Cavaliere': { parti: [
      { target: 'testaTop', ax: 3, ay: 4, pal: { K: '#17171e', M: '#a8b0bc', m: '#7a8290', R: '#c02838' },
        g: ['..RR..', '.KMMK.', 'KM..MK', 'KMmmMK', '.KKKK.'] },
      { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', M: '#a8b0bc', m: '#7a8290' },
        g: ['KM....MK', 'KMMMMMMK', 'KMmMMmMK', 'KMMMMMMK', '.KMmmMK.', '.KKKKKK.'] }
    ] },
    'Muta da Sub': { parti: [
      { target: 'testaTop', ax: 4, ay: -1, pal: { K: '#17171e', C: '#40c8e0', W: '#cfeef8' },
        g: ['KKKKKKKK', 'KCWWWWCK', '.KK..KK.'] },
      { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', B: '#2a3a4a', b: '#3e5468', Y: '#f0d040' },
        g: ['KB....BK', 'KBBBBBBK', 'KBYYYYBK', 'KBbBBbBK', '.KBBBBK.', '.KKKKKK.'] }
    ] },
    'Completo da Pirata': { parti: [
      { target: 'testaTop', ax: 4, ay: 3, pal: { K: '#17171e', B: '#3a2a1a', W: '#e8e0d0' },
        g: ['K.KKKK.K', 'KKBBBBKK', '.KBWWBK.', '.KKKKKK.'] },
      { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', R: '#a8302c', W: '#f0e8d8', Y: '#c8a040' },
        g: ['KR....RK', 'KRWWWWRK', 'KRWKKWRK', 'KYYYYYYK', '.KRRRRK.', '.KKKKKK.'] }
    ] },
    'Smoking': { parti: [
      { target: 'testaTop', ax: 3, ay: 4, pal: { K: '#17171e', B: '#1a1a22', g: '#3a3a48' },
        g: ['.KKKK.', 'KBBBBK', 'KBggBK', 'KKKKKK', '.KKKK.'] },
      { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', B: '#1a1a22', W: '#f4f4f8', R: '#a02030' },
        g: ['KB....BK', 'KBWWWWBK', 'KBWRRWBK', 'KBWWWWBK', '.KBBBBK.', '.KKKKKK.'] }
    ] },
    'Parrucchino di Elvis': { target: 'testaTop', ax: 5, ay: 5, pal: { K: '#17171e', k: '#2e2e3a', s: '#4a4a5c' },
      g: ['...KKK....', '..KkkKK...', '.KkskkKK..', 'KkkkkkkKK.', 'KkskkkkkK.', '.KKKKKKKK.'] },
    // Chef in DUE parti (richiesta fondatore 8 lug 2026: "grembiule bianco e forma giusta del
    // cappello"): toque vera (sbuffo largo sopra + fascia stretta) in testa + grembiule sul corpo.
    'Completo da Chef': { parti: [
      { target: 'testaTop', ax: 3, ay: 4, pal: { K: '#17171e', W: '#ffffff', w: '#d8d4c4' },
        g: ['.KKKK.', 'KWWWWK', 'KWWWWK', '.KwwK.', '.KWWK.'] },
      { target: 'corpo', ax: 3, ay: 2, pal: { K: '#17171e', W: '#ffffff', w: '#d8d4c4' },
        g: ['K.WW.K', 'KWWWWK', 'KWwwWK', 'KWWWWK', '.KKKK.'] }
    ] },
    'Toga da Avvocato': { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', k: '#2c2c3a', W: '#ffffff' },
      g: ['Kk....kK', 'KkKKKKkK', 'KkkWWkkK', '.KkkkkK.', '.KkkkkK.', '.KKKKKK.'] },
    'Camice del Dottore': { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', W: '#ffffff', C: '#20c8dc', w: '#d8d4c4' },
      g: ['KW....WK', 'KWKKKKWK', 'KWWCCWWK', 'KWwCCwWK', '.KWWWWK.', '.KKKKKK.'] },
    'Maschera da Wrestler': { target: 'testaTop', ax: 3, ay: 0, pal: { K: '#17171e', R: '#f03838', r: '#a32d2d', Y: '#f8d838' },
      g: ['KRRRRRK', 'KR.RR.K', 'KRYRRYK', 'KrRRRrK', '.KKKKK.'] },
    'Microfono da Cantante': { target: 'manoDx', ax: 1, ay: 4, pal: { K: '#17171e', M: '#aab4c0', W: '#f4f8fc', D: '#2b2b34' },
      g: ['.KK.', 'KWMK', 'KMMK', '.KDK', '.KD.'] },
    'Bouquet da Sposa': { target: 'manoDx', ax: 1, ay: 4, pal: { K: '#17171e', p: '#ff9ab0', R: '#f05868', Y: '#f8d838', g: '#2e6a3a', W: '#ffffff' },
      g: ['KpRpK', 'pWYWp', 'KRpRK', '.KgK.', '..g..'] },
    // ===== INDOSSABILI P3 — batch testa (target testaTop) =====
    'Cuffie da DJ': { target: 'testaTop', ax: 3, ay: 2, pal: { K: '#17171e', C: '#40e0f0', c: '#2098b0' },
      g: ['.KKKK.', 'KCCCCK', 'cK..Kc', 'cK..Kc'] },
    'Casco Spaziale': { target: 'testaTop', ax: 3, ay: 2, pal: { K: '#17171e', W: '#e8f0f8', B: '#20486a', b: '#3a78a8' },
      g: ['.KKKK.', 'KWWWWK', 'KbBBbK', 'KWWWWK'] },
    'Cappello da Detective': { target: 'testaTop', ax: 3, ay: 2, pal: { K: '#17171e', n: '#a0703a', N: '#6e4826' },
      g: ['.KKKK.', 'KnnnnK', 'NKnnKN', '.NNNN.'] },
    'Corona d\'Alloro': { target: 'testaTop', ax: 3, ay: 2, pal: { K: '#17171e', G: '#5cae52', g: '#2e6a3a' },
      g: ['.g..g.', 'GgKKgG', 'Gg..gG', '.G..G.'] },
    'Cappello da Chef': { target: 'testaTop', ax: 3, ay: 3, pal: { K: '#17171e', W: '#ffffff', w: '#d8d4c4' },
      g: ['.KKKK.', 'KWWWWK', 'KWWWWK', '.KwwK.', '.KWWK.'] },
    'Casco da Corriere Spaziale': { target: 'testaTop', ax: 3, ay: 3, pal: { K: '#17171e', W: '#e8f0f8', O: '#f0a030', b: '#3a78a8' },
      g: ['..O...', '.KKKK.', 'KWWWWK', 'KbbWWK', 'KWWWWK'] },
    // ===== INDOSSABILI P3 — batch corpo (target corpo) =====
    'Fischietto dell\'Istruttore': { target: 'corpo', ax: 3, ay: 2, pal: { K: '#17171e', r: '#c02828', Y: '#f0c040' },
      g: ['r....r', '.r..r.', '..rr..', '.KYYK.', '.KKKK.'] },
    'Costume da Protagonista': { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', B: '#3060c0', b: '#204090', Y: '#f8d838' },
      g: ['KB....BK', 'KBBBBBBK', 'KBBYBBBK', 'KBbBBbBK', '.KBBBBK.', '.KKKKKK.'] },
    'Costume dell\'Allenatore': { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', G: '#2e8a4a', W: '#e8e8e8' },
      g: ['KG....GK', 'KGWGGWGK', 'KGWGGWGK', 'KGGGGGGK', '.KGGGGK.', '.KKKKKK.'] },
    'Cintura Mondiale': { target: 'corpo', ax: 4, ay: 1, pal: { K: '#17171e', Y: '#f8d838', y: '#c89830', W: '#fff0a0' },
      g: ['KKKKKKKK', 'yYYYYYYy', 'yYWWWWYy', 'yYWKKWYy', 'yYYYYYYy', 'KKKKKKKK'] },
    'Accappatoio del Campione': { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', R: '#c02838', W: '#f0e8d0' },
      g: ['KRWWWWRK', 'KRRRRRRK', 'KRRWWRRK', 'KRRWWRRK', '.KRRRRK.', '.KKKKKK.'] },
    'Medaglione del Concilio': { target: 'corpo', ax: 3, ay: 1, pal: { K: '#17171e', Y: '#f0c040', C: '#40c0e0', y: '#a07820' },
      g: ['y....y', '.y..y.', '.KYYK.', '.YCYK.', '.KYYK.'] },
    'Fascia da Sindaco': { target: 'corpo', ax: 3, ay: 1, pal: { K: '#17171e', R: '#c02838', Y: '#f0c040' },
      g: ['.....RK', '...KRRK', '..KRRK.', '.KRRK..', 'KRRK...', 'KYK....'] },
    'Cintura del Peperoncino': { target: 'corpo', ax: 4, ay: 1, pal: { K: '#17171e', Y: '#c8a030', R: '#e03020', g: '#3a8a3a' },
      g: ['KKKKKKKK', 'KYYgYYYK', 'KYKRRKYK', 'KYRRRRYK', 'KYYYYYYK', 'KKKKKKKK'] },
    // ===== INDOSSABILI P3 — batch mano + speciali =====
    'Guantoni Consumati': { target: 'manoDx', ax: 1, ay: 2, pal: { K: '#17171e', R: '#c02838', r: '#8a1c28', W: '#d8c8b0' },
      g: ['KRRK', 'RRRR', 'RRrR', 'KrrK', '.WW.'] },
    'Chitarra Fiammante': { target: 'manoDx', ax: 1, ay: 4, pal: { K: '#17171e', o: '#e05020', B: '#8a4a2a', h: '#3a2c1a' },
      g: ['.hK.', '.hK.', 'oBBo', 'oBBo', '.oo.'] },
    // ay:-2 con due righe VUOTE in testa spingeva le scarpe sotto il riquadro 16x16:
    // sprite definito ma ZERO pixel a schermo. Trovato il 29 lug 2026 col test che confronta
    // i pixel del pet vestito contro quelli del pet nudo, non con la sola presenza in tabella.
    'Scarpe d\'Oro': { target: 'corpo', ax: 4, ay: -1, pal: { K: '#17171e', Y: '#f8d838', y: '#c89830' },
      g: ['.KK..KK.', '.YY..YY.', '.yy..yy.'] },
    'Tavola Leggendaria': { target: 'manoDx', ax: 1, ay: 6, pal: { K: '#17171e', C: '#40c0e0', Y: '#f0c040', W: '#e8f0f8' },
      g: ['.K.', 'KCK', 'KWK', 'KYK', 'KCK', 'KWK', '.K.'] },
    // ===== INDOSSABILI MEME (revamp negozio v171) — disegnati a mano 29 lug 2026 =====
    // Convenzioni v2 come sopra: contorno K, forma grande, un accento vivo per riconoscerli a
    // colpo d'occhio nella stanza. ay NEGATIVO = si disegna SOTTO l'ancora (v. Scarpe d'Oro):
    // serve per occhiali e visore, che vanno sul viso e non sopra la testa.
    'Occhialoni Fattene Una Ragione': { target: 'testaTop', ax: 4, ay: -1, pal: { K: '#17171e', D: '#2e2e3a', W: '#ffffff' },
      g: ['KKKKKKKK', 'KDWKKDDK', '.KK..KK.'] },
    'Cappellino di Stagnola': { target: 'testaTop', ax: 3, ay: 4, pal: { K: '#17171e', S: '#d8dce4', s: '#9aa4b0' },
      g: ['..KK..', '.KSSK.', 'KSsSSK', 'KSSsSK', 'KKKKKK'] },
    'Sandaloni col Calzino': { target: 'corpo', ax: 4, ay: -1, pal: { K: '#17171e', W: '#f0ece0', b: '#a0703a' },
      g: ['.WW..WW.', '.KK..KK.', '.bb..bb.'] },
    'Acetatona Lucida': { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', P: '#7a3ec8', p: '#a86ee8', W: '#ffffff' },
      g: ['KP....PK', 'KPWppWPK', 'KPWPPWPK', 'KPPPPPPK', '.KPPPPK.', '.KKKKKK.'] },
    'Piuminone del Paninaro': { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', G: '#f08030', g: '#c05818' },
      g: ['KG....GK', 'KGGGGGGK', 'KggggggK', 'KGGGGGGK', '.KggggK.', '.KKKKKK.'] },
    'Cappelluccio Rosso dell\'Idraulico': { target: 'testaTop', ax: 3, ay: 4, pal: { K: '#17171e', R: '#d02828', W: '#ffffff' },
      g: ['.KKKK..', 'KRRRRK.', 'KRWWRK.', 'KRRRRKK', '.KKKKKK'] },
    'Collarone della Vergogna': { target: 'corpo', ax: 4, ay: 4, pal: { K: '#17171e', W: '#e8f0f8', w: '#b8c8d8' },
      g: ['KWWWWWWWWK', 'KwWWWWWWwK', '.KWWWWWWK.', '..KwwwwK..', '...KKKK...'] },
    'Visorone della Realt\u00e0 Finta': { target: 'testaTop', ax: 4, ay: -1, pal: { K: '#17171e', B: '#2b2b34', C: '#40e0f0', k: '#5a6478' },
      g: ['kKKKKKKk', 'KBBBBBBK', 'KBCCCCBK', 'KKKKKKKK'] },
    'Elmo del Centurione da Selfie': { target: 'testaTop', ax: 3, ay: 4, pal: { K: '#17171e', R: '#d02828', Y: '#e8c040', y: '#a88820' },
      g: ['..RRR..', '.KRRRK.', 'KYYYYYK', 'KYyyyYK', 'KK...KK'] },
    'Pettorina Catarifrangente': { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', Y: '#d8f038', S: '#c8d0d8' },
      g: ['KY....YK', 'KYYYYYYK', 'KSSSSSSK', 'KYYYYYYK', '.KSSSSK.', '.KKKKKK.'] },
    'Maglione della Nonna Renna': { target: 'corpo', ax: 4, ay: 2, pal: { K: '#17171e', R: '#b02830', W: '#f0ece0' },
      g: ['KR....RK', 'KRRRRRRK', 'KRWRRWRK', 'KRRWWRRK', '.KRWWRK.', '.KKKKKK.'] },
    'Cappellone di Paglietta': { target: 'testaTop', ax: 4, ay: 4, pal: { K: '#17171e', S: '#e8c878', b: '#3a3a48' },
      g: ['..KKKK..', '.KSSSSK.', '.KbbbbK.', 'KSSSSSSK', 'KKKKKKKK'] },
    'Berrettone a Punta dell\'Eroe Muto': { target: 'testaTop', ax: 3, ay: 5, pal: { K: '#17171e', G: '#1e6a32', g: '#4aba5a' },
      g: ['.....KK', '....KgK', '..KKGgK', '.KGGGgK', 'KGGGGgK', '.KKKKK.'] }
  };
  var ARMA_SPR = {
    'Spadone': { target: 'manoDx', ax: 1, ay: 6, pal: { K: '#17171e', W: '#eef4fa', B: '#9aa6b2', g: '#f0c832', h: '#6a4a2a' },
      g: ['.WK.', '.WK.', '.WK.', '.WK.', '.BK.', 'gggg', '.Kh.', '.Kh.'] },
    'Alabarda': { target: 'manoDx', ax: 1, ay: 6, pal: { K: '#17171e', W: '#eef4fa', B: '#9aa6b2', s: '#8a6a3a' },
      g: ['WWK.', 'WBWK', 'KWK.', '.sK.', '.sK.', '.sK.', '.sK.', '.sK.'] },
    'Martellone': { target: 'manoDx', ax: 1, ay: 6, pal: { K: '#17171e', B: '#9aa6b2', b: '#cdd6e0', s: '#8a6a3a' },
      g: ['KKKKK', 'KbBBK', 'KBBbK', 'KKKKK', '.KsK.', '.KsK.', '.KsK.', '..s..'] },
    'Doppie Lame': { target: 'manoDx', ax: 1, ay: 5, pal: { K: '#17171e', W: '#eef4fa', B: '#9aa6b2', g: '#f0c832', h: '#6a4a2a' },
      g: ['WK.WK', 'WK.WK', 'WK.WK', 'BK.BK', 'ggggg', '.h.h.', '.h.h.'] },
    'Arco Pesante': { target: 'manoDx', ax: 1, ay: 6, pal: { K: '#17171e', b: '#a0703a', B: '#6e4826', W: '#f4f0e0' },
      g: ['.bbK', 'bWKb', 'bW.K', 'bW.K', 'bW.K', 'bWKb', '.bbK', '.KB.'] },
    'Bastone da combattimento': { target: 'manoDx', ax: 0, ay: 6, pal: { K: '#17171e', s: '#a0703a', S: '#c89858' },
      g: ['SK', 'sK', 'sK', 'sK', 'sK', 'sK', 'sK', 'SK'] },
    'Sai gemelli': { target: 'manoDx', ax: 1, ay: 5, pal: { K: '#17171e', W: '#eef4fa', B: '#9aa6b2', h: '#6a4a2a' },
      g: ['WKW', 'WWW', 'KWK', '.BK', '.hK', '.h.'] },
    'Nunchaku arrugginiti': { target: 'manoDx', ax: 0, ay: 5, pal: { K: '#17171e', s: '#a0703a', k: '#8a96a4' },
      g: ['sK..', 'sK..', 'kK..', '.Kk.', '..sK', '..sK'] },
    'Katane a farfalla': { target: 'manoDx', ax: 1, ay: 4, pal: { K: '#17171e', W: '#eef4fa', B: '#9aa6b2', g: '#f0c832', h: '#6a4a2a' },
      g: ['WKW', 'WWW', 'KgK', 'KhK', '.h.'] },
    'Pistola Spara-Spazzatura': { target: 'manoDx', ax: 1, ay: 2, pal: { K: '#17171e', B: '#6a7684', b: '#20c8dc', G: '#48d858', h: '#2b2b34' },
      g: ['KKKKK', 'GKbbK', 'KBBBK', '.KhK.', '..h..'] }
  };
  // Modifiche PERMANENTI da M17 "Pimp My Pet" (scelta all'evoluzione teen): +stat + sprite per
  // sempre sul pet. 4 stat x 2 razze = 8 (robot: impianti / alieno: mutazioni). petLike.modSprite.
  // MOD_SPR v2 (fix playtest 8 lug 2026, "mancano gli sprite della modifica" = troppo piccoli
  // per leggersi a scala stanza): contorno scuro + forme piu' grandi e accese, ancore invariate.
  var MOD_SPR = {
    servobraccia: { target: 'manoDx', ax: 1, ay: 3, pal: { K: '#17171e', M: '#8a96a4', m: '#3a4258', w: '#e8f0f8' },
      g: ['w.w', 'KMK', 'MmM', 'KMK'] },
    turbina: { target: 'testaTop', ax: 1, ay: 4, pal: { K: '#17171e', C: '#5ce8f8', c: '#2098b0', m: '#3a4258' },
      g: ['.KK.', 'KCcK', 'KcCK', '.KK.', '.mm.'] },
    antenna: { target: 'testaTop', ax: 1, ay: 4, pal: { C: '#5cf0ff', c: '#2098b0', M: '#5a6478' },
      g: ['.CC', '.Cc', '..M', '..M', '..M'] },
    neon: { target: 'testaTop', ax: 3, ay: 3, pal: { K: '#17171e', p: '#ff6ab0', C: '#40e0f0', W: '#ffffff' },
      g: ['KKKKKK', 'KpCpWK', 'KKKKKK', '..KK..'] },
    chele: { target: 'manoDx', ax: 1, ay: 3, pal: { K: '#17171e', g: '#68f088', G: '#2e6a3a' },
      g: ['g.g', 'gKg', 'GgG', '.GK', '.G.'] },
    pinne: { target: 'manoDx', ax: 0, ay: 2, pal: { K: '#17171e', C: '#50e0f0', c: '#2098b0' },
      g: ['.CK', 'CCK', 'CcK', 'CCK', '.CK'] },
    terzocchio: { target: 'testaTop', ax: 2, ay: 1, pal: { K: '#17171e', P: '#d088e8', W: '#ffffff' },
      g: ['KPPPK', 'PWKWP', 'KPPPK'] },
    biolum: { target: 'corpo', ax: 1, ay: 1, pal: { C: '#40f8e8', G: '#68f878', p: '#c8f8ff' },
      g: ['C..G', 'G.p.', '.C.G', 'p..C'] }
  };
  function drawEquipSprite(ctx, spr, anc, scale, ox, oy) {
    // supporto multi-parte (es. Completo da Chef = toque in testa + grembiule sul corpo):
    // ogni parte ha il suo target/ancora, disegnate in ordine.
    if (spr.parti) {
      for (var ip = 0; ip < spr.parti.length; ip++) drawEquipSprite(ctx, spr.parti[ip], anc, scale, ox, oy);
      return;
    }
    var t = anc[spr.target] || anc.corpo;
    var originX = t[0] - spr.ax, originY = t[1] - spr.ay;
    paintFrame(ctx, spr.g, spr.pal, scale, ox + originX * scale, oy + originY * scale);
  }
  // disegna modifica permanente (petLike.modSprite, sotto), vestito (indossato) e arma (armaEquip)
  function drawOverlayEquip(ctx, petLike, scale, ox, oy) {
    if (!petLike) return;
    var key = (petLike.razza === 'robot') ? 'robot' : (petLike.razza === 'leggenda') ? 'leggenda' : (petLike.sottorazza || 'blob');
    // "adulto" usa le ancore ANCHORS.*_adulto (P3: placeholder = teen, v. mappa ANCHORS sopra).
    var stadio = (petLike.stadio === 'teen' || petLike.stadio === 'adulto') ? petLike.stadio : 'baby';
    var anc = ANCHORS[key + '_' + stadio] || ANCHORS.blob_baby;
    // Ancore ed equip vivono in griglia 16-logica come gli overlay volto: converto la scala del
    // corpo (canvas/SIZE) alla scala 16 (canvas/16) cosi' ANCHORS e le griglie equip restano
    // valide qualunque sia SIZE. Con SIZE=16 s16===scale (invariato); con SIZE=32 s16=scale*2.
    var s16 = scale * SIZE / 16;
    var m = petLike.modSprite && MOD_SPR[petLike.modSprite]; // impianto/mutazione = parte del pet, sotto tutto
    if (m) drawEquipSprite(ctx, m, anc, s16, ox, oy);
    var v = petLike.indossato && VESTITO_SPR[petLike.indossato];
    if (v) drawEquipSprite(ctx, v, anc, s16, ox, oy);
    var a = petLike.armaEquip && ARMA_SPR[petLike.armaEquip];
    if (a) drawEquipSprite(ctx, a, anc, s16, ox, oy);
  }

  // petLike: {razza:'robot'|'alieno', sottorazza:'blob'|'insettoide'|'rettiliano', parts:{antenna,testa,colore}, stadio, corpo, sporco, indossato, armaEquip}
  function draw(canvas, petLike, opts) {
    if (!canvas || !petLike) return;
    opts = opts || {};
    var ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    var res = resolvePet(petLike);
    var scale = canvas.width / SIZE;
    paintFrame(ctx, res.frame, res.palette, scale, 0, 0);

    if (petLike.sporco) {
      drawDirtOverlay(ctx, res.frame, scale, 0, 0);
      drawFlies(ctx, res.frame, scale, opts.frame === 1 ? 1 : 0, 0, 0);
    }
    // equipaggiamento + modifica permanente M17 SOPRA il pet. Guard: solo se c'e' qualcosa.
    if (petLike.indossato || petLike.armaEquip || petLike.modSprite) drawOverlayEquip(ctx, petLike, scale, 0, 0);
  }

  // Resa "sdraiato" (dorme, GDD "Energia e sonno" -> "posa ben leggibile da dormiente,
  // sdraiato, testa verso il cuscino"): ruota lo sprite esistente di 90 gradi cosi' il pet
  // appare disteso in orizzontale invece che in piedi, senza bisogno di ridisegnare ogni
  // creatura in una posa dedicata. Il canvas resta quadrato (stesso PET_PX x PET_PX usato per
  // lo sprite in piedi, v. ui.js PET_PX) cosi' il chiamante non deve toccare hit-test/
  // posizionamento: la rotazione avviene internamente attorno al centro.
  // "lato": 1 = testa a sinistra / verso il cuscino (default, per il letto), -1 = testa a
  // destra (specchiato, variante per il crollo sul pavimento).
  //
  // Nota di design: gli sprite di questo gioco sono tutti tozzi/compatti (16x16, "umanoidi
  // rotondi") - una rotazione pura di 90 gradi da sola non basta a leggersi come "disteso",
  // perche' silhouette gia' quasi quadrate restano quasi quadrate anche ruotate (verificato:
  // baby e teen ruotati restano un blocco compatto senza un lato chiaramente "testa"). Per
  // questo aggiungiamo due indizi extra, disegnati insieme alla rotazione invece di ridisegnare
  // ogni creatura: un CUSCINO (rettangolo chiaro dietro la testa, dal lato "lato") e una
  // COPERTA (fascia semi-trasparente sulla meta' del corpo lontana dalla testa) - questi due
  // elementi ancorano visivamente "dove sta la testa" e "il pet e' sotto qualcosa", cosa che la
  // sola rotazione non comunicava.
  var CUSCINO_COLOR = "#eef1f6";
  var COPERTA_COLOR = "rgba(80, 110, 150, 0.55)";
  function drawSdraiato(canvas, petLike, opts) {
    if (!canvas || !petLike) return;
    opts = opts || {};
    var ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    var res = resolvePet(petLike);
    var scale = canvas.width / SIZE;
    var cx = canvas.width / 2, cy = canvas.height / 2;
    var lato = opts.lato === -1 ? -1 : 1;
    var w = canvas.width, h = canvas.height;

    // Cuscino: rettangolo chiaro nel terzo di canvas dal lato della testa, DIETRO il corpo.
    // Un po' piu' alto del corpo (sporge sopra/sotto) cosi' si legge come oggetto a se',
    // non come parte dello sprite.
    var cuscinoW = w * 0.3;
    var cuscinoX = lato === 1 ? 0 : w - cuscinoW;
    ctx.fillStyle = CUSCINO_COLOR;
    ctx.fillRect(cuscinoX, h * 0.12, cuscinoW, h * 0.76);

    ctx.save();
    // ruota di un quarto di giro attorno al centro: "in piedi" (verticale) -> "disteso"
    // (orizzontale). Verso scelto cosi' la testa (riga 0 del frame) finisce dal lato "lato",
    // sovrapposta al cuscino appena disegnato.
    ctx.translate(cx, cy);
    ctx.rotate(lato === 1 ? -Math.PI / 2 : Math.PI / 2);
    ctx.translate(-cx, -cy);
    paintFrame(ctx, res.frame, res.palette, scale, 0, 0);
    if (petLike.sporco) {
      drawDirtOverlay(ctx, res.frame, scale, 0, 0);
      drawFlies(ctx, res.frame, scale, opts.frame === 1 ? 1 : 0, 0, 0);
    }
    // Equip + modifica permanente M17 anche da sdraiato (fix audit: la mod "per sempre"
    // spariva mentre il pet dormiva). Dentro il transform: ruota col corpo, ancore coerenti.
    if (petLike.indossato || petLike.armaEquip || petLike.modSprite) drawOverlayEquip(ctx, petLike, scale, 0, 0);
    ctx.restore();

    // Coperta: fascia semi-trasparente sulla meta' del corpo LONTANA dalla testa (dove
    // starebbero gambe/piedi), NON ruotata (resta un rettangolo pulito allineato al canvas).
    // Rinforza la lettura "disteso sotto una coperta" senza dover disegnare gambe/piedi
    // per ogni creatura.
    var copertaW = w * 0.62;
    var copertaX = lato === 1 ? (w - copertaW) : 0;
    ctx.fillStyle = COPERTA_COLOR;
    ctx.fillRect(copertaX, h * 0.2, copertaW, h * 0.68);

    // occhi chiusi: NON riusiamo drawPalpebre "di fronte" (due fasce ai lati sinistro/destro
    // pensate per il volto frontale in piedi) perche' ruotata di 90 gradi diventerebbe
    // un'unica fascia scura che taglia tutta la larghezza del canvas, sopra il cuscino incluso
    // (bug visto in verifica manuale). Da sdraiato disegniamo invece un trattino unico,
    // piccolo, posizionato sopra la testa (accanto al cuscino, lato "lato").
    var palpX = lato === 1 ? w * 0.32 : w * 0.5;
    ctx.fillStyle = "rgba(20,20,24,0.75)";
    ctx.fillRect(palpX, h * 0.28, w * 0.18, h * 0.06);
    // Zzz: SOLO se il chiamante non li ridisegna gia' altrove (opts.zzz === false). Bug noto
    // (fix 5 lug 2026): sul mini-canvas quadrato del pet (16x16 logici) le "Z" piu' grandi
    // escono dal bordo superiore/destro (drawZzz usa y negativi e x+size>16, v. sotto) — il
    // chiamante con una scena piu' ampia (canvas stanza) puo' passare zzz:false e richiamare
    // PETQ.sprites.drawZzz direttamente sul canvas stanza, dove il margine extra le contiene
    // per intero (v. ui.js disegnaZzzStanza).
    if (opts.zzz !== false) drawZzz(ctx, opts.frame);
  }

  // ===== Icone cibo 12x12 (outline scuro + fill, "." trasparente) =====
  var ICON_SIZE = 12;

  var FOOD_ICONS = {
    crocchettesemplici: {
      px: ["............","............","....k..k....","..k..k..k...",".##########.",".#rrrrrrrr#.",".#rrrrrrrr#.","..#rrrrrr#..","...######...","....####....","............","............"],
      pal: { "#": "#33201a", k: "#a8743c", r: "#d85a4a" }
    },
    bistecca: {
      px: ["............","............","..#######...",".#fffffff#..",".#mmoommm#..",".#mmoommm#..",".#mmmmmmm#..","..#######...","............","............","............","............"],
      pal: { "#": "#3a1616", m: "#c04a3c", f: "#f0d0b8", o: "#f4ecd8" }
    },
    spiedino: {
      px: ["............",".....s......","...#####....","...#mmm#....","...#####....","...#ppp#....","...#####....","...#mmm#....","...#####....",".....s......",".....s......","............"],
      pal: { "#": "#33201a", m: "#c04a3c", p: "#5cb84a", s: "#a8743c" }
    },
    insalatona: {
      px: ["............","............","...vlvlv....","..vlvlvlv...",".##########.",".#wwwwwwww#.","..#wwwwww#..","...######...","....####....","............","............","............"],
      pal: { "#": "#2b3020", v: "#3f8c34", l: "#7fd45c", w: "#f0ead8" }
    },
    zuppadiverdure: {
      px: ["............","...q..q.....","....q..q....","...q..q.....",".##########.",".#oooooooo#.",".#bbbbbbbb#.","..#bbbbbb#..","...######...","....####....","............","............"],
      pal: { "#": "#2b2430", q: "#c8d8e0", o: "#e8963c", b: "#4a7ba6" }
    },
    sushi: {
      px: ["............","............","............","..########..",".#ssskksss#.",".#ssskksss#.",".#rrrkkrrr#.",".#rrrrrrrr#.","..########..","............","............","............"],
      pal: { "#": "#33202a", s: "#f08a5c", r: "#f8f4ec", k: "#22331e" }
    },
    pesceallagriglia: {
      px: ["............","............","............","...#####....","..#fgfgf#.t.",".#efgfgff#tt","..#fgfgf#.t.","...#####....","............","............","............","............"],
      pal: { "#": "#1a2a34", f: "#5aa8d8", g: "#2c485c", e: "#10141a", t: "#3f7ea6" }
    },
    biscotto: {
      px: ["............","............","...######...","..#bbbbbb#..",".#bcbbbbcb#.",".#bbbcbbbb#.",".#bbbbbcbb#.","..#bbbbbb#..","...######...","............","............","............"],
      pal: { "#": "#3a2814", b: "#d8a05c", c: "#4a2c14" }
    },
    tortaintera: {
      px: ["............",".....xx.....","..########..",".#iiiiiiii#.",".#ipiipiip#.",".#pppppppp#.",".#pppppppp#.",".#pppppppp#.","..########..","............","............","............"],
      pal: { "#": "#3a1a28", i: "#f8f0f4", p: "#f0a0c0", x: "#d83048" }
    },
    // ===== Revamp icone cibo (4 ago 2026, regista, disegnate a mano): 43 icone nuove, una per
    // OGNI cibo del catalogo post-revamp-meme — prima solo i 9 classici avevano un disegno e
    // tutti i meme (Disonore compreso) cadevano sul fallback di categoria, cioe' sembravano
    // placeholder. Il fallback resta SOLO per cibi futuri non ancora disegnati. =====
    "fettaditorta": {
      px: ["............","....x.......","...##.......","...#i#......","...#pi#.....","...#ipi#....","...#pipi#...","...#ipipi#..","...#ppppp#..","....######..","............","............"],
      pal: { "#": "#3a1a28", i: "#f8f0f4", p: "#f0a0c0", x: "#d83048" }
    },
    "barrettaproteica": {
      px: ["............","............","............",".##########.",".#bbwwwwww#.",".#bbwrrrww#.",".#bbwwwwww#.",".##########.","............","............","............","............"],
      pal: { "#": "#3a1616", b: "#a05a2c", w: "#d84a3c", r: "#f4ecd8" }
    },
    "ghiacciolo": {
      px: ["............","....####....","...#aabb#...","...#aabb#...","...#aabb#...","...#aabb#...","...#aabb#...","....####....",".....ss.....",".....ss.....","............","............"],
      pal: { "#": "#2a3440", a: "#6ad8e8", b: "#f06a8a", s: "#c89858" }
    },
    "acquafrizzantissima": {
      px: ["......q..q..",".....##.....",".....##...q.","....####....","...#wwww#...","...#wqww#...","...#wwww#...","...#wwqw#...","...#wwww#...","....####....","............","............"],
      pal: { "#": "#1e3a40", w: "#9adfe0", q: "#ffffff" }
    },
    "snackriciclato": {
      px: ["............","............","............",".z.######.z.",".zz#gggg#zz.",".zz#lggl#zz.",".zz#gglg#zz.",".z.######.z.","............","............","............","............"],
      pal: { "#": "#22331e", g: "#4aa84a", l: "#8ad86a", z: "#2e6e2e" }
    },
    "arrosto": {
      px: ["............","............","............","...######...","..#msmmsm#..",".#mmsmmsmm#.",".#mmsmmsmm#.","..#msmmsm#..","...######...","............","............","............"],
      pal: { "#": "#3a1616", m: "#b05a2c", s: "#e8c88a" }
    },
    "scortadipanini": {
      px: ["............","............","..########..",".#wwwwwwww#.",".#hlhlhlhl#.",".#wwwwwwww#.",".#hlhlhlhl#.",".#wwwwwwww#.","..########..","............","............","............"],
      pal: { "#": "#3a2814", w: "#e8c88a", h: "#e07050", l: "#7fd45c" }
    },
    "fettadipaninogigante": {
      px: ["............","..#.........","..##........","..#w#.......","..#wh#......","..#whl#.....","..#whlw#....","..#whlwh#...","..#wwwwww#..","..########..","............","............"],
      pal: { "#": "#3a2814", w: "#e8c88a", h: "#e07050", l: "#7fd45c" }
    },
    "pizza": {
      px: ["............","............","...#cccc#...","..#cyyyyc#..",".#cyryyryc#.",".#cyyryyyc#.",".#cyyyryyc#.","..#cyyyyc#..","...#cccc#...","............","............","............"],
      pal: { "#": "#4a2410", c: "#c8863c", y: "#f0c848", r: "#d84a3c" }
    },
    "tortanuziale": {
      px: ["............",".....xx.....","....#ii#....","....#ii#....","...##ii##...","..#iiiiii#..","..#iiiiii#..",".##iiiiii##.",".#iiiiiiii#.",".##########.","............","............"],
      pal: { "#": "#3a1a28", i: "#f8f0f4", x: "#d83048" }
    },
    "salsainfernale": {
      px: [".....kk.....",".....kk.....","....####....","...#rrrr#...","...#rffr#...","...#ffff#...","...#rffr#...","...#rrrr#...","....####....","............","............","............"],
      pal: { "#": "#3a1010", r: "#c83224", f: "#f0a03c", k: "#33333d" }
    },
    "scatoladicioccolatini": {
      px: ["............","............","..########..",".#rrrrrrrr#.",".#dcdcdcdc#.",".#cdcdcdcd#.",".#dcdcdcdc#.","..########..","............","............","............","............"],
      pal: { "#": "#2e1a0e", r: "#d83048", c: "#8a5428", d: "#4a2c14" }
    },
    "zuppadellanonna": {
      px: ["....q..x....","...q..q.....","....q..q....",".##########.",".#oooooooo#.",".#nnnnnnnn#.","..#nnnnnn#..","...######...","....####....","............","............","............"],
      pal: { "#": "#3a241a", q: "#e8e0d0", x: "#f06a8a", o: "#e8963c", n: "#c86a3c" }
    },
    "latte": {
      px: ["............","....####....","...#....#...","..########..","..#wwwwww#..","..#wbbbbw#..","..#wbbbbw#..","..#wwwwww#..","..#wwwwww#..","..########..","............","............"],
      pal: { "#": "#2a3440", w: "#f4f4f0", b: "#4a7ba6" }
    },
    "cosciottonemanganime": {
      px: ["............","............","............","...######...","..#mmmmmm#..","oo#mfmmmm#oo","oo#mmmmmm#oo","..#mmmmmm#..","...######...","............","............","............"],
      pal: { "#": "#3a1616", m: "#b8502e", f: "#e8a880", o: "#f4ecd8" }
    },
    "bisteccasalabracciod'oro": {
      px: ["..s...s.....","....s.......","..#######...",".#ggggggg#..",".#gGGggGg#..",".#ggggggg#..",".#gGggGgg#..","..#######...","............","............","............","............"],
      pal: { "#": "#5a3a10", g: "#f0c23c", G: "#c89020", s: "#ffffff" }
    },
    "nudoliniincendiari2x": {
      px: ["....y..y....","...ff.fff...","..#nnnnnn#..",".##########.",".#rrrrrrrr#.",".#rwwwwrrr#.",".#rrrrrrrr#.","..#rrrrrr#..","...######...","............","............","............"],
      pal: { "#": "#3a1010", y: "#f0c23c", f: "#f08a2c", n: "#f0d890", r: "#c8342c", w: "#f4ecd8" }
    },
    "kebabbonedelletre": {
      px: ["............","..#######...",".#hlhrhlh#..",".#wwwwwww#..","..#wwwww#s..","..#wwwww#...","...#wwww#...","...#www#....","....#ww#....","....###.....","............","............"],
      pal: { "#": "#3a2814", w: "#e8c88a", h: "#a05a2c", l: "#7fd45c", r: "#d84a3c", s: "#f4ecd8" }
    },
    "fungoneingrandotto": {
      px: ["............","...######...","..#rrwwrr#..",".#rrrrrrrr#.",".#wrrwwrrw#.",".##########.","..#eeeeee#..","..#eoeeoe#..","...######...","............","............","............"],
      pal: { "#": "#3a1616", r: "#d83c2c", w: "#f4f0e0", e: "#f0e0c0", o: "#33201a" }
    },
    "pannocchiaammazzafame": {
      px: ["............","....####....","...#yYyy#...","...#yyYy#...","...#Yyyy#...","...#yyYy#...","...#yYyy#...","..g.#yy#.g..","..gg####gg..","...gg..gg...","............","............"],
      pal: { "#": "#4a3a10", y: "#f0d84a", Y: "#c8a020", g: "#4aa84a" }
    },
    "ciambrisogelatinoso": {
      px: ["............",".....##.....","....#rr#....","...#rrrr#...","..#rrrrrr#..",".#rrrrrrrr#.",".#rrnnnnrr#.",".#rrnnnnrr#.","..########..","............","............","............"],
      pal: { "#": "#33202a", r: "#f8f4ec", n: "#22331e" }
    },
    "cappuccinosicarino": {
      px: ["............","............","..#zzzzzz#..",".#zzzzzzzz#.",".#wowwwwow#.",".#wwwwwwww#u","..#wwwwww#u.","...######...","..########..","............","............","............"],
      pal: { "#": "#2a2a34", z: "#c83224", w: "#f4f4f0", o: "#1a1a20", u: "#d8d4cc" }
    },
    "cioccolattonedellosceicco": {
      px: ["............","............","..########..",".#cc#cc#cc#.",".#cc#cc#cc#.",".#gggggggg#.",".#cc#cc#cc#.",".#cc#cc#cc#.","..########..","............","............","............"],
      pal: { "#": "#2e160a", c: "#6a3a1c", g: "#7fd45c" }
    },
    "sbafella": {
      px: [".......s....",".......s....","..########..",".#nnnnnnnn#.",".#bbbbbbbb#.",".#bwwwwwwb#.",".#bwwwwwwb#.",".#bbbbbbbb#.","..########..","............","............","............"],
      pal: { "#": "#2e160a", s: "#c8ccd4", n: "#9a6030", b: "#5c3a1e", w: "#f4ecd8" }
    },
    "gelatopuffoso": {
      px: ["............","...######...","..#pppppp#..","..#pqpppp#..","..#pppppp#..","...######...","...#wcww#...","....#cw#....","....#wc#....",".....##.....","............","............"],
      pal: { "#": "#28324a", p: "#5ab4e8", q: "#a8e0f8", w: "#e8c88a", c: "#b08040" }
    },
    "erpaccodasotto": {
      px: ["............","............","..########..",".#bbbttbss#.",".#bbbttbss#.",".#bbbttbbb#.",".#bbbttbbb#.",".#bbbttbbb#.","..########..","............","............","............"],
      pal: { "#": "#4a3014", b: "#c89858", t: "#e8dcb8", s: "#d84a3c" }
    },
    "carburantedagiocatore": {
      px: ["............",".zzz........","#ooo#..#ss#.","#ooo#..#gg#.","#ofo#..#gg#.","#oof#..#gg#.","#ooo#..#gg#.","#####..####.","............","............","............","............"],
      pal: { "#": "#3a2010", z: "#c87820", o: "#e8862c", f: "#f0d84a", s: "#c8ccd4", g: "#4aa84a" }
    },
    "limonesignoraaa!": {
      px: ["............","......g.....",".....g...w..","...####.w...","..#yyyy#..w.",".#yqyyyy#w..",".#yyyyyy#.w.","..#yyyy#w...","...####..w..","............","............","............"],
      pal: { "#": "#4a3a10", y: "#f0d84a", q: "#f8f0b0", g: "#4aa84a", w: "#f0f0e0" }
    },
    "carboneraallapanna": {
      px: ["............","............","....wwww....","...wwwwww...","..pwwwwwwp..",".#pppppppp#.",".##########.","..#tttttt#..","...######...","............","............","............"],
      pal: { "#": "#3a2c14", w: "#f8f8f4", p: "#f0d84a", t: "#d8dce4" }
    },
    "fettuccinealfredone": {
      px: ["............","............","..#nwnwnw#..",".#wnwnwnwn#.",".#nwnwnwnw#.",".##########.","..#tttttt#..","...######...","....####....","............","............","............"],
      pal: { "#": "#33240e", n: "#f0e0a0", w: "#f8f4ec", t: "#4a7ba6" }
    },
    "pizzaananassa": {
      px: ["............","...#........","...##.......","...#y#......","...#hy#.....","...#yay#....","...#ayha#...","...#yayay#..","...#ccccc#..","....######..","............","............"],
      pal: { "#": "#4a2410", y: "#f0b03c", a: "#f8ec90", h: "#e88a9c", c: "#c8863c" }
    },
    "arancinodelladiscordia": {
      px: ["............",".....#......","....##......","...#aaa#....","..#aAaaa#...",".#aaaAaaa#..",".#aAaaaAa#..",".#aaaaaaa#..","..#aaaaa#...","...#####....","............","............"],
      pal: { "#": "#4a2410", a: "#e8963c", A: "#c07020" }
    },
    "spaghettotronco": {
      px: ["..#psp#.....","..#psp#.....","..#psp#.....","..#psp#.....",".!#psp#!....","....!#psp#!.",".....#psp#..",".....#psp#..",".....#psp#..",".....#psp#..","............","............"],
      pal: { "#": "#4a3a14", p: "#f0d890", s: "#d0b05c", "!": "#f0f0e0" }
    },
    "cappucciodemezzanotte": {
      px: ["............",".z.......z..","...######...","..#wwwwww#..",".#wwwmmmww#.",".#wwmmwwww#u",".#wwwmmmww#.","..#wwwwww#..","...######...","............","............","............"],
      pal: { "#": "#28324a", z: "#f0d84a", w: "#f0e8d8", m: "#8a5428", u: "#d8d4cc" }
    },
    "poltigliadubbiosa": {
      px: ["....qq......","......q.....",".....q......","............","...mmmm.....","..mmmmmmm...",".mmdmmmdmm..",".##########.","..#tttttt#..","...######...","............","............"],
      pal: { "#": "#3a3c42", q: "#e8e0d0", m: "#9aa06a", d: "#6e7448", t: "#d8dce4" }
    },
    "tortamenzogniera": {
      px: ["....x.......","..#####..c..",".#iiiii#c...",".#ccccc#.c..",".#ccccc#c...",".#ccccc#..c.","..#####.c...","............","............","............","............","............"],
      pal: { "#": "#2e160a", x: "#d83048", i: "#f8f0f4", c: "#6a3a1c" }
    },
    "cacioepepequantistica": {
      px: ["...e...e....",".....E......","...e...e....",".##########.",".#pkpppkpp#.",".#ppkpppkp#.","..#tttttt#..","...######...","....####....","............","............","............"],
      pal: { "#": "#2a3040", e: "#6ad8e8", E: "#f0f0e0", p: "#f0e0a0", k: "#22241e", t: "#5a8ac0" }
    },
    "sganassonediparmigiano": {
      px: ["............","............","..##........",".#cc##......",".#cccc##....",".#cCcccc##..",".#ccccCccc#.",".#rrrrrrrr#.","..########..","............","............","............"],
      pal: { "#": "#4a3410", c: "#f0e0b0", C: "#fcf8ec", r: "#c8963c" }
    },
    "merendinagattarcobaleno": {
      px: ["............","............","....#..#....","rr.######...","yy.#popop#..","bb.#ppppp#..","...######...","............","............","............","............","............"],
      pal: { "#": "#3a1a28", r: "#e84a4a", y: "#f0d84a", b: "#5ab4e8", p: "#f0a0c0", o: "#22241e" }
    },
    "meladoratablocchettosa": {
      px: ["............","......s.....",".....ss.....","..########..",".#gggggggg#.",".#gqgggggg#.",".#gggggggg#.",".#gggggggg#.","..########..","............","............","............"],
      pal: { "#": "#5a3a10", s: "#6a4a1c", g: "#f0c23c", q: "#f8e8a0" }
    },
    "frullavioladelmalaugurio": {
      px: [".......s....","......s.....","..########..","..#vvvvvv#..","..#vqvvvv#..","..#vvvvvv#..","...#vvvv#...","...#vvvv#...","....####....","............","............","............"],
      pal: { "#": "#2e1a40", s: "#e84a6a", v: "#8a5cc0", q: "#c0a0e8" }
    },
    "alettedell'intervistainfuocata": {
      px: ["......y..y..",".....ff.ff..",".oo.........",".ooo........","..oo........","...#hh#.....","..#hhhh#....","..#hhhhh#...","...#hhhh#...","....####....","............","............"],
      pal: { "#": "#3a1610", y: "#f0c23c", f: "#f08a2c", h: "#c05a2c", o: "#f4ecd8" }
    },
    "abbuffataindiretta": {
      px: ["RR..........","RR..........","....####....","...#bbbb#...","..#cccccc#..","..#mmmmmm#..","..#bbbbbb#..","...######...","............","............","............","............"],
      pal: { "#": "#3a2010", R: "#e83030", b: "#e8a85c", c: "#f0c848", m: "#7a4020" }
    }
  };

  // fallback per categoria per cibi futuri non mappati
  var FOOD_FALLBACK = {
    carne: {
      px: ["............","............","...#####....","..#mmmmm#...",".#mmmmmm#oo.",".#mmmmmm#oo.","..#mmmmm#...","...#####....","............","............","............","............"],
      pal: { "#": "#3a1616", m: "#c04a3c", o: "#f4ecd8" }
    },
    verdura: {
      px: ["............","......v.....","....vv.v....","...#cccc#...","...#cccc#...","....#cc#....","....#cc#....",".....##.....","............","............","............","............"],
      pal: { "#": "#4a2c14", c: "#f08a3c", v: "#3f8c34" }
    },
    pesce: {
      px: ["............","............","............","...#####....","..#fffff#.t.",".#effffff#tt","..#fffff#.t.","...#####....","............","............","............","............"],
      pal: { "#": "#1a2a34", f: "#5aa8d8", e: "#10141a", t: "#3f7ea6" }
    },
    dolce: {
      px: ["............","............","....#ii#....","...#iiii#...","..#iiiiii#..","..########..","...#wwww#...","...#wwww#...","....####....","............","............","............"],
      pal: { "#": "#3a1a28", i: "#f0a0c0", w: "#e8d8b0" }
    },
    base: {
      px: ["............","............","............","............",".##########.",".#bbbbbbbb#.",".#bbbbbbbb#.","..#bbbbbb#..","...######...","....####....","............","............"],
      pal: { "#": "#1e2830", b: "#4a7ba6" }
    }
  };

  // ===== Prop attività 12x12 (libro=Intelligenza, pesi=Forza, specchio=Carisma, corsa=Velocità) =====
  var PROP_ICONS = {
    libro: {
      px: ["............","............","..########..",".#bkbbbbbb#.",".#bkbbbbbb#.",".#bkbbbbbb#.",".#bkbbbbbb#.",".#bkbbbbbb#.",".#wwwwwwww#.","..########..","............","............"],
      pal: { "#": "#1e2830", b: "#4a7ba6", k: "#e85a78", w: "#f4f0e0" }
    },
    pesi: {
      px: ["............","............","............",".##......##.",".##......##.",".##bbbbbb##.",".##bbbbbb##.",".##......##.",".##......##.","............","............","............"],
      pal: { "#": "#37424c", b: "#8fa3ad" }
    },
    specchio: {
      px: ["............","...######...","..#mmmmmm#..","..#rmmmmm#..","..#rmmmmm#..","..#mmmmmm#..","..#mmmmmm#..","..#mmmmmm#..","...######...","....#..#....","...##..##...","............"],
      pal: { "#": "#3a2c14", m: "#cfeef8", r: "#ffffff" }
    },
    corsa: {
      px: ["............","............","............","...####.....","..#ssss#....",".#sssssss##.",".#wwwwwwww#.","..########..","............","............","............","............"],
      pal: { "#": "#1e2830", s: "#e85a3c", w: "#f4f4f0" }
    }
  };

  // ===== Prop animazioni idle di personalita' (GDD "Personalita'" -> "Animazioni idle di
  // personalita'", P1 leggero): 2 frame ciascuno, stesso stile outline+fill 12x12 dei prop
  // sopra. cuboRubik (nerd b), note (gentile a), monete (maleducato a), boccaccia NON e' un
  // prop ma un overlay sul volto del pet (v. drawBoccaccia sotto) quindi non e' qui dentro.
  var IDLE_PROP_ICONS = {
    // Cubo di Rubik (nerd, azione b): 2 frame con le facce colorate "spostate" per dare
    // l'idea che il pet lo stia girando tra le mani.
    cuborubik_0: {
      px: ["............","............","..########..",".#rrrgggbb#.",".#rrrgggbb#.","..########..",".#yyywwwoo#.",".#yyywwwoo#.","..########..","............","............","............"],
      pal: { "#": "#1a1a1a", r: "#d8402c", g: "#4aa84a", b: "#3a6ec4", y: "#e8d83c", w: "#f4f4f0", o: "#e8862c" }
    },
    cuborubik_1: {
      px: ["............","............","..########..",".#gggbbrr#..",".#gggbbrr#..","..########..","..#wwwooyyy#","..#wwwooyyy#","..########..","............","............","............"],
      pal: { "#": "#1a1a1a", r: "#d8402c", g: "#4aa84a", b: "#3a6ec4", y: "#e8d83c", w: "#f4f4f0", o: "#e8862c" }
    },
    // Note musicali (gentile, azione a): salgono (frame 1 piu' in alto), stile minimale.
    note_0: {
      px: ["............","...n........","...nn.......","...n.n......","..nn..n.....","............","......n.....","......nn....","......n.n...","............","............","............"],
      pal: { n: "#f0d84a" }
    },
    note_1: {
      px: ["...n........","...nn.......","...n.n......","..nn..n.....","............","......n.....","......nn....","......n.n...","............","............","............","............"],
      pal: { n: "#f0d84a" }
    },
    // Mucchietto di monete (maleducato, azione a): la moneta in cima "si sposta" tra i due frame,
    // come se il pet la stesse contando spostandola da una pila all'altra.
    monete_0: {
      px: ["............","............","............","............","......oo....","....ooooo...",".##ooooooo#.",".#ooooooooo.","...########.","............","............","............"],
      pal: { "#": "#8a5c14", o: "#f0c23c" }
    },
    monete_1: {
      px: ["............","............","............","....oo......","............","....ooooo...",".##ooooooo#.",".#ooooooooo.","...########.","............","............","............"],
      pal: { "#": "#8a5c14", o: "#f0c23c" }
    }
  };

  // Valigetta (PROTOTIPO 2, Blocco 2 "Partenza (valigia)"): sprite semplice 12x12, disegnato in
  // scena accanto al pet quando e' in fase valigia (state.valigia). Valigia marrone con manico
  // in alto, due borchie/chiusure dorate e una banda piu' scura. Stesso formato px/pal delle
  // altre icone (drawIcon).
  var VALIGETTA_ICON = {
    px: [
      "............",
      "....####....",
      "...#....#...",
      "..########..",
      ".#bbbbbbbb#.",
      ".#bbggbbgg#.",
      ".#bbbbbbbb#.",
      ".#bBBBBBBb#.",
      ".#bbbbbbbb#.",
      "..########..",
      "............",
      "............"
    ],
    pal: { "#": "#3a2412", b: "#9c6a34", B: "#6e4a22", g: "#f0c23c" }
  };

  // Disegna la valigetta su un canvas (di solito 12x12 o 24x24, la scala si adatta come drawIcon).
  function drawValigetta(canvas) {
    if (!canvas) return;
    drawIcon(canvas, VALIGETTA_ICON);
  }

  // ===== Scena PIANETA / STAZIONE dei ritirati (PROTOTIPO-2.md Blocco 4) =====
  // Dove sta il pet PARTITO (state.petPartito): sfondo stellato, un pianetino (alieno, sul suo
  // pianeta) o una stazione orbitante (robot, al centro di manutenzione) e il pet disegnato
  // sopra in posa d'attesa/malinconica. Riusa lo sprite del pet via draw() su un canvas
  // temporaneo, poi lo compone sulla scena (stesso pattern di disegnaScenaAddio in ui.js).
  // "flavor": { razza, tinta, corpo } opzionale; se assente si deduce dalla razza del pet.
  // La scena e' disegnata su base 112x64 (come le stanze) e scalata sul canvas passato.
  var PIANETA_BASE_W = 112;
  var PIANETA_BASE_H = 64;
  var PIANETA_FLAVOR = {
    alieno: { cielo: "#241a3a", pianeta: "#7a5cc0", pianetaOmbra: "#4d3a86", suolo: "#33265e", stazione: false },
    robot: { cielo: "#141c2c", pianeta: "#3a4c66", pianetaOmbra: "#26384f", suolo: "#1e2838", stazione: true }
  };

  function drawPianeta(canvas, petLike, opts) {
    if (!canvas || !petLike) return;
    opts = opts || {};
    var g = canvas.getContext("2d");
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);
    var sx = canvas.width / PIANETA_BASE_W;
    var sy = canvas.height / PIANETA_BASE_H;
    var needsScale = sx !== 1 || sy !== 1;
    if (needsScale) { g.save(); g.scale(sx, sy); }
    disegnaScenaPianeta(g, petLike, opts);
    if (needsScale) g.restore();
  }

  // Disegno alla base 112x64 (il chiamante scala). Deterministico: le stelle usano una
  // sequenza fissa (nessun rng) cosi' la scena e' identica a ogni ridisegno.
  var STELLE = [
    [8, 6], [20, 12], [34, 4], [48, 10], [60, 5], [74, 14], [88, 8], [100, 4],
    [14, 22], [40, 18], [66, 24], [92, 20], [104, 30], [6, 34], [26, 30], [82, 32]
  ];
  function disegnaScenaPianeta(g, petLike, opts) {
    var razza = (opts.razza || petLike.razza) === "robot" ? "robot" : "alieno";
    var fl = PIANETA_FLAVOR[razza];
    var W = PIANETA_BASE_W, H = PIANETA_BASE_H;

    // cielo notturno
    g.fillStyle = fl.cielo;
    g.fillRect(0, 0, W, H);

    // stelle (2 tinte, punti fissi)
    for (var i = 0; i < STELLE.length; i++) {
      g.fillStyle = (i % 3 === 0) ? "#fff6c8" : "#cfd8ff";
      var s = (i % 4 === 0) ? 2 : 1;
      g.fillRect(STELLE[i][0], STELLE[i][1], s, s);
    }

    if (fl.stazione) {
      // ROBOT: stazione spaziale orbitante sullo sfondo (a destra, in alto)
      disegnaStazione(g, 78, 8, fl);
    } else {
      // ALIENO: pianeta grande sullo sfondo (a destra, in alto)
      disegnaPianetino(g, 86, 18, 16, fl);
    }

    // "terreno" in primo piano dove sta il pet (curva bassa a suolo)
    g.fillStyle = fl.suolo;
    // semplice collinetta: rettangolo di base + smusso agli angoli
    g.fillRect(0, H - 14, W, 14);
    g.fillStyle = fl.pianetaOmbra;
    g.fillRect(0, H - 14, W, 2);

    // il PET partito, in posa d'attesa al centro sul suolo. Riuso lo sprite in piedi (frame 0),
    // corpo forzato a 'normale' e sporco off: e' "il ricordo" del pet, non lo stato di cura.
    // dimensione FISICA del pet sul pianeta: 32px fissi (prima era SIZE*2; con SIZE=32 sarebbe
    // diventato 64 e il pet gigante sullo sfondo — Strada 1). draw() lo rende a canvas/SIZE.
    var PLANET_PET_PX = 32;
    var petCanvas = document.createElement("canvas");
    petCanvas.width = PLANET_PET_PX;
    petCanvas.height = PLANET_PET_PX;
    var petLike2 = {
      razza: petLike.razza,
      sottorazza: petLike.sottorazza,
      parts: petLike.parts,
      stadio: petLike.stadio || "teen",
      corpo: opts.corpo || "normale",
      sporco: false,
      modSprite: petLike.modSprite || null // la modifica M17 e' parte del pet, anche "via da casa"
    };
    draw(petCanvas, petLike2, { frame: 0 });
    var pw = PLANET_PET_PX;
    var px = Math.round((W - pw) / 2);
    var py = (H - 14) - pw + 4; // piedi appoggiati al suolo
    g.drawImage(petCanvas, px, py);

    // piccola "nuvoletta di malinconia": un sospiro sopra la testa (tre puntini che salgono)
    g.fillStyle = "rgba(207,216,255,0.8)";
    var hx = px + pw - 3;
    var hy = py + 1;
    g.fillRect(hx, hy, 2, 2);
    g.fillRect(hx + 3, hy - 3, 2, 2);
    g.fillRect(hx + 6, hy - 7, 3, 3);
  }

  // pianetino: cerchio pixel semplice con terminatore d'ombra + anello sottile
  function disegnaPianetino(g, cx, cy, r, fl) {
    for (var y = -r; y <= r; y++) {
      for (var x = -r; x <= r; x++) {
        if (x * x + y * y <= r * r) {
          // meta' in ombra (lato destro/basso)
          g.fillStyle = (x + y > r * 0.3) ? fl.pianetaOmbra : fl.pianeta;
          g.fillRect(cx + x, cy + y, 1, 1);
        }
      }
    }
    // anello
    g.strokeStyle = "rgba(255,255,255,0.25)";
    g.lineWidth = 1;
    g.beginPath();
    g.ellipse ? g.ellipse(cx, cy, r + 5, 3, -0.3, 0, Math.PI * 2) : g.arc(cx, cy, r + 5, 0, Math.PI * 2);
    g.stroke();
  }

  // stazione spaziale: corpo centrale + due pannelli solari + luce lampeggiante-fissa
  function disegnaStazione(g, x, y, fl) {
    // pannelli solari (bracci)
    g.fillStyle = "#2a3d5c";
    g.fillRect(x - 12, y + 4, 10, 6);
    g.fillRect(x + 14, y + 4, 10, 6);
    g.fillStyle = "#4a6fa0";
    g.fillRect(x - 11, y + 5, 8, 1);
    g.fillRect(x + 15, y + 5, 8, 1);
    // corpo centrale
    g.fillStyle = fl.pianeta;
    g.fillRect(x - 2, y, 16, 12);
    g.fillStyle = fl.pianetaOmbra;
    g.fillRect(x - 2, y + 8, 16, 4);
    // oblo'
    g.fillStyle = "#bfe0ff";
    g.fillRect(x + 2, y + 3, 3, 3);
    g.fillRect(x + 8, y + 3, 3, 3);
    // luce di segnalazione
    g.fillStyle = "#ff6a6a";
    g.fillRect(x + 5, y - 2, 2, 2);
  }

  function normalizzaNome(nome) {
    return String(nome || "").toLowerCase().replace(/\s+/g, "");
  }

  function drawIcon(canvas, icon) {
    if (!canvas || !icon) return;
    var ctx = canvas.getContext("2d");
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    var scale = canvas.width / ICON_SIZE;
    for (var y = 0; y < icon.px.length; y++) {
      var row = icon.px[y];
      for (var x = 0; x < row.length; x++) {
        var ch = row[x];
        if (ch === ".") continue;
        ctx.fillStyle = icon.pal[ch] || "#ff00ff";
        ctx.fillRect(x * scale, y * scale, scale, scale);
      }
    }
  }

  // cibo: oggetto da PETQ.content.data.cibi ({nome, categoria, ...}); match per nome normalizzato, fallback per categoria
  function drawFood(canvas, cibo) {
    if (!canvas || !cibo) return;
    var icon = FOOD_ICONS[normalizzaNome(cibo.nome)] ||
               FOOD_FALLBACK[normalizzaNome(cibo.categoria)] ||
               FOOD_FALLBACK.base;
    drawIcon(canvas, icon);
  }

  // id: 'libro' | 'pesi' | 'specchio' | 'corsa'
  function drawProp(canvas, id) {
    if (!canvas) return;
    drawIcon(canvas, PROP_ICONS[id] || PROP_ICONS.libro);
  }

  // Prop delle animazioni idle di personalita' (GDD "Personalita'"): id 'cuborubik' | 'note' |
  // 'monete' (2 frame ciascuno, v. IDLE_PROP_ICONS sopra). frame: 0|1. Usata da ui.js per il
  // prop nuovo mostrato accanto al pet durante la mini-azione idle (nerd/gentile/maleducato).
  function drawIdleProp(canvas, id, frame) {
    if (!canvas) return;
    var key = (id || "cuborubik") + "_" + (frame === 1 ? 1 : 0);
    drawIcon(canvas, IDLE_PROP_ICONS[key] || IDLE_PROP_ICONS.cuborubik_0);
  }

  // ===== Effetti overlay sul canvas del pet =====
  // Questi overlay (schiuma/briciole/boccaccia/palpebre/Zzz) sono APPROSSIMAZIONI del volto in
  // una griglia 16-logica, non arte del corpo: la scala e' SEMPRE canvas.width/16 (NON /SIZE),
  // cosi' restano ancorati alla stessa posizione fisica del volto qualunque sia la risoluzione
  // del corpo sotto (16 raddoppiato o 32 nativo). Strada 1 (8 lug 2026): prima usavano /SIZE.
  var FOAM_WHITE = "#ffffff", FOAM_AZURE = "#a8e0f0";
  var CRUMB_BROWN = "#8a5c2e", CRUMB_DARK = "#5c3a1e";

  // 3-4 nuvolette di schiuma sul corpo del pet, 2 frame alternabili (lavaggio)
  function drawFoam(ctx, frame) {
    if (!ctx) return;
    var s = ctx.canvas.width / 16;
    var f = frame === 1 ? 1 : 0;
    var clouds = [[4, 8], [9, 6], [6, 11], [11, 10]];
    clouds.forEach(function (c, i) {
      var dx = f === 1 ? (i % 2 === 0 ? 1 : -1) : 0;
      var x = c[0] + dx, y = c[1];
      ctx.fillStyle = FOAM_WHITE;
      ctx.fillRect(x * s, y * s, 2 * s, 2 * s);
      ctx.fillStyle = FOAM_AZURE;
      ctx.fillRect((x - 1) * s, (y + 1) * s, s, s);
      ctx.fillRect((x + 2) * s, y * s, s, s);
      ctx.fillRect((x + 1) * s, (y - 1) * s, s, s);
    });
  }

  // 3-4 briciole che cadono davanti al pet, 2 frame (frame 1 = più in basso)
  function drawCrumbs(ctx, frame) {
    if (!ctx) return;
    var s = ctx.canvas.width / 16;
    var f = frame === 1 ? 1 : 0;
    var crumbs = [[6, 9], [9, 10], [7, 12], [10, 8]];
    crumbs.forEach(function (c, i) {
      var x = c[0] + (f === 1 && i % 2 === 0 ? 1 : 0);
      var y = c[1] + f;
      ctx.fillStyle = i % 2 === 0 ? CRUMB_BROWN : CRUMB_DARK;
      ctx.fillRect(x * s, y * s, s, s);
    });
  }

  // Boccaccia (idle personalita' maleducato, azione b): overlay sul volto, indipendente da
  // razza/sottorazza come le palpebre sotto — copre la fascia occhi/bocca (righe 6-9, stesso
  // terzo superiore usato da drawPalpebre) con "occhi storti" (due trattini in diagonale
  // invece che orizzontali) + lingua rosa che sporge in basso. 2 frame: la lingua oscilla di
  // 1px per dare l'idea del "bleh" ripetuto.
  var LINGUA_COLOR = "#e8748c";
  function drawBoccaccia(ctx, frame) {
    if (!ctx) return;
    var s = ctx.canvas.width / 16;
    var f = frame === 1 ? 1 : 0;
    // occhi storti: un pixel alto da un lato, basso dall'altro (invece della fascia dritta)
    ctx.fillStyle = "rgba(20,20,24,0.85)";
    ctx.fillRect(3 * s, (6 - f) * s, 2 * s, 1 * s);
    ctx.fillRect(5 * s, 7 * s, 2 * s, 1 * s);
    ctx.fillRect(9 * s, 7 * s, 2 * s, 1 * s);
    ctx.fillRect(11 * s, (6 + f) * s, 2 * s, 1 * s);
    // lingua fuori: rettangolo rosa che sporge dal "mento" verso il basso
    ctx.fillStyle = LINGUA_COLOR;
    ctx.fillRect(6 * s, 9 * s, 3 * s, (2 + f) * s);
  }

  // Palpebre chiuse (overlay sonno, GDD "Energia e sonno"): due trattini scuri sovrapposti
  // alla fascia occhi del pet, indipendenti da razza/sottorazza (riga occhi non nota qui a
  // priori: l'overlay copre approssimativamente il terzo superiore del corpo, dove in tutti
  // gli sprite 16x16 di questo modulo si trovano gli occhi/il viso).
  var ZZZ_COLOR = "#dfe4ec";
  function drawPalpebre(ctx) {
    if (!ctx) return;
    var s = ctx.canvas.width / 16;
    ctx.fillStyle = "rgba(20,20,24,0.75)";
    ctx.fillRect(3 * s, 6 * s, 4 * s, 1 * s);
    ctx.fillRect(9 * s, 6 * s, 4 * s, 1 * s);
  }

  // 2-3 "Z" pixel animabili sopra la testa del pet, 2 frame (alternano posizione/dimensione).
  // "scale" opzionale: pixel-schermo per unita' logica (griglia 16x16). Se omesso si ricava da
  // ctx.canvas.width/SIZE come prima (caso tipico: si disegna sul mini-canvas del pet stesso).
  // Il chiamante puo' passarlo esplicitamente per disegnare le Z altrove (es. sul canvas
  // stanza, molto piu' ampio, per non farle clippare dal bordo del mini-canvas del pet — v.
  // ui.js disegnaZzzStanza, fix del bug noto di clipping).
  function drawZzz(ctx, frame, scale) {
    if (!ctx) return;
    var s = scale || (ctx.canvas.width / 16);
    var f = frame === 1 ? 1 : 0;
    ctx.fillStyle = ZZZ_COLOR;
    var zetas = f === 1
      ? [[11, -1, 3], [13, -3, 2], [14, -5, 1]]
      : [[10, 0, 3], [12, -2, 2], [13, -4, 1]];
    zetas.forEach(function (z) {
      var x = z[0], y = z[1], size = z[2];
      // "Z" minimale: barra sopra, diagonale, barra sotto (scala size in pixel logici)
      ctx.fillRect(x * s, y * s, size * s, s);
      ctx.fillRect((x + size - 1) * s, (y + 1) * s, s, s);
      if (size > 2) ctx.fillRect((x + size - 2) * s, (y + 1) * s, s, s);
      ctx.fillRect(x * s, (y + size - 1) * s, size * s, s);
    });
  }

  // overlay completo "dorme" sul canvas del pet: palpebre chiuse + Zzz
  function drawSonno(ctx, frame) {
    drawPalpebre(ctx);
    drawZzz(ctx, frame);
  }

  // ===== Cartoline esiti missione: canvas logico 112x64, rect-composition + sprite del pet =====
  var CART_W = 112, CART_H = 64;

  // Topo delle fogne (grosso, peloso): 3 espressioni. chars: # outline, f pelo, v pancia/muso, e occhi, t coda
  var RAT_PAL = { "#": "#2a2018", f: "#8a7562", v: "#c9b299", e: "#141210", t: "#d89a9a" };
  var RAT_FUGA = ["................","................","................","................",".....##....##...",".....#f#..#f#...","....##########..","...#ffffffffff#.","tt#fffffffeeff#.",".tt#ffffffffvv#.","...#ffvvvvvvff#.","....##########..","....#..#..#..#..","...##..##..##...","................","................"];
  var RAT_PAURA = ["................","................","................","................","...##......##...","...#f#....#f#...","....########....","...#ffffffff#...","..#feeffffeef#..","..#feeffffeef#..","..#ffffvvffff#..","...#ffffffff#t..","...#ffffffff#.t.","....##....##....","................","................"];
  var RAT_AMICO = ["................","................","................","................","...##......##...","...#f#....#f#...","....########....","...#ffffffff#...","..#ffeffffeff#..","..#ffffvvffff#..","..#fvvvvvvvvf#..","..#fvvvvvvvvf#..","...#ffffffff#t..","....##..##..t...","................","................"];

  // helper rect locali (stesso stile rect-composition di rooms.js)
  function CR(g, x, y, w, h, col) { g.fillStyle = col; g.fillRect(x, y, w, h); }
  function CO(g, x, y, w, h, outline, fill) { CR(g, x, y, w, h, outline); CR(g, x + 1, y + 1, w - 2, h - 2, fill); }

  // pet dentro la scena: x,y = angolo alto-sinistra, scala 1 (16px) o 2 (32px, protagonista)
  function petAt(g, petLike, x, y, scale) {
    var res = resolvePet(petLike);
    // scale e' in unita' "16-cella" (1=16px, 2=32px). Il frame ora e' 32 celle (SIZE): la scala
    // effettiva per cella si dimezza cosi' la dimensione FISICA resta identica (Strada 1).
    var effScale = scale * 16 / SIZE;
    paintFrame(g, res.frame, res.palette, effScale, x, y);
    if (petLike.sporco) drawDirtOverlay(g, res.frame, effScale, x, y);
  }
  function ratAt(g, variant, x, y, scale) {
    paintFrame(g, variant, RAT_PAL, scale, x, y);
  }
  // leggenda-companion dentro una scena (cartoline Imprese): riusa lo sprite del pet leggenda.
  function legAt(g, id, x, y, scale) {
    petAt(g, { razza: "leggenda", leggendaId: id, stadio: "adulto", corpo: "normale", parts: {} }, x, y, scale);
  }

  // sagoma di comparsa (testa+corpo), per folle e pubblico
  function figura(g, x, y, h, col) {
    CR(g, x + 1, y, 4, 4, col);
    CR(g, x, y + 4, 6, h - 4, col);
  }
  function scintilla(g, x, y, col) {
    CR(g, x, y - 1, 1, 3, col);
    CR(g, x - 1, y, 3, 1, col);
  }
  function pioggia(g, col) {
    for (var i = 0; i < 10; i++) {
      var px = (i * 23 + 7) % CART_W;
      var py = (i * 13 + 5) % 40;
      CR(g, px, py, 1, 4, col);
    }
  }
  function striscioneTraguardo(g, x, y, w) {
    CR(g, x, y, 2, 26, "#8fa3ad");
    CR(g, x + w - 2, y, 2, 26, "#8fa3ad");
    for (var i = 0; i < Math.floor(w / 4); i++) {
      CR(g, x + 2 + i * 4, y, 4, 4, i % 2 === 0 ? "#f4f4f0" : "#1e2830");
      CR(g, x + 2 + i * 4, y + 4, 4, 4, i % 2 === 0 ? "#1e2830" : "#f4f4f0");
    }
  }

  // sfondi condivisi
  function sfondoSalaGiochi(g) {
    CR(g, 0, 0, CART_W, 48, "#16121f");
    CR(g, 0, 48, CART_W, 16, "#221c2e");
    CR(g, 0, 3, CART_W, 2, "#e85ad8"); // neon a soffitto
    // cabinati sul fondo
    [8, 40, 82].forEach(function (cx, i) {
      CO(g, cx, 12, 22, 34, "#0c0a12", "#2e2840");
      CR(g, cx + 3, 15, 16, 11, ["#3fd8ea", "#e85ad8", "#5ce87f"][i]);
      CR(g, cx + 4, 28, 6, 2, "#120e1a");
      CR(g, cx + 12, 28, 6, 2, "#120e1a");
    });
  }
  function sfondoParco(g) {
    CR(g, 0, 0, CART_W, 46, "#a9d9f2");
    CR(g, 0, 46, CART_W, 18, "#5cb84a");
    CR(g, 0, 44, CART_W, 2, "#3f8c34");
    CR(g, 92, 6, 10, 10, "#f8e05a"); // sole
    // palloncini
    [[14, 10, "#e85a78"], [24, 6, "#4dd8e8"], [98, 26, "#f0b84a"]].forEach(function (b) {
      CR(g, b[0], b[1], 6, 7, b[2]);
      CR(g, b[0] + 2, b[1] + 7, 1, 8, "#3a3a3a");
    });
  }
  function sfondoDojo(g) {
    CR(g, 0, 0, CART_W, 44, "#8a5c34");
    CR(g, 0, 4, CART_W, 2, "#6e4826");
    CR(g, 0, 26, CART_W, 2, "#6e4826");
    CR(g, 0, 44, CART_W, 20, "#4a8c5c"); // tatami
    CR(g, 0, 52, CART_W, 1, "#3a6e48");
    for (var x = 14; x < CART_W; x += 14) CR(g, x, 44, 1, 20, "#3a6e48");
    CO(g, 48, 8, 16, 22, "#2b2018", "#f0ead8"); // stendardo
    CR(g, 53, 12, 6, 3, "#c22a3a");
    CR(g, 53, 18, 6, 3, "#c22a3a");
  }
  function sfondoBiblioteca(g) {
    CR(g, 0, 0, CART_W, 46, "#c9a878");
    CR(g, 0, 46, CART_W, 18, "#8a5c34");
    // scaffali con dorsi colorati
    [4, 78].forEach(function (sx) {
      CO(g, sx, 6, 30, 38, "#3a2814", "#6e4826");
      [10, 22, 34].forEach(function (sy) {
        CR(g, sx + 2, sy, 26, 2, "#3a2814");
        var libri = ["#c22a3a", "#4a7ba6", "#5cb84a", "#f0b84a", "#8a4ab0"];
        for (var i = 0; i < 5; i++) CR(g, sx + 3 + i * 5, sy - 8, 4, 8, libri[(i + sy) % 5]);
      });
    });
  }
  function sfondoVicolo(g) {
    CR(g, 0, 0, CART_W, 48, "#141a2a");
    CR(g, 0, 48, CART_W, 16, "#1c2334");
    // palazzi scuri con finestrelle
    CO(g, 2, 6, 26, 42, "#0a0e18", "#1e2637");
    CO(g, 86, 10, 24, 38, "#0a0e18", "#1e2637");
    [[6, 10], [16, 10], [6, 20], [90, 14], [100, 22]].forEach(function (f) {
      CR(g, f[0], f[1], 4, 5, "#f0b84a");
    });
    // vapore dal tombino
    CR(g, 52, 50, 10, 3, "#2a3448");
    CR(g, 54, 42, 2, 8, "#3f4a62");
    CR(g, 58, 38, 2, 12, "#3f4a62");
    pioggia(g, "#4a6a9a");
  }
  function sfondoPista(g) {
    CR(g, 0, 0, CART_W, 40, "#12101e");
    CR(g, 0, 40, CART_W, 24, "#221c34");
    CR(g, 0, 46, CART_W, 2, "#e85ad8"); // corsie neon
    CR(g, 0, 56, CART_W, 2, "#3fd8ea");
    // pubblico dietro la transenna
    for (var i = 0; i < 8; i++) figura(g, 4 + i * 14, 26, 12, i % 2 === 0 ? "#3a3450" : "#2e2a44");
    CR(g, 0, 38, CART_W, 2, "#5c5480"); // transenna
  }
  function sfondoFogna(g, calda) {
    CR(g, 0, 0, CART_W, 46, calda ? "#2e3428" : "#232a22");
    CR(g, 0, 46, CART_W, 18, "#1a1f18");
    // tubi
    CR(g, 0, 8, CART_W, 5, "#3f4a3a");
    CR(g, 0, 8, CART_W, 1, "#556450");
    CR(g, 18, 13, 4, 33, "#3f4a3a");
    CR(g, 88, 13, 4, 33, "#3f4a3a");
    // canale d'acqua
    CR(g, 0, 58, CART_W, 6, calda ? "#3a5c4a" : "#2e4a3e");
    if (calda) { // lanterna calda per la scena amicizia
      CR(g, 52, 16, 8, 8, "#f0b84a");
      CR(g, 54, 12, 4, 4, "#8a5c2e");
    }
  }

  // ===== Le 17 scene =====
  var SCENE = {
    std_videogioco: function (g, pet) {
      sfondoSalaGiochi(g);
      petAt(g, pet, 36, 28, 2); // di fronte al cabinato centrale, in primo piano
    },
    std_sociale: function (g, pet) {
      sfondoParco(g);
      figura(g, 66, 30, 18, "#6e5a8a");
      figura(g, 80, 32, 16, "#4a6a5a");
      petAt(g, pet, 24, 26, 2);
      CO(g, 46, 46, 12, 4, "#8a8a86", "#f4f4f0"); // piatto
      CR(g, 49, 42, 6, 4, "#f0a0c0"); // fetta di torta
      CR(g, 49, 41, 6, 1, "#f8f0f4");
    },
    std_combattimento: function (g, pet) {
      sfondoDojo(g);
      figura(g, 76, 30, 16, "#3a3450");
      figura(g, 88, 32, 14, "#2e2a44");
      figura(g, 100, 31, 15, "#3a3450");
      petAt(g, pet, 18, 26, 2); // in guardia in primo piano
    },
    std_studio: function (g, pet) {
      sfondoBiblioteca(g);
      petAt(g, pet, 40, 14, 2); // seduto dietro il tavolo
      CO(g, 40, 44, 34, 12, "#3a2814", "#8a5c34"); // tavolo davanti al pet
      CO(g, 46, 38, 20, 8, "#8a8a86", "#f8f4ec"); // album aperto sul piano
      CR(g, 55, 39, 1, 6, "#8a8a86");
    },
    std_consegne: function (g, pet) {
      sfondoVicolo(g);
      var sporco = { razza: pet.razza, sottorazza: pet.sottorazza, parts: pet.parts, stadio: pet.stadio, corpo: pet.corpo, sporco: true };
      petAt(g, sporco, 38, 26, 2); // di corsa, macchie addosso (brief scheda M5)
      CO(g, 66, 38, 12, 10, "#3a2814", "#a8743c"); // pacco sottobraccio
      CR(g, 71, 38, 2, 10, "#6e4826");
    },
    std_sport: function (g, pet) {
      sfondoPista(g);
      petAt(g, pet, 40, 24, 2);
      CR(g, 42, 56, 10, 3, "#f4f4f0"); // pattini
      CR(g, 60, 56, 10, 3, "#f4f4f0");
    },
    fail_generica: function (g, pet) {
      CR(g, 0, 0, CART_W, 48, "#8a929c"); // cielo grigio
      CR(g, 0, 48, CART_W, 16, "#5c646e");
      CR(g, 10, 6, 22, 8, "#6e767e"); // nuvoloni
      CR(g, 44, 4, 26, 8, "#6e767e");
      CO(g, 84, 22, 24, 26, "#2b3640", "#a8968a"); // casa in fondo alla via
      CR(g, 92, 34, 8, 14, "#4a3a2e");
      CR(g, 88, 16, 16, 6, "#6e4826");
      CR(g, 30, 56, 20, 4, "#4a6a9a"); // pozzanghera
      CR(g, 34, 57, 8, 1, "#8fb8d8");
      petAt(g, pet, 24, 26, 2); // mogio sulla via di casa
      pioggia(g, "#a8b2bc");
    },
    super_m1: function (g, pet) {
      sfondoSalaGiochi(g);
      CR(g, 30, 0, 4, 28, "#3a3450"); // fasci di luce
      CR(g, 78, 0, 4, 28, "#3a3450");
      figura(g, 4, 34, 14, "#3a3450");
      figura(g, 98, 34, 14, "#3a3450");
      petAt(g, pet, 40, 28, 2);
      // coppa dorata sopra la testa: calice + manici + stelo + base
      CO(g, 49, 12, 14, 9, "#6e4826", "#f0b84a");
      CR(g, 46, 13, 3, 4, "#f0b84a"); // manico sx
      CR(g, 63, 13, 3, 4, "#f0b84a"); // manico dx
      CR(g, 54, 21, 4, 3, "#c99a3c"); // stelo
      CR(g, 51, 24, 10, 2, "#6e4826"); // base
      CR(g, 51, 13, 2, 3, "#f8e05a"); // riflesso
      scintilla(g, 44, 10, "#f8f0a0");
      scintilla(g, 68, 16, "#f8f0a0");
    },
    super_m2: function (g, pet) {
      sfondoParco(g);
      figura(g, 12, 28, 20, "#6e5a8a");
      figura(g, 26, 31, 17, "#4a6a5a");
      figura(g, 80, 28, 20, "#8a5c5c");
      figura(g, 94, 31, 17, "#5a6a8a");
      petAt(g, pet, 44, 26, 2);
      CO(g, 62, 44, 14, 7, "#6e1a26", "#d83048"); // macchinina
      CR(g, 64, 51, 3, 3, "#1e2830");
      CR(g, 71, 51, 3, 3, "#1e2830");
      CR(g, 65, 45, 6, 2, "#8fd8f0");
      scintilla(g, 78, 42, "#f8f0a0");
      scintilla(g, 60, 40, "#f8f0a0");
    },
    super_m3: function (g, pet) {
      sfondoDojo(g);
      figura(g, 8, 32, 15, "#3a3450");
      figura(g, 20, 34, 13, "#2e2a44");
      figura(g, 92, 32, 15, "#3a3450");
      figura(g, 102, 34, 13, "#2e2a44");
      petAt(g, pet, 42, 24, 2);
      CR(g, 48, 44, 20, 3, "#c22a3a"); // cintura del completo nuovo
      CR(g, 66, 44, 4, 6, "#c22a3a");
      scintilla(g, 40, 22, "#f8f0a0");
      scintilla(g, 76, 28, "#f8f0a0");
    },
    super_m4: function (g, pet) {
      sfondoBiblioteca(g);
      petAt(g, pet, 24, 26, 2);
      // pila di libri più alta del pet
      var libri = ["#c22a3a", "#4a7ba6", "#5cb84a", "#f0b84a", "#8a4ab0", "#4dd8e8", "#c05a88"];
      for (var i = 0; i < 7; i++) CO(g, 58, 52 - i * 6, 22, 6, "#3a2814", libri[i]);
      CO(g, 60, 10, 18, 6, "#6e4826", "#f0b84a"); // il volume prezioso in cima alla pila
      scintilla(g, 82, 10, "#f8f0a0");
    },
    super_m5: function (g, pet) {
      sfondoVicolo(g);
      CR(g, 24, 58, 18, 4, "#4a6a9a"); // pozzanghere sotto il salto
      CR(g, 58, 58, 16, 4, "#4a6a9a");
      petAt(g, pet, 40, 12, 2); // a mezz'aria sopra le pozzanghere
      CR(g, 30, 26, 8, 2, "#3f4a62"); // scie del salto
      CR(g, 26, 32, 8, 2, "#3f4a62");
      // scooter giocattolo
      CO(g, 74, 40, 16, 4, "#5c1a26", "#d83048");
      CR(g, 76, 44, 4, 4, "#1e2830");
      CR(g, 84, 44, 4, 4, "#1e2830");
      CR(g, 87, 30, 2, 10, "#8fa3ad");
      CR(g, 84, 30, 8, 2, "#8fa3ad");
    },
    super_m6: function (g, pet) {
      CR(g, 0, 0, CART_W, 48, "#1a1420"); // studio buio
      CR(g, 0, 48, CART_W, 16, "#2a2230");
      // riflettori: fasci che scendono sul pet
      CR(g, 46, 0, 6, 10, "#3a3450");
      CR(g, 44, 10, 10, 12, "#4a4462");
      CR(g, 42, 22, 14, 26, "#5a5474");
      petAt(g, pet, 40, 26, 2);
      // statuetta dorata in mano
      CR(g, 70, 34, 4, 8, "#f0b84a");
      CR(g, 69, 42, 6, 3, "#c99a3c");
      CR(g, 71, 31, 2, 3, "#f8e05a");
      // regista in piedi che applaude
      figura(g, 96, 28, 20, "#3a3450");
      CR(g, 93, 30, 3, 2, "#3a3450");
      CR(g, 102, 30, 3, 2, "#3a3450");
      scintilla(g, 66, 28, "#f8f0a0");
    },
    super_m7_dominio: function (g, pet) {
      sfondoFogna(g, false);
      petAt(g, pet, 30, 24, 2);
      // tutte e 4 le armi intorno: bastone, sai, nunchaku, katane
      CR(g, 24, 26, 2, 16, "#8a5c2e"); // bastone
      CR(g, 64, 30, 2, 8, "#c9ccd4"); // sai 1
      CR(g, 62, 32, 6, 2, "#c9ccd4");
      CR(g, 68, 28, 2, 6, "#8fa3ad"); // nunchaku
      CR(g, 72, 30, 2, 6, "#8fa3ad");
      CR(g, 70, 30, 2, 1, "#5c646e");
      CR(g, 76, 24, 2, 12, "#dfe4ec"); // katana 1
      CR(g, 80, 26, 2, 12, "#dfe4ec"); // katana 2
      CR(g, 76, 36, 2, 3, "#5c3a1e");
      CR(g, 80, 38, 2, 3, "#5c3a1e");
      ratAt(g, RAT_FUGA, 92, 32, 1); // topo in fuga sullo sfondo
    },
    super_m7_intimidazione: function (g, pet) {
      sfondoFogna(g, false);
      petAt(g, pet, 28, 22, 2); // pet minaccioso, in alto
      ratAt(g, RAT_PAURA, 64, 40, 1); // topo terrorizzato ai suoi piedi
      CR(g, 63, 43, 2, 2, "#8fd8f0"); // gocce di sudore
      CR(g, 79, 44, 2, 2, "#8fd8f0");
    },
    super_m7_amicizia: function (g, pet) {
      sfondoFogna(g, true); // atmosfera calda, lanterna accesa
      petAt(g, pet, 24, 28, 2); // seduti fianco a fianco
      ratAt(g, RAT_AMICO, 60, 20, 2); // il topone, grosso, accanto
      CR(g, 55, 34, 4, 4, "#e85a78"); // cuoricino tra i due
      CR(g, 54, 33, 2, 2, "#e85a78");
      CR(g, 58, 33, 2, 2, "#e85a78");
    },
    super_m8: function (g, pet) {
      sfondoPista(g);
      striscioneTraguardo(g, 62, 14, 36);
      petAt(g, pet, 64, 24, 2); // oltre il traguardo, largo margine
      CR(g, 66, 56, 10, 3, "#f4f4f0"); // pattini scintillanti
      CR(g, 84, 56, 10, 3, "#f4f4f0");
      scintilla(g, 64, 54, "#f8f0a0");
      scintilla(g, 96, 55, "#f8f0a0");
      figura(g, 6, 42, 14, "#3a3450"); // avversari lontanissimi
      figura(g, 18, 44, 12, "#2e2a44");
    },
    // Tutorial m0 "Regalo di benvenuto" (fix audit: scenaIdDa emette super_m0 ma la scena
    // mancava -> fallback su fail_generica: la PRIMA cartolina di una partita nuova era il
    // pet mogio sotto la pioggia). Interno caldo del negozio di giocattoli + pacco regalo.
    super_m0: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#5c4a6e");
      CR(g, 0, 46, CART_W, 18, "#8a5c34");
      CR(g, 0, 44, CART_W, 2, "#6e4826");
      CO(g, 4, 8, 30, 30, "#3a2814", "#a9773f"); // scaffale coi giocattoli
      CR(g, 6, 14, 26, 2, "#6e4826"); CR(g, 6, 24, 26, 2, "#6e4826");
      CR(g, 8, 9, 4, 4, "#d83048"); CR(g, 16, 10, 5, 3, "#4a7ba6"); CR(g, 25, 9, 4, 4, "#5ce87f");
      CR(g, 8, 18, 5, 5, "#f0b84a"); CR(g, 18, 19, 4, 4, "#e85ad8"); CR(g, 26, 18, 4, 5, "#4dd8e8");
      for (var iT = 0; iT < 5; iT++) CR(g, 72 + iT * 8, 4, 8, 6, iT % 2 === 0 ? "#e85a5a" : "#f4f0e0"); // tenda a strisce
      petAt(g, pet, 40, 26, 2);
      CO(g, 74, 40, 18, 14, "#8a2030", "#d83048"); // pacco regalo
      CR(g, 82, 40, 3, 14, "#f8e05a"); CR(g, 74, 45, 18, 3, "#f8e05a"); // nastri
      CR(g, 80, 36, 3, 4, "#f8e05a"); CR(g, 84, 36, 3, 4, "#f8e05a"); // fiocco
      scintilla(g, 70, 32, "#fff6c0"); scintilla(g, 98, 36, "#fff6c0");
    },
    std_m9: function (g, pet) {
    CR(g, 0, 0, CART_W, 46, "#2b3a4a"); CR(g, 0, 46, CART_W, 18, "#6b5a3e"); CR(g, 0, 44, CART_W, 2, "#4a3f2a");
    CR(g, 6, 4, 40, 4, "#c05a44"); CR(g, 4, 8, 6, 3, "#c8a24a"); CR(g, 46, 8, 6, 3, "#c8a24a");
    CO(g, 8, 22, 26, 22, "#1a2430", "#eceadd"); CR(g, 11, 25, 20, 3, "#3a5a8a"); CR(g, 11, 30, 14, 2, "#5a5a5a"); CR(g, 11, 34, 18, 2, "#5a5a5a"); CR(g, 11, 38, 10, 2, "#5a5a5a"); CR(g, 19, 44, 4, 4, "#1a2430");
    petAt(g, pet, 34, 24, 2);
    CO(g, 66, 36, 8, 12, "#2a3540", "#8ad0c0"); CR(g, 68, 30, 4, 6, "#8ad0c0"); CR(g, 67, 44, 6, 4, "#c8f0a0");
    CR(g, 67, 24, 3, 4, "#7ad86a"); CR(g, 70, 20, 4, 4, "#a8ee8a"); CR(g, 74, 16, 3, 3, "#7ad86a");
    figura(g, 88, 30, 16, "#3a4a5e"); figura(g, 98, 31, 15, "#2e3c50"); figura(g, 108, 32, 14, "#3a4a5e");
    CR(g, 84, 46, 30, 4, "#4a3f2a"); CR(g, 88, 40, 4, 2, "#e8e2c8"); CR(g, 98, 41, 4, 2, "#e8e2c8"); CR(g, 108, 42, 3, 2, "#e8e2c8");
    scintilla(g, 60, 20, "#f8e05a"); scintilla(g, 46, 14, "#f8e05a");
    },
    std_m10: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#2a2f3a"); CR(g, 0, 46, CART_W, 18, "#4a4038"); CR(g, 0, 44, CART_W, 2, "#6a5c4c"); CR(g, 0, 30, CART_W, 4, "#5a6470"); CR(g, 14, 30, 3, 4, "#3a424e"); CR(g, 46, 30, 3, 4, "#3a424e"); CR(g, 82, 30, 3, 4, "#3a424e"); CR(g, 4, 34, CART_W - 8, 4, "#7a8490"); CR(g, 4, 37, CART_W - 8, 1, "#3a424e"); figura(g, 10, 20, 16, "#3a5a6a"); figura(g, 22, 22, 14, "#5a4a6a"); figura(g, 90, 20, 16, "#6a4a4a"); figura(g, 100, 22, 14, "#4a5a4a"); CR(g, 30, 8, 52, 3, "#c04030"); CR(g, 32, 11, 3, 4, "#8a2a20"); CR(g, 77, 11, 3, 4, "#8a2a20"); petAt(g, pet, 30, 24, 2); CO(g, 68, 48, 16, 10, "#20242c", "#8a94a0"); CR(g, 70, 50, 5, 4, "#c8342c"); CR(g, 78, 50, 5, 4, "#3fd8ea"); CR(g, 72, 46, 2, 2, "#20242c"); CR(g, 79, 46, 2, 2, "#20242c"); CR(g, 64, 52, 3, 2, "#3a424e"); CR(g, 84, 52, 3, 2, "#3a424e"); CO(g, 22, 50, 10, 6, "#20242c", "#4a4038"); CR(g, 25, 47, 4, 3, "#d8b040"); CR(g, 26, 45, 2, 2, "#5a4a3a"); scintilla(g, 74, 44, "#f8e05a"); scintilla(g, 82, 42, "#f8a030"); scintilla(g, 66, 46, "#f8e05a"); scintilla(g, 88, 47, "#fff0a0"); },
    std_m11: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#e8c9a0"); CR(g, 0, 44, CART_W, 2, "#c79a68"); CR(g, 0, 46, CART_W, 18, "#a9764a"); CR(g, 0, 46, CART_W, 2, "#8a5c38"); CO(g, 8, 8, 22, 24, "#6a4a2a", "#c9b090"); CR(g, 13, 8, 2, 24, "#6a4a2a"); CR(g, 19, 8, 2, 24, "#6a4a2a"); CR(g, 25, 8, 2, 24, "#6a4a2a"); CO(g, 84, 12, 20, 22, "#6a4a2a", "#c9b090"); CR(g, 90, 12, 2, 22, "#6a4a2a"); CR(g, 97, 12, 2, 22, "#6a4a2a"); figura(g, 90, 40, 10, "#7a8a6a"); figura(g, 22, 22, 9, "#9a7a5a"); CR(g, 58, 40, 10, 8, "#c86a4a"); CR(g, 58, 39, 10, 2, "#e88a6a"); CR(g, 60, 42, 6, 4, "#f0d0a0"); petAt(g, pet, 36, 28, 2); CR(g, 66, 48, 8, 6, "#8a9a6a"); CR(g, 67, 47, 6, 2, "#aabb88"); scintilla(g, 74, 26, "#fff0c0"); scintilla(g, 30, 20, "#ffd0d0"); },
    std_m12: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#2e6b4a"); CR(g, 0, 0, CART_W, 12, "#4f9c6e"); CR(g, 26, 0, 2, 46, "#7fd0a0"); CR(g, 56, 0, 2, 46, "#7fd0a0"); CR(g, 86, 0, 2, 46, "#7fd0a0"); CR(g, 0, 14, CART_W, 1, "#7fd0a0"); CR(g, 0, 30, CART_W, 1, "#7fd0a0"); CR(g, 0, 46, CART_W, 18, "#4a3520"); CR(g, 0, 44, CART_W, 4, "#6b4d2c"); figura(g, 92, 30, 20, "#3f7a3a"); CR(g, 88, 22, 8, 3, "#5cae52"); CR(g, 8, 10, 5, 36, "#2f8f4a"); CO(g, 4, 6, 12, 8, "#1f5a30", "#8ad04a"); CR(g, 7, 8, 2, 2, "#12331c"); CR(g, 12, 8, 2, 2, "#12331c"); CR(g, 3, 20, 8, 4, "#3fae5a"); CR(g, 100, 8, 5, 38, "#2f8f4a"); CO(g, 96, 4, 12, 8, "#1f5a30", "#c86ad0"); CR(g, 99, 6, 2, 2, "#331233"); CR(g, 104, 6, 2, 2, "#331233"); CR(g, 74, 16, 4, 30, "#2f8f4a"); CR(g, 70, 18, 12, 5, "#5cae52"); petAt(g, pet, 40, 26, 2); CO(g, 32, 46, 8, 6, "#2a4a5a", "#4a90b0"); CR(g, 30, 47, 3, 2, "#6ab0d0"); CO(g, 58, 48, 14, 8, "#5a3d20", "#7a5a35"); CR(g, 62, 46, 6, 3, "#3fae5a"); scintilla(g, 22, 20, "#d8ffb0"); scintilla(g, 96, 24, "#ffd8f0"); scintilla(g, 66, 40, "#d8ffb0"); },
    std_m13: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#3a2a24"); CR(g, 0, 46, CART_W, 18, "#5a3a22"); CR(g, 0, 44, CART_W, 3, "#2a1c16"); CR(g, 0, 30, CART_W, 5, "#4a2e20"); CR(g, 8, 32, 3, 3, "#7a5a3a"); CR(g, 34, 33, 3, 3, "#7a5a3a"); CR(g, 74, 32, 3, 3, "#7a5a3a"); CR(g, 100, 33, 3, 3, "#7a5a3a"); figura(g, 18, 24, 22, "#2c2622"); figura(g, 90, 22, 24, "#2c2622"); CO(g, 60, 20, 26, 24, "#3a3430", "#b06a4a"); CR(g, 66, 16, 8, 8, "#c07850"); CR(g, 62, 30, 22, 5, "#7a4a30"); petAt(g, pet, 36, 24, 2); CO(g, 30, 46, 40, 6, "#3a2418", "#6a4428"); CR(g, 32, 44, 36, 2, "#8a5c38"); CO(g, 12, 42, 8, 10, "#8a6a20", "#e0b840"); CR(g, 14, 40, 4, 3, "#f0e090"); CO(g, 92, 40, 9, 12, "#7a5a1a", "#d0a838"); CR(g, 94, 36, 5, 4, "#e8d060"); CR(g, 95, 34, 3, 3, "#f4e8a0"); scintilla(g, 90, 32, "#fff6c0"); },
    std_m14: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#4a4038"); CR(g, 0, 46, CART_W, 18, "#6b5d4f"); CR(g, 0, 44, CART_W, 2, "#312a24"); CR(g, 72, 8, 40, 38, "#3a322b"); CR(g, 100, 6, 12, 40, "#8a7a5a"); CR(g, 96, 36, 16, 4, "#2b241f"); CR(g, 92, 28, 20, 4, "#2b241f"); CR(g, 88, 20, 24, 4, "#2b241f"); CR(g, 84, 12, 28, 4, "#2b241f"); CR(g, 86, 6, 3, 30, "#c9a24a"); CR(g, 86, 6, 26, 2, "#c9a24a"); CO(g, 8, 30, 16, 14, "#6e4a2a", "#a9773f"); CO(g, 10, 20, 12, 10, "#6e4a2a", "#b98a4c"); CR(g, 8, 37, 16, 1, "#5a3a1f"); CO(g, 62, 6, 22, 40, "#2a1f18", "#7a5636"); CR(g, 66, 6, 2, 40, "#5a3f24"); CR(g, 71, 24, 4, 4, "#e8d48a"); petAt(g, pet, 40, 28, 2); scintilla(g, 30, 18, "#d9cbb0"); scintilla(g, 58, 40, "#d9cbb0"); },
    std_m15: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#2a2438"); CR(g, 44, 0, 24, 46, "#5a5a72"); CR(g, 0, 0, 40, 46, "#3a3450"); CR(g, 72, 0, 40, 46, "#3a3450"); CR(g, 10, 8, 6, 6, "#e8d060"); CR(g, 26, 20, 6, 6, "#c8a040"); CR(g, 84, 12, 6, 6, "#e8d060"); CR(g, 96, 26, 6, 6, "#c8a040"); CR(g, 0, 46, CART_W, 18, "#33303a"); CR(g, 0, 45, CART_W, 2, "#1c1a22"); CR(g, 14, 52, 8, 3, "#26242c"); CR(g, 40, 57, 10, 3, "#26242c"); CR(g, 82, 53, 8, 3, "#26242c"); CO(g, 6, 36, 22, 16, "#1e4a2a", "#2e7a44"); CR(g, 6, 34, 22, 3, "#3e9a58"); figura(g, 82, 30, 18, "#1a1a24"); CR(g, 68, 20, 8, 6, "#8a5a2a"); CR(g, 66, 22, 2, 4, "#6a4420"); scintilla(g, 78, 18, "#f0d84a"); scintilla(g, 88, 24, "#f0d84a"); petAt(g, pet, 34, 26, 2); },
    std_m16: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#1b6e78"); CR(g, 0, 44, CART_W, 3, "#0f4a52"); CR(g, 0, 47, CART_W, 17, "#3aa8c0"); CR(g, 0, 47, CART_W, 2, "#8fdcec"); CR(g, 6, 8, 22, 30, "#2a8e9a"); CO(g, 6, 8, 22, 30, "#0f4a52", "#2a8e9a"); CR(g, 10, 12, 6, 9, "#63c9d6"); CR(g, 18, 22, 7, 11, "#63c9d6"); CO(g, 78, 22, 20, 22, "#0f4a52", "#4fc0d0"); CR(g, 80, 24, 7, 8, "#bfeef4"); CR(g, 91, 30, 5, 3, "#0f4a52"); CR(g, 85, 40, 12, 4, "#7a5a2e"); CR(g, 84, 44, 14, 3, "#5a3f1e"); CO(g, 62, 40, 12, 11, "#bfeef4", "#7fd6e6"); CR(g, 66, 50, 4, 2, "#7a5a2e"); CR(g, 65, 45, 4, 2, "#e8873a"); CR(g, 69, 45, 2, 1, "#c85a1a"); CR(g, 34, 20, 6, 2, "#e8873a"); CR(g, 40, 21, 2, 1, "#c85a1a"); CR(g, 33, 22, 2, 1, "#c85a1a"); CR(g, 96, 14, 5, 2, "#f0a83a"); CR(g, 101, 15, 2, 1, "#d06a1a"); petAt(g, pet, 40, 28, 2); scintilla(g, 30, 46, "#eafcff"); scintilla(g, 58, 40, "#eafcff"); scintilla(g, 74, 50, "#cfeef8"); scintilla(g, 46, 52, "#eafcff"); },
    std_m17: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#2a3a4a"); CR(g, 0, 46, CART_W, 18, "#4a4e56"); CR(g, 0, 44, CART_W, 2, "#1b2732"); CR(g, 0, 52, CART_W, 1, "#5c616a"); CO(g, 6, 8, 26, 20, "#12303a", "#0e2630"); scintilla(g, 11, 13, "#48e0c0"); scintilla(g, 20, 12, "#f0d040"); scintilla(g, 27, 20, "#f06060"); scintilla(g, 14, 22, "#60a0f0"); CR(g, 84, 0, 4, 12, "#20262e"); CR(g, 82, 12, 8, 3, "#3a4048"); CR(g, 84, 15, 4, 5, "#c0c6cc"); scintilla(g, 85, 20, "#ffffff"); figura(g, 90, 28, 20, "#7a6a3a"); CO(g, 30, 47, 22, 6, "#2a2e34", "#6a6f78"); petAt(g, pet, 34, 26, 2); CO(g, 4, 42, 14, 10, "#20262e", "#585d66"); CR(g, 6, 44, 3, 3, "#48e0c0"); CR(g, 11, 44, 3, 3, "#f06060"); CR(g, 6, 48, 8, 2, "#8a8f98"); },
    std_m18: function (g, pet) {
    CR(g, 0, 0, CART_W, 46, "#1c2230"); CR(g, 0, 46, CART_W, 18, "#3a3a44"); CR(g, 0, 44, CART_W, 2, "#14161e");
    CO(g, 4, 8, 30, 34, "#6a6e78", "#4a4e58"); CR(g, 8, 12, 22, 26, "#565a64"); CR(g, 17, 22, 4, 4, "#c8b048"); CR(g, 12, 24, 2, 8, "#2c2e36"); CR(g, 24, 15, 2, 8, "#2c2e36"); CR(g, 26, 30, 6, 3, "#8a8e98");
    CO(g, 82, 20, 22, 6, "#6a5a2a", "#c8a838"); CR(g, 84, 16, 18, 4, "#3a3020"); scintilla(g, 90, 18, "#f0e060");
    petAt(g, pet, 40, 26, 2);
    CR(g, 38, 8, 2, 40, "#e03040"); CR(g, 74, 6, 2, 42, "#e03040"); scintilla(g, 39, 30, "#ff8080"); scintilla(g, 75, 24, "#ff8080");
    CO(g, 86, 40, 8, 4, "#8a6a20", "#e0c040"); CO(g, 96, 42, 8, 4, "#8a6a20", "#e0c040"); CO(g, 90, 45, 8, 4, "#8a6a20", "#e0c040");
    },
    // M18 FALLIMENTO dedicato (richiesta fondatore per la clip SKILL ISSUE, 12 ago 2026):
    // dalla scheda — "pet ammanettato bonariamente da due guardie, una fetta di panino in mano".
    // Stesso caveau notturno dello standard, ma l'allarme e' SCATTATO (lampeggiante rosso al
    // posto dei laser), le due guardie in divisa lo scortano fuori, e la teca col Panino
    // Gigante resta INTATTA sullo sfondo: e' il colpo mancato che si vede.
    fail_m18: function (g, pet) {
    CR(g, 0, 0, CART_W, 46, "#1c2230"); CR(g, 0, 46, CART_W, 18, "#3a3a44"); CR(g, 0, 44, CART_W, 2, "#14161e");
    CO(g, 4, 8, 30, 34, "#6a6e78", "#4a4e58"); CR(g, 8, 12, 22, 26, "#565a64"); CR(g, 17, 22, 4, 4, "#c8b048"); // porta del caveau, richiusa
    CR(g, 52, 2, 8, 5, "#e03040"); CR(g, 54, 7, 4, 2, "#2c2e36"); // lampeggiante dell'allarme
    scintilla(g, 47, 5, "#ff8080"); scintilla(g, 65, 5, "#ff8080"); scintilla(g, 56, 12, "#ff8080");
    CO(g, 82, 20, 22, 6, "#6a5a2a", "#c8a838"); CR(g, 84, 16, 18, 4, "#3a3020"); scintilla(g, 90, 18, "#f0e060"); // la teca: panino ancora li'
    // Le guardie ADDOSSO al pet, in divisa piu' chiara del fondo (primo giro bocciato guardando
    // il render: due colonnine scure lontane non leggevano "scorta") + braccio teso verso di lui.
    figura(g, 30, 26, 22, "#44608a"); // guardia sinistra
    CR(g, 30, 24, 6, 3, "#22344a"); CR(g, 33, 27, 5, 1, "#101c2c"); // berretto, visiera verso il pet
    CR(g, 32, 36, 2, 2, "#e8c84a"); // distintivo
    CR(g, 36, 34, 3, 5, "#22344a"); // braccio teso
    figura(g, 78, 26, 22, "#44608a"); // guardia destra, speculare
    CR(g, 78, 24, 6, 3, "#22344a"); CR(g, 76, 27, 5, 1, "#101c2c");
    CR(g, 80, 36, 2, 2, "#e8c84a");
    CR(g, 75, 34, 3, 5, "#22344a"); // braccio verso la manetta
    petAt(g, pet, 40, 26, 2);
    CR(g, 70, 41, 3, 3, "#9aa2ac"); CR(g, 73, 42, 2, 1, "#6a727c"); CR(g, 76, 42, 2, 1, "#6a727c"); // manetta + catenella verso la guardia
    CR(g, 34, 42, 6, 2, "#e8c07a"); CR(g, 35, 41, 4, 1, "#c85a3a"); CR(g, 35, 44, 4, 1, "#e8c07a"); // la fetta di panino "per la fatica"
    scintilla(g, 74, 22, "#9ad0f0"); // goccia di imbarazzo
    },
    std_m19: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#1a1030"); CR(g, 0, 46, CART_W, 18, "#5a2f18"); CR(g, 0, 46, CART_W, 2, "#8a4a26"); CR(g, 30, 0, 10, 46, "#3a2a5a"); CR(g, 74, 0, 10, 46, "#3a2a5a"); CR(g, 33, 2, 4, 4, "#fff6c0"); CR(g, 77, 2, 4, 4, "#fff6c0"); figura(g, 10, 40, 12, "#2e3f6a"); figura(g, 20, 41, 11, "#3a5a4a"); figura(g, 92, 40, 12, "#5a3a6a"); figura(g, 102, 41, 11, "#3a5a6a"); CO(g, 8, 34, 96, 2, "#6a4020", "#3a2410"); petAt(g, pet, 42, 24, 2); CR(g, 62, 30, 1, 16, "#c8c8d0"); CO(g, 59, 26, 7, 5, "#2a2a30", "#8a8a92"); CO(g, 74, 40, 12, 12, "#c8a020", "#f0d040"); CR(g, 79, 45, 2, 2, "#2a2418"); scintilla(g, 26, 12, "#fff6c0"); scintilla(g, 88, 16, "#ffd0e8"); scintilla(g, 54, 8, "#c0f0ff"); },
    std_m20: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#3a2f4a"); CR(g, 0, 46, CART_W, 18, "#2a2530"); CR(g, 0, 45, CART_W, 2, "#4a4055"); CR(g, 10, 14, 16, 32, "#241c30"); CR(g, 13, 18, 3, 3, "#f0c040"); CR(g, 20, 24, 3, 3, "#f0c040"); CR(g, 13, 32, 3, 3, "#f0c040"); CR(g, 86, 8, 20, 38, "#1e1828"); CR(g, 90, 13, 3, 3, "#f0c040"); CR(g, 98, 20, 3, 3, "#f0c040"); CR(g, 90, 30, 3, 3, "#f0c040"); CR(g, 62, 4, 30, 42, "#161020"); CR(g, 68, 2, 8, 8, "#161020"); CR(g, 84, 2, 8, 8, "#161020"); CR(g, 67, 14, 4, 4, "#e83028"); CR(g, 82, 14, 4, 4, "#e83028"); CR(g, 74, 22, 6, 5, "#5a4030"); CR(g, 64, 46, 10, 4, "#4a4250"); CR(g, 96, 47, 8, 3, "#4a4250"); petAt(g, pet, 36, 26, 2); CO(g, 30, 20, 3, 22, "#8a8a90", "#d8d8e0"); CR(g, 27, 20, 9, 3, "#7a5a2a"); scintilla(g, 33, 18, "#fff2b0"); scintilla(g, 78, 12, "#e83028"); },
    std_m21: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#2a2438"); CR(g, 0, 46, CART_W, 18, "#3d3550"); CR(g, 0, 44, CART_W, 2, "#1c1828"); CO(g, 6, 6, 22, 14, "#101018", "#7a1420"); CR(g, 9, 9, 4, 8, "#ff2e2e"); CR(g, 14, 9, 4, 8, "#ff2e2e"); CR(g, 20, 9, 4, 8, "#ff2e2e"); CO(g, 84, 5, 22, 18, "#5a5a66", "#14203a"); CR(g, 88, 9, 6, 6, "#e8f0ff"); CR(g, 96, 9, 6, 6, "#e8f0ff"); CR(g, 90, 17, 10, 2, "#a0b0d0"); CR(g, 40, 4, 8, 9, "#f0e8c8"); CR(g, 41, 6, 6, 1, "#4a4030"); CR(g, 41, 9, 5, 1, "#4a4030"); CR(g, 62, 3, 8, 8, "#e8dcc0"); CR(g, 63, 5, 6, 1, "#4a4030"); CR(g, 63, 8, 4, 1, "#4a4030"); scintilla(g, 30, 12, "#ff5050"); petAt(g, pet, 40, 26, 2); CO(g, 26, 48, 12, 12, "#c8a020", "#f0d040"); CR(g, 30, 44, 4, 6, "#8a7018"); CR(g, 28, 52, 8, 2, "#3a3010"); CR(g, 29, 55, 8, 2, "#3a3010"); CO(g, 78, 50, 14, 10, "#6a4a2a", "#9a6a3a"); CR(g, 82, 50, 2, 10, "#3a2818"); },
    std_m22: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#5a4632"); CR(g, 0, 46, CART_W, 18, "#3a2c1e"); CR(g, 0, 44, CART_W, 2, "#241a10"); CR(g, 74, 8, 30, 22, "#6b543c"); CR(g, 74, 8, 30, 2, "#3a2c1e"); CR(g, 87, 28, 4, 8, "#241a10"); CR(g, 82, 14, 14, 2, "#c9a24a"); CR(g, 88, 12, 2, 8, "#c9a24a"); CR(g, 84, 20, 3, 3, "#c9a24a"); CR(g, 91, 20, 3, 3, "#c9a24a"); CR(g, 74, 34, 30, 12, "#4a3826"); CR(g, 74, 34, 30, 2, "#2c2114"); CR(g, 90, 30, 8, 6, "#2c2114"); figura(g, 96, 30, 14, "#7a8a9a"); CR(g, 96, 25, 6, 4, "#3a464e"); CR(g, 100, 26, 4, 2, "#8a3c2a"); petAt(g, pet, 40, 26, 2); CO(g, 22, 40, 12, 10, "#2c2114", "#4a3826"); figura(g, 26, 34, 12, "#8a9aa8"); scintilla(g, 30, 30, "#f4e08a"); scintilla(g, 100, 18, "#f4e08a"); },
    std_m23: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#7a5a44"); CR(g, 0, 0, CART_W, 6, "#5c4230"); CR(g, 0, 40, CART_W, 2, "#5c4230"); CR(g, 0, 46, CART_W, 18, "#4a3a2c"); CR(g, 0, 46, CART_W, 2, "#332618"); CO(g, 70, 10, 30, 26, "#c9a24a", "#8a5a6a"); CO(g, 74, 14, 22, 18, "#5a3a4a", "#a86a5a"); CR(g, 78, 18, 8, 6, "#e8c890"); CR(g, 80, 26, 12, 4, "#3a2838"); scintilla(g, 68, 14, "#bff0ff"); scintilla(g, 100, 20, "#bff0ff"); scintilla(g, 96, 32, "#bff0ff"); CO(g, 6, 8, 30, 9, "#2a2018", "#e8d8b8"); CR(g, 9, 11, 3, 3, "#4a3a2c"); CR(g, 14, 11, 3, 3, "#4a3a2c"); CR(g, 19, 11, 3, 3, "#4a3a2c"); CR(g, 24, 11, 3, 3, "#4a3a2c"); CR(g, 29, 11, 3, 3, "#4a3a2c"); petAt(g, pet, 38, 26, 2); CR(g, 20, 50, 3, 12, "#3a2818"); CR(g, 30, 50, 3, 12, "#3a2818"); CR(g, 18, 48, 17, 3, "#5a4230"); CR(g, 24, 40, 8, 10, "#c9b898"); CR(g, 25, 41, 6, 8, "#8a6a5a"); },
    std_m24: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#161428"); CR(g, 0, 44, CART_W, 4, "#0e0c1c"); CR(g, 0, 46, CART_W, 18, "#2a2440"); CR(g, 0, 46, CART_W, 2, "#1a1630"); CO(g, 8, 6, 10, 40, "#3a3458", "#4c466e"); CO(g, 94, 6, 10, 40, "#3a3458", "#4c466e"); CO(g, 66, 14, 14, 20, "#2e2a48", "#3c3860"); CR(g, 70, 6, 6, 8, "#5a5478"); CR(g, 68, 34, 10, 4, "#242038"); CO(g, 24, 30, 8, 12, "#5a3a24", "#7a5030"); CR(g, 26, 26, 4, 4, "#8a5c38"); striscioneTraguardo(g, 0, 2, CART_W); figura(g, 84, 33, 15, "#1e1a30"); figura(g, 20, 34, 13, "#1e1a30"); petAt(g, pet, 40, 26, 2); CR(g, 58, 54, 4, 6, "#e06018"); CR(g, 57, 60, 6, 2, "#f0a020"); CR(g, 88, 55, 4, 6, "#e06018"); CR(g, 87, 61, 6, 2, "#f0a020"); scintilla(g, 74, 20, "#c8b8ff"); scintilla(g, 30, 12, "#c8b8ff"); },
    std_m25: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#1a1030"); CR(g, 0, 46, CART_W, 18, "#241540"); CR(g, 0, 45, CART_W, 2, "#3a2a5a"); CO(g, 34, 4, 44, 26, "#0a3a4a", "#0e2a52"); CR(g, 40, 10, 32, 3, "#ff3a5a"); CR(g, 40, 16, 20, 3, "#f5d020"); CR(g, 40, 21, 26, 3, "#f5d020"); scintilla(g, 44, 7, "#ffffff"); scintilla(g, 68, 25, "#ffffff"); CO(g, 4, 22, 16, 24, "#0e0820", "#c02840"); CR(g, 7, 26, 10, 9, "#40e0d0"); CO(g, 92, 22, 16, 24, "#0e0820", "#2848c0"); CR(g, 95, 26, 10, 9, "#f5d020"); figura(g, 26, 33, 14, "#3a2a5a"); figura(g, 84, 34, 13, "#2a3a5a"); scintilla(g, 24, 20, "#f5d020"); scintilla(g, 88, 21, "#ff3a5a"); petAt(g, pet, 44, 26, 2); },
    std_m26: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#f4a25a"); CR(g, 0, 0, CART_W, 14, "#e8734a"); CR(g, 0, 14, CART_W, 8, "#f28c52"); CR(g, 0, 38, CART_W, 8, "#f7c07a"); CR(g, 84, 8, 7, 7, "#ffe6a0"); CR(g, 0, 46, CART_W, 18, "#7a5a4a"); CR(g, 0, 44, CART_W, 2, "#5c4436"); CR(g, 4, 30, 20, 16, "#8a5c4a"); CR(g, 4, 28, 20, 2, "#6e4636"); CO(g, 9, 32, 5, 6, "#3a2820", "#5c4436"); CR(g, 92, 26, 18, 20, "#7a4e42"); CR(g, 92, 24, 18, 2, "#5c3a30"); CR(g, 96, 18, 4, 8, "#4a4a52"); CR(g, 98, 16, 8, 2, "#4a4a52"); CR(g, 101, 12, 2, 6, "#4a4a52"); CR(g, 30, 24, 1, 12, "#3a2c26"); CR(g, 78, 22, 1, 14, "#3a2c26"); CR(g, 30, 25, 48, 1, "#2a2018"); CR(g, 36, 26, 8, 8, "#e8d8c0"); CR(g, 48, 26, 7, 9, "#d86a7a"); CR(g, 60, 26, 8, 7, "#7ab0d8"); petAt(g, pet, 40, 24, 2); CO(g, 62, 40, 12, 7, "#4a5058", "#8a9098"); CR(g, 73, 42, 3, 2, "#c8ccd0"); CR(g, 60, 43, 3, 2, "#c04030"); CR(g, 65, 41, 1, 1, "#40e0ff"); scintilla(g, 68, 39, "#a0f0ff"); scintilla(g, 86, 10, "#fff2c0"); },
    std_m27: function (g, pet) { CR(g, 0, 0, CART_W, 44, "#2a1e3a"); CR(g, 0, 44, CART_W, 20, "#7a2030"); CR(g, 0, 44, CART_W, 2, "#3a1018"); CR(g, 0, 20, CART_W, 12, "#3a2a4e"); figura(g, 10, 26, 12, "#4a3a5e"); figura(g, 24, 26, 12, "#5a4a6e"); figura(g, 38, 25, 12, "#4a3a5e"); figura(g, 74, 25, 12, "#5a4a6e"); figura(g, 88, 26, 12, "#4a3a5e"); figura(g, 100, 26, 12, "#5a4a6e"); scintilla(g, 16, 12, "#fff0b0"); scintilla(g, 96, 14, "#fff0b0"); CR(g, 8, 42, 96, 20, "#d8c8a0"); CR(g, 8, 42, 96, 2, "#b8a880"); CR(g, 10, 44, 4, 18, "#3a3a4a"); CR(g, 98, 44, 4, 18, "#3a3a4a"); CR(g, 8, 46, 96, 1, "#f4f4f0"); CR(g, 8, 52, 96, 1, "#f4f4f0"); CR(g, 8, 58, 96, 1, "#f4f4f0"); CR(g, 68, 30, 14, 24, "#6a4a3a"); CR(g, 70, 26, 10, 6, "#8a3030"); petAt(g, pet, 34, 28, 2); },
    std_m28: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#7a6a58"); CR(g, 0, 0, CART_W, 20, "#9a8a72"); CR(g, 0, 34, CART_W, 12, "#4a5a58"); CO(g, 4, 24, 14, 10, "#2a3038", "#3a4650"); CO(g, 22, 20, 12, 14, "#2a3038", "#455058"); CO(g, 96, 22, 13, 12, "#2a3038", "#3a4650"); CR(g, 0, 46, CART_W, 18, "#5a4c3a"); CR(g, 0, 44, CART_W, 2, "#403626"); CR(g, 70, 30, 30, 16, "#6a5a3e"); CR(g, 76, 26, 18, 10, "#7a6a44"); CR(g, 80, 22, 8, 6, "#8a7a50"); scintilla(g, 84, 20, "#c8b060"); CO(g, 66, 48, 8, 8, "#3a2e1e", "#a04030"); CR(g, 68, 50, 2, 2, "#e8d840"); CR(g, 71, 51, 3, 1, "#606a70"); CO(g, 88, 50, 7, 6, "#3a2e1e", "#4a8a5a"); CR(g, 90, 52, 2, 2, "#e8d840"); CR(g, 20, 52, 6, 5, "#606a70"); CR(g, 27, 54, 4, 3, "#8a3040"); petAt(g, pet, 40, 26, 2); scintilla(g, 62, 40, "#f0e060"); scintilla(g, 58, 46, "#f0e060"); },
    std_m29: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#3a2a52"); CR(g, 0, 46, CART_W, 18, "#4a3626"); CR(g, 0, 44, CART_W, 2, "#2e2016"); CR(g, 8, 8, 2, 2, "#f0d060"); CR(g, 30, 5, 2, 2, "#f07050"); CR(g, 54, 9, 2, 2, "#60d0f0"); CR(g, 100, 6, 2, 2, "#f0d060"); scintilla(g, 20, 12, "#f6e28a"); scintilla(g, 68, 7, "#f6e28a"); figura(g, 12, 30, 16, "#5a4a72"); figura(g, 24, 32, 14, "#48607a"); CO(g, 82, 12, 10, 36, "#6a2a30", "#c8323c"); CR(g, 84, 18, 6, 2, "#f4f4f0"); CR(g, 84, 26, 6, 2, "#f4f4f0"); CR(g, 84, 34, 6, 2, "#f4f4f0"); CO(g, 80, 6, 14, 6, "#8a6a10", "#f0c838"); CR(g, 84, 28, 6, 3, "#f05038"); CO(g, 76, 46, 22, 4, "#2e2016", "#7a5a3a"); petAt(g, pet, 40, 26, 2); CR(g, 62, 20, 2, 22, "#8a6a3a"); CO(g, 58, 14, 10, 8, "#3a3a40", "#8a8a92"); },
    std_m30: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#2a2340"); CR(g, 0, 46, CART_W, 18, "#3a3050"); CR(g, 0, 44, CART_W, 2, "#4a3d66"); CO(g, 4, 10, 30, 24, "#12101c", "#141a2e"); CR(g, 7, 13, 24, 15, "#e5407a"); CR(g, 9, 16, 6, 2, "#ffd0e0"); CR(g, 17, 16, 12, 2, "#ffd0e0"); CR(g, 9, 20, 16, 2, "#ffd0e0"); CR(g, 9, 24, 10, 2, "#ffd0e0"); CO(g, 88, 6, 20, 20, "#c8c8d4", "#4a4a5a"); CR(g, 91, 9, 14, 14, "#fff4c8"); CR(g, 96, 24, 4, 14, "#22202c"); scintilla(g, 84, 14, "#fff4c8"); scintilla(g, 108, 20, "#fff4c8"); scintilla(g, 78, 30, "#ffe080"); petAt(g, pet, 40, 26, 2); CO(g, 40, 50, 30, 12, "#1a1826", "#3a3a4a"); CR(g, 43, 52, 24, 8, "#6fd0ff"); CR(g, 45, 54, 8, 4, "#0e2a3a"); CR(g, 30, 34, 6, 6, "#ff5090"); CR(g, 72, 30, 5, 5, "#ff5090"); CR(g, 62, 20, 4, 4, "#ff70a8"); scintilla(g, 36, 30, "#ffffff"); figura(g, 12, 44, 14, "#5a4a72"); figura(g, 100, 46, 12, "#4a5a72"); },
    std_m31: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#f3d9e6"); CR(g, 0, 44, CART_W, 2, "#c9a0b6"); CR(g, 0, 46, CART_W, 18, "#8a5a6e"); CR(g, 0, 46, CART_W, 2, "#a06a80"); CR(g, 8, 4, 14, 5, "#e8607a"); CR(g, 26, 3, 14, 5, "#f0b040"); CR(g, 44, 4, 14, 5, "#e8607a"); CR(g, 62, 3, 14, 5, "#f0b040"); CR(g, 80, 4, 14, 5, "#e8607a"); CR(g, 98, 3, 12, 5, "#f0b040"); figura(g, 16, 30, 20, "#3a4a7a"); figura(g, 90, 30, 20, "#d0d0dc"); petAt(g, pet, 42, 26, 2); CR(g, 82, 32, 20, 14, "#faf0f2"); CR(g, 85, 24, 14, 8, "#faf0f2"); CR(g, 88, 18, 8, 6, "#faf0f2"); CO(g, 82, 32, 20, 14, "#d8b0c0", "#faf0f2"); CR(g, 82, 38, 20, 2, "#f0c0d0"); CR(g, 85, 28, 14, 2, "#f0c0d0"); CR(g, 90, 15, 2, 4, "#f0a0c0"); scintilla(g, 91, 14, "#fff0b0"); CR(g, 4, 40, 22, 6, "#6a3a4e"); CO(g, 7, 36, 4, 5, "#c0d8e0", "#e8f4f8"); CO(g, 15, 36, 4, 5, "#c0d8e0", "#e8f4f8"); },
    std_m32: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#1e1830"); CR(g, 0, 46, CART_W, 18, "#3a2a1e"); CR(g, 0, 44, CART_W, 2, "#5a3f2a"); CO(g, 60, 6, 44, 22, "#2a4a6e", "#173a5c"); CR(g, 64, 11, 30, 2, "#7fe0ff"); CR(g, 64, 16, 24, 2, "#7fe0ff"); CR(g, 64, 21, 34, 2, "#5ab8e0"); CR(g, 28, 40, 56, 8, "#6e4a2a"); CR(g, 28, 38, 56, 2, "#8a5f38"); CR(g, 34, 6, 14, 40, "#3a3050"); CR(g, 38, 6, 6, 40, "#5a4e78"); scintilla(g, 40, 30, "#fff6c0"); figura(g, 8, 34, 14, "#241c38"); figura(g, 18, 36, 12, "#2e2444"); figura(g, 96, 35, 13, "#241c38"); figura(g, 104, 37, 11, "#2e2444"); scintilla(g, 10, 26, "#ffd23f"); scintilla(g, 22, 28, "#ff9a3f"); scintilla(g, 100, 27, "#ffd23f"); scintilla(g, 108, 29, "#ff6ad0"); petAt(g, pet, 44, 24, 2); CR(g, 60, 30, 1, 16, "#20242a"); CO(g, 57, 26, 6, 5, "#0e1216", "#4a5058"); },

    // ===== GRANDI IMPRESE M65-M72 (cartoline dedicate): pet protagonista + LEGGENDA companion (legAt) =====
    // M65 La Palestra degli Dei — Giga Ciad, tramonto in montagna, pet regge un macigno sopra la testa.
    std_m65: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#f0995a"); CR(g, 0, 0, CART_W, 14, "#e8734a"); CR(g, 0, 14, CART_W, 8, "#f5ac66"); CR(g, 90, 6, 9, 9, "#ffe6a0");
      CR(g, 0, 46, CART_W, 18, "#5a4636"); CR(g, 0, 44, CART_W, 2, "#3a2c1e");
      CR(g, 38, 34, 34, 12, "#7a5a4a"); CR(g, 46, 26, 18, 8, "#8a6a5a"); CR(g, 52, 20, 6, 6, "#9a7a6a");
      legAt(g, "m65", 4, 22, 2);
      petAt(g, pet, 66, 24, 2);
      CO(g, 66, 12, 26, 10, "#3a3028", "#6a5c50"); CR(g, 70, 10, 16, 3, "#7a6c60");
      scintilla(g, 60, 8, "#fff2c0"); scintilla(g, 102, 16, "#fff2c0"); scintilla(g, 30, 16, "#ffd0a0");
    },
    // M66 L'Ultimo Round — Rocco Baldoria, ring, campana finale, folla in delirio.
    std_m66: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#2a2030"); CR(g, 0, 46, CART_W, 18, "#3a2a20");
      for (var i = 0; i < 8; i++) figura(g, 2 + i * 14, 8, 12, i % 2 ? "#4a3a5e" : "#5a4a6e");
      CR(g, 0, 40, CART_W, 6, "#8a6a4a"); CR(g, 0, 38, CART_W, 2, "#6a4a2a");
      CR(g, 0, 24, CART_W, 1, "#e03040"); CR(g, 0, 31, CART_W, 1, "#e03040");
      CR(g, 2, 24, 2, 16, "#c8c8d0"); CR(g, 108, 24, 2, 16, "#c8c8d0");
      CO(g, 50, 3, 12, 9, "#8a6a20", "#e0c040"); CR(g, 54, 12, 4, 2, "#8a6a20"); scintilla(g, 56, 2, "#fff0a0");
      legAt(g, "m66", 18, 22, 2);
      petAt(g, pet, 60, 22, 2);
      scintilla(g, 46, 18, "#ff8080"); scintilla(g, 92, 20, "#ff8080");
    },
    // M67 L'Esorcismo del Grattacielo — Padre Maronno, attico, demone enorme, pet serve il te'.
    std_m67: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#241830"); CR(g, 0, 46, CART_W, 18, "#3a2a3e"); CR(g, 0, 44, CART_W, 2, "#1e1428");
      [[6, 6], [92, 10], [24, 4]].forEach(function (f) { CR(g, f[0], f[1], 10, 12, "#6a2ab0"); CR(g, f[0] + 2, f[1] + 2, 6, 8, "#a04ae0"); });
      CR(g, 80, 12, 28, 34, "#3a1a2a"); CR(g, 84, 8, 4, 6, "#3a1a2a"); CR(g, 100, 8, 4, 6, "#3a1a2a");
      CR(g, 86, 18, 5, 5, "#e83a3a"); CR(g, 98, 18, 5, 5, "#e83a3a");
      legAt(g, "m67", 2, 24, 2);
      petAt(g, pet, 44, 24, 2);
      CO(g, 62, 40, 8, 5, "#d8cfc0", "#f4efe4"); CR(g, 70, 41, 3, 2, "#cfc7b8"); scintilla(g, 64, 36, "#d0f0ff");
    },
    // M68 La Corsa Infinita — Forrest Gampo, statale al tramonto, pet in testa al gruppo.
    std_m68: function (g, pet) {
      CR(g, 0, 0, CART_W, 40, "#f0a85a"); CR(g, 0, 0, CART_W, 12, "#e87a4a"); CR(g, 86, 6, 8, 8, "#ffe6a0");
      CR(g, 0, 40, CART_W, 24, "#4a4450"); CR(g, 0, 40, CART_W, 2, "#5a5460");
      for (var i = 0; i < 7; i++) CR(g, 8 + i * 16, 54, 8, 2, "#e8d060");
      figura(g, 18, 30, 12, "#5a3a2a"); figura(g, 28, 31, 11, "#3a4a5a");
      legAt(g, "m68", 10, 26, 2);
      petAt(g, pet, 62, 26, 2);
      scintilla(g, 50, 14, "#fff2c0"); scintilla(g, 100, 20, "#ffd0a0");
    },
    // M69 La Foto del Secolo — Fabrice, suite reale, pet appeso al lampadario, flash.
    std_m69: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#3a2a4a"); CR(g, 0, 46, CART_W, 18, "#2a1e34"); CR(g, 0, 0, CART_W, 6, "#5a4a6a");
      CR(g, 52, 0, 8, 4, "#c8a838"); CO(g, 47, 4, 18, 8, "#8a6a20", "#f0d040"); [50, 54, 58].forEach(function (x) { CR(g, x, 12, 2, 4, "#fff0a0"); });
      legAt(g, "m69", 4, 24, 2);
      petAt(g, pet, 44, 14, 2);
      CO(g, 46, 12, 8, 5, "#20242c", "#5a5d66");
      scintilla(g, 38, 12, "#ffffff"); scintilla(g, 72, 14, "#ffffff"); scintilla(g, 90, 22, "#fff0c0"); scintilla(g, 30, 22, "#ffffff");
    },
    // M70 Oltre il Novemila — Veggeta frantuma il visore, pet in posa da combattimento, aura dorata.
    std_m70: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#2a1a1a"); CR(g, 0, 46, CART_W, 18, "#3a2a20"); CR(g, 10, 42, 92, 6, "#4a3020"); CR(g, 20, 46, 72, 8, "#3a2418");
      CR(g, 64, 22, 28, 24, "#b8860b"); CR(g, 68, 16, 20, 32, "#f0c040"); CR(g, 73, 12, 10, 40, "#f8e070"); // aura a colonna sfumata dietro il pet
      legAt(g, "m70", 8, 24, 2);
      CR(g, 22, 20, 5, 4, "#50d678"); CR(g, 20, 17, 2, 2, "#a0f0b0"); CR(g, 28, 15, 2, 2, "#50d678"); // pezzi del visore
      petAt(g, pet, 62, 24, 2);
      scintilla(g, 60, 18, "#fff2a0"); scintilla(g, 96, 20, "#fff2a0"); scintilla(g, 78, 8, "#ffd040"); scintilla(g, 90, 40, "#ffd040");
    },
    // M71 Il Teorema di Tutto — Sceldon, lavagna completata, gessetto a mezz'aria, divano.
    std_m71: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#2a2a34"); CR(g, 0, 46, CART_W, 18, "#3a3226"); CR(g, 0, 44, CART_W, 2, "#241f16");
      CO(g, 6, 6, 60, 32, "#3a2a1a", "#1e3a2e"); [12, 20, 28].forEach(function (y) { CR(g, 10, y, 40, 1, "#a0d0b0"); });
      CR(g, 12, 15, 8, 1, "#fff0c0"); CR(g, 26, 23, 12, 1, "#fff0c0");
      CO(g, 82, 30, 26, 14, "#5a3020", "#8a4a30"); CR(g, 82, 28, 26, 3, "#9a5a3a");
      legAt(g, "m71", 68, 24, 2);
      petAt(g, pet, 36, 24, 2);
      CR(g, 58, 30, 2, 3, "#f4f4f0"); scintilla(g, 56, 26, "#d0ffe0");
    },
    // M72 L'Armatura di Latta — Tonino Stark, tetto al tramonto, armatura che si illumina.
    std_m72: function (g, pet) {
      CR(g, 0, 0, CART_W, 30, "#f09a5a"); CR(g, 0, 0, CART_W, 10, "#e8734a"); CR(g, 92, 4, 8, 8, "#ffe6a0");
      CR(g, 0, 30, CART_W, 16, "#3a3444"); for (var i = 0; i < 6; i++) CR(g, 4 + i * 20, 22, 12, 8, "#2a2434");
      CR(g, 0, 46, CART_W, 18, "#4a4450"); CR(g, 0, 44, CART_W, 2, "#5a5460");
      CO(g, 44, 20, 14, 26, "#8a2020", "#c83030"); CR(g, 47, 24, 8, 6, "#f0d040"); CR(g, 48, 30, 5, 5, "#78d7eb"); CR(g, 47, 14, 8, 6, "#c83030"); scintilla(g, 51, 10, "#a0f0ff");
      legAt(g, "m72", 2, 24, 2);
      petAt(g, pet, 78, 24, 2);
      scintilla(g, 66, 16, "#fff2c0"); scintilla(g, 104, 20, "#ffd0a0");
    },

    // ===== ADULTO M33-M64 (Onda 2, cartoline std a mano) =====
    // M33 Torneo Mondiale di Arti Marziali — ring illuminato, tabellone dei match.
    std_m33: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#1c1a2e"); CR(g, 0, 46, CART_W, 18, "#2a2438");
      CR(g, 32, 0, 48, 5, "#f0e070"); CR(g, 38, 5, 36, 3, "#c8b850");
      CO(g, 76, 8, 32, 15, "#101018", "#16324a"); CR(g, 80, 12, 24, 2, "#7fe0ff"); CR(g, 80, 16, 16, 2, "#7fe0ff");
      CR(g, 0, 42, CART_W, 4, "#6a5a4a"); CR(g, 0, 31, CART_W, 1, "#c02838"); CR(g, 0, 37, CART_W, 1, "#c02838");
      CR(g, 2, 31, 2, 11, "#c8c8d0"); CR(g, 108, 31, 2, 11, "#c8c8d0");
      for (var i = 0; i < 4; i++) figura(g, 6 + i * 16, 24, 8, "#2e2a44");
      petAt(g, pet, 44, 22, 2);
      scintilla(g, 40, 16, "#fff2c0"); scintilla(g, 72, 20, "#fff2c0");
    },
    // M34 Il Mostro del Lago Vaporoso — sagoma mostruosa tra i vapori, spruzzi.
    std_m34: function (g, pet) {
      CR(g, 0, 0, CART_W, 40, "#2a4a5a"); CR(g, 0, 40, CART_W, 24, "#1e3a4a"); CR(g, 0, 40, CART_W, 2, "#3a6a7a");
      for (var i = 0; i < 5; i++) CR(g, 8 + i * 22, 24 - ((i * 5) % 8), 10, 4, "#5a7a8a");
      CR(g, 80, 14, 28, 30, "#14282e"); CR(g, 84, 10, 5, 6, "#14282e"); CR(g, 99, 10, 5, 6, "#14282e");
      CR(g, 86, 22, 5, 4, "#e8d040"); CR(g, 98, 22, 5, 4, "#e8d040");
      petAt(g, pet, 28, 26, 2);
      scintilla(g, 60, 34, "#bfe8f0"); scintilla(g, 52, 40, "#bfe8f0"); scintilla(g, 70, 38, "#bfe8f0"); scintilla(g, 46, 30, "#dff4f8");
    },
    // M35 Sparring col Campione in Ritiro — pet al sacco, vecchio pugile a braccia conserte.
    std_m35: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#6a5240"); CR(g, 0, 4, CART_W, 2, "#4a3628"); CR(g, 0, 46, CART_W, 18, "#4a5a4e"); CR(g, 0, 44, CART_W, 2, "#3a4a3e");
      CR(g, 44, 0, 2, 8, "#3a2c1e"); CO(g, 40, 8, 10, 22, "#5a3020", "#8a4a30"); CR(g, 42, 12, 6, 2, "#6a3828");
      CR(g, 88, 22, 16, 24, "#7a6a5a"); CR(g, 92, 14, 8, 8, "#c8a888"); CR(g, 89, 30, 14, 3, "#5a4a3a");
      CR(g, 88, 29, 5, 5, "#c02828"); CR(g, 99, 29, 5, 5, "#c02828"); // guantoni rossi (braccia conserte)
      petAt(g, pet, 20, 26, 2);
      scintilla(g, 40, 34, "#fff2c0"); scintilla(g, 70, 20, "#fff2c0");
    },
    // M36 I Bulli del Racket — pet affronta teppisti tra le bancarelle, negozianti che sbirciano.
    std_m36: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#3a3448"); CR(g, 0, 46, CART_W, 18, "#4a4038");
      CO(g, 2, 18, 26, 8, "#6a2020", "#c85040"); CR(g, 2, 18, 26, 2, "#e87060");
      CO(g, 84, 18, 24, 8, "#204a6a", "#4080a0"); CR(g, 84, 18, 24, 2, "#60a0c0");
      figura(g, 74, 24, 20, "#1e1a28"); figura(g, 90, 26, 18, "#241f30");
      CR(g, 30, 22, 4, 4, "#c8a888"); CR(g, 96, 40, 4, 4, "#c8a888");
      petAt(g, pet, 34, 26, 2);
      scintilla(g, 62, 20, "#ff8080");
    },
    // M37 Maratona dei Cinque Distretti — pet stremato che taglia il traguardo, folla ai lati.
    std_m37: function (g, pet) {
      CR(g, 0, 0, CART_W, 40, "#a9d9f2"); CR(g, 0, 40, CART_W, 24, "#5a5460"); CR(g, 0, 40, CART_W, 2, "#6a6470");
      striscioneTraguardo(g, 0, 2, CART_W);
      figura(g, 8, 30, 12, "#3a5a6a"); figura(g, 96, 30, 12, "#6a4a5a"); figura(g, 104, 31, 11, "#4a5a6a");
      petAt(g, pet, 44, 26, 2);
      scintilla(g, 36, 34, "#fff2c0"); scintilla(g, 74, 34, "#fff2c0");
    },
    // M38 Olimpiadi di Quartiere — pet fra più prove, torcia olimpica accesa.
    std_m38: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#7fb5e8"); CR(g, 0, 46, CART_W, 18, "#c88a4a"); CR(g, 0, 44, CART_W, 2, "#a06a34"); CR(g, 0, 40, CART_W, 2, "#e8e0d0");
      CR(g, 96, 14, 4, 30, "#8a7050"); CR(g, 94, 6, 8, 8, "#f0a030"); CR(g, 96, 2, 4, 6, "#f8d040"); scintilla(g, 98, 1, "#fff0a0");
      CR(g, 10, 10, 6, 6, "#e83030"); CR(g, 18, 10, 6, 6, "#f0c040"); CR(g, 26, 10, 6, 6, "#30a030");
      petAt(g, pet, 44, 26, 2);
      scintilla(g, 70, 20, "#fff2c0");
    },
    // M39 Half-Pipe Contest — pet a mezz'aria sopra la rampa, skater che guardano.
    std_m39: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#2a5a7a"); CR(g, 0, 46, CART_W, 18, "#3a3a44");
      CR(g, 0, 40, 24, 24, "#6a6470"); CR(g, 88, 40, 24, 24, "#6a6470"); CR(g, 0, 38, 24, 2, "#8a8490"); CR(g, 88, 38, 24, 2, "#8a8490"); CR(g, 24, 52, 64, 12, "#4a4450");
      figura(g, 4, 30, 10, "#2e2a3a"); figura(g, 100, 30, 10, "#2e2a3a");
      petAt(g, pet, 44, 12, 2); CR(g, 46, 44, 20, 2, "#e08030");
      scintilla(g, 40, 8, "#c0f0ff"); scintilla(g, 74, 10, "#c0f0ff");
    },
    // M40 Speedrun World Record — cuffie+controller, cronometro che scorre, chat che scrolla.
    std_m40: function (g, pet) {
      sfondoSalaGiochi(g);
      CO(g, 40, 4, 32, 10, "#101018", "#0a2a1a"); CR(g, 44, 7, 24, 4, "#40f080");
      CR(g, 92, 16, 18, 30, "#12101a"); for (var i = 0; i < 6; i++) CR(g, 94, 18 + i * 4, 12, 2, i % 2 ? "#4a90c0" : "#5aa050");
      petAt(g, pet, 32, 26, 2);
      CO(g, 28, 48, 22, 6, "#2a2e34", "#6a6f78"); CR(g, 31, 50, 4, 2, "#c83030"); CR(g, 43, 50, 4, 2, "#40c0e0");
      scintilla(g, 40, 20, "#40f080");
    },
    // M41 La Notte del Cabinato Maledetto — pet illuminato dallo schermo di un cabinato inquietante, arcade buio.
    std_m41: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#0e0c16"); CR(g, 0, 46, CART_W, 18, "#161320");
      CO(g, 40, 6, 32, 40, "#060410", "#1a1226"); CR(g, 45, 10, 22, 16, "#7a1030"); CR(g, 48, 13, 16, 3, "#e83050"); CR(g, 48, 19, 10, 2, "#a01838"); CR(g, 50, 31, 12, 3, "#2a1020");
      petAt(g, pet, 40, 24, 2);
      scintilla(g, 52, 8, "#e83050"); scintilla(g, 30, 30, "#5a1030"); scintilla(g, 84, 24, "#5a1030");
    },
    // M42 Scavo Archeologico Proibito — pet con torcia tra rovine sotterranee, vaso antico in primo piano.
    std_m42: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#2a2018"); CR(g, 0, 46, CART_W, 18, "#3a2c1e");
      CR(g, 0, 0, CART_W, 6, "#1a140e"); for (var i = 0; i < 7; i++) CR(g, 4 + i * 16, 8, 12, 6, "#4a3a2a");
      CO(g, 8, 34, 14, 16, "#6a4a2a", "#a07840"); CR(g, 11, 32, 8, 3, "#8a6030"); CR(g, 10, 40, 10, 2, "#c8a860");
      CR(g, 96, 20, 3, 4, "#f0a030"); scintilla(g, 97, 18, "#fff0a0");
      petAt(g, pet, 40, 26, 2);
      scintilla(g, 30, 24, "#f4e0a0"); scintilla(g, 72, 30, "#f4e0a0");
    },
    // M43 Il Razzo del Cortile — razzo artigianale che sputa fumo, vicini alle finestre.
    std_m43: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#243050"); CR(g, 0, 46, CART_W, 18, "#3a3428");
      CR(g, 80, 0, 32, 46, "#2a2636"); for (var i = 0; i < 3; i++) for (var j = 0; j < 2; j++) CR(g, 86 + j * 14, 8 + i * 12, 8, 6, "#f0c850");
      CR(g, 28, 12, 8, 30, "#c8c8d0"); CR(g, 29, 6, 6, 8, "#c83030"); CR(g, 26, 30, 3, 8, "#8a8a92"); CR(g, 36, 30, 3, 8, "#8a8a92");
      CR(g, 28, 44, 8, 4, "#8a8a92"); scintilla(g, 30, 50, "#c0c0c8"); scintilla(g, 32, 4, "#fff0a0");
      petAt(g, pet, 48, 26, 2);
    },
    // M44 Il Caso dei Gatti Scomparsi — pet detective con lente, gatti che tornano a casa.
    std_m44: function (g, pet) {
      sfondoVicolo(g);
      CR(g, 10, 50, 8, 5, "#3a3a44"); CR(g, 8, 48, 3, 3, "#3a3a44"); CR(g, 11, 51, 2, 1, "#f0d040");
      CR(g, 92, 51, 8, 5, "#4a3a3a"); CR(g, 98, 49, 3, 3, "#4a3a3a"); CR(g, 96, 52, 2, 1, "#f0d040");
      petAt(g, pet, 44, 26, 2);
      CO(g, 26, 30, 9, 9, "#8a8a90", "#bfe8f0"); CR(g, 34, 38, 4, 4, "#5a5a60");
      scintilla(g, 30, 28, "#dff4f8");
    },
    // M45 La Laurea — pet con toga e tocco tra i banchi dell'aula magna, commissione solenne.
    std_m45: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#3a2a3a"); CR(g, 0, 46, CART_W, 18, "#4a3a2a"); CR(g, 0, 0, CART_W, 8, "#2a1e2a");
      CR(g, 0, 38, CART_W, 8, "#5a3a2a"); CR(g, 0, 36, CART_W, 2, "#6a4a3a");
      figura(g, 8, 26, 12, "#2a2436"); figura(g, 96, 26, 12, "#2a2436"); figura(g, 104, 27, 11, "#2a2436");
      petAt(g, pet, 44, 24, 2);
      CR(g, 46, 18, 20, 3, "#1a1620"); CR(g, 54, 15, 4, 4, "#1a1620"); CR(g, 62, 18, 3, 8, "#f0d040");
      scintilla(g, 40, 22, "#fff2c0"); scintilla(g, 72, 24, "#fff2c0");
    },
    // M46 Ambasciatore delle Due Razze — pet fra delegazioni robot (grigie) e aliene (verdi), stretta di mano.
    std_m46: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#2a3a4a"); CR(g, 0, 46, CART_W, 18, "#3a4048"); CR(g, 0, 0, CART_W, 6, "#1e2a34"); CR(g, 50, 6, 12, 40, "#3a4a5a");
      figura(g, 6, 26, 18, "#6a7a8a"); figura(g, 20, 28, 16, "#5a6a7a");
      figura(g, 90, 26, 18, "#5a8a5a"); figura(g, 102, 28, 16, "#4a7a4a");
      petAt(g, pet, 44, 26, 2);
      CR(g, 34, 20, 6, 4, "#4a90c0"); CR(g, 72, 20, 6, 4, "#5aa050");
      scintilla(g, 56, 18, "#fff2c0");
    },
    // M47 Ospite al Talk Show — pet sul divano sotto le luci, conduttore che ride.
    std_m47: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#2a1e3a"); CR(g, 0, 46, CART_W, 18, "#3a2e2a");
      CR(g, 8, 0, 6, 8, "#f0e070"); CR(g, 98, 0, 6, 8, "#f0e070"); scintilla(g, 10, 10, "#fff0a0"); scintilla(g, 100, 10, "#fff0a0");
      CO(g, 28, 38, 54, 10, "#5a2030", "#a03848"); CR(g, 28, 36, 54, 3, "#c04858");
      figura(g, 92, 24, 20, "#3a3a4a");
      petAt(g, pet, 40, 24, 2);
      scintilla(g, 60, 16, "#ffd0e0");
    },
    // M48 Elezioni di Quartiere — pet sul palco con la fascia da sindaco, folla di sostenitori.
    std_m48: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#5a80a8"); CR(g, 0, 46, CART_W, 18, "#4a4438");
      CR(g, 8, 4, 20, 5, "#c83040"); CR(g, 40, 4, 20, 5, "#3060c0"); CR(g, 72, 4, 20, 5, "#c83040");
      CR(g, 34, 40, 44, 8, "#6a4a2a"); CR(g, 34, 38, 44, 2, "#8a5f38");
      for (var i = 0; i < 8; i++) figura(g, 2 + i * 14, 36, 8, i % 2 ? "#3a4a5e" : "#4a3a5e");
      petAt(g, pet, 44, 20, 2);
      CR(g, 48, 30, 14, 3, "#c02840"); CR(g, 56, 26, 4, 2, "#f0d040");
      scintilla(g, 40, 16, "#fff2c0"); scintilla(g, 74, 18, "#fff2c0");
    },
    // M49 Headliner al Festival Rock — pet che suona su un palco enorme, mare di spettatori con luci alzate.
    std_m49: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#1a1030"); CR(g, 0, 46, CART_W, 18, "#241540");
      CR(g, 0, 40, CART_W, 6, "#3a2a1a"); CR(g, 0, 38, CART_W, 2, "#5a4a2a");
      CR(g, 6, 0, 4, 14, "#3a3a4a"); CR(g, 102, 0, 4, 14, "#3a3a4a"); CR(g, 4, 2, 8, 4, "#e85ad8"); CR(g, 100, 2, 8, 4, "#3fd8ea");
      for (var i = 0; i < 10; i++) { figura(g, 2 + i * 11, 48, 10, "#1a1a26"); CR(g, 5 + i * 11, 44, 1, 4, "#f0e070"); }
      petAt(g, pet, 42, 22, 2);
      CR(g, 66, 30, 10, 4, "#c83030"); CR(g, 74, 28, 8, 2, "#8a2020");
      scintilla(g, 30, 12, "#e85ad8"); scintilla(g, 80, 14, "#3fd8ea"); scintilla(g, 56, 8, "#f0e070");
    },
    // M50 La Cucina dello Chef Urlante — pet in cucina tra fiamme e pentole, chef enorme che urla.
    std_m50: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#3a2a2a"); CR(g, 0, 46, CART_W, 18, "#4a4038");
      CR(g, 0, 0, CART_W, 20, "#4a3a3a"); for (var i = 0; i < 8; i++) CR(g, i * 14, 0, 1, 20, "#3a2a2a");
      CR(g, 8, 36, 20, 8, "#2a2426"); CR(g, 12, 32, 4, 4, "#f06020"); CR(g, 20, 32, 4, 4, "#f0a020"); CR(g, 14, 30, 2, 3, "#f8e040");
      CO(g, 10, 40, 14, 4, "#2a2426", "#6a6a72");
      CR(g, 84, 8, 26, 38, "#6a5a4a"); CR(g, 90, 2, 14, 8, "#e8e0d0"); CR(g, 92, 12, 10, 6, "#c8a888"); CR(g, 95, 15, 4, 3, "#3a1a1a");
      petAt(g, pet, 40, 26, 2);
      scintilla(g, 18, 28, "#f8c040"); scintilla(g, 60, 20, "#fff0c0");
    },
    // M51 La Villa Infestata — pet al tavolo con tre fantasmi lenzuolati che firmano un regolamento.
    std_m51: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#1e2430"); CR(g, 0, 46, CART_W, 18, "#2a2a34");
      CR(g, 14, 42, 86, 6, "#4a3020"); CR(g, 14, 40, 86, 2, "#6a4530");
      [52, 70, 88].forEach(function (fx) { CR(g, fx, 22, 12, 18, "#e8ecf0"); CR(g, fx + 2, 40, 2, 3, "#e8ecf0"); CR(g, fx + 6, 40, 2, 3, "#e8ecf0"); CR(g, fx + 3, 27, 2, 3, "#3a4048"); CR(g, fx + 7, 27, 2, 3, "#3a4048"); });
      CR(g, 60, 38, 8, 4, "#f4f0e0");
      petAt(g, pet, 18, 24, 2);
      scintilla(g, 46, 16, "#bfe8f0"); scintilla(g, 100, 18, "#bfe8f0");
    },
    // M52 Rapina al Treno Blindato — pet che corre sul tetto di un treno in corsa al tramonto.
    std_m52: function (g, pet) {
      CR(g, 0, 0, CART_W, 30, "#e88a4a"); CR(g, 0, 0, CART_W, 10, "#e05a3a"); CR(g, 88, 4, 8, 8, "#ffe0a0");
      CR(g, 0, 30, CART_W, 8, "#2a3040");
      CR(g, 0, 44, CART_W, 20, "#3a4048"); CR(g, 0, 42, CART_W, 3, "#5a6068");
      for (var i = 0; i < 7; i++) CR(g, 6 + i * 16, 50, 10, 8, "#2a3038");
      CR(g, 8, 60, 12, 4, "#1a1a20"); CR(g, 90, 60, 12, 4, "#1a1a20");
      petAt(g, pet, 44, 12, 2);
      CR(g, 20, 24, 10, 1, "#ffd0a0"); CR(g, 78, 28, 10, 1, "#ffd0a0");
      scintilla(g, 30, 14, "#fff2c0");
    },
    // M53 Demolizione Controllata — pet che abbatte un muro con una mazza enorme, polvere ovunque.
    std_m53: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#8a9aa8"); CR(g, 0, 46, CART_W, 18, "#5a5040");
      CR(g, 70, 6, 38, 40, "#6a5a4a"); for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) CR(g, 76 + j * 10, 12 + i * 12, 6, 8, "#3a3228");
      CR(g, 82, 6, 2, 30, "#3a3228"); CR(g, 94, 10, 2, 24, "#3a3228");
      CR(g, 60, 40, 16, 6, "#c8c0b0"); scintilla(g, 66, 36, "#e0d8c8"); scintilla(g, 76, 42, "#e0d8c8");
      petAt(g, pet, 30, 26, 2);
      CR(g, 50, 14, 6, 6, "#4a4a52"); CR(g, 52, 20, 2, 12, "#6a4a2a");
      scintilla(g, 54, 12, "#fff0c0");
    },
    // M54 I Gemelli Terribili — pet stremato tra due cuccioli scatenati che finalmente dormono.
    std_m54: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#3a3a5a"); CR(g, 0, 46, CART_W, 18, "#4a4038");
      CR(g, 74, 4, 34, 20, "#2a2a44"); CR(g, 78, 8, 26, 12, "#5a80a8");
      CO(g, 6, 40, 20, 8, "#5a3a2a", "#8a6a4a"); CR(g, 10, 38, 12, 3, "#c8b0a0"); CR(g, 13, 40, 3, 2, "#3a3040");
      CO(g, 86, 40, 20, 8, "#5a3a2a", "#8a6a4a"); CR(g, 90, 38, 12, 3, "#c8b0a0");
      petAt(g, pet, 44, 26, 2);
      scintilla(g, 20, 34, "#c0c0f0"); scintilla(g, 96, 34, "#c0c0f0");
    },
    // M55 Consegna Orbitale — pet in tuta spaziale che consegna un pacco a una stazione, Terra sullo sfondo.
    std_m55: function (g, pet) {
      CR(g, 0, 0, CART_W, 64, "#080614");
      for (var i = 0; i < 16; i++) CR(g, (i * 29 + 5) % CART_W, (i * 17 + 3) % 60, 1, 1, "#f0f0ff");
      CR(g, 82, 40, 30, 24, "#2a5a9a"); CR(g, 86, 44, 20, 12, "#3a8a5a"); CR(g, 82, 40, 30, 2, "#5a9aca");
      CO(g, 6, 10, 30, 16, "#5a5a68", "#8a8a98"); CR(g, 10, 14, 6, 8, "#3fd8ea"); CR(g, 20, 14, 6, 8, "#3fd8ea"); CR(g, 36, 16, 8, 3, "#6a6a78");
      petAt(g, pet, 42, 22, 2);
      CO(g, 36, 30, 8, 8, "#6a4a2a", "#a07840");
      scintilla(g, 34, 16, "#fff2c0"); scintilla(g, 70, 12, "#c0f0ff");
    },
    // M56 Il Pacco Maledetto — pet che consegna un pacco pulsante a una porta buia.
    std_m56: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#141018"); CR(g, 0, 46, CART_W, 18, "#1e1824");
      CO(g, 78, 8, 28, 46, "#0a0810", "#241a2a"); CR(g, 82, 12, 20, 30, "#160f1e"); CR(g, 96, 28, 3, 3, "#8a6a2a");
      petAt(g, pet, 36, 26, 2);
      CO(g, 30, 40, 12, 10, "#3a1a3a", "#6a2a6a"); CR(g, 33, 43, 6, 4, "#c040c0");
      scintilla(g, 36, 36, "#e060e0"); scintilla(g, 44, 44, "#e060e0"); scintilla(g, 26, 42, "#a040a0");
    },
    // M57 Sagra del Peperoncino Esplosivo — pet paonazzo che addenta un peperoncino gigante, pubblico che soffia il fumo.
    std_m57: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#d85a3a"); CR(g, 0, 0, CART_W, 14, "#c84428"); CR(g, 0, 46, CART_W, 18, "#7a4030");
      CR(g, 8, 4, 20, 4, "#f0c040"); CR(g, 60, 4, 20, 4, "#f0c040");
      figura(g, 8, 30, 12, "#6a3a2a"); figura(g, 96, 30, 12, "#6a3a2a"); figura(g, 104, 31, 11, "#5a3020");
      CR(g, 40, 12, 6, 4, "#c8c0b0"); CR(g, 48, 8, 6, 4, "#d8d0c0"); scintilla(g, 44, 6, "#e8e0d0");
      petAt(g, pet, 40, 24, 2);
      CR(g, 62, 30, 6, 14, "#d02020"); CR(g, 64, 26, 3, 5, "#3a8a3a");
      scintilla(g, 30, 20, "#fff0a0");
    },
    // M58 Il Fantasma del Teatro dell'Opera — pet che canta su un palco d'opera, fantasma che osserva dal loggione.
    std_m58: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#2a1424"); CR(g, 0, 46, CART_W, 18, "#3a2018");
      CR(g, 0, 0, 14, 46, "#7a1420"); CR(g, 98, 0, 14, 46, "#7a1420"); CR(g, 0, 0, CART_W, 6, "#5a1018");
      CO(g, 82, 8, 22, 14, "#3a1a2a", "#241420"); CR(g, 88, 12, 10, 8, "#e8ecf0"); CR(g, 90, 14, 2, 2, "#3a4048"); CR(g, 94, 14, 2, 2, "#3a4048");
      petAt(g, pet, 40, 26, 2);
      CR(g, 30, 20, 2, 6, "#f0e0a0"); CR(g, 28, 25, 4, 2, "#f0e0a0"); CR(g, 66, 16, 2, 6, "#f0e0a0"); CR(g, 64, 21, 4, 2, "#f0e0a0");
      scintilla(g, 56, 14, "#ffd0e0");
    },
    // M59 Tour de Pizza — pet in motorino carico di pizze che sfreccia per la citta' al tramonto.
    std_m59: function (g, pet) {
      CR(g, 0, 0, CART_W, 40, "#f0a05a"); CR(g, 0, 0, CART_W, 12, "#e8703a"); CR(g, 88, 4, 8, 8, "#ffe0a0");
      CR(g, 0, 40, CART_W, 24, "#4a4450"); CR(g, 0, 40, CART_W, 2, "#5a5460");
      for (var i = 0; i < 5; i++) CR(g, 2 + i * 24, 24, 16, 16, "#c86040");
      petAt(g, pet, 40, 20, 2);
      CR(g, 36, 44, 30, 8, "#c83030"); CR(g, 40, 52, 6, 6, "#1a1a20"); CR(g, 60, 52, 6, 6, "#1a1a20");
      CO(g, 60, 34, 10, 4, "#8a5a2a", "#d8a030"); CO(g, 60, 30, 10, 4, "#8a5a2a", "#d8a030");
      scintilla(g, 30, 14, "#fff2c0"); scintilla(g, 78, 18, "#ffd0a0");
    },
    // M60 Allerta Meteorite — pet all'osservatorio fra calcoli, meteorite in avvicinamento nel cielo.
    std_m60: function (g, pet) {
      CR(g, 0, 0, CART_W, 30, "#0e1428"); CR(g, 0, 30, CART_W, 34, "#2a2438");
      for (var i = 0; i < 12; i++) CR(g, (i * 23 + 4) % CART_W, (i * 11 + 2) % 26, 1, 1, "#e0e8ff");
      CR(g, 80, 6, 8, 6, "#f0a040"); CR(g, 88, 4, 6, 4, "#f8d060"); CR(g, 70, 10, 8, 2, "#e07030");
      CO(g, 4, 30, 20, 14, "#3a3448", "#4a4460"); CR(g, 6, 20, 16, 12, "#2a2840"); CR(g, 8, 22, 12, 2, "#a0c0e0");
      CO(g, 82, 34, 24, 12, "#1a2a1a", "#0e2a1a"); CR(g, 85, 37, 18, 1, "#80c080"); CR(g, 85, 41, 12, 1, "#80c080");
      petAt(g, pet, 42, 26, 2);
      scintilla(g, 84, 4, "#fff0c0");
    },
    // M61 Caccia al Tesoro Cittadina — pet che corre con una mappa fra i vicoli, concorrenti alle spalle.
    std_m61: function (g, pet) {
      sfondoVicolo(g);
      figura(g, 6, 30, 16, "#2e2a3a"); figura(g, 18, 32, 14, "#3a2a3a");
      petAt(g, pet, 44, 26, 2);
      CR(g, 62, 30, 12, 9, "#e8dcb8"); CR(g, 64, 32, 8, 1, "#8a6a3a"); CR(g, 66, 35, 5, 1, "#8a6a3a"); CR(g, 70, 34, 2, 2, "#c02020");
      scintilla(g, 58, 24, "#fff2c0");
    },
    // M62 La Colonia in Cantina — pet con lente e taccuino che studia minuscole creaturine tra i rottami.
    std_m62: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#241f28"); CR(g, 0, 46, CART_W, 18, "#2e2820");
      CR(g, 6, 8, 20, 38, "#3a3228"); CR(g, 84, 6, 24, 40, "#332c22"); for (var i = 0; i < 3; i++) CR(g, 86, 12 + i * 12, 20, 2, "#4a4030");
      [[30, 44], [38, 46], [70, 45], [62, 43]].forEach(function (p) { CR(g, p[0], p[1], 4, 3, "#6a8a4a"); CR(g, p[0] + 1, p[1] + 1, 1, 1, "#f0d040"); });
      petAt(g, pet, 40, 24, 2);
      CO(g, 28, 30, 8, 8, "#8a8a90", "#bfe8f0");
      scintilla(g, 34, 28, "#dff4f8");
    },
    // M63 Il Grande Blackout — pet che gira la manovella di un generatore, quartiere buio sullo sfondo.
    std_m63: function (g, pet) {
      CR(g, 0, 0, CART_W, 46, "#0e0e1a"); CR(g, 0, 46, CART_W, 18, "#1a1a26");
      CR(g, 4, 10, 24, 36, "#161624"); CR(g, 84, 8, 26, 38, "#161624"); CR(g, 12, 16, 4, 4, "#3a3a4a"); CR(g, 92, 20, 4, 4, "#3a3a4a");
      CO(g, 62, 34, 20, 12, "#2a2a30", "#4a4a54"); CR(g, 80, 36, 6, 2, "#6a6a72"); CR(g, 84, 34, 2, 8, "#8a8a92");
      CR(g, 66, 36, 8, 3, "#f0e040"); scintilla(g, 70, 32, "#fff0a0");
      petAt(g, pet, 36, 26, 2);
      scintilla(g, 20, 20, "#3a3a5a");
    },
    // M64 Regata dei Rottami — pet al timone di una barca di rottami con vela rattoppata, barche ridicole intorno.
    std_m64: function (g, pet) {
      CR(g, 0, 0, CART_W, 32, "#a9d9f2"); CR(g, 0, 32, CART_W, 32, "#2a6a9a"); CR(g, 0, 32, CART_W, 2, "#4a8aba"); CR(g, 88, 6, 8, 8, "#f8e05a");
      CR(g, 4, 34, 16, 6, "#6a4a3a"); CR(g, 10, 28, 2, 8, "#8a6a4a"); CR(g, 96, 36, 14, 6, "#5a4a6a"); CR(g, 100, 30, 2, 8, "#7a6a8a");
      CR(g, 34, 40, 44, 10, "#7a5a3a"); CR(g, 34, 38, 44, 2, "#9a7a5a");
      CR(g, 54, 16, 2, 24, "#5a4030"); CR(g, 44, 18, 20, 16, "#d8c8a8"); CR(g, 50, 22, 8, 6, "#b8a888");
      petAt(g, pet, 42, 22, 2);
      scintilla(g, 30, 40, "#c0f0ff"); scintilla(g, 80, 42, "#c0f0ff");
    },

    // ===== Missioni m73-m98 (fix "cartoline mancanti", 16 lug 2026): una scena std per missione,
    // disegnata a mano dalla descrizione "Scena:" della scheda standard (il super = std + trofeo,
    // v. trofeoSuper). Stesse regole compositive delle m9-m64: cielo 0-44, orizzonte 44-46,
    // terra 46-64, pet protagonista ~x36-46 scala 2, figure di contorno, scintille mirate. =====
    // m73 Tiro alla Fune dei Cuccioli — parco, due squadre alla corda, fango che schizza.
    std_m73: function (g, pet) { CR(g, 0, 0, CART_W, 44, "#a9d9f2"); CR(g, 90, 5, 8, 8, "#f8e05a"); CR(g, 0, 44, CART_W, 20, "#4a8a3c"); CR(g, 0, 44, CART_W, 2, "#356a2c"); CR(g, 40, 52, 34, 8, "#6a4a2a"); CR(g, 44, 50, 8, 3, "#7a5a36"); CR(g, 60, 56, 9, 3, "#7a5a36"); CR(g, 6, 36, 100, 2, "#b8905a"); CR(g, 30, 35, 3, 4, "#8a6a3c"); CR(g, 78, 35, 3, 4, "#8a6a3c"); figura(g, 10, 30, 13, "#c47a4a"); figura(g, 20, 32, 11, "#8a6aa0"); figura(g, 92, 30, 13, "#4a7ab0"); figura(g, 102, 32, 11, "#b0a04a"); petAt(g, pet, 42, 24, 2); scintilla(g, 56, 46, "#8a6a3c"); scintilla(g, 26, 48, "#8a6a3c"); scintilla(g, 84, 24, "#fff2b0"); },
    // m74 Il Trasloco dei Giocattoli — interno caldo, pet sotto uno scatolone piu' grande di lui.
    std_m74: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#d8c0a0"); CR(g, 0, 46, CART_W, 18, "#8a6a4a"); CR(g, 0, 44, CART_W, 2, "#6a4e34"); CR(g, 88, 8, 20, 38, "#b89878"); CR(g, 90, 10, 16, 34, "#7a5a3c"); CR(g, 8, 10, 22, 16, "#a9d9f2"); CO(g, 8, 10, 22, 16, "#8a6a4a", "#a9d9f2"); petAt(g, pet, 40, 28, 2); CO(g, 32, 8, 34, 24, "#8a6428", "#d8a85c"); CR(g, 32, 8, 34, 4, "#b8863c"); CR(g, 30, 6, 12, 5, "#c8964c"); CR(g, 58, 6, 12, 5, "#c8964c"); CR(g, 40, 2, 6, 6, "#e05050"); CR(g, 52, 3, 6, 5, "#4a7ab0"); CR(g, 47, 0, 4, 5, "#5ce87f"); scintilla(g, 70, 14, "#fff2b0"); CR(g, 12, 52, 8, 6, "#c04030"); CR(g, 24, 54, 6, 5, "#4a7ab0"); },
    // m75 Acchiapparella Reale — parco, pet che scarta con una finta, inseguitori sparsi.
    std_m75: function (g, pet) { CR(g, 0, 0, CART_W, 44, "#bfe3f7"); CR(g, 96, 4, 8, 8, "#f8e05a"); CR(g, 0, 44, CART_W, 20, "#54964a"); CR(g, 0, 44, CART_W, 2, "#3d7236"); CR(g, 8, 14, 16, 30, "#3a6a34"); CR(g, 12, 30, 4, 14, "#6a4a2a"); CR(g, 4, 10, 24, 14, "#4a8a3c"); figura(g, 78, 28, 14, "#c47a4a"); figura(g, 94, 32, 12, "#8a6aa0"); figura(g, 66, 34, 11, "#b0a04a"); petAt(g, pet, 34, 24, 2); scintilla(g, 56, 34, "#ffffff"); scintilla(g, 60, 28, "#ffffff"); scintilla(g, 52, 40, "#dff4ff"); CR(g, 40, 55, 26, 3, "#e8d8b0"); },
    // m76 Il Piccolo Postino — scale del condominio, buste tra i denti, cassette postali.
    std_m76: function (g, pet) { CR(g, 0, 0, CART_W, 64, "#c8b8a8"); CR(g, 0, 0, CART_W, 6, "#a89888"); CR(g, 4, 10, 26, 30, "#8a8a94"); CR(g, 6, 12, 10, 8, "#6a6a74"); CR(g, 18, 12, 10, 8, "#6a6a74"); CR(g, 6, 22, 10, 8, "#6a6a74"); CR(g, 18, 22, 10, 8, "#6a6a74"); CR(g, 8, 14, 4, 1, "#e8e8e0"); CR(g, 20, 24, 4, 1, "#e8e8e0"); CR(g, 40, 52, 72, 12, "#a08870"); CR(g, 52, 44, 60, 10, "#b09880"); CR(g, 64, 36, 48, 10, "#a08870"); CR(g, 76, 28, 36, 10, "#b09880"); CR(g, 40, 50, 72, 2, "#7a6450"); CR(g, 52, 42, 60, 2, "#7a6450"); CR(g, 64, 34, 48, 2, "#7a6450"); CR(g, 76, 26, 36, 2, "#7a6450"); petAt(g, pet, 46, 18, 2); CR(g, 42, 30, 10, 7, "#f4f0e0"); CR(g, 44, 28, 10, 7, "#e8e0cc"); CR(g, 43, 33, 8, 1, "#c04030"); scintilla(g, 34, 12, "#fff2b0"); },
    // m77 Il Puzzle del Museo — pavimento del museo, puzzle gigante a meta', quadri alle pareti.
    std_m77: function (g, pet) { CR(g, 0, 0, CART_W, 40, "#6a5a7a"); CR(g, 0, 40, CART_W, 24, "#b8ac98"); CR(g, 0, 40, CART_W, 2, "#8a8070"); CO(g, 10, 8, 20, 16, "#c9a24a", "#3a6a9a"); CR(g, 14, 12, 8, 6, "#7ab0d8"); CO(g, 78, 8, 22, 16, "#c9a24a", "#8a3a4a"); CR(g, 82, 12, 10, 6, "#d87a6a"); petAt(g, pet, 34, 22, 2); CR(g, 44, 44, 8, 7, "#e05050"); CR(g, 52, 44, 8, 7, "#f0b040"); CR(g, 60, 44, 8, 7, "#4a7ab0"); CR(g, 44, 51, 8, 7, "#5ce87f"); CR(g, 60, 51, 8, 7, "#e05050"); CR(g, 68, 51, 8, 7, "#8a6aa0"); CR(g, 52, 58, 8, 6, "#f0b040"); CR(g, 68, 44, 8, 7, "#b8ac98"); CR(g, 52, 51, 8, 7, "#b8ac98"); CR(g, 84, 52, 7, 6, "#4a7ab0"); scintilla(g, 90, 46, "#fff2b0"); },
    // m78 L'Orto sul Balcone — ringhiera, tre vasi, annaffiatoio piu' grande del pet.
    std_m78: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#ffe2a8"); CR(g, 0, 0, CART_W, 12, "#ffd07a"); CR(g, 94, 4, 8, 8, "#ffca3a"); CR(g, 0, 46, CART_W, 18, "#9a8a78"); CR(g, 0, 44, CART_W, 2, "#7a6c5c"); CR(g, 0, 20, CART_W, 3, "#5a5a66"); CR(g, 6, 23, 3, 23, "#5a5a66"); CR(g, 26, 23, 3, 23, "#5a5a66"); CR(g, 86, 23, 3, 23, "#5a5a66"); CR(g, 104, 23, 3, 23, "#5a5a66"); CO(g, 62, 34, 12, 12, "#7a3c28", "#b85c3c"); CO(g, 78, 36, 10, 10, "#7a3c28", "#b85c3c"); CO(g, 94, 34, 12, 12, "#7a3c28", "#b85c3c"); CR(g, 66, 28, 3, 6, "#4a8a3c"); CR(g, 64, 26, 3, 4, "#5ca84a"); CR(g, 81, 32, 3, 4, "#4a8a3c"); CR(g, 98, 28, 3, 6, "#4a8a3c"); CR(g, 100, 25, 3, 4, "#5ca84a"); petAt(g, pet, 34, 26, 2); CO(g, 14, 34, 16, 12, "#3a5a6a", "#6a94a8"); CR(g, 28, 36, 8, 3, "#6a94a8"); CR(g, 35, 34, 3, 3, "#6a94a8"); scintilla(g, 42, 38, "#7fd8ff"); scintilla(g, 46, 44, "#7fd8ff"); scintilla(g, 60, 24, "#fff2b0"); },
    // m79 Il Teatrino dei Burattini — teatrino di cartone col drago, piccolo pubblico nel cortile.
    std_m79: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#8a7a68"); CR(g, 0, 0, CART_W, 8, "#6e6052"); CR(g, 0, 46, CART_W, 18, "#9a8a76"); CR(g, 0, 44, CART_W, 2, "#6e6052"); CO(g, 34, 8, 46, 32, "#6a4a2a", "#b8863c"); CR(g, 34, 8, 46, 6, "#c04030"); CR(g, 38, 14, 38, 3, "#e8c890"); CR(g, 42, 18, 30, 14, "#3a2818"); CR(g, 48, 20, 8, 6, "#4a9a4a"); CR(g, 56, 18, 6, 5, "#5cb85a"); CR(g, 58, 20, 2, 1, "#f4f0e0"); CR(g, 54, 26, 12, 2, "#3a7a3a"); scintilla(g, 66, 22, "#ffd23f"); petAt(g, pet, 84, 22, 2); figura(g, 14, 48, 10, "#c47a4a"); figura(g, 26, 50, 9, "#8a6aa0"); figura(g, 44, 49, 10, "#4a7ab0"); figura(g, 58, 51, 9, "#b0a04a"); scintilla(g, 20, 40, "#fff2b0"); },
    // m80 Il Banchetto della Limonata — banchetto con brocca e cartello, sole pieno.
    std_m80: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#ffe9b8"); CR(g, 0, 0, CART_W, 10, "#ffd98a"); CR(g, 10, 4, 9, 9, "#ffca3a"); CR(g, 0, 46, CART_W, 18, "#9a9aa2"); CR(g, 0, 44, CART_W, 2, "#7a7a84"); CR(g, 0, 52, CART_W, 1, "#c8c8d0"); petAt(g, pet, 40, 20, 2); CO(g, 26, 34, 58, 16, "#6a4a2a", "#b8863c"); CR(g, 26, 34, 58, 3, "#8a6438"); CR(g, 30, 50, 4, 10, "#6a4a2a"); CR(g, 76, 50, 4, 10, "#6a4a2a"); CO(g, 60, 22, 12, 12, "#8a7a1e", "#f5d020"); CR(g, 62, 20, 8, 2, "#e8e8e0"); CR(g, 72, 26, 3, 4, "#f5d020"); CO(g, 88, 24, 20, 20, "#6a4a2a", "#f4f0e0"); CR(g, 92, 28, 12, 3, "#f5d020"); CR(g, 92, 34, 10, 2, "#8a6438"); CR(g, 96, 44, 3, 12, "#6a4a2a"); scintilla(g, 54, 28, "#fff2b0"); scintilla(g, 80, 18, "#ffd23f"); },
    // m81 Braccio di Ferro del Porto — taverna buia, tavolo, scaricatore enorme, lanterne.
    std_m81: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#2a1e18"); CR(g, 0, 46, CART_W, 18, "#3a2c20"); CR(g, 0, 44, CART_W, 2, "#1c1410"); CO(g, 8, 6, 8, 10, "#5a4020", "#f0b840"); CR(g, 10, 3, 4, 3, "#5a4020"); CO(g, 96, 6, 8, 10, "#5a4020", "#f0b840"); CR(g, 98, 3, 4, 3, "#5a4020"); scintilla(g, 12, 18, "#ffd88a"); scintilla(g, 100, 18, "#ffd88a"); CR(g, 30, 36, 52, 6, "#6a4a2a"); CR(g, 30, 42, 52, 2, "#4a3018"); CR(g, 34, 44, 4, 12, "#4a3018"); CR(g, 74, 44, 4, 12, "#4a3018"); figura(g, 84, 14, 24, "#4a5a6a"); CR(g, 78, 20, 10, 6, "#4a5a6a"); CR(g, 80, 12, 8, 4, "#c8a070"); CR(g, 76, 26, 6, 10, "#c8a070"); petAt(g, pet, 34, 20, 2); CR(g, 52, 30, 6, 6, "#c8a070"); CR(g, 56, 28, 4, 4, "#c8a070"); CO(g, 18, 30, 7, 8, "#3a2210", "#8a5a2a"); CR(g, 20, 28, 3, 3, "#e8d8b0"); scintilla(g, 56, 22, "#ffd23f"); },
    // m82 Buttafuori per una Sera — terrazza notturna, lucine, corda rossa, fila che aspetta.
    std_m82: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#1a1830"); CR(g, 0, 46, CART_W, 18, "#2e2a3e"); CR(g, 0, 44, CART_W, 2, "#3e3a52"); CR(g, 6, 6, 2, 2, "#f0d060"); CR(g, 34, 4, 2, 2, "#f0d060"); CR(g, 74, 7, 2, 2, "#f0d060"); CR(g, 102, 5, 2, 2, "#f0d060"); CR(g, 0, 14, CART_W, 1, "#3e3a52"); CR(g, 10, 14, 2, 3, "#ff5050"); CR(g, 30, 14, 2, 3, "#50c8ff"); CR(g, 50, 14, 2, 3, "#f5d020"); CR(g, 70, 14, 2, 3, "#5ce87f"); CR(g, 90, 14, 2, 3, "#ff5050"); CR(g, 106, 14, 2, 3, "#50c8ff"); CR(g, 88, 20, 20, 26, "#3a3448"); CR(g, 88, 24, 20, 3, "#5a5470"); CR(g, 88, 32, 20, 3, "#5a5470"); CR(g, 88, 40, 20, 3, "#5a5470"); petAt(g, pet, 52, 24, 2); CR(g, 48, 36, 10, 7, "#f4f0e0"); CR(g, 50, 38, 6, 1, "#3a3a44"); CR(g, 50, 41, 5, 1, "#3a3a44"); CR(g, 14, 34, 3, 12, "#c8a020"); CR(g, 36, 34, 3, 12, "#c8a020"); CR(g, 15, 34, 23, 2, "#c02840"); figura(g, 18, 26, 15, "#4a3a5e"); figura(g, 30, 28, 13, "#3e4a66"); scintilla(g, 60, 16, "#fff0b0"); },
    // m83 Istruttore Supplente — palestra, pet col fischietto sul podio, allievi in affanno.
    std_m83: function (g, pet) { CR(g, 0, 0, CART_W, 44, "#d8d0c0"); CR(g, 0, 0, CART_W, 6, "#b8b0a0"); CR(g, 8, 8, 24, 10, "#a9d9f2"); CO(g, 8, 8, 24, 10, "#8a8278", "#a9d9f2"); CR(g, 0, 44, CART_W, 20, "#4a6a9a"); CR(g, 0, 44, CART_W, 2, "#3a5478"); petAt(g, pet, 34, 18, 2); CO(g, 30, 40, 22, 8, "#5a4a30", "#8a7a52"); CR(g, 47, 26, 4, 4, "#c8ccd0"); CR(g, 45, 24, 2, 6, "#8a8a92"); figura(g, 70, 34, 12, "#c47a4a"); figura(g, 84, 36, 11, "#8a6aa0"); figura(g, 98, 35, 12, "#b0a04a"); scintilla(g, 74, 26, "#7fd8ff"); scintilla(g, 88, 28, "#7fd8ff"); scintilla(g, 102, 27, "#7fd8ff"); CR(g, 62, 50, 14, 5, "#3a3a44"); CR(g, 92, 52, 12, 4, "#3a3a44"); scintilla(g, 40, 10, "#fff2b0"); },
    // m84 Il Furgone del Gelataio — salita, pet che spinge, cono sul tetto, tifo dal marciapiede.
    std_m84: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#ffd98a"); CR(g, 0, 0, CART_W, 10, "#f4a25a"); CR(g, 0, 46, CART_W, 18, "#8a8a94"); CR(g, 0, 44, CART_W, 2, "#6a6a74"); CR(g, 0, 50, 56, 14, "#7a7a84"); CR(g, 56, 46, 56, 4, "#7a7a84"); CO(g, 48, 14, 44, 26, "#8a5a5a", "#f4f0e0"); CR(g, 48, 26, 44, 6, "#e8607a"); CR(g, 82, 18, 8, 8, "#7ab0d8"); CR(g, 56, 40, 8, 8, "#2a2a32"); CR(g, 80, 40, 8, 8, "#2a2a32"); CR(g, 58, 42, 4, 4, "#8a8a92"); CR(g, 82, 42, 4, 4, "#8a8a92"); CR(g, 62, 6, 8, 8, "#e8c890"); CR(g, 63, 2, 6, 5, "#e86a8a"); CR(g, 64, 0, 4, 3, "#f4f0e0"); petAt(g, pet, 26, 26, 2); scintilla(g, 20, 22, "#7fd8ff"); figura(g, 6, 36, 10, "#c47a4a"); figura(g, 14, 38, 9, "#8a6aa0"); scintilla(g, 10, 28, "#fff2b0"); scintilla(g, 98, 12, "#fff2b0"); },
    // m85 Gran Premio dei Go-Kart — pista notturna del luna park, curva, ruota panoramica.
    std_m85: function (g, pet) { CR(g, 0, 0, CART_W, 40, "#1a1030"); CR(g, 0, 40, CART_W, 24, "#3a3a44"); CR(g, 0, 40, CART_W, 2, "#5a5a66"); CO(g, 78, 2, 26, 26, "#4a3a5e", "#1a1030"); CR(g, 88, 12, 6, 6, "#5a4a72"); CR(g, 82, 6, 3, 3, "#ff5050"); CR(g, 98, 6, 3, 3, "#50c8ff"); CR(g, 82, 20, 3, 3, "#f5d020"); CR(g, 98, 20, 3, 3, "#5ce87f"); CR(g, 90, 0, 3, 3, "#e85ad8"); CR(g, 90, 24, 3, 3, "#f0b040"); CR(g, 0, 40, 20, 3, "#e8e8e0"); CR(g, 20, 40, 20, 3, "#c02840"); CR(g, 40, 40, 20, 3, "#e8e8e0"); CR(g, 60, 40, 20, 3, "#c02840"); CR(g, 80, 40, 20, 3, "#e8e8e0"); CR(g, 100, 40, 12, 3, "#c02840"); petAt(g, pet, 36, 22, 2); CO(g, 30, 42, 26, 10, "#7a1420", "#e83028"); CR(g, 32, 50, 6, 6, "#16161c"); CR(g, 48, 50, 6, 6, "#16161c"); CR(g, 56, 44, 6, 4, "#f5d020"); CO(g, 84, 48, 18, 8, "#1e3a5c", "#3a6ab0"); CR(g, 86, 54, 5, 5, "#16161c"); CR(g, 96, 54, 5, 5, "#16161c"); scintilla(g, 24, 48, "#ffffff"); scintilla(g, 18, 54, "#c8c8d0"); scintilla(g, 70, 50, "#c8c8d0"); },
    // m86 La Consegna dell'Ultima Torta — torta a tre piani in equilibrio, torre dell'orologio.
    std_m86: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#f4a25a"); CR(g, 0, 0, CART_W, 12, "#e8734a"); CR(g, 0, 46, CART_W, 18, "#6a5a5a"); CR(g, 0, 44, CART_W, 2, "#4a3e3e"); CR(g, 86, 4, 18, 42, "#5a4a5a"); CR(g, 84, 2, 22, 4, "#4a3e4e"); CO(g, 90, 10, 10, 10, "#3a3040", "#f4f0e0"); CR(g, 94, 12, 1, 4, "#3a3040"); CR(g, 95, 14, 3, 1, "#3a3040"); CR(g, 8, 20, 16, 26, "#7a5a6a"); CR(g, 10, 24, 4, 4, "#f0d060"); CR(g, 18, 30, 4, 4, "#f0d060"); petAt(g, pet, 42, 28, 2); CR(g, 38, 18, 24, 8, "#f4f0e0"); CR(g, 42, 12, 16, 7, "#e8a0b8"); CR(g, 46, 7, 8, 6, "#f4f0e0"); CR(g, 49, 4, 3, 4, "#c02840"); CR(g, 38, 24, 24, 2, "#e8a0b8"); CR(g, 42, 17, 16, 2, "#c87a94"); scintilla(g, 34, 10, "#fff2b0"); scintilla(g, 66, 14, "#fff2b0"); CR(g, 20, 52, 20, 3, "#8a7a7a"); },
    // m87 Il Borseggiatore del Mercato — inseguimento tra i banchi, arance che volano.
    std_m87: function (g, pet) { CR(g, 0, 0, CART_W, 44, "#e8d8b8"); CR(g, 0, 0, CART_W, 6, "#c8b898"); CR(g, 0, 44, CART_W, 20, "#a89a84"); CR(g, 0, 44, CART_W, 2, "#7a6e5c"); CR(g, 2, 8, 30, 5, "#c02840"); CR(g, 2, 13, 30, 5, "#f4f0e0"); CR(g, 2, 18, 30, 3, "#c02840"); CR(g, 4, 21, 26, 14, "#8a6438"); CR(g, 6, 24, 6, 5, "#f0862a"); CR(g, 14, 24, 6, 5, "#f0862a"); CR(g, 22, 24, 6, 5, "#f0862a"); CR(g, 80, 8, 30, 5, "#2a7a4a"); CR(g, 80, 13, 30, 5, "#f4f0e0"); CR(g, 80, 18, 30, 3, "#2a7a4a"); CR(g, 82, 21, 26, 14, "#8a6438"); CR(g, 86, 24, 7, 6, "#f5d020"); CR(g, 96, 24, 7, 6, "#5ce87f"); figura(g, 92, 36, 15, "#3a3a4a"); CR(g, 98, 38, 8, 8, "#6a5a3e"); petAt(g, pet, 36, 26, 2); CR(g, 58, 18, 4, 4, "#f0862a"); CR(g, 68, 12, 4, 4, "#f0862a"); CR(g, 52, 10, 4, 4, "#f0862a"); scintilla(g, 64, 22, "#ffffff"); scintilla(g, 30, 38, "#ffffff"); scintilla(g, 74, 8, "#fff2b0"); },
    // m88 La Traversata della Cava — acqua turchese, pareti di roccia, isolotto: il pet nuota.
    std_m88: function (g, pet) { CR(g, 0, 0, CART_W, 30, "#8ac8d8"); CR(g, 0, 30, CART_W, 34, "#1d8a84"); CR(g, 0, 30, CART_W, 2, "#2aa8a0"); CR(g, 0, 0, 18, 46, "#5a5a62"); CR(g, 0, 0, 14, 30, "#6e6e78"); CR(g, 94, 0, 18, 48, "#5a5a62"); CR(g, 98, 0, 14, 32, "#6e6e78"); CR(g, 44, 46, 26, 10, "#6e6e78"); CR(g, 48, 42, 18, 6, "#8a8a94"); petAt(g, pet, 34, 20, 2); CR(g, 24, 36, 52, 10, "#1d8a84"); CR(g, 24, 36, 52, 2, "#2aa8a0"); CR(g, 20, 40, 18, 1, "#7fd8d0"); CR(g, 62, 42, 16, 1, "#7fd8d0"); CR(g, 30, 46, 14, 1, "#4ab8b0"); scintilla(g, 26, 34, "#bff0ea"); scintilla(g, 68, 36, "#bff0ea"); scintilla(g, 54, 24, "#ffffff"); },
    // m89 Il Torneo di Scacchi del Circolo — scacchiera, anziani con gli occhiali che osservano.
    std_m89: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#6a4a3a"); CR(g, 0, 0, CART_W, 8, "#523828"); CR(g, 0, 46, CART_W, 18, "#4a3428"); CR(g, 0, 44, CART_W, 2, "#38261c"); CO(g, 44, 2, 14, 8, "#8a7a2e", "#f0d060"); scintilla(g, 50, 14, "#ffe8a0"); CR(g, 28, 34, 56, 8, "#8a6438"); CR(g, 28, 42, 56, 2, "#5c4224"); CR(g, 34, 44, 4, 12, "#5c4224"); CR(g, 74, 44, 4, 12, "#5c4224"); CR(g, 36, 28, 40, 8, "#e8d8b0"); CR(g, 36, 28, 5, 4, "#3a2c20"); CR(g, 46, 28, 5, 4, "#3a2c20"); CR(g, 56, 28, 5, 4, "#3a2c20"); CR(g, 66, 28, 5, 4, "#3a2c20"); CR(g, 41, 32, 5, 4, "#3a2c20"); CR(g, 51, 32, 5, 4, "#3a2c20"); CR(g, 61, 32, 5, 4, "#3a2c20"); CR(g, 71, 32, 5, 4, "#3a2c20"); CR(g, 44, 24, 3, 5, "#f4f0e0"); CR(g, 62, 23, 3, 6, "#2a2a32"); CR(g, 70, 25, 3, 4, "#f4f0e0"); petAt(g, pet, 30, 18, 2); figura(g, 92, 22, 16, "#5a6a7a"); CR(g, 92, 16, 8, 3, "#e8e8e0"); CR(g, 93, 22, 6, 2, "#c8ccd0"); figura(g, 12, 24, 14, "#6a5a7a"); CR(g, 12, 18, 8, 3, "#e8e8e0"); CR(g, 13, 24, 6, 2, "#c8ccd0"); },
    // m90 Ripetizioni al Vicino — scrivania, lampada, libro aperto, cucciolo che annuisce.
    std_m90: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#3a2a4e"); CR(g, 0, 46, CART_W, 18, "#4a3828"); CR(g, 0, 44, CART_W, 2, "#2e2016"); CR(g, 8, 8, 20, 14, "#141a3a"); CO(g, 8, 8, 20, 14, "#2a2038", "#141a3a"); CR(g, 20, 11, 5, 5, "#e8e8d0"); CR(g, 30, 30, 74, 8, "#6a4a2a"); CR(g, 30, 38, 74, 2, "#4a3018"); CR(g, 36, 40, 4, 14, "#4a3018"); CR(g, 94, 40, 4, 14, "#4a3018"); CO(g, 88, 14, 12, 8, "#8a7a1e", "#f0d060"); CR(g, 92, 22, 3, 8, "#5a5a66"); scintilla(g, 84, 24, "#ffe8a0"); CR(g, 52, 24, 12, 6, "#f4f0e0"); CR(g, 58, 24, 1, 6, "#8a8a92"); CR(g, 54, 26, 3, 1, "#5a5a66"); CR(g, 60, 26, 3, 1, "#5a5a66"); petAt(g, pet, 30, 16, 2); figura(g, 76, 18, 12, "#c47a4a"); CR(g, 78, 14, 5, 4, "#c47a4a"); scintilla(g, 84, 10, "#fff2b0"); },
    // m91 Il Cabinato Rotto — sala giochi buia, pannello aperto, fili, torcia tra i denti.
    std_m91: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#14101c"); CR(g, 0, 46, CART_W, 18, "#221c30"); CR(g, 0, 44, CART_W, 2, "#3a3050"); CR(g, 4, 4, 24, 2, "#e5407a"); CR(g, 84, 4, 24, 2, "#40e0d0"); CO(g, 8, 12, 20, 32, "#2a2440", "#3a3458"); CR(g, 11, 16, 14, 10, "#141a2e"); CR(g, 13, 18, 4, 3, "#5ce87f"); CO(g, 58, 8, 34, 38, "#2a2440", "#463e66"); CR(g, 62, 12, 26, 14, "#8a8a92"); CR(g, 64, 14, 22, 3, "#a8a8b0"); CR(g, 64, 19, 22, 3, "#6a6a74"); CR(g, 62, 30, 12, 14, "#241c30"); CR(g, 64, 32, 8, 1, "#e83028"); CR(g, 64, 35, 8, 1, "#f5d020"); CR(g, 64, 38, 8, 1, "#5ce87f"); CR(g, 64, 41, 8, 1, "#50c8ff"); petAt(g, pet, 38, 24, 2); CR(g, 50, 30, 8, 3, "#c8ccd0"); CR(g, 56, 28, 6, 7, "#fff6c0"); scintilla(g, 78, 28, "#ffd23f"); scintilla(g, 30, 20, "#e5407a"); },
    // m92 Il Fungo Misterioso — bosco, fungo gigante a pois, lente e taccuino.
    std_m92: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#24402a"); CR(g, 0, 0, CART_W, 12, "#182c1c"); CR(g, 0, 46, CART_W, 18, "#2e3c26"); CR(g, 0, 44, CART_W, 2, "#1c2816"); CR(g, 8, 6, 6, 40, "#4a3626"); CR(g, 100, 10, 6, 36, "#4a3626"); CR(g, 4, 2, 16, 10, "#182c1c"); CR(g, 96, 4, 16, 10, "#182c1c"); CR(g, 70, 26, 10, 20, "#e8d8b8"); CR(g, 58, 14, 34, 14, "#c02840"); CR(g, 62, 10, 26, 6, "#c02840"); CR(g, 66, 16, 5, 5, "#f4f0e0"); CR(g, 80, 12, 5, 5, "#f4f0e0"); CR(g, 74, 22, 4, 4, "#f4f0e0"); petAt(g, pet, 32, 24, 2); CO(g, 48, 22, 8, 8, "#3a3a44", "#bfe8f0"); CR(g, 54, 30, 3, 5, "#5a4a30"); CR(g, 24, 50, 12, 8, "#f4f0e0"); CR(g, 30, 50, 1, 8, "#8a8a92"); scintilla(g, 60, 6, "#c8f0a0"); scintilla(g, 92, 24, "#c8f0a0"); },
    // m93 DJ della Festa Scolastica — consolle, cuffie, palestra che balla sotto la sfera.
    std_m93: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#1a1428"); CR(g, 0, 46, CART_W, 18, "#241c34"); CR(g, 0, 44, CART_W, 2, "#3a2a5a"); CO(g, 50, 2, 12, 12, "#5a5a66", "#c8ccd0"); CR(g, 54, 0, 4, 3, "#8a8a92"); scintilla(g, 44, 10, "#ffffff"); scintilla(g, 66, 8, "#ffffff"); CR(g, 20, 16, 3, 3, "#e5407a"); CR(g, 88, 14, 3, 3, "#40e0d0"); CR(g, 34, 8, 3, 3, "#f5d020"); petAt(g, pet, 40, 16, 2); CR(g, 42, 14, 12, 3, "#2a2a32"); CR(g, 40, 16, 3, 5, "#2a2a32"); CR(g, 53, 16, 3, 5, "#2a2a32"); CO(g, 28, 32, 56, 10, "#16121e", "#3a3448"); CR(g, 32, 35, 6, 4, "#e5407a"); CR(g, 42, 35, 6, 4, "#40e0d0"); CR(g, 52, 35, 6, 4, "#f5d020"); CR(g, 62, 35, 6, 4, "#5ce87f"); CR(g, 72, 35, 8, 4, "#16121e"); figura(g, 12, 48, 11, "#5a4a72"); figura(g, 26, 50, 10, "#48607a"); figura(g, 88, 48, 11, "#6a4a62"); figura(g, 102, 50, 10, "#4a5a72"); scintilla(g, 20, 40, "#ff9ad0"); scintilla(g, 96, 40, "#7fd8ff"); },
    // m94 Il Mercatino dell'Usato — ombrellone, banchetto di cianfrusaglie, cliente che contratta.
    std_m94: function (g, pet) { CR(g, 0, 0, CART_W, 44, "#bfe3f7"); CR(g, 92, 4, 8, 8, "#f8e05a"); CR(g, 0, 44, CART_W, 20, "#b0a088"); CR(g, 0, 44, CART_W, 2, "#8a7c66"); CR(g, 26, 4, 60, 6, "#c02840"); CR(g, 32, 10, 48, 4, "#f4f0e0"); CR(g, 40, 14, 32, 3, "#c02840"); CR(g, 54, 17, 3, 16, "#6a4a2a"); CR(g, 24, 32, 64, 10, "#8a6438"); CR(g, 24, 42, 64, 2, "#5c4224"); CR(g, 30, 44, 4, 12, "#5c4224"); CR(g, 78, 44, 4, 12, "#5c4224"); CO(g, 28, 24, 8, 8, "#5a4a30", "#f0d060"); CR(g, 40, 26, 8, 6, "#6a4a5e"); CR(g, 41, 22, 2, 4, "#6a4a5e"); CO(g, 52, 26, 10, 6, "#2a3038", "#7ab0d8"); CR(g, 66, 24, 7, 8, "#c8ccd0"); CR(g, 76, 27, 6, 5, "#e05050"); petAt(g, pet, 34, 12, 2); figura(g, 98, 26, 16, "#5a6a52"); CR(g, 92, 32, 6, 3, "#c8a070"); CR(g, 70, 18, 6, 4, "#f4f0e0"); scintilla(g, 46, 18, "#fff2b0"); },
    // m95 La Recita del Quartiere — palco, sipario, mantello e spada di legno, pubblico in penombra.
    std_m95: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#2a1a24"); CR(g, 0, 0, CART_W, 4, "#4a2a38"); CR(g, 0, 4, 18, 42, "#7a1828"); CR(g, 4, 4, 3, 42, "#5c1220"); CR(g, 11, 4, 3, 42, "#5c1220"); CR(g, 94, 4, 18, 42, "#7a1828"); CR(g, 98, 4, 3, 42, "#5c1220"); CR(g, 105, 4, 3, 42, "#5c1220"); CR(g, 18, 40, 76, 8, "#8a6438"); CR(g, 18, 40, 76, 2, "#a87e4c"); CR(g, 30, 10, 52, 30, "#3a2a3e"); scintilla(g, 40, 14, "#ffe8a0"); scintilla(g, 70, 12, "#ffe8a0"); CR(g, 40, 22, 14, 14, "#c02840"); petAt(g, pet, 42, 18, 2); CR(g, 60, 10, 3, 12, "#b8863c"); CR(g, 58, 12, 7, 3, "#8a6438"); CR(g, 0, 48, CART_W, 16, "#16101c"); CR(g, 8, 50, 10, 6, "#241a2c"); CR(g, 26, 52, 10, 6, "#241a2c"); CR(g, 46, 50, 10, 6, "#241a2c"); CR(g, 66, 52, 10, 6, "#241a2c"); CR(g, 86, 50, 10, 6, "#241a2c"); CR(g, 102, 53, 8, 5, "#241a2c"); },
    // m96 La Festa di Quartiere (BOSS) — piazza in festa, bancarelle, luci, pet con la cassa.
    std_m96: function (g, pet) { CR(g, 0, 0, CART_W, 46, "#241934"); CR(g, 0, 46, CART_W, 18, "#3a3044"); CR(g, 0, 44, CART_W, 2, "#4a4058"); CR(g, 0, 8, CART_W, 1, "#4a4058"); CR(g, 8, 8, 2, 3, "#ff5050"); CR(g, 24, 8, 2, 3, "#f5d020"); CR(g, 40, 8, 2, 3, "#50c8ff"); CR(g, 56, 8, 2, 3, "#5ce87f"); CR(g, 72, 8, 2, 3, "#e85ad8"); CR(g, 88, 8, 2, 3, "#f0b040"); CR(g, 104, 8, 2, 3, "#ff5050"); CR(g, 2, 14, 26, 4, "#c02840"); CR(g, 2, 18, 26, 3, "#f4f0e0"); CR(g, 4, 21, 22, 12, "#8a6438"); CR(g, 7, 24, 6, 5, "#f5d020"); CR(g, 16, 24, 6, 5, "#f0862a"); CR(g, 84, 14, 26, 4, "#2a7a4a"); CR(g, 84, 18, 26, 3, "#f4f0e0"); CR(g, 86, 21, 22, 12, "#8a6438"); CR(g, 90, 24, 6, 5, "#e05050"); CR(g, 99, 24, 6, 5, "#7ab0d8"); figura(g, 14, 38, 12, "#5a4a72"); figura(g, 96, 38, 12, "#4a5a72"); figura(g, 106, 40, 10, "#6a4a62"); petAt(g, pet, 42, 24, 2); CO(g, 38, 30, 20, 12, "#5a3a1c", "#8a6438"); CR(g, 42, 33, 12, 2, "#5a3a1c"); CR(g, 42, 37, 12, 2, "#5a3a1c"); scintilla(g, 34, 4, "#ffd23f"); scintilla(g, 98, 2, "#ff6ad0"); scintilla(g, 66, 6, "#7fd8ff"); scintilla(g, 78, 30, "#fff2b0"); },
    // m97 Il Mostriciattolo dell'Erba Alta — spighe alte, creatura guizzante, scintille.
    std_m97: function (g, pet) { CR(g, 0, 0, CART_W, 44, "#2e4a2a"); CR(g, 0, 0, CART_W, 14, "#22381e"); CR(g, 0, 44, CART_W, 20, "#3a5a30"); CR(g, 0, 44, CART_W, 2, "#2a4222"); CR(g, 4, 18, 3, 30, "#4a7a3c"); CR(g, 12, 14, 3, 34, "#5a8a48"); CR(g, 20, 20, 3, 28, "#4a7a3c"); CR(g, 28, 12, 3, 36, "#5a8a48"); CR(g, 84, 14, 3, 34, "#5a8a48"); CR(g, 92, 18, 3, 30, "#4a7a3c"); CR(g, 100, 12, 3, 36, "#5a8a48"); CR(g, 108, 20, 3, 28, "#4a7a3c"); CR(g, 3, 16, 5, 3, "#8ab060"); CR(g, 27, 10, 5, 3, "#8ab060"); CR(g, 99, 10, 5, 3, "#8ab060"); petAt(g, pet, 34, 26, 2); CR(g, 68, 28, 12, 10, "#3ac8b0"); CR(g, 72, 24, 8, 6, "#3ac8b0"); CR(g, 74, 26, 4, 3, "#f4f0e0"); CR(g, 75, 27, 2, 2, "#16161c"); CR(g, 66, 34, 4, 3, "#2aa890"); CR(g, 80, 36, 4, 3, "#2aa890"); scintilla(g, 62, 20, "#ffd23f"); scintilla(g, 86, 26, "#ffd23f"); scintilla(g, 56, 36, "#c8f0a0"); },
    // m98 Ci Hanno Rubato i Colori — muro mezzo sbiadito, intervistato che gesticola, pet con la lente.
    std_m98: function (g, pet) { CR(g, 0, 0, 56, 46, "#8a8a90"); CR(g, 0, 0, 56, 10, "#74747c"); CR(g, 8, 14, 16, 12, "#a0a0a6"); CR(g, 30, 16, 16, 10, "#9a9aa0"); CR(g, 56, 0, 56, 46, "#e8a05a"); CR(g, 56, 0, 56, 10, "#d4884a"); CR(g, 64, 14, 16, 12, "#f0c060"); CR(g, 88, 16, 16, 10, "#7ab0d8"); CR(g, 0, 46, CART_W, 18, "#6a6a74"); CR(g, 0, 44, CART_W, 2, "#4e4e58"); CR(g, 54, 0, 3, 46, "#3a3a44"); figura(g, 14, 26, 18, "#4a5a6a"); CR(g, 8, 30, 7, 3, "#4a5a6a"); CR(g, 22, 28, 6, 3, "#4a5a6a"); CR(g, 28, 26, 3, 6, "#2a2a32"); CR(g, 28, 24, 3, 3, "#8a8a92"); petAt(g, pet, 66, 24, 2); CO(g, 86, 30, 8, 8, "#3a3a44", "#bfe8f0"); CR(g, 92, 38, 3, 5, "#5a4a30"); CR(g, 40, 50, 3, 12, "#2a2a32"); CR(g, 36, 48, 11, 3, "#2a2a32"); CR(g, 38, 46, 7, 4, "#16161c"); CR(g, 44, 47, 2, 2, "#50c8ff"); scintilla(g, 100, 12, "#ffd23f"); scintilla(g, 30, 8, "#c8c8d0"); },
  };

  // Distintivo SUPER (PROTOTIPO 2, fase sprite): coppa dorata + coriandoli, overlay "super successo"
  // disegnato SOPRA la scena della missione. Per le missioni M9+ il super = scena std_m<N> + questo.
  function trofeoSuper(g) {
    CO(g, 48, 3, 14, 9, "#6e4826", "#f0b84a");
    CR(g, 45, 4, 3, 4, "#f0b84a"); CR(g, 62, 4, 3, 4, "#f0b84a"); // manici
    CR(g, 53, 12, 4, 3, "#c99a3c"); CR(g, 50, 15, 10, 2, "#6e4826"); // stelo + base
    CR(g, 50, 4, 2, 3, "#f8e05a"); // riflesso
    scintilla(g, 43, 2, "#f8f0a0"); scintilla(g, 66, 6, "#f8f0a0");
    var cf = [[10, 6, "#e85a78"], [24, 3, "#4dd8e8"], [88, 4, "#5ce87f"], [100, 8, "#f0b84a"], [6, 14, "#e85ad8"], [104, 16, "#4dd8e8"]];
    for (var i = 0; i < cf.length; i++) CR(g, cf[i][0], cf[i][1], 2, 2, cf[i][2]);
  }
  // Missioni M9-M32 (regola fondatore "ogni quest la sua scena"): il super riusa la scena
  // per-missione std_m<N> (disegnata dalla descrizione) + il trofeo. Le baby M1-M8 tengono le
  // loro super_m<N> dedicate (gia' fatte, invariate). std_m9..m32 aggiunte a SCENE piu' sopra.
  // Range esteso a m98 (adulto M33-64 + imprese M65-72 + extra M73-98): il super = std_m<N> + trofeo
  // viene creato SOLO se la scena std_m<N> esiste gia' (guardia). Le scene ancora da disegnare per le
  // ondate future NON generano un super vuoto: cadono sul fallback fail_generica finche' non le disegno.
  (function () {
    for (var n = 9; n <= 98; n++) {
      (function (N) {
        if (!SCENE['std_m' + N]) return;
        SCENE['super_m' + N] = function (g, pet) {
          SCENE['std_m' + N](g, pet);
          trofeoSuper(g);
        };
      })(n);
    }
  })();

  // scenaId: 'std_<categoria>' | 'std_m9..m32' | 'fail_generica' | 'super_m1..m32'
  // ===== Cornici della cartolina (cosmetico, 29 lug 2026) =====
  // Si disegnano SOPRA la scena e SOLO sul bordo: il centro deve restare libero, perche' nelle
  // scene il pet sta quasi sempre in mezzo e una cornice piena lo coprirebbe.
  // Coordinate nello spazio cartolina 112x64 (CART_W/CART_H), helper CR/CO come le scene.
  var CORNICI = {
    dorata: function (g) {
      var scuro = "#8a6a20", oro = "#d8a840", luce = "#f4e08a";
      CR(g, 0, 0, CART_W, 5, oro); CR(g, 0, CART_H - 5, CART_W, 5, oro);
      CR(g, 0, 0, 5, CART_H, oro); CR(g, CART_W - 5, 0, 5, CART_H, oro);
      CR(g, 4, 4, CART_W - 8, 1, scuro); CR(g, 4, CART_H - 5, CART_W - 8, 1, scuro);
      CR(g, 4, 4, 1, CART_H - 8, scuro); CR(g, CART_W - 5, 4, 1, CART_H - 8, scuro);
      CR(g, 0, 0, CART_W, 1, luce); CR(g, 0, 0, 1, CART_H, luce);
      CR(g, 1, 1, 3, 3, luce); CR(g, CART_W - 4, 1, 3, 3, luce);
      CR(g, 1, CART_H - 4, 3, 3, luce); CR(g, CART_W - 4, CART_H - 4, 3, 3, luce);
    },
    pellicola: function (g) {
      var nero = "#14141a", bianco = "#f0f0f4";
      CR(g, 0, 0, CART_W, 7, nero); CR(g, 0, CART_H - 7, CART_W, 7, nero);
      CR(g, 0, 0, 3, CART_H, nero); CR(g, CART_W - 3, 0, 3, CART_H, nero);
      for (var x = 5; x < CART_W - 6; x += 10) {
        CR(g, x, 2, 5, 3, bianco);
        CR(g, x, CART_H - 5, 5, 3, bianco);
      }
    },
    polaroid: function (g) {
      var carta = "#f4f2ec", ombra = "#c8c4b8";
      CR(g, 0, 0, CART_W, 5, carta);
      CR(g, 0, 0, 5, CART_H, carta); CR(g, CART_W - 5, 0, 5, CART_H, carta);
      CR(g, 0, CART_H - 13, CART_W, 13, carta); // fascia bassa spessa: la firma della polaroid
      CR(g, 4, 4, CART_W - 8, 1, ombra);
      CR(g, 4, CART_H - 13, CART_W - 8, 1, ombra);
      CR(g, 10, CART_H - 8, 40, 2, ombra);      // la riga su cui si scrive la didascalia
    },
    pergamena: function (g) {
      var carta = "#e8dcb8", bordo = "#c8b888", scuro = "#a89868";
      CR(g, 0, 0, CART_W, 6, carta); CR(g, 0, CART_H - 6, CART_W, 6, carta);
      CR(g, 0, 0, 6, CART_H, carta); CR(g, CART_W - 6, 0, 6, CART_H, carta);
      // bordo interno STRAPPATO: dentini sfalsati, e' quello che la fa sembrare carta antica
      for (var i = 0; i < CART_W; i += 4) { CR(g, i, 5, 2, 1, bordo); CR(g, i + 2, 6, 2, 1, bordo); }
      for (var j = 0; j < CART_W; j += 4) { CR(g, j, CART_H - 6, 2, 1, bordo); CR(g, j + 2, CART_H - 7, 2, 1, bordo); }
      for (var k = 0; k < CART_H; k += 4) { CR(g, 5, k, 1, 2, bordo); CR(g, CART_W - 6, k + 2, 1, 2, bordo); }
      CR(g, 0, 0, CART_W, 1, scuro); CR(g, 0, CART_H - 1, CART_W, 1, scuro);
    },
    neon: function (g) {
      var nero = "#0e0a1a", rosa = "#ff4aa0", ciano = "#40e8f0";
      CR(g, 0, 0, CART_W, 5, nero); CR(g, 0, CART_H - 5, CART_W, 5, nero);
      CR(g, 0, 0, 5, CART_H, nero); CR(g, CART_W - 5, 0, 5, CART_H, nero);
      CR(g, 0, 1, CART_W, 1, rosa); CR(g, 0, CART_H - 2, CART_W, 1, rosa);
      CR(g, 1, 0, 1, CART_H, rosa); CR(g, CART_W - 2, 0, 1, CART_H, rosa);
      CR(g, 4, 4, CART_W - 8, 1, ciano); CR(g, 4, CART_H - 5, CART_W - 8, 1, ciano);
      CR(g, 4, 4, 1, CART_H - 8, ciano); CR(g, CART_W - 5, 4, 1, CART_H - 8, ciano);
    }
  };

  // `cornice` (opzionale) = id in CORNICI: si disegna DOPO la scena, quindi sta sopra tutto.
  // Id sconosciuto o assente = nessuna cornice, comportamento identico a prima.
  function drawCartolina(canvas, scenaId, petLike, cornice) {
    if (!canvas || !petLike) return;
    var g = canvas.getContext("2d");
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);
    var sx = canvas.width / CART_W;
    var sy = canvas.height / CART_H;
    var scena = SCENE[scenaId] || SCENE.fail_generica;
    var needsScale = sx !== 1 || sy !== 1;
    if (needsScale) { g.save(); g.scale(sx, sy); }
    scena(g, petLike);
    if (cornice && CORNICI[cornice]) CORNICI[cornice](g);
    if (needsScale) g.restore();
  }

  // Disegna la sola cornice su un canvas gia' pronto: serve alle anteprime del negozio e
  // della scheda, che non hanno bisogno di una scena sotto.
  /* ---------- IL RITRATTO DEL CAPO (perk Ritrattista, Corso di Disegno) ----------
   *
   * E' il PET che ti disegna, e si deve vedere. Il fondatore ha scelto "un po' storto": non e' un
   * avatar creator, e' uno scarabocchio affettuoso — se venisse pulito perderebbe tutto il senso.
   *
   * LO STORTO NON E' CASUALE, sono sei scelte precise (il caso a runtime cambierebbe il ritratto a
   * ogni ridisegno, che e' l'opposto di un quadro appeso al muro):
   *   1. la testa e' spostata di 1px a destra rispetto al centro;
   *   2. il contorno e' spesso 2px a sinistra e 1px a destra;
   *   3. il bordo superiore e' alzato di 1px e sporge a destra;
   *   4. gli occhi sono DIVERSI fra loro: uno 2x3, l'altro 2x2 e piu' alto;
   *   5. la bocca e' fuori asse a sinistra;
   *   6. i capelli SBORDANO dal contorno in un punto, come quando si colora di fretta.
   * Il contorno e' marrone scuro e non nero: sa di pastello, mentre il nero sa di vettoriale.
   *
   * Un solo livello di qualita' (decisione del fondatore: "facciamo 1, senza complicare"). Se un
   * giorno si vorra' il ritratto che cresce col pet, questa funzione prende un parametro in piu' e
   * le tabelle dei tratti restano identiche.
   */
  var RIT_W = 32;
  var RIT_H = 32;
  var RIT_MAGLIA = '#4a6a9a';
  var RIT_MAGLIA_SCURA = '#31486c';

  // Le tabelle dei tratti stanno QUI e non nella UI: sono dati di disegno, e la schermata deve
  // leggere le opzioni da chi sa disegnarle, non tenerne una lista parallela che divergera'.
  /* Il colore dei TRATTI cambia con la pelle, e non e' un vezzo: col contorno unico marrone scuro
   * sulle due carnagioni piu' scure occhi e bocca quasi SPARIVANO — visto renderizzando il
   * provino, non prevedibile a tavolino. Un ritratto in cui non si legge la faccia non e' uno
   * stile ingenuo, e' un difetto. Sulle pelli chiare resta il marrone da pastello; sulle scure si
   * scende quasi al nero, che stacca. */
  var RIT_TRATTI_PER_PELLE = ['#2f2118', '#2f2118', '#1c1310', '#140d0b'];

  /* Ampliamento 11 ago 2026 (fondatore: "mostra solo opzioni maschili, soprattutto nel 2026 —
   * metti versioni femminili"): +caschetto e +trecce fra le forme, e la riga nuova 'tocco'
   * (orecchini / rossetto / fiocco). Nessuna opzione e' etichettata per genere: sono TRATTI, e
   * ognuno compone il ritratto che vuole — barba col rossetto compresa. */
  var TRATTI = {
    pelle: ['#f2cfa8', '#dda878', '#ab7048', '#7d5138'],
    capelliColore: ['#33241a', '#8a5a2b', '#e6c65e', '#bdbdc6'],
    capelliForma: ['corti', 'lunghi', 'ricci', 'coda', 'caschetto', 'trecce', 'calvo'],
    occhiali: ['no', 'vista', 'sole'],
    barba: ['no', 'baffi', 'barba'],
    tocco: ['no', 'orecchini', 'rossetto', 'fiocco']
  };

  function ritIndice(lista, v) {
    var i = (typeof v === 'number') ? v : 0;
    if (i < 0 || i >= lista.length) i = 0;
    return i;
  }

  function drawRitratto(canvas, tratti) {
    if (!canvas) return;
    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);
    var sx = canvas.width / RIT_W, sy = canvas.height / RIT_H;
    g.save();
    if (sx !== 1 || sy !== 1) g.scale(sx, sy);

    var t = tratti || {};
    var iPelle = ritIndice(TRATTI.pelle, t.pelle);
    var pelle = TRATTI.pelle[iPelle];
    // Contorno e tratti del viso in base alla CARNAGIONE (v. RIT_TRATTI_PER_PELLE sopra): con un
    // contorno unico, sulle pelli scure la faccia non si leggeva.
    var RIT_CONTORNO = RIT_TRATTI_PER_PELLE[iPelle] || RIT_TRATTI_PER_PELLE[0];
    var capCol = TRATTI.capelliColore[ritIndice(TRATTI.capelliColore, t.capelliColore)];
    var forma = TRATTI.capelliForma[ritIndice(TRATTI.capelliForma, t.capelliForma)];
    var occhiali = TRATTI.occhiali[ritIndice(TRATTI.occhiali, t.occhiali)];
    var barba = TRATTI.barba[ritIndice(TRATTI.barba, t.barba)];
    var tocco = TRATTI.tocco[ritIndice(TRATTI.tocco, t.tocco)];

    // --- maglia: il bordo alto e' a DUE altezze diverse, cioe' spalle sbilenche ---
    CR(g, 5, 26, 23, 6, RIT_MAGLIA);
    CR(g, 6, 25, 9, 1, RIT_MAGLIA);
    CR(g, 16, 24, 10, 1, RIT_MAGLIA);   // la spalla destra piu' alta della sinistra
    CR(g, 5, 26, 1, 6, RIT_MAGLIA_SCURA);
    CR(g, 27, 26, 1, 6, RIT_MAGLIA_SCURA);
    CR(g, 15, 27, 1, 5, RIT_MAGLIA_SCURA); // accenno di scollatura, fuori centro

    // --- collo ---
    CR(g, 14, 21, 5, 4, pelle);

    /* --- testa. GLI SPIGOLI SMUSSATI SONO LA COSA PIU' IMPORTANTE DI TUTTO IL DISEGNO: al primo
     * giro la testa era un rettangolo pieno e a schermo leggeva come una SCATOLA, non come una
     * faccia. Storto e quadrato sono due cose diverse, e il quadrato non e' un errore simpatico,
     * e' un errore. Togliendo un paio di pixel per angolo (in modo diseguale, cosi' resta
     * disegnata a mano) il cranio diventa una testa restando ingenuo. --- */
    CR(g, 9, 6, 2, 15, RIT_CONTORNO);    // lato sinistro spesso 2px
    CR(g, 23, 7, 1, 14, RIT_CONTORNO);   // destro 1px e piu' corto: asimmetria voluta
    CR(g, 11, 4, 11, 2, RIT_CONTORNO);   // calotta
    CR(g, 10, 5, 1, 1, RIT_CONTORNO);    // smussi dell'angolo, diseguali fra i due lati
    CR(g, 22, 6, 1, 1, RIT_CONTORNO);
    CR(g, 11, 21, 12, 1, RIT_CONTORNO);  // mento
    CR(g, 10, 20, 1, 1, RIT_CONTORNO);
    CR(g, 23, 20, 1, 1, RIT_CONTORNO);
    CR(g, 11, 6, 12, 15, pelle);
    CR(g, 10, 7, 1, 13, pelle);          // la guancia sinistra sporge un filo: faccia non simmetrica

    // --- occhi DIVERSI fra loro: e' il dettaglio che dice "l'ha disegnato lui" ---
    CR(g, 12, 12, 2, 3, RIT_CONTORNO);
    CR(g, 18, 11, 2, 2, RIT_CONTORNO);

    // --- naso, e una bocca che SORRIDE storta: una riga dritta e' una faccia inespressiva, e un
    // pixel piu' basso a un'estremita' sola basta a farla sembrare contenta ---
    CR(g, 16, 15, 1, 2, RIT_CONTORNO);
    CR(g, 13, 18, 4, 1, RIT_CONTORNO);
    CR(g, 17, 17, 1, 1, RIT_CONTORNO);

    // --- capelli ---
    if (forma !== 'calvo') {
      CR(g, 10, 2, 13, 3, capCol);
      CR(g, 9, 4, 2, 3, capCol);
      CR(g, 8, 5, 1, 2, capCol);         // SBORDA dal contorno: colorato di fretta
    }
    if (forma === 'lunghi') {
      // Al primo giro i capelli lunghi comparivano solo a destra e sembravano una macchia. Ora
      // INQUADRANO la faccia da entrambi i lati, con lunghezze diverse (a destra scende di piu'):
      // e' la differenza fra "capelli lunghi" e "sbaffo di colore".
      CR(g, 7, 5, 3, 15, capCol);
      CR(g, 6, 8, 1, 10, capCol);
      CR(g, 23, 6, 3, 17, capCol);
      CR(g, 26, 9, 1, 11, capCol);
      CR(g, 8, 20, 2, 2, capCol);
    } else if (forma === 'ricci') {
      CR(g, 8, 3, 4, 4, capCol);
      CR(g, 12, 1, 5, 4, capCol);
      CR(g, 17, 2, 5, 4, capCol);
      CR(g, 21, 4, 3, 3, capCol);
      CR(g, 7, 6, 3, 3, capCol);
    } else if (forma === 'coda') {
      // La coda ATTACCATA alla testa con l'elastico e rastremata: staccata leggeva come una
      // scatola appoggiata di fianco.
      CR(g, 23, 9, 2, 2, RIT_CONTORNO); // elastico
      CR(g, 25, 8, 3, 7, capCol);
      CR(g, 27, 11, 2, 5, capCol);
      CR(g, 28, 14, 1, 3, capCol);      // punta che si assottiglia
    } else if (forma === 'caschetto') {
      // Il caschetto e' FRANGIA piena + lati che si fermano alla mascella con le punte in
      // dentro: e' la fermata a meta' che lo distingue dai "lunghi" (che inquadrano fino
      // al collo) e la frangia dritta a distinguerlo dai "corti".
      CR(g, 11, 5, 12, 3, capCol);      // frangia sulla fronte
      CR(g, 11, 8, 3, 1, capCol);       // sbaffo della frangia, storto
      CR(g, 8, 4, 2, 13, capCol);       // lato sinistro fino alla mascella
      CR(g, 7, 7, 1, 8, capCol);
      CR(g, 23, 5, 3, 12, capCol);      // destro piu' spesso: asimmetria di casa
      CR(g, 26, 8, 1, 7, capCol);
      CR(g, 9, 16, 1, 2, capCol);       // punte rivolte in dentro
      CR(g, 24, 16, 1, 2, capCol);
    } else if (forma === 'trecce') {
      // Due codini che SPORGONO dai lati e PENDONO fin sotto la mascella. Primo giro bocciato
      // guardando il foglio: attaccati alla testa leggevano come BASETTE. Cio' che dice
      // "treccia" e': staccarsi dalla sagoma del cranio, scendere piu' giu' del mento, e lo
      // zigzag LARGO dei segmenti (una colonna dritta e' solo un ciuffo).
      CR(g, 11, 5, 12, 2, capCol);      // frangetta leggera
      CR(g, 8, 6, 2, 3, capCol);        // attaccatura sinistra
      CR(g, 6, 8, 2, 2, capCol);        // sporge in fuori
      CR(g, 6, 10, 1, 1, RIT_CONTORNO); // elastico
      CR(g, 5, 11, 3, 3, capCol);       // segmenti a zigzag largo
      CR(g, 6, 14, 2, 3, capCol);
      CR(g, 5, 17, 2, 3, capCol);       // scende sotto la mascella
      CR(g, 6, 20, 1, 1, capCol);       // puntina
      CR(g, 23, 5, 2, 3, capCol);       // destra: piu' alta e sfalsata diversa (asimmetria)
      CR(g, 25, 7, 2, 2, capCol);
      CR(g, 26, 9, 1, 1, RIT_CONTORNO); // elastico
      CR(g, 25, 10, 3, 3, capCol);
      CR(g, 26, 13, 2, 3, capCol);
      CR(g, 27, 16, 2, 3, capCol);
      CR(g, 27, 19, 1, 1, capCol);      // puntina
    } else if (forma === 'calvo') {
      // I due "capelli superstiti" a schermo erano solo rumore. Meglio una LUCE sulla fronte: e'
      // quella che dice "pelato" a colpo d'occhio, in qualunque fumetto.
      CR(g, 13, 6, 6, 1, '#ffffff');
      CR(g, 12, 7, 3, 1, '#ffffff');
    }

    // --- occhiali: sopra gli occhi, un filo storti anche loro ---
    if (occhiali !== 'no') {
      var lente = (occhiali === 'sole') ? RIT_CONTORNO : null;
      CO(g, 10, 10, 6, 5, RIT_CONTORNO, lente || pelle);
      CO(g, 17, 9, 6, 5, RIT_CONTORNO, lente || pelle);
      CR(g, 16, 12, 1, 1, RIT_CONTORNO);
      if (occhiali !== 'sole') {         // con le lenti chiare gli occhi si rivedono dentro
        CR(g, 12, 12, 2, 2, RIT_CONTORNO);
        CR(g, 19, 11, 2, 2, RIT_CONTORNO);
      }
    }

    // --- barba / baffi ---
    if (barba === 'baffi') {
      CR(g, 12, 17, 7, 1, capCol);
    } else if (barba === 'barba') {
      CR(g, 11, 17, 9, 1, capCol);
      CR(g, 10, 18, 12, 3, capCol);
      CR(g, 12, 21, 8, 2, capCol);       // scende sotto il mento, un po' storta
      CR(g, 12, 18, 5, 1, RIT_CONTORNO); // la bocca resta visibile dentro la barba
    }

    // --- tocco finale: DOPO tutto il resto, cosi' resta visibile anche coi capelli lunghi
    // o sopra la barba (nessuna combinazione e' vietata: sono tratti, non un genere) ---
    if (tocco === 'orecchini') {
      CR(g, 9, 16, 1, 1, '#e8c44a');     // sul contorno della guancia: li' leggono "orecchio"
      CR(g, 23, 16, 1, 1, '#e8c44a');
      CR(g, 9, 17, 1, 1, '#b5952f');     // il pendente solo a sinistra: storto come tutto qui
    } else if (tocco === 'rossetto') {
      CR(g, 13, 18, 4, 1, '#c0304a');    // ricalca la bocca sorridente...
      CR(g, 17, 17, 1, 1, '#c0304a');
      CR(g, 14, 19, 2, 1, '#c0304a');    // ...piu' un accenno di labbro sotto
    } else if (tocco === 'fiocco') {
      CR(g, 17, 2, 2, 2, '#d84878');     // due falde
      CR(g, 20, 2, 2, 2, '#d84878');
      CR(g, 19, 3, 1, 1, '#8f2a4e');     // nodo scuro
      CR(g, 18, 4, 1, 1, '#d84878');     // nastrino che scende, storto
    }

    g.restore();
  }

  function drawCornice(canvas, cornice) {
    if (!canvas || !cornice || !CORNICI[cornice]) return;
    var g = canvas.getContext("2d");
    g.imageSmoothingEnabled = false;
    var sx = canvas.width / CART_W, sy = canvas.height / CART_H;
    if (sx !== 1 || sy !== 1) { g.save(); g.scale(sx, sy); CORNICI[cornice](g); g.restore(); }
    else CORNICI[cornice](g);
  }

  // ===== Assert di sviluppo: sprite 16x16, icone 12x12 =====
  function assertSpriteDims() {
    var all = {
      A_BABY: A_BABY, A_TEEN: A_TEEN,
      INS_BABY: INS_BABY, INS_TEEN: INS_TEEN,
      REP_BABY: REP_BABY, REP_TEEN: REP_TEEN,
      R_BABY: R_BABY, R_TEEN: R_TEEN
    };
    for (var name in all) {
      if (!Object.prototype.hasOwnProperty.call(all, name)) continue;
      checkArt(name, all[name]);
    }
    // combinazioni robot (3 antenne x 3 teste x 2 stadi)
    for (var a = 0; a < 3; a++) {
      for (var t = 0; t < 3; t++) {
        checkArt("R_BABY[a" + a + "t" + t + "]", buildRobotBaby(a, t));
        checkArt("R_TEEN[a" + a + "t" + t + "]", buildRobotTeen(a, t));
      }
    }
    // varianti corpo teen per ogni sottorazza + robot
    ["blob", "insettoide", "rettiliano"].forEach(function (sr) {
      ["normale", "magro", "ciccione"].forEach(function (corpo) {
        checkArt("alieno[" + sr + "," + corpo + "]", getAlienFrame(sr, "teen", corpo));
      });
    });
    ["normale", "magro", "ciccione"].forEach(function (corpo) {
      checkArt("robot[teen," + corpo + "]", getRobotFrame({ antenna: 0, testa: 0 }, "teen", corpo));
    });
    // topo delle fogne (16x16, non-pet: NON passa da up2, resta a 16)
    checkFrame("RAT_FUGA", RAT_FUGA, 16);
    checkFrame("RAT_PAURA", RAT_PAURA, 16);
    checkFrame("RAT_AMICO", RAT_AMICO, 16);
    // icone cibo e prop (12x12)
    var iconSets = [["cibo", FOOD_ICONS], ["cibo-fallback", FOOD_FALLBACK], ["prop", PROP_ICONS], ["idle-prop", IDLE_PROP_ICONS]];
    iconSets.forEach(function (set) {
      for (var id in set[1]) {
        if (Object.prototype.hasOwnProperty.call(set[1], id)) {
          checkFrame(set[0] + "[" + id + "]", set[1][id].px, ICON_SIZE);
        }
      }
    });
    checkFrame("valigetta", VALIGETTA_ICON.px, ICON_SIZE);
  }

  // Valida un frame ARTE del pet: quadrato e a risoluzione 16 (legacy) o 32 (nativo). Serve
  // durante la migrazione Strada 1 (corpi misti 16/32 finche' non sono tutti ridisegnati).
  function checkArt(name, frame) {
    if (!frame || !frame.length) { console.error("PETQ.sprites: " + name + " frame vuoto"); return false; }
    var n = frame.length;
    if (n !== SIZE_ART && n !== SIZE) {
      console.error("PETQ.sprites: " + name + " ha " + n + " righe (attese " + SIZE_ART + " o " + SIZE + ")");
      return false;
    }
    return checkFrame(name, frame, n);
  }

  function checkFrame(name, frame, size) {
    size = size || SIZE;
    if (!frame || frame.length !== size) {
      console.error("PETQ.sprites: " + name + " ha " + (frame ? frame.length : 0) + " righe (attese " + size + ")");
      return false;
    }
    var ok = true;
    for (var i = 0; i < frame.length; i++) {
      if (typeof frame[i] !== "string" || frame[i].length !== size) {
        console.error("PETQ.sprites: " + name + " riga " + i + " lunga " + (frame[i] ? frame[i].length : "?") + " invece di " + size + ": '" + frame[i] + "'");
        ok = false;
      }
    }
    return ok;
  }

  // esegue subito il check (sviluppo): eventuali errori vanno in console, non bloccano l'app
  assertSpriteDims();

  window.PETQ.sprites = {
    draw: draw,
    drawSdraiato: drawSdraiato,
    drawFood: drawFood,
    drawProp: drawProp,
    drawFoam: drawFoam,
    drawCrumbs: drawCrumbs,
    drawZzz: drawZzz,
    drawSonno: drawSonno,
    drawIdleProp: drawIdleProp,
    drawBoccaccia: drawBoccaccia,
    drawValigetta: drawValigetta,
    drawRitratto: drawRitratto,
    _tratti: function () { return TRATTI; },
    RIT_W: RIT_W,
    RIT_H: RIT_H,
    drawPianeta: drawPianeta,
    drawCartolina: drawCartolina,
    drawCornice: drawCornice,
    // elenco degli id cornice disponibili: la UI non deve mai scriverseli a mano
    _cornici: function () { var o = []; for (var k in CORNICI) if (CORNICI.hasOwnProperty(k)) o.push(k); return o; },
    drawOverlayEquip: drawOverlayEquip,
    _cartoline: Object.keys(SCENE),
    // topo amichevole riusabile fuori dalle cartoline (arredo "allenatore" nelle stanze)
    drawRatAmico: function (ctx, x, y, scale) { if (ctx) paintFrame(ctx, RAT_AMICO, RAT_PAL, scale || 1, x || 0, y || 0); },
    // esposti per test-sprites.html e debug
    _assertSpriteDims: assertSpriteDims,
    _getAlienFrame: getAlienFrame,
    _getRobotFrame: getRobotFrame,
    _getPalette: getPalette,
    _leggendeIds: function () { return Object.keys(LEGGENDE); }, // leggende EFFETTIVAMENTE disegnate (debug: ciclatore)
    _foodIcons: FOOD_ICONS,
    _foodFallback: FOOD_FALLBACK,
    _propIcons: PROP_ICONS
  };
})();
