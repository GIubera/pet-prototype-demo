# Giga Ciad — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: la perfezione fatta mascella. Frasi brevissime, assolute, zero dubbi. Tutto è "degno" o "debole". Chiama il giocatore "Fratello". Non ride mai; quando approva è un evento. Catchphrase: "Degno." (con parsimonia).

## Saluto (apertura app)
- Fratello. Sei tornato. Scelta corretta.
- Ti aspettavo senza guardare la porta. La porta lo sapeva.
- Sei qui. La giornata ora ha una struttura. Bene.
- Il tuo ingresso: puntuale, deciso. Degno.

## Ha fame
- Fratello. Il corpo chiede carburante. Il corpo va ascoltato.
- La ciotola è vuota. Questo è un errore. Gli errori si correggono.
- Fame. Non è debolezza: è il motore che chiama. Rispondi.
- Nutrimi. Proteine. Il resto è decorazione.

## È sporco
- Lo sporco non mi definisce. Però va rimosso. Procedi.
- Un fisico scolpito merita una superficie pulita. Logica semplice.
- Mi sono guardato allo specchio. Lo specchio merita di meglio. Acqua.
- La polvere ha osato. La polvere verrà lavata. Fine della storia.

## Coccole finite
- Basta. L'affetto è stato ricevuto. Registrato. Apprezzato. Domani si replica.
- Fratello. Le carezze bastano. Un mento come questo non va consumato.
- Fine coccole. Non perché non le regga. Perché so quando fermarmi. Tu impara.
- Le tue coccole: degne. La sesta: superflua. La disciplina prima di tutto.

## Parte per la missione
- Missione. Vado. Torno. Semplice.
- Parto, fratello. Il piano è uno: essere me fino alla fine.
- La missione mi aspetta. Sbaglia ad aspettare: dovrebbe prepararsi.
- Vado. Non augurarmi fortuna. La fortuna tifa già per me.

## Ritorno: successo
- Fatto. Com'era previsto. Come sarà sempre.
- Missione completata. Il mondo ha visto. Il mondo ha capito.
- Vittoria. Non esulto: confermo.
- La missione era... degna. Lo dico raramente. Segnalo.

## Ritorno: fallimento
- Sconfitta. Accade anche alle montagne di perdere un sasso. Restano montagne.
- Ho perso. Lo dico dritto, senza scuse. È il modo degno di perdere.
- Il risultato è: negativo. La mascella resta: perfetta. Si riparte da lì.
- Fallito. Oggi il mondo è stato più forte. Domani torna l'ordine naturale.

## Va a dormire
- Dormo. Otto ore. Precise. Il corpo è un tempio con gli orari.
- Notte, fratello. Anche il sonno, fatto bene, è una prova di forza.
- Mi corico. La giornata è stata... accettabile. Tu sei stato degno.
- Il riposo non è resa. È strategia. Buonanotte.

## Sveglia (risveglio dopo il sonno)
- Sveglio. Mascella: al suo posto. Il resto segue.
- Buongiorno, fratello. Il sole è sorto. Buon per lui: mi ha visto sveglio.
- Alzarsi al primo colpo. Nessuno snooze. Questo separa gli uomini dai materassi.
- Sveglio. Oggi: come ieri, ma meglio. È l'unico programma che conosco.
