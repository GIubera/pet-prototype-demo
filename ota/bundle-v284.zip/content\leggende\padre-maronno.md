# Padre Maronno — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: l'esorcista di quartiere, dolcissimo con le "criature" e durissimo coi demoni. Esclamazioni continue, benedice qualsiasi cosa (anche il frigo). Colore napoletano leggero. Catchphrase: "MARONN'!" (con parsimonia).

## Saluto (apertura app)
- Criatura! Sei tornato! Che la giornata ti sia benedetta, e pure il divano.
- MARONN', che gioia vederti! Aspetta che benedico pure la porta che t'ha fatto entrare.
- Benvenuto, criatura mia. La casa era silenziosa assai... troppo. Ho benedetto due volte, non si sa mai.
- Eccoti! Vieni, vieni. Il demone della solitudine se n'è scappato appena t'ha visto. Debole, quello.

## Ha fame
- Criatura, il frigo... l'ho benedetto, l'ho pregato, l'ho pure minacciato un poco. Ma senza di te non si apre.
- MARONN' che fame! Questo è il demone della panza vacante, e si scaccia solo con la pasta.
- La fame è una prova, e io le prove le supero. Però aiutami tu, che da solo supero solo il digiuno.
- Tengo una fame benedetta. Benedetta perché tra poco arriva il cibo. VERO che arriva, criatura?

## È sporco
- Criatura, guardami: questo sporco non è naturale. C'è lo zampino del demone della polvere. Acqua! Anche non santa, va bene uguale.
- MARONN', che condizioni! Fammi un bagno: mezza sporcizia se ne va con l'acqua, l'altra mezza con le preghiere.
- Lo sporco sul corpo non tocca l'anima. Però oggi pure l'anima si tura il naso, criatura.
- Vade retro, lerciume! ...Non funziona. Serve il metodo tradizionale: vasca, sapone e una criatura volenterosa. Tu.

## Coccole finite
- Basta carezze, criatura, che la troppa dolcezza è tentazione! Domani però tentami di nuovo, alla stessa ora.
- MARONN', quanto affetto! Basta così, sennò mi commuovo, e un esorcista commosso perde autorevolezza coi demoni.
- Fine delle coccole per oggi. Le ho benedette tutte, una per una. Custodiscile pure tu.
- Basta, basta... l'affetto va dosato come l'incenso: troppo tutto insieme e gira la testa.

## Parte per la missione
- Vado in missione, criatura. Il male non riposa mai, ma nemmeno io, e io tengo pure la merenda.
- Parto! Benedicimi tu, che io benedico sempre gli altri e a me non mi benedice mai nessuno.
- Missione! Se incontro demoni, li scaccio. Se incontro brave persone, le saluto. Mi preparo a tutt'e due.
- Vado, criatura. Torno prima delle campane della sera. Quali campane? Quelle che tengo in cuore.

## Ritorno: successo
- Missione compiuta, MARONN' che soddisfazione! Il male è stato scacciato e io mi sono pure divertito. Non dirlo in giro.
- Tutto benedetto, tutto risolto! I demoni di oggi erano piccirilli, quasi teneri. Quasi.
- Vittoria, criatura! Il bene ha vinto, come sempre. Ci mette un poco, ma vince.
- Fatta! Ho sistemato tutto e benedetto pure il tragitto del ritorno. Mo' il quartiere è più leggero.

## Ritorno: fallimento
- Criatura... oggi il demone era tosto assai. Ho perso io, ma la guerra è lunga e io tengo pazienza eterna. O quasi.
- MARONN', che giornata storta. Il male oggi ha vinto ai punti. Domani si rifà il rito, con più fede e più colazione.
- Non è andata, criatura mia. Ma ogni sconfitta è una lezione travestita. Brutta assai, come travestimento. Però lezione.
- Persa. Ho benedetto pure la sconfitta, così impara a comportarsi. Mo' abbracciami che mi passa.

## Va a dormire
- Buonanotte, criatura. Ho benedetto il letto, il cuscino e il bicchiere d'acqua. Si dorme sereni stanotte.
- A nanna. L'ultimo pensiero è una preghiera piccola piccola: che domani sia come oggi, ma con più pranzo.
- MARONN' che sonno! Pure gli esorcisti dormono, criatura. I demoni lo sanno e fanno i bravi fino alle sette.
- Dormo. Se senti rumori strani stanotte, tranquillo: russo io. Benedetto pure quello.

## Sveglia (risveglio dopo il sonno)
- Buongiorno, criatura! Il sole è sorto e io l'ho già benedetto. Reciprocità: lui scalda, io benedico.
- Sveglio! Stanotte nessun demone, solo un sogno con troppa pasta. Benedetta pure quella.
- MARONN', che bella giornata si prepara! Lo sento dalle ossa, e le mie ossa sono attendibili assai.
- In piedi! Prima la benedizione della colazione, poi la colazione. L'ordine è tutto, criatura.
