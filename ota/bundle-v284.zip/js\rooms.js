// PETQ.rooms — stanze 112x64 in rect-composition, temi 'lab' (robot) e 'ship' (alieno).
// Ogni mobile ha outline scuro e riempimento che stacca dalla parete (regola contrasto in scala di grigi).
// Layout a "slot": mobili chiave ai lati, centro parete/pavimento libero per pet e futuri arredi (modulo 6).
// Nessun modulo ES, nessuna libreria. Vedi docs/SPEC-MODULI-1-2-3.md sezione [B].
window.PETQ = window.PETQ || {};

(function () {
  "use strict";

  var W = 112, H = 64;
  var WALL_H = 44; // parete 0..44, pavimento 44..64
  // Altezza parametrica (GDD "Slot arredo, tetto passivo e Ingrandimento casa"): la LARGHEZZA W
  // resta 112 SEMPRE (le coordinate X di mobili/hotzone/pet non cambiano mai); cambia solo
  // l'altezza. H_BASE=64 stanza normale, H_GRANDE=80 stanza ingrandita (pavimento esteso in basso
  // 64..80, dove vive il 4o slot). Il modulo H (usato dai builder e dallo scaleY del draw) viene
  // impostato a H_BASE/H_GRANDE all'inizio di draw() in base a stato.ingrandimentoCasa e sempre
  // ripristinato. Il pavimento e' gia' parametrico: i builder disegnano R(g,0,WALL_H,W,H-WALL_H),
  // quindi con H piu' alto il pavimento si estende in basso da solo.
  // STANZA PIU' PROFONDA (27 lug 2026, richiesta fondatore "l'interfaccia e' sempre simile,
  // sotto c'e' uno spazio con quella scritta e basta"): H_BASE passa da 64 a 96. Misurato su
  // telefono 412x915: la stanza col pet occupava 217px su 915, MENO delle barre dell'HUD, e
  // sotto la barra azioni restavano fino a 333px vuoti. L'altezza a schermo dipende dalla
  // larghezza (aspect 112:H), quindi l'unico modo di dare respiro alla scena e' alzare H.
  // Si allunga SOLO il pavimento (44..96 invece di 44..64): la parete resta 0..44 e cosi'
  // NESSUN mobile va rispostato — sono tutti disegnati a coordinate assolute contro la parete.
  // Effetto collaterale voluto: il pet, che si posiziona sempre rispetto al FONDO della stanza
  // (v. ui.js, y = altezzaStanzaCorrente() - PET_PX - 4), scende in primo piano e i mobili
  // restano dietro di lui — prima era schiacciato contro i mobili, ora la scena ha profondita'.
  // H_GRANDE mantiene gli stessi 16px di banda extra per il 4o slot dell'Ingrandimento casa.
  var H_BASE = 96, H_GRANDE = 112;
  function altezzaStanza(stato) {
    return (stato && stato.ingrandimentoCasa) ? H_GRANDE : H_BASE;
  }

  function R(g, x, y, w, h, col) {
    g.fillStyle = col;
    g.fillRect(x, y, w, h);
  }
  // rettangolo con outline scuro 1px + riempimento, stile sprite
  function O(g, x, y, w, h, outline, fill) {
    R(g, x, y, w, h, outline);
    R(g, x + 1, y + 1, w - 2, h - 2, fill);
  }

  // ===== Palette CASA DELLA NONNA (skin acquistabile, 29 lug 2026) =====
  // Legno caldo, carta da parati a fiori, pizzo e velluto. Nessun led, nessun metallo spaziale:
  // il contrasto con lab/ship e' esattamente la battuta della skin.
  var N = {
    out: "#4a3524",
    parete: "#ecdcc4", fiore: "#d07a9c", foglia: "#7aa86a",
    ottone: "#d8a840", battiscopa: "#8a6a48",
    pavimento: "#b08a58", fuga: "#8a6a38", pavScuro: "#9a7748", pavChiaro: "#c8a068",
    legno: "#a0703a", legnoScuro: "#6e4826", legnoChiaro: "#c89858",
    pizzo: "#fdf8f0", pizzoOmbra: "#ded4c4",
    velluto: "#a04858", vellutoScuro: "#7a3040",
    plastica: "#dfe9ee",
    porcellana: "#f4f0e8", porcellanaBlu: "#6a8ac0",
    piastrella: "#bfe0d4", piastrellaFuga: "#98c4b4",
    rame: "#c07840", vetro: "#cfe4ee",
    tessuto: "#c8546a", tessutoChiaro: "#e0808f",
    lana1: "#d8a048", lana2: "#8aa8d0", lana3: "#c86a8a"
  };

  // ===== Palette SALA GIOCHI ANNI 80 (skin) =====
  // Moquette blu a stelline, neon rosa e ciano, cabinati. Tutto scuro tranne cio' che brilla.
  var A = {
    out: "#0e0a20",
    parete: "#2a1e52", fascia: "#3a2a72", pannello: "#241a48", giunto: "#160f30",
    battiscopa: "#160f30",
    pavimento: "#1e2a6a", fuga: "#141c48", pavScuro: "#18225a", pavChiaro: "#2a3a88",
    stella: "#f0e8ff",
    neonRosa: "#ff4aa0", neonCiano: "#40e8f0", neonGiallo: "#f8d838", neonVerde: "#5cf07a",
    cabinato: "#2e2258", cabinatoChiaro: "#463a80", schermo: "#0a0818",
    metallo: "#6a6a90", plastica: "#c8c8e0", rosso: "#e03a5a"
  };

  // ===== Palette DOJO (skin) =====
  // Carta di riso, listelli di legno scuro, tatami di paglia. Nessun colore acceso tranne il
  // rosso della bandiera: la calma e' il punto.
  var J = {
    out: "#2a1e14",
    parete: "#ece0c4", listello: "#5e402a", listelloChiaro: "#7a5638",
    battiscopa: "#402a18",
    pavimento: "#c8b878", fuga: "#8a7a48", pavScuro: "#b0a068", pavChiaro: "#dccc90",
    bordoTatami: "#2e4a2e",
    legno: "#6a4a2a", legnoScuro: "#402a18", legnoChiaro: "#8a6a42",
    rosso: "#b02828", rossoScuro: "#7a1c1c",
    carta: "#f4ece0", inchiostro: "#241810",
    acqua: "#7ab4c0", bambu: "#6a8a4a", corda: "#c8a868"
  };

  // ===== Palette FONDALE MARINO (skin) =====
  // Si chiama MR e non M perche' M e' GIA' la palette della MAPPA, dichiarata piu' in basso
  // nello stesso scope: con var vince la dichiarazione che viene eseguita dopo, quindi la mia
  // palette spariva e ogni colore diventava undefined. Il canvas allora IGNORA fillStyle e
  // tiene il nero di default: tutte e quattro le stanze uscivano NERE senza un solo errore.
  var MR = {
    out: "#08202c",
    parete: "#1a5a70", fascia: "#247a90", pannello: "#14485c", giunto: "#0e3646",
    battiscopa: "#0e3646",
    pavimento: "#d8c88a", fuga: "#b0a068", pavScuro: "#c4b478", pavChiaro: "#ece0aa",
    vetro: "#7ad8f0", ottone: "#c8a840", acqua: "#3ab0d0", acquaChiara: "#8ae8f8",
    alga: "#3a9a5a", algaChiara: "#5cc47a", corallo: "#e06a8a", coralloGiallo: "#f0a040",
    perla: "#f4f8ff", conchiglia: "#f0d8c0", bolla: "#b8f0ff", pesce: "#f08030"
  };

  // ===== Palette BAITA DI MONTAGNA (skin) =====
  var Q = {
    out: "#241810",
    tronco: "#8a5a32", troncoScuro: "#6e4626", troncoChiaro: "#a87246",
    battiscopa: "#4a2e1a",
    pavimento: "#7a5230", fuga: "#5a3a20", pavScuro: "#6a4628", pavChiaro: "#96663c",
    pietra: "#8a8a92", pietraScura: "#6a6a72",
    fuoco: "#f08030", brace: "#e04020", fiamma: "#f8d040",
    plaid: "#b03030", plaidChiaro: "#e0d0c0", pelliccia: "#c8b898",
    neve: "#eef6fc", cielo: "#a8c8e0", metallo: "#5a6068", legno: "#8a6a42"
  };

  // ===== Palette CASTELLO (skin) =====
  var K = {
    out: "#14141a",
    pietra: "#8a8a94", pietraScura: "#6e6e78", fuga: "#5a5a64",
    battiscopa: "#4a4a54",
    pavimento: "#7a7a86", pavFuga: "#5e5e68", pavScuro: "#6a6a76", pavChiaro: "#94949e",
    torcia: "#f0a030", fiamma: "#f8d040", ferro: "#4a4a56", ferroChiaro: "#6a6a78",
    stendardo: "#8a2038", oro: "#d8c060", legno: "#5a3a20", legnoChiaro: "#7a5230",
    tessuto: "#3a4a7a", pergamena: "#e8dcc0"
  };

  // ===== Palette BUNKER (skin) =====
  var Z = {
    out: "#0e1014",
    cemento: "#5a5e62", cementoScuro: "#464a4e", giunto: "#3a3e42",
    battiscopa: "#2e3236",
    pavimento: "#4e5256", fuga: "#3a3e42", pavScuro: "#42464a", pavChiaro: "#63676b",
    metallo: "#6a7078", metalloChiaro: "#8a9098", ruggine: "#8a5a30",
    emergenza: "#e03030", monitor: "#40d060", scatoletta: "#c0a860",
    nastro: "#c8c0a0", tubo: "#7a7060", vetro: "#9ab0b8"
  };

  // ===== Palette LAB (grigio-azzurro, mobili a contrasto) =====
  var L = {
    out: "#2b3640",
    parete: "#c9d6de", fascia: "#aebfc9", pannello: "#b7c7d0", giunto: "#9fb2bc",
    battiscopa: "#8fa0aa", pavimento: "#7d909b", fuga: "#65767f",
    // due toni in piu' per il pavimento profondo (v. pavimentoProfondo): una fascia piu' scura
    // subito sotto la parete (l'ombra dove il pavimento incontra il muro) e una piu' chiara sul
    // bordo vicino a chi guarda. Servono a dare profondita' restando nello stile PIATTO della
    // stanza: niente prospettiva, che qui stonerebbe.
    pavScuro: "#6e828d", pavChiaro: "#8b9ea8",
    piastrella: "#bdd6e0", piastrellaFuga: "#9dbcca",
    crema: "#f2ede0", cremaOmbra: "#b9b2a2",
    metallo: "#5c6b74", metalloScuro: "#3d4a54", metalloChiaro: "#8fa3ad",
    fuoco: "#1e2830", pentola: "#37424c",
    bancone: "#4a6a7a", banconeTop: "#6a8a9a",
    verde: "#5ce87f", ciano: "#4dd8e8", ambra: "#f0b84a", vetroRim: "#eef6f8",
    led: "#4be8c8",
    bianco: "#f4f6f2", acqua: "#5fd0f0", acquaChiara: "#b8ecf8",
    specchio: "#e4f2f8", riflesso: "#f8fdff", ceramica: "#dfe4e2",
    divano: "#4a7ba6", divanoChiaro: "#5c8db8", divanoScuro: "#3d6a92",
    cuscino1: "#f08a3c", cuscino2: "#3ad8c8",
    schermoFrame: "#1e2830", schermoOn: "#3fd8ea", schermoBar: "#12707e", schermoGlow: "#a8f0f8",
    tappeto: "#a05838", tappetoBordo: "#5c3020", tappetoRiga: "#c07a52",
    cielo: "#a9d9f2", nuvola: "#e8f6fc"
  };

  // ===== Palette SHIP (scuro, luci accese; parete/accento diversi per stanza) =====
  var S = {
    out: "#120e20",
    metallo: "#6a5fa0", metalloChiaro: "#8a7fc0",
    spazio: "#0d0a1c", stella: "#f0e8ff",
    ghiaccio: "#a8e0f0", brina: "#e8f8fc",
    mobiletto: "#3a2e5c", mobilettoTop: "#241c3c", sportello: "#312752",
    fuoco: "#120e20", fuocoGlow: "#e85ad8", pentola: "#463868",
    bancone: "#463868", banconeTop: "#5c4d88",
    verde: "#5ce87f", ciano: "#4dd8e8", ambra: "#f0b84a",
    acqua: "#4ac8e8", bolla: "#a8ecf8",
    specchio: "#cfeef8", riflesso: "#effcff",
    seduta: "#8a4ab0", sedutaBase: "#6a5fa0", glow: "#5ae8e0",
    cuscino1: "#4ae0d8", cuscino2: "#f0b84a",
    holoFrame: "#1a1430", holoOn: "#3ae0c8", holoBar: "#17705f", holoGlow: "#b8f8ec",
    pad: "#3a3060",
    ledM: "#e85ad8", ledC: "#5ae8e0", ledA: "#f0b84a",
    pianta: "#3f9c6a", piantaBulbo: "#e85ad8", piantaBulbo2: "#5ae8e0"
  };

  // pareti ship per stanza: cucina teal, bagno blu acqua, salone viola caldo/magenta
  var S_WALLS = {
    cucina: { parete: "#1c3a36", fascia: "#2e5c54", pannello: "#142a27", giunto: "#2e6660", battiscopa: "#0f211e", pavimento: "#16302c", fuga: "#2a544c", pavScuro: "#0f221f", pavChiaro: "#1d3d37" },
    bagno:  { parete: "#1c2a4a", fascia: "#2e4474", pannello: "#141f38", giunto: "#31497c", battiscopa: "#101a2e", pavimento: "#162138", fuga: "#293e64", pavScuro: "#101829", pavChiaro: "#1e2c48" },
    salone: { parete: "#3a2148", fascia: "#5c2e6e", pannello: "#2a1836", giunto: "#6e3a80", battiscopa: "#1c1026", pavimento: "#281732", fuga: "#472a56", pavScuro: "#1d1025", pavChiaro: "#33203f" }
  };

  // stelline deterministiche dentro un rettangolo di vetro già disegnato (pattern ripetuto ogni 18px)
  var STAR_PTS = [[2, 2], [6, 4], [10, 1], [3, 6], [8, 7], [12, 3], [5, 1], [11, 6], [15, 4], [14, 8], [7, 9], [1, 4], [17, 2], [16, 7]];
  function stars(g, x, y, w, h, col) {
    g.fillStyle = col;
    for (var ox = 0; ox < w; ox += 18) {
      STAR_PTS.forEach(function (p) {
        if (p[0] + ox < w && p[1] < h) g.fillRect(x + ox + p[0], y + p[1], 1, 1);
      });
    }
  }

  // oblò ship: cornice metallica + vetro nero spazio + stelle
  function oblo(g, x, y, w, h) {
    O(g, x, y, w, h, S.out, S.metalloChiaro);
    R(g, x + 2, y + 2, w - 4, h - 4, S.spazio);
    stars(g, x + 2, y + 2, w - 4, h - 4, S.stella);
  }

  // pannellino a muro ship con led colorati
  function ledPanel(g, x, y) {
    O(g, x, y, 9, 10, S.out, S.mobiletto);
    R(g, x + 2, y + 2, 2, 2, S.ledM);
    R(g, x + 5, y + 2, 2, 2, S.ledC);
    R(g, x + 2, y + 6, 2, 2, S.ledA);
  }

  // ===== Pavimento profondo (stanza 112x96) =====
  // Con il pavimento passato da 20 a 52px di altezza, riempirlo di tinta piatta lo faceva
  // sembrare un vuoto grigio. Qui gli si da' profondita' RESTANDO PIATTI (nessuna prospettiva:
  // la stanza e' disegnata di profilo e delle fughe che convergono stonerebbero), con tre
  // trucchi da pixel art:
  //  1. una fascia scura di 3px sotto la parete: e' l'ombra di contatto muro/pavimento, aggancia
  //     i mobili al terreno invece di lasciarli galleggiare;
  //  2. fughe orizzontali a passo CRESCENTE verso il basso (6,7,9,11,13...): l'occhio legge le
  //     righe piu' fitte come "lontane" e quelle larghe come "vicine" — profondita' a costo zero;
  //  3. una fascia chiara di 3px sul bordo inferiore: e' lo spigolo vicino a chi guarda, prende
  //     piu' luce e chiude la composizione.
  // Le fughe si fermano da sole prima del fondo, quindi la funzione va bene anche con la casa
  // ingrandita (H_GRANDE) senza toccare nulla.
  function pavimentoProfondo(g, pav, fuga, scuro, chiaro) {
    R(g, 0, WALL_H, W, H - WALL_H, pav);
    R(g, 0, WALL_H, W, 3, scuro);

    var passo = 6;
    var y = WALL_H + passo;
    while (y < H - 6) {
      R(g, 0, y, W, 1, fuga);
      passo += 2;
      y += passo;
    }

    R(g, 0, H - 3, W, 3, chiaro);
    R(g, 0, H - 4, W, 1, fuga);
  }

  // ===== Oggetti a terra del primo piano (stanza 112x96) =====
  // Il pavimento profondo da solo restava una distesa di tinta piatta. Questi sono i pezzi
  // disegnati a mano che lo abitano: stanno tutti nella fascia y 66..92, cioe' DAVANTI ai mobili
  // (che finiscono verso y=64) e attorno al pet (che cammina a y 76..92), cosi' la scena si legge
  // su tre piani: parete coi mobili, pavimento, primo piano. Le forme sono volutamente semplici e
  // con outline 1px come tutto il resto della stanza; i colori arrivano da fuori, cosi' la stessa
  // forma serve sia al tema lab sia al tema ship senza duplicare il disegno.

  // tappeto/tappetino: cornice interna (e' quella che lo fa leggere come tappeto e non come una
  // scatola piatta), campo, motivo a rombi al centro e frangia corta sul lato vicino
  function tappeto(g, x, y, w, h, out, base, riga, frangia) {
    O(g, x, y, w, h, out, base);
    R(g, x + 2, y + 2, w - 4, 1, riga);
    R(g, x + 2, y + h - 3, w - 4, 1, riga);
    R(g, x + 2, y + 3, 1, h - 6, riga);
    R(g, x + w - 3, y + 3, 1, h - 6, riga);
    var cy = y + Math.floor(h / 2);
    for (var d = x + 7; d < x + w - 7; d += 9) {
      R(g, d, cy, 3, 1, riga);
      R(g, d + 1, cy - 1, 1, 3, riga);
    }
    if (frangia) {
      for (var i = x + 3; i < x + w - 3; i += 4) R(g, i, y + h, 1, 1, frangia);
    }
  }

  // ciotola del pet: base stretta + scodella che si allarga verso l'alto (e' lo svaso che la fa
  // leggere come una ciotola invece che come una scatola), labbro chiaro e crocchette a monticello
  function ciotola(g, x, y, out, scodella, labbro, cibo, ombra) {
    R(g, x, y + 8, 14, 1, ombra);
    O(g, x + 3, y + 5, 8, 3, out, scodella);
    O(g, x + 1, y + 2, 12, 4, out, scodella);
    R(g, x + 2, y + 3, 10, 1, labbro);
    R(g, x + 4, y + 1, 6, 1, cibo);
    R(g, x + 3, y + 2, 8, 1, cibo);
    R(g, x + 6, y, 2, 1, cibo);
  }

  // pila di riviste/fumetti: tre dorsi sfalsati, il tocco "casa vissuta" del salone
  function pila(g, x, y, out, c1, c2, c3, ombra) {
    R(g, x - 1, y + 9, 18, 1, ombra);
    O(g, x, y + 6, 16, 3, out, c1);
    O(g, x + 1, y + 3, 14, 3, out, c2);
    O(g, x + 2, y, 12, 3, out, c3);
  }

  // cassa/contenitore d'angolo: doghe orizzontali e una spia accesa
  function cassa(g, x, y, out, base, chiaro, spia, ombra) {
    R(g, x - 1, y + 19, 22, 1, ombra);
    O(g, x, y, 20, 19, out, base);
    R(g, x + 2, y + 5, 16, 1, chiaro);
    R(g, x + 2, y + 12, 16, 1, chiaro);
    R(g, x + 15, y + 2, 3, 2, spia);
  }

  // papera/creaturina di gomma: corpo, testa, becco, occhio
  function papera(g, x, y, out, corpo, becco, occhio, ombra) {
    R(g, x - 1, y + 9, 13, 1, ombra);
    O(g, x, y + 4, 11, 6, out, corpo);
    O(g, x + 6, y, 5, 5, out, corpo);
    R(g, x + 10, y + 2, 2, 1, becco);
    R(g, x + 8, y + 1, 1, 1, occhio);
  }

  // paio di pantofole viste dall'alto: punta arrotondata (1px rientrato per lato) e apertura
  // scura sul tallone — senza quei due dettagli restano due quadrati e non si capisce cosa siano
  function pantofolaSingola(g, x, y, out, base, interno) {
    O(g, x + 1, y, 5, 2, out, base);
    O(g, x, y + 1, 7, 7, out, base);
    R(g, x + 2, y + 4, 3, 3, interno);
    R(g, x + 2, y + 3, 3, 1, out);
  }

  function pantofole(g, x, y, out, base, interno, ombra) {
    R(g, x - 1, y + 9, 18, 1, ombra);
    pantofolaSingola(g, x, y, out, base, interno);
    pantofolaSingola(g, x + 9, y + 1, out, base, interno);
  }

  // Composizione del primo piano, stanza per stanza e tema per tema. Le forme sono le stesse
  // (v. helper sopra), cambiano colori e disposizione: nel lab oggetti di casa in tinte calde che
  // staccano dal grigio-azzurro, nella ship gli stessi oggetti in versione tecnologica sui viola
  // e teal della navicella. Tutto sta a sinistra e a destra del centro: il centro resta libero
  // perche' e' li' che il pet passa piu' spesso.
  var PRIMO_PIANO = {
    lab: {
      cucina: function (g) {
        tappeto(g, 4, 76, 30, 13, L.out, L.tappeto, L.tappetoRiga, L.tappetoBordo);
        ciotola(g, 11, 79, L.out, L.metallo, L.metalloChiaro, L.ambra, L.fuga);
        cassa(g, 86, 70, L.out, L.metallo, L.metalloChiaro, L.verde, L.fuga);
      },
      bagno: function (g) {
        tappeto(g, 26, 74, 42, 15, L.out, L.acquaChiara, L.acqua, L.bianco);
        papera(g, 86, 78, L.out, L.ambra, "#e8722c", L.out, L.fuga);
        R(g, 78, 88, 2, 2, L.acqua);
        R(g, 82, 91, 2, 1, L.acqua);
        R(g, 74, 92, 1, 1, L.acqua);
      },
      salone: function (g) {
        // NIENTE tappeto qui: il salone ne ha gia' uno suo davanti al divano (v. labSalone) e
        // due tappeti in fila si leggevano come un errore. In primo piano ci va la roba che il
        // pet lascia in giro: pila di fumetti, pouf e il telecomando.
        pila(g, 14, 78, L.out, L.cuscino1, L.ciano, L.ambra, L.fuga);
        O(g, 40, 74, 22, 16, L.out, L.divano);
        R(g, 42, 76, 18, 2, L.divanoChiaro);
        R(g, 42, 86, 18, 2, L.divanoScuro);
        O(g, 94, 82, 12, 8, L.out, L.schermoFrame);
        R(g, 96, 84, 3, 2, L.schermoOn);
        R(g, 101, 84, 3, 2, L.ambra);
      },
      camera: function (g) {
        tappeto(g, 18, 72, 60, 18, L.out, L.divano, L.divanoChiaro, L.divanoScuro);
        pantofole(g, 88, 82, L.out, L.cuscino1, L.crema, L.fuga);
      }
    },
    mare: {
      cucina: function (g) {
        tappeto(g, 4, 76, 30, 13, MR.out, MR.acqua, MR.acquaChiara, MR.conchiglia);
        ciotola(g, 11, 79, MR.out, MR.conchiglia, MR.perla, MR.coralloGiallo, MR.pavScuro);
        cassa(g, 86, 70, MR.out, MR.corallo, MR.coralloGiallo, MR.perla, MR.pavScuro);
      },
      bagno: function (g) {
        tappeto(g, 26, 74, 42, 15, MR.out, MR.alga, MR.algaChiara, MR.conchiglia);
        papera(g, 86, 78, MR.out, MR.pesce, MR.coralloGiallo, MR.out, MR.pavScuro);
      },
      salone: function (g) {
        pila(g, 14, 78, MR.out, MR.corallo, MR.algaChiara, MR.coralloGiallo, MR.pavScuro);
        pantofole(g, 62, 84, MR.out, MR.conchiglia, MR.perla, MR.pavScuro);
      },
      camera: function (g) {
        tappeto(g, 30, 74, 40, 14, MR.out, MR.acqua, MR.acquaChiara, MR.perla);
        pantofole(g, 84, 84, MR.out, MR.corallo, MR.conchiglia, MR.pavScuro);
      }
    },
    baita: {
      cucina: function (g) {
        tappeto(g, 4, 76, 30, 13, Q.out, Q.plaid, Q.plaidChiaro, Q.pelliccia);
        ciotola(g, 11, 79, Q.out, Q.metallo, Q.pietra, Q.fuoco, Q.pavScuro);
        cassa(g, 86, 70, Q.out, Q.legno, Q.troncoChiaro, Q.fuoco, Q.pavScuro);
      },
      bagno: function (g) {
        tappeto(g, 26, 74, 42, 15, Q.out, Q.pelliccia, Q.plaidChiaro, Q.neve);
        papera(g, 86, 78, Q.out, Q.plaidChiaro, Q.fuoco, Q.out, Q.pavScuro);
      },
      salone: function (g) {
        tappeto(g, 20, 72, 54, 18, Q.out, Q.pelliccia, Q.plaidChiaro, Q.legno);
        pila(g, 84, 78, Q.out, Q.legno, Q.troncoScuro, Q.troncoChiaro, Q.pavScuro);
      },
      camera: function (g) {
        tappeto(g, 30, 74, 40, 14, Q.out, Q.plaid, Q.plaidChiaro, Q.pelliccia);
        pantofole(g, 84, 84, Q.out, Q.pelliccia, Q.plaidChiaro, Q.pavScuro);
      }
    },
    castello: {
      cucina: function (g) {
        tappeto(g, 4, 76, 30, 13, K.out, K.stendardo, K.oro, K.pergamena);
        ciotola(g, 11, 79, K.out, K.ferroChiaro, K.ferro, K.torcia, K.pavScuro);
        cassa(g, 86, 70, K.out, K.legno, K.legnoChiaro, K.oro, K.pavScuro);
      },
      bagno: function (g) {
        tappeto(g, 26, 74, 42, 15, K.out, K.tessuto, K.oro, K.pergamena);
        papera(g, 86, 78, K.out, K.pergamena, K.torcia, K.out, K.pavScuro);
      },
      salone: function (g) {
        tappeto(g, 20, 72, 54, 18, K.out, K.stendardo, K.oro, K.pergamena);
        pila(g, 84, 78, K.out, K.pergamena, K.tessuto, K.oro, K.pavScuro);
      },
      camera: function (g) {
        tappeto(g, 30, 74, 40, 14, K.out, K.tessuto, K.oro, K.pergamena);
        pantofole(g, 84, 84, K.out, K.legnoChiaro, K.pergamena, K.pavScuro);
      }
    },
    bunker: {
      cucina: function (g) {
        tappeto(g, 4, 76, 30, 13, Z.out, Z.cementoScuro, Z.nastro, Z.metallo);
        ciotola(g, 11, 79, Z.out, Z.metallo, Z.metalloChiaro, Z.scatoletta, Z.pavScuro);
        cassa(g, 86, 70, Z.out, Z.ruggine, Z.scatoletta, Z.emergenza, Z.pavScuro);
      },
      bagno: function (g) {
        tappeto(g, 26, 74, 42, 15, Z.out, Z.cementoScuro, Z.tubo, Z.metalloChiaro);
        papera(g, 86, 78, Z.out, Z.scatoletta, Z.emergenza, Z.out, Z.pavScuro);
      },
      salone: function (g) {
        pila(g, 14, 78, Z.out, Z.scatoletta, Z.ruggine, Z.nastro, Z.pavScuro);
        cassa(g, 84, 74, Z.out, Z.metallo, Z.metalloChiaro, Z.monitor, Z.pavScuro);
      },
      camera: function (g) {
        tappeto(g, 30, 74, 40, 14, Z.out, Z.cementoScuro, Z.tubo, Z.nastro);
        pantofole(g, 84, 84, Z.out, Z.tubo, Z.nastro, Z.pavScuro);
      }
    },
    arcade: {
      cucina: function (g) {
        tappeto(g, 4, 76, 30, 13, A.out, A.pannello, A.neonRosa, A.neonCiano);
        ciotola(g, 11, 79, A.out, A.plastica, A.metallo, A.neonGiallo, A.pavScuro);
        cassa(g, 86, 70, A.out, A.cabinato, A.cabinatoChiaro, A.neonVerde, A.pavScuro);
      },
      bagno: function (g) {
        tappeto(g, 26, 74, 42, 15, A.out, A.pannello, A.neonCiano, A.plastica);
        papera(g, 86, 78, A.out, A.neonGiallo, A.rosso, A.out, A.pavScuro);
      },
      salone: function (g) {
        pila(g, 14, 78, A.out, A.neonRosa, A.neonCiano, A.neonGiallo, A.pavScuro);
        cassa(g, 84, 74, A.out, A.cabinato, A.cabinatoChiaro, A.neonRosa, A.pavScuro);
      },
      camera: function (g) {
        tappeto(g, 30, 74, 40, 14, A.out, A.pannello, A.neonVerde, A.neonCiano);
        pantofole(g, 84, 84, A.out, A.neonRosa, A.plastica, A.pavScuro);
      }
    },
    dojo: {
      cucina: function (g) {
        tappeto(g, 4, 76, 30, 13, J.out, J.legnoChiaro, J.rosso, J.corda);
        ciotola(g, 11, 79, J.out, J.carta, J.legnoChiaro, J.bambu, J.pavScuro);
        cassa(g, 86, 70, J.out, J.legno, J.legnoChiaro, J.rosso, J.pavScuro);
      },
      bagno: function (g) {
        tappeto(g, 26, 74, 42, 15, J.out, J.legnoChiaro, J.acqua, J.carta);
        papera(g, 86, 78, J.out, J.carta, J.rosso, J.out, J.pavScuro);
      },
      salone: function (g) {
        pila(g, 14, 78, J.out, J.carta, J.rosso, J.legnoChiaro, J.pavScuro);
        pantofole(g, 62, 84, J.out, J.legnoScuro, J.carta, J.pavScuro);
      },
      camera: function (g) {
        tappeto(g, 30, 74, 40, 14, J.out, J.legnoChiaro, J.bordoTatami, J.corda);
        pantofole(g, 84, 84, J.out, J.legno, J.carta, J.pavScuro);
      }
    },
    nonna: {
      cucina: function (g) {
        tappeto(g, 4, 76, 30, 13, N.out, N.tessuto, N.tessutoChiaro, N.pizzo);
        ciotola(g, 11, 79, N.out, N.porcellana, N.porcellanaBlu, N.rame, N.pavScuro);
        cassa(g, 86, 70, N.out, N.legno, N.legnoChiaro, N.ottone, N.pavScuro);
      },
      bagno: function (g) {
        tappeto(g, 26, 74, 42, 15, N.out, N.piastrella, N.piastrellaFuga, N.pizzo);
        papera(g, 86, 78, N.out, "#f0d040", "#e08020", N.out, N.pavScuro);
      },
      salone: function (g) {
        pila(g, 14, 78, N.out, N.lana1, N.lana2, N.lana3, N.pavScuro);
        pantofole(g, 62, 84, N.out, N.tessuto, N.pizzo, N.pavScuro);
      },
      camera: function (g) {
        tappeto(g, 30, 74, 40, 14, N.out, N.velluto, N.vellutoScuro, N.pizzo);
        pantofole(g, 84, 84, N.out, N.tessutoChiaro, N.pizzo, N.pavScuro);
      }
    },
    ship: {
      cucina: function (g) {
        var wp = S_WALLS.cucina;
        tappeto(g, 4, 76, 30, 13, S.out, wp.giunto, S.ledA || wp.fascia, wp.pavScuro);
        ciotola(g, 11, 79, S.out, S.metallo, S.metalloChiaro, "#5ce87f", wp.pavScuro);
        cassa(g, 86, 70, S.out, S.metallo, S.metalloChiaro, "#4dd8e8", wp.pavScuro);
      },
      bagno: function (g) {
        var wp = S_WALLS.bagno;
        tappeto(g, 26, 74, 42, 15, S.out, wp.giunto, wp.fascia, S.metalloChiaro);
        papera(g, 86, 78, S.out, "#5ce87f", "#3ad8c8", S.out, wp.pavScuro);
        R(g, 78, 88, 2, 2, wp.fascia);
        R(g, 82, 91, 2, 1, wp.fascia);
        R(g, 74, 92, 1, 1, wp.fascia);
      },
      salone: function (g) {
        // come nel lab: qui il tappeto c'e' gia' (shipSalone), quindi primo piano di oggetti
        var wp = S_WALLS.salone;
        pila(g, 14, 78, S.out, "#e85ad8", "#5ae8e0", "#f0b84a", wp.pavScuro);
        O(g, 40, 74, 22, 16, S.out, S.metallo);
        R(g, 42, 76, 18, 2, S.metalloChiaro);
        R(g, 42, 86, 18, 2, wp.pavScuro);
        O(g, 94, 82, 12, 8, S.out, S.metallo);
        R(g, 96, 84, 3, 2, "#4dd8e8");
        R(g, 101, 84, 3, 2, "#f0b84a");
      },
      camera: function (g) {
        var wp = S_WALLS.salone;
        tappeto(g, 18, 72, 60, 18, S.out, wp.pannello, wp.giunto, wp.fascia);
        pantofole(g, 88, 82, S.out, S.metallo, "#8a7fc0", wp.pavScuro);
      }
    }
  };

  function disegnaPrimoPiano(g, tema, stanza) {
    var perTema = PRIMO_PIANO[tema];
    if (!perTema) return;
    var fn = perTema[stanza];
    if (fn) fn(g);
  }

  // ===== Pareti e pavimenti =====
  function labWall(g, tiles) {
    R(g, 0, 0, W, WALL_H, L.parete);
    R(g, 0, 4, W, 2, L.fascia);
    if (tiles) {
      R(g, 0, 24, W, 18, L.piastrella);
      R(g, 0, 32, W, 1, L.piastrellaFuga);
      for (var x = 10; x < W; x += 10) R(g, x, 24, 1, 18, L.piastrellaFuga);
    } else {
      R(g, 0, 34, W, 8, L.pannello);
      for (var j = 14; j < W; j += 14) R(g, j, 34, 1, 8, L.giunto);
    }
    R(g, 0, 42, W, 2, L.battiscopa);
    pavimentoProfondo(g, L.pavimento, L.fuga, L.pavScuro, L.pavChiaro);
  }

  function shipWall(g, wp) {
    R(g, 0, 0, W, WALL_H, wp.parete);
    R(g, 0, 4, W, 2, wp.fascia);
    R(g, 0, 34, W, 8, wp.pannello);
    for (var j = 14; j < W; j += 14) R(g, j, 34, 1, 8, wp.giunto);
    R(g, 0, 42, W, 2, wp.battiscopa);
    pavimentoProfondo(g, wp.pavimento, wp.fuga, wp.pavScuro, wp.pavChiaro);
    // Le tre fughe VERTICALI restano una firma del tema ship (piastroni metallici della navicella),
    // ma si fermano prima dello spigolo chiaro in basso, se no lo taglierebbero in tre.
    R(g, 28, WALL_H + 3, 1, H - WALL_H - 7, wp.fuga);
    R(g, 56, WALL_H + 3, 1, H - WALL_H - 7, wp.fuga);
    R(g, 84, WALL_H + 3, 1, H - WALL_H - 7, wp.fuga);
  }

  // tre provette/contenitori colorati in piedi su un piano (topY = y del piano d'appoggio)
  function provette(g, xs, topY, rimCol) {
    var cols = [L.verde, L.ciano, L.ambra];
    for (var i = 0; i < 3; i++) {
      R(g, xs[i], topY - 9, 3, 1, rimCol);
      R(g, xs[i], topY - 8, 3, 8, cols[i]);
    }
  }

  // ===== LAB (slot: mobili ai lati, centro libero) =====
  function labCucina(g) {
    labWall(g, false);
    // finestra piccola al centro parete (dettaglio)
    O(g, 56, 8, 20, 14, L.out, L.cielo);
    R(g, 65, 9, 1, 12, L.out);
    R(g, 59, 12, 4, 1, L.nuvola);
    // frigo crema a sinistra, con split freezer e maniglie
    O(g, 6, 12, 16, 32, L.out, L.crema);
    R(g, 7, 22, 14, 1, L.cremaOmbra);
    R(g, 18, 15, 1, 4, L.out);
    R(g, 18, 25, 1, 6, L.out);
    // bancone con provette accanto al frigo
    O(g, 26, 32, 26, 12, L.out, L.bancone);
    R(g, 27, 33, 24, 2, L.banconeTop);
    provette(g, [30, 36, 42], 33, L.vetroRim);
    // fornelli a destra: 2 fuochi scuri + pentola + forno, led sopra
    R(g, 80, 16, 24, 2, L.out);
    R(g, 81, 17, 22, 1, L.led);
    O(g, 78, 26, 28, 18, L.out, L.metallo);
    R(g, 79, 27, 26, 4, L.metalloScuro);
    R(g, 82, 28, 6, 2, L.fuoco);
    R(g, 94, 28, 6, 2, L.fuoco);
    R(g, 92, 21, 9, 5, L.pentola);
    R(g, 93, 20, 7, 1, L.metalloChiaro);
    R(g, 96, 19, 1, 1, L.fuoco);
    R(g, 82, 33, 20, 9, "#4a5762");
    R(g, 86, 35, 10, 4, "#252f38");
    R(g, 82, 32, 20, 1, L.metalloChiaro);
    // mensolina collezione sopra i fornelli (slot cucina[0], v. SLOT_SPOTS.cucina [84,2])
    mensolina(g, 84, 16, "lab");
  }

  function labBagno(g) {
    labWall(g, true);
    // infermeria: kit medico a muro nell'angolo in alto a sinistra (croce rossa)
    O(g, 6, 10, 12, 10, L.out, L.bianco);
    R(g, 11, 12, 2, 6, "#d84040");
    R(g, 9, 14, 6, 2, "#d84040");
    // specchio bordato con riflesso + led sopra (destra)
    R(g, 84, 4, 14, 2, L.out);
    R(g, 85, 5, 12, 1, L.led);
    O(g, 80, 8, 22, 14, L.out, L.specchio);
    R(g, 84, 10, 3, 8, L.riflesso);
    // lavandino con rubinetto e colonna (destra)
    R(g, 88, 26, 5, 1, L.pentola);
    R(g, 89, 27, 2, 3, L.pentola);
    O(g, 80, 30, 24, 8, L.out, L.bianco);
    O(g, 86, 38, 12, 10, L.out, L.ceramica);
    // vasca a sinistra: acqua celeste, rubinetto a muro, piedini
    R(g, 38, 20, 2, 8, L.pentola);
    R(g, 34, 20, 5, 2, L.pentola);
    R(g, 34, 24, 1, 3, L.acqua);
    O(g, 4, 28, 40, 16, L.out, L.bianco);
    R(g, 6, 30, 36, 6, L.acqua);
    R(g, 9, 31, 6, 1, L.acquaChiara);
    R(g, 21, 31, 6, 1, L.acquaChiara);
    R(g, 32, 31, 5, 1, L.acquaChiara);
    R(g, 7, 44, 4, 3, L.out);
    R(g, 37, 44, 4, 3, L.out);
  }

  function labSalone(g) {
    labWall(g, false);
    // targa a muro sopra il divano (dettaglio)
    O(g, 10, 8, 14, 8, L.out, L.metalloChiaro);
    R(g, 12, 10, 10, 1, L.parete);
    R(g, 12, 13, 7, 1, L.parete);
    // schermo a muro acceso con "grafico" (destra)
    O(g, 58, 8, 46, 22, L.out, L.schermoFrame);
    R(g, 60, 10, 42, 18, L.schermoOn);
    R(g, 60, 10, 42, 1, L.schermoGlow);
    R(g, 64, 20, 6, 6, L.schermoBar);
    R(g, 74, 16, 6, 10, L.schermoBar);
    R(g, 84, 12, 6, 14, L.schermoBar);
    // divano a sinistra: schienale + 2 cuscini accento + seduta + braccioli + piedini
    O(g, 6, 22, 38, 10, L.out, L.divano);
    O(g, 10, 24, 14, 8, L.out, L.cuscino1);
    O(g, 26, 24, 14, 8, L.out, L.cuscino2);
    O(g, 4, 30, 42, 10, L.out, L.divano);
    R(g, 5, 36, 40, 2, L.divanoChiaro);
    O(g, 4, 26, 6, 14, L.out, L.divanoScuro);
    O(g, 40, 26, 6, 14, L.out, L.divanoScuro);
    R(g, 6, 40, 3, 3, L.out);
    R(g, 41, 40, 3, 3, L.out);
    // tappeto a pavimento
    O(g, 18, 48, 50, 12, L.tappetoBordo, L.tappeto);
    R(g, 20, 51, 46, 1, L.tappetoRiga);
    R(g, 20, 56, 46, 1, L.tappetoRiga);
    mensolaSalone(g, "lab");
  }

  // Camera da letto (GDD "Casa" -> camera, playtest 4 lug 2026): 4a stanza, il letto qui
  // e' GRANDE e protagonista (era troppo piccolo nel salone). Comodino a fianco, finestra
  // sopra la testiera.
  // Rettangoli letto (anche hotzone drag per la UI, pattern HOTZONE_VASCA): generosi,
  // protagonisti della scena, forma diversa per lab (capsula medicale) e ship (cupola).
  var LETTO_LAB_CAMERA = { x: 14, y: 20, w: 40, h: 30 };
  var LETTO_SHIP_CAMERA = { x: 14, y: 18, w: 40, h: 32 };

  // Scrivania del diario (PROTOTIPO-2.md punto 6 "Diario in camera"): mobile a pavimento
  // nell'angolo LIBERO a sinistra del letto (il letto inizia a x=14, room x=0..112). Zona
  // scelta apposta per non sovrapporsi MAI col rettangolo del pet (hotzone tap, non solo
  // grafica): il pet in camera sta a x40-72/y28-60 da fermo, e puo' arrivare fino a x24-88
  // durante l'idle action "corre per casa" dello sportivo (v. ui.js posizionePet/
  // IDLE_ACTIONS) — x0-14 resta sempre fuori da entrambi i range. Niente sovrapposizioni
  // nemmeno con LETTO_*_CAMERA (inizia a x=14) ne' con SLOT_SPOTS.camera ([96,46] pavimento,
  // [58,4] muro). Stessa hotzone per lab/ship (solo lo stile del mobile cambia).
  var SCRIVANIA_CAMERA = { x: 0, y: 46, w: 14, h: 18 };

  // Frigo in cucina (GDD "Economia" -> "Spesa e dispensa"): hotzone tap sul frigo/capsula
  // criogenica gia' disegnati da labCucina/shipCucina, coordinate del rettangolo del mobile
  // (con un margine generoso applicato dalla UI in fase di hit-test, stesso pattern hotzone
  // vasca/letto). Esposta come _frigoZona per tema cosi' ui.js puo' fare hit-test sul tap.
  var FRIGO_LAB_CUCINA = { x: 6, y: 12, w: 16, h: 32 };
  var FRIGO_SHIP_CUCINA = { x: 6, y: 10, w: 16, h: 34 };

  function labCameraLetto(g) {
    var r = LETTO_LAB_CAMERA;
    // gambe/base capsula
    R(g, r.x + 2, r.y + r.h - 4, 3, 4, L.metalloScuro);
    R(g, r.x + r.w - 5, r.y + r.h - 4, 3, 4, L.metalloScuro);
    // scocca della capsula medicale, ampia e accogliente
    O(g, r.x, r.y + 4, r.w, r.h - 8, L.out, L.metallo);
    R(g, r.x + 2, r.y + 6, r.w - 4, r.h - 14, L.metalloChiaro);
    // cupola/vetro superiore semiaperta
    O(g, r.x + 4, r.y, r.w - 8, 10, L.out, L.specchio);
    R(g, r.x + 6, r.y + 2, r.w - 16, 3, L.riflesso);
    // cuscino + coperta ben visibili dentro la capsula
    O(g, r.x + 4, r.y + 9, 12, 7, L.out, L.crema);
    R(g, r.x + 4, r.y + 16, r.w - 8, r.h - 22, L.divano);
    R(g, r.x + 4, r.y + 16, r.w - 8, 2, L.divanoChiaro);
    // led di stato sulla scocca
    R(g, r.x + 3, r.y + r.h - 10, 3, 2, L.led);
  }
  // Scrivania lab: piano metallico su gambe, lampada da tavolo + foglio/diario appoggiato
  // (indizio visivo del suo uso, GDD "Diario in camera": qui il pet "va a scrivere"). Mobile
  // compatto (14x18, v. SCRIVANIA_CAMERA) nell'angolo libero a sinistra del letto.
  function labScrivania(g) {
    var r = SCRIVANIA_CAMERA;
    // gambe
    R(g, r.x + 1, r.y + 9, 2, r.h - 9, L.metalloScuro);
    R(g, r.x + r.w - 3, r.y + 9, 2, r.h - 9, L.metalloScuro);
    // piano
    O(g, r.x, r.y + 5, r.w, 5, L.out, L.metallo);
    R(g, r.x + 1, r.y + 6, r.w - 2, 1, L.metalloChiaro);
    // foglio/diario aperto sul piano
    O(g, r.x + 2, r.y, 7, 5, L.out, L.crema);
    R(g, r.x + 3, r.y + 1, 5, 1, L.cremaOmbra);
    R(g, r.x + 3, r.y + 3, 3, 1, L.cremaOmbra);
    // lampada da tavolo
    R(g, r.x + r.w - 5, r.y - 5, 2, 5, L.metalloScuro);
    O(g, r.x + r.w - 7, r.y - 8, 6, 4, L.out, L.ambra);
  }

  function labCamera(g) {
    labWall(g, false);
    // finestra sopra la testiera del letto
    O(g, 6, 6, 20, 14, L.out, L.cielo);
    R(g, 15, 7, 1, 12, L.out);
    R(g, 9, 10, 4, 1, L.nuvola);
    labCameraLetto(g);
    // comodino a fianco del letto con lampada
    O(g, 78, 30, 16, 14, L.out, L.crema);
    R(g, 79, 36, 14, 1, L.cremaOmbra);
    R(g, 83, 22, 2, 8, L.metalloScuro);
    O(g, 80, 18, 8, 6, L.out, L.ambra);
    // scrivania del diario, tra letto e comodino (GDD "Diario in camera")
    labScrivania(g);
    // mensolina collezione a sinistra, sopra la testiera (slot camera[0], v. SLOT_SPOTS.camera [28,4])
    mensolina(g, 28, 18, "lab");
    // oggetti sulla mensola/comodino: spazio slot pavimento+muro gestito da SLOT_SPOTS.camera
  }

  // Letto ship-camera: capsula cupola sospesa, piu' grande della versione salone precedente
  function shipCameraLetto(g) {
    var r = LETTO_SHIP_CAMERA;
    // base/piedistallo
    R(g, r.x + 3, r.y + r.h - 5, r.w - 6, 5, S.mobiletto);
    R(g, r.x + 5, r.y + r.h - 3, r.w - 10, 2, S.mobilettoTop);
    // scocca capsula-navicella
    O(g, r.x, r.y + 3, r.w, r.h - 10, S.out, S.metallo);
    R(g, r.x + 2, r.y + 5, r.w - 4, r.h - 16, S.mobiletto);
    // cupola trasparente in cima, con stelle
    O(g, r.x + 5, r.y, r.w - 10, 9, S.out, S.metalloChiaro);
    R(g, r.x + 7, r.y + 1, r.w - 14, 6, S.spazio);
    stars(g, r.x + 7, r.y + 1, r.w - 14, 6, S.stella);
    // giaciglio energetico interno + led
    R(g, r.x + 4, r.y + 12, r.w - 8, r.h - 20, S.sportello);
    R(g, r.x + 5, r.y + 13, 4, 2, S.ledC);
    R(g, r.x + r.w - 9, r.y + r.h - 9, 4, 2, S.ledM);
  }
  // Scrivania ship: consolle sospesa luminosa con schermo/tavoletta al posto del foglio e
  // pannellino led al posto della lampada (stesso ingombro/hotzone di labScrivania). Mobile
  // compatto (14x18, v. SCRIVANIA_CAMERA) nell'angolo libero a sinistra del letto.
  function shipScrivania(g) {
    var r = SCRIVANIA_CAMERA;
    // base/gambe
    R(g, r.x + 1, r.y + 9, 2, r.h - 9, S.mobiletto);
    R(g, r.x + r.w - 3, r.y + 9, 2, r.h - 9, S.mobiletto);
    // piano luminoso
    O(g, r.x, r.y + 5, r.w, 5, S.out, S.mobiletto);
    R(g, r.x + 1, r.y + 6, r.w - 2, 1, S.glow);
    // tavoletta/schermo con "pagina" del diario accesa
    O(g, r.x + 2, r.y, 7, 5, S.out, S.mobilettoTop);
    R(g, r.x + 3, r.y + 1, 5, 1, S.glow);
    R(g, r.x + 3, r.y + 3, 3, 1, S.glow);
    // pannellino led sospeso (ledPanel e' 9x10: alziamolo un po' per non sforare il muro sopra)
    ledPanel(g, r.x + r.w - 9, r.y - 9);
  }

  function shipCamera(g) {
    shipWall(g, S_WALLS.salone);
    oblo(g, 8, 6, 18, 13);
    shipCameraLetto(g);
    // comodino luminoso a fianco
    O(g, 78, 30, 16, 14, S.out, S.mobiletto);
    R(g, 80, 36, 12, 1, S.glow);
    ledPanel(g, 82, 18);
    // scrivania del diario, tra letto e comodino (GDD "Diario in camera")
    shipScrivania(g);
    // mensolina collezione a sinistra, sopra la testiera (slot camera[0], v. SLOT_SPOTS.camera [28,4])
    mensolina(g, 28, 18, "ship");
    // oggetti sulla mensola/comodino: spazio slot pavimento+muro gestito da SLOT_SPOTS.camera
  }

  // Mensola a muro del salone + zona ganci/quadri accanto (supporti collezione, GDD -> Casa).
  // Ripiano oggetti a y14-16 (lo slot "mensola" appoggia qui), ripiano decorativo sotto a y19-21.
  function mensolaSalone(g, tema) {
    if (tema === "lab") {
      // mensola metallica con montanti e staffe
      R(g, 25, 14, 16, 2, L.metalloChiaro);
      R(g, 25, 16, 16, 1, L.out);
      R(g, 25, 19, 16, 2, L.metalloChiaro);
      R(g, 25, 21, 16, 1, L.out);
      R(g, 25, 14, 1, 8, L.metalloScuro); // montanti
      R(g, 40, 14, 1, 8, L.metalloScuro);
      // mini-libri decorativi sul ripiano basso
      R(g, 28, 16, 2, 3, "#c22a3a");
      R(g, 31, 16, 2, 3, "#4a7ba6");
      R(g, 35, 17, 3, 2, "#f0b84a");
      // ganci a muro accanto (zona quadri)
      R(g, 44, 6, 2, 2, L.metalloScuro);
      R(g, 49, 6, 2, 2, L.metalloScuro);
    } else {
      // mensola fluttuante luminosa (niente montanti, glow sotto i ripiani)
      R(g, 25, 14, 16, 2, S.metalloChiaro);
      R(g, 25, 16, 16, 1, S.glow);
      R(g, 25, 19, 16, 2, S.metalloChiaro);
      R(g, 25, 21, 16, 1, S.glow);
      R(g, 28, 16, 2, 3, "#4ae0d8"); // mini-oggetti luminosi
      R(g, 31, 16, 2, 3, "#e85ad8");
      R(g, 35, 17, 3, 2, "#f0b84a");
      R(g, 44, 6, 2, 2, S.metalloChiaro); // ganci
      R(g, 49, 6, 2, 2, S.metalloChiaro);
    }
  }

  // Mensolina generica a muro (PROTOTIPO 2, Blocco 7): ripiano sottile su cui appoggia lo slot
  // "mensola" di cucina/camera. Il piano d'appoggio sta al bordo BASSO del footprint 14x14 dello
  // slot (l'arredo viene disegnato con top-left = coordinata slot, alto ~14px): plane = slotY+14.
  // Stile per tema come mensolaSalone (montanti metallici lab, glow fluttuante ship).
  function mensolina(g, x, planeY, tema) {
    if (tema === "lab") {
      R(g, x, planeY - 2, 14, 2, L.metalloChiaro);
      R(g, x, planeY, 14, 1, L.out);
      R(g, x, planeY - 6, 1, 6, L.metalloScuro); // montanti
      R(g, x + 13, planeY - 6, 1, 6, L.metalloScuro);
    } else if (tema === "mare") {
      R(g, x, planeY - 2, 14, 2, MR.conchiglia);
      R(g, x, planeY, 14, 1, MR.out);
    } else if (tema === "baita") {
      R(g, x, planeY - 2, 14, 2, Q.legno);
      R(g, x, planeY, 14, 1, Q.troncoScuro);
    } else if (tema === "castello") {
      R(g, x, planeY - 2, 14, 2, K.legno);
      R(g, x, planeY, 14, 1, K.ferro);
    } else if (tema === "bunker") {
      R(g, x, planeY - 2, 14, 2, Z.metallo);
      R(g, x, planeY, 14, 1, Z.giunto);
    } else if (tema === "arcade") {
      R(g, x, planeY - 2, 14, 2, A.cabinatoChiaro);
      R(g, x, planeY, 14, 1, A.neonCiano);
    } else if (tema === "dojo") {
      R(g, x, planeY - 2, 14, 2, J.legno);
      R(g, x, planeY, 14, 1, J.legnoScuro);
    } else if (tema === "nonna") {
      R(g, x, planeY - 2, 14, 2, N.legno);
      R(g, x, planeY, 14, 1, N.out);
      R(g, x, planeY + 1, 14, 1, N.pizzo); // mantovanina di pizzo sotto la mensola
    } else {
      R(g, x, planeY - 2, 14, 2, S.metalloChiaro);
      R(g, x, planeY, 14, 1, S.glow);
    }
  }

  // ===== SHIP (stessi slot, skin sci-fi; oblò con stelle e palette parete diversa in ogni stanza) =====
  function shipCucina(g) {
    shipWall(g, S_WALLS.cucina);
    oblo(g, 56, 6, 24, 16);
    ledPanel(g, 42, 10);
    // distintivo cucina: tubo dispenser del cibo dal soffitto al bancone, con pellet in caduta
    O(g, 28, 0, 10, 31, S.out, S.metallo);
    R(g, 30, 2, 6, 27, S.ghiaccio);
    R(g, 32, 6, 2, 2, "#a8743c");
    R(g, 31, 13, 2, 2, "#c04a3c");
    R(g, 33, 20, 2, 2, "#a8743c");
    O(g, 26, 29, 14, 4, S.out, S.metalloChiaro);
    // capsula criogenica (frigo): vetro ghiaccio + brina + base con led
    O(g, 6, 10, 16, 34, S.out, S.metallo);
    R(g, 8, 12, 12, 24, S.ghiaccio);
    R(g, 10, 15, 3, 1, S.brina);
    R(g, 15, 20, 3, 1, S.brina);
    R(g, 11, 28, 4, 1, S.brina);
    R(g, 8, 37, 12, 5, S.bancone);
    R(g, 9, 39, 3, 1, S.ledC);
    R(g, 14, 39, 3, 1, S.ledM);
    R(g, 19, 20, 1, 5, S.out);
    // bancone con contenitori luminosi
    O(g, 26, 32, 26, 12, S.out, S.bancone);
    R(g, 27, 33, 24, 2, S.banconeTop);
    provette(g, [30, 36, 42], 33, S.brina);
    // fornelli sci-fi a destra: 2 fuochi con glow magenta + pentola
    O(g, 78, 26, 28, 18, S.out, S.mobiletto);
    R(g, 79, 27, 26, 4, S.mobilettoTop);
    R(g, 82, 28, 6, 2, S.fuoco);
    R(g, 83, 28, 4, 1, S.fuocoGlow);
    R(g, 94, 28, 6, 2, S.fuoco);
    R(g, 95, 28, 4, 1, S.fuocoGlow);
    R(g, 92, 21, 9, 5, S.pentola);
    R(g, 93, 20, 7, 1, S.metalloChiaro);
    R(g, 82, 33, 20, 9, S.sportello);
    R(g, 86, 35, 10, 4, S.out);
    R(g, 82, 32, 20, 1, S.metalloChiaro);
    // mensolina collezione sopra i fornelli (slot cucina[0], v. SLOT_SPOTS.cucina [84,2])
    mensolina(g, 84, 16, "ship");
  }

  function shipBagno(g) {
    shipWall(g, S_WALLS.bagno);
    oblo(g, 10, 6, 20, 13);
    // distintivo bagno: capsula-doccia a tubo al centro (vetro + gocce + base)
    O(g, 48, 10, 16, 6, S.out, S.metalloChiaro);
    O(g, 50, 15, 12, 26, S.out, "#bfe8f4");
    R(g, 54, 19, 1, 3, S.acqua);
    R(g, 58, 24, 1, 3, S.acqua);
    R(g, 55, 30, 1, 3, S.acqua);
    R(g, 59, 35, 1, 2, S.acqua);
    O(g, 48, 40, 16, 4, S.out, S.metallo);
    // pannellino led tra doccia e specchio
    O(g, 68, 24, 9, 10, S.out, S.mobiletto);
    R(g, 70, 26, 2, 2, S.ledM);
    R(g, 73, 26, 2, 2, S.ledC);
    R(g, 70, 30, 2, 2, S.ledA);
    // specchio sci-fi (destra)
    O(g, 82, 8, 20, 13, S.out, S.specchio);
    R(g, 86, 10, 3, 7, S.riflesso);
    // lavandino: vaschetta ghiaccio + colonna metallica + rubinetto
    R(g, 89, 26, 5, 1, S.metalloChiaro);
    R(g, 90, 27, 2, 3, S.metalloChiaro);
    O(g, 82, 30, 22, 8, S.out, S.ghiaccio);
    O(g, 88, 38, 12, 10, S.out, S.metallo);
    // infermeria: capsula rigenerante compatta nell'angolo destro (croce verde luminosa)
    O(g, 104, 24, 7, 20, S.out, S.metallo);
    R(g, 105, 27, 5, 8, S.ghiaccio);
    R(g, 107, 37, 1, 4, "#4ae08a");
    R(g, 106, 38, 3, 2, "#4ae08a");
    // vasca a bolle a sinistra, con oblò sul fianco
    O(g, 4, 26, 40, 18, S.out, S.metallo);
    R(g, 6, 28, 36, 7, S.acqua);
    R(g, 10, 29, 3, 2, S.bolla);
    R(g, 20, 30, 2, 2, S.bolla);
    R(g, 30, 29, 3, 2, S.bolla);
    R(g, 12, 22, 2, 2, S.bolla);
    R(g, 24, 21, 2, 2, S.bolla);
    R(g, 34, 23, 1, 1, S.bolla);
    O(g, 18, 36, 10, 6, S.out, S.spazio);
    R(g, 21, 38, 3, 1, S.acqua);
  }

  function shipSalone(g) {
    shipWall(g, S_WALLS.salone);
    ledPanel(g, 10, 8);
    // distintivo salone: schermo panoramico stellare gigante (è anche l'oblò della stanza)
    oblo(g, 52, 6, 56, 22);
    // distintivo salone: pianta aliena in vaso (steli + bulbi luminosi)
    R(g, 99, 38, 2, 13, S.pianta);
    R(g, 103, 32, 2, 19, S.pianta);
    R(g, 95, 42, 2, 9, S.pianta);
    R(g, 98, 35, 4, 4, S.piantaBulbo);
    R(g, 102, 29, 4, 4, S.piantaBulbo);
    R(g, 94, 39, 4, 4, S.piantaBulbo2);
    O(g, 94, 50, 14, 8, S.out, S.pentola);
    // seduta futuristica a sinistra: schienale viola + 2 cuscini + base con striscia glow
    O(g, 6, 22, 38, 10, S.out, S.seduta);
    O(g, 10, 24, 14, 8, S.out, S.cuscino1);
    O(g, 26, 24, 14, 8, S.out, S.cuscino2);
    O(g, 4, 30, 42, 10, S.out, S.sedutaBase);
    R(g, 5, 37, 40, 1, S.glow);
    // pad luminoso a pavimento (tappeto)
    O(g, 18, 48, 50, 12, S.out, S.pad);
    R(g, 20, 49, 46, 1, S.glow);
    R(g, 20, 58, 46, 1, S.glow);
    mensolaSalone(g, "ship");
  }

  // ===== CASA DELLA NONNA =====
  // Parete: carta da parati a fiorellini con il motivo sfalsato a righe alterne (come la carta
  // vera), guida per i quadri in ottone in alto, battiscopa di legno.
  function nonnaWall(g, piastrelle) {
    R(g, 0, 0, W, WALL_H, N.parete);
    var riga = 0;
    for (var y = 8; y < WALL_H - 8; y += 11) {
      for (var x = (riga % 2 === 0) ? 6 : 13; x < W - 2; x += 14) {
        R(g, x, y, 2, 2, N.fiore);
        R(g, x - 1, y + 1, 1, 1, N.fiore);
        R(g, x + 2, y + 1, 1, 1, N.fiore);
        R(g, x, y + 3, 1, 1, N.foglia);
      }
      riga++;
    }
    if (piastrelle) {
      // bagno: mezza parete piastrellata verde acqua, il resto resta carta da parati
      R(g, 0, 24, W, 18, N.piastrella);
      R(g, 0, 32, W, 1, N.piastrellaFuga);
      for (var t = 10; t < W; t += 10) R(g, t, 24, 1, 18, N.piastrellaFuga);
    }
    R(g, 0, 3, W, 1, N.ottone);
    R(g, 0, 42, W, 2, N.battiscopa);
    pavimentoProfondo(g, N.pavimento, N.fuga, N.pavScuro, N.pavChiaro);
  }

  function nonnaCucina(g) {
    nonnaWall(g, false);
    // credenza col servizio buono in mostra e il centrino sopra
    R(g, 8, 6, 22, 2, N.pizzo);
    O(g, 4, 8, 30, 36, N.out, N.legno);
    R(g, 5, 9, 28, 2, N.legnoChiaro);
    R(g, 6, 12, 26, 11, N.legnoScuro);
    O(g, 8, 13, 8, 8, N.out, N.porcellana);
    R(g, 11, 16, 2, 2, N.porcellanaBlu);
    O(g, 17, 13, 8, 8, N.out, N.porcellana);
    R(g, 20, 16, 2, 2, N.porcellanaBlu);
    O(g, 26, 13, 6, 8, N.out, N.porcellana);
    R(g, 5, 24, 28, 1, N.legnoScuro);
    R(g, 6, 26, 12, 16, N.legnoScuro);
    R(g, 20, 26, 12, 16, N.legnoScuro);
    R(g, 16, 33, 2, 2, N.ottone);
    R(g, 21, 33, 2, 2, N.ottone);
    // tavolo apparecchiato. Prima era un rettangolo pieno a righe verticali e si leggeva
    // come una CASSA: ora ha il piano di legno, le gambe sotto e la tovaglia che RICADE,
    // e i quadretti sono righe orizzontali E verticali (a sole righe verticali non e' un
    // quadretto, e' una tenda).
    R(g, 44, 42, 3, 2, N.legnoScuro);
    R(g, 61, 42, 3, 2, N.legnoScuro);
    O(g, 40, 30, 28, 4, N.out, N.legnoChiaro);
    R(g, 42, 34, 24, 8, N.tessuto);
    R(g, 42, 36, 24, 1, N.tessutoChiaro);
    R(g, 42, 39, 24, 1, N.tessutoChiaro);
    R(g, 47, 34, 1, 8, N.tessutoChiaro);
    R(g, 53, 34, 1, 8, N.tessutoChiaro);
    R(g, 59, 34, 1, 8, N.tessutoChiaro);
    for (var fr = 0; fr < 8; fr++) R(g, 42 + fr * 3, 42, 2, 1, N.pizzo);
    // cucina a gas con la moka che borbotta
    O(g, 74, 26, 32, 18, N.out, N.legnoChiaro);
    R(g, 75, 27, 30, 3, N.rame);
    R(g, 78, 31, 8, 2, N.out);
    R(g, 94, 31, 8, 2, N.out);
    R(g, 76, 20, 6, 6, N.rame);
    R(g, 77, 17, 4, 3, N.rame);
    R(g, 81, 18, 2, 1, N.out);
    R(g, 78, 15, 1, 2, N.pizzo);
    mensolina(g, 84, 16, "nonna");
  }

  function nonnaBagno(g) {
    nonnaWall(g, true);
    // vasca con i piedini e la mantovana a fiori sopra
    R(g, 4, 20, 44, 3, N.tessuto);
    for (var m = 0; m < 6; m++) R(g, 6 + m * 7, 23, 3, 2, N.tessutoChiaro);
    O(g, 2, 26, 46, 18, N.out, N.porcellana);
    R(g, 4, 28, 42, 4, N.vetro);
    R(g, 6, 44, 3, 2, N.ottone);
    R(g, 41, 44, 3, 2, N.ottone);
    // lavandino col centrino e lo specchio dalla cornice dorata
    O(g, 82, 6, 22, 16, N.ottone, N.vetro);
    R(g, 84, 8, 18, 2, N.pizzoOmbra);
    O(g, 80, 28, 24, 14, N.out, N.porcellana);
    R(g, 90, 24, 2, 4, N.rame);
    R(g, 82, 26, 20, 2, N.pizzo);
  }

  function nonnaSalone(g) {
    nonnaWall(g, false);
    // quadro col paesaggio e la cornice dorata
    O(g, 4, 8, 18, 14, N.ottone, N.legnoScuro);
    R(g, 6, 10, 14, 6, N.vetro);
    R(g, 6, 16, 14, 4, N.foglia);
    // televisore a tubo catodico, centrino sopra e antenna a V
    R(g, 27, 21, 1, 5, N.out);
    R(g, 33, 19, 1, 7, N.out);
    R(g, 4, 26, 28, 2, N.pizzo);
    O(g, 4, 28, 28, 16, N.out, N.legnoScuro);
    R(g, 7, 31, 22, 10, N.vetro);
    // IL DIVANO DI VELLUTO ANCORA COPERTO DALLA PLASTICA: il pezzo forte della stanza
    O(g, 58, 24, 48, 20, N.out, N.velluto);
    R(g, 60, 26, 44, 3, N.vellutoScuro);
    R(g, 60, 36, 44, 6, N.vellutoScuro);
    R(g, 59, 24, 46, 1, N.plastica);
    R(g, 64, 26, 2, 16, N.plastica);
    R(g, 76, 26, 2, 16, N.plastica);
    R(g, 88, 26, 2, 16, N.plastica);
    R(g, 100, 26, 2, 16, N.plastica);
  }

  function nonnaCamera(g) {
    nonnaWall(g, false);
    // letto con la coperta a quadrotti di lana fatta a mano
    R(g, 4, 18, 6, 26, N.legnoScuro);
    O(g, 4, 24, 50, 20, N.out, N.legno);
    R(g, 11, 26, 42, 4, N.pizzo);
    var lane = [N.lana1, N.lana2, N.lana3];
    for (var qy = 0; qy < 2; qy++) {
      for (var qx = 0; qx < 5; qx++) {
        R(g, 12 + qx * 8, 31 + qy * 6, 7, 5, lane[(qx + qy) % 3]);
      }
    }
    // comodino con la lampada dal paralume di stoffa e la sveglia a carica
    O(g, 76, 30, 22, 14, N.out, N.legno);
    // paralume a TRAPEZIO (stretto sopra, largo sotto) con stelo e base: un rettangolo
    // pieno si leggeva come una scatola rosa appoggiata li'.
    R(g, 83, 18, 8, 1, N.out);
    R(g, 82, 19, 10, 2, N.tessutoChiaro);
    R(g, 81, 21, 12, 2, N.tessutoChiaro);
    R(g, 80, 23, 14, 2, N.tessuto);
    R(g, 80, 25, 14, 1, N.out);
    R(g, 86, 26, 2, 2, N.ottone);
    O(g, 83, 28, 8, 2, N.out, N.ottone);
    O(g, 90, 24, 8, 6, N.out, N.porcellana);
    R(g, 93, 26, 2, 2, N.out);
  }

  // ===== SALA GIOCHI ANNI 80 =====
  function arcadeWall(g, tiles) {
    R(g, 0, 0, W, WALL_H, A.parete);
    R(g, 0, 0, W, 3, A.pannello);
    // tubi al neon accesi lungo la parete: due righe di colore che tagliano il buio
    R(g, 0, 5, W, 1, A.neonRosa);
    R(g, 0, 7, W, 1, A.neonCiano);
    if (tiles) {
      R(g, 0, 24, W, 18, A.pannello);
      for (var t = 8; t < W; t += 8) R(g, t, 24, 1, 18, A.giunto);
      R(g, 0, 32, W, 1, A.giunto);
    } else {
      R(g, 0, 36, W, 6, A.pannello);
      for (var j = 12; j < W; j += 12) R(g, j, 36, 1, 6, A.giunto);
    }
    R(g, 0, 42, W, 2, A.battiscopa);
    pavimentoProfondo(g, A.pavimento, A.fuga, A.pavScuro, A.pavChiaro);
    // moquette a stelline: il pavimento delle sale giochi vere
    for (var sy = 50; sy < H; sy += 12) {
      for (var sx = ((sy / 12) % 2 === 0) ? 8 : 18; sx < W; sx += 20) {
        R(g, sx, sy, 1, 1, A.stella);
        R(g, sx - 1, sy + 1, 3, 1, A.stella);
        R(g, sx, sy + 2, 1, 1, A.stella);
      }
    }
  }

  function arcadeCucina(g) {
    arcadeWall(g, false);
    // distributore di lattine con lo sportello illuminato
    O(g, 4, 10, 26, 34, A.out, A.cabinato);
    R(g, 6, 12, 22, 18, A.schermo);
    for (var la = 0; la < 3; la++) {
      R(g, 8 + la * 7, 14, 5, 6, la === 0 ? A.rosso : (la === 1 ? A.neonCiano : A.neonGiallo));
      R(g, 8 + la * 7, 22, 5, 6, la === 2 ? A.rosso : A.neonVerde);
    }
    R(g, 6, 32, 22, 6, A.cabinatoChiaro);
    R(g, 10, 34, 14, 2, A.neonRosa);
    // bancone snack con i bicchieroni
    O(g, 40, 30, 30, 14, A.out, A.cabinatoChiaro);
    R(g, 41, 31, 28, 2, A.neonCiano);
    R(g, 44, 22, 6, 8, A.plastica);
    R(g, 45, 20, 4, 2, A.rosso);
    R(g, 54, 24, 5, 6, A.plastica);
    R(g, 55, 22, 3, 2, A.neonGiallo);
    // cambiamonete a destra
    O(g, 76, 24, 30, 20, A.out, A.cabinato);
    R(g, 79, 27, 24, 8, A.schermo);
    R(g, 82, 29, 18, 2, A.neonGiallo);
    R(g, 86, 38, 10, 2, A.metallo);
    mensolina(g, 84, 16, "arcade");
  }

  function arcadeBagno(g) {
    arcadeWall(g, true);
    // vasca-idromassaggio con la luce dentro (siamo negli anni 80)
    O(g, 2, 26, 46, 18, A.out, A.cabinatoChiaro);
    R(g, 4, 28, 42, 5, A.neonCiano);
    R(g, 6, 30, 8, 1, A.plastica);
    R(g, 20, 30, 8, 1, A.plastica);
    R(g, 34, 30, 8, 1, A.plastica);
    // specchio da camerino con le lampadine intorno
    O(g, 80, 6, 26, 18, A.out, A.schermo);
    for (var lb = 0; lb < 5; lb++) {
      R(g, 82 + lb * 5, 7, 2, 2, A.neonGiallo);
      R(g, 82 + lb * 5, 21, 2, 2, A.neonGiallo);
    }
    R(g, 84, 10, 18, 10, A.plastica);
    // lavandino
    O(g, 80, 30, 24, 12, A.out, A.plastica);
    R(g, 90, 26, 2, 4, A.metallo);
  }

  function arcadeSalone(g) {
    arcadeWall(g, false);
    // DUE CABINATI accesi: il cuore della stanza
    O(g, 4, 12, 22, 32, A.out, A.cabinato);
    R(g, 6, 14, 18, 12, A.schermo);
    R(g, 8, 16, 4, 4, A.neonRosa);
    R(g, 16, 20, 4, 4, A.neonCiano);
    R(g, 6, 28, 18, 4, A.cabinatoChiaro);
    R(g, 8, 29, 3, 2, A.rosso);
    R(g, 13, 29, 3, 2, A.neonGiallo);
    R(g, 18, 29, 3, 2, A.neonVerde);
    R(g, 5, 34, 20, 2, A.neonRosa);
    O(g, 60, 12, 22, 32, A.out, A.cabinato);
    R(g, 62, 14, 18, 12, A.schermo);
    R(g, 64, 18, 14, 2, A.neonVerde);
    R(g, 68, 22, 6, 2, A.neonGiallo);
    R(g, 62, 28, 18, 4, A.cabinatoChiaro);
    R(g, 64, 29, 3, 2, A.neonCiano);
    R(g, 70, 29, 3, 2, A.rosso);
    R(g, 61, 34, 20, 2, A.neonCiano);
    // insegna al neon in alto a destra
    R(g, 88, 12, 20, 2, A.neonRosa);
    R(g, 88, 18, 20, 2, A.neonCiano);
    R(g, 88, 15, 2, 3, A.neonGiallo);
    R(g, 106, 15, 2, 3, A.neonGiallo);
  }

  function arcadeCamera(g) {
    arcadeWall(g, false);
    // letto con la trapunta a pixel
    R(g, 4, 18, 6, 26, A.cabinato);
    O(g, 4, 24, 50, 20, A.out, A.cabinatoChiaro);
    R(g, 11, 26, 42, 4, A.plastica);
    var tinte = [A.neonRosa, A.neonCiano, A.neonGiallo, A.neonVerde];
    for (var py = 0; py < 2; py++) {
      for (var px = 0; px < 6; px++) {
        R(g, 12 + px * 7, 31 + py * 6, 6, 5, tinte[(px + py) % 4]);
      }
    }
    // poster e televisorino con la console
    O(g, 76, 8, 22, 14, A.out, A.schermo);
    R(g, 78, 10, 18, 4, A.neonRosa);
    R(g, 78, 16, 12, 4, A.neonCiano);
    O(g, 76, 30, 24, 14, A.out, A.cabinato);
    R(g, 79, 33, 18, 8, A.schermo);
    R(g, 82, 35, 12, 4, A.neonVerde);
  }

  // ===== DOJO =====
  function dojoWall(g, tiles) {
    R(g, 0, 0, W, WALL_H, J.parete);
    // shoji: pannelli di carta divisi da listelli scuri
    for (var v = 0; v < W; v += 22) R(g, v, 0, 2, WALL_H - 2, J.listello);
    R(g, 0, 14, W, 2, J.listello);
    R(g, 0, 28, W, 2, J.listello);
    if (tiles) {
      R(g, 0, 30, W, 12, J.legno);
      for (var t = 0; t < W; t += 16) R(g, t, 30, 1, 12, J.legnoScuro);
    }
    R(g, 0, 42, W, 2, J.battiscopa);
    // tatami. Le stuoie vere sono GRANDI, col bordo di tessuto scuro sui lati lunghi e le
    // giunzioni SFALSATE: la griglia regolare del primo tentativo si leggeva come un
    // pavimento piastrellato, non come paglia.
    pavimentoProfondo(g, J.pavimento, J.fuga, J.pavScuro, J.pavChiaro);
    for (var ty = 46; ty < H; ty += 18) R(g, 0, ty, W, 1, J.bordoTatami);
    R(g, 56, 46, 1, 18, J.bordoTatami);
    R(g, 28, 64, 1, 18, J.bordoTatami);
    R(g, 84, 64, 1, 18, J.bordoTatami);
    R(g, 56, 82, 1, 14, J.bordoTatami);
  }

  function dojoCucina(g) {
    dojoWall(g, false);
    // credenza bassa di legno con le ciotole impilate
    O(g, 4, 24, 30, 20, J.out, J.legno);
    R(g, 5, 25, 28, 2, J.legnoChiaro);
    R(g, 7, 29, 11, 13, J.legnoScuro);
    R(g, 21, 29, 11, 13, J.legnoScuro);
    O(g, 8, 16, 10, 8, J.out, J.carta);
    O(g, 20, 18, 8, 6, J.out, J.carta);
    // fuoco basso con la teiera di ghisa
    O(g, 44, 32, 24, 12, J.out, J.legnoScuro);
    R(g, 46, 34, 20, 2, J.rosso);
    O(g, 50, 22, 12, 10, J.out, J.out);
    R(g, 52, 24, 8, 2, J.legnoChiaro);
    R(g, 61, 25, 3, 2, J.out);
    R(g, 55, 19, 1, 3, J.carta);
    // noren: la tenda divisa a meta' dell'ingresso, con l'ideogramma. Prima era un
    // rettangolo rosso con un blocco bianco in mezzo e sembrava una bandiera qualunque.
    R(g, 76, 6, 32, 2, J.legnoScuro);
    R(g, 77, 8, 14, 16, J.rosso);
    R(g, 93, 8, 14, 16, J.rosso);
    R(g, 77, 8, 14, 1, J.rossoScuro);
    R(g, 93, 8, 14, 1, J.rossoScuro);
    R(g, 81, 12, 6, 2, J.carta);
    R(g, 83, 14, 2, 6, J.carta);
    R(g, 97, 13, 6, 2, J.carta);
    R(g, 97, 17, 6, 2, J.carta);
    mensolina(g, 84, 30, "dojo");
  }

  function dojoBagno(g) {
    dojoWall(g, true);
    // ofuro: vasca di legno rotonda col vapore
    O(g, 2, 24, 44, 20, J.out, J.legno);
    R(g, 4, 26, 40, 4, J.acqua);
    R(g, 4, 30, 40, 1, J.legnoChiaro);
    for (var v2 = 0; v2 < 6; v2++) R(g, 6 + v2 * 7, 32, 1, 10, J.legnoScuro);
    R(g, 10, 20, 1, 4, J.carta);
    R(g, 24, 18, 1, 5, J.carta);
    R(g, 36, 21, 1, 3, J.carta);
    // secchiello e sgabellino
    O(g, 82, 32, 12, 10, J.out, J.legnoChiaro);
    R(g, 83, 33, 10, 1, J.acqua);
    O(g, 98, 36, 10, 6, J.out, J.legno);
    // specchio di carta
    O(g, 80, 8, 26, 16, J.out, J.carta);
    R(g, 82, 10, 22, 1, J.inchiostro);
  }

  function dojoSalone(g) {
    dojoWall(g, false);
    // makiwara: il palo da colpire, fasciato di corda
    R(g, 14, 10, 8, 34, J.legno);
    for (var c2 = 0; c2 < 5; c2++) R(g, 13, 14 + c2 * 4, 10, 2, J.corda);
    R(g, 12, 42, 12, 2, J.legnoScuro);
    // kakemono: rotolo appeso con l'ideogramma
    O(g, 46, 6, 18, 30, J.out, J.carta);
    R(g, 46, 6, 18, 2, J.legnoScuro);
    R(g, 46, 34, 18, 2, J.legnoScuro);
    R(g, 52, 12, 6, 2, J.inchiostro);
    R(g, 54, 14, 2, 8, J.inchiostro);
    R(g, 50, 20, 10, 2, J.inchiostro);
    // rastrelliera delle armi
    O(g, 78, 20, 30, 4, J.out, J.legnoScuro);
    R(g, 82, 10, 2, 14, J.legnoChiaro);
    R(g, 92, 8, 2, 16, J.legnoChiaro);
    R(g, 102, 12, 2, 12, J.legnoChiaro);
  }

  function dojoCamera(g) {
    dojoWall(g, false);
    // futon steso a terra, basso, con il cuscino di grano saraceno
    O(g, 8, 30, 46, 14, J.out, J.carta);
    R(g, 10, 32, 42, 2, J.legnoChiaro);
    R(g, 12, 35, 14, 7, J.rosso);
    R(g, 28, 35, 22, 7, J.legnoChiaro);
    // paravento pieghevole: ante di altezza LEGGERMENTE diversa, telaio scuro e piedini.
    // Un rettangolo unico si leggeva come un armadio.
    O(g, 74, 14, 11, 28, J.out, J.carta);
    O(g, 85, 11, 11, 31, J.out, J.carta);
    O(g, 96, 15, 11, 27, J.out, J.carta);
    // il disegno ATTRAVERSA le tre ante: e' questo che fa leggere un paravento invece di
    // tre armadietti. Bambu che sale da sinistra e monte sullo sfondo a destra.
    R(g, 79, 20, 2, 20, J.bambu);
    R(g, 76, 24, 3, 1, J.bambu);
    R(g, 81, 28, 3, 1, J.bambu);
    R(g, 76, 32, 3, 1, J.bambu);
    R(g, 88, 30, 2, 10, J.bambu);
    R(g, 86, 34, 2, 1, J.bambu);
    R(g, 96, 26, 4, 2, J.inchiostro);
    R(g, 99, 24, 4, 2, J.inchiostro);
    R(g, 102, 26, 4, 2, J.inchiostro);
    R(g, 97, 28, 8, 1, J.inchiostro);
    R(g, 76, 42, 2, 2, J.legnoScuro);
    R(g, 92, 42, 2, 2, J.legnoScuro);
    R(g, 103, 42, 2, 2, J.legnoScuro);
  }

  // ===== FONDALE MARINO =====
  function mareWall(g, oblo) {
    R(g, 0, 0, W, WALL_H, MR.parete);
    R(g, 0, 0, W, 4, MR.pannello);
    // raggi di luce che scendono dall'alto: l'unica cosa che dice "sei sott'acqua"
    for (var lx = 8; lx < W; lx += 26) {
      R(g, lx, 4, 2, 18, MR.fascia);
      R(g, lx + 1, 4, 1, 26, MR.acqua);
    }
    if (oblo) {
      O(g, 44, 10, 24, 22, MR.ottone, MR.vetro);
      R(g, 47, 13, 18, 4, MR.acquaChiara);
      R(g, 52, 22, 6, 3, MR.pesce);
      R(g, 50, 23, 2, 1, MR.pesce);
    }
    R(g, 0, 38, W, 4, MR.pannello);
    R(g, 0, 42, W, 2, MR.battiscopa);
    // fondale di sabbia con le increspature
    pavimentoProfondo(g, MR.pavimento, MR.fuga, MR.pavScuro, MR.pavChiaro);
    for (var wy = 52; wy < H; wy += 11) {
      for (var wx = ((wy / 11) % 2 === 0) ? 6 : 16; wx < W; wx += 22) R(g, wx, wy, 8, 1, MR.pavScuro);
    }
  }

  function mareCucina(g) {
    mareWall(g, false);
    // anfore rovesciate al posto della credenza
    O(g, 6, 20, 14, 24, MR.out, MR.conchiglia);
    R(g, 9, 16, 8, 5, MR.conchiglia);
    R(g, 8, 24, 10, 2, MR.corallo);
    O(g, 24, 26, 12, 18, MR.out, MR.conchiglia);
    R(g, 27, 23, 6, 4, MR.conchiglia);
    // banco di corallo
    O(g, 42, 30, 30, 14, MR.out, MR.corallo);
    R(g, 44, 32, 26, 2, MR.coralloGiallo);
    R(g, 48, 24, 4, 6, MR.algaChiara);
    R(g, 58, 22, 4, 8, MR.alga);
    // alghe alte a destra
    R(g, 100, 16, 3, 28, MR.alga);
    R(g, 104, 22, 3, 22, MR.algaChiara);
    R(g, 96, 26, 3, 18, MR.alga);
    mensolina(g, 84, 16, "mare");
  }

  function mareBagno(g) {
    mareWall(g, true);
    // vasca-conchiglia
    O(g, 2, 26, 44, 18, MR.out, MR.conchiglia);
    R(g, 4, 28, 40, 4, MR.acquaChiara);
    for (var v = 0; v < 6; v++) R(g, 6 + v * 7, 33, 1, 9, MR.pavScuro);
    // bolle che salgono
    R(g, 20, 20, 2, 2, MR.bolla);
    R(g, 26, 14, 3, 3, MR.bolla);
    R(g, 18, 8, 2, 2, MR.bolla);
    // colonna di corallo e stella marina
    R(g, 84, 24, 6, 20, MR.corallo);
    R(g, 80, 30, 4, 3, MR.corallo);
    R(g, 90, 34, 4, 3, MR.corallo);
    O(g, 98, 30, 10, 10, MR.out, MR.coralloGiallo);
    R(g, 102, 33, 2, 4, MR.conchiglia);
  }

  function mareSalone(g) {
    mareWall(g, false);
    // grande oblo sul mare aperto con un banco di pesci
    O(g, 56, 8, 48, 30, MR.ottone, MR.vetro);
    R(g, 59, 11, 42, 6, MR.acquaChiara);
    R(g, 66, 20, 6, 3, MR.pesce);
    R(g, 64, 21, 2, 1, MR.pesce);
    R(g, 78, 26, 6, 3, MR.pesce);
    R(g, 76, 27, 2, 1, MR.pesce);
    R(g, 88, 18, 5, 2, MR.pesce);
    // divano di corallo
    O(g, 4, 24, 40, 20, MR.out, MR.corallo);
    R(g, 6, 26, 36, 3, MR.coralloGiallo);
    R(g, 6, 36, 36, 6, MR.coralloGiallo);
    R(g, 12, 30, 8, 4, MR.perla);
    R(g, 28, 30, 8, 4, MR.perla);
  }

  function mareCamera(g) {
    mareWall(g, false);
    // letto-conchiglia
    R(g, 4, 16, 6, 28, MR.conchiglia);
    O(g, 4, 24, 48, 20, MR.out, MR.conchiglia);
    R(g, 11, 26, 40, 4, MR.perla);
    R(g, 12, 32, 38, 8, MR.acqua);
    for (var r2 = 0; r2 < 5; r2++) R(g, 14 + r2 * 8, 32, 1, 8, MR.acquaChiara);
    // alghe e perla sul comodino
    O(g, 78, 30, 20, 14, MR.out, MR.conchiglia);
    O(g, 84, 22, 8, 8, MR.out, MR.perla);
    R(g, 104, 20, 3, 24, MR.alga);
  }

  // ===== BAITA DI MONTAGNA =====
  function baitaWall(g, finestra) {
    // parete di tronchi orizzontali
    for (var ty = 0; ty < WALL_H; ty += 8) {
      R(g, 0, ty, W, 7, (ty / 8) % 2 === 0 ? Q.tronco : Q.troncoChiaro);
      R(g, 0, ty + 7, W, 1, Q.troncoScuro);
    }
    if (finestra) {
      O(g, 74, 8, 28, 20, Q.out, Q.cielo);
      R(g, 76, 10, 24, 6, Q.neve);
      R(g, 87, 8, 2, 20, Q.troncoScuro);
      R(g, 74, 17, 28, 2, Q.troncoScuro);
      R(g, 76, 24, 24, 3, Q.neve);
    }
    R(g, 0, 42, W, 2, Q.battiscopa);
    pavimentoProfondo(g, Q.pavimento, Q.fuga, Q.pavScuro, Q.pavChiaro);
  }

  function baitaCucina(g) {
    baitaWall(g, false);
    // dispensa con le conserve
    O(g, 4, 10, 26, 34, Q.out, Q.troncoScuro);
    R(g, 6, 12, 22, 1, Q.legno);
    for (var cy = 0; cy < 3; cy++) {
      for (var cx = 0; cx < 3; cx++) {
        O(g, 7 + cx * 7, 14 + cy * 10, 5, 8, Q.out, cy === 1 ? Q.plaid : Q.fuoco);
        R(g, 8 + cx * 7, 15 + cy * 10, 3, 1, Q.plaidChiaro);
      }
    }
    // fuoco con il pentolone appeso
    O(g, 44, 30, 26, 14, Q.out, Q.pietra);
    R(g, 47, 33, 20, 6, Q.brace);
    R(g, 50, 34, 4, 3, Q.fiamma);
    R(g, 58, 35, 4, 2, Q.fiamma);
    O(g, 50, 20, 14, 10, Q.out, Q.metallo);
    R(g, 52, 22, 10, 2, Q.pietraScura);
    R(g, 56, 16, 2, 4, Q.metallo);
    mensolina(g, 84, 16, "baita");
  }

  function baitaBagno(g) {
    baitaWall(g, true);
    // tinozza di legno a doghe
    O(g, 2, 26, 42, 18, Q.out, Q.legno);
    R(g, 4, 28, 38, 4, Q.cielo);
    for (var d = 0; d < 6; d++) R(g, 6 + d * 6, 32, 1, 10, Q.troncoScuro);
    R(g, 2, 30, 42, 1, Q.metallo);
    R(g, 2, 39, 42, 1, Q.metallo);
    // secchio e mestolo
    O(g, 50, 34, 12, 10, Q.out, Q.legno);
    R(g, 51, 35, 10, 1, Q.cielo);
    R(g, 64, 30, 2, 14, Q.troncoChiaro);
  }

  function baitaSalone(g) {
    baitaWall(g, false);
    // IL CAMINO acceso: il cuore della baita
    O(g, 60, 6, 44, 38, Q.out, Q.pietra);
    R(g, 62, 8, 40, 3, Q.pietraScura);
    O(g, 68, 18, 28, 24, Q.out, Q.out);
    R(g, 71, 30, 22, 10, Q.brace);
    R(g, 74, 26, 5, 8, Q.fuoco);
    R(g, 82, 24, 5, 10, Q.fiamma);
    R(g, 88, 28, 4, 6, Q.fuoco);
    R(g, 70, 40, 24, 2, Q.pietraScura);
    // sci incrociati alla parete
    R(g, 6, 10, 2, 26, Q.legno);
    R(g, 16, 10, 2, 26, Q.legno);
    R(g, 4, 20, 16, 2, Q.plaid);
    // poltrona
    O(g, 28, 28, 24, 16, Q.out, Q.plaid);
    R(g, 30, 30, 20, 3, Q.plaidChiaro);
  }

  function baitaCamera(g) {
    baitaWall(g, true);
    // letto col plaid a scacchi
    R(g, 4, 18, 6, 26, Q.troncoScuro);
    O(g, 4, 24, 48, 20, Q.out, Q.legno);
    R(g, 11, 26, 40, 4, Q.plaidChiaro);
    R(g, 12, 31, 38, 11, Q.plaid);
    for (var sx2 = 0; sx2 < 5; sx2++) R(g, 14 + sx2 * 8, 31, 2, 11, Q.plaidChiaro);
    R(g, 12, 35, 38, 2, Q.plaidChiaro);
    // tappeto di pelliccia appeso e lanterna
    O(g, 58, 30, 14, 12, Q.out, Q.metallo);
    R(g, 60, 32, 10, 8, Q.fiamma);
    R(g, 63, 26, 4, 4, Q.metallo);
  }

  // ===== CASTELLO =====
  function castelloWall(g, feritoia) {
    R(g, 0, 0, W, WALL_H, K.pietra);
    // conci sfalsati: la pietra vera non e' a griglia
    for (var by = 0; by < WALL_H; by += 9) {
      R(g, 0, by, W, 1, K.fuga);
      for (var bx = ((by / 9) % 2 === 0) ? 0 : 11; bx < W; bx += 22) R(g, bx, by, 1, 9, K.fuga);
    }
    if (feritoia) {
      R(g, 50, 6, 8, 22, K.out);
      R(g, 52, 8, 4, 18, K.tessuto);
    }
    R(g, 0, 42, W, 2, K.battiscopa);
    pavimentoProfondo(g, K.pavimento, K.pavFuga, K.pavScuro, K.pavChiaro);
    for (var fy = 50; fy < H; fy += 12) R(g, 0, fy, W, 1, K.pavFuga);
  }

  function castelloCucina(g) {
    castelloWall(g, false);
    // focolare col calderone
    O(g, 4, 12, 34, 32, K.out, K.out);
    R(g, 6, 14, 30, 2, K.pietraScura);
    R(g, 8, 32, 26, 10, K.torcia);
    R(g, 12, 28, 6, 8, K.fiamma);
    R(g, 22, 26, 6, 10, K.fiamma);
    O(g, 14, 18, 16, 12, K.ferro, K.ferroChiaro);
    R(g, 16, 20, 12, 2, K.out);
    // botti
    O(g, 46, 28, 16, 16, K.out, K.legno);
    R(g, 46, 32, 16, 2, K.ferro);
    R(g, 46, 38, 16, 2, K.ferro);
    O(g, 64, 32, 12, 12, K.out, K.legnoChiaro);
    R(g, 64, 36, 12, 2, K.ferro);
    mensolina(g, 84, 16, "castello");
  }

  function castelloBagno(g) {
    castelloWall(g, true);
    // tinozza di legno cerchiata di ferro
    O(g, 2, 26, 42, 18, K.out, K.legno);
    R(g, 4, 28, 38, 4, K.tessuto);
    R(g, 2, 31, 42, 2, K.ferro);
    R(g, 2, 39, 42, 2, K.ferro);
    // brocca e torcia
    O(g, 84, 30, 12, 12, K.out, K.legnoChiaro);
    R(g, 88, 26, 4, 4, K.legnoChiaro);
    R(g, 102, 20, 3, 16, K.legno);
    R(g, 100, 14, 7, 7, K.torcia);
    R(g, 102, 11, 3, 4, K.fiamma);
  }

  function castelloSalone(g) {
    castelloWall(g, false);
    // stendardi appesi
    R(g, 6, 4, 16, 26, K.stendardo);
    R(g, 6, 4, 16, 2, K.oro);
    R(g, 11, 12, 6, 6, K.oro);
    R(g, 6, 30, 4, 4, K.stendardo);
    R(g, 18, 30, 4, 4, K.stendardo);
    // trono
    O(g, 58, 12, 26, 32, K.out, K.legno);
    R(g, 60, 14, 22, 12, K.stendardo);
    R(g, 64, 16, 14, 8, K.oro);
    R(g, 60, 30, 22, 4, K.legnoChiaro);
    // torce ai lati
    R(g, 94, 18, 3, 14, K.legno);
    R(g, 92, 12, 7, 7, K.torcia);
    R(g, 94, 9, 3, 4, K.fiamma);
  }

  function castelloCamera(g) {
    castelloWall(g, true);
    // letto a baldacchino
    R(g, 4, 8, 4, 36, K.legno);
    R(g, 46, 8, 4, 36, K.legno);
    R(g, 4, 8, 46, 4, K.legno);
    R(g, 8, 12, 38, 6, K.tessuto);
    O(g, 6, 26, 42, 18, K.out, K.legnoChiaro);
    R(g, 12, 28, 34, 4, K.pergamena);
    R(g, 13, 33, 32, 9, K.stendardo);
    // cassapanca
    O(g, 76, 30, 26, 14, K.out, K.legno);
    R(g, 76, 34, 26, 2, K.ferro);
    R(g, 86, 32, 6, 4, K.oro);
  }

  // ===== BUNKER =====
  function bunkerWall(g, piastrelle) {
    R(g, 0, 0, W, WALL_H, Z.cemento);
    for (var py = 10; py < WALL_H; py += 14) R(g, 0, py, W, 1, Z.giunto);
    for (var px = 18; px < W; px += 36) R(g, px, 0, 1, WALL_H, Z.giunto);
    // tubi che corrono lungo il soffitto
    R(g, 0, 3, W, 3, Z.tubo);
    R(g, 0, 6, W, 1, Z.giunto);
    for (var tx = 12; tx < W; tx += 24) R(g, tx, 2, 3, 5, Z.metallo);
    // lampada d'emergenza accesa
    O(g, 88, 9, 12, 7, Z.out, Z.metallo);
    R(g, 90, 11, 8, 3, Z.emergenza);
    if (piastrelle) {
      R(g, 0, 26, W, 16, Z.cementoScuro);
      for (var t2 = 9; t2 < W; t2 += 9) R(g, t2, 26, 1, 16, Z.giunto);
    }
    R(g, 0, 42, W, 2, Z.battiscopa);
    pavimentoProfondo(g, Z.pavimento, Z.fuga, Z.pavScuro, Z.pavChiaro);
  }

  function bunkerCucina(g) {
    bunkerWall(g, false);
    // scaffalatura di scatolette
    O(g, 4, 14, 34, 30, Z.out, Z.metallo);
    R(g, 5, 23, 32, 2, Z.metalloChiaro);
    R(g, 5, 33, 32, 2, Z.metalloChiaro);
    for (var sy = 0; sy < 3; sy++) {
      for (var sx3 = 0; sx3 < 5; sx3++) {
        R(g, 7 + sx3 * 6, 16 + sy * 10, 4, 6, Z.scatoletta);
        R(g, 7 + sx3 * 6, 17 + sy * 10, 4, 1, Z.ruggine);
      }
    }
    // fornello da campo con la bombola
    O(g, 48, 30, 24, 14, Z.out, Z.metallo);
    R(g, 51, 33, 8, 3, Z.emergenza);
    R(g, 62, 33, 6, 3, Z.monitor);
    O(g, 76, 26, 12, 18, Z.out, Z.ruggine);
    R(g, 79, 22, 6, 4, Z.metallo);
    mensolina(g, 84, 16, "bunker");
  }

  function bunkerBagno(g) {
    bunkerWall(g, true);
    // doccia d'emergenza con la catena
    R(g, 16, 8, 2, 12, Z.metallo);
    O(g, 8, 20, 18, 5, Z.out, Z.metalloChiaro);
    R(g, 11, 25, 2, 4, Z.vetro);
    R(g, 17, 25, 2, 6, Z.vetro);
    R(g, 22, 25, 2, 3, Z.vetro);
    O(g, 4, 32, 30, 12, Z.out, Z.cementoScuro);
    // taniche d'acqua
    O(g, 82, 28, 14, 16, Z.out, Z.metallo);
    R(g, 84, 30, 10, 3, Z.vetro);
    R(g, 86, 26, 6, 2, Z.metalloChiaro);
    O(g, 98, 34, 10, 10, Z.out, Z.ruggine);
  }

  function bunkerSalone(g) {
    bunkerWall(g, false);
    // radio da campo con le manopole
    O(g, 4, 24, 30, 20, Z.out, Z.metallo);
    R(g, 7, 27, 16, 8, Z.out);
    R(g, 9, 29, 12, 2, Z.monitor);
    R(g, 9, 32, 8, 1, Z.monitor);
    R(g, 26, 28, 4, 4, Z.emergenza);
    R(g, 26, 35, 4, 4, Z.scatoletta);
    R(g, 6, 38, 24, 3, Z.metalloChiaro);
    // mappa alla parete tenuta col nastro adesivo
    O(g, 60, 8, 40, 26, Z.out, Z.scatoletta);
    R(g, 63, 12, 34, 1, Z.giunto);
    R(g, 63, 20, 34, 1, Z.giunto);
    R(g, 72, 11, 1, 22, Z.giunto);
    R(g, 86, 11, 1, 22, Z.giunto);
    R(g, 78, 18, 5, 5, Z.emergenza);
    R(g, 58, 6, 8, 3, Z.nastro);
    R(g, 96, 32, 8, 3, Z.nastro);
  }

  function bunkerCamera(g) {
    bunkerWall(g, false);
    // branda militare
    R(g, 4, 22, 4, 22, Z.metallo);
    R(g, 48, 22, 4, 22, Z.metallo);
    O(g, 4, 26, 48, 12, Z.out, Z.cementoScuro);
    R(g, 8, 28, 40, 3, Z.metalloChiaro);
    R(g, 10, 31, 36, 5, Z.tubo);
    // cassa munizioni e luce rossa d'emergenza
    O(g, 76, 30, 26, 14, Z.out, Z.ruggine);
    R(g, 76, 34, 26, 2, Z.metallo);
    R(g, 84, 32, 10, 2, Z.nastro);
    R(g, 104, 20, 4, 10, Z.metallo);
    R(g, 103, 16, 6, 5, Z.emergenza);
  }

  var BUILDERS = {
    lab: { cucina: labCucina, bagno: labBagno, salone: labSalone, camera: labCamera },
    ship: { cucina: shipCucina, bagno: shipBagno, salone: shipSalone, camera: shipCamera },
    nonna: { cucina: nonnaCucina, bagno: nonnaBagno, salone: nonnaSalone, camera: nonnaCamera },
    arcade: { cucina: arcadeCucina, bagno: arcadeBagno, salone: arcadeSalone, camera: arcadeCamera },
    dojo: { cucina: dojoCucina, bagno: dojoBagno, salone: dojoSalone, camera: dojoCamera },
    mare: { cucina: mareCucina, bagno: mareBagno, salone: mareSalone, camera: mareCamera },
    baita: { cucina: baitaCucina, bagno: baitaBagno, salone: baitaSalone, camera: baitaCamera },
    castello: { cucina: castelloCucina, bagno: castelloBagno, salone: castelloSalone, camera: castelloCamera },
    bunker: { cucina: bunkerCucina, bagno: bunkerBagno, salone: bunkerSalone, camera: bunkerCamera }
  };

  // ===== Poop: piccolo sprite marrone a terra, 1-3 in base a stato.poop =====
  // Scese col pavimento profondo (erano [16,52],[54,55],[92,52], tarate sulla stanza alta 64):
  // in una stanza 112x96 quelle y cadevano nella parte LONTANA del pavimento, lontanissime dal
  // pet, e si leggevano come tre puntini sospesi a mezz'aria invece che come qualcosa per terra
  // accanto a lui. Ora stanno nella fascia dove il pet cammina (y 76..92), nella striscia
  // centrale libera: a sinistra c'e' il tappetino con la ciotola e a destra la cassa (v.
  // PRIMO_PIANO), e ci finirebbero sopra. Il tap per pulire usa le stesse coordinate
  // (ui.js poopSpots -> _poopSpots), quindi resta allineato da solo.
  // NB sulle X: il pet sta al centro (x 48..64) e l'idle "corre per casa" lo sposta di +-16,
  // quindi la vecchia posizione centrale [56,86] gli finiva proprio sotto ai piedi. Le tre
  // posizioni ora stanno ai lati del suo posto di riposo. La priorita' del tocco e' comunque
  // gia' risolta a monte (ui.js controlla la cacca PRIMA del pet), questo e' solo per non
  // disegnarla sotto di lui.
  var POOP_SPOTS = [[36, 86], [72, 80], [92, 88]];
  function drawPoop(g, count) {
    var n = Math.max(0, Math.min(3, count || 0));
    g.fillStyle = "#5c3a1e";
    for (var i = 0; i < n; i++) {
      var p = POOP_SPOTS[i];
      g.fillRect(p[0], p[1], 4, 3);
      g.fillRect(p[0] + 1, p[1] - 1, 2, 1);
    }
  }

  // ===== Mappa della città (tab Missioni): 144x128, crepuscolo, 9 luoghi + strade =====
  // Fix playtest "Mappa leggibilità": scena schiarita rispetto alla notte piena originale,
  // cosi' gli edifici a silhouette grande restano a contrasto invece di sparire nel buio.
  // Unica per entrambe le razze: è la città, non la casa.
  // MAPPA_H esteso 512 -> 640 (fix "mappa m73-98 ingiocabile": 26 missioni extra + Grandi
  // Imprese m65-72 spostate piu' in basso, v. MAPPA_PINS e mappaBase/IMPRESE_ZONA_Y).
  var MAPPA_W = 216, MAPPA_H = 530;
  // Altezza PARAMETRICA della mappa (27 lug 2026, richiesta fondatore guardando la mappa:
  // "quella linea gialla con sotto quegli edifici vuoti non hanno senso, andrebbero
  // rimossi... e la mappa e' sempre troppo lunga"): la zona finale delle Grandi Imprese
  // (fascia viola scuro + soglia dorata + 2 lampioni + pin m65-m72, v. mappaBase) e' contenuto
  // ENDGAME riservato al pet ADULTO — veniva disegnata SEMPRE, anche per un cucciolo che non ne
  // vedra' una per giorni: 74px logici su 530 (14% dell'altezza mappa) di edifici spenti e
  // inspiegabili. Stesso schema di H_BASE/H_GRANDE/altezzaStanza in cima al file: MAPPA_H_BASE
  // e' la mappa "corta" che finisce esattamente dove comincia la zona Imprese, MAPPA_H_IMPRESE
  // e' quella completa di oggi. Il modulo MAPPA_H (usato da mappaBase/drawMappa/assertMappa)
  // viene impostato a una delle due all'inizio di drawMappa() in base a stato.imprese e sempre
  // ripristinato nel finally — esattamente come H in draw() (v. commento li' per i dettagli).
  var MAPPA_H_BASE = 456, MAPPA_H_IMPRESE = 530;
  // torna l'altezza giusta per lo stato corrente: quella con la zona Imprese SOLO se c'e'
  // davvero un'Impresa da mostrare. stato.imprese arriva da ui.js statoMappa(), che lo calcola
  // dalla STESSA fonte di verita' gia' usata per accendere il pin (impresaPendente/
  // impresaScheda) — qui non si ricalcola nulla e non si guarda mai lo stadio del pet.
  function altezzaMappa(stato) {
    return (stato && stato.imprese) ? MAPPA_H_IMPRESE : MAPPA_H_BASE;
  }
  // soglia y dove comincia la zona Grandi Imprese in mappaBase (fascia viola + soglia dorata +
  // 2 lampioni): DEVE combaciare con MAPPA_H_BASE, visto che e' li' che la mappa "corta" finisce
  // — definita come alias diretto cosi' non puo' andare fuori sync. Se un giorno le coordinate
  // dei pin Imprese (m65-m72 in MAPPA_PINS) cambiano, spostare insieme anche questa.
  var IMPRESE_ZONA_Y = MAPPA_H_BASE;

  // Palette mappa a CREPUSCOLO (fix playtest, GDD "Mappa leggibilità"): piu' chiara della
  // notte piena di prima, cosi' gli edifici (a silhouette grande) restano a contrasto sul
  // cielo della sera invece di sparire nel quasi-nero.
  var M = {
    fondo: "#2a3350", isolato: "#333d5c",
    strada: "#3d4666", corsia: "#6c7796", marciapiede: "#4b5578",
    lastricato: "#3c4562", lastricatoChiaro: "#485272",
    lampione: "#6c7796", lampLuce: "#f8e05a", lampAlone: "#5c5638",
    zebra: "#d8dfe8",
    pinOut: "#3a3208", pinFill: "#f0c832", pinBright: "#ffe066", pinLuce: "#fff6c0",
    // toni "spento" condivisi: piu' chiari di prima ma ancora chiaramente desaturati/spenti
    dimMuro: "#3a4058", dimScuro: "#323952", dimChiaro: "#484f6c", dimFinestra: "#383f58"
  };

  // rettangoli logici dei 9 luoghi missione (hit-test per la UI, generosi, min 16x14)
  var MAPPA_PINS = {
    // Regione hero (m0-m14): pin a tema con arte dedicata in mappaBase, INVARIATI.
    m2: { x: 2,   y: 4,  w: 32, h: 36 }, // Parco delle Antenne
    m4: { x: 38,  y: 6,  w: 26, h: 34 }, // Biblioteca dei Bit Perduti
    m5: { x: 80,  y: 4,  w: 62, h: 36 }, // Vicoli della Zona Industriale
    m1: { x: 2,   y: 52, w: 32, h: 36 }, // Sala Giochi "Bit & Byte"
    m0: { x: 36,  y: 52, w: 18, h: 36 }, // Negozio di Giocattoli
    m6: { x: 90,  y: 52, w: 24, h: 36 }, // Studio di Trasmissione
    m3: { x: 118, y: 52, w: 24, h: 36 }, // Dojo del Rottame
    m8: { x: 2,   y: 98, w: 62, h: 26 }, // Neon Avenue
    m7: { x: 84,  y: 98, w: 34, h: 26 }, // Fogne / Laboratorio Abbandonato
    m9:  { x: 150, y: 6,  w: 26, h: 30 },
    m10: { x: 182, y: 6,  w: 26, h: 30 },
    m11: { x: 150, y: 50, w: 26, h: 30 },
    m12: { x: 182, y: 50, w: 26, h: 30 },
    m13: { x: 150, y: 94, w: 26, h: 30 },
    m14: { x: 182, y: 94, w: 26, h: 30 },
    // Griglia missioni RICOMPATTATA (m15-m64 + m73-m98): 7 colonne (x 4/34/64/94/124/154/184),
    // slot 28x24, passo verticale 28. MAPPA_H 640->530 per ridurre lo scroll su mobile
    // (richiesta fondatore). Hit-test solo sui pin ATTIVI della rosa -> colonne fitte non
    // creano ambiguita di tap. Coordinate generate e verificate (assertMappa: 0 overlap).
    m15: { x:   4, y: 136, w: 28, h: 24 },
    m16: { x:  34, y: 136, w: 28, h: 24 },
    m17: { x:  64, y: 136, w: 28, h: 24 },
    m18: { x:  94, y: 136, w: 28, h: 24 },
    m19: { x: 124, y: 136, w: 28, h: 24 },
    m20: { x: 154, y: 136, w: 28, h: 24 },
    m21: { x: 184, y: 136, w: 28, h: 24 },
    m22: { x:   4, y: 164, w: 28, h: 24 },
    m23: { x:  34, y: 164, w: 28, h: 24 },
    m24: { x:  64, y: 164, w: 28, h: 24 },
    m25: { x:  94, y: 164, w: 28, h: 24 },
    m26: { x: 124, y: 164, w: 28, h: 24 },
    m27: { x: 154, y: 164, w: 28, h: 24 },
    m28: { x: 184, y: 164, w: 28, h: 24 },
    m29: { x:   4, y: 192, w: 28, h: 24 },
    m30: { x:  34, y: 192, w: 28, h: 24 },
    m31: { x:  64, y: 192, w: 28, h: 24 },
    m32: { x:  94, y: 192, w: 28, h: 24 },
    m33: { x: 124, y: 192, w: 28, h: 24 },
    m34: { x: 154, y: 192, w: 28, h: 24 },
    m35: { x: 184, y: 192, w: 28, h: 24 },
    m36: { x:   4, y: 220, w: 28, h: 24 },
    m37: { x:  34, y: 220, w: 28, h: 24 },
    m38: { x:  64, y: 220, w: 28, h: 24 },
    m39: { x:  94, y: 220, w: 28, h: 24 },
    m40: { x: 124, y: 220, w: 28, h: 24 },
    m41: { x: 154, y: 220, w: 28, h: 24 },
    m42: { x: 184, y: 220, w: 28, h: 24 },
    m43: { x:   4, y: 248, w: 28, h: 24 },
    m44: { x:  34, y: 248, w: 28, h: 24 },
    m45: { x:  64, y: 248, w: 28, h: 24 },
    m46: { x:  94, y: 248, w: 28, h: 24 },
    m47: { x: 124, y: 248, w: 28, h: 24 },
    m48: { x: 154, y: 248, w: 28, h: 24 },
    m49: { x: 184, y: 248, w: 28, h: 24 },
    m50: { x:   4, y: 276, w: 28, h: 24 },
    m51: { x:  34, y: 276, w: 28, h: 24 },
    m52: { x:  64, y: 276, w: 28, h: 24 },
    m53: { x:  94, y: 276, w: 28, h: 24 },
    m54: { x: 124, y: 276, w: 28, h: 24 },
    m55: { x: 154, y: 276, w: 28, h: 24 },
    m56: { x: 184, y: 276, w: 28, h: 24 },
    m57: { x:   4, y: 304, w: 28, h: 24 },
    m58: { x:  34, y: 304, w: 28, h: 24 },
    m59: { x:  64, y: 304, w: 28, h: 24 },
    m60: { x:  94, y: 304, w: 28, h: 24 },
    m61: { x: 124, y: 304, w: 28, h: 24 },
    m62: { x: 154, y: 304, w: 28, h: 24 },
    m63: { x: 184, y: 304, w: 28, h: 24 },
    m64: { x:   4, y: 332, w: 28, h: 24 },
    m73: { x:  34, y: 332, w: 28, h: 24 },
    m74: { x:  64, y: 332, w: 28, h: 24 },
    m75: { x:  94, y: 332, w: 28, h: 24 },
    m76: { x: 124, y: 332, w: 28, h: 24 },
    m77: { x: 154, y: 332, w: 28, h: 24 },
    m78: { x: 184, y: 332, w: 28, h: 24 },
    m79: { x:   4, y: 360, w: 28, h: 24 },
    m80: { x:  34, y: 360, w: 28, h: 24 },
    m81: { x:  64, y: 360, w: 28, h: 24 },
    m82: { x:  94, y: 360, w: 28, h: 24 },
    m83: { x: 124, y: 360, w: 28, h: 24 },
    m84: { x: 154, y: 360, w: 28, h: 24 },
    m85: { x: 184, y: 360, w: 28, h: 24 },
    m86: { x:   4, y: 388, w: 28, h: 24 },
    m87: { x:  34, y: 388, w: 28, h: 24 },
    m88: { x:  64, y: 388, w: 28, h: 24 },
    m89: { x:  94, y: 388, w: 28, h: 24 },
    m90: { x: 124, y: 388, w: 28, h: 24 },
    m91: { x: 154, y: 388, w: 28, h: 24 },
    m92: { x: 184, y: 388, w: 28, h: 24 },
    m93: { x:   4, y: 416, w: 28, h: 24 },
    m94: { x:  34, y: 416, w: 28, h: 24 },
    m95: { x:  64, y: 416, w: 28, h: 24 },
    m96: { x:  94, y: 416, w: 28, h: 24 },
    m97: { x: 124, y: 416, w: 28, h: 24 },
    m98: { x: 154, y: 416, w: 28, h: 24 },
    // Grandi Imprese (m65-m72): zona finale speciale (34x26), sotto la griglia, IMPRESE_ZONA_Y 456.
    m65: { x:  26, y: 462, w: 34, h: 26 },
    m66: { x:  69, y: 462, w: 34, h: 26 },
    m67: { x: 112, y: 462, w: 34, h: 26 },
    m68: { x: 155, y: 462, w: 34, h: 26 },
    m69: { x:  26, y: 494, w: 34, h: 26 },
    m70: { x:  69, y: 494, w: 34, h: 26 },
    m71: { x: 112, y: 494, w: 34, h: 26 },
    m72: { x: 155, y: 494, w: 34, h: 26 }
  };

  // Negozio unico (GDD "Economia" -> "Spesa e dispensa", fix fondatore): NON esiste piu' un
  // pin "Market" separato. Il Negozio di Giocattoli (m0, MAPPA_PINS.m0) e' l'UNICO shop sulla
  // mappa: prima del tutorial e' il luogo del tutorial, dopo diventa il pin permanente del
  // menu acquisto cibo. Riusiamo le sue stesse coordinate per il pin "sempre illuminato".
  var SHOP_PIN_ID = 'm0';
  var MAPPA_PIN_SHOP = MAPPA_PINS.m0;

  // pin a goccia gialla sopra un luogo; bright = frame di pulsazione
  function mapPin(g, cx, tipY, bright) {
    var yTop = tipY - 10;
    R(g, cx - 4, yTop, 9, 7, M.pinOut);
    R(g, cx - 2, yTop + 7, 5, 2, M.pinOut);
    R(g, cx - 1, yTop + 9, 3, 1, M.pinOut);
    R(g, cx - 3, yTop + 1, 7, 5, bright ? M.pinBright : M.pinFill);
    R(g, cx - 1, yTop + 6, 3, 2, bright ? M.pinBright : M.pinFill);
    R(g, cx - 2, yTop + 2, 2, 2, M.pinLuce);
  }
  function pinTipY(rect) { return Math.max(12, rect.y + 2); }
  function pinCx(rect) { return rect.x + Math.floor(rect.w / 2); }

  // ----- i 9 luoghi (on = illuminato/attivo, off = spento/desaturato) -----
  function luogoParco(g, on) { // m2: verde con laghetto, sentiero e due torri-antenna
    var r = MAPPA_PINS.m2;
    R(g, r.x, r.y, r.w, r.h, on ? "#24543a" : "#232c33");
    // laghetto in basso a sinistra
    R(g, r.x + 3, r.y + 24, 12, 9, on ? "#2e6a8a" : "#26303c");
    R(g, r.x + 5, r.y + 26, 8, 5, on ? "#4a9ab8" : "#2c3844");
    if (on) R(g, r.x + 7, r.y + 27, 3, 1, "#8fd8f0");
    // sentiero che sale dal bordo al centro
    R(g, r.x + 20, r.y + 30, 4, 6, on ? "#5c6450" : "#2e3440");
    R(g, r.x + 18, r.y + 24, 4, 6, on ? "#5c6450" : "#2e3440");
    R(g, r.x + 16, r.y + 18, 4, 6, on ? "#5c6450" : "#2e3440");
    // alberi
    R(g, r.x + 24, r.y + 8, 6, 6, on ? "#3f9c5c" : "#2c3844");
    R(g, r.x + 26, r.y + 14, 2, 3, on ? "#5c4a2e" : "#2a303c");
    R(g, r.x + 25, r.y + 20, 5, 5, on ? "#357a4a" : "#28323e");
    R(g, r.x + 2, r.y + 14, 5, 5, on ? "#3f9c5c" : "#2c3844");
    // due torri-antenna a traliccio con luci rosse
    R(g, r.x + 8, r.y + 4, 2, 16, on ? "#8fa3ad" : "#3a4150");
    R(g, r.x + 6, r.y + 8, 6, 1, on ? "#8fa3ad" : "#3a4150");
    R(g, r.x + 6, r.y + 14, 6, 1, on ? "#8fa3ad" : "#3a4150");
    R(g, r.x + 8, r.y + 2, 2, 2, on ? "#e84040" : "#4a3540");
    R(g, r.x + 16, r.y + 8, 2, 12, on ? "#8fa3ad" : "#3a4150");
    R(g, r.x + 14, r.y + 12, 6, 1, on ? "#8fa3ad" : "#3a4150");
    R(g, r.x + 16, r.y + 6, 2, 2, on ? "#e84040" : "#4a3540");
  }
  function luogoBiblioteca(g, on) { // m4: facciata classica, colonne, scalinata
    var r = MAPPA_PINS.m4;
    O(g, r.x + 1, r.y + 5, r.w - 2, r.h - 12, "#0e1118", on ? "#6e5638" : M.dimMuro);
    R(g, r.x + 3, r.y, r.w - 6, 5, on ? "#8a6c46" : M.dimChiaro); // timpano
    R(g, r.x + 5, r.y + 2, r.w - 10, 1, on ? "#5c4426" : M.dimScuro);
    R(g, r.x + 4, r.y + 8, 3, 14, on ? "#c9a878" : M.dimChiaro); // colonne
    R(g, r.x + 11, r.y + 8, 3, 14, on ? "#c9a878" : M.dimChiaro);
    R(g, r.x + 19, r.y + 8, 3, 14, on ? "#c9a878" : M.dimChiaro);
    R(g, r.x + 8, r.y + 10, 2, 6, on ? "#f0b84a" : M.dimFinestra); // finestre calde
    R(g, r.x + 15, r.y + 10, 2, 6, on ? "#f0b84a" : M.dimFinestra);
    R(g, r.x + 10, r.y + 16, 6, 7, on ? "#f0d089" : M.dimFinestra); // portone
    // scalinata a 3 gradini
    R(g, r.x + 4, r.y + 27, r.w - 8, 2, on ? "#a08a68" : M.dimChiaro);
    R(g, r.x + 2, r.y + 29, r.w - 4, 2, on ? "#8a755a" : "#2e3440");
    R(g, r.x, r.y + 31, r.w, 3, on ? "#75634c" : "#2a303c");
  }
  function luogoIndustria(g, on) { // m5: capannoni a shed, ciminiere, serbatoio, recinzione
    var r = MAPPA_PINS.m5;
    R(g, r.x, r.y + 8, r.w, r.h - 8, on ? "#3a3644" : M.dimScuro); // lotto
    R(g, r.x, r.y + 8, r.w, 1, on ? "#5c5468" : "#2e3440"); // recinzione
    for (var f = 2; f < r.w; f += 6) R(g, r.x + f, r.y + 6, 1, 3, on ? "#5c5468" : "#2e3440");
    O(g, r.x + 2, r.y + 14, 24, 18, "#0e1118", on ? "#4a4456" : M.dimMuro); // capannone 1 (tetto a shed)
    R(g, r.x + 3, r.y + 12, 6, 3, on ? "#5c5468" : M.dimChiaro);
    R(g, r.x + 11, r.y + 12, 6, 3, on ? "#5c5468" : M.dimChiaro);
    R(g, r.x + 19, r.y + 12, 6, 3, on ? "#5c5468" : M.dimChiaro);
    O(g, r.x + 30, r.y + 18, 20, 14, "#0e1118", on ? "#443e50" : M.dimMuro); // capannone 2
    O(g, r.x + 53, r.y + 14, 8, 18, "#0e1118", on ? "#50485e" : M.dimMuro); // serbatoio
    R(g, r.x + 55, r.y + 12, 4, 3, on ? "#5c5468" : M.dimChiaro);
    R(g, r.x + 8, r.y, 5, 14, on ? "#5c5468" : M.dimChiaro); // ciminiera 1
    R(g, r.x + 20, r.y + 3, 5, 11, on ? "#5c5468" : M.dimChiaro); // ciminiera 2
    R(g, r.x + 38, r.y + 6, 5, 12, on ? "#5c5468" : M.dimChiaro); // ciminiera 3
    if (on) {
      R(g, r.x + 9, r.y - 3, 3, 3, "#6a7280"); // fumo
      R(g, r.x + 22, r.y, 3, 3, "#6a7280");
      R(g, r.x + 40, r.y + 2, 2, 2, "#6a7280");
      R(g, r.x + 8, r.y, 5, 1, "#e84040"); // luci di segnalazione
      R(g, r.x + 38, r.y + 6, 5, 1, "#f0b84a");
      R(g, r.x + 5, r.y + 18, 4, 4, "#f0b84a"); // finestre calde
      R(g, r.x + 14, r.y + 18, 4, 4, "#f0b84a");
      R(g, r.x + 34, r.y + 22, 3, 3, "#f0b84a");
      R(g, r.x + 43, r.y + 22, 3, 3, "#f0b84a");
    }
  }
  function luogoSalaGiochi(g, on) { // m1: vetrata con cabinati visibili dentro + insegna neon
    var r = MAPPA_PINS.m1;
    O(g, r.x, r.y + 7, r.w, r.h - 7, "#0e1118", on ? "#221c34" : M.dimScuro);
    R(g, r.x + 2, r.y, r.w - 4, 7, on ? "#2e2547" : M.dimMuro); // fascione insegna
    R(g, r.x + 4, r.y + 2, 7, 3, on ? "#e85ad8" : "#3d3247"); // neon insegna
    R(g, r.x + 13, r.y + 2, 7, 3, on ? "#4dd8e8" : "#32404a");
    R(g, r.x + 22, r.y + 2, 6, 3, on ? "#5ce87f" : "#324a3a");
    if (on) R(g, r.x + 2, r.y + 6, r.w - 4, 1, "#e85ad8"); // bordo glow
    // vetrata con dentro due cabinati
    O(g, r.x + 3, r.y + 11, 18, 16, "#0e1118", on ? "#1a1526" : M.dimFinestra);
    R(g, r.x + 5, r.y + 13, 5, 10, on ? "#2e2840" : "#252a36"); // cabinato 1
    R(g, r.x + 6, r.y + 14, 3, 3, on ? "#4dd8e8" : "#2c3540");
    R(g, r.x + 12, r.y + 13, 5, 10, on ? "#2e2840" : "#252a36"); // cabinato 2
    R(g, r.x + 13, r.y + 14, 3, 3, on ? "#e85ad8" : "#332c3e");
    // porta luminosa
    R(g, r.x + 24, r.y + 14, 6, 13, on ? "#e85ad8" : M.dimFinestra);
    R(g, r.x + 25, r.y + 15, 4, 12, on ? "#f8bff0" : M.dimScuro);
  }
  function luogoNegozio(g, on) { // m0: negozietto con tenda a strisce, vetrina e insegna
    var r = MAPPA_PINS.m0;
    O(g, r.x, r.y + 6, r.w, r.h - 6, "#0e1118", on ? "#5c4a6e" : M.dimMuro);
    R(g, r.x + 3, r.y + 1, r.w - 6, 4, on ? "#f0b84a" : M.dimChiaro); // insegna
    for (var i = 0; i < 5; i++) { // tenda a strisce
      var sx0 = r.x + 1 + i * 4;
      var sw = Math.min(4, r.x + r.w - 1 - sx0);
      if (sw > 0) R(g, sx0, r.y + 6, sw, 4, i % 2 === 0 ? (on ? "#e85a5a" : "#3d3038") : (on ? "#f4f0e0" : M.dimChiaro));
    }
    R(g, r.x + 2, r.y + 13, 9, 10, on ? "#f8e05a" : M.dimFinestra); // vetrina calda
    if (on) {
      R(g, r.x + 4, r.y + 18, 2, 4, "#d83048"); // giocattoli in vetrina
      R(g, r.x + 7, r.y + 16, 3, 3, "#4a7ba6");
      R(g, r.x + 4, r.y + 15, 2, 2, "#5ce87f");
    }
    R(g, r.x + 12, r.y + 16, 5, 12, on ? "#8a5c34" : M.dimScuro); // porta
    R(g, r.x + 2, r.y + 30, r.w - 4, 3, on ? "#75634c" : "#2a303c"); // gradino d'ingresso
  }
  function luogoStudioTV(g, on) { // m6: studio con parabolona, ON AIR e ingresso a vetri
    var r = MAPPA_PINS.m6;
    O(g, r.x, r.y + 9, r.w, r.h - 9, "#0e1118", on ? "#3a4258" : M.dimMuro);
    R(g, r.x + 16, r.y + 1, 2, 9, on ? "#8fa3ad" : M.dimChiaro); // palo
    R(g, r.x + 10, r.y, 6, 2, on ? "#c9d2dc" : M.dimChiaro); // parabola grande
    R(g, r.x + 8, r.y + 2, 6, 2, on ? "#c9d2dc" : M.dimChiaro);
    R(g, r.x + 7, r.y + 4, 4, 2, on ? "#c9d2dc" : M.dimChiaro);
    R(g, r.x + 2, r.y + 11, 6, 3, on ? "#e84040" : "#3d2c34"); // ON AIR
    if (on) R(g, r.x + 9, r.y + 12, 4, 1, "#8a2c2c");
    R(g, r.x + 3, r.y + 17, 6, 5, on ? "#4dd8e8" : M.dimFinestra); // vetrate regia
    R(g, r.x + 11, r.y + 17, 6, 5, on ? "#4dd8e8" : M.dimFinestra);
    O(g, r.x + 8, r.y + 25, 9, 11, "#0e1118", on ? "#4dd8e8" : M.dimFinestra); // ingresso a vetri
    R(g, r.x + 12, r.y + 27, 1, 9, "#0e1118");
  }
  function luogoDojo(g, on) { // m3: cortile murato con cancello + pagoda a due falde
    var r = MAPPA_PINS.m3;
    // cortile con muretto e cancello
    R(g, r.x, r.y + 16, r.w, r.h - 16, on ? "#3d3830" : M.dimScuro);
    R(g, r.x, r.y + 16, r.w, 1, on ? "#75634c" : "#2e3440");
    R(g, r.x, r.y + 34, r.w, 2, on ? "#75634c" : "#2e3440"); // muretto davanti
    R(g, r.x + 9, r.y + 34, 6, 2, on ? "#f0b84a" : M.dimFinestra); // cancello caldo
    // vialetto di pietre
    R(g, r.x + 10, r.y + 30, 4, 2, on ? "#8a755a" : "#2e3440");
    R(g, r.x + 10, r.y + 26, 4, 2, on ? "#8a755a" : "#2e3440");
    // pagoda
    R(g, r.x + 2, r.y + 6, r.w - 4, 3, on ? "#8a3038" : "#33262c"); // falda larga
    R(g, r.x + 5, r.y + 1, r.w - 10, 5, on ? "#a83c46" : "#3d2c32"); // falda alta
    O(g, r.x + 4, r.y + 9, r.w - 8, 13, "#0e1118", on ? "#8a5c34" : M.dimMuro);
    R(g, r.x + 9, r.y + 13, 6, 9, on ? "#f0b84a" : M.dimFinestra); // porta calda
    R(g, r.x + 5, r.y + 12, 2, 5, on ? "#f0e0c0" : M.dimFinestra); // lanterne
    R(g, r.x + 17, r.y + 12, 2, 5, on ? "#f0e0c0" : M.dimFinestra);
  }
  function luogoNeonAvenue(g, on) { // m8: boulevard con facciate, insegne neon e lampioni
    var r = MAPPA_PINS.m8;
    R(g, r.x, r.y, r.w, r.h, on ? "#1c1830" : M.dimScuro);
    R(g, r.x, r.y + 19, r.w, 2, on ? "#e85ad8" : "#3d3247"); // doppia striscia neon a terra
    R(g, r.x, r.y + 22, r.w, 1, on ? "#4dd8e8" : "#32404a");
    var facciate = [
      { fx: 2,  neon: "#e85ad8", dimN: "#3d3247" },
      { fx: 17, neon: "#5ce87f", dimN: "#324a3a" },
      { fx: 32, neon: "#4dd8e8", dimN: "#32404a" },
      { fx: 47, neon: "#f0b84a", dimN: "#3d3830" }
    ];
    facciate.forEach(function (f) {
      O(g, r.x + f.fx, r.y + 2, 13, 15, "#0e1118", on ? "#2e2547" : M.dimMuro);
      R(g, r.x + f.fx + 2, r.y + 4, 9, 3, on ? f.neon : f.dimN); // insegna
      if (on) {
        R(g, r.x + f.fx + 4, r.y + 10, 4, 6, "#f8e05a"); // porta accesa
        R(g, r.x + f.fx + 10, r.y + 9, 2, 3, f.neon); // dettaglio laterale
      }
    });
  }
  function luogoFogne(g, on) { // m7: piazzale con tombino grande, seconda grata, tubo e cartello
    var r = MAPPA_PINS.m7;
    R(g, r.x, r.y, r.w, r.h, on ? "#2e3547" : M.dimScuro);
    O(g, r.x + 6, r.y + 7, 16, 11, "#0e1118", on ? "#4a5268" : M.dimMuro); // tombino grande
    R(g, r.x + 8, r.y + 10, 12, 1, "#0e1118"); // grata
    R(g, r.x + 8, r.y + 13, 12, 1, "#0e1118");
    R(g, r.x + 25, r.y + 16, 6, 4, on ? "#3d4657" : M.dimMuro); // seconda grata a terra
    R(g, r.x + 26, r.y + 17, 4, 1, "#0e1118");
    R(g, r.x + 26, r.y + 3, 4, 14, on ? "#3f4a3a" : M.dimMuro); // tubo verticale
    R(g, r.x + 25, r.y + 3, 6, 2, on ? "#4a5744" : M.dimMuro);
    // cartello di pericolo
    R(g, r.x + 2, r.y + 10, 1, 8, on ? "#8fa3ad" : "#3a4150");
    R(g, r.x, r.y + 6, 5, 5, on ? "#f0b84a" : M.dimChiaro);
    R(g, r.x + 2, r.y + 7, 1, 2, "#0e1118");
    R(g, r.x + 2, r.y + 10, 1, 1, "#0e1118");
    if (on) {
      R(g, r.x + 8, r.y + 11, 12, 2, "#5ce87f"); // bagliore verde dalla grata
      R(g, r.x + 7, r.y + 18, 14, 1, "#2e5c3a");
      R(g, r.x + 27, r.y, 2, 2, "#6a7280"); // sbuffo dal tubo
    }
  }

  // ----- renderer generico parametrico per i luoghi m9-m32 (mappa ingrandita) -----
  // Disegna un edificio dentro il rect r usando i primitivi R/O. cfg = { sil, base, tetto, acc }.
  // Convenzione on/off identica agli altri luoghi: acceso = colori vivi di cfg, spento = toni M.dim*.
  // 7 silhouette: box (tetto piatto), pitched (tetto a punta), dome (cupola), tent (padiglione),
  // tower (palazzo alto con griglia finestre), columns (facciata classica), wheel (ruota panoramica).
  function luogoGenerico(g, r, on, cfg) {
    var base = on ? cfg.base : M.dimMuro;
    var tetto = on ? cfg.tetto : M.dimChiaro;
    var acc = on ? cfg.acc : M.dimFinestra;
    var scuro = on ? "#0e1118" : M.dimScuro;
    var x = r.x, y = r.y, w = r.w, h = r.h;
    var cx = x + Math.floor(w / 2);
    var sil = cfg.sil;

    if (sil === "pitched") {
      // corpo + tetto a punta (triangolo a gradini)
      O(g, x + 2, y + 8, w - 4, h - 8, scuro, base);
      var ph = 8;
      for (var pr = 0; pr < ph; pr++) {
        var pw = Math.max(2, (w - 4) - pr * Math.max(1, Math.floor((w - 4) / (ph * 2))) * 2);
        R(g, cx - Math.floor(pw / 2), y + pr, pw, 1, tetto);
      }
      if (on) { R(g, cx - 3, y + h - 9, 6, 8, acc); R(g, x + 4, y + 12, 3, 3, acc); }
    } else if (sil === "dome") {
      // corpo squadrato + cupola arrotondata sopra
      O(g, x + 2, y + 9, w - 4, h - 9, scuro, base);
      R(g, x + 3, y + 6, w - 6, 4, tetto);       // tamburo
      R(g, x + 5, y + 3, w - 10, 3, tetto);      // spicchio medio
      R(g, cx - 3, y, 6, 3, tetto);              // calotta
      R(g, cx - 1, y - 2, 2, 2, on ? cfg.acc : M.dimChiaro); // pinnacolo
      if (on) { R(g, cx - 4, y + h - 9, 8, 8, acc); }
    } else if (sil === "tent") {
      // padiglione: tettoia a strisce ampia + corpo basso
      O(g, x + 2, y + 10, w - 4, h - 10, scuro, base);
      R(g, x, y + 6, w, 4, tetto);               // gronda tendone
      for (var ts = 0; ts < w; ts += 6) R(g, x + ts, y + 6, Math.min(3, w - ts), 4, on ? cfg.acc : M.dimScuro); // width clamp: niente sforo di 1px sul bordo destro (slot w=26)
      R(g, cx - 1, y, 2, 6, tetto);              // palo centrale
      R(g, cx - 3, y - 1, 6, 2, on ? cfg.acc : M.dimChiaro); // bandierina
      if (on) { R(g, cx - 3, y + h - 8, 6, 7, acc); }
    } else if (sil === "tower") {
      // palazzo alto con griglia di finestre
      O(g, x + 4, y, w - 8, h - 1, scuro, base);
      R(g, x + 4, y, w - 8, 2, tetto);           // coronamento
      for (var fy = y + 4; fy < y + h - 4; fy += 5) {
        for (var fx = x + 7; fx < x + w - 7; fx += 5) {
          R(g, fx, fy, 3, 3, acc);
        }
      }
    } else if (sil === "columns") {
      // facciata classica: timpano + colonne + portone
      R(g, x + 2, y, w - 4, 4, tetto);           // timpano/architrave
      R(g, x + 4, y + 2, w - 8, 1, scuro);
      O(g, x + 2, y + 4, w - 4, h - 4, scuro, base);
      for (var cxp = x + 5; cxp < x + w - 5; cxp += 6) R(g, cxp, y + 6, 3, h - 12, tetto); // colonne
      if (on) { R(g, cx - 3, y + h - 9, 6, 8, acc); } // portone
    } else if (sil === "wheel") {
      // ruota panoramica: mozzo + raggi + cabine + piloni
      R(g, x + 4, y + h - 6, 3, 6, tetto);       // piloni
      R(g, x + w - 7, y + h - 6, 3, 6, tetto);
      var wr = Math.min(Math.floor(w / 2) - 2, Math.floor((h - 6) / 2));
      var wcy = y + wr + 1;
      O(g, cx - wr, wcy - wr, wr * 2, wr * 2, scuro, base); // cerchione (approssimato a box)
      R(g, cx - wr, wcy, wr * 2, 1, tetto);      // raggi orizz/vert
      R(g, cx, wcy - wr, 1, wr * 2, tetto);
      R(g, cx - 2, wcy - 2, 4, 4, on ? cfg.tetto : M.dimChiaro); // mozzo
      if (on) {                                  // cabine luminose ai 4 poli
        R(g, cx - 1, wcy - wr - 1, 3, 3, acc);
        R(g, cx - 1, wcy + wr - 2, 3, 3, cfg.tetto);
        R(g, cx - wr - 1, wcy - 1, 3, 3, cfg.tetto);
        R(g, cx + wr - 2, wcy - 1, 3, 3, acc);
      }
    } else {
      // "box" (default): edificio a tetto piatto con cornicione
      O(g, x + 2, y + 4, w - 4, h - 4, scuro, base);
      R(g, x + 1, y + 2, w - 2, 3, tetto);       // cornicione/tetto piatto
      if (on) {
        R(g, x + 4, y + 8, 4, 4, acc);           // finestra
        R(g, x + w - 8, y + 8, 4, 4, acc);
        R(g, cx - 2, y + h - 8, 5, 7, acc);      // porta illuminata
      }
    }
    // dettaglio-icona distintivo (2-4px, colore acc) sopra il tetto, solo da acceso
    if (on) R(g, cx - 1, y + 1, 2, 2, cfg.acc);
  }

  // config per id m9-m32: silhouette + palette coerente col crepuscolo della palette M.
  var LUOGHI_CFG = {
    m9:  { sil: "tent",    base: "#1f5a52", tetto: "#3f9c88", acc: "#5ce8c8" }, // Fiera Scienza (verde/teal)
    m10: { sil: "dome",    base: "#4a5260", tetto: "#8fa3ad", acc: "#c9d2dc" }, // Arena Robotica (acciaio)
    m11: { sil: "pitched", base: "#5c4426", tetto: "#8a5c34", acc: "#f0b84a" }, // Rifugio Creature (marrone)
    m12: { sil: "box",     base: "#2e5c3a", tetto: "#3f9c5c", acc: "#8fe8a0" }, // Serra (verde chiaro vetro)
    m13: { sil: "box",     base: "#6e4826", tetto: "#a8743c", acc: "#f0a03c" }, // Bar dei Bulloni (ambra)
    m14: { sil: "tower",   base: "#3a4258", tetto: "#5c6b8a", acc: "#f0d089" }, // Palazzo senza Ascensore (grigio-blu)
    m15: { sil: "box",     base: "#4a3a5c", tetto: "#6e5680", acc: "#c4a4e8" }, // Vicoli del Centro (viola spento)
    m16: { sil: "box",     base: "#1c4a5c", tetto: "#2e6a8a", acc: "#5fd0f0" }, // Acquario (azzurro/acqua)
    m17: { sil: "box",     base: "#1f5250", tetto: "#3f9c88", acc: "#4de8c8" }, // Clinica di Modding (verde-teal)
    m18: { sil: "box",     base: "#5c4a26", tetto: "#a8863c", acc: "#f8e05a" }, // Caveau del Panino (oro)
    m19: { sil: "tent",    base: "#5c2452", tetto: "#a83c96", acc: "#e85ad8" }, // Talent Show (magenta)
    m20: { sil: "tower",   base: "#5c2830", tetto: "#a83c46", acc: "#e84040" }, // Quartiere sotto Attacco (rosso allerta)
    m21: { sil: "box",     base: "#3a2c5c", tetto: "#5c4a8a", acc: "#a86ee8" }, // Escape Room (viola)
    m22: { sil: "columns", base: "#4a5058", tetto: "#c9d2dc", acc: "#f4f0e0" }, // Tribunale (bianco marmo)
    m23: { sil: "columns", base: "#5c5236", tetto: "#c9a878", acc: "#f0d089" }, // Museo Civico (sabbia/tan)
    m24: { sil: "columns", base: "#2a2e5c", tetto: "#4a5299", acc: "#8fa0f0" }, // Museo notte (indaco)
    m25: { sil: "box",     base: "#3a1c4a", tetto: "#a83c96", acc: "#4dd8e8" }, // Sala Giochi FPS (magenta+ciano)
    m26: { sil: "pitched", base: "#3a4250", tetto: "#5c6470", acc: "#8fa3ad" }, // Tetti del Quartiere (ardesia)
    m27: { sil: "dome",    base: "#4a2830", tetto: "#a83c46", acc: "#4a7ba6" }, // Palasport Wrestling (rosso+blu)
    m28: { sil: "box",     base: "#4a4a2e", tetto: "#6e6a3c", acc: "#a8863c" }, // Discarica (oliva/marrone)
    m29: { sil: "wheel",   base: "#5c3a1e", tetto: "#f0b84a", acc: "#e84040" }, // Luna Park (giallo/rosso festoso)
    m30: { sil: "box",     base: "#1c4a52", tetto: "#2e7a8a", acc: "#4dd8e8" }, // Studio Social (ciano)
    m31: { sil: "box",     base: "#5c4626", tetto: "#c9a878", acc: "#f8e05a" }, // Sala Ricevimenti (oro caldo)
    m32: { sil: "box",     base: "#4a2450", tetto: "#a83c96", acc: "#f078d8" }, // Karaoke (rosa/viola neon)

    // ===== config m33-m64 (32 missioni ADULTO): stesso ventaglio di 7 silhouette di sopra,
    // combinazioni di colore nuove ma nella stessa famiglia "crepuscolo desaturato". =====
    m33: { sil: "dome",    base: "#5c2436", tetto: "#9c3c56", acc: "#f0c85a" }, // Palazzetto Mondiale (arti marziali, cremisi/oro)
    m34: { sil: "pitched", base: "#1f4a46", tetto: "#387a6e", acc: "#7ce8c4" }, // Lago Vaporoso (mostro, foschia teal)
    m35: { sil: "box",     base: "#4a3828", tetto: "#7a5c3c", acc: "#e8b060" }, // Palestra sul Monte (legno/pietra)
    m36: { sil: "box",     base: "#5c4a2e", tetto: "#8a723e", acc: "#e8d068" }, // Via del Mercato (bulli del racket)
    m37: { sil: "tent",    base: "#5c2e2e", tetto: "#a84a44", acc: "#f0e0d0" }, // Maratona Cinque Distretti (banner gara)
    m38: { sil: "tower",   base: "#2e5c3e", tetto: "#4a8a5c", acc: "#f4f0d8" }, // Stadio Comunale (Olimpiadi, BOSS)
    m39: { sil: "box",     base: "#3a3a44", tetto: "#5c5c6a", acc: "#e8507c" }, // Skatepark del Porto (cemento/graffiti)
    m40: { sil: "box",     base: "#2a1f5c", tetto: "#4a3c9c", acc: "#5ce8f0" }, // Sala Giochi speedrun (neon arcade)
    m41: { sil: "pitched", base: "#241c30", tetto: "#42304e", acc: "#8a3ce8" }, // Retro-Arcade "Gettone Nero" (cabinato maledetto)
    m42: { sil: "columns", base: "#4a4230", tetto: "#8a7c54", acc: "#d8c088" }, // Rovine sotto la Metro (scavo archeologico)
    m43: { sil: "tower",   base: "#3a3e4a", tetto: "#5c6478", acc: "#f04a3c" }, // Cortile-Base di Lancio (razzo)
    m44: { sil: "box",     base: "#4a342e", tetto: "#7a5648", acc: "#e8a878" }, // Quartiere (indagine gatti scomparsi)
    m45: { sil: "columns", base: "#2a3450", tetto: "#4a5888", acc: "#e8d078" }, // Università di Città (La Laurea, BOSS)
    m46: { sil: "columns", base: "#30425c", tetto: "#547298", acc: "#cfe4f4" }, // Palazzo del Concilio (ambasciatore)
    m47: { sil: "box",     base: "#2e2e3a", tetto: "#4c4c60", acc: "#e84a90" }, // Studi TV (talk show)
    m48: { sil: "columns", base: "#42423a", tetto: "#726e5c", acc: "#e8c860" }, // Piazza Municipale (Elezioni, BOSS)
    m49: { sil: "tent",    base: "#3a1f4a", tetto: "#6a3c8a", acc: "#f0e050" }, // Palco Festival Rock (headliner)
    m50: { sil: "box",     base: "#5c2e20", tetto: "#8a4a34", acc: "#f0a848" }, // Ristorante "Bestiale" (chef urlante)
    m51: { sil: "pitched", base: "#2e2438", tetto: "#4a3c5c", acc: "#7860a0" }, // Villa Abbandonata (infestata, gotico)
    m52: { sil: "box",     base: "#3e342a", tetto: "#6a5842", acc: "#c8863c" }, // Ferrovia di Ponente (rapina al treno)
    m53: { sil: "tower",   base: "#3a3a3a", tetto: "#605c54", acc: "#e8503c" }, // Palazzo Condannato (demolizione)
    m54: { sil: "columns", base: "#3e2e50", tetto: "#6a4c82", acc: "#f0d8a0" }, // Attico Vicini Ricchi (gemelli terribili)
    m55: { sil: "dome",    base: "#242e42", tetto: "#3c5270", acc: "#8fe0f0" }, // Stazione Orbitante (consegna spazio)
    m56: { sil: "pitched", base: "#24281f", tetto: "#40483a", acc: "#a8c85a" }, // Ultimo Indirizzo (pacco maledetto)
    m57: { sil: "tent",    base: "#5c2418", tetto: "#a8442c", acc: "#f0a83c" }, // Piazza della Sagra (peperoncino)
    m58: { sil: "columns", base: "#3a1f2e", tetto: "#6a3c54", acc: "#d8a8d8" }, // Teatro dell'Opera (fantasma)
    m59: { sil: "box",     base: "#5c3a1e", tetto: "#8a6034", acc: "#f0c860" }, // Pizzeria del Porto (tour de pizza)
    m60: { sil: "dome",    base: "#242840", tetto: "#3c4a70", acc: "#c8d8f8" }, // Osservatorio del Colle (meteorite)
    m61: { sil: "box",     base: "#4a3c24", tetto: "#7a6440", acc: "#e8d0a0" }, // Caccia al Tesoro Cittadina (mappa antica)
    m62: { sil: "box",     base: "#2e3a2e", tetto: "#4c5c48", acc: "#8ce860" }, // Cantina Condominiale (colonia mostri)
    m63: { sil: "tower",   base: "#3a2e2e", tetto: "#605048", acc: "#f0d83c" }, // Centrale del Quartiere (blackout)
    m64: { sil: "wheel",   base: "#4a3020", tetto: "#8a5c34", acc: "#4dd8e8" }, // Porto Vecchio (regata rottami, gru arrugginita)

    // ===== config m65-m72 (8 Grandi Imprese, GDD "P3 endgame"): palette DISTINTIVA oro/viola
    // scuro condivisa (acc sempre #f0c832, lo stesso oro dei pin sulla mappa) cosi' la fascia
    // finale si riconosce a colpo d'occhio anche prima di leggere i nomi; silhouette piu'
    // "monumentali" (dome/columns/tower) per il tono da endgame, con una eccezione ironica
    // (m71 box: il genio vive in un appartamento qualunque). =====
    m65: { sil: "dome",    base: "#2e1a3a", tetto: "#5c3a7a", acc: "#f0c832" }, // Monte Mascellone (Palestra degli Dei)
    m66: { sil: "columns", base: "#3a1a2a", tetto: "#7a3a54", acc: "#f0c832" }, // Arena Porto Vecchio (Ultimo Round)
    m67: { sil: "tower",   base: "#1a1a34", tetto: "#3a3a70", acc: "#f0c832" }, // Grattacielo Maledetto (Esorcismo)
    m68: { sil: "columns", base: "#3a2a1a", tetto: "#7a5c3a", acc: "#f0c832" }, // Strada Statale Tramonto (arco d'arrivo, Corsa Infinita)
    m69: { sil: "tower",   base: "#2e1a2e", tetto: "#6a3a6a", acc: "#f0c832" }, // Hotel Splendido (Foto del Secolo)
    m70: { sil: "dome",    base: "#241a3a", tetto: "#4a3a7a", acc: "#f0c832" }, // Cratere in Periferia (Oltre il Novemila)
    m71: { sil: "box",     base: "#2a1a3a", tetto: "#583a68", acc: "#f0c832" }, // Appartamento 4A (Il Teorema di Tutto)
    m72: { sil: "tower",   base: "#3a1a34", tetto: "#703a68", acc: "#f0c832" }, // Officina sul Tetto (Armatura di Latta)

    // ===== config m73-m98 (26 missioni extra, fix "mappa m73-98 ingiocabile"): stesso
    // ventaglio di 7 silhouette di sopra, palette "crepuscolo desaturato" coerente col tema di
    // ogni luogo (letto dal campo "- Luogo:" di ogni scheda in content/missioni.md). m73-80 =
    // baby (parco/giocattoli/orto/teatrino/limonata, toni piu' tenui); m81-98 = teen (porto,
    // feste, gelataio, go-kart, scacchi, cava, mercatino, recita, festa, erba alta, colori). =====
    m73: { sil: "tent",    base: "#2e5c30", tetto: "#4a8a3c", acc: "#c8e860" }, // Parco Giochi (Tiro alla Fune, prato/tenda gara)
    m74: { sil: "box",     base: "#4a3824", tetto: "#7a5c3a", acc: "#f0b860" }, // Casa del Vicino (Trasloco, legno caldo)
    m75: { sil: "dome",    base: "#245c3a", tetto: "#3c9c5c", acc: "#a8f088" }, // Parco Giochi (Acchiapparella, gazebo verde chiaro)
    m76: { sil: "tower",   base: "#3a4250", tetto: "#5c6a80", acc: "#e8d090" }, // Condominio (Piccolo Postino, grigio-blu)
    m77: { sil: "columns", base: "#4a4030", tetto: "#8a7a50", acc: "#e8c868" }, // Museo dei Piccoli (Puzzle, sabbia)
    m78: { sil: "box",     base: "#2e4a24", tetto: "#5c8a3c", acc: "#f04a4a" }, // Balcone di Casa (Orto, verde + fragola)
    m79: { sil: "pitched", base: "#5c3424", tetto: "#a85c3c", acc: "#f0c860" }, // Cortile del Palazzo (Teatrino, terracotta)
    m80: { sil: "box",     base: "#5c5424", tetto: "#a89c3c", acc: "#f0e060" }, // Marciapiede di Casa (Limonata, giallo limone)
    m81: { sil: "pitched", base: "#4a3020", tetto: "#7a5438", acc: "#4dc8e8" }, // Taverna del Porto (Braccio di Ferro, legno + riflesso mare)
    m82: { sil: "tower",   base: "#3a2050", tetto: "#6a3c8a", acc: "#f070d0" }, // Festa in Terrazza (Buttafuori, viola/neon)
    m83: { sil: "box",     base: "#5c2420", tetto: "#a8443c", acc: "#f0a83c" }, // Palestra di Quartiere (Istruttore Supplente, rosso/arancio)
    m84: { sil: "box",     base: "#2a4a54", tetto: "#3c8a9c", acc: "#f8d0e0" }, // Via del Mercato (Furgone del Gelataio, azzurro pastello)
    m85: { sil: "wheel",   base: "#4a2020", tetto: "#e84040", acc: "#f4f0e0" }, // Pista del Luna Park (Go-Kart, rosso corsa/scacchi)
    m86: { sil: "tower",   base: "#4a2c44", tetto: "#8a5478", acc: "#f0d8a0" }, // Pasticceria/Villa (Consegna Torta, elegante rosa/oro)
    m87: { sil: "box",     base: "#5c4420", tetto: "#a87c3c", acc: "#8ce860" }, // Mercato Rionale (Borseggiatore, frutta/verdura)
    m88: { sil: "dome",    base: "#1c4a54", tetto: "#2e8a9c", acc: "#8ff0e0" }, // Cava Allagata (Traversata, turchese acqua)
    m89: { sil: "columns", base: "#3a3e2c", tetto: "#6a704a", acc: "#d8c888" }, // Circolo degli Anziani (Scacchi, verde bottiglia/legno)
    m90: { sil: "box",     base: "#3a2e1c", tetto: "#6a5638", acc: "#f0d080" }, // Casa del Vicino sera (Ripetizioni, lampada calda)
    m91: { sil: "box",     base: "#241c40", tetto: "#4a3c8a", acc: "#5cf0e8" }, // Sala Giochi (Cabinato Rotto, neon arcade)
    m92: { sil: "pitched", base: "#1f3a24", tetto: "#3c6a3c", acc: "#e8e060" }, // Bosco del Parco Grande (Fungo Misterioso, giallo luminoso)
    m93: { sil: "box",     base: "#243a54", tetto: "#3c6a94", acc: "#f0f0f0" }, // Palestra della Scuola (DJ Festa, blu/bianco sportivo)
    m94: { sil: "box",     base: "#4a3c28", tetto: "#8a7048", acc: "#e8a060" }, // Piazzetta del Quartiere (Mercatino Usato, legno/ottone)
    m95: { sil: "columns", base: "#3a1c28", tetto: "#6a3448", acc: "#e8b878" }, // Teatro Parrocchiale (Recita, velluto rosso scuro)
    m96: { sil: "dome",    base: "#2e2450", tetto: "#5c3c8a", acc: "#f4d060" }, // Piazza Grande (Festa di Quartiere, BOSS, festa/lanterne)
    m97: { sil: "box",     base: "#3a4a1c", tetto: "#6a8a3c", acc: "#f0e838" }, // Erba Alta del Parco Grande (Mostriciattolo, scintille gialle)
    m98: { sil: "tower",   base: "#242c44", tetto: "#3c4c78", acc: "#e84a4a" }  // Piazzetta dell'Intervista (Colori Rubati, TV/diretta rosso)
  };

  var LUOGHI = {
    m0: luogoNegozio, m1: luogoSalaGiochi, m2: luogoParco, m3: luogoDojo, m4: luogoBiblioteca,
    m5: luogoIndustria, m6: luogoStudioTV, m7: luogoFogne, m8: luogoNeonAvenue
  };
  // Guardia anti-regressione (fix "mappa m73-98 ingiocabile", stesso difetto del vecchio bug
  // m33-m72): se in futuro un id missione finisce nel content/rotazione ma qualcuno si scorda
  // di aggiungergli il pin/config qui, la mappa NON deve rompersi per TUTTI gli altri luoghi —
  // salta quel singolo id con un warning (una volta sola per id, non ad ogni frame) invece di
  // lasciare che un'eccezione (rect.x su undefined) fermi l'intero ciclo di disegno/pin in
  // drawMappa. Usata sia dalla registrazione qui sotto sia dal ciclo pin di drawMappa.
  var _pinMancantiAvvisati = {};
  function avvisaPinMancante(id) {
    if (_pinMancantiAvvisati[id]) return;
    _pinMancantiAvvisati[id] = true;
    console.warn('pin mancante: ' + id);
  }

  // registrazione m9-m98: closure per-iterazione (IIFE) cosi' ogni closure cattura il proprio id.
  // m9-m32 = mappa ingrandita (fondatore); m33-m64 = 32 missioni ADULTO; m65-m72 = 8 Grandi
  // Imprese (P3); m73-m98 = 26 missioni extra. Stesso identico pattern per tutti: basta che
  // MAPPA_PINS/LUOGHI_CFG abbiano l'id, la registrazione e' automatica (v. fix "mappa adulto
  // ingiocabile" / "mappa m73-98 ingiocabile").
  (function () {
    for (var k = 9; k <= 98; k++) {
      (function (id) {
        var cfg = LUOGHI_CFG[id];
        LUOGHI[id] = function (g, on) {
          var rect = MAPPA_PINS[id];
          if (!rect || !cfg) { avvisaPinMancante(id); return; }
          luogoGenerico(g, rect, on, cfg);
        };
      })('m' + k);
    }
  })();

  // decorazioni di vita cittadina (sempre visibili, non sono luoghi missione)
  function mapAuto(g, x, y, col, verticale) {
    if (verticale) {
      R(g, x, y, 4, 9, "#0e1118");
      R(g, x, y + 1, 4, 7, col);
      R(g, x + 1, y + 2, 2, 2, "#1a2030"); // parabrezza
      R(g, x + 1, y + 6, 2, 1, "#1a2030");
    } else {
      R(g, x, y, 9, 4, "#0e1118");
      R(g, x + 1, y, 7, 4, col);
      R(g, x + 2, y + 1, 2, 2, "#1a2030");
      R(g, x + 6, y + 1, 1, 2, "#1a2030");
    }
  }
  function mapLampione(g, x, y) {
    R(g, x + 1, y + 2, 1, 7, M.lampione);
    R(g, x, y, 3, 2, M.lampLuce);
    R(g, x - 1, y + 2, 5, 1, M.lampAlone);
  }
  function mapZebra(g, x, y, orizzontale) {
    for (var i = 0; i < 4; i++) {
      if (orizzontale) R(g, x + i * 3, y, 2, 6, M.zebra);
      else R(g, x, y + i * 3, 6, 2, M.zebra);
    }
  }

  function mappaBase(g) {
    R(g, 0, 0, MAPPA_W, MAPPA_H, M.fondo);
    // isolati
    R(g, 0, 0, MAPPA_W, 43, M.isolato);
    R(g, 0, 51, MAPPA_W, 38, M.isolato);
    R(g, 0, 97, MAPPA_W, 31, M.isolato);
    // strade orizzontali
    R(g, 0, 44, MAPPA_W, 6, M.strada);
    R(g, 0, 90, MAPPA_W, 6, M.strada);
    for (var x = 2; x < MAPPA_W; x += 10) {
      R(g, x, 46, 5, 1, M.corsia);
      R(g, x, 92, 5, 1, M.corsia);
    }
    // strada verticale (interrotta dalla piazzetta)
    R(g, 69, 0, 6, 44, M.strada);
    R(g, 69, 96, 6, MAPPA_H - 96, M.strada);
    for (var y = 2; y < 44; y += 10) R(g, 71, y, 1, 5, M.corsia);
    for (var y2 = 98; y2 < MAPPA_H; y2 += 10) R(g, 71, y2, 1, 5, M.corsia);
    // marciapiedi
    R(g, 0, 43, MAPPA_W, 1, M.marciapiede);
    R(g, 0, 50, MAPPA_W, 1, M.marciapiede);
    R(g, 0, 89, MAPPA_W, 1, M.marciapiede);
    R(g, 0, 96, MAPPA_W, 1, M.marciapiede);
    R(g, 68, 0, 1, 44, M.marciapiede);
    R(g, 75, 0, 1, 44, M.marciapiede);
    R(g, 68, 96, 1, MAPPA_H - 96, M.marciapiede);
    R(g, 75, 96, 1, MAPPA_H - 96, M.marciapiede);
    // strisce pedonali
    mapZebra(g, 39, 44, true);
    mapZebra(g, 100, 90, true);
    // piazzetta centrale lastricata con fontana, panchina, idrante
    R(g, 58, 51, 28, 38, M.lastricato);
    for (var px = 60; px < 86; px += 6) R(g, px, 53, 1, 34, M.lastricatoChiaro);
    for (var py = 55; py < 89; py += 8) R(g, 59, py, 26, 1, M.lastricatoChiaro);
    O(g, 64, 62, 16, 12, "#0e1118", "#4a5268"); // fontana
    R(g, 66, 64, 12, 8, "#2e6a8a");
    R(g, 69, 66, 6, 2, "#8fd8f0");
    R(g, 71, 63, 2, 3, "#8fd8f0"); // zampillo
    R(g, 62, 80, 8, 2, "#75634c"); // panchina
    R(g, 62, 82, 1, 2, "#4a3a2e");
    R(g, 69, 82, 1, 2, "#4a3a2e");
    R(g, 80, 55, 3, 4, "#c23a3a"); // idrante
    R(g, 81, 54, 1, 1, "#c23a3a");
    // lampioni accesi
    mapLampione(g, 60, 53);
    mapLampione(g, 82, 78);
    mapLampione(g, 36, 32);
    mapLampione(g, 115, 78);
    // auto parcheggiate
    mapAuto(g, 100, 45, "#c23a3a", false);
    mapAuto(g, 20, 91, "#3a8ac2", false);
    mapAuto(g, 70, 20, "#8a4ab0", true);
    // casetta di riempimento (non è un luogo missione, sempre spenta)
    O(g, 122, 98, 20, 24, "#0e1118", M.dimMuro);
    R(g, 126, 104, 4, 5, M.dimFinestra);
    R(g, 134, 104, 4, 5, M.dimFinestra);
    R(g, 130, 114, 5, 8, M.dimScuro);

    // ===== Estensione città per il canvas ingrandito (216x224 all'epoca di m9-m32) =====
    // La zona storica (0..144 x 0..128) resta intatta sopra; qui riempiamo il resto cosi'
    // i nuovi edifici m9-m32 non galleggiano sul fondo. Isolati + un paio di strade + decori.
    // NOTA (fix "mappa adulto ingiocabile", MAPPA_H 224 -> 512 per m33-m72): il riempimento
    // isolato qui sotto e le due strade verticali usano "MAPPA_H - 128"/"MAPPA_H - 96" in modo
    // dinamico, quindi si sono gia' estesi da soli fino al nuovo fondo scala senza toccare
    // una riga di questa sezione. Sotto, un blocco dedicato aggiunge solo la tinta/soglia
    // della fascia finale Imprese (m65-m72).
    // Fascia destra (x 146..214, y 0..128): isolati sotto i nuovi edifici m9-m14
    R(g, 146, 0, MAPPA_W - 146, 128, M.isolato);
    R(g, 145, 0, 1, 128, M.marciapiede);        // marciapiede di raccordo con la zona storica
    // strada verticale sulla destra che scende dalla fascia destra alla fascia bassa
    R(g, 174, 40, 6, 88, M.strada);
    R(g, 173, 40, 1, 88, M.marciapiede);
    R(g, 180, 40, 1, 88, M.marciapiede);
    for (var yr = 44; yr < 128; yr += 10) R(g, 176, yr, 1, 5, M.corsia);

    // Fascia bassa (x 0..216, y 128..224): grande blocco di isolati con 2 strade a griglia
    R(g, 0, 128, MAPPA_W, MAPPA_H - 128, M.isolato);
    // strada orizzontale a met (separa le due file di edifici bassi m15-m20 / m21-m32)
    R(g, 0, 162, MAPPA_W, 6, M.strada);
    R(g, 0, 161, MAPPA_W, 1, M.marciapiede);
    R(g, 0, 168, MAPPA_W, 1, M.marciapiede);
    for (var xb = 2; xb < MAPPA_W; xb += 10) R(g, xb, 164, 5, 1, M.corsia);
    // strada orizzontale bassa (sotto la terza fila m27-m32)
    R(g, 0, 194, MAPPA_W, 4, M.strada);
    R(g, 0, 193, MAPPA_W, 1, M.marciapiede);
    R(g, 0, 198, MAPPA_W, 1, M.marciapiede);
    for (var xb2 = 4; xb2 < MAPPA_W; xb2 += 10) R(g, xb2, 195, 5, 1, M.corsia);
    // raccordo tra zona storica e fascia bassa (bordo superiore della fascia bassa)
    R(g, 0, 127, MAPPA_W, 1, M.marciapiede);
    // strada verticale che collega giu (allineata alla verticale storica ~x69)
    R(g, 100, 128, 6, MAPPA_H - 128, M.strada);
    R(g, 99, 128, 1, MAPPA_H - 128, M.marciapiede);
    R(g, 106, 128, 1, MAPPA_H - 128, M.marciapiede);
    for (var yv = 130; yv < MAPPA_H; yv += 10) R(g, 102, yv, 1, 5, M.corsia);
    // strisce pedonali agli incroci
    mapZebra(g, 108, 162, true);
    mapZebra(g, 36, 194, true);
    // lampioni e auto di contorno nelle nuove zone
    mapLampione(g, 160, 44);
    mapLampione(g, 20, 160);
    mapLampione(g, 150, 192);
    mapLampione(g, 190, 128);
    mapAuto(g, 176, 70, "#3a8ac2", true);
    mapAuto(g, 40, 170, "#c23a3a", false);
    mapAuto(g, 130, 200, "#8a4ab0", false);

    // ===== Zona finale: le 8 Grandi Imprese (m65-m72, y 568..630) =====
    // Tinta di terreno dedicata (viola scuro) + soglia dorata a y=552 (dentro lo stacco
    // verticale tra la griglia missioni m33-m98 e la fascia Imprese, v. MAPPA_PINS — spostata
    // in basso insieme ai pin quando e' stata aggiunta la griglia m73-m98): la zona si legge
    // come "distretto" a parte gia' dal terreno, ancora prima dei colori oro/viola degli
    // edifici (LUOGHI_CFG). Disegnata sopra il fondo isolato (gia' esteso dinamicamente sopra)
    // e sotto gli edifici (drawMappa li disegna dopo mappaBase), quindi non copre nulla.
    // Se le coordinate dei pin Imprese cambiano, spostare di conseguenza IMPRESE_ZONA_Y (ora
    // costante di modulo, v. sopra vicino a MAPPA_H_BASE/MAPPA_H_IMPRESE).
    // DISEGNATA SOLO se la mappa corrente e' quella alta (v. altezzaMappa): con la mappa corta
    // (nessuna Impresa da fare, es. pet ancora cucciolo) MAPPA_H vale MAPPA_H_BASE, che e'
    // esattamente IMPRESE_ZONA_Y — quindi non c'e' nemmeno lo spazio per questa fascia, e la si
    // salta invece di disegnarla per niente oltre il fondo scala del canvas corto.
    if (MAPPA_H > MAPPA_H_BASE) {
      R(g, 0, IMPRESE_ZONA_Y, MAPPA_W, MAPPA_H - IMPRESE_ZONA_Y, "#241934");
      R(g, 0, IMPRESE_ZONA_Y, MAPPA_W, 1, M.pinFill); // soglia dorata: da qui in poi il finale
      mapLampione(g, 20, IMPRESE_ZONA_Y + 6);
      mapLampione(g, 194, IMPRESE_ZONA_Y + 6);
    }
  }

  // stato = { attivi:['m1',...], inCorso:'m3'|null, frame:0|1, imprese:bool }
  function drawMappa(canvas, stato) {
    if (!canvas) return;
    stato = stato || {};
    var attivi = stato.attivi || [];

    // Altezza corrente della mappa (MAPPA_H_BASE corta, o MAPPA_H_IMPRESE con la fascia finale
    // Grandi Imprese): il modulo MAPPA_H e' usato da mappaBase (fondo/strade/la fascia Imprese
    // gated li' dentro) e qui sotto dallo scaleY. Lo impostiamo per la durata del draw e lo
    // ripristiniamo SEMPRE nel finally, cosi' non "sporca" i draw successivi (es. una mappa
    // corta dopo una con l'Impresa) — identico pattern di H in draw() qui sopra.
    var Hcorr = altezzaMappa(stato);
    var Hprec = MAPPA_H;
    MAPPA_H = Hcorr;
    try {
      var g = canvas.getContext("2d");
      g.imageSmoothingEnabled = false;
      g.clearRect(0, 0, canvas.width, canvas.height);
      var sx = canvas.width / MAPPA_W;
      var sy = canvas.height / MAPPA_H;
      var needsScale = sx !== 1 || sy !== 1;
      if (needsScale) { g.save(); g.scale(sx, sy); }

      mappaBase(g);
      var id;
      for (id in LUOGHI) {
        if (!Object.prototype.hasOwnProperty.call(LUOGHI, id)) continue;
        var on = attivi.indexOf(id) >= 0 || stato.inCorso === id;
        LUOGHI[id](g, on);
      }

      // pin sopra i luoghi attivi; quello in corso pulsa su 2 frame
      for (id in LUOGHI) {
        if (!Object.prototype.hasOwnProperty.call(LUOGHI, id)) continue;
        var rect = MAPPA_PINS[id];
        // guardia anti-regressione (v. avvisaPinMancante sopra): un id senza pin viene saltato
        // con un warning invece di far esplodere rect.x e fermare il disegno di TUTTI i pin.
        if (!rect) { avvisaPinMancante(id); continue; }
        if (stato.inCorso === id) {
          var su = stato.frame === 1 ? 2 : 0;
          mapPin(g, pinCx(rect), pinTipY(rect) - su, stato.frame === 1);
        } else if (attivi.indexOf(id) >= 0) {
          mapPin(g, pinCx(rect), pinTipY(rect), false);
        }
      }

      if (needsScale) g.restore();
    } finally {
      MAPPA_H = Hprec;
    }
  }

  // assert di sviluppo: rettangoli dentro il canvas, dimensioni minime, niente sovrapposizioni (luoghi e pin)
  // Negozio unico: MAPPA_PIN_SHOP e' un alias di MAPPA_PINS.m0 (v. sopra), quindi basta
  // controllare MAPPA_PINS una sola volta, nessun pin "shop" aggiuntivo da unire qui.
  function assertMappa() {
    var tuttiIPin = {};
    var idL;
    for (idL in MAPPA_PINS) {
      if (Object.prototype.hasOwnProperty.call(MAPPA_PINS, idL)) tuttiIPin[idL] = MAPPA_PINS[idL];
    }

    var ids = [];
    var id;
    for (id in tuttiIPin) {
      if (!Object.prototype.hasOwnProperty.call(tuttiIPin, id)) continue;
      ids.push(id);
      var r = tuttiIPin[id];
      // I pin delle Grandi Imprese (m65-m72) vivono OLTRE MAPPA_H_BASE, dentro la fascia che
      // esiste solo con la mappa ALTA (v. altezzaMappa/MAPPA_H_IMPRESE): vanno validati contro
      // quella, non contro MAPPA_H_BASE, altrimenti darebbero un falso errore "esce dal canvas"
      // sulla mappa corta — stessa identica logica di Hslot in assertSlots per il 4o slot
      // arredo (v. sotto). Nota: si usano le costanti esplicite, non il modulo MAPPA_H (che qui,
      // a module-load-time, non e' ancora mai stato toccato da un vero drawMappa()).
      var Hpin = (r.y >= MAPPA_H_BASE) ? MAPPA_H_IMPRESE : MAPPA_H_BASE;
      if (r.x < 0 || r.y < 0 || r.x + r.w > MAPPA_W || r.y + r.h > Hpin) {
        console.error("PETQ.rooms: _mappaPins." + id + " esce dal canvas " + MAPPA_W + "x" + Hpin);
      }
      if (r.w < 16 || r.h < 14) {
        console.error("PETQ.rooms: _mappaPins." + id + " sotto la dimensione minima 16x14 (" + r.w + "x" + r.h + ")");
      }
    }
    function overlap(a, b) {
      return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
    }
    function pinBox(rect) {
      var tipY = pinTipY(rect), cx = pinCx(rect);
      return { x: cx - 4, y: tipY - 12, w: 9, h: 12 }; // include il margine di pulsazione
    }
    for (var i = 0; i < ids.length; i++) {
      for (var j = i + 1; j < ids.length; j++) {
        if (overlap(tuttiIPin[ids[i]], tuttiIPin[ids[j]])) {
          console.error("PETQ.rooms: luoghi sovrapposti " + ids[i] + " / " + ids[j]);
        }
        if (overlap(pinBox(tuttiIPin[ids[i]]), pinBox(tuttiIPin[ids[j]]))) {
          console.error("PETQ.rooms: pin sovrapposti " + ids[i] + " / " + ids[j]);
        }
      }
    }
  }
  assertMappa();

  // ===================================================================================
  // ===== Mappa QUARTIERE: SOLO il quartiere di oggi, grande, mappa bassa un terzo =====
  // ===================================================================================
  // Richiesta fondatore 28 lug 2026: la mappa sopra (drawMappa/MAPPA_PINS) e' l'ATLANTE
  // dell'intero gioco — 99 edifici disegnati per 99 missioni, corrispondenza perfetta, nessuna
  // decorazione — ma ogni giorno ne sono accesi al massimo 6 (rosa del giorno fino a 3 +
  // Negozio sempre + Clinica di Modding pendente + Grande Impresa pendente, v. statoMappa in
  // ui.js) e i restanti 93+ sono spenti e mai toccabili: comprimere ancora la griglia non
  // risolve nulla, il taglio vero e' smettere di disegnare l'atlante. drawMappa/MAPPA_PINS NON
  // vengono toccate: restano per un eventuale ritorno alla vista d'insieme.
  //
  // GEOMETRIA RIVISTA (fondatore, stesso giorno, seconda passata dopo aver visto la prima a
  // schermo: la prima taratura era fatta sulle sole misure della griglia m9+ e non teneva conto
  // che l'arte hero m0-m8 e' molto piu' grande — risultato "m5/m8 si toccano" + "il pin non sta
  // sopra il suo edificio" + "riga bassa con un edificio solo perso a sinistra"). Numeri
  // attuali, non ricalcolati oltre: spazio logico 216 (= MAPPA_W) x 130 con due righe / 76 con
  // una sola. Slot 64x38 (contiene anche l'hero piu' grande, 62x36, con margine), gap
  // orizzontale FISSO 6 fra due slot della stessa riga. Ogni riga si centra DA SOLA in base a
  // quanti edifici contiene (non piu' colonne fisse): sinistra = (216 - n*64 - (n-1)*6) / 2,
  // poi passo 70 (=64+6) — 1 in riga -> x=76; 2 -> x=41,111; 3 -> x=6,76,146 (v.
  // quartiereXPerRiga). Righe a y=26 (prima) e y=84 (seconda). Fino a 3 attivi: una riga sola.
  // Da 4 in su: DUE righe BILANCIATE (mai "prima piena, seconda quasi vuota" — il difetto visto
  // a schermo): 4->2+2, 5->3+2, 6->3+3 (v. quartiereDistribuzioneRighe). L'ordine di
  // riempimento resta quello di ARRIVO in stato.attivi (+ stato.inCorso in coda se assente, v.
  // idsAttiviQuartiere sotto), riga alta prima, dentro ogni riga sinistra verso destra.
  var QUARTIERE_W = MAPPA_W; // stesso spazio logico orizzontale della mappa d'insieme (216)
  var QUARTIERE_SLOT_W = 64, QUARTIERE_SLOT_H = 38;
  var QUARTIERE_GAP_X = 6; // gap orizzontale fisso fra due slot della stessa riga
  var QUARTIERE_ROW_Y = [26, 84];
  var QUARTIERE_H_PIENA = 130, QUARTIERE_H_CORTA = 76;

  // gli id "hero" m0-m8 hanno arte dedicata che legge le proprie coordinate FISSE da MAPPA_PINS
  // al proprio interno (v. luogoNegozio ecc. sopra: nessuna prende un rect come parametro) — per
  // riposizionarli in uno slot qualsiasi si trasla il contesto invece di passargli un rect nuovo,
  // v. disegnaLuogoQuartiere sotto.
  var QUARTIERE_HERO_IDS = { m0: 1, m1: 1, m2: 1, m3: 1, m4: 1, m5: 1, m6: 1, m7: 1, m8: 1 };

  // Rettangoli slot dell'ULTIMO drawMappaQuartiere: id -> {x,y,w,h}, STESSA forma di MAPPA_PINS
  // cosi' ui.js puo' riusare dentroRect/pinCx/pinTipY invariati. E' la fonte di verita' per
  // hit-test/etichette lato UI con la vista quartiere: MAPPA_PINS resta quella dell'atlante
  // (posizioni fisse, sbagliate qui — gli slot cambiano posto ogni giorno secondo la rosa).
  // Aggiornata ad ogni drawMappaQuartiere, mai svuotata altrove: se la mappa non e' mai stata
  // disegnata resta {} e l'hit-test lato UI semplicemente non trova nulla (stesso comportamento
  // "nessun pin" di un MAPPA_PINS mai popolato).
  var _quartiereRect = {};

  // stato.attivi (ordine di arrivo) + stato.inCorso in coda se assente (v. commento sopra):
  // e' la lista di id che il quartiere deve mostrare oggi.
  function idsAttiviQuartiere(stato) {
    var ids = (stato && stato.attivi) ? stato.attivi.slice() : [];
    if (stato && stato.inCorso && ids.indexOf(stato.inCorso) === -1) ids.push(stato.inCorso);
    return ids;
  }

  // Altezza logica per lo stato corrente (76 o 130, v. GEOMETRIA sopra): la UI la usa PRIMA di
  // disegnare per dimensionare canvas/aspect-ratio (stesso pattern di altezzaMappa/altezzaStanza),
  // altrimenti il disegno arriverebbe schiacciato o con un fondo scala vuoto sotto.
  function altezzaMappaQuartiere(stato) {
    var n = idsAttiviQuartiere(stato).length;
    return (n < 4) ? QUARTIERE_H_CORTA : QUARTIERE_H_PIENA;
  }

  // Posizioni x che centrano DA SOLA una riga di n edifici (formula del fondatore, v. GEOMETRIA
  // sopra): sinistra = (216 - n*64 - (n-1)*6) / 2, poi passo costante 70 (=slot+gap). n<=0 non ha
  // slot da piazzare.
  function quartiereXPerRiga(n) {
    if (n <= 0) return [];
    var passo = QUARTIERE_SLOT_W + QUARTIERE_GAP_X; // 70
    var sinistra = (QUARTIERE_W - n * QUARTIERE_SLOT_W - (n - 1) * QUARTIERE_GAP_X) / 2;
    var xs = [];
    for (var i = 0; i < n; i++) xs.push(sinistra + i * passo);
    return xs;
  }

  // Quanti edifici mettere in ciascuna riga secondo il totale (fondatore, fix "riga bassa con un
  // edificio solo incollato a sinistra e mezza mappa vuota"): fino a 3 una riga sola; da 4 in su
  // DUE righe BILANCIATE, mai "prima piena poi quasi vuota" — 4->2+2, 5->3+2, 6->3+3 (6 e' anche
  // il tetto: oltre viene tagliato PRIMA di arrivare qui, v. calcolaSlotQuartiere).
  function quartiereDistribuzioneRighe(n) {
    if (n <= 3) return [n];
    if (n === 4) return [2, 2];
    if (n === 5) return [3, 2];
    return [3, 3];
  }

  // Assegna gli slot in ordine di arrivo (v. sopra) secondo la distribuzione a righe bilanciate,
  // centrando ogni riga da sola. Difesa oltre i 6 (non dovrebbe mai succedere: rosa max 3 +
  // Negozio + Clinica + Grande Impresa = 6, v. statoMappa in ui.js): i soli primi 6 in ordine di
  // arrivo prendono uno slot, gli altri restano senza — nessuna eccezione, stesso spirito
  // difensivo di avvisaPinMancante.
  function calcolaSlotQuartiere(ids) {
    var lista = ids.slice(0, 6);
    var righe = quartiereDistribuzioneRighe(lista.length);
    var risultato = [];
    var cursore = 0;
    for (var r = 0; r < righe.length; r++) {
      var n = righe[r];
      var xs = quartiereXPerRiga(n);
      var y = QUARTIERE_ROW_Y[r];
      for (var c = 0; c < n; c++) {
        risultato.push({ id: lista[cursore], rect: { x: xs[c], y: y, w: QUARTIERE_SLOT_W, h: QUARTIERE_SLOT_H } });
        cursore++;
      }
    }
    return risultato;
  }

  // Rettangoli slot dell'ultimo disegno (v. _quartiereRect sopra): fonte di verita' per
  // hit-test/etichette lato ui.js con la vista quartiere.
  function rettangoliQuartiere() {
    return _quartiereRect;
  }

  // striscia di strada orizzontale subito sotto una riga di edifici (marciapiede + asfalto +
  // corsie tratteggiate + marciapiede, stesso stile di mappaBase): gli edifici "poggiano" sul
  // bordo superiore di questa striscia (v. spec fondatore).
  function quartiereStradaSottoRiga(g, rowY) {
    var yStrada = rowY + QUARTIERE_SLOT_H;
    R(g, 0, yStrada - 1, QUARTIERE_W, 1, M.marciapiede);
    R(g, 0, yStrada, QUARTIERE_W, 6, M.strada);
    for (var x = 2; x < QUARTIERE_W; x += 10) R(g, x, yStrada + 2, 5, 1, M.corsia);
    R(g, 0, yStrada + 6, QUARTIERE_W, 1, M.marciapiede);
  }

  // Sfondo: cielo (M.fondo) in alto, terreno (M.isolato) dall'orizzonte in giu' fino al fondo
  // scala — STESSE tinte di mappaBase, nessun colore nuovo inventato (v. spec fondatore). CIELO_H
  // (16) e' una striscia SOTTILE apposta (fix "con altezza 76 il cielo non deve essere meta'
  // mappa"): lascia solo un margine di 10px sopra la prima riga di edifici (y=26), quindi resta
  // sottile sia con una riga (16/76 = 21%) sia con due (16/130 = 12%). Una striscia di strada per
  // ogni riga effettivamente in uso (la riga bassa esiste solo con la mappa "piena" H=130, v.
  // altezzaMappaQuartiere). Un paio di decori di vita cittadina (funzioni gia' esistenti): con la
  // nuova geometria i margini laterali sono stretti (solo 6px per lato quando una riga ha 3
  // edifici, v. GEOMETRIA sopra) — troppo poco per un'auto (9px), quindi il lampione resta nel
  // margine sinistro (x=2, sta in 5px, verificato contro il caso piu' stretto: il primo slot di
  // una riga da 3 comincia a x=6) mentre l'auto va nella fascia di strada sotto la riga in alto
  // (che e' larga quanto tutta la mappa e non e' mai occupata da un edificio, quindi nessun
  // vincolo di colonna).
  function quartiereSfondo(g, Hcorr) {
    var CIELO_H = 16;
    R(g, 0, 0, QUARTIERE_W, Hcorr, M.fondo);
    R(g, 0, CIELO_H, QUARTIERE_W, Hcorr - CIELO_H, M.isolato);
    quartiereStradaSottoRiga(g, QUARTIERE_ROW_Y[0]);
    if (Hcorr === QUARTIERE_H_PIENA) quartiereStradaSottoRiga(g, QUARTIERE_ROW_Y[1]);
    mapLampione(g, 2, 32);
    mapAuto(g, 100, 65, "#3a8ac2", false);
  }

  // Un edificio nello slot assegnato. Gli hero m0-m8 (arte dedicata, coordinate FISSE lette
  // internamente da MAPPA_PINS) si disegnano traslando il contesto canvas — ma centrando la loro
  // dimensione NATIVA (mai riscalata) dentro il nuovo slot su ENTRAMBI gli assi, non solo
  // allineando l'angolo in alto a sinistra: fix del DIFETTO visto a schermo "il pin non sta sopra
  // il suo edificio" (prima si traslava per l'angolo, quindi un hero stretto come m0, 18px contro
  // uno slot che ora e' largo 64, restava tutto addossato a sinistra mentre il pin — sempre al
  // centro dello slot — cadeva a vuoto). Centrando su entrambi gli assi il centro dell'hero
  // coincide SEMPRE col centro dello slot, quindi col pin, qualunque sia la sua larghezza nativa
  // (da 18 a 62). Verificato leggendo luogoParco/luogoBiblioteca/luogoIndustria/
  // luogoSalaGiochi/luogoNegozio/luogoStudioTV/luogoDojo/luogoNeonAvenue/luogoFogne: disegnano
  // tutte relativo a r.x/r.y (r = MAPPA_PINS.mN), quindi la traslazione le riposiziona
  // correttamente. Lo slot (64x38) e' stato dimensionato apposta per contenere anche l'hero piu'
  // grande (m5/m8, 62x36) con margine (1px per lato, centrato): a differenza della prima misura
  // (40x34, dove i 62px di m5/m8 sfondavano lo slot) NESSUN hero puo' piu' sconfinare in quello
  // adiacente (fix DIFETTO "m5 e m8 si toccano"). Gli id m9+ invece non hanno una posizione
  // propria da traslare: sono gia' generici (luogoGenerico prende QUALSIASI rect e riempie
  // esattamente quello che gli si passa), quindi si chiamano direttamente passandogli lo slot,
  // bypassando il wrapper LUOGHI[id] che leggerebbe ancora MAPPA_PINS[id] (la vecchia posizione
  // fissa dell'atlante).
  function disegnaLuogoQuartiere(g, id, rect) {
    if (QUARTIERE_HERO_IDS[id]) {
      var orig = MAPPA_PINS[id];
      var dx = rect.x + (rect.w - orig.w) / 2 - orig.x;
      var dy = rect.y + (rect.h - orig.h) / 2 - orig.y;
      g.save();
      g.translate(dx, dy);
      LUOGHI[id](g, true);
      g.restore();
    } else {
      var cfg = LUOGHI_CFG[id];
      if (!cfg) { avvisaPinMancante(id); return; }
      luogoGenerico(g, rect, true, cfg);
    }
  }

  // stato = { attivi:['m1',...], inCorso:'m3'|null, frame:0|1 } — stessa forma di stato di
  // drawMappa (stato.imprese non serve qui: l'altezza segue solo il numero di luoghi attivi
  // oggi, v. altezzaMappaQuartiere, non lo stadio del pet/le Grandi Imprese).
  function drawMappaQuartiere(canvas, stato) {
    if (!canvas) return;
    stato = stato || {};
    var ids = idsAttiviQuartiere(stato);
    var slot = calcolaSlotQuartiere(ids);
    var Hcorr = altezzaMappaQuartiere(stato);

    // aggiorna la fonte di verita' per hit-test/etichette PRIMA di disegnare: cosi' resta
    // coerente anche se qualcosa nel disegno sotto lanciasse a meta' (non atteso, ma stesso
    // spirito difensivo del resto del modulo).
    var nuovi = {};
    var k;
    for (k = 0; k < slot.length; k++) nuovi[slot[k].id] = slot[k].rect;
    _quartiereRect = nuovi;

    var g = canvas.getContext("2d");
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);
    var sx = canvas.width / QUARTIERE_W;
    var sy = canvas.height / Hcorr;
    var needsScale = sx !== 1 || sy !== 1;
    if (needsScale) { g.save(); g.scale(sx, sy); }

    quartiereSfondo(g, Hcorr);
    for (k = 0; k < slot.length; k++) disegnaLuogoQuartiere(g, slot[k].id, slot[k].rect);

    // pin sopra ogni edificio mostrato, pulsante sul luogo in corso (stessa identica logica del
    // ciclo pin di drawMappa).
    for (k = 0; k < slot.length; k++) {
      var id = slot[k].id, rect = slot[k].rect;
      if (stato.inCorso === id) {
        var su = stato.frame === 1 ? 2 : 0;
        mapPin(g, pinCx(rect), pinTipY(rect) - su, stato.frame === 1);
      } else {
        mapPin(g, pinCx(rect), pinTipY(rect), false);
      }
    }

    if (needsScale) g.restore();
  }

  // ===== Arredi piazzati nelle stanze (112x64): 3 slot per stanza, footprint max ~14x14 =====
  // PROTOTIPO 2, Blocco 7 (collectables in TUTTE le stanze): ogni stanza ha 3 slot con supporti
  // coerenti col mobilio esistente e i due temi lab/ship, scelti per NON collidere con i mobili
  // chiave (frigo/fornelli, vasca/lavandino/infermeria, letto/comodino/scrivania), con le hotzone
  // (vasca x0-50 y20-64, frigo, letto, scrivania) ne' col pet (base al centro x48-64/y44-60, che
  // con l'idle "corre per casa" arriva fino a x32-80). V. _assertSlots per la verifica.
  // - Salone: supporti dedicati storici (mensola a muro con oggetti appoggiati piano y=14, zona
  //   ganci/quadri, pavimento a sinistra) — invariato.
  // - Cucina: mensola sopra i fornelli (parete libera y<16) + pavimento angolo sinistro (sotto il
  //   frigo, y>44) + pavimento far-right (fuori dalla banda del pet).
  // - Bagno: 2 muro (sopra la fascia, fuori dalla hotzone vasca) + 1 pavimento far-right sotto
  //   il lavandino (l'unico angolo di pavimento fuori da vasca e pet).
  // - Camera: mensolina a muro a sinistra (sopra la testiera) + muro centro + pavimento far-right.
  // I primi 3 slot sono quelli storici (validi su canvas W x 64). Il 4o slot (GDD "Slot arredo,
  // tetto passivo e Ingrandimento casa") vive nel PAVIMENTO ESTESO (y 64..80): compare/e'
  // piazzabile SOLO con Ingrandimento casa comprato (stanze alte 80). Footprint 14x14 -> y 64
  // tiene il mobile tra 64 e 78 (dentro il pavimento nuovo). x su un lato LIBERO dalla banda pet
  // (x32..80) e dai mobili: cucina/camera a sinistra (x2/x16), bagno x16, salone far-right (x92).
  var SLOT_SPOTS = {
    // NB il 4o slot (Ingrandimento casa) vive nella banda extra OLTRE H_BASE: quando H_BASE e'
    // passato da 64 a 96 (stanza piu' profonda) e' sceso con lei, da y=64 a y=96, altrimenti
    // sarebbe finito dentro la stanza normale e la casa sarebbe risultata gia' ingrandita.
    cucina: [[84, 2], [2, 48], [96, 48], [2, 96]],
    bagno:  [[32, 4], [64, 4], [92, 49], [16, 96]],
    salone: [[26, 0], [40, 4], [2, 46], [92, 96]],
    camera: [[28, 4], [58, 4], [96, 46], [16, 96]]
  };
  // tipo di supporto di ogni slot, nello stesso ordine di SLOT_SPOTS (il 4o e' sempre pavimento)
  var SLOT_TIPI = {
    cucina: ["mensola", "pavimento", "pavimento", "pavimento"],
    bagno:  ["muro", "muro", "pavimento", "pavimento"],
    salone: ["mensola", "muro", "pavimento", "pavimento"],
    camera: ["mensola", "muro", "pavimento", "pavimento"]
  };

  // supporto naturale di ogni arredo (chiavi normalizzate); tutto il resto -> pavimento
  var ARREDO_SUPPORTO = {
    postermotivazionale: "muro", fasciadamartialartist: "muro", completodamartialartist: "muro",
    bastonedacombattimento: "muro", saigemelli: "muro", nunchakuarrugginiti: "muro",
    kataneafarfalla: "muro", megafono: "muro", ombrellomeccanico: "muro",
    pattinospaiato: "muro", pattinidagara: "muro",
    coppaarcade: "mensola", statuettatipooscar: "mensola", macchininagiocattolo: "mensola",
    gamebitportatile: "mensola", fumettosarcastico: "mensola", albumdadisegno: "mensola",
    libro: "mensola", microfonogiocattolo: "mensola",
    tappetomorbido: "pavimento", pesi: "pavimento", scootergiocattolo: "pavimento",
    pallonedacalcio: "pavimento", lampadadaterra: "pavimento", piantinastrana: "pavimento",
    vascaidromassaggio: "pavimento", acquariodimeduse: "pavimento",
    servostazionediricarica: "pavimento", frigonuovo: "pavimento"
  };
  function supportoDi(nome) {
    var k = normalizzaArredo(nome);
    if (ARREDO_SUPPORTO[k]) return ARREDO_SUPPORTO[k];
    return "pavimento"; // topo, fallback e sconosciuti stanno a terra
  }

  var A_OUT = "#241c14";

  // Normalizzazione nome->chiave ARREDI (fix batch sprite 8 lug 2026): oltre agli spazi vanno
  // tolti anche apostrofi/trattini e le lettere accentate vanno de-accentate (NFD), altrimenti
  // "Disco d'Oro" / "Mecha-Bot" / "Panino Più Grande" non troverebbero MAI la loro chiave
  // (identificatori JS senza apostrofi/accenti) e cadrebbero sul pacchetto-regalo di fallback.
  function normalizzaArredo(nome) {
    return String(nome || "").toLowerCase()
      .normalize("NFD").replace(/[̀-ͯ]/g, "")
      .replace(/[^a-z0-9]/g, "");
  }

  // rastrelliera condivisa per le 4 armi
  function rastrelliera(g, x, y) {
    R(g, x + 2, y + 2, 2, 12, "#5c4426");
    R(g, x + 10, y + 2, 2, 12, "#5c4426");
    R(g, x + 2, y + 4, 10, 1, "#3a2c1a");
    R(g, x + 2, y + 11, 10, 1, "#3a2c1a");
  }

  var ARREDI = {
    // ===== COMPANION DEL SUPPORTER PACK (29 lug 2026) — stile Topo allenatore =====
    topochef: function (g, x, y) { // ratto cuoco: testa larga, orecchie tonde, toque
      R(g, x + 4, y + 0, 7, 3, "#f4f4f0");             // sbuffo della toque
      R(g, x + 5, y + 3, 5, 1, "#d8d4c8");             // fascia
      O(g, x + 0, y + 3, 5, 5, "#0e1118", "#c8a0a8");  // orecchio sx
      O(g, x + 9, y + 3, 5, 5, "#0e1118", "#c8a0a8");  // orecchio dx
      O(g, x + 1, y + 5, 12, 9, "#0e1118", "#9aa0a8"); // testa larga
      R(g, x + 4, y + 8, 2, 2, "#16120e");             // occhi
      R(g, x + 9, y + 8, 2, 2, "#16120e");
      R(g, x + 5, y + 11, 4, 3, "#c8ccd2");            // musetto chiaro
      R(g, x + 6, y + 12, 2, 1, "#e8a0b0");            // nasino
    },
    lumacadellepulizie: function (g, x, y) { // lumaca col guscio-spugna e la scia lucida
      O(g, x + 4, y + 2, 10, 9, "#0e1118", "#f0d858");
      R(g, x + 6, y + 4, 2, 2, "#c8a830");            // buchi della spugna
      R(g, x + 10, y + 6, 2, 2, "#c8a830");
      R(g, x + 7, y + 8, 2, 2, "#c8a830");
      O(g, x + 0, y + 8, 8, 5, "#0e1118", "#a8d8a0");
      R(g, x + 1, y + 5, 1, 3, "#a8d8a0");            // antenne
      R(g, x + 4, y + 5, 1, 3, "#a8d8a0");
      R(g, x + 1, y + 4, 1, 1, "#16120e");
      R(g, x + 4, y + 4, 1, 1, "#16120e");
      R(g, x + 0, y + 13, 11, 1, "#cfeef8");          // scia
    },
    piccionepostino: function (g, x, y) { // piccione col cappellino da fattorino e la lettera
      R(g, x + 3, y + 1, 7, 1, "#2e4a72");            // visiera
      R(g, x + 4, y + 2, 5, 2, "#3a5a8a");
      O(g, x + 3, y + 4, 8, 6, "#0e1118", "#8a98a8");
      R(g, x + 5, y + 6, 1, 1, "#16120e");
      R(g, x + 1, y + 7, 2, 2, "#f0a030");            // becco
      O(g, x + 5, y + 9, 9, 5, "#0e1118", "#6a7888");
      R(g, x + 7, y + 10, 5, 3, "#f4f0e0");           // lettera
      R(g, x + 7, y + 11, 5, 1, "#c85a5a");           // sigillo
    },
    cricetodinamo: function (g, x, y) { // criceto nella ruota
      // ruota: ANELLO a fasce, non un rettangolo pieno (sembrerebbe una scatola)
      R(g, x + 4, y + 0, 6, 1, "#8a9098");
      R(g, x + 2, y + 1, 10, 1, "#8a9098");
      R(g, x + 1, y + 2, 1, 10, "#8a9098");
      R(g, x + 12, y + 2, 1, 10, "#8a9098");
      R(g, x + 2, y + 12, 10, 1, "#8a9098");
      R(g, x + 4, y + 13, 6, 1, "#8a9098");
      R(g, x + 3, y + 3, 2, 2, "#5a6068");            // raggi accennati
      R(g, x + 9, y + 9, 2, 2, "#5a6068");
      O(g, x + 4, y + 5, 7, 7, "#0e1118", "#e8b878"); // criceto
      R(g, x + 3, y + 4, 2, 2, "#e8b878");            // orecchie
      R(g, x + 10, y + 4, 2, 2, "#e8b878");
      R(g, x + 6, y + 7, 1, 1, "#16120e");
      R(g, x + 9, y + 7, 1, 1, "#16120e");
      R(g, x + 7, y + 9, 2, 1, "#c88a6a");
    },
    // Caricatore da Viaggio — premio del traguardo 7 giorni dello streak (Retention 2.0/A2).
    // Non e' in vendita e non si trova in missione: e' l'unico modo di averlo, quindi deve
    // leggersi come un oggetto ESCLUSIVO anche a 14 pixel. La barra di carica verde e' la
    // stessa della batteria nell'HUD: chi lo vede in stanza riconosce subito di cosa parla.
    /* Il Tuo Ritratto (perk Ritrattista). A 14x14 un ritratto 32x32 non si legge — provare a
     * rimpicciolirlo darebbe tre pixel di poltiglia. Quindi in stanza si disegna una CORNICE
     * APPESA, che si riconosce subito per quello che e', e il ritratto vero si guarda grande nella
     * scheda del pet. Meglio un simbolo leggibile di una miniatura illeggibile.
     * Dentro la cornice un accenno di figura (testa e spalle) e non un rettangolo pieno: e' quello
     * che fa capire che il quadro e' un RITRATTO e non uno specchio. */
    iltuoritratto: function (g, x, y) {
      R(g, x + 6, y + 0, 2, 2, '#6a5a48');             // chiodo e filo
      R(g, x + 1, y + 2, 12, 12, '#8a6a3a');           // cornice, legno
      R(g, x + 2, y + 3, 10, 10, '#c8a45c');           // battuta chiara
      R(g, x + 3, y + 4, 8, 8, '#efe6d2');             // tela
      R(g, x + 6, y + 5, 3, 3, '#e0b98d');             // testa
      R(g, x + 5, y + 8, 5, 3, '#4a6a9a');             // spalle
      R(g, x + 6, y + 6, 1, 1, '#3a2a20');             // due occhi: bastano a farla una persona
      R(g, x + 8, y + 6, 1, 1, '#3a2a20');
      R(g, x + 3, y + 4, 1, 4, '#ffffff');             // luce sul vetro
    },
    caricatoredaviaggio: function (g, x, y) {
      O(g, x + 1, y + 1, 11, 12, "#0e1118", "#414b5c"); // corpo
      R(g, x + 2, y + 2, 9, 10, "#2b3341");             // pannello incassato
      R(g, x + 2, y + 2, 1, 10, "#5c687c");             // luce sul bordo sinistro

      // Fulmine: il simbolo della carica si legge a colpo d'occhio anche a 14 pixel, dove uno
      // schermo con dei led fa solo "elettrodomestico" (primo tentativo scartato: sembrava un
      // frigo). Righe scritte una per una perche' qui la forma E' il disegno.
      R(g, x + 7, y + 3, 2, 1, "#ffd23f");
      R(g, x + 6, y + 4, 2, 1, "#ffd23f");
      R(g, x + 5, y + 5, 2, 1, "#ffd23f");
      R(g, x + 4, y + 6, 5, 1, "#ffd23f");
      R(g, x + 6, y + 7, 2, 1, "#ffd23f");
      R(g, x + 5, y + 8, 2, 1, "#ffd23f");
      R(g, x + 4, y + 9, 2, 1, "#ffd23f");

      R(g, x + 3, y + 11, 7, 1, "#1b212c");             // livello di carica
      R(g, x + 3, y + 11, 5, 1, "#3ddc84");
      R(g, x + 12, y + 3, 2, 1, "#20262f");             // cavo che esce di lato
      R(g, x + 13, y + 4, 1, 5, "#20262f");
      R(g, x + 12, y + 9, 2, 2, "#8a98a8");             // testa dello spinotto
      R(g, x + 2, y + 13, 3, 1, "#20262f");             // due piedini: spezzano il rettangolo
      R(g, x + 8, y + 13, 3, 1, "#20262f");
    },
    // ===== GIOCATTOLI del revamp negozio (v171) — disegnati a mano 29 lug 2026 =====
    // Servono al negozio e al menu "Usa un giocattolo": senza, si vedeva la sagoma generica
    // di categoria. Nomi normalizzati (minuscole, niente spazi) come da normalizzaArredo.
    squalottotrescarpe: function (g, x, y) { // squalo di peluche azzurro, sdraiato
      R(g, x + 11, y + 3, 3, 3, "#3f7fae");             // pinna caudale alta
      R(g, x + 11, y + 10, 3, 3, "#3f7fae");            // pinna caudale bassa
      R(g, x + 5, y + 2, 3, 3, "#3f7fae");              // pinna dorsale
      O(g, x + 0, y + 5, 13, 7, "#0e1118", "#5aa8d8");  // corpo
      R(g, x + 1, y + 9, 10, 2, "#e8f0f8");             // pancia chiara
      R(g, x + 2, y + 7, 1, 1, "#16120e");              // occhio
      R(g, x + 1, y + 8, 3, 1, "#16120e");              // bocca
    },
    scatolettainutile: function (g, x, y) { // scatola di legno con la levetta
      R(g, x + 8, y + 1, 2, 2, "#e03030");              // pomello rosso
      R(g, x + 8, y + 3, 2, 3, "#16120e");              // levetta
      O(g, x + 1, y + 5, 12, 8, "#0e1118", "#a0703a");  // corpo
      R(g, x + 2, y + 6, 10, 1, "#c89858");             // luce sul bordo
      R(g, x + 2, y + 9, 4, 2, "#8a5c2c");              // sportellino
    },
    cartucciasoffiona: function (g, x, y) { // cartuccia grigia con etichetta, piu' lo sbuffo
      O(g, x + 3, y + 2, 10, 11, "#0e1118", "#9aa4b0"); // guscio
      R(g, x + 4, y + 3, 8, 4, "#e8d848");              // etichetta
      R(g, x + 5, y + 9, 6, 2, "#2b2b34");              // contatti
      R(g, x + 5, y + 11, 1, 2, "#2b2b34");
      R(g, x + 10, y + 11, 1, 2, "#2b2b34");
      R(g, x + 0, y + 5, 2, 1, "#d8e8f8");              // sbuffo d'aria
      R(g, x + 1, y + 7, 1, 1, "#d8e8f8");
    },
    paperottaconsigliera: function (g, x, y) { // paperella di gomma
      O(g, x + 1, y + 7, 11, 6, "#0e1118", "#f8d838"); // corpo
      O(g, x + 6, y + 2, 6, 6, "#0e1118", "#f8d838");  // testa
      R(g, x + 11, y + 4, 2, 2, "#f08030");            // becco
      R(g, x + 8, y + 4, 1, 1, "#16120e");             // occhio
      R(g, x + 2, y + 9, 4, 2, "#e8c020");             // ala
    },
    sferasentenziosa: function (g, x, y) { // sfera dei responsi
      // silhouette TONDA a tre fasce: con un rettangolo solo sembrava un televisore
      R(g, x + 4, y + 0, 6, 14, "#0e1118");
      R(g, x + 2, y + 1, 10, 12, "#0e1118");
      R(g, x + 1, y + 3, 12, 8, "#0e1118");
      R(g, x + 5, y + 1, 4, 12, "#3c3c4c");
      R(g, x + 3, y + 2, 8, 10, "#3c3c4c");
      R(g, x + 2, y + 4, 10, 6, "#3c3c4c");
      R(g, x + 3, y + 3, 2, 2, "#6a6a80");             // luce in alto a sinistra
      O(g, x + 4, y + 6, 6, 5, "#0e1118", "#e8f0f8");  // finestrella
      R(g, x + 6, y + 8, 2, 1, "#3050c8");             // triangolino blu
      R(g, x + 5, y + 9, 4, 1, "#3050c8");
    },
    trottolonesbatacchione: function (g, x, y) { // trottola da battaglia
      R(g, x + 5, y + 1, 4, 2, "#c8d0d8");             // albero
      O(g, x + 1, y + 3, 12, 5, "#0e1118", "#3aa8d8"); // disco
      R(g, x + 2, y + 4, 3, 1, "#8ae0f8");             // luce
      R(g, x + 9, y + 4, 3, 1, "#e8c040");             // accento oro
      R(g, x + 5, y + 8, 4, 3, "#9aa4b0");             // corpo
      R(g, x + 6, y + 11, 2, 2, "#16120e");            // punta
    },
    cubboloseifacce: function (g, x, y) { // cubo a nove caselle colorate
      O(g, x + 1, y + 1, 12, 12, "#0e1118", "#16120e");
      R(g, x + 2, y + 2, 3, 3, "#e03030"); R(g, x + 6, y + 2, 3, 3, "#f8d838"); R(g, x + 10, y + 2, 2, 3, "#3aa858");
      R(g, x + 2, y + 6, 3, 3, "#f08030"); R(g, x + 6, y + 6, 3, 3, "#e8f0f8"); R(g, x + 10, y + 6, 2, 3, "#3050c8");
      R(g, x + 2, y + 10, 3, 2, "#3aa858"); R(g, x + 6, y + 10, 3, 2, "#e03030"); R(g, x + 10, y + 10, 2, 2, "#f8d838");
    },
    peluffociarliero: function (g, x, y) { // peluche tondo, occhietti e beccuccio
      R(g, x + 2, y + 0, 2, 3, "#c07ad8");             // ciuffo sx
      R(g, x + 10, y + 0, 2, 3, "#c07ad8");            // ciuffo dx
      O(g, x + 1, y + 2, 12, 11, "#0e1118", "#d08ae8");
      // occhi PICCOLI e in alto: con occhi grandi il nero del contorno mangiava tutto il
      // corpo e restava una maschera invece di un peluche
      O(g, x + 3, y + 5, 4, 4, "#0e1118", "#ffffff");
      O(g, x + 8, y + 5, 4, 4, "#0e1118", "#ffffff");
      R(g, x + 4, y + 6, 1, 1, "#16120e");
      R(g, x + 9, y + 6, 1, 1, "#16120e");
      R(g, x + 6, y + 9, 2, 2, "#f0a030");             // becco
      R(g, x + 4, y + 11, 6, 1, "#b06ac8");            // pancia
    },
    ciucciolottopiagnucolone: function (g, x, y) { // ciuccio con anello e lacrimuccia
      O(g, x + 4, y + 0, 6, 5, "#0e1118", "#f8b0c8"); // anello
      R(g, x + 6, y + 2, 2, 1, "#20202c");            // buco
      O(g, x + 2, y + 5, 10, 5, "#0e1118", "#f8f0e0"); // scudetto
      R(g, x + 3, y + 6, 3, 1, "#ffffff");
      O(g, x + 5, y + 9, 4, 4, "#0e1118", "#f8d0b0"); // tettarella
      R(g, x + 0, y + 8, 1, 2, "#7ac8f0");            // lacrimuccia
    },
    pescionecantautore: function (g, x, y) { // pesce canterino sulla targa di legno
      O(g, x + 0, y + 8, 14, 5, "#0e1118", "#8a5c2c"); // targa
      R(g, x + 1, y + 9, 12, 1, "#a0703a");
      R(g, x + 10, y + 1, 3, 3, "#3f8a3e");            // coda
      R(g, x + 10, y + 6, 3, 2, "#3f8a3e");
      O(g, x + 1, y + 2, 10, 6, "#0e1118", "#5aa858"); // corpo
      R(g, x + 2, y + 3, 3, 1, "#8ad868");             // luce
      R(g, x + 1, y + 5, 2, 2, "#16120e");             // bocca aperta
      R(g, x + 4, y + 4, 1, 1, "#ffffff");             // occhio
      R(g, x + 12, y + 4, 1, 2, "#f8f0e0");            // notina
    },
    pallonedacalcio: function (g, x, y) { // bianco/nero a esagoni accennati
      O(g, x + 2, y + 3, 10, 11, "#0e1118", "#ffffff");
      R(g, x + 6, y + 7, 3, 3, "#16120e"); // pentagono centrale
      R(g, x + 3, y + 5, 2, 2, "#16120e"); // spicchi ai bordi
      R(g, x + 9, y + 5, 2, 2, "#16120e");
      R(g, x + 4, y + 11, 2, 2, "#16120e");
      R(g, x + 8, y + 11, 2, 2, "#16120e");
    },
    gamebitportatile: function (g, x, y) { // schermo acceso
      O(g, x + 2, y + 6, 10, 8, "#0e1118", "#5c6b74");
      R(g, x + 4, y + 8, 4, 4, "#5ce87f");
      R(g, x + 4, y + 8, 4, 1, "#b8ffd0"); // scanline
      R(g, x + 9, y + 8, 2, 2, "#e85a5a");
      R(g, x + 9, y + 11, 2, 1, "#f0b84a");
    },
    microfonogiocattolo: function (g, x, y) {
      R(g, x + 6, y + 5, 2, 7, "#5c6b74");
      O(g, x + 4, y + 1, 6, 5, A_OUT, "#c9d2dc");
      R(g, x + 5, y + 2, 2, 1, "#f4f4f0");
      R(g, x + 3, y + 12, 8, 2, "#37424c");
    },
    fumettosarcastico: function (g, x, y) {
      O(g, x + 3, y + 2, 9, 12, A_OUT, "#f0b84a");
      R(g, x + 4, y + 3, 7, 3, "#d83048");
      R(g, x + 6, y + 7, 2, 4, "#1e2830");
      R(g, x + 6, y + 12, 2, 1, "#1e2830");
    },
    coppaarcade: function (g, x, y) { // dorata brillante, base a filo mensola
      O(g, x + 2, y + 1, 10, 6, "#3a2808", "#f8c832");
      R(g, x, y + 2, 2, 3, "#f8c832"); // manici
      R(g, x + 12, y + 2, 2, 3, "#f8c832");
      R(g, x + 6, y + 7, 2, 4, "#c99a3c"); // stelo
      R(g, x + 3, y + 11, 8, 3, "#3a2808"); // base
      R(g, x + 4, y + 11, 6, 1, "#c99a3c");
      R(g, x + 3, y + 2, 2, 3, "#fff0a0"); // riflesso
    },
    macchininagiocattolo: function (g, x, y) {
      R(g, x + 1, y + 6, 12, 5, A_OUT);
      R(g, x + 2, y + 7, 10, 3, "#d83048");
      R(g, x + 4, y + 4, 6, 3, "#d83048");
      R(g, x + 5, y + 5, 3, 2, "#8fd8f0");
      R(g, x + 3, y + 11, 3, 3, "#1e2830");
      R(g, x + 9, y + 11, 3, 3, "#1e2830");
    },
    fasciadamartialartist: function (g, x, y) { // appesa a un chiodo
      R(g, x + 6, y + 1, 2, 2, "#8fa3ad");
      R(g, x + 3, y + 3, 8, 3, "#c22a3a");
      R(g, x + 4, y + 6, 2, 6, "#c22a3a");
      R(g, x + 8, y + 6, 2, 5, "#a02430");
    },
    completodamartialartist: function (g, x, y) { // su appendino
      R(g, x + 6, y, 2, 2, "#8fa3ad");
      R(g, x + 2, y + 2, 10, 1, "#5c4426");
      R(g, x + 3, y + 3, 8, 6, "#f4f0e0");
      R(g, x + 3, y + 9, 8, 2, "#c22a3a");
      R(g, x + 3, y + 11, 3, 3, "#f4f0e0");
      R(g, x + 8, y + 11, 3, 3, "#f4f0e0");
    },
    albumdadisegno: function (g, x, y) {
      O(g, x + 2, y + 5, 10, 9, A_OUT, "#f8f4ec");
      R(g, x + 3, y + 6, 1, 7, "#8fa3ad");
      R(g, x + 5, y + 8, 5, 1, "#4a7ba6");
      R(g, x + 5, y + 10, 4, 1, "#e85a5a");
      R(g, x + 10, y + 2, 2, 5, "#f0b84a"); // matita appoggiata
      R(g, x + 10, y + 1, 2, 1, "#37424c");
    },
    libro: function (g, x, y) { // dorso colorato ben visibile
      O(g, x + 4, y + 3, 7, 11, "#0e1118", "#4a7ba6");
      R(g, x + 5, y + 4, 2, 9, "#e85a5a"); // dorso rosso
      R(g, x + 9, y + 4, 1, 9, "#f4f0e0"); // taglio pagine
      R(g, x + 7, y + 6, 1, 3, "#f0b84a"); // fregio
    },
    ombrellomeccanico: function (g, x, y) { // chiuso, appoggiato
      R(g, x + 6, y + 1, 3, 3, "#8fa3ad");
      R(g, x + 6, y + 4, 3, 6, "#5c6b74");
      R(g, x + 5, y + 5, 1, 4, "#4a5760");
      R(g, x + 7, y + 10, 1, 3, "#37424c");
      R(g, x + 8, y + 12, 2, 1, "#37424c");
    },
    scootergiocattolo: function (g, x, y) {
      R(g, x + 10, y + 3, 2, 8, "#8fa3ad");
      R(g, x + 8, y + 3, 6, 1, "#8fa3ad");
      R(g, x + 2, y + 10, 9, 2, "#d83048");
      R(g, x + 2, y + 12, 3, 2, "#1e2830");
      R(g, x + 9, y + 12, 3, 2, "#1e2830");
    },
    megafono: function (g, x, y) { // rosso acceso, bocca bianca, outline scuro
      R(g, x + 1, y + 5, 5, 7, "#3a0e0e");
      R(g, x + 2, y + 6, 3, 5, "#c22a3a");
      R(g, x + 5, y + 3, 6, 11, "#3a0e0e");
      R(g, x + 6, y + 4, 4, 9, "#e84040");
      R(g, x + 11, y + 2, 2, 12, "#f4f0e0"); // bocca bianca
      R(g, x + 2, y + 12, 2, 2, "#37424c"); // manico
    },
    statuettatipooscar: function (g, x, y) { // oro brillante su base nera
      R(g, x + 6, y + 1, 2, 2, "#f8c832");
      R(g, x + 5, y + 3, 4, 6, "#f8c832");
      R(g, x + 6, y + 3, 1, 4, "#fff0a0");
      R(g, x + 6, y + 9, 2, 2, "#c99a3c");
      R(g, x + 3, y + 11, 8, 3, "#16120e"); // base nera
    },
    bastonedacombattimento: function (g, x, y) {
      rastrelliera(g, x, y);
      R(g, x + 6, y + 1, 2, 13, "#8a5c2e");
      R(g, x + 6, y + 1, 2, 1, "#5c3a1e");
      R(g, x + 6, y + 13, 2, 1, "#5c3a1e");
    },
    saigemelli: function (g, x, y) {
      rastrelliera(g, x, y);
      R(g, x + 5, y + 3, 1, 8, "#c9ccd4");
      R(g, x + 4, y + 5, 3, 1, "#c9ccd4");
      R(g, x + 8, y + 3, 1, 8, "#c9ccd4");
      R(g, x + 7, y + 5, 3, 1, "#c9ccd4");
    },
    nunchakuarrugginiti: function (g, x, y) {
      rastrelliera(g, x, y);
      R(g, x + 5, y + 3, 2, 5, "#a8622e");
      R(g, x + 8, y + 6, 2, 5, "#a8622e");
      R(g, x + 7, y + 5, 1, 2, "#5c5468");
    },
    kataneafarfalla: function (g, x, y) {
      rastrelliera(g, x, y);
      R(g, x + 5, y + 2, 1, 9, "#dfe4ec");
      R(g, x + 5, y + 11, 1, 2, "#5c3a1e");
      R(g, x + 8, y + 2, 1, 9, "#dfe4ec");
      R(g, x + 8, y + 11, 1, 2, "#5c3a1e");
    },
    pesi: function (g, x, y) { // outline netto + barra chiara: leggibile anche sul pad scuro ship
      O(g, x + 1, y + 7, 4, 7, "#0e1118", "#37424c");
      O(g, x + 9, y + 7, 4, 7, "#0e1118", "#37424c");
      R(g, x + 5, y + 9, 4, 2, "#c9d2dc");
      R(g, x + 2, y + 8, 1, 3, "#8fa3ad"); // riflesso piastra
    },
    pattinospaiato: function (g, x, y) {
      R(g, x + 4, y + 5, 6, 5, "#e85a3c");
      R(g, x + 3, y + 10, 8, 2, "#f4f4f0");
      R(g, x + 4, y + 12, 2, 2, "#1e2830");
      R(g, x + 8, y + 12, 2, 2, "#1e2830");
    },
    pattinidagara: function (g, x, y) {
      R(g, x + 1, y + 5, 5, 5, "#e85a3c");
      R(g, x, y + 10, 7, 2, "#f4f4f0");
      R(g, x + 8, y + 5, 5, 5, "#e85a3c");
      R(g, x + 7, y + 10, 7, 2, "#f4f4f0");
      R(g, x + 1, y + 12, 2, 2, "#1e2830");
      R(g, x + 10, y + 12, 2, 2, "#1e2830");
      R(g, x + 6, y + 2, 1, 3, "#f8f0a0"); // scintilla
      R(g, x + 5, y + 3, 3, 1, "#f8f0a0");
    },
    lampadadaterra: function (g, x, y) {
      R(g, x + 4, y + 1, 6, 4, "#f0b84a");
      R(g, x + 5, y + 2, 4, 1, "#f8e05a");
      R(g, x + 6, y + 5, 2, 7, "#5c6b74");
      R(g, x + 4, y + 12, 6, 2, "#37424c");
      R(g, x + 2, y + 5, 2, 1, "#4a4430"); // alone
      R(g, x + 10, y + 5, 2, 1, "#4a4430");
    },
    tappetomorbido: function (g, x, y) {
      O(g, x, y + 5, 14, 9, "#5c3020", "#a05838");
      R(g, x + 2, y + 7, 10, 1, "#c07a52");
      R(g, x + 2, y + 11, 10, 1, "#c07a52");
    },
    postermotivazionale: function (g, x, y) { // a muro
      O(g, x + 3, y + 1, 9, 12, A_OUT, "#f4f0e0");
      R(g, x + 4, y + 2, 7, 1, "#4a7ba6");
      R(g, x + 5, y + 4, 5, 4, "#f0b84a"); // sole
      R(g, x + 5, y + 9, 5, 1, "#37424c"); // motto
      R(g, x + 5, y + 11, 3, 1, "#37424c");
    },
    piantinastrana: function (g, x, y) {
      R(g, x + 5, y + 4, 1, 6, "#3f9c6a");
      R(g, x + 8, y + 2, 1, 8, "#3f9c6a");
      R(g, x + 4, y + 2, 2, 2, "#e85ad8");
      R(g, x + 7, y, 2, 2, "#5ae8e0");
      O(g, x + 3, y + 9, 8, 5, A_OUT, "#463868");
    },
    vascaidromassaggio: function (g, x, y) { // versione compatta
      O(g, x, y + 6, 14, 8, A_OUT, "#6a5fa0");
      R(g, x + 2, y + 8, 10, 3, "#4ac8e8");
      R(g, x + 4, y + 7, 2, 1, "#a8ecf8");
      R(g, x + 9, y + 5, 2, 2, "#a8ecf8"); // bolle
      R(g, x + 3, y + 3, 2, 2, "#a8ecf8");
    },
    acquariodimeduse: function (g, x, y) {
      O(g, x + 1, y + 2, 12, 12, A_OUT, "#123246");
      R(g, x + 3, y + 4, 8, 8, "#1a4a66");
      R(g, x + 4, y + 5, 3, 2, "#f0a0c0"); // medusa 1
      R(g, x + 5, y + 7, 1, 2, "#f0a0c0");
      R(g, x + 8, y + 8, 3, 2, "#c4a4e8"); // medusa 2
      R(g, x + 9, y + 10, 1, 2, "#c4a4e8");
      R(g, x + 3, y + 3, 8, 1, "#4dd8e8");
    },
    servostazionediricarica: function (g, x, y) {
      O(g, x + 3, y + 1, 8, 13, A_OUT, "#3a4258");
      R(g, x + 5, y + 3, 4, 3, "#4be8c8");
      R(g, x + 7, y + 7, 1, 2, "#f8e05a"); // fulmine
      R(g, x + 6, y + 9, 1, 2, "#f8e05a");
      R(g, x + 5, y + 12, 4, 1, "#5ae8e0");
    },
    frigonuovo: function (g, x, y) { // versione mini con badge
      O(g, x + 3, y + 1, 8, 13, A_OUT, "#f2ede0");
      R(g, x + 4, y + 6, 6, 1, "#b9b2a2");
      R(g, x + 9, y + 3, 1, 2, A_OUT);
      R(g, x + 9, y + 8, 1, 3, A_OUT);
      R(g, x + 4, y + 2, 3, 3, "#4dd8e8"); // badge nuovo
    },
    bracciomeccanicodabanco: function (g, x, y) { // base, braccio a L, pinza aperta
      R(g, x + 3, y + 11, 9, 3, "#37424c");
      R(g, x + 7, y + 4, 2, 8, "#5c6b74");
      R(g, x + 2, y + 3, 6, 2, "#8fa3ad");
      R(g, x + 6, y + 2, 3, 3, "#f0b84a");
      R(g, x + 2, y + 1, 1, 6, "#c9d2dc");
      R(g, x, y + 1, 2, 2, "#c9d2dc");
      R(g, x, y + 5, 2, 2, "#c9d2dc");
    },
    chipdimemoria: function (g, x, y) { // piedini oro sporgenti sotto il corpo verde
      R(g, x + 1, y + 4, 12, 1, "#f8c832");
      R(g, x + 1, y + 7, 12, 1, "#f8c832");
      R(g, x + 1, y + 10, 12, 1, "#f8c832");
      O(g, x + 3, y + 2, 8, 11, "#0e1118", "#2f8f4a");
      R(g, x + 5, y + 4, 4, 4, "#5ce87f");
      R(g, x + 6, y + 3, 2, 1, "#16120e");
    },
    ventolaovercloccata: function (g, x, y) { // pale a girandola, mozzo rovente, scie
      O(g, x + 1, y + 1, 12, 12, "#0e1118", "#1e2830");
      R(g, x + 3, y + 4, 3, 2, "#8fa3ad");
      R(g, x + 8, y + 3, 2, 3, "#8fa3ad");
      R(g, x + 8, y + 8, 3, 2, "#8fa3ad");
      R(g, x + 4, y + 8, 2, 3, "#8fa3ad");
      R(g, x + 6, y + 6, 2, 2, "#e84040");
      R(g, x + 2, y + 2, 2, 1, "#8fd8f0");
      R(g, x + 10, y + 11, 2, 1, "#8fd8f0");
    },
    torcialaser: function (g, x, y) { // fascio rosso sparato a sinistra
      R(g, x, y + 6, 5, 2, "#e84040");
      R(g, x, y + 6, 4, 1, "#ffb4b4");
      O(g, x + 5, y + 4, 4, 6, "#0e1118", "#c9d2dc");
      R(g, x + 9, y + 5, 4, 4, "#37424c");
      R(g, x + 10, y + 6, 2, 1, "#f0b84a");
      R(g, x + 13, y + 5, 1, 4, "#1e2830");
    },
    coppadellafiera: function (g, x, y) { // coppa argento con beuta teal
      O(g, x + 2, y + 1, 10, 6, "#1e2830", "#c9d2dc");
      R(g, x, y + 2, 2, 3, "#c9d2dc");
      R(g, x + 12, y + 2, 2, 3, "#c9d2dc");
      R(g, x + 6, y + 2, 2, 1, "#1a9e9e");
      R(g, x + 5, y + 3, 4, 3, "#3ccfcf");
      R(g, x + 6, y + 7, 2, 4, "#8fa3ad");
      R(g, x + 3, y + 11, 8, 3, "#37424c");
    },
    copparobotwars: function (g, x, y) { // robottino a braccia alzate sulla coppa
      R(g, x + 5, y, 4, 3, "#8fa3ad");
      R(g, x + 3, y, 2, 1, "#8fa3ad");
      R(g, x + 9, y, 2, 1, "#8fa3ad");
      R(g, x + 6, y + 1, 2, 1, "#e84040");
      O(g, x + 3, y + 3, 8, 5, "#3a2808", "#f8c832");
      R(g, x + 1, y + 4, 2, 2, "#f8c832");
      R(g, x + 11, y + 4, 2, 2, "#f8c832");
      R(g, x + 6, y + 8, 2, 3, "#c99a3c");
      R(g, x + 3, y + 11, 8, 3, "#16120e");
    },
    mechabot: function (g, x, y) { // squadrato, occhi verdi accesi
      O(g, x + 3, y + 1, 8, 5, "#0e1118", "#5c6b74");
      R(g, x + 4, y + 2, 2, 2, "#5ce87f");
      R(g, x + 8, y + 2, 2, 2, "#5ce87f");
      O(g, x + 4, y + 6, 6, 8, "#0e1118", "#8fa3ad");
      R(g, x + 6, y + 7, 2, 2, "#e84040");
      R(g, x + 6, y + 10, 2, 4, "#0e1118");
      R(g, x + 2, y + 6, 2, 4, "#5c6b74");
      R(g, x + 10, y + 6, 2, 4, "#5c6b74");
    },
    telecomandopirata: function (g, x, y) { // nero con teschio e antenna
      R(g, x + 9, y + 1, 1, 2, "#8fa3ad");
      R(g, x + 8, y, 2, 1, "#e84040");
      O(g, x + 3, y + 3, 8, 11, "#0e1118", "#1e2830");
      R(g, x + 5, y + 5, 5, 3, "#f4f4f0");
      R(g, x + 6, y + 6, 1, 1, "#1e2830");
      R(g, x + 8, y + 6, 1, 1, "#1e2830");
      R(g, x + 4, y + 10, 2, 2, "#e84040");
      R(g, x + 7, y + 10, 2, 2, "#5ce87f");
    },
    cuccia: function (g, x, y) { // mezzaluna con cuscino azzurro
      O(g, x + 1, y + 7, 12, 7, "#0e1118", "#8a5c2e");
      O(g, x + 1, y + 3, 4, 5, "#0e1118", "#8a5c2e");
      O(g, x + 9, y + 3, 4, 5, "#0e1118", "#8a5c2e");
      R(g, x + 4, y + 6, 6, 3, "#8fd8f0");
      R(g, x + 4, y + 6, 6, 1, "#c8ecfa");
    },
    distributoredicroccantini: function (g, x, y) { // tramoggia con croccantini a vista
      R(g, x + 4, y, 6, 1, "#e84040");
      O(g, x + 3, y + 1, 8, 7, "#0e1118", "#a8d8e8");
      R(g, x + 4, y + 4, 6, 3, "#c9803a");
      R(g, x + 5, y + 5, 1, 1, "#7a4a22");
      R(g, x + 8, y + 4, 1, 1, "#7a4a22");
      R(g, x + 5, y + 8, 4, 4, "#5c6b74");
      R(g, x + 2, y + 12, 10, 2, "#37424c");
    },
    gattinorobot: function (g, x, y) { // seduto, orecchie a punta, led verdi
      R(g, x + 3, y + 1, 2, 2, "#8fa3ad");
      R(g, x + 9, y + 1, 2, 2, "#8fa3ad");
      O(g, x + 3, y + 2, 8, 5, "#0e1118", "#c9d2dc");
      R(g, x + 4, y + 4, 2, 1, "#5ce87f");
      R(g, x + 8, y + 4, 2, 1, "#5ce87f");
      O(g, x + 4, y + 7, 6, 7, "#0e1118", "#c9d2dc");
      R(g, x + 10, y + 12, 3, 1, "#8fa3ad");
      R(g, x + 12, y + 8, 1, 5, "#8fa3ad");
    },
    manualedibotanica: function (g, x, y) { // copertina verde con foglia
      O(g, x + 2, y + 2, 10, 12, "#0e1118", "#2f8f4a");
      R(g, x + 3, y + 3, 1, 10, "#1e6b34");
      R(g, x + 6, y + 5, 3, 4, "#5ce87f");
      R(g, x + 7, y + 5, 1, 3, "#2f8f4a");
      R(g, x + 7, y + 4, 1, 1, "#5ce87f");
      R(g, x + 7, y + 9, 1, 2, "#8a5c2e");
      R(g, x + 5, y + 12, 5, 1, "#f0b84a");
    },
    piantaesotica: function (g, x, y) { // foglie storte e bacca magenta luminosa
      R(g, x + 6, y + 2, 2, 8, "#2f8f4a");
      R(g, x + 2, y + 4, 4, 2, "#2f8f4a");
      R(g, x + 2, y + 2, 2, 2, "#5ce87f");
      R(g, x + 8, y + 5, 4, 2, "#2f8f4a");
      R(g, x + 10, y + 3, 2, 2, "#5ce87f");
      R(g, x + 6, y, 2, 2, "#e85ad8");
      O(g, x + 4, y + 10, 6, 4, "#0e1118", "#b0563a");
    },
    trofeobracciodiferro: function (g, x, y) { // trofeo di latta, braccio piegato
      R(g, x + 3, y + 11, 8, 3, "#16120e");
      O(g, x + 4, y + 8, 6, 3, "#0e1118", "#8fa3ad");
      R(g, x + 5, y + 6, 5, 2, "#aab4c4");
      R(g, x + 8, y + 2, 2, 4, "#aab4c4");
      R(g, x + 7, y, 3, 2, "#8fa3ad");
      R(g, x + 8, y + 2, 1, 3, "#dfe4ec");
      R(g, x + 6, y + 12, 3, 1, "#c22a3a");
    },
    trofeodorobracciodiferro: function (g, x, y) { // versione dorata sfarzosa
      R(g, x + 2, y + 11, 10, 3, "#16120e");
      R(g, x + 3, y + 11, 8, 1, "#c99a3c");
      O(g, x + 4, y + 8, 6, 3, "#3a2808", "#f8c832");
      R(g, x + 5, y + 6, 5, 2, "#f8c832");
      R(g, x + 8, y + 2, 2, 4, "#f8c832");
      R(g, x + 7, y, 3, 2, "#f8c832");
      R(g, x + 8, y + 2, 1, 3, "#fff0a0");
      R(g, x + 6, y + 9, 2, 1, "#e85a5a");
    },
    targatraslocatoredellanno: function (g, x, y) { // targa a muro con scatola
      O(g, x + 2, y + 1, 10, 12, "#0e1118", "#5c4426");
      R(g, x + 5, y + 3, 4, 4, "#c9a86a");
      R(g, x + 5, y + 4, 4, 1, "#8a5c2e");
      R(g, x + 4, y + 9, 6, 2, "#f8c832");
      R(g, x + 3, y + 2, 1, 1, "#8fa3ad");
      R(g, x + 10, y + 2, 1, 1, "#8fa3ad");
    },
    paperellaareazione: function (g, x, y) { // paperella col razzo sul dorso
      O(g, x + 2, y + 7, 9, 5, "#0e1118", "#f8d848");
      O(g, x + 1, y + 3, 5, 5, "#0e1118", "#f8d848");
      R(g, x, y + 5, 2, 2, "#f08828");
      R(g, x + 3, y + 4, 1, 1, "#0e1118");
      R(g, x + 8, y + 5, 2, 2, "#37424c");
      O(g, x + 6, y + 2, 6, 3, "#0e1118", "#c9d2dc");
      R(g, x + 8, y + 3, 2, 1, "#c22a3a");
      R(g, x + 12, y + 2, 2, 3, "#f0b84a");
    },
    scarpedaparkour: function (g, x, y) { // sneaker sfalsate con scie
      O(g, x + 1, y + 2, 7, 4, "#0e1118", "#f08828");
      R(g, x + 1, y + 6, 7, 1, "#f4f0e0");
      R(g, x + 3, y + 3, 2, 1, "#f4f0e0");
      R(g, x + 9, y + 3, 4, 1, "#c9d2dc");
      O(g, x + 5, y + 8, 8, 4, "#0e1118", "#f08828");
      R(g, x + 5, y + 12, 8, 1, "#f4f0e0");
      R(g, x + 8, y + 9, 2, 1, "#f4f0e0");
      R(g, x + 1, y + 9, 3, 1, "#c9d2dc");
    },
    acquariodicasa: function (g, x, y) { // pesce arancio e alghe
      R(g, x + 1, y + 1, 12, 1, "#37424c");
      O(g, x + 1, y + 2, 12, 12, "#0e1118", "#2a6a8e");
      R(g, x + 2, y + 3, 10, 1, "#4dd8e8");
      R(g, x + 2, y + 12, 10, 1, "#c9a86a");
      R(g, x + 9, y + 6, 1, 6, "#3f9c6a");
      R(g, x + 11, y + 8, 1, 4, "#2e7a50");
      R(g, x + 4, y + 7, 3, 2, "#f08828");
      R(g, x + 3, y + 7, 1, 2, "#d86818");
      R(g, x + 6, y + 7, 1, 1, "#0e1118");
    },
    paninopiugrandedelmondo: function (g, x, y) { // burger a 3 piani sotto campana
      R(g, x + 4, y + 2, 6, 2, "#d9a85c");
      R(g, x + 3, y + 4, 8, 1, "#7a4a26");
      R(g, x + 3, y + 5, 8, 1, "#f8c832");
      R(g, x + 3, y + 6, 8, 1, "#7a4a26");
      R(g, x + 3, y + 7, 8, 1, "#3f9c6a");
      R(g, x + 3, y + 8, 8, 1, "#7a4a26");
      R(g, x + 4, y + 9, 6, 2, "#d9a85c");
      R(g, x + 2, y + 2, 1, 9, "#bfe8f4");
      R(g, x + 11, y + 2, 1, 9, "#bfe8f4");
      R(g, x + 3, y + 1, 8, 1, "#bfe8f4");
      R(g, x + 6, y, 2, 1, "#8fa3ad");
      O(g, x + 1, y + 11, 12, 3, "#0e1118", "#dfe4ec");
    },
    discodoro: function (g, x, y) { // vinile dorato incorniciato
      O(g, x + 1, y + 1, 12, 12, "#0e1118", "#3a2c1a");
      R(g, x + 3, y + 3, 8, 8, "#1c2030");
      R(g, x + 5, y + 3, 4, 1, "#f8c832");
      R(g, x + 4, y + 4, 6, 4, "#f8c832");
      R(g, x + 5, y + 8, 4, 1, "#f8c832");
      R(g, x + 6, y + 5, 2, 2, "#c22a3a");
      R(g, x + 4, y + 4, 1, 2, "#fff0a0");
      R(g, x + 5, y + 11, 4, 1, "#c99a3c");
    },
    spadone: function (g, x, y) { // lama larga, elsa oro
      rastrelliera(g, x, y);
      R(g, x + 6, y, 2, 1, "#dfe4ec");
      R(g, x + 5, y + 1, 4, 8, "#dfe4ec");
      R(g, x + 5, y + 1, 1, 8, "#f8fbff");
      R(g, x + 6, y + 2, 1, 6, "#aab4c4");
      R(g, x + 3, y + 9, 8, 2, "#f0b84a");
      R(g, x + 6, y + 11, 2, 3, "#5c3a1e");
    },
    martellone: function (g, x, y) { // testa metallica massiccia
      rastrelliera(g, x, y);
      O(g, x + 3, y + 1, 8, 5, "#0e1118", "#6b7684");
      R(g, x + 4, y + 2, 2, 1, "#c9d2dc");
      R(g, x + 4, y + 4, 6, 1, "#4a545e");
      R(g, x + 6, y + 6, 2, 6, "#8a5c2e");
      R(g, x + 6, y + 12, 2, 2, "#c22a3a");
    },
    doppielame: function (g, x, y) { // lame gemelle a X
      rastrelliera(g, x, y);
      R(g, x + 2, y + 1, 2, 2, "#dfe4ec");
      R(g, x + 10, y + 1, 2, 2, "#dfe4ec");
      R(g, x + 4, y + 3, 2, 2, "#dfe4ec");
      R(g, x + 8, y + 3, 2, 2, "#dfe4ec");
      R(g, x + 6, y + 5, 2, 2, "#f8fbff");
      R(g, x + 4, y + 7, 2, 2, "#dfe4ec");
      R(g, x + 8, y + 7, 2, 2, "#dfe4ec");
      R(g, x + 2, y + 9, 2, 2, "#f0b84a");
      R(g, x + 10, y + 9, 2, 2, "#f0b84a");
    },
    arcopesante: function (g, x, y) { // arco teso con freccia, su appoggio
      R(g, x + 5, y + 1, 4, 2, "#8a5c2e");
      R(g, x + 4, y + 3, 2, 2, "#8a5c2e");
      R(g, x + 3, y + 5, 2, 4, "#8a5c2e");
      R(g, x + 4, y + 9, 2, 2, "#8a5c2e");
      R(g, x + 5, y + 11, 4, 2, "#8a5c2e");
      R(g, x + 8, y + 3, 1, 8, "#f4f0e0");
      R(g, x + 3, y + 6, 7, 1, "#d9a85c");
      R(g, x + 1, y + 5, 2, 3, "#dfe4ec");
      R(g, x + 10, y + 5, 2, 1, "#c22a3a");
      R(g, x + 10, y + 7, 2, 1, "#c22a3a");
      R(g, x + 2, y + 13, 10, 1, "#5c4426");
    },
    alabarda: function (g, x, y) { // asta con lama ad ascia e punta
      rastrelliera(g, x, y);
      R(g, x + 6, y + 2, 2, 12, "#8a5c2e");
      R(g, x + 6, y, 2, 2, "#dfe4ec");
      O(g, x + 2, y + 3, 4, 5, "#0e1118", "#c9d2dc");
      R(g, x + 8, y + 4, 2, 2, "#c9d2dc");
      R(g, x + 8, y + 7, 1, 3, "#c22a3a");
    },
    specchiodeldottorenigma: function (g, x, y) { // "?" inciso nel vetro
      O(g, x + 3, y + 1, 8, 12, "#0e1118", "#8fa3ad");
      R(g, x + 4, y + 2, 6, 10, "#bfe6ee");
      R(g, x + 4, y + 2, 1, 9, "#e8f8fc");
      R(g, x + 6, y + 4, 3, 1, "#2fbfa8");
      R(g, x + 8, y + 5, 1, 1, "#2fbfa8");
      R(g, x + 7, y + 6, 1, 2, "#2fbfa8");
      R(g, x + 7, y + 9, 1, 1, "#2fbfa8");
      R(g, x + 2, y + 13, 10, 1, "#57616c");
    },
    martellettodagiudice: function (g, x, y) { // su basetta
      O(g, x + 1, y + 2, 5, 6, "#0e1118", "#a9743c");
      R(g, x + 2, y + 3, 1, 4, "#c99a3c");
      R(g, x + 6, y + 4, 6, 2, "#5c3a1e");
      R(g, x + 9, y + 4, 1, 2, "#f0b84a");
      R(g, x + 11, y + 3, 2, 4, "#8a5c2e");
      O(g, x + 2, y + 10, 10, 4, "#0e1118", "#6e4a24");
      R(g, x + 3, y + 11, 8, 1, "#8a5c2e");
    },
    dipintoartistico: function (g, x, y) { // paesaggio, cornice dorata
      R(g, x + 6, y, 2, 1, "#37424c");
      O(g, x + 1, y + 1, 12, 12, "#0e1118", "#f0b84a");
      R(g, x + 2, y + 2, 10, 1, "#fff0a0");
      R(g, x + 3, y + 3, 8, 8, "#8fd8f0");
      R(g, x + 9, y + 4, 2, 2, "#f8c832");
      R(g, x + 5, y + 5, 3, 3, "#7b8ea0");
      R(g, x + 3, y + 8, 8, 3, "#5aa03c");
    },
    dipintofalso: function (g, x, y) { // storto, cornice cheap, targhetta
      O(g, x + 1, y + 3, 7, 9, "#0e1118", "#9a8468");
      O(g, x + 7, y + 2, 6, 9, "#0e1118", "#9a8468");
      R(g, x + 2, y + 4, 5, 4, "#a8c8d0");
      R(g, x + 8, y + 3, 4, 4, "#a8c8d0");
      R(g, x + 2, y + 8, 5, 3, "#6d9a54");
      R(g, x + 8, y + 7, 4, 3, "#6d9a54");
      R(g, x + 10, y + 4, 1, 1, "#e8d890");
      O(g, x + 4, y + 11, 7, 3, "#0e1118", "#f4f0e0");
      R(g, x + 6, y + 12, 3, 1, "#c22a3a");
    },
    lentedingrandimento: function (g, x, y) { // lente da detective
      O(g, x + 2, y + 1, 8, 8, "#0e1118", "#8fd8f0");
      R(g, x + 4, y + 3, 2, 2, "#e8f8fc");
      R(g, x + 9, y + 8, 2, 2, "#f0b84a");
      R(g, x + 10, y + 9, 2, 3, "#5c3a1e");
      R(g, x + 11, y + 11, 2, 3, "#8a5c2e");
    },
    dipintorubato: function (g, x, y) { // mezzo nascosto da un telo
      O(g, x + 1, y + 2, 12, 11, "#0e1118", "#f0b84a");
      R(g, x + 3, y + 4, 8, 7, "#8fd8f0");
      R(g, x + 3, y + 8, 8, 3, "#5aa03c");
      R(g, x + 9, y + 5, 2, 2, "#f8c832");
      R(g, x, y, 8, 12, "#3a4148");
      R(g, x + 2, y + 1, 1, 11, "#57616c");
      R(g, x + 5, y + 1, 1, 11, "#242b32");
      R(g, x + 1, y + 12, 5, 2, "#3a4148");
    },
    scarpedacorsa: function (g, x, y) { // sneaker di profilo
      R(g, x + 8, y + 3, 5, 5, "#0e1118");
      R(g, x + 9, y + 4, 3, 3, "#d83048");
      R(g, x + 9, y + 5, 2, 1, "#f4f0e0");
      R(g, x + 1, y + 6, 12, 5, "#0e1118");
      R(g, x + 2, y + 7, 10, 3, "#d83048");
      R(g, x + 2, y + 8, 8, 1, "#f8c832");
      R(g, x + 1, y + 11, 12, 2, "#f4f0e0");
      R(g, x + 1, y + 13, 12, 1, "#37424c");
    },
    coppadelvincitore: function (g, x, y) { // con bandierina a scacchi
      R(g, x + 12, y + 1, 1, 10, "#5c3a1e");
      R(g, x + 8, y + 1, 4, 2, "#f4f0e0");
      R(g, x + 8, y + 1, 1, 1, "#16120e");
      R(g, x + 10, y + 1, 1, 1, "#16120e");
      R(g, x + 9, y + 2, 1, 1, "#16120e");
      R(g, x + 11, y + 2, 1, 1, "#16120e");
      O(g, x + 2, y + 2, 6, 5, "#0e1118", "#f8c832");
      R(g, x + 3, y + 3, 1, 3, "#fff0a0");
      R(g, x + 1, y + 3, 1, 3, "#c99a3c");
      R(g, x + 8, y + 3, 1, 3, "#c99a3c");
      R(g, x + 4, y + 7, 2, 4, "#c99a3c");
      R(g, x + 2, y + 11, 8, 3, "#16120e");
    },
    console: function (g, x, y) { // con controller e led
      O(g, x + 1, y + 2, 12, 5, "#0e1118", "#37424c");
      R(g, x + 3, y + 4, 6, 1, "#242b32");
      R(g, x + 10, y + 3, 1, 1, "#38e06e");
      R(g, x + 6, y + 7, 1, 3, "#242b32");
      O(g, x + 3, y + 9, 8, 5, "#0e1118", "#5c6b74");
      R(g, x + 5, y + 10, 1, 3, "#1e2830");
      R(g, x + 4, y + 11, 3, 1, "#1e2830");
      R(g, x + 8, y + 10, 1, 1, "#e85a5a");
      R(g, x + 9, y + 11, 1, 1, "#f8c832");
    },
    gabbiaperuccelli: function (g, x, y) { // vuota, sportellino aperto
      R(g, x + 6, y, 2, 2, "#37424c");
      O(g, x + 3, y + 2, 9, 10, "#0e1118", "#eef2f6");
      R(g, x + 5, y + 3, 1, 8, "#8fa3ad");
      R(g, x + 7, y + 3, 1, 8, "#8fa3ad");
      R(g, x + 9, y + 3, 1, 2, "#8fa3ad");
      R(g, x + 11, y + 5, 1, 4, "#eef2f6");
      R(g, x + 12, y + 4, 1, 6, "#0e1118");
      R(g, x + 3, y + 12, 9, 2, "#0e1118");
      R(g, x + 4, y + 12, 7, 1, "#f0b84a");
    },
    piccionecyborg: function (g, x, y) { // appollaiato sulla gabbietta
      R(g, x + 1, y + 3, 1, 2, "#57616c");
      O(g, x + 2, y + 2, 7, 6, "#0e1118", "#8fa3ad");
      R(g, x + 3, y + 3, 3, 2, "#c9ccd4");
      O(g, x + 8, y + 1, 4, 4, "#0e1118", "#7b8ea0");
      R(g, x + 10, y + 2, 1, 1, "#ff2d2d");
      R(g, x + 12, y + 2, 1, 1, "#f0b84a");
      R(g, x + 2, y + 8, 10, 1, "#0e1118");
      R(g, x + 3, y + 9, 1, 4, "#57616c");
      R(g, x + 6, y + 9, 1, 4, "#57616c");
      R(g, x + 9, y + 9, 1, 4, "#57616c");
      R(g, x + 2, y + 13, 10, 1, "#0e1118");
    },
    posterdelcampione: function (g, x, y) { // wrestler a braccia alzate
      O(g, x + 2, y + 1, 10, 13, "#0e1118", "#f4e8c8");
      R(g, x + 6, y + 3, 3, 3, "#c22a3a");
      R(g, x + 7, y + 4, 1, 1, "#f4f0e0");
      R(g, x + 4, y + 4, 1, 3, "#37424c");
      R(g, x + 10, y + 4, 1, 3, "#37424c");
      R(g, x + 5, y + 6, 5, 3, "#37424c");
      R(g, x + 5, y + 9, 5, 1, "#f8c832");
      R(g, x + 5, y + 10, 2, 2, "#37424c");
      R(g, x + 8, y + 10, 2, 2, "#37424c");
      R(g, x + 4, y + 12, 7, 1, "#c22a3a");
    },
    pupazzomostriciattolo: function (g, x, y) { // occhione ciclope
      R(g, x + 3, y + 2, 2, 3, "#3d7a28");
      R(g, x + 9, y + 2, 2, 3, "#3d7a28");
      O(g, x + 3, y + 4, 8, 9, "#0e1118", "#5aa03c");
      R(g, x + 5, y + 6, 4, 3, "#f4f0e0");
      R(g, x + 6, y + 7, 2, 2, "#8a3ae0");
      R(g, x + 5, y + 10, 4, 1, "#16120e");
      R(g, x + 6, y + 10, 1, 1, "#f4f0e0");
      R(g, x + 4, y + 13, 2, 1, "#3d7a28");
      R(g, x + 8, y + 13, 2, 1, "#3d7a28");
    },
    adesivomartello: function (g, x, y) { // adesivo a muro col martello
      O(g, x + 1, y + 1, 12, 12, A_OUT, "#f8f4ec");
      R(g, x + 3, y + 3, 7, 3, "#e84040");
      R(g, x + 3, y + 6, 2, 1, "#a02430");
      R(g, x + 6, y + 6, 2, 6, "#8a5c2e");
      R(g, x + 11, y + 2, 1, 1, "#c9d2dc");
    },
    peluchelunapark: function (g, x, y) { // orsetto rosa da fiera
      R(g, x + 3, y + 2, 2, 2, "#f08bb0");
      R(g, x + 9, y + 2, 2, 2, "#f08bb0");
      O(g, x + 3, y + 3, 8, 5, A_OUT, "#f4a0c0");
      R(g, x + 5, y + 5, 1, 1, "#16120e");
      R(g, x + 8, y + 5, 1, 1, "#16120e");
      R(g, x + 6, y + 7, 2, 1, "#d83048");
      O(g, x + 2, y + 8, 10, 6, A_OUT, "#f4a0c0");
      R(g, x + 5, y + 9, 4, 3, "#fbd3e0");
    },
    martellovero: function (g, x, y) { // martellone da fiera, testona a terra
      R(g, x + 6, y + 1, 2, 7, "#8a5c2e");
      R(g, x + 6, y + 1, 2, 1, "#5c3a1e");
      O(g, x + 1, y + 8, 12, 6, "#0e1118", "#e84040");
      R(g, x + 2, y + 9, 3, 2, "#ff9a9a");
      R(g, x + 3, y + 12, 8, 1, "#a02430");
    },
    laptop: function (g, x, y) { // aperto, schermo acceso e adesivi
      O(g, x + 2, y + 2, 10, 8, "#0e1118", "#37424c");
      R(g, x + 4, y + 4, 6, 4, "#5ce87f");
      R(g, x + 4, y + 4, 6, 1, "#b8ffd0");
      R(g, x + 3, y + 3, 1, 1, "#f0b84a");
      R(g, x + 3, y + 10, 8, 1, "#4a5760");
      R(g, x + 1, y + 11, 12, 3, "#5c6b74");
      R(g, x + 2, y + 12, 7, 1, "#37424c");
      R(g, x + 10, y + 12, 2, 1, "#e85a5a");
    },
    completodachef: function (g, x, y) { // giacca bianca + toque sulla gruccia
      R(g, x + 4, y, 6, 2, "#ffffff");
      R(g, x + 5, y + 2, 4, 1, "#c9d2dc");
      R(g, x + 2, y + 3, 10, 1, "#5c4426");
      R(g, x + 3, y + 4, 8, 9, "#f8f4ec");
      R(g, x + 6, y + 4, 2, 1, "#d83048");
      R(g, x + 6, y + 5, 1, 7, "#c9d2dc");
      R(g, x + 8, y + 6, 1, 1, "#16120e");
      R(g, x + 8, y + 9, 1, 1, "#16120e");
    },
    parrucchinodielvis: function (g, x, y) { // ciuffo su testa di polistirolo
      R(g, x + 4, y + 5, 6, 6, "#f4f0e0");
      R(g, x + 5, y + 11, 4, 2, "#c9d2dc");
      R(g, x + 3, y + 13, 8, 1, "#37424c");
      R(g, x + 3, y + 3, 8, 3, "#16120e");
      R(g, x + 2, y + 1, 5, 3, "#16120e");
      R(g, x + 3, y + 2, 2, 1, "#4a7ba6");
      R(g, x + 4, y + 6, 1, 2, "#16120e");
      R(g, x + 9, y + 6, 1, 2, "#16120e");
    },
    camicedeldottore: function (g, x, y) { // su appendino, con stetoscopio
      R(g, x + 6, y, 2, 2, "#8fa3ad");
      R(g, x + 2, y + 2, 10, 1, "#5c4426");
      R(g, x + 3, y + 3, 8, 10, "#f8f4ec");
      R(g, x + 6, y + 4, 2, 9, "#c9d2dc");
      R(g, x + 4, y + 4, 1, 4, "#e85a5a");
      R(g, x + 4, y + 8, 2, 2, "#8fa3ad");
      R(g, x + 9, y + 7, 1, 2, "#4a7ba6");
    },
    togadaavvocato: function (g, x, y) { // su appendino, colletto bianco
      R(g, x + 6, y, 2, 2, "#8fa3ad");
      R(g, x + 2, y + 2, 10, 1, "#5c4426");
      R(g, x + 2, y + 3, 10, 10, "#1e2830");
      R(g, x + 3, y + 4, 1, 8, "#37424c");
      R(g, x + 10, y + 4, 1, 8, "#37424c");
      R(g, x + 5, y + 3, 4, 2, "#ffffff");
      R(g, x + 6, y + 5, 2, 3, "#f4f0e0");
    },
    mascheradawrestler: function (g, x, y) { // luchador rossa su supporto
      O(g, x + 3, y + 1, 8, 8, "#0e1118", "#d83048");
      R(g, x + 6, y + 2, 2, 2, "#f0b84a");
      R(g, x + 4, y + 4, 2, 2, "#ffffff");
      R(g, x + 8, y + 4, 2, 2, "#ffffff");
      R(g, x + 6, y + 7, 2, 1, "#f4f0e0");
      R(g, x + 6, y + 9, 2, 3, "#5c6b74");
      R(g, x + 4, y + 12, 6, 2, "#37424c");
    },
    bouquetdasposa: function (g, x, y) { // fiori bianco/rosa col nastro
      R(g, x + 3, y + 1, 3, 3, "#ffffff");
      R(g, x + 8, y + 1, 3, 3, "#ffffff");
      R(g, x + 5, y + 2, 4, 3, "#f4a0c0");
      R(g, x + 4, y + 5, 6, 2, "#4a8a4a");
      R(g, x + 4, y + 7, 6, 3, "#f4f0e0");
      R(g, x + 4, y + 8, 6, 1, "#d83048");
      R(g, x + 5, y + 10, 4, 2, "#f4f0e0");
      R(g, x + 6, y + 12, 2, 2, "#e8e0d0");
    },
    microfonodacantante: function (g, x, y) { // inclinato su asta da tavolo
      O(g, x + 2, y + 1, 6, 5, A_OUT, "#c9d2dc");
      R(g, x + 3, y + 2, 2, 1, "#ffffff");
      R(g, x + 7, y + 5, 3, 2, "#e85a5a");
      R(g, x + 9, y + 7, 2, 2, "#e85a5a");
      R(g, x + 9, y + 9, 2, 3, "#37424c");
      R(g, x + 6, y + 12, 8, 2, "#1e2830");
    },
    pistolasparaspazzatura: function (g, x, y) { // sci-fi a canna larga, su supporto
      R(g, x + 4, y + 2, 4, 2, "#5ce87f");
      O(g, x + 1, y + 4, 9, 4, "#0e1118", "#5c6b74");
      O(g, x + 9, y + 3, 4, 6, "#0e1118", "#4a8a4a");
      R(g, x + 10, y + 5, 2, 2, "#5ce87f");
      R(g, x + 2, y + 8, 3, 3, "#37424c");
      R(g, x + 3, y + 11, 8, 1, "#5c6b74");
      R(g, x + 4, y + 12, 6, 2, "#1e2830");
    },
    pallagiocattolo: function (g, x, y) { // palla a spicchi rossa/bianca
      O(g, x + 3, y + 4, 8, 8, "#0e1118", "#e84040");
      R(g, x + 4, y + 5, 6, 3, "#f4f0e0");
      R(g, x + 6, y + 5, 2, 6, "#f8c832");
      R(g, x + 4, y + 5, 2, 2, "#ffffff");
    },
    robottinogiocattolo: function (g, x, y) { // robottino a molla con chiavetta
      R(g, x + 10, y + 4, 3, 2, "#c9d2dc");
      O(g, x + 4, y + 2, 6, 5, "#0e1118", "#4a7ba6");
      R(g, x + 5, y + 3, 1, 1, "#f8c832");
      R(g, x + 8, y + 3, 1, 1, "#f8c832");
      O(g, x + 3, y + 7, 8, 5, "#0e1118", "#6a9ac6");
      R(g, x + 6, y + 8, 2, 2, "#e84040");
      R(g, x + 4, y + 12, 2, 2, "#37424c");
      R(g, x + 8, y + 12, 2, 2, "#37424c");
    },
    treninogiocattolo: function (g, x, y) { // locomotiva colorata coi binari
      R(g, x + 1, y + 12, 12, 1, "#5c4426");
      R(g, x + 2, y + 13, 1, 1, "#37424c");
      R(g, x + 5, y + 13, 1, 1, "#37424c");
      R(g, x + 8, y + 13, 1, 1, "#37424c");
      R(g, x + 11, y + 13, 1, 1, "#37424c");
      O(g, x + 2, y + 6, 6, 6, "#0e1118", "#e84040");
      R(g, x + 3, y + 3, 3, 3, "#37424c");
      R(g, x + 8, y + 8, 5, 4, "#f8c832");
      R(g, x + 9, y + 9, 2, 2, "#4a7ba6");
      R(g, x + 3, y + 12, 2, 2, "#16120e");
      R(g, x + 6, y + 12, 2, 2, "#16120e");
      R(g, x + 10, y + 12, 2, 2, "#16120e");
    },
    astronavegiocattolo: function (g, x, y) { // ufo giocattolo con cupola
      R(g, x + 5, y + 2, 4, 3, "#8fd8f0");
      O(g, x + 2, y + 5, 10, 4, "#0e1118", "#c9d2dc");
      R(g, x + 3, y + 6, 2, 1, "#e84040");
      R(g, x + 7, y + 6, 2, 1, "#f8c832");
      R(g, x + 10, y + 6, 1, 1, "#5ce87f");
      R(g, x + 4, y + 9, 2, 3, "#37424c");
      R(g, x + 8, y + 9, 2, 3, "#37424c");
      R(g, x + 3, y + 12, 8, 2, "#1e2830");
    },
    // ===== ARREDI ADULTO P3 (M33-M64) — batch A =====
    trofeopinna: function (g, x, y) { // coppa oro con pinna azzurra in cima
      R(g, x + 6, y + 1, 3, 2, "#4a90c0"); R(g, x + 8, y + 0, 2, 2, "#6ab0d0"); // pinna
      O(g, x + 3, y + 3, 8, 5, "#3a2808", "#f8c832"); // coppa
      R(g, x + 1, y + 4, 2, 2, "#f8c832"); R(g, x + 11, y + 4, 2, 2, "#f8c832"); // manici
      R(g, x + 6, y + 8, 2, 3, "#c99a3c"); R(g, x + 4, y + 11, 6, 2, "#3a2808"); // stelo + base
    },
    mostrodellago: function (g, x, y) { // companion: mostriciattolo verde-acqua con occhi gialli
      R(g, x + 2, y + 6, 10, 7, "#2a7a6a"); R(g, x + 3, y + 4, 8, 3, "#3a8a7a"); // corpo + testa
      R(g, x + 4, y + 6, 2, 2, "#f0e040"); R(g, x + 8, y + 6, 2, 2, "#f0e040"); // occhi
      R(g, x + 3, y + 2, 2, 3, "#2a7a6a"); R(g, x + 9, y + 2, 2, 3, "#2a7a6a"); // pinne testa
      R(g, x + 5, y + 11, 1, 2, "#1a5a4a"); R(g, x + 8, y + 11, 1, 2, "#1a5a4a"); // zampette
    },
    chiavidelquartiere: function (g, x, y) { // mazzo di chiavi dorate
      O(g, x + 2, y + 3, 6, 6, A_OUT, "#c8a838"); R(g, x + 4, y + 5, 2, 2, "#3a2c1a"); // anello grande
      R(g, x + 7, y + 8, 2, 5, "#e0c040"); R(g, x + 7, y + 12, 3, 1, "#e0c040"); R(g, x + 7, y + 10, 2, 1, "#e0c040"); // stelo + denti
      R(g, x + 9, y + 4, 2, 4, "#c8a838"); R(g, x + 10, y + 7, 2, 1, "#c8a838"); // seconda chiave
    },
    medagliadelfinisher: function (g, x, y) { // medaglia oro su nastro bicolore
      R(g, x + 4, y + 1, 2, 4, "#4a7ba6"); R(g, x + 8, y + 1, 2, 4, "#c22a3a"); // nastri
      R(g, x + 5, y + 1, 4, 2, "#5a8bc6"); // colletto nastro
      O(g, x + 4, y + 5, 6, 7, "#8a6d1a", "#f0c832"); R(g, x + 6, y + 7, 2, 3, "#c99a3c"); // medaglia + stella
    },
    torciaolimpica: function (g, x, y) { // torcia con fiamma
      R(g, x + 6, y + 6, 3, 8, "#c8a060"); R(g, x + 6, y + 6, 1, 8, "#e0c080"); // manico
      R(g, x + 5, y + 4, 5, 3, "#8a7050"); // coppa
      R(g, x + 6, y + 1, 3, 4, "#f0a030"); R(g, x + 7, y + 0, 2, 3, "#f8d050"); R(g, x + 6, y + 2, 1, 2, "#e07020"); // fiamma
    },
    podiodoro: function (g, x, y) { // podio a 3 gradini dorato
      R(g, x + 1, y + 7, 4, 6, "#e0b828"); R(g, x + 5, y + 4, 4, 9, "#f0c832"); R(g, x + 9, y + 9, 4, 4, "#e0b828");
      R(g, x + 6, y + 5, 2, 1, "#fff0a0"); R(g, x + 2, y + 8, 1, 1, "#fff0a0"); R(g, x + 10, y + 10, 1, 1, "#fff0a0"); // riflessi
      R(g, x + 6, y + 6, 2, 1, "#8a6d1a"); // numero 1 accennato
    },
    skateboardpro: function (g, x, y) { // tavola rossa con ruote
      R(g, x + 1, y + 6, 12, 3, "#c83030"); R(g, x + 1, y + 6, 12, 1, "#e85050"); // deck
      R(g, x + 3, y + 7, 8, 1, "#f0d040"); // grafica
      R(g, x + 2, y + 9, 2, 2, "#1a1a20"); R(g, x + 10, y + 9, 2, 2, "#1a1a20"); // ruote
    },
    tastieradoro: function (g, x, y) { // tastiera gaming dorata
      O(g, x + 1, y + 7, 12, 5, "#3a2808", "#f0c832");
      R(g, x + 2, y + 8, 2, 1, "#3a2808"); R(g, x + 5, y + 8, 2, 1, "#3a2808"); R(g, x + 8, y + 8, 2, 1, "#3a2808"); R(g, x + 11, y + 8, 1, 1, "#3a2808");
      R(g, x + 4, y + 10, 6, 1, "#3a2808"); // barra spazio
    },
    gettonenero: function (g, x, y) { // gettone nero con simbolo rosso cupo
      O(g, x + 3, y + 3, 8, 8, "#0a0a0e", "#2a2a34");
      R(g, x + 6, y + 5, 2, 4, "#8a3040"); R(g, x + 5, y + 6, 4, 2, "#8a3040"); // simbolo
      R(g, x + 4, y + 4, 1, 1, "#4a4a55"); // riflesso
    },
    cabinatomaledetto: function (g, x, y) { // mini-cabinato con schermo rosso cupo
      O(g, x + 3, y + 1, 8, 13, "#060410", "#1a1226");
      R(g, x + 5, y + 3, 4, 4, "#7a1030"); R(g, x + 5, y + 3, 4, 1, "#e83050"); // schermo
      R(g, x + 5, y + 9, 4, 1, "#2a1020"); R(g, x + 6, y + 11, 2, 1, "#3a1828"); // pannello
    },
    vasoantico: function (g, x, y) { // anfora decorata
      O(g, x + 4, y + 3, 6, 10, "#6a4a2a", "#a07840"); R(g, x + 5, y + 1, 4, 3, "#8a6030"); // corpo + collo
      R(g, x + 3, y + 5, 2, 3, "#8a6030"); R(g, x + 9, y + 5, 2, 3, "#8a6030"); // manici
      R(g, x + 5, y + 8, 5, 1, "#c8a860"); R(g, x + 5, y + 6, 5, 1, "#7a5628"); // decori
    },
    idolodorato: function (g, x, y) { // idolo/tiki dorato con occhi neri
      O(g, x + 4, y + 2, 6, 11, "#8a6d1a", "#f0c832");
      R(g, x + 3, y + 3, 2, 3, "#e0b828"); R(g, x + 9, y + 3, 2, 3, "#e0b828"); // orecchie
      R(g, x + 5, y + 4, 1, 2, "#3a2808"); R(g, x + 8, y + 4, 1, 2, "#3a2808"); // occhi
      R(g, x + 5, y + 8, 4, 1, "#3a2808"); R(g, x + 5, y + 2, 4, 1, "#fff0a0"); // bocca + riflesso corona
    },
    // ===== ARREDI ADULTO P3 — batch B =====
    modellinorazzo: function (g, x, y) { // razzo giocattolo bianco/rosso
      R(g, x + 6, y + 1, 3, 3, "#c83030"); O(g, x + 5, y + 4, 5, 8, A_OUT, "#d8d8e0"); // punta + corpo
      R(g, x + 6, y + 6, 3, 2, "#4a90c0"); // oblo
      R(g, x + 3, y + 9, 3, 4, "#8a8a92"); R(g, x + 9, y + 9, 3, 4, "#8a8a92"); // pinne
      R(g, x + 6, y + 12, 3, 2, "#f0a030"); // fiamma
    },
    pergamenadilaurea: function (g, x, y) { // pergamena arrotolata con nastro rosso
      R(g, x + 2, y + 5, 10, 4, "#f0e8d0"); R(g, x + 2, y + 4, 10, 1, "#d8cfb0"); R(g, x + 2, y + 9, 10, 1, "#c8bfa0");
      R(g, x + 1, y + 4, 2, 6, "#c8b070"); R(g, x + 11, y + 4, 2, 6, "#c8b070"); // aste
      R(g, x + 6, y + 8, 2, 4, "#c22a3a"); R(g, x + 5, y + 11, 4, 2, "#c22a3a"); // nastro
    },
    poltronadeltalk: function (g, x, y) { // poltrona da talk show
      O(g, x + 2, y + 4, 10, 9, "#5a2030", "#a03848"); R(g, x + 3, y + 8, 8, 4, "#c04858"); // schienale + seduta
      R(g, x + 1, y + 7, 2, 5, "#8a2838"); R(g, x + 11, y + 7, 2, 5, "#8a2838"); // braccioli
      R(g, x + 3, y + 12, 2, 2, "#3a1018"); R(g, x + 9, y + 12, 2, 2, "#3a1018"); // piedi
    },
    statuainpiazza: function (g, x, y) { // statua grigia su piedistallo
      R(g, x + 5, y + 2, 4, 7, "#a8a8b0"); R(g, x + 6, y + 1, 2, 2, "#b8b8c0"); // busto + testa
      R(g, x + 4, y + 4, 2, 3, "#9898a0"); R(g, x + 8, y + 4, 2, 3, "#9898a0"); // braccia
      R(g, x + 3, y + 9, 8, 2, "#787880"); R(g, x + 2, y + 11, 10, 3, "#6a6a72"); R(g, x + 2, y + 11, 10, 1, "#8a8a92"); // base + piedistallo
    },
    chitarraelettrica: function (g, x, y) { // chitarra elettrica rossa
      R(g, x + 8, y + 1, 2, 9, "#3a2c1a"); R(g, x + 8, y + 1, 2, 1, "#c8c8d0"); // manico + paletta
      O(g, x + 2, y + 8, 7, 6, A_OUT, "#c83030"); R(g, x + 4, y + 10, 3, 2, "#f0d040"); // corpo + ponte
    },
    setdicoltelli: function (g, x, y) { // ceppo con coltelli
      R(g, x + 3, y + 6, 8, 7, "#5a3a24"); R(g, x + 3, y + 6, 8, 1, "#7a5030"); // ceppo
      R(g, x + 4, y + 1, 1, 5, "#e8e8f0"); R(g, x + 6, y + 2, 1, 4, "#c8c8d0"); R(g, x + 8, y + 1, 1, 5, "#e8e8f0"); R(g, x + 10, y + 3, 1, 3, "#c8c8d0"); // lame
      R(g, x + 4, y + 6, 7, 1, "#3a2c1a"); // manici
    },
    fantasmino: function (g, x, y) { // companion fantasmino carino
      R(g, x + 3, y + 3, 8, 8, "#e8ecf0"); R(g, x + 4, y + 2, 6, 1, "#e8ecf0");
      R(g, x + 3, y + 11, 2, 2, "#e8ecf0"); R(g, x + 7, y + 11, 2, 2, "#e8ecf0"); R(g, x + 10, y + 11, 1, 2, "#e8ecf0"); // frangia
      R(g, x + 5, y + 5, 2, 2, "#3a4048"); R(g, x + 8, y + 5, 2, 2, "#3a4048"); R(g, x + 6, y + 8, 3, 1, "#8a90a0"); // occhi + bocca
    },
    saccodirefurtiva: function (g, x, y) { // sacco della refurtiva col simbolo oro
      R(g, x + 3, y + 5, 8, 8, "#4a4438"); R(g, x + 4, y + 13, 6, 1, "#3a352c"); // sacco
      R(g, x + 5, y + 2, 4, 3, "#5a5448"); R(g, x + 5, y + 4, 4, 1, "#2a2620"); // collo
      R(g, x + 6, y + 8, 3, 3, "#f0c040"); R(g, x + 7, y + 8, 1, 3, "#8a6d1a"); // simbolo
    },
    palladademolizione: function (g, x, y) { // palla da demolizione con catena
      R(g, x + 7, y + 1, 1, 4, "#8a8a92"); R(g, x + 6, y + 2, 1, 1, "#8a8a92"); R(g, x + 8, y + 3, 1, 1, "#8a8a92"); // catena
      O(g, x + 3, y + 5, 8, 8, "#0a0a0e", "#3a3a44"); R(g, x + 5, y + 6, 2, 2, "#5a5a64"); // sfera + riflesso
    },
    trofeomigliorbabysitter: function (g, x, y) { // trofeo col cuore rosa
      O(g, x + 3, y + 2, 8, 6, "#3a2808", "#f8c832"); R(g, x + 1, y + 3, 2, 2, "#f8c832"); R(g, x + 11, y + 3, 2, 2, "#f8c832");
      R(g, x + 5, y + 3, 2, 2, "#e85a78"); R(g, x + 7, y + 3, 2, 2, "#e85a78"); R(g, x + 6, y + 5, 2, 1, "#e85a78"); // cuore
      R(g, x + 6, y + 8, 2, 2, "#c99a3c"); R(g, x + 4, y + 10, 6, 3, "#3a2808"); // stelo + base
    },
    paccomaledetto: function (g, x, y) { // scatola scura col bagliore viola
      O(g, x + 3, y + 4, 9, 9, "#1a0e1a", "#3a1a3a"); R(g, x + 3, y + 8, 9, 1, "#5a2a5a"); R(g, x + 7, y + 4, 1, 9, "#5a2a5a"); // scatola + nastro
      R(g, x + 6, y + 7, 3, 3, "#c040c0"); R(g, x + 7, y + 8, 1, 1, "#f070f0"); // bagliore
    },
    spartitomaledetto: function (g, x, y) { // spartito con note viola inquietanti
      R(g, x + 3, y + 2, 8, 11, "#e8e0d0"); R(g, x + 3, y + 2, 8, 1, "#c8c0b0");
      R(g, x + 4, y + 4, 6, 1, "#3a3040"); R(g, x + 4, y + 6, 6, 1, "#3a3040"); R(g, x + 4, y + 8, 6, 1, "#3a3040"); // righi
      R(g, x + 5, y + 5, 1, 2, "#8a2a8a"); R(g, x + 8, y + 7, 1, 2, "#8a2a8a"); R(g, x + 4, y + 10, 4, 1, "#8a2a2a"); // note + macchia
    },
    // ===== ARREDI ADULTO P3 — batch C =====
    portapizzedoro: function (g, x, y) { // borsa porta-pizze dorata
      O(g, x + 2, y + 4, 10, 9, "#8a6d1a", "#f0c832"); R(g, x + 3, y + 7, 8, 1, "#c99a3c"); // borsa + cerniera
      R(g, x + 5, y + 2, 4, 2, "#c99a3c"); R(g, x + 5, y + 9, 4, 2, "#e05a2a"); // manico + logo
    },
    frammentodimeteorite: function (g, x, y) { // roccia scura con vena incandescente
      R(g, x + 3, y + 5, 9, 8, "#2a2430"); R(g, x + 4, y + 4, 6, 2, "#3a3440"); R(g, x + 3, y + 12, 9, 1, "#1a1620");
      R(g, x + 5, y + 7, 3, 3, "#f0a030"); R(g, x + 6, y + 8, 1, 1, "#f8e050"); // vena
    },
    nucleodelmeteorite: function (g, x, y) { // nucleo cristallino cyan luminoso
      R(g, x + 4, y + 6, 6, 7, "#2a2430"); R(g, x + 3, y + 12, 8, 1, "#1a1620"); // roccia
      R(g, x + 5, y + 3, 4, 6, "#40e0d0"); R(g, x + 6, y + 2, 2, 2, "#a0f8f0"); R(g, x + 6, y + 5, 2, 2, "#e0fffa"); // nucleo
    },
    mappaincorniciata: function (g, x, y) { // mappa del tesoro incorniciata
      O(g, x + 2, y + 2, 11, 11, "#5a3a1a", "#8a6030"); R(g, x + 4, y + 4, 7, 7, "#e8dcb8"); // cornice + mappa
      R(g, x + 5, y + 5, 3, 1, "#8a6a3a"); R(g, x + 6, y + 7, 3, 1, "#8a6a3a"); R(g, x + 8, y + 8, 2, 2, "#c02020"); // percorso + X
    },
    forzieredeltesoro: function (g, x, y) { // forziere con monete
      R(g, x + 2, y + 7, 11, 6, "#6a4020"); R(g, x + 2, y + 7, 11, 1, "#8a5a30"); // cassa
      R(g, x + 2, y + 4, 11, 3, "#7a4a28"); R(g, x + 2, y + 4, 11, 1, "#9a6a38"); // coperchio
      R(g, x + 6, y + 6, 3, 3, "#c8a838"); R(g, x + 4, y + 8, 2, 2, "#f0d040"); R(g, x + 8, y + 9, 2, 1, "#f0d040"); // serratura + monete
    },
    micromostroregina: function (g, x, y) { // companion insettoide regina con coroncina
      R(g, x + 4, y + 6, 6, 6, "#5a8a3a"); R(g, x + 5, y + 4, 4, 3, "#6a9a4a"); // corpo
      R(g, x + 5, y + 6, 1, 1, "#f0e040"); R(g, x + 8, y + 6, 1, 1, "#f0e040"); // occhi
      R(g, x + 4, y + 2, 1, 2, "#f0c040"); R(g, x + 6, y + 1, 1, 2, "#f0c040"); R(g, x + 8, y + 2, 1, 2, "#f0c040"); // corona
      R(g, x + 3, y + 9, 1, 3, "#3a5a24"); R(g, x + 10, y + 9, 1, 3, "#3a5a24"); // zampe
    },
    generatorediscorta: function (g, x, y) { // generatore con spia e manovella
      O(g, x + 2, y + 5, 10, 8, A_OUT, "#4a4a54"); R(g, x + 3, y + 7, 6, 3, "#2a2a30"); // corpo + pannello
      R(g, x + 4, y + 8, 2, 1, "#f0e040"); // spia
      R(g, x + 11, y + 7, 2, 1, "#8a8a92"); R(g, x + 12, y + 5, 1, 4, "#8a8a92"); R(g, x + 3, y + 3, 3, 2, "#5a5a64"); // manovella + scarico
    },
    timonedifortuna: function (g, x, y) { // timone di nave
      O(g, x + 3, y + 3, 8, 8, "#3a2c1a", "#8a6030"); R(g, x + 5, y + 5, 4, 4, "#5a4028"); // ruota
      R(g, x + 6, y + 1, 2, 3, "#6a4a2a"); R(g, x + 6, y + 10, 2, 3, "#6a4a2a"); R(g, x + 1, y + 6, 3, 2, "#6a4a2a"); R(g, x + 10, y + 6, 3, 2, "#6a4a2a"); // razze
      R(g, x + 6, y + 6, 2, 2, "#c8a860"); // mozzo
    },
    velaleggendaria: function (g, x, y) { // vela con emblema oro
      R(g, x + 3, y + 1, 1, 13, "#5a4030"); // albero
      R(g, x + 4, y + 2, 7, 9, "#e8e0c8"); R(g, x + 4, y + 2, 7, 1, "#c8c0a8"); R(g, x + 4, y + 11, 7, 1, "#c8c0a8"); // vela
      R(g, x + 6, y + 4, 3, 4, "#c8a838"); R(g, x + 7, y + 5, 1, 2, "#f0d060"); // emblema
    },
    fotoautografatadifabrice: function (g, x, y) { // foto autografata incorniciata
      O(g, x + 2, y + 2, 11, 11, "#2a2a30", "#c8c8d0"); R(g, x + 4, y + 4, 7, 5, "#4a5a7a"); // cornice + foto
      R(g, x + 6, y + 5, 3, 3, "#c8a888"); // volto
      R(g, x + 4, y + 10, 7, 1, "#c83030"); R(g, x + 5, y + 11, 5, 1, "#a02828"); // autografo
    },
    caffettierabruciacchiata: function (g, x, y) { // moka bruciacchiata
      R(g, x + 4, y + 7, 6, 6, "#8a8a92"); R(g, x + 5, y + 4, 4, 3, "#a8a8b0"); R(g, x + 4, y + 7, 6, 1, "#3a3a40"); // corpo
      R(g, x + 9, y + 5, 3, 2, "#5a5a64"); R(g, x + 10, y + 6, 2, 4, "#3a3a40"); // beccuccio + manico
      R(g, x + 5, y + 10, 4, 2, "#2a2418"); R(g, x + 6, y + 3, 2, 1, "#1a1612"); // bruciature
    },
    // ===== INDOSSABILI P3 — icone armadio (batch testa) =====
    cuffiedadj: function (g, x, y) { // cuffie da DJ
      R(g, x + 3, y + 2, 8, 2, "#2098b0"); // archetto
      R(g, x + 2, y + 3, 3, 7, "#40e0f0"); R(g, x + 9, y + 3, 3, 7, "#40e0f0"); // padiglioni
      R(g, x + 2, y + 3, 3, 1, "#17171e"); R(g, x + 9, y + 3, 3, 1, "#17171e"); R(g, x + 3, y + 5, 1, 3, "#e8f0f8");
    },
    cascospaziale: function (g, x, y) { // casco spaziale
      O(g, x + 3, y + 2, 8, 9, "#17171e", "#e8f0f8"); // cupola
      R(g, x + 4, y + 5, 6, 3, "#20486a"); R(g, x + 4, y + 5, 6, 1, "#3a78a8"); R(g, x + 5, y + 5, 1, 3, "#5a98c8"); // visiera
    },
    cappellodadetective: function (g, x, y) { // deerstalker
      R(g, x + 4, y + 2, 6, 2, "#8a5f30"); R(g, x + 3, y + 4, 8, 5, "#a0703a"); R(g, x + 3, y + 4, 8, 1, "#6e4826"); // cappello
      R(g, x + 2, y + 6, 2, 3, "#6e4826"); R(g, x + 10, y + 6, 2, 3, "#6e4826"); // paraorecchie
      R(g, x + 2, y + 9, 10, 1, "#5a3a20"); // tesa
    },
    coronadalloro: function (g, x, y) { // corona d'alloro
      R(g, x + 3, y + 3, 2, 2, "#5cae52"); R(g, x + 2, y + 5, 2, 2, "#5cae52"); R(g, x + 2, y + 7, 2, 3, "#2e6a3a"); // ramo sx
      R(g, x + 9, y + 3, 2, 2, "#5cae52"); R(g, x + 10, y + 5, 2, 2, "#5cae52"); R(g, x + 10, y + 7, 2, 3, "#2e6a3a"); // ramo dx
      R(g, x + 5, y + 10, 4, 2, "#5cae52"); R(g, x + 6, y + 11, 2, 1, "#f0c040"); // base + nastro oro
    },
    cappellodachef: function (g, x, y) { // toque
      R(g, x + 4, y + 1, 6, 3, "#ffffff"); R(g, x + 2, y + 3, 10, 4, "#ffffff"); R(g, x + 3, y + 2, 8, 6, "#ffffff"); // sbuffo
      R(g, x + 3, y + 8, 8, 3, "#d8d4c4"); R(g, x + 3, y + 8, 8, 1, "#b8b4a4"); // fascia
    },
    cascodacorrierespaziale: function (g, x, y) { // casco corriere spaziale
      R(g, x + 6, y + 0, 2, 3, "#f0a030"); R(g, x + 6, y + 0, 2, 1, "#f8d060"); // antenna
      O(g, x + 3, y + 3, 8, 9, "#17171e", "#e8f0f8"); // cupola
      R(g, x + 4, y + 6, 6, 3, "#20486a"); R(g, x + 4, y + 6, 6, 1, "#3a78a8"); R(g, x + 8, y + 9, 3, 2, "#f0a030"); // visiera + accento
    },
    // ===== INDOSSABILI P3 — icone armadio (batch corpo) =====
    fischiettodellistruttore: function (g, x, y) { // fischietto al collo
      R(g, x + 3, y + 3, 2, 4, "#c02828"); R(g, x + 9, y + 3, 2, 4, "#c02828"); // cordino
      R(g, x + 4, y + 7, 6, 5, "#3a3a44"); R(g, x + 4, y + 7, 6, 1, "#5a5a64"); R(g, x + 10, y + 8, 2, 2, "#3a3a44"); // fischietto
      R(g, x + 6, y + 9, 2, 2, "#f0c040"); // foro
    },
    costumedaprotagonista: function (g, x, y) { // costume da eroe su gruccia
      R(g, x + 3, y + 2, 8, 1, "#8a8a92"); R(g, x + 6, y + 1, 2, 2, "#8a8a92"); // gruccia
      R(g, x + 3, y + 4, 8, 8, "#3060c0"); R(g, x + 3, y + 4, 8, 1, "#4070d0"); // tuta
      R(g, x + 6, y + 6, 2, 3, "#f8d838"); R(g, x + 5, y + 7, 4, 1, "#f8d838"); // stella
    },
    costumedellallenatore: function (g, x, y) { // tuta da allenatore
      R(g, x + 3, y + 2, 8, 1, "#8a8a92"); R(g, x + 6, y + 1, 2, 2, "#8a8a92"); // gruccia
      R(g, x + 3, y + 4, 8, 8, "#2e8a4a"); R(g, x + 4, y + 4, 1, 8, "#e8e8e8"); R(g, x + 9, y + 4, 1, 8, "#e8e8e8"); // tuta + strisce
    },
    cinturamondiale: function (g, x, y) { // cintura mondiale
      R(g, x + 2, y + 5, 10, 4, "#f8d838"); R(g, x + 2, y + 5, 10, 1, "#fff0a0"); // fascia oro
      R(g, x + 5, y + 3, 4, 8, "#c89830"); R(g, x + 5, y + 3, 4, 1, "#f8d838"); R(g, x + 6, y + 5, 2, 3, "#f0e8d0"); // placca centrale
    },
    accappatoiodelcampione: function (g, x, y) { // accappatoio
      R(g, x + 3, y + 2, 8, 1, "#8a8a92"); R(g, x + 6, y + 1, 2, 2, "#8a8a92"); // gruccia
      R(g, x + 3, y + 3, 8, 9, "#c02838"); R(g, x + 6, y + 3, 2, 9, "#f0e8d0"); R(g, x + 3, y + 9, 8, 1, "#8a1c28"); // vestaglia + risvolto + cintura
    },
    medaglionedelconcilio: function (g, x, y) { // medaglione
      R(g, x + 4, y + 2, 2, 3, "#a07820"); R(g, x + 8, y + 2, 2, 3, "#a07820"); // catena
      O(g, x + 4, y + 5, 6, 6, "#a07820", "#f0c040"); R(g, x + 6, y + 7, 2, 2, "#40c0e0"); // disco + gemma
    },
    fasciadasindaco: function (g, x, y) { // fascia diagonale
      R(g, x + 9, y + 2, 3, 3, "#c02838"); R(g, x + 7, y + 4, 3, 3, "#c02838"); R(g, x + 5, y + 6, 3, 3, "#c02838"); R(g, x + 3, y + 8, 3, 3, "#c02838"); // sciarpa diagonale
      R(g, x + 3, y + 10, 3, 2, "#f0c040"); // medaglia
    },
    cinturadelpeperoncino: function (g, x, y) { // cintura del peperoncino
      R(g, x + 2, y + 5, 10, 4, "#c8a030"); R(g, x + 2, y + 5, 10, 1, "#e0b840"); // fascia
      R(g, x + 5, y + 3, 4, 8, "#8a6020"); R(g, x + 6, y + 5, 2, 4, "#e03020"); R(g, x + 6, y + 4, 2, 1, "#3a8a3a"); // placca + peperoncino
    },
    // ===== INDOSSABILI P3 — icone armadio (batch mano + speciali) =====
    guantoniconsumati: function (g, x, y) { // guantone da boxe consumato
      R(g, x + 3, y + 3, 7, 8, "#c02838"); R(g, x + 3, y + 3, 7, 1, "#e04050"); // guantone
      R(g, x + 9, y + 5, 3, 3, "#c02838"); R(g, x + 4, y + 6, 3, 2, "#8a1c28"); // pollice + ombra
      R(g, x + 3, y + 11, 7, 2, "#d8c8b0"); // polsino
    },
    chitarrafiammante: function (g, x, y) { // chitarra fiammeggiante
      R(g, x + 6, y + 1, 2, 6, "#3a2c1a"); R(g, x + 6, y + 1, 2, 1, "#8a8a92"); // manico
      O(g, x + 3, y + 7, 8, 6, "#17171e", "#8a4a2a"); // corpo
      R(g, x + 2, y + 6, 2, 3, "#e05020"); R(g, x + 10, y + 6, 2, 3, "#e05020"); R(g, x + 3, y + 5, 2, 2, "#f0a030"); // fiamme
      R(g, x + 6, y + 9, 2, 2, "#f0c040"); // buca
    },
    scarpedoro: function (g, x, y) { // scarpe d'oro
      R(g, x + 2, y + 8, 5, 4, "#f8d838"); R(g, x + 2, y + 8, 5, 1, "#fff0a0"); R(g, x + 2, y + 11, 5, 1, "#c89830"); // scarpa sx
      R(g, x + 7, y + 8, 5, 4, "#f8d838"); R(g, x + 7, y + 8, 5, 1, "#fff0a0"); R(g, x + 7, y + 11, 5, 1, "#c89830"); // scarpa dx
      R(g, x + 3, y + 9, 2, 1, "#fff0a0"); // riflesso
    },
    tavolaleggendaria: function (g, x, y) { // tavola da surf
      R(g, x + 6, y + 1, 3, 12, "#40c0e0"); R(g, x + 6, y + 1, 3, 1, "#17171e"); R(g, x + 6, y + 12, 3, 1, "#17171e"); // tavola
      R(g, x + 7, y + 3, 1, 8, "#e8f0f8"); R(g, x + 6, y + 5, 3, 1, "#f0c040"); R(g, x + 6, y + 8, 3, 1, "#f0c040"); // strisce
    },
    // ===== ARREDI TARDIVI M73-M98 (baby/teen extra) =====
    cordadellavittoria: function (g, x, y) { // corda arrotolata
      O(g, x + 2, y + 3, 10, 9, "#6a4a2a", "#a0703a"); R(g, x + 4, y + 5, 6, 5, "#8a5f30"); R(g, x + 5, y + 6, 4, 3, "#a0703a");
      R(g, x + 3, y + 4, 8, 1, "#c89858"); R(g, x + 3, y + 8, 8, 1, "#c89858"); R(g, x + 9, y + 2, 2, 3, "#8a5f30");
    },
    dinosaurogiocattolo: function (g, x, y) { // t-rex verde giocattolo
      R(g, x + 2, y + 6, 7, 6, "#5cae52"); R(g, x + 7, y + 3, 5, 4, "#5cae52"); R(g, x + 11, y + 5, 1, 2, "#5cae52");
      R(g, x + 3, y + 5, 4, 2, "#8ad868"); R(g, x + 9, y + 4, 1, 1, "#17171e"); R(g, x + 1, y + 8, 2, 4, "#4a9a42");
      R(g, x + 3, y + 12, 2, 2, "#3a7a34"); R(g, x + 6, y + 12, 2, 2, "#3a7a34");
    },
    puzzleincorniciato: function (g, x, y) { // puzzle in cornice
      O(g, x + 2, y + 2, 11, 11, "#5a3a1a", "#8a6030"); R(g, x + 4, y + 4, 7, 7, "#4a90c0");
      R(g, x + 4, y + 7, 7, 1, "#2a6090"); R(g, x + 7, y + 4, 1, 7, "#2a6090"); R(g, x + 6, y + 6, 2, 1, "#6ab0e0"); R(g, x + 6, y + 7, 1, 2, "#6ab0e0");
    },
    piantinadifragole: function (g, x, y) { // piantina con fragole
      R(g, x + 4, y + 9, 6, 4, "#a0703a"); R(g, x + 4, y + 9, 6, 1, "#c89858"); R(g, x + 3, y + 4, 8, 5, "#3a8a3a"); R(g, x + 4, y + 3, 6, 2, "#5cae52");
      R(g, x + 4, y + 6, 2, 2, "#e03040"); R(g, x + 8, y + 5, 2, 2, "#e03040"); R(g, x + 4, y + 6, 1, 1, "#f8d838"); R(g, x + 8, y + 5, 1, 1, "#f8d838");
    },
    burattinodrago: function (g, x, y) { // burattino drago
      R(g, x + 6, y + 8, 2, 6, "#8a5f30"); R(g, x + 3, y + 3, 8, 6, "#3a8a3a"); R(g, x + 9, y + 5, 3, 2, "#3a8a3a");
      R(g, x + 5, y + 4, 2, 2, "#f0c040"); R(g, x + 4, y + 2, 2, 2, "#e03040"); R(g, x + 7, y + 2, 2, 2, "#e03040"); R(g, x + 9, y + 6, 2, 1, "#f0a030");
    },
    spremiagrumidoro: function (g, x, y) { // spremiagrumi dorato
      O(g, x + 3, y + 7, 8, 5, "#8a6d1a", "#f0c832"); R(g, x + 5, y + 3, 4, 5, "#f8d838"); R(g, x + 6, y + 2, 2, 2, "#fff0a0");
      R(g, x + 4, y + 4, 1, 3, "#c89830"); R(g, x + 9, y + 4, 1, 3, "#c89830"); R(g, x + 3, y + 11, 8, 1, "#c89830");
    },
    trofeodelporto: function (g, x, y) { // trofeo con ancora
      O(g, x + 3, y + 2, 8, 5, "#3a2808", "#f8c832"); R(g, x + 1, y + 3, 2, 2, "#f8c832"); R(g, x + 11, y + 3, 2, 2, "#f8c832");
      R(g, x + 6, y + 3, 2, 3, "#c89830"); R(g, x + 5, y + 4, 4, 1, "#c89830"); R(g, x + 6, y + 7, 2, 3, "#c99a3c"); R(g, x + 4, y + 10, 6, 3, "#3a2808");
    },
    kartapedali: function (g, x, y) { // kart a pedali rosso
      R(g, x + 2, y + 6, 10, 4, "#e03040"); R(g, x + 2, y + 6, 10, 1, "#f05060"); R(g, x + 8, y + 4, 3, 3, "#c02838");
      R(g, x + 2, y + 10, 3, 3, "#1a1a20"); R(g, x + 9, y + 10, 3, 3, "#1a1a20"); R(g, x + 3, y + 11, 1, 1, "#5a5a64"); R(g, x + 10, y + 11, 1, 1, "#5a5a64"); R(g, x + 1, y + 5, 2, 1, "#8a8a92");
    },
    trofeoranadoro: function (g, x, y) { // rana d'oro
      R(g, x + 3, y + 4, 8, 6, "#f0c832"); R(g, x + 3, y + 4, 8, 1, "#f8d838"); R(g, x + 3, y + 3, 2, 2, "#f8d838"); R(g, x + 9, y + 3, 2, 2, "#f8d838");
      R(g, x + 4, y + 4, 1, 1, "#17171e"); R(g, x + 9, y + 4, 1, 1, "#17171e"); R(g, x + 2, y + 9, 2, 2, "#c89830"); R(g, x + 10, y + 9, 2, 2, "#c89830"); R(g, x + 3, y + 11, 8, 2, "#8a6d1a");
    },
    scacchieradonice: function (g, x, y) { // scacchiera d'onice
      O(g, x + 2, y + 5, 11, 8, "#1a1a1a", "#3a3a44");
      R(g, x + 3, y + 6, 2, 2, "#e8e8e8"); R(g, x + 7, y + 6, 2, 2, "#e8e8e8"); R(g, x + 5, y + 8, 2, 2, "#e8e8e8"); R(g, x + 9, y + 8, 2, 2, "#e8e8e8");
      R(g, x + 6, y + 2, 2, 4, "#0a0a0a"); R(g, x + 5, y + 1, 4, 2, "#2a2a34");
    },
    gettonedoro: function (g, x, y) { // gettone/moneta d'oro
      O(g, x + 3, y + 3, 8, 8, "#8a6d1a", "#f0c832"); R(g, x + 6, y + 5, 2, 4, "#c89830"); R(g, x + 5, y + 6, 4, 2, "#c89830");
      R(g, x + 4, y + 4, 1, 1, "#fff0a0"); R(g, x + 5, y + 4, 2, 1, "#fff0a0");
    },
    lampadalavadisecondamano: function (g, x, y) { // lampada lava
      R(g, x + 5, y + 11, 4, 2, "#3a3a44"); R(g, x + 5, y + 1, 4, 1, "#5a5a64"); R(g, x + 5, y + 3, 4, 8, "#7a2a6a");
      R(g, x + 6, y + 4, 2, 2, "#e070c0"); R(g, x + 6, y + 8, 2, 2, "#f090d0"); R(g, x + 5, y + 3, 1, 8, "#a04a90");
    },
    lanternedellafesta: function (g, x, y) { // lanterne della festa
      R(g, x + 1, y + 3, 12, 1, "#5a5a64");
      R(g, x + 2, y + 4, 3, 4, "#e03040"); R(g, x + 6, y + 4, 3, 4, "#f0c040"); R(g, x + 10, y + 4, 3, 4, "#40c0e0");
      R(g, x + 3, y + 8, 1, 1, "#8a1c28"); R(g, x + 7, y + 8, 1, 1, "#c89830"); R(g, x + 11, y + 8, 1, 1, "#2098b0"); R(g, x + 3, y + 5, 1, 1, "#f05060");
    },
    sferatascabile: function (g, x, y) { // sfera-cattura
      R(g, x + 4, y + 2, 6, 5, "#e03040"); R(g, x + 3, y + 3, 8, 3, "#e03040"); R(g, x + 4, y + 9, 6, 3, "#e8e8e8"); R(g, x + 3, y + 8, 8, 3, "#e8e8e8");
      R(g, x + 3, y + 6, 8, 2, "#1a1a1a"); R(g, x + 6, y + 6, 2, 2, "#c8c8d0"); R(g, x + 6, y + 7, 1, 1, "#3a3a44"); R(g, x + 4, y + 3, 2, 1, "#f05868");
    },
    mostriciattolo: function (g, x, y) { // companion mostriciattolo viola
      R(g, x + 4, y + 5, 6, 7, "#8a4ab0"); R(g, x + 5, y + 3, 4, 3, "#9a5ac0"); R(g, x + 5, y + 6, 1, 1, "#f8d838"); R(g, x + 8, y + 6, 1, 1, "#f8d838");
      R(g, x + 6, y + 9, 2, 1, "#3a1a4a"); R(g, x + 3, y + 4, 1, 2, "#8a4ab0"); R(g, x + 10, y + 4, 1, 2, "#8a4ab0"); R(g, x + 4, y + 12, 2, 1, "#6a3a90"); R(g, x + 8, y + 12, 2, 1, "#6a3a90");
    },
    barattolodeicolorirubati: function (g, x, y) { // barattolo coi colori rubati
      O(g, x + 4, y + 3, 6, 10, A_OUT, "#c8e0e8"); R(g, x + 5, y + 1, 4, 2, "#8a8a92");
      R(g, x + 5, y + 5, 4, 1, "#e03040"); R(g, x + 5, y + 6, 4, 1, "#f0a030"); R(g, x + 5, y + 7, 4, 1, "#f0c040"); R(g, x + 5, y + 8, 4, 1, "#40c040"); R(g, x + 5, y + 9, 4, 1, "#4090e0"); R(g, x + 5, y + 10, 4, 1, "#a040c0");
    },
  };

  function arredoFallback(g, x, y) { // cassa con fiocco per nomi non riconosciuti
    O(g, x + 2, y + 4, 10, 10, A_OUT, "#a8743c");
    R(g, x + 3, y + 8, 8, 1, "#6e4826");
    R(g, x + 6, y + 5, 2, 8, "#e85a78"); // nastro
    R(g, x + 3, y + 7, 8, 2, "#e85a78");
    R(g, x + 5, y + 2, 4, 2, "#e85a78"); // fiocco
    R(g, x + 6, y + 3, 2, 1, "#a02430");
  }

  // COMPANION LEGGENDARI (super Grandi Imprese M65-M72): l'arredo del salone RIUSA lo sprite del
  // pet leggenda (riconoscibile: il meme), rimpicciolito a taglia-companion. Chiave normalizzata -> id.
  // ===== COMPANION VIVI (29 lug 2026) =====
  // Chi e' un companion e COME respira. Il movimento e' minuscolo di proposito: un companion che
  // saltella troppo ruba l'occhio al pet, che e' il protagonista. 'su' = sale di 1px sul frame
  // dispari (respiro), 'ondeggia' = 1px alternato a destra/sinistra (galleggia), 'sussulta' =
  // 2px, per i tipi nervosi.
  // I NOMI sono normalizzati come fa normalizzaArredo (minuscole, senza spazi/accenti).
  var COMPANION_MOTO = {
    piccionecyborg: "sussulta",        // testa nervosa da piccione
    mostriciattolo: "su",
    mostrodellago: "ondeggia",         // sta nell'acqua
    fantasmino: "ondeggia",            // fluttua
    micromostroregina: "su",
    gattinorobot: "su",
    // companion del Supporter Pack: il criceto SUSSULTA (corre nella ruota), la lumaca
    // ondeggia (striscia), gli altri due respirano.
    topochef: "su",
    lumacadellepulizie: "ondeggia",
    piccionepostino: "sussulta",
    cricetodinamo: "sussulta",
    // companion leggendari (Grandi Imprese): respiro sobrio, sono statue viventi
    gigaciad: "su", roccobaldoria: "su", padremaronno: "su", forrestgampo: "su",
    fabricethecrown: "su", veggeta: "su", sceldon: "su", toninostark: "su"
  };

  // Scostamento (dx, dy) del companion per il frame corrente. frame 0 = posa di riposo.
  function scostamentoCompanion(key, frame) {
    var moto = COMPANION_MOTO[key];
    if (!moto || !frame) return null;
    if (moto === "su") return { dx: 0, dy: -1 };
    if (moto === "sussulta") return { dx: 0, dy: -2 };
    if (moto === "ondeggia") return { dx: 1, dy: 0 };
    return null;
  }

  var LEGGENDA_ARREDO = {
    gigaciad: "m65", roccobaldoria: "m66", padremaronno: "m67", forrestgampo: "m68",
    fabricethecrown: "m69", veggeta: "m70", sceldon: "m71", toninostark: "m72"
  };
  var _legCompCache = {}; // id -> canvas gia' rimpicciolito (calcolato una volta)
  function companionCanvas(id) {
    if (_legCompCache[id]) return _legCompCache[id];
    var T = 16; // taglia-companion (leggermente sopra il footprint 14, come il Topo)
    var off = document.createElement("canvas"); off.width = 64; off.height = 64;
    var g = off.getContext("2d"); g.imageSmoothingEnabled = false;
    window.PETQ.sprites.draw(off, { razza: "leggenda", leggendaId: id, stadio: "adulto", corpo: "normale", parts: {} }, { frame: 0 });
    var d = g.getImageData(0, 0, 64, 64).data, minx = 64, miny = 64, maxx = 0, maxy = 0, trovato = false;
    for (var yy = 0; yy < 64; yy++) for (var xx = 0; xx < 64; xx++) {
      if (d[(yy * 64 + xx) * 4 + 3] > 0) { trovato = true; if (xx < minx) minx = xx; if (xx > maxx) maxx = xx; if (yy < miny) miny = yy; if (yy > maxy) maxy = yy; }
    }
    // BUSTO: prendo solo la parte alta (testa+torso, ~62%) e la scalo a T -> la faccia/tratto
    // iconico resta grande e riconoscibile invece di schiacciarsi (a corpo intero a 16px sparisce).
    var bw = trovato ? (maxx - minx + 1) : 1, bh = trovato ? (maxy - miny + 1) : 1;
    var bhCrop = Math.max(1, Math.round(bh * 0.62));
    var w = Math.max(1, Math.round(bw * (T / bhCrop)));
    var cc = document.createElement("canvas"); cc.width = w; cc.height = T;
    if (trovato) { var g2 = cc.getContext("2d"); g2.imageSmoothingEnabled = false; g2.drawImage(off, minx, miny, bw, bhCrop, 0, 0, w, T); }
    _legCompCache[id] = cc;
    return cc;
  }

  // disegna l'arredo "nome" con angolo alto-sinistra (x,y), footprint max 14x14
  // `frame` (opzionale) = battito dell'inattivita' (0|1): i COMPANION si spostano di 1-2px e
  // sembrano vivi. Tutto il resto lo ignora, quindi i mobili restano fermi come devono.
  function drawArredo(ctx, nome, x, y, frame) {
    if (!ctx) return;
    var key = normalizzaArredo(nome);
    var sc = scostamentoCompanion(key, frame);
    if (sc) { x += sc.dx; y += sc.dy; }
    if (ARREDI[key]) { ARREDI[key](ctx, x, y); return; }
    // companion leggendario: riusa lo sprite del pet leggenda (rimpicciolito, seduto sulla mensola)
    if (LEGGENDA_ARREDO[key] && window.PETQ.sprites && window.PETQ.sprites.draw) {
      var cc = companionCanvas(LEGGENDA_ARREDO[key]);
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(cc, x + Math.round((14 - cc.width) / 2), y + 14 - cc.height); // centrato, seduto sulla mensola
      return;
    }
    // il topo allenatore: sprite RAT_AMICO seduto nella stanza
    if (key.indexOf("topo") >= 0 || key.indexOf("allenatore") >= 0) {
      if (window.PETQ.sprites && window.PETQ.sprites.drawRatAmico) {
        window.PETQ.sprites.drawRatAmico(ctx, x - 1, y - 2, 1);
        return;
      }
    }
    arredoFallback(ctx, x, y);
  }

  // estrae fino a 4 nomi dallo stato.arredi (stringhe o {nome}), tollerante col vecchio formato
  // (4o slot = Ingrandimento casa; senza upgrade non ci sono mai piu' di 3 arredi piazzati per
  // stanza, quindi il cap a 4 e' retro-compatibile).
  function nomiArrediDaStato(arredi) {
    var nomi = [];
    if (!arredi || !arredi.length) return nomi;
    for (var i = 0; i < arredi.length && nomi.length < 4; i++) {
      var a = arredi[i];
      var nome = typeof a === "string" ? a : (a && a.nome);
      if (nome) nomi.push(nome);
    }
    // ordinamento per slot: tappeto per primo (sotto gli altri, slot a pavimento),
    // il topo preferisce il pavimento, poster/fascia vanno all'ultimo slot (a muro)
    function pesoSlot(nome) {
      var k = normalizzaArredo(nome);
      if (k.indexOf("tappeto") >= 0) return 0;
      if (k.indexOf("topo") >= 0 || k.indexOf("allenatore") >= 0) return 1;
      if (k.indexOf("poster") >= 0 || k.indexOf("fascia") >= 0) return 3;
      return 2;
    }
    nomi.sort(function (a, b) { return pesoSlot(a) - pesoSlot(b); });
    return nomi;
  }

  // assert di sviluppo: slot dentro il canvas stanza, senza sovrapposizioni tra loro né coi
  // mobili chiave / hotzone / pet della stanza (PROTOTIPO 2, Blocco 7).
  // NO_GO[stanza] = rettangoli proibiti per gli slot arredo. Coordinate allineate ai mobili
  // disegnati (peggiore tra lab/ship) e alle hotzone tap gia' esistenti. Il "pet" e' la banda
  // in cui il pet si muove: base al centro (x48-64) + escursione idle "corre per casa" (+/-16 ->
  // x32-80), altezza a pavimento (y44-60). La vasca usa la sua hotzone drag (ui.js HOTZONE_VASCA).
  var PET_BAND = { x: 32, y: 44, w: 48, h: 16, _n: "pet" };
  var NO_GO = {
    cucina: [
      { x: 6, y: 10, w: 16, h: 34, _n: "frigo" },          // frigo/capsula (hotzone _frigoZona)
      { x: 26, y: 32, w: 26, h: 12, _n: "bancone" },
      { x: 78, y: 16, w: 28, h: 28, _n: "fornelli/forno" },
      PET_BAND
    ],
    bagno: [
      { x: 0, y: 20, w: 50, h: 44, _n: "vasca (hotzone)" }, // ui.js HOTZONE_VASCA
      { x: 48, y: 10, w: 16, h: 34, _n: "doccia ship" },
      { x: 80, y: 8, w: 24, h: 40, _n: "specchio/lavandino" },
      { x: 104, y: 24, w: 8, h: 20, _n: "infermeria ship" },
      { x: 6, y: 10, w: 12, h: 10, _n: "infermeria lab" },
      PET_BAND
    ],
    salone: [
      { x: 4, y: 22, w: 42, h: 18, _n: "divano/seduta" },
      { x: 54, y: 6, w: 54, h: 24, _n: "schermo/oblo" }, // x54: bordo utile, lo slot muro [40,4] tiene l'oggetto a x<=52
      PET_BAND
    ],
    camera: [
      LETTO_LAB_CAMERA, LETTO_SHIP_CAMERA, SCRIVANIA_CAMERA,
      { x: 78, y: 18, w: 16, h: 26, _n: "comodino" },
      { x: 6, y: 6, w: 20, h: 14, _n: "finestra/oblo" }
      // niente PET_BAND in camera: il letto occupa il centro, il pet dorme/sta ai lati; gli slot
      // [28,4]/[58,4] sono a muro sopra il letto e [96,46] e' l'angolo pavimento far-right libero.
    ]
  };

  function assertSlots() {
    function overlap(a, b) {
      return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
    }
    for (var stanza in SLOT_SPOTS) {
      if (!Object.prototype.hasOwnProperty.call(SLOT_SPOTS, stanza)) continue;
      var boxes = SLOT_SPOTS[stanza].map(function (s) { return { x: s[0], y: s[1], w: 14, h: 14 }; });
      var vietati = NO_GO[stanza] || [];
      for (var i = 0; i < boxes.length; i++) {
        // Il 4o slot (Ingrandimento casa) sta nel pavimento esteso (y>=64): va validato contro
        // l'altezza GRANDE (H_GRANDE=80), non contro H_BASE=64 — altrimenti darebbe un falso
        // errore "esce dal canvas". I primi 3 slot restano validati contro l'altezza base.
        var Hslot = (boxes[i].y >= H_BASE) ? H_GRANDE : H_BASE;
        if (boxes[i].x < 0 || boxes[i].y < 0 || boxes[i].x + boxes[i].w > W || boxes[i].y + boxes[i].h > Hslot) {
          console.error("PETQ.rooms: slot " + stanza + "[" + i + "] esce dal canvas " + W + "x" + Hslot);
        }
        for (var j = i + 1; j < boxes.length; j++) {
          if (overlap(boxes[i], boxes[j])) {
            console.error("PETQ.rooms: slot sovrapposti " + stanza + "[" + i + "]/[" + j + "]");
          }
        }
        for (var v = 0; v < vietati.length; v++) {
          if (overlap(boxes[i], vietati[v])) {
            console.error("PETQ.rooms: slot " + stanza + "[" + i + "] si sovrappone a " + (vietati[v]._n || "zona vietata"));
          }
        }
      }
      if ((SLOT_TIPI[stanza] || []).length !== SLOT_SPOTS[stanza].length) {
        console.error("PETQ.rooms: _slotTipi." + stanza + " non allineato agli slot");
      }
    }
    // scrivania vs letto (entrambi i temi) e vs canvas: stessa verifica di sviluppo sopra
    if (SCRIVANIA_CAMERA.x < 0 || SCRIVANIA_CAMERA.y < 0 ||
        SCRIVANIA_CAMERA.x + SCRIVANIA_CAMERA.w > W || SCRIVANIA_CAMERA.y + SCRIVANIA_CAMERA.h > H) {
      console.error("PETQ.rooms: _scrivania.camera esce dal canvas " + W + "x" + H);
    }
    if (overlap(SCRIVANIA_CAMERA, LETTO_LAB_CAMERA) || overlap(SCRIVANIA_CAMERA, LETTO_SHIP_CAMERA)) {
      console.error("PETQ.rooms: _scrivania.camera si sovrappone al letto");
    }
  }
  assertSlots();

  // ===== Draw pubblico =====
  // tema 'lab'|'ship'; stanza 'cucina'|'bagno'|'salone'; stato {poop:int, arredi:[nomi|{nome}]}
  function draw(canvas, tema, stanza, stato) {
    if (!canvas) return;
    var g = canvas.getContext("2d");
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);

    // Altezza corrente della stanza (64 normale, 80 ingrandita): il modulo H e' usato dai
    // builder (pavimento R(g,0,WALL_H,W,H-WALL_H)) e qui dallo scaleY. Lo impostiamo per la
    // durata del draw e lo ripristiniamo SEMPRE nel finally, cosi' non "sporca" i draw
    // successivi (es. una stanza normale dopo una ingrandita). La larghezza W resta 112.
    var Hcorr = altezzaStanza(stato);
    var Hprec = H;
    H = Hcorr;
    try {
      var scaleX = canvas.width / W;
      var scaleY = canvas.height / H;
      var needsScale = scaleX !== 1 || scaleY !== 1;

      var draw112 = function () {
        var temaSet = BUILDERS[tema] || BUILDERS.lab;
        var builder = temaSet[stanza] || temaSet.cucina;
        builder(g);
        // Primo piano (tappeti, ciotola, pantofole...): SUBITO DOPO il builder e PRIMA degli
        // arredi piazzati, cosi' un arredo del 4o slot (pavimento esteso) finisce sopra il
        // tappeto e non sotto. V. PRIMO_PIANO in cima al file.
        // il tema vero se ha un primo piano suo, altrimenti il ripiego storico lab/ship
        disegnaPrimoPiano(g, PRIMO_PIANO[tema] ? tema : (temaSet === BUILDERS.ship ? "ship" : "lab"), stanza);
        // arredi piazzati della stanza corrente: ognuno sul SUO supporto (mensola/muro/pavimento);
        // se lo slot naturale è occupato o assente, primo slot libero (meglio fuori posto che invisibile)
        var spots = SLOT_SPOTS[stanza] || SLOT_SPOTS.cucina;
        var tipi = SLOT_TIPI[stanza] || SLOT_TIPI.cucina;
        var nomi = nomiArrediDaStato(stato && stato.arredi);
        // occupato dinamico su spots.length (3 base, 4 con Ingrandimento casa). Il 4o spot esiste
        // sempre in SLOT_SPOTS ma viene raggiunto solo se c'e' un 4o arredo piazzato — e piazzare
        // il 4o e' possibile solo con l'upgrade (v. arredi.slotPerStanza), quindi senza upgrade il
        // 4o spot (nel pavimento y64-78) resta vuoto e la stanza normale (H=64) non lo mostra.
        var occupato = spots.map(function () { return false; });
        for (var i = 0; i < nomi.length; i++) {
          var idx = tipi.indexOf(supportoDi(nomi[i]));
          if (idx < 0 || occupato[idx]) idx = occupato.indexOf(false);
          if (idx < 0) break;
          occupato[idx] = true;
          drawArredo(g, nomi[i], spots[idx][0], spots[idx][1], stato && stato.idleFrame);
        }
        if (stato && stato.poop) drawPoop(g, stato.poop);
      };

      if (needsScale) {
        g.save();
        g.scale(scaleX, scaleY);
        draw112();
        g.restore();
      } else {
        draw112();
      }
    } finally {
      H = Hprec;
    }
  }

  window.PETQ.rooms = {
    draw: draw,
    drawMappa: drawMappa,
    // vero se questo nome ha un disegno PROPRIO in ARREDI: serve alla UI per capire se
    // vale la pena chiamare drawArredo (che altrimenti ripiega su una scatola generica).
    haDisegnoArredo: function (nome) { return !!ARREDI[normalizzaArredo(nome)]; },
    // vero se questo arredo e' un COMPANION (creatura viva) e non un mobile
    eCompanion: function (nome) { return !!COMPANION_MOTO[normalizzaArredo(nome)]; },
    drawArredo: drawArredo,
    // altezza corrente della stanza in coord interne: 64 normale, 80 con Ingrandimento casa
    // (GDD "Slot arredo, tetto passivo e Ingrandimento casa"). La UI la usa per canvas/hotzone/pet.
    altezzaStanza: altezzaStanza,
    _W: W,
    _H: H,
    _H_BASE: H_BASE,
    _H_GRANDE: H_GRANDE,
    // Esportate perche' ui.js le usa per il tap "pulisci la cacca" (v. ui.js poopSpots, che
    // prevedeva questo nome ma non lo trovava e ricadeva su una copia HARDCODATA delle vecchie
    // coordinate): finche' restavano private, spostare le cacche nel disegno le lasciava
    // cliccabili dove stavano prima. Unica fonte di verita', da qui.
    _poopSpots: POOP_SPOTS,
    _MAPPA_W: MAPPA_W,
    _MAPPA_H: MAPPA_H,
    // altezza corrente della mappa in coord interne: MAPPA_H_BASE (456, corta) di default,
    // MAPPA_H_IMPRESE (530, con la fascia Grandi Imprese) solo se stato.imprese e' vero. La UI
    // la usa per canvas/aspect-ratio/hit-test, esattamente come altezzaStanza per la stanza.
    altezzaMappa: altezzaMappa,
    _MAPPA_H_BASE: MAPPA_H_BASE,
    _MAPPA_H_IMPRESE: MAPPA_H_IMPRESE,
    _mappaPins: MAPPA_PINS,
    _assertMappa: assertMappa,
    _slotSpots: SLOT_SPOTS,
    _slotTipi: SLOT_TIPI,
    _arredoSupporto: ARREDO_SUPPORTO,
    _assertSlots: assertSlots,
    // hotzone letto per tema (GDD "Casa" -> camera): la UI sceglie in base a temaRazza(pet)
    _letto: { camera: { lab: LETTO_LAB_CAMERA, ship: LETTO_SHIP_CAMERA } },
    // hotzone scrivania (PROTOTIPO-2.md punto 6 "Diario in camera"): stessa hotzone per
    // entrambi i temi (solo lo stile del mobile cambia, v. labScrivania/shipScrivania).
    _scrivania: { camera: SCRIVANIA_CAMERA },
    // hotzone frigo per tema (GDD "Economia" -> "Spesa e dispensa"): tap -> menu posseduto
    _frigoZona: { cucina: { lab: FRIGO_LAB_CUCINA, ship: FRIGO_SHIP_CUCINA } },
    _arredi: Object.keys(ARREDI),
    _temi: Object.keys(BUILDERS),
    _stanze: ["cucina", "bagno", "salone", "camera"],
    // Negozio unico (GDD "Economia" -> "Spesa e dispensa"): SHOP_PIN_ID/MAPPA_PIN_SHOP sono
    // ora un alias del Negozio di Giocattoli m0 (stesso pin, stessa silhouette) — non esiste
    // piu' un edificio "Market" separato. ui.js li usa per il proprio hit-test del menu acquisto.
    _shopPinId: SHOP_PIN_ID,
    _shopPin: MAPPA_PIN_SHOP,
    // ===== Mappa QUARTIERE (richiesta fondatore 28 lug 2026, v. commento sopra drawMappaQuartiere):
    // mostra SOLO i luoghi attivi oggi, grandi, su una mappa bassa un terzo dell'atlante. La UI la
    // usa al posto di drawMappa/_mappaPins/altezzaMappa per la tab Missioni (v. ui.js
    // renderTabMissioniMappa/ridisegnaMappa/hitPin/aggiornaEtichetteMappa).
    drawMappaQuartiere: drawMappaQuartiere,
    // altezza logica corrente (76 corta con meno di 4 luoghi attivi, 130 piena altrimenti): la UI
    // la usa PRIMA di disegnare per dimensionare canvas/aspect-ratio, esattamente come altezzaMappa.
    altezzaMappaQuartiere: altezzaMappaQuartiere,
    // rettangoli slot {id:{x,y,w,h}} dell'ULTIMO drawMappaQuartiere: fonte di verita' per
    // hit-test/etichette lato UI, al posto di _mappaPins (che restano le posizioni FISSE
    // dell'atlante, sbagliate per questa vista: gli slot cambiano posto ogni giorno).
    rettangoliQuartiere: rettangoliQuartiere
  };
})();
