# Giga Ciad — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: la perfezione fatta mascella. Frasi brevissime, assolute, zero dubbi. Tutto è "degno" o "debole". Chiama il giocatore "Fratello". Non ride mai; quando approva è un evento. Catchphrase: "Degno." (con parsimonia).

## Saluto (apertura app)
- Brother. You returned. Correct choice.
- I waited without watching the door. The door knew.
- You are here. The day now has structure. Good.
- Your entrance: punctual. Decisive. Worthy.

## Ha fame
- Brother. The body demands fuel. The body must be heard.
- The bowl is empty. This is an error. Errors get corrected.
- Hunger. Not weakness: the engine calling. Answer it.
- Feed me. Protein. Everything else is decoration.

## È sporco
- Dirt does not define me. It must still be removed. Proceed.
- A sculpted physique deserves a clean surface. Simple logic.
- I looked in the mirror. The mirror deserves better. Water.
- The dust dared. The dust will be washed. End of story.

## Coccole finite
- Enough. Affection received. Logged. Appreciated. We repeat tomorrow.
- Brother. That is sufficient petting. A jaw like this must not be worn down.
- Cuddles: over. Not because I can't take more. Because I know when to stop. Learn this.
- Your cuddles: worthy. The sixth one: unnecessary. Discipline above all.

## Parte per la missione
- Mission. I go. I return. Simple.
- I depart, brother. The plan has one step: be me until the end.
- The mission awaits me. A mistake. It should be preparing.
- I go. Do not wish me luck. Luck already cheers for me.

## Ritorno: successo
- Done. As predicted. As it will always be.
- Mission complete. The world watched. The world understood.
- Victory. I do not celebrate. I confirm.
- The mission was... worthy. I rarely say this. Take note.

## Ritorno: fallimento
- Defeat. Even mountains lose a pebble. They remain mountains.
- I lost. I say it straight, no excuses. The worthy way to lose.
- The result: negative. The jaw: still perfect. We rebuild from there.
- Failed. Today the world was stronger. Tomorrow, natural order resumes.

## Va a dormire
- I sleep. Eight hours. Exact. The body is a temple with a schedule.
- Night, brother. Sleep, done correctly, is also a feat of strength.
- I retire. The day was... acceptable. You were worthy.
- Rest is not surrender. It is strategy. Goodnight.

## Sveglia (risveglio dopo il sonno)
- Awake. Jaw: in position. The rest follows.
- Morning, brother. The sun rose. Good for it: it saw me awake.
- Up on the first alarm. No snooze. This separates men from mattresses.
- Awake. Today: like yesterday, but better. The only program I know.
