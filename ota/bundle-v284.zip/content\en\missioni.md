# Missioni — prototipo (32 schede + tutorial)

Chi compila: il fondatore definisce le schede (requisiti, durata, reward, condizioni); il socio scrive i testi degli esiti (qui in versione neutra, poi le varianti per personalità). Ogni scheda ha anche una riga "Scena" per chi disegnerà gli sprite di ogni esito.

**Modello di risoluzione (pet baby, prototipo)** — niente tiro di dado, niente soglia probabilistica. Il giocatore sceglie 1 missione al giorno da una rosa di 3; quasi sempre l'esito è quello **standard** (è così che il pet cresce, punto). Fallimento e super successo sono code rare, deterministiche: scattano solo se il pet soddisfa la condizione scritta sulla scheda (di solito una personalità precisa, a volte insieme a una stat molto bassa/alta). Il fallimento non è mai un "meno secco": compensa sempre con qualcosa, possibilmente in tema con la missione. Dettagli del modello e vecchia formula probabilistica (fase adulta) in bilanciamento.md.

**INDICE STADIO (per il motore — così è chiaro cosa è baby/teen/fuori-rosa):**
- **Baby rosa** (16): M1–M16. **Baby intro fuori-rosa**: M0 (tutorial, giorno 1).
- **Teen rosa** (15): M18–M32. **Teen intro fuori-rosa**: M17 (Pimp My Pet, all'evoluzione, 1 volta).
- Nelle righe Dati: `stadio=baby|teen` su ogni scheda; gli intro hanno `tutorial=1` (M0) o `teenIntro=1` (M17) e NON entrano nella rosa. (Le baby senza `stadio=` esplicito vanno lette come baby.)
- **Rosa per stadio** (decisione fondatore 5 lug): la rosa di un pet TEEN pesca SOLO missioni teen; quella di un pet BABY solo baby. Un teen non rigioca le baby.

**Categorie, tag & perk**: ogni missione ha una categoria (Videogioco, Sociale, Combattimento, Studio, Consegne, Sport, Lavoretti) e opzionalmente uno o più **tag** trasversali (invenzione, natura, gara, inseguimento, rapina, mostro, studio, social, musica) usati dai talenti e da alcuni perk. Alcuni super successi sbloccano un **perk**: un arredo che, finché è piazzato in casa, annulla il fallimento e garantisce sempre il super successo nelle missioni future della stessa categoria — o dello stesso tag, come Sabotatore sulle gare senza perk proprio.

---

## Missione 0 — Tutorial: The Toy Store [fuori rosa, solo giorno 1, mai fallimento]
Brief: The shutters roll up right as he walks by, like an invitation: shelves stacked high, and something in there is calling his name.
- Luogo: 📍 Toy Store
- Razza: entrambe
- Costo: gratis (regalo di benvenuto)
- Dati: tutorial=1 ; costo=0
- Reward: Felicità +10 + 1 oggetto collezionabile, secondo la personalità:

| Personalità | Oggetto | Bonus passivo |
|---|---|---|
| Sportivo | Pallone da calcio | +1 Forza |
| Nerd | GameBit portatile | +1 Intelligenza |
| Gentile | Microfono giocattolo | +1 Carisma |
| Maleducato | Fumetto sarcastico | +1 Intelligenza |

- Dati: cond= sportivo ; reward= fel+10, arredo:Pallone da calcio
- Dati: cond= nerd ; reward= fel+10, arredo:GameBit portatile
- Dati: cond= gentile ; reward= fel+10, arredo:Microfono giocattolo
- Dati: cond= maleducato ; reward= fel+10, arredo:Fumetto sarcastico
- Testo (slot {oggetto}): "The toy store's shutters roll up right as you walk by, almost like an invitation. Inside, shelves stacked to the ceiling with things you don't need — but you head straight for one, like it's calling you by name: {oggetto}. You hug it tight the whole way home, and for once you're not doing the math on whether you actually need it. You just want it. That's the whole equation."
- Scena: pet che stringe {oggetto} tra le braccia, sorriso aperto

## Missione 1: Arcade Tournament
Brief: Thumbs on the buttons, lights blinking: it's flash-tournament night at Bit & Byte, and the trophy on the line is real.
- Luogo: 📍 "Bit & Byte" Arcade
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Velocità
- Durata: 1h
- Costo: 3 monete
- Dati: durata=1h ; costo=3 ; categoria=videogioco ; stat=velocita

**Standard** — +1 Velocità, Felicità +5
Dati: reward= velocita+1, fel+5
Testo: "The arcade hums with its usual chorus of cabinets and blinking lights. You grab the first free screen, thumbs already loaded — and you grind out points like the joystick answers to you alone. Not the all-time house record, but enough to earn a respectful nod from the guy behind the counter."
Scena: pet di profilo davanti al cabinato, pollici sui pulsanti, aria concentrata

**Fallimento** (condizione: Maleducato + Velocità 0) — rimborso dei 3 monete del costo, Felicità invariata
Dati: cond= maleducato & velocita<=0 ; reward= rimborsoCosto
Testo: "First level, first game over — and let's be honest, the game wasn't the problem. The cabinet flashes the most humiliating words in the alphabet, and you answer with a punch that makes more noise than damage. The manager, mortified by the scene, walks you out with a hand on your shoulder: 'there there, no harm done, but maybe don't come back for a while.'"
Scena: pet col pugno chiuso contro lo schermo "GAME OVER", oppure scortato fuori

**Super successo** (condizione: Nerd O Velocità 3+, oppure perk Videogioco già posseduto) — Felicità +10, Coppa Arcade (arredo raro, +1 Velocità passivo; piazzata = perk Videogioco: niente fallimento e sempre super successo nelle prossime missioni Videogioco)
Dati: cond= nerd | velocita>=3 ; reward= fel+10, arredo:Coppa Arcade, perk:videogioco
Testo: "Someone taped a 'FLASH TOURNAMENT — WIN THE CUP' sign over the fanciest cabinet in the room. You enter for laughs, advance on a mix of reflexes and shameless luck, and by the final, half the arcade is rooting for the other guy. You win anyway. The manager personally hands you an actual trophy — heavy, shiny, embarrassingly oversized for a tournament invented by accident on a Tuesday afternoon."
Scena: pet con le braccia alzate, coppa dorata sopra la testa, luci/folla sullo sfondo

## Missione 2: Birthday Party at the Park
Brief: Balloons, aggressively cheerful music, a cake nobody's watching closely enough: a birthday party is in full swing at Antenna Park.
- Luogo: 📍 Antenna Park
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma

**Standard** — +1 Carisma, Felicità +5, Fetta di torta (cibo, Carisma+1)
Dati: reward= carisma+1, fel+5, cibo:Fetta di torta
Testo: "The park is bursting with balloons and that aggressively cheerful music you can hear from three blocks away. You dive into the crowd, chat, laugh at the right jokes at the right moments — and before you vanish into the chaos, someone puts a slice of cake in your hand. Just one. 'The rest is for the others.' Still a day well spent."
Scena: pet tra sagome di altri invitati, piatto con fetta di torta in mano, palloncini

**Fallimento** (condizione: Maleducato + Carisma 0) — niente Carisma, Torta intera (cibo, Carisma+3)
Dati: cond= maleducato & carisma<=0 ; reward= cibo:Torta intera
Testo: "You set a personal record for winning people over: zero. One joke too many, one side-eye too far, and within five minutes the whole party is looking at you like a problem to be solved. You don't lose sleep over it: the second nobody's watching, you skip the slice, grab the ENTIRE cake and strut out, leaving the party in chaos wondering where dessert went."
Scena: pet a braccia conserte che scappa con la torta intera sotto il braccio, altri invitati contrariati

**Super successo** (condizione: Carisma 3+) — +1 Carisma, Felicità +10, Macchinina giocattolo (arredo, nessun bonus passivo, solo collezione)
Dati: cond= carisma>=3 ; reward= carisma+1, fel+10, arredo:Macchinina giocattolo
Testo: "You're not even trying to impress anyone, which is exactly why it works: joke after joke, you become the reason this party will be remembered. At the end, the birthday kid personally shoves their favorite present of the day into your hands — a toy car still shiny from the wrapping — 'because you deserve it more than me.'"
Scena: pet al centro di un capannello festante, macchinina in mano che luccica

## Missione 3: Martial Arts Lessons
Brief: The Scrapheap Dojo reeks of sweat and discipline: the sensei lines up the students, and it's his first day on the mat.
- Luogo: 📍 Scrapheap Dojo
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=combattimento ; stat=forza

**Standard** — +1 Forza, Fascia da martial artist (arredo, +1 Forza passivo), Felicità +5
Dati: reward= forza+1, arredo:Fascia da martial artist, fel+5
Testo: "The sensei — or whatever passes for one in here — lines you up with the other students and runs the basic drills. You sweat, take a few hits, give a few back: by the end you've learned two real moves and earned one approving bow. Baby steps."
Scena: pet in guardia, fila di allievi sullo sfondo

**Fallimento** (condizione: Forza 0 O Gentile) — niente Forza, −10 Salute, +1 Carisma
Dati: cond= forza<=0 | gentile ; reward= ferite+10, carisma+1
Testo: "Your first sparring match goes so badly the sensei pulls you off the mat 'for your own safety.' You spend the rest of the lesson on the sidelines with a bruise or three — but that's where another student, as quiet as you, strikes up a conversation. You didn't learn to fight. You made a friend."
Scena: pet seduto a bordo tatami con un cerotto, chiacchiera con un altro allievo

**Super successo** (condizione: Maleducato O Forza 3+) — +1 Forza, Completo da martial artist (arredo, +2 Forza passivo, sostituisce la Fascia), perk Street Fighter (categoria Combattimento: niente fallimento, sempre super successo), Felicità +10
Dati: cond= maleducato | forza>=3 ; reward= forza+1, arredo:Completo da martial artist, perk:combattimento, fel+10
Testo: "You don't even pretend to follow the beginner class: you walk straight up to the advanced students and challenge them one by one, just to see what happens. What happens is they stop laughing remarkably fast. The sensei, torn between horror and respect, hands you the uniform reserved for those who 'truly grasp the spirit of the dojo.'"
Scena: pet in posa vittoriosa, allievi intimoriti intorno, completo nuovo indosso

## Missione 4: Afternoon at the Library
Brief: A table by the window and a stack of blank pages are waiting for him: the Library of Lost Bits is hushed like a church today.
- Luogo: 📍 Library of Lost Bits
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 1h30
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=intelligenza

**Standard** — +1 Intelligenza, Album da disegno (arredo, +1 Intelligenza passivo), Felicità +5
Dati: reward= intelligenza+1, arredo:Album da disegno, fel+5
Testo: "The librarian — or her mechanical/organic equivalent, hard to tell — points you to a table by the window and leaves you a stack of blank sheets. You spend the afternoon sketching and scribbling notes, tongue poking out in concentration. Not a masterpiece, but when you close the album you're sure you've learned something."
Scena: pet seduto al tavolo, album aperto, lingua fuori per la concentrazione

**Fallimento** (condizione: Maleducato) — niente Intelligenza, +1 Forza
Dati: cond= maleducato ; reward= forza+1
Testo: "Five minutes of silence turn out to be five too many: the table, the blank pages, the hum of the neon lights — all way too boring to sit through. You ditch the album mid-page and slip out toward the court around the corner, where at least the ball never gives you that disappointed look."
Scena: pet che scappa con un pallone sottobraccio, foglio a metà abbandonato sul tavolo

**Super successo** (condizione: Intelligenza 3+) — +2 Intelligenza (invece di +1), Libro (arredo, +2 Intelligenza passivo, sostituisce l'Album), Felicità +10
Dati: cond= intelligenza>=3 ; reward= intelligenza+2, arredo:Libro, fel+10
Testo: "The stack of blank sheets stays blank: today you don't feel like drawing, you feel like UNDERSTANDING. You get lost in the shelves and resurface hours later with a pile of books taller than you. The librarian, impressed, lets you take home the most precious volume on the shelf."
Scena: pet che porta una pila di libri più alta di lui, un volume speciale in evidenza

## Missione 5: Delivery in the Scrap Rain
Brief: An acid drizzle nobody can explain falls over the Industrial District alleys, and a package is waiting for its night delivery.
- Luogo: 📍 Industrial District Alleys
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità + Forza
- Durata: 1h
- Dati: durata=1h ; costo=0 ; categoria=consegne ; stat=velocita,forza

**Standard** — +1 Velocità, +1 Forza, +8 monete, −10 Igiene, Felicità +5
Dati: reward= velocita+1, forza+1, monete+8, igiene-10, fel+5
Testo: "The industrial district at night is all narrow alleys, steam hissing from manholes, and that acid drizzle nobody can quite explain. You deliver on time, signature collected, everything by the book — shame about the layer of sludge you've been wearing since block one."
Scena: pet che corre tra vicoli stretti, pacco sottobraccio, macchie sul corpo

**Fallimento** (condizione: Forza 0 E Velocità 0, oppure Nerd con Forza≤1 E Velocità≤1) — niente XP, −15 Igiene, Ombrello meccanico (arredo collezionabile: dimezza il calo Igiene — da −10 a −5 — in tutte le missioni a rischio pioggia/sporco, mentre è piazzato)
Dati: cond= forza<=0 & velocita<=0 | nerd & forza<=1 & velocita<=1 ; reward= igiene-15, arredo:Ombrello meccanico
Testo: "Between potholes, wrong shortcuts and that drizzle that just won't quit, the package arrives late and you arrive worse. Soaked through and vowing never again, you lock yourself in the garage and do the only sensible thing: build yourself an umbrella out of whatever's lying around. Not pretty. Works."
Scena: pet fradicio seduto in garage, assembla un ombrello con pezzi di scarto

**Super successo** (condizione: Forza 2+ E Velocità 2+) — +2 Velocità, +2 Forza, +15 monete, −10 Igiene (come standard), Scooter giocattolo (arredo, +1 Velocità passivo), Felicità +10
Dati: cond= forza>=2 & velocita>=2 ; reward= velocita+2, forza+2, monete+15, igiene-10, arredo:Scooter giocattolo, fel+10
Testo: "You dart through the alleys like you've got them memorized, hopping puddles and dodging steam-belching pipes without ever slowing down. Record delivery, generous tip, and the customer — startled to see you this early AND this clean, relatively speaking — throws in a toy scooter 'for next time.'"
Scena: pet che salta agilmente pozzanghere, scooter in mano

## Missione 6: TV Commercial Audition
Brief: New faces every five minutes, cameras rolling: it's almost his turn at the audition inside the Broadcast Studio.
- Luogo: 📍 Broadcast Studio
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma

**Standard** — +1 Carisma, +10 monete, Felicità +5
Dati: reward= carisma+1, monete+10, fel+5
Testo: "The casting call is a carousel of new faces cycling in and out every five minutes. When it's your turn, you say the line, strike the pose, and the director nods with the face of someone who's seen better but isn't complaining. You're in. The pay's not bad either."
Scena: pet davanti a luci da studio, regista che annuisce

**Fallimento A** (condizione: Maleducato + Carisma ≤1) — niente Carisma, Megafono (arredo, +1 Carisma passivo)
Dati: priorita=1 ; cond= maleducato & carisma<=1 ; reward= arredo:Megafono
Testo: "The director corrects you one time too many, so you declare the audition over — but not before sharing your full, unsolicited review of his directing. You don't get cast. You do, however, storm out with his megaphone under your arm."
Scena: pet che se ne va a grandi passi con un megafono, regista scandalizzato

**Fallimento B** (condizione: Intelligenza 0 O Carisma 0) — niente Carisma, +3 monete, Biscotto (cibo, Carisma+1)
Dati: priorita=2 ; cond= intelligenza<=0 | carisma<=0 ; reward= monete+3, cibo:Biscotto
Testo: "The lines were written on a sheet of paper that, at some point, you simply stopped looking at. The director thanks you with that special politeness that means 'we will not be calling' — but someone on the crew takes pity, slips a couple of coins in your pocket and a cookie from the catering table. Better than nothing."
Scena: pet con un biscotto in mano, espressione un po' delusa, tavolo del catering sullo sfondo

**Super successo** (condizione: Carisma 3+) — +1 Carisma, +20 monete, Statuetta tipo Oscar (arredo, +1 Carisma passivo), Felicità +10
Dati: cond= carisma>=3 ; reward= carisma+1, monete+20, arredo:Statuetta tipo Oscar, fel+10
Testo: "At some point you're not even acting anymore — you're just being YOU, and the camera seems to love it. The director stands up mid-audition. They cast you on the spot, pay you triple, and somebody even hands you a leftover statuette from who-knows-what awards night."
Scena: pet sotto i riflettori, regista in piedi che applaude, statuetta dorata in mano

## Missione 7: The Monster in the Sewers
Brief: Something big, furry, and considerably angrier than usual is prowling the Sewers beneath the city: tonight, it's hunting season.
- Luogo: 📍 Sewers / Abandoned Lab
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Durata: 1h30
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza

Le 4 armi (drop casuale nello standard, set completo nei super successi "da combattimento"): Bastone da combattimento, Sai gemelli, Nunchaku arrugginiti, Katane a farfalla — tutte arredo, +1 Forza passivo, stesso bonus, differenza solo estetica/collezione.

**Standard** — +1 Forza, −15 Salute, 1 arma casuale (delle 4), Felicità +5
Dati: reward= forza+1, ferite+15, armaCasuale, fel+5
Testo: "Something big, furry, and considerably angrier than your average street rat is prowling the sewers under the city. The fight is short but ugly — you win, though your hide pays the bill. You grab a random weapon from the wreckage of its lair and limp home satisfied."
Scena: pet in posa vittoriosa ma ammaccato, un'arma in mano, sfondo fogna

**Fallimento** (condizione: Forza 1 o meno) — niente Forza, −25 Salute, +5 monete, Pesi (arredo, +1 Forza passivo), Spiedino (cibo, Forza+1)
Dati: cond= forza<=1 ; reward= ferite+25, monete+5, arredo:Pesi, cibo:Spiedino
Testo: "The mutant rat is twice your size and proves it inside thirty seconds. You retreat more banged-up than ever — but not quite empty-handed: you scoop up a few coins spilled from some unlucky pocket, and the neighborhood gym gifts you a set of weights and a well-grilled skewer 'to get your strength back.' Literally."
Scena: pet zoppicante, pesi e spiedino in mano

**Super successo — Dominio** (condizione: Forza 3+) — +2 Forza, −10 Salute, +20 monete, tutte e 4 le armi, Felicità +10
Dati: priorita=2 ; cond= forza>=3 ; reward= forza+2, ferite+10, monete+20, tutteArmi, fel+10
Testo: "It's not even a contest: you floor it with embarrassing ease and watch it scamper off into the dark. The lair is all yours — and no random weapon this time. You're taking ALL of them."
Scena: pet trionfante con tutte le armi addosso, topo in fuga sullo sfondo

**Super successo — Intimidazione** (condizione: Forza 2+ E Maleducato) — +2 Forza, +15 monete, tutte le armi, il topo come allenatore per 7 giorni (arredo temporaneo: +1 Forza extra ad ogni allenamento Forza a casa, poi scade), Felicità +10
Dati: priorita=3 ; cond= forza>=2 & maleducato ; reward= forza+2, monete+15, tutteArmi, allenatore:7g, fel+10
Testo: "You don't even need to throw a punch: one dirty look and the big rat understands exactly who it's dealing with. Terrified, it hands over weapons and coins — and to apologize properly, it even offers to be your personal trainer for a week before vanishing into the dark again."
Scena: pet minaccioso, topo terrorizzato ai suoi piedi

**Super successo — Amicizia** (condizione: Gentile E Carisma 3+) — +1 Forza (solo XP base, niente armi/bottino), 0 Salute persa, il topo come allenatore permanente (arredo: +1 Forza extra ad ogni allenamento Forza a casa, per sempre), Felicità +10
Dati: priorita=1 ; cond= gentile & carisma>=3 ; reward= forza+1, allenatore:perm, fel+10
Testo: "Instead of throwing punches you sit down — literally — and talk. The big rat just wanted some company in those dark sewers. Before you know it, you've promised to train together every single day. No weapons, no loot: a real trainer, forever."
Scena: pet e topo seduti fianco a fianco, atmosfera calma, nessuna arma in vista

Priorità se un pet soddisfa più condizioni di super successo insieme: Amicizia > Dominio > Intimidazione (l'amicizia è un percorso alternativo che esclude lo scontro a prescindere dalla Forza).

## Missione 8: Skate Race on Neon Avenue
Brief: Crowds lining the sidewalks, the light blinking out the start: it's skate-race night on Neon Avenue.
- Luogo: 📍 Neon Avenue
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Durata: 1h
- Dati: durata=1h ; costo=0 ; categoria=sport ; stat=velocita

**Standard** — +1 Velocità, +8 monete, Pesce alla griglia (cibo, Velocità+1), Felicità +5
Dati: reward= velocita+1, monete+8, cibo:Pesce alla griglia, fel+5
Testo: "The crowd packs the sidewalks as the traffic light blinks out the starting signal. You're not the lightning bolt of the evening, but you hold an honest pace and cross the line with your head high, to polite applause and a participation prize that at least covers the skate rental."
Scena: pet sui pattini al traguardo, pubblico ai lati

**Fallimento** (condizione: Velocità 0 O Gentile) — niente Velocità, Pattino spaiato (arredo, +1 Velocità passivo)
Dati: cond= velocita<=0 | gentile ; reward= arredo:Pattino spaiato
Testo: "You take off with all the politeness in the world — which, in a skate race, is roughly the same as standing still. Everyone overtakes you, with mutual courtesy on both sides. On the edge of the track, though, you spot a single skate somebody lost: good enough to keep."
Scena: pet sorpassato da tutti, raccoglie un pattino sul bordo pista

**Super successo** (condizione: Velocità 3+ O Sportivo) — +2 Velocità, +20 monete, Pattini da gara (arredo, +2 Velocità passivo), perk Sport (categoria Sport: niente fallimento, sempre super successo), Felicità +10
Dati: cond= velocita>=3 | sportivo ; reward= velocita+2, monete+20, arredo:Pattini da gara, perk:sport, fel+10
Testo: "At some point you're not even skating — you're flying at ground level. You cross the finish line with an embarrassing lead, and the race sponsor hands you a pair of professional skates straight out of the shop window."
Scena: pet che taglia il traguardo con largo margine, pattini scintillanti

## Missione 9: Neighborhood Science Fair
Brief: Wobbly poster boards and smoking experiments: at the Neighborhood Science Fair, it's his turn to present an invention.
- Luogo: 📍 Neighborhood Science Fair
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: invenzione
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=studio ; stat=int ; tag=invenzione

**Standard** — +2 Int, +8 monete, Felicità +5
Dati: reward= int+2, monete+8, fel+5
Testo: "The Science Fair is a riot of wobbly poster boards, smoking experiments and suspicious buzzing sounds. You present your invention to a jury of four thick-glasses know-it-alls: they nod, take notes, one even fires a hard question at you and you answer on the fly. You don't win, but you leave with a fuller head than you came in with."
Scena: pet davanti a un cartellone-esperimento, giuria di profilo che prende appunti

**Fallimento** (condizione: Sportivo) — niente Int, Zuppa di verdure (cibo, Int+2)
Dati: priorita=1 ; cond= sportivo ; reward= cibo:Zuppa di verdure
Testo: "Five minutes of formulas and circuits and your ears are already ringing: way too much nerd stuff for your taste. You drift over to the refreshments table, where at least the soup is hot, and spend the rest of the fair shooting paper-ball three-pointers. Science-wise, nothing stuck today. Soup-wise, plenty."
Scena: pet annoiato che si allontana dai cartelloni con una scodella di zuppa in mano

**Fallimento** (condizione: Intelligenza ≤1) — +6 monete, +1 Int
Dati: priorita=2 ; cond= int<=1 ; reward= monete+6, int+1
Testo: "Your invention had, let's say, potential. Shame that halfway through the presentation it started sizzling, then smoking, then powering down with one sad little 'plop.' The jury claps out of kindness and refunds your expenses 'for the effort.' You did learn something — mostly how NOT to do it."
Scena: pet imbarazzato accanto a un aggeggio che sputa fumo

**Super successo** (condizione: Intelligenza 3+, o auto col talento Inventore via tag invenzione) — +3 Int, +15 monete, Coppa della Fiera (arredo raro, +1 Int passivo + perk Studio "Doc Brown": missioni Studio → niente fallimento e sempre super successo), Felicità +10
Dati: cond= int>=3 ; reward= int+3, monete+15, arredo:Coppa della Fiera, perk:studio, fel+10
Testo: "You're not presenting an invention — you're presenting THE FUTURE, and the jury gets it within thirty seconds. Glasses slide down noses, notes turn frantic, applause breaks out on its own. They hand you the 'Fair Trophy' in front of everyone, and one of the judges shakes your hand a little too long: 'remember me when you're famous.'"
Scena: pet che alza la Coppa della Fiera, giuria in piedi che applaude

## Missione 10: Robot Rumble
Brief: Dented sheet metal, sparks in the air: at the Robot Rumble Arena, his homemade robot is about to roll into the ring.
- Luogo: 📍 Robot Rumble Arena
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: invenzione, gara
- Durata: 1h
- Costo: 3 monete
- Dati: durata=1h ; costo=3 ; categoria=studio ; stat=int ; tag=invenzione,gara

**Standard** — +1 Int, Coppa Robot Wars (arredo, +1 Int passivo), Felicità +5
Dati: reward= int+1, arredo:Coppa Robot Wars, fel+5
Testo: "The Robot Rumble arena is a square of dented sheet metal where tiny homemade robots headbutt each other amid sparks and hysterical cheering. Yours holds its own: a few hits landed, a few dents collected, an honorable mid-table finish. You take home a trophy and a solid education in motors and gears."
Scena: pet a bordo arena con un piccolo robot telecomandato, scintille

**Fallimento** (condizione: Gentile) — niente Int, +1 Carisma, Insalatona (cibo, Int+1)
Dati: priorita=1 ; cond= gentile ; reward= carisma+1, cibo:Insalatona
Testo: "You reach the arena, take one look at those little robots about to smash each other to bits... and you just can't. They're too cute to end up in pieces. You drop out, sit down with your 'opponents' to talk about how you all built them, and walk away with more friends than dents. You didn't learn to fight — but you never really wanted to."
Scena: pet seduto in cerchio con altri concorrenti e i loro robottini, atmosfera amichevole

**Fallimento** (condizione: Intelligenza ≤1) — niente Int, Zuppa di verdure (cibo, Int+2)
Dati: priorita=2 ; cond= int<=1 ; reward= cibo:Zuppa di verdure
Testo: "Your robot lasts exactly one round: it starts off crooked, spins in circles, then stops dead as if it had second thoughts. The other contestants don't even mock you — they just watch with pity and hand you a bowl of soup, 'hey, next time will go better.' At least you eat."
Scena: pet accanto al suo robottino fermo e fumante, un altro concorrente gli porge del cibo

**Super successo — Sabotaggio** (condizione: Maleducato + Intelligenza 2+) — +2 Int, Telecomando Pirata (arredo, +1 Velocità passivo + perk Sabotatore: nelle gare senza perk proprio → sempre super successo), Felicità +10
Dati: priorita=1 ; cond= maleducato & int>=2 ; reward= int+2, arredo:Telecomando Pirata, perk:sabotatore, fel+10
Testo: "While everyone else focuses on their robots, you focus on ONE 'borrowed' remote control. Two tweaks to their receivers and suddenly the rival bots go haywire, turn on their own masters, and self-destruct in a waltz of sparks. You win by forfeit. Nobody figured out a thing, and you keep the remote."
Scena: pet con un ghigno che smanetta un telecomando, robot avversari in tilt sullo sfondo

**Super successo — Mecha-Bot** (condizione: Intelligenza 3+) — +2 Int, Mecha-Bot (arredo raro, +2 Forza passivo), Felicità +10
Dati: priorita=2 ; cond= int>=3 ; reward= int+2, arredo:Mecha-Bot, fel+10
Testo: "The others brought little robots. You brought a MONSTER. Your Mecha-Bot sweeps the arena in three moves, and while your opponents pick up the pieces of theirs, you just stand there, arms crossed. It's coming home with you — not a toy anymore, but a compact war beast that makes you considerably scarier from now on."
Scena: pet trionfante accanto a un robot grosso e minaccioso, rottami intorno

Priorità super M10: Sabotaggio (Maleducato) prima di Mecha-Bot (generico Int 3+). Come per M7, il super batte sempre il fallimento: un Gentile con Int 3+ va in Mecha-Bot, non nel fallimento "fa amicizia".

## Missione 11: Lost Critter Shelter
Brief: The Lost Critter Shelter is all yips, metallic chirps and three-eyed fuzzballs waiting to be won over — good luck this afternoon.
- Luogo: 📍 Lost Critter Shelter
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: natura
- Durata: 1h
- Costo: gratis (volontariato)
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=natura,companion

**Standard** — +1 Carisma, +8 monete, Cuccia (arredo camera, +1 Felicità passiva), Felicità +5
Dati: reward= carisma+1, monete+8, arredo:Cuccia, fel+5
Testo: "The shelter is a riot of yips, metallic chirps and unidentifiable alien noises. You spend the afternoon cuddling robo-puppies and bewildered little creatures, cleaning cages, and convincing a couple of families that yes, that three-eyed fuzzball is adorable. The owner, deeply moved, thanks you with a few coins and a spare pet bed 'for when you adopt one yourself.'"
Scena: pet accovacciato che accarezza un cucciolo robo/alieno, gabbiette sullo sfondo, altri cuccioli intorno — mood caldo e tenero

**Fallimento** (condizione: Maleducato) — niente Carisma, morso (Ferite +10), Biscotto (cibo Carisma+1), Distributore di croccantini (arredo cucina)
Dati: priorita=1 ; cond= maleducato ; reward= ferite+10, cibo:Biscotto, arredo:Distributore di croccantini
Testo: "It takes you exactly one afternoon to turn a peaceful shelter into a war zone: you sass the customers, treat the pups like a nuisance, and one of them — understandably — sinks its teeth into your calf. You limp out, but not empty-handed: in the chaos you swipe a box of treats and 'borrow' the kibble dispenser while you're at it."
Scena: pet scocciato che si allontana con un cucciolo aggrappato alla gamba e una scatola sottobraccio — mood comico-caotico

**Fallimento** (condizione: Carisma ≤1) — niente Carisma, morso (Ferite +10), +5 monete, Biscotto (cibo Carisma+1)
Dati: priorita=2 ; cond= carisma<=1 ; reward= ferite+10, monete+5, cibo:Biscotto
Testo: "You give it your all, but the spark just isn't there: the pups sniff you, circle you, and decide you're not their type. One of them, just to be safe, gives you a little nip. The owner sends you off with two coins and a handful of cookies 'for your trouble.' There's always next time."
Scena: pet mogio con un cerotto, un cucciolo che gli volta le spalle — mood dispiaciuto

**Super successo** (condizione: Carisma 3+, o auto col talento Amante della Natura via tag natura) — +2 Carisma, +18 monete, Gattino Robot (arredo camera, +1 Carisma passivo), Felicità +10
Dati: cond= carisma>=3 ; reward= carisma+2, monete+18, arredo:Gattino Robot, fel+10
Testo: "Within an hour you're the shelter's favorite: the pups follow you around in single file, the customers only trust you, and you've found homes for half the guests before sundown. The owner showers you in coins and places the shelter's crown jewel in your arms: a robot kitten that has chosen YOU and has zero intention of ever letting go."
Scena: [DEDICATA] pet raggiante circondato da cuccioli festanti, un gattino robot in braccio che fa le fusa (scintille/cuoricini) — mood trionfale e adorabile

## Missione 12: The Mad Gardener's Greenhouse
Brief: In the Mad Gardener's Greenhouse the alien plants hiss, stretch and stare back — and the old gardener plays by his own strange rules.
- Luogo: 📍 Mad Gardener's Greenhouse
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: natura
- Durata: 1h30
- Costo: gratis (volontariato)
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; tag=natura

**Standard** — +1 Int, +8 monete, Felicità +5
Dati: reward= int+1, monete+8, fel+5
Testo: "The greenhouse is a jungle of alien plants that hiss, stretch, and stare at you with pods that look suspiciously like eyes. The old gardener, half mad and covered in leaves, teaches you which ones to water, which ones NOT to touch, and which one to hum to until it blooms. You leave with green fingers and a head full of botanical facts — absurd, but useful."
Scena: pet con annaffiatoio tra piante aliene bizzarre e altissime, il giardiniere eccentrico che indica una pianta — mood curioso, luce verde-serra

**Fallimento** (condizione: Intelligenza ≤1) — niente Int, Manuale di Botanica (arredo camera, +1 Int passivo)
Dati: cond= int<=1 ; reward= arredo:Manuale di Botanica
Testo: "Alien plants have very precise rules, and you break basically all of them: you water the one that hates water, prune the one that wanted to be left alone, and end up wrapped in the tentacles of one that's 'usually docile.' The gardener untangles you, chuckling, and hands you a manual: 'next time, read this BEFORE you come in.'"
Scena: pet impigliato nei tentacoli di una pianta, il giardiniere che ride e porge un libro — mood comico

**Super successo** (condizione: Intelligenza 3+, o auto col talento Amante della Natura via tag natura) — +2 Int, +15 monete, Pianta Esotica (arredo mettibile in ogni stanza, +2 a una stat RPG casuale ogni giorno), Felicità +10
Dati: cond= int>=3 ; reward= int+2, monete+15, arredo:Pianta Esotica, fel+10
Testo: "You don't just learn the greenhouse's rules — you rewrite them. You instantly get what every plant wants, coax one into blooming that the gardener hadn't seen flower in years, and he, teary-eyed, entrusts you with his most precious specimen: an exotic plant with unpredictable powers that gifts a different energy every day to whoever stays close."
Scena: [DEDICATA] pet che regge con orgoglio una pianta esotica luminosa e pulsante di colori, il giardiniere commosso sullo sfondo — mood magico

## Missione 13: Arm Wrestling at the Bolt Bar
Brief: The Bolt Bar is packed with bruisers who shake hands like they mean to break them — now it's your turn at the table.
- Luogo: 📍 Bolt Bar
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: gara
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=gara

**Standard** — +1 Forza, +8 monete, Trofeo Braccio di Ferro (arredo, +1 Forza passivo), Felicità +5
Dati: reward= forza+1, monete+8, arredo:Trofeo Braccio di Ferro, fel+5
Testo: "The Bolt Bar is packed with bruisers who shake hands like they're trying to snap them. You sit down, plant your elbow, and put the first challenger's arm down with one clean push. Applause, a drink on the house, and a tin trophy."
Scena: pet al tavolo che atterra il braccio di un energumeno, folla di bestioni intorno

**Fallimento** (condizione: Gentile + Forza ≤1) — +1 Carisma, Spiedino (cibo Forza+1)
Dati: priorita=1 ; cond= gentile & forza<=1 ; reward= carisma+1, cibo:Spiedino
Testo: "You don't have the muscle to win, but you've got the right smile: instead of getting crushed, you end up laughing and joking with the big guys, who adopt you as the official mascot of the counter."
Scena: pet minuto che ride tra energumeni sorridenti

**Fallimento** (condizione: Forza ≤1) — Ferite +10, Bistecca (cibo Forza+2)
Dati: priorita=2 ; cond= forza<=1 ; reward= ferite+10, cibo:Bistecca
Testo: "Your elbow hits the table in half a second flat, and you take home one very sore arm. The big guys, between laughs, slide you a nice steak: 'eat up, celery stick.'"
Scena: pet col braccio indolenzito, un bestione che gli porge un piatto di carne

**Super successo** (condizione: Forza 3+, o auto col perk Sabotatore via tag gara) — +2 Forza, +12 monete, Trofeo d'Oro Braccio di Ferro (arredo raro, +1 Forza passivo + perk Popeye: mangiando verdure prende anche +1 Forza), Felicità +10
Dati: cond= forza>=3 ; reward= forza+2, monete+12, arredo:Trofeo d'Oro Braccio di Ferro, perk:popeye, fel+10
Testo: "You put them down one after another without breaking a sweat. The whole bar chants your name, and the owner takes down the golden trophy from the wall — the one reserved for legends."
Scena: [DEDICATA] pet che alza il trofeo d'oro, energumeni sconfitti a bocca aperta

## Missione 14: The Sixth-Floor Move
Brief: Six flights, zero elevator, one wardrobe that weighs as much as you: the walk-up move shows no mercy today.
- Luogo: 📍 Walk-Up Building
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza

**Standard** — +1 Forza, +15 monete, −8 Igiene, Felicità +5
Dati: reward= forza+1, monete+15, igiene-8, fel+5
Testo: "Six flights, no elevator, and a four-door wardrobe that weighs as much as you do. Up and down until evening: your arms are on fire, but the move is done and your wallet says thank you. Shame about the dust. It's everywhere."
Scena: pet che porta un armadio enorme su per le scale, sudato

**Fallimento** (condizione: Maleducato) — Arrosto (cibo multi-porzione: 3 fette, ogni fetta Forza+1)
Dati: priorita=1 ; cond= maleducato ; reward= cibo:Arrosto
Testo: "Two orders too many from the foreman and you quit halfway up the stairs. But since you're already wandering the building, you 'borrow' an entire roast from a kitchen somebody left open."
Scena: pet che se ne va spallucciando con un arrosto fumante sottobraccio

**Fallimento** (condizione: Forza ≤1) — +6 monete, Barretta proteica (cibo Forza+1)
Dati: priorita=2 ; cond= forza<=1 ; reward= monete+6, cibo:Barretta proteica
Testo: "On trip number three your legs file a formal complaint. The boss pays you half and hands you a protein bar: 'train up and come back.'"
Scena: pet accasciato sui gradini con una scatola mollata a terra

**Super successo** (condizione: Nerd + talento Inventore) — +2 Forza, +20 monete, Targa Traslocatore dell'Anno (arredo, +1 Forza passivo), 0 energia consumata e niente −Igiene (monti un montacarichi), Felicità +10
Dati: priorita=1 ; cond= nerd & talento:inventore ; reward= forza+2, monete+20, arredo:Targa Traslocatore dell'Anno, energiaMissione=0, fel+10
Testo: "Instead of wearing yourself out, you spend an hour rigging a freight hoist from ropes and pulleys: physics does the heavy lifting. Same plaque, same pay, zero sweat — and clean hands."
Scena: [DEDICATA] pet soddisfatto accanto a un montacarichi rustico che solleva i mobili

**Super successo** (condizione: Forza 3+) — +2 Forza, +20 monete, −8 Igiene, Targa Traslocatore dell'Anno (arredo, +1 Forza passivo), Felicità +10
Dati: priorita=2 ; cond= forza>=3 ; reward= forza+2, monete+20, igiene-8, arredo:Targa Traslocatore dell'Anno, fel+10
Testo: "You carry two boxes per hand and fly up and down the stairs like they're flat ground. You finish in half the time and the boss hands you the 'Mover of the Year' plaque."
Scena: [DEDICATA] pet trionfante con la targa, pila di scatoloni sistemati dietro

Priorità M14: la via Nerd+Inventore (montacarichi, 0 energia) batte il super generico Forza 3+.

## Missione 15: Catch That Purse Snatcher
Brief: A purse snatcher zips past with somebody's loot — the chase through the downtown alleys is officially on.
- Luogo: 📍 Downtown Alleys
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: inseguimento
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=inseguimento

**Standard** — +1 Velocità, +10 monete, Paperella a Reazione (arredo bagno, +1 Velocità passivo), Felicità +5
Dati: reward= velocita+1, monete+10, arredo:Paperella a Reazione, fel+5
Testo: "A purse snatcher zips past you with somebody's loot. You launch into a sprint, chase him through the alleys and tackle him into a dumpster. The victim rewards you — and inside the recovered bag, there's even a jet-powered rubber duck."
Scena: pet in corsa che placca uno scippatore, borsa che vola

**Fallimento** (condizione: Velocità ≤1) — Sushi (cibo Velocità+2)
Dati: cond= velocita<=1 ; reward= cibo:Sushi
Testo: "He takes off like a rocket and you... don't. You lose him at the first corner. The neighbors, who witnessed the attempt, console you with some fresh sushi."
Scena: pet piegato in due col fiatone, lo scippatore lontano

**Super successo** (condizione: Velocità 3+, oppure Sportivo + talento Energico) — +2 Velocità, +15 monete, Scarpe da Parkour (arredo, +1 Velocità passivo + perk Parkour Master: auto-super nelle missioni tag inseguimento), Felicità +10
Dati: cond= velocita>=3 | (sportivo & talento:energico) ; reward= velocita+2, monete+15, arredo:Scarpe da Parkour, perk:parkour, fel+10
Testo: "You don't just catch him — you do it ricocheting off walls, stairs and rooftops like the whole city is your personal parkour course. You come away with a pair of legendary shoes and a reputation: on these streets, nobody outruns you."
Scena: [DEDICATA] pet a mezz'aria tra due muri in posa da parkour, scippatore braccato sotto

## Missione 16: Bare-Handed Fish Catch
Brief: The city aquarium's tanks have burst and fish are flopping everywhere across the flooded floor — bare hands only.
- Luogo: 📍 City Aquarium (Broken Tanks)
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: natura
- Durata: 1h30
- Costo: gratis
- Nota: missione volutamente difficile (super a Velocità 4+)
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=natura

**Standard** — +2 Velocità, +10 monete, Acquario di Casa (arredo camera, +1 Velocità +1 Felicità passivo), Felicità +5
Dati: reward= velocita+2, monete+10, arredo:Acquario di Casa, fel+5
Testo: "The aquarium tanks have burst and fish are flopping all over the flooded floor. You chase them for hours, slipping, sliding, and snatching them up bare-handed. You save a good number, earn your fee, and get to keep one in a bowl."
Scena: pet che si tuffa per acchiappare pesci guizzanti in una sala allagata

**Fallimento** (condizione: Velocità ≤1, oppure Nerd + talento Idrofobico) — +4 monete, +1 Velocità, niente acquario
Dati: cond= velocita<=1 | (nerd & talento:idrofobico) ; reward= monete+4, velocita+1
Testo: "You're slow, the water gives you the creeps, and the fish are faster than you. You catch exactly two after an eternity: small pay, no aquarium. At least you now have a much clearer idea of how it's done."
Scena: pet fradicio e sconsolato con due pesciolini in mano

**Super successo** (condizione: Velocità 4+, o auto col talento Amante della Natura via tag natura) — +3 Velocità, +20 monete, Acquario di Casa (arredo camera, +1 Velocità +1 Felicità passivo), Felicità +10
Dati: cond= velocita>=4 ; reward= velocita+3, monete+20, arredo:Acquario di Casa, fel+10
Testo: "You dart between the puddles like lightning (or, if you're the gentle type, you sweet-talk the fish into leaping straight into your hands). You save every last one, the aquarium stuffs your wallet, and they gift you the prettiest specimen in the building."
Scena: [DEDICATA] pet che afferra al volo tre pesci in un tuffo spettacolare, spruzzi ovunque

---

## Missione 73: Pups' Tug-of-War
Brief: Rope taut, mud everywhere: the playground pups' tug-of-war tournament is no joke today.
- Luogo: 📍 Playground
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: gara
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=gara ; stadio=baby

**Standard** — +1 Forza, Felicità +5
Dati: reward= forza+1, fel+5
Testo: "The playground pups' tug-of-war tournament: two teams, one rope, mud for everybody. Your team wins two pulls out of three and you head home filthy and satisfied."
Scena: due squadre di cuccioli che tirano una corda, fango che schizza

**Fallimento** (condizione: Forza ≤1) — −10 Igiene, Biscotto (cibo, Carisma+1)
Dati: cond= forza<=1 ; reward= igiene-10, cibo:Biscotto, fel-5
Testo: "One yank and you're airborne, landing face-first as a welcome mat for the other team. You get up wearing mud from head to toe — but nobody says no to a consolation cookie."
Scena: pet spiaccicato nel fango con la corda sopra, avversari che esultano

**Super successo** (condizione: Forza 3+) — +2 Forza, +10 monete, Corda della Vittoria (arredo salone, +1 Forza), Felicità +10
Dati: cond= forza>=3 ; reward= forza+2, monete+10, arredo:Corda della Vittoria, fel+10
Testo: "You pull so hard the entire opposing team crosses the line in one piece, like a little train. They give you the rope as a prize, plus the official title of playground 'anchor.'"
Scena: [DEDICATA] pet che tira da solo contro cinque cuccioli, tutti che volano verso di lui

## Missione 74: Toy Moving Day
Brief: The pup next door's moving to a bigger room, and somebody needs little arms for all those toy boxes.
- Luogo: 📍 The Neighbor's House
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza ; stadio=baby

**Standard** — +1 Forza, +8 monete, Felicità +5
Dati: reward= forza+1, monete+8, fel+5
Testo: "The pup next door is upgrading to a bigger bedroom, and somebody needs little arms for all those boxes of toys. Three hours of back-and-forth and your allowance is well earned."
Scena: pet che porta uno scatolone di giocattoli più grande di lui

**Fallimento** (condizione: Forza ≤1) — Fetta di torta (cibo, Carisma+1)
Dati: cond= forza<=1 ; reward= cibo:Fetta di torta, fel-5
Testo: "The first box tips over on top of you and you spend the afternoon buried under a mountain of plushies. The neighbor, feeling guilty, repays you with a slice of cake."
Scena: pet che sbuca da una montagna di peluche, un orsacchiotto in testa

**Super successo** (condizione: Forza 3+) — +2 Forza, +15 monete, Dinosauro Giocattolo (arredo camera, +1 Felicità), Felicità +10
Dati: cond= forza>=3 ; reward= forza+2, monete+15, arredo:Dinosauro Giocattolo, fel+10
Testo: "You move everything in half the time, stacking boxes with the precision of a seasoned warehouse pro. The pup next door, awestruck, gifts you their favorite dinosaur."
Scena: [DEDICATA] torre di scatoloni perfetta, pet col dinosauro giocattolo in braccio

## Missione 75: Royal Tag
Brief: Playground tag today has real stakes: the slide throne is officially up for grabs.
- Luogo: 📍 Playground
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: inseguimento
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sport ; stat=velocita ; tag=inseguimento ; stadio=baby

**Standard** — +1 Velocità, Felicità +5
Dati: reward= velocita+1, fel+5
Testo: "Playground tag is serious business today: the slide throne is on the line. You run, you juke, you escape by a whisker twice, and you close out the afternoon without ever once being 'it.'"
Scena: pet che scarta un inseguitore con una finta, altri cuccioli che corrono

**Fallimento** (condizione: Velocità ≤1) — Biscotto (cibo, Carisma+1)
Dati: cond= velocita<=1 ; reward= cibo:Biscotto, fel-5
Testo: "You're 'it' within three seconds. And you stay 'it' for two hours: every pup in the park strolls past you in slow motion. At the end, they give you a cookie for the effort (and out of pity)."
Scena: pet col fiatone al centro del parco, cuccioli che gli girano intorno ridendo

**Super successo** (condizione: Velocità 3+) — +2 Velocità, +10 monete, Felicità +10
Dati: cond= velocita>=3 ; reward= velocita+2, monete+10, fel+10
Testo: "Untouchable. Nobody lays a paw on you all afternoon, and when it's your turn to chase, you tag the whole park in three minutes flat. The slide throne is yours — loyal subjects included."
Scena: [DEDICATA] pet seduto in cima allo scivolo come su un trono, cuccioli inchinati sotto

## Missione 76: The Little Mailman
Brief: The real mailman's out sick, and the building needs fast little paws: five floors, zero elevator.
- Luogo: 📍 Apartment Building
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=consegne ; stat=velocita ; stadio=baby

**Standard** — +1 Velocità, +8 monete, Felicità +5
Dati: reward= velocita+1, monete+8, fel+5
Testo: "The real mailman is out sick and the building needs quick little paws: five floors, twelve envelopes, zero elevators. You deliver everything by evening, tongue hanging out."
Scena: pet che sale le scale con un mazzetto di buste tra i denti

**Fallimento** (condizione: Velocità ≤1) — Fetta di torta (cibo, Carisma+1)
Dati: cond= velocita<=1 ; reward= cibo:Fetta di torta, fel-5
Testo: "You deliver 4B's utility bill to the lady in 2A, 2A's party invite to the guy in 5C, and generally invent a brand-new kind of postal chaos. The lady in 2A, however, finds you adorable: cake for you."
Scena: pet confuso tra le buste sul pianerottolo, vicini che se le scambiano

**Super successo** (condizione: Velocità 3+) — +2 Velocità, +15 monete, Felicità +10
Dati: cond= velocita>=3 ; reward= velocita+2, monete+15, fel+10
Testo: "Every envelope to every right door in half an hour, beating the elevator to every single floor. The building takes up a collection: 'the tiny mailman beats the real one.'"
Scena: [DEDICATA] pet che sfreccia su per le scale, buste che volano nelle mani dei vicini

## Missione 77: The Museum Puzzle
Brief: The kids' museum lays out a 500-piece dinosaur: three hours to finish it, tail included.
- Luogo: 📍 Kids' Museum
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=studio ; stat=int ; stadio=baby

**Standard** — +1 Intelligenza, Felicità +5
Dati: reward= int+1, fel+5
Testo: "The kids' museum challenges the pups with a giant 500-piece puzzle: a (nearly) life-size dinosaur. In three hours you place your fair share of pieces, tail included."
Scena: pet concentrato su un puzzle enorme steso sul pavimento del museo

**Fallimento** (condizione: Intelligenza ≤1) — Merendina Gattarcobaleno (cibo, Velocità+1 Felicità+5)
Dati: cond= int<=1 ; reward= cibo:Merendina Gattarcobaleno, fel-5
Testo: "You try jamming the same piece into the same hole for forty minutes (it's not its hole). Then you try tasting it (it's not edible). The guide gently relocates you to the snack table, where the one with the rainbow-trail cat puts your mood right back together."
Scena: pet che morde un pezzo di puzzle, guida del museo che accorre

**Super successo** (condizione: Intelligenza 3+) — +2 Intelligenza, Puzzle Incorniciato (arredo camera, +1 Intelligenza), Felicità +10
Dati: cond= int>=3 ; reward= int+2, arredo:Puzzle Incorniciato, fel+10
Testo: "You place pieces on sight alone, without even glancing at the box, and finish the dinosaur two hours early. The museum gifts you the bedroom edition, pre-framed."
Scena: [DEDICATA] puzzle-dinosauro completo, pet che piazza l'ultimo pezzo tra gli applausi

## Missione 78: The Balcony Garden
Brief: Three pots, mystery seeds and grandma's instructions: the home balcony is about to become a tiny garden.
- Luogo: 📍 Home Balcony
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Intelligenza
- Tag: natura
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=int ; tag=natura ; stadio=baby

**Standard** — +1 Intelligenza, Insalatona (cibo, Intelligenza+1), Felicità +5
Dati: reward= int+1, cibo:Insalatona, fel+5
Testo: "Three pots, mystery seeds and grandma's instructions: the balcony garden is born. You water, you wait, you water again, and the first little leaves pay you back with a salad all your own."
Scena: pet che annaffia tre vasi con un annaffiatoio più grande di lui

**Fallimento** (condizione: Intelligenza ≤1) — Insalatona (cibo, Intelligenza+1)
Dati: cond= int<=1 ; reward= cibo:Insalatona, fel-5
Testo: "You water with a little too much enthusiasm: two pots out of three become swamps and the balcony becomes a protected wetland. The lone surviving sprout, miraculously, still produces a small salad for you."
Scena: pet in mezzo a vasi allagati, un'unica piantina eroica che sbuca

**Super successo** (condizione: Intelligenza 3+, o auto col talento Amante della Natura via tag natura) — +2 Intelligenza, Piantina di Fragole (arredo cucina, +1 Felicità), Insalatona, Felicità +10
Dati: cond= int>=3 ; reward= int+2, arredo:Piantina di Fragole, cibo:Insalatona, fel+10
Testo: "You dose water and sunlight like a tiny agronomist and the garden explodes with life: salad, the smell of basil and — surprise — a strawberry plant nobody ever planted. Prettiest balcony in the whole building."
Scena: [DEDICATA] balcone rigoglioso, pet che raccoglie una fragola rossa perfetta

## Missione 79: The Puppet Show
Brief: The courtyard puppet show needs a fresh voice for the evil dragon: stage set, pups already packed in the front row.
- Luogo: 📍 Building Courtyard
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; stadio=baby

**Standard** — +1 Carisma, +5 monete, Felicità +5
Dati: reward= carisma+1, monete+5, fel+5
Testo: "The courtyard puppet show needs a new voice for the evil dragon. Your roar gets more laughs than screams, but the audience of pups applauds and leaves little coins."
Scena: pet dietro un teatrino di cartone che agita un burattino-drago

**Fallimento** (condizione: Carisma ≤1) — Merendina Gattarcobaleno (cibo, Velocità+1 Felicità+5)
Dati: cond= carisma<=1 ; reward= cibo:Merendina Gattarcobaleno, fel-5
Testo: "You get so deep into character that YOUR OWN dragon puppet scares you: you bail mid-scene and hide behind the puppet stage. The pups think it's part of the show. Almost. The puppeteer consoles you with a snack cake: the one with the flying cat that leaves a rainbow trail behind it."
Scena: pet nascosto dietro il teatrino, burattino-drago abbandonato sul palco

**Super successo** (condizione: Carisma 3+) — +2 Carisma, +12 monete, Burattino Drago (arredo camera, +1 Carisma), Felicità +10
Dati: cond= carisma>=3 ; reward= carisma+2, monete+12, arredo:Burattino Drago, fel+10
Testo: "Your dragon has a voice, a personality, and even a catchphrase the pups keep repeating for days. After the show, the puppeteer hands you the dragon: 'it's more yours than mine now.'"
Scena: [DEDICATA] pet che fa l'inchino col burattino-drago, cortile che applaude in piedi

## Missione 80: The Lemonade Stand
Brief: A little table, a pitcher, a crooked hand-lettered sign: your first lemonade stand opens right on the sidewalk out front.
- Luogo: 📍 Sidewalk Out Front
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Carisma
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=carisma ; stadio=baby

**Standard** — +1 Carisma, +10 monete, Felicità +5
Dati: reward= carisma+1, monete+10, fel+5
Testo: "A little table, a pitcher, a sign written crooked: your very first lemonade stand. Passersby stop more for the cuteness than the thirst, but coins are coins."
Scena: pet dietro un banchetto con brocca e cartello 'LIMONATA 1 MONETA'

**Fallimento** (condizione: Carisma ≤1) — +3 monete
Dati: cond= carisma<=1 ; reward= monete+3, fel-5
Testo: "It's hot, the lemonade is right there, and you are weak: you drink most of it yourself. Your only sale goes to a gentleman who mostly wanted a good laugh. Final tally: 3 coins and a belly full of lemonade."
Scena: pet con la brocca vuota rovesciata sulla testa, cartello che pende storto

**Super successo** (condizione: Carisma 4+) — +2 Carisma, +20 monete, Spremiagrumi d'Oro (arredo cucina, +1 Carisma), Felicità +10
Dati: cond= carisma>=4 ; reward= carisma+2, monete+20, arredo:Spremiagrumi d'Oro, fel+10
Testo: "A smile, some small talk, a dash of theater: an actual LINE forms. You empty the pitcher three times over, and the fruit vendor, who's been watching the whole thing, sponsors you with a golden juicer: 'I invest in talent.'"
Scena: [DEDICATA] fila di clienti al banchetto, pet che versa limonata con gesto da barman

---

# TEEN — missioni sbloccate dall'evoluzione (tier più alto: soglie 10+/13+, reward più grosse, modifiche permanenti e vestiti indossabili)


## Missione 17: Pimp My Pet — The Modding Clinic [teen intro, off-rotation, once per evolution]
Brief: Now a teen, the Modding Clinic awaits: one permanent upgrade, your pick alone. Choose carefully, it's forever.
- Luogo: 📍 The Modding Clinic (robot → mechanic's garage · alien → molting clinic; same building on the map, reskinned per species)
- Razza: entrambe (opzioni diverse per razza)
- Tipo: modifica PERMANENTE, scelta del giocatore (niente fallimento/super)
- Costo: 10 monete
- Dati: teenIntro=1 ; stadio=teen ; costo=10 ; scelta=1

Il giocatore sceglie UNA modifica permanente: +2 permanente alla stat scelta + nuovo sprite (permanente, per sempre).

| Stat | Robot (impianto) | Alieno (mutazione) | Bonus |
|---|---|---|---|
| Forza | Servo-braccia idrauliche | Chele / arto extra | +2 Forza permanente |
| Velocità | Turbina dorsale | Pinne / zampe da corsa | +2 Velocità permanente |
| Intelligenza | Antenna neurale | Terzo occhio | +2 Intelligenza permanente |
| Carisma | Insegna al neon | Bioluminescenza / cresta | +2 Carisma permanente |

Dati: cond= robot & scelta:forza ; reward= forza+2, sprite:servobraccia
Dati: cond= robot & scelta:velocita ; reward= velocita+2, sprite:turbina
Dati: cond= robot & scelta:int ; reward= int+2, sprite:antenna
Dati: cond= robot & scelta:carisma ; reward= carisma+2, sprite:neon
Dati: cond= alieno & scelta:forza ; reward= forza+2, sprite:chele
Dati: cond= alieno & scelta:velocita ; reward= velocita+2, sprite:pinne
Dati: cond= alieno & scelta:int ; reward= int+2, sprite:terzocchio
Dati: cond= alieno & scelta:carisma ; reward= carisma+2, sprite:biolum
Testo: "Being a teenager has its perks: someone — a mechanic with a slightly too-eager grin, or a technician from the molting clinic — waves you inside. For ten coins, you can walk out of here... upgraded. Take your time choosing: whatever you pick, you're keeping it forever."
Scena: [DEDICATA] pet sul lettino/rialzo dell'officina-clinica, il tecnico che mostra le opzioni; servono 8 varianti sprite d'esito (una per impianto/mutazione, permanente sul pet)

## Missione 18: The Heist of the Century
Brief: The World's Biggest Sandwich sits in the downtown vault, guarded like a national treasure — the heist of the century starts now.
- Luogo: 📍 The Sandwich Vault (Downtown)
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: qualsiasi (conta la più alta)
- Tag: rapina
- Durata: 1h30
- Costo: gratis
- Nota: la "boss" dell'infornata; modello a SOGLIA teen — qui si può FALLIRE davvero (serve una stat a 10+ per riuscire)
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=qualsiasi ; tag=rapina ; stadio=teen

**Standard** (riesci nel colpo, con almeno una stat a 10+) — +25 monete, Panino Più Grande del Mondo (arredo cucina, +2 Felicità passivo), Scorta di Panini (cibo multi-porzione: 5 porzioni, ogni porzione +2 a una stat RPG casuale), Felicità +5
Dati: reward= monete+25, arredo:Panino Più Grande del Mondo, cibo:Scorta di Panini, fel+5
Testo: "The World's Biggest Sandwich is on display in the downtown vault, guarded like a national treasure. You sneak in, handle the alarms your own way, and stroll out with it in front of everyone. Dinner is sorted for a month."
Scena: pet che sguscia via da un caveau con un panino gigantesco in spalla

**Fallimento** (condizione: nessuna stat a 10+) — −10 monete (multa), Fetta di Panino Gigante (cibo, +2 a una stat casuale, 1 porzione)
Dati: cond= statMax<10 ; reward= monete-10, cibo:Fetta di Panino Gigante
Testo: "The plan was flawless on paper. In practice, the alarm goes off on step one and you end up explaining yourself to two guards. You pay the fine — but they're more amused than angry, and they send you off with a chunk of sandwich 'for the effort'."
Scena: pet ammanettato bonariamente da due guardie, una fetta di panino in mano

**Super successo** (condizione: qualsiasi stat a 13+) — reward normali + Completo da Chef (indossabile: mentre indossato, ogni primo pasto di categoria del giorno dà +1 stat extra) + +40 monete, Felicità +10
Dati: priorita=2 ; cond= statMax>=13 ; reward= monete+40, arredo:Panino Più Grande del Mondo, cibo:Scorta di Panini, indossabile:Completo da Chef, fel+10
Testo: "You don't just take the sandwich: you do it with such style that you also find the owner's chef outfit in the vault — and pocket that too. No one will ever figure out how you pulled it off."
Scena: [DEDICATA] pet che esce dal caveau col panino gigante E indossando un completo da chef, occhiolino

**Super successo** (condizione: Maleducato + talento Boss di Quartiere + qualsiasi stat a 13+) — tutto il super + perk GTB "Gran Theft Burger" (tag rapina: niente fallimento + sempre super successo nelle missioni tag rapina), Felicità +10
Dati: priorita=1 ; cond= maleducato & talento:bossdiquartiere & statMax>=13 ; reward= monete+40, arredo:Panino Più Grande del Mondo, cibo:Scorta di Panini, indossabile:Completo da Chef, perk:gtb, fel+10
Testo: "This isn't a heist, it's ART. In, out, leaving nothing behind but legend and crumbs. The neighborhood has a new king of gastronomic crime."
Scena: [DEDICATA] pet incoronato "re del crimine" dagli altri teppisti, panino gigante come trofeo

Priorità M18: il super Maleducato+Boss di Quartiere (più specifico) prima del super generico. Il super batte sempre il fallimento. (Nota: "super" e "grande successo" sono lo stesso tier.)

## Missione 19: Intergalactic Talent Show
Brief: Step onto the Intergalactic Talent Show stage, in front of a jury of aliens and robots who've already seen it all.
- Luogo: 📍 Intergalactic Talent Show Stage
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: gara
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=gara ; stadio=teen

**Standard** (buona performance) — +2 Carisma, Parrucchino di Elvis (indossabile, +2 Carisma mentre indossato), +15 monete, Felicità +5
Dati: reward= carisma+2, indossabile:Parrucchino di Elvis, monete+15, fel+5
Testo: "You take the stage before a jury of aliens and robots who look like they've seen it all. You do your act, earn some honest applause, and score a prize: an Elvis-style wig that — let's be real — suits you a LOT."
Scena: pet sul palco sotto i riflettori, giuria che applaude, parrucchino in mano

**Fallimento** (condizione: Maleducato, oppure Carisma ≤7) — Torta intera (cibo, Carisma+3)
Dati: cond= maleducato | carisma<=7 ; reward= cibo:Torta intera
Testo: "The stage is not your friend today: a bum note here, a blunder there, and the jury watches you the way people watch a car crash. You finish dead last, but someone in the audience takes pity and sends a whole cake backstage for you."
Scena: pet mortificato sul palco, ortaggi virtuali che volano, una torta di consolazione

**Super successo** (condizione: Carisma 12+, oppure Sportivo + talento Spirito Agonistico) — reward base + +30 monete + Disco d'Oro (arredo, +2 Carisma passivo), Felicità +10
Dati: cond= carisma>=12 | (sportivo & talento:spiritoagonistico) ; reward= carisma+2, indossabile:Parrucchino di Elvis, monete+30, arredo:Disco d'Oro, fel+10
Testo: "That's not a performance, it's a PHENOMENON. The jury leaps to its feet, the crowd loses its mind, and they hand you a gold record on the spot. A star is born."
Scena: [DEDICATA] pet trionfante col parrucchino e un disco d'oro sopra la testa, pioggia di stelle filanti

## Missione 20: Kaiju Defense
Brief: A beast the size of an office block is tearing downtown apart — the neighborhood needs a hero, and today that's you.
- Luogo: 📍 Neighborhood Under Attack
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: mostro
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=mostro ; stadio=teen

Le 5 armi epiche (nomi generici, no marchi; drop casuale nello standard, set completo nel super): Spadone, Martellone, Doppie Lame, Arco Pesante, Alabarda — arredo, +2 Forza ciascuna.

**Standard** (sconfiggi il mostro) — +3 Forza, 1 arma casuale (delle 5, +2 Forza), Felicità +5
Dati: reward= forza+3, armaCasualeKaiju, fel+5
Testo: "A beast the size of an office block is causing panic downtown. You dive in, dodge paws the size of cars, and drive it back blow by blow. In the rubble it leaves behind, you salvage one seriously fine weapon."
Scena: pet minuscolo in posa di sfida davanti a un kaiju gigante, un'arma epica in pugno

**Fallimento** (condizione: Forza ≤7) — Bistecca (cibo, Forza+2)
Dati: cond= forza<=7 ; reward= cibo:Bistecca
Testo: "Saying you'll fight a monster is one thing. Standing in front of an ACTUAL sixty-foot one is another. Your legs make the decision for you, and you run. The locals, grateful for the attempt anyway, feed you one truly heroic steak."
Scena: pet che scappa a gambe levate dall'ombra enorme del kaiju, cittadini che gli offrono cibo

**Super successo** (condizione: Forza 13+, oppure perk Cacciatore di Mostri) — +4 Forza, tutte e 5 le armi, perk Cacciatore di Mostri (tag mostro: niente fallimento + sempre super successo nelle missioni tag mostro), Felicità +10
Dati: cond= forza>=13 ; reward= forza+4, tutteArmiKaiju, perk:cacciatoremostri, fel+10
Testo: "You face it head-on and take it down in a duel destined for neighborhood legend. You walk away with the entire arsenal and the title of Monster Hunter."
Scena: [DEDICATA] pet trionfante sul kaiju abbattuto, tutte e 5 le armi addosso, folla in delirio

## Missione 21: Doctor Enigma's Escape Room
Brief: Locked in a room of padlocks and cryptic clues while the timer ticks down, Doctor Enigma watches from a screen, smirking.
- Luogo: 📍 Doctor Enigma's Escape Room
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: invenzione
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; tag=invenzione ; stadio=teen

**Standard** — +2 Int, +15 monete, Camice del Dottore (indossabile, +1 Int), Felicità +5
Dati: reward= int+2, monete+15, indossabile:Camice del Dottore, fel+5
Testo: "You're locked in a room full of padlocks, cryptic clues and a timer ticking menacingly. Doctor Enigma watches you from a screen, smirking. You crack puzzle after puzzle and swing the door open with time still on the clock — you walk out with your brain on fire and the lab coat the Doctor, being a good sport, hands over as a prize."
Scena: pet chino su un lucchetto a combinazione, indizi appesi, timer rosso sullo sfondo

**Fallimento** (condizione: Intelligenza ≤7) — Zuppa di verdure (cibo, Int+2)
Dati: cond= int<=7 ; reward= cibo:Zuppa di verdure
Testo: "The puzzles stare at you, you stare at the puzzles, and nothing happens for a solid hour. Doctor Enigma, almost feeling sorry for you, opens the door himself, shaking his head, and hands you a soup 'for the brain — you clearly need it'."
Scena: pet perplesso davanti a un muro di enigmi, il Dottore che apre la porta scuotendo la testa

**Super successo** (condizione: Intelligenza 13+, oppure Nerd + talento Mente Analitica) — +3 Int, +15 monete, Camice del Dottore (indossabile), Specchio del Dottor Enigma (arredo bagno, +1 Int), Felicità +10
Dati: cond= int>=13 | (nerd & talento:menteanalitica) ; reward= int+3, monete+15, indossabile:Camice del Dottore, arredo:Specchio del Dottor Enigma, fel+10
Testo: "You don't solve the room — you DISMANTLE it. Puzzles devoured in half the time, and while Doctor Enigma stammers in disbelief, you're already outside. He even hands you the mirror with his big smug face on it, as a trophy of his defeat."
Scena: [DEDICATA] pet che esce dalla porta a braccia alzate col camice, specchio-faccione sotto il braccio, Dottore sbigottito

## Missione 22: Lawyer for a Day
Brief: A robot's on trial for draining the building's Wi-Fi, and somebody has to be its lawyer in front of a robot judge. That's you.
- Luogo: 📍 City Courthouse
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Intelligenza + Carisma (doppia)
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sociale ; stat=int,carisma ; stadio=teen

**Standard** — +1 Int, +1 Carisma, Toga da Avvocato (indossabile, +2 Carisma +1 Int), Felicità +5
Dati: reward= int+1, carisma+1, indossabile:Toga da Avvocato, fel+5
Testo: "In court, you defend a robot accused of draining the whole building's Wi-Fi. Between a legal loophole and a well-placed one-liner, you scrape out half a verdict and the regulation robe. Not a triumph, but your client dodges the scrapyard."
Scena: pet in toga davanti a un giudice-robot, cliente-robottino al banco

**Fallimento** (condizione: Intelligenza ≤7 E Carisma ≤7) — Insalatona (cibo, Int+1), Biscotto (cibo, Carisma+1)
Dati: cond= int<=7 & carisma<=7 ; reward= cibo:Insalatona, cibo:Biscotto
Testo: "Your closing argument starts badly and ends worse: you trip over your words, the judge yawns, your client covers his metal eyes. Acquitted out of pity, not merit. The judge still sends you off to eat something 'before your next disaster'."
Scena: pet impappinato, giudice che sbadiglia, cliente che si copre gli occhi

**Super successo** (condizione: Intelligenza 9+ E Carisma 9+, oppure Maleducato + talento Faccia di Bronzo con Carisma o Int ≥5) — +2 Int, +2 Carisma, Toga da Avvocato (indossabile), Martelletto da Giudice (arredo salone, +2 Int +1 Carisma), Felicità +10
Dati: cond= (int>=9 & carisma>=9) | (maleducato & talento:facciadibronzo & (carisma>=5 | int>=5)) ; reward= int+2, carisma+2, indossabile:Toga da Avvocato, arredo:Martelletto da Giudice, fel+10
Testo: "A textbook closing argument: loopholes, plot twists, a witness breaking down in oily tears. The jury goes wild, the judge gifts you his gavel, and the robot walks out with its head held high — and the whole neighborhood back online."
Scena: [DEDICATA] pet trionfante in toga col martelletto in mano, giuria in piedi, cliente libero

## Missione 23: The Forger
Brief: The Civic Museum calls you in for a delicate verdict: under the UV lights, is that painting the real deal, or fresh paint?
- Luogo: 📍 Civic Museum
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; stadio=teen

**Standard** — +2 Int, +15 monete, Dipinto Artistico (arredo salone, +1 Int +1 Felicità), Felicità +5
Dati: reward= int+2, monete+15, arredo:Dipinto Artistico, fel+5
Testo: "The museum calls you in for an expert opinion: is that painting the real deal or a knock-off? With lenses, UV lights and a whole lot of patience, you deliver your verdict — and it turns out you're right. They pay you well and throw in an original canvas for your trouble."
Scena: pet con lente e luce UV che esamina un quadro, cartello "MUSEO"

**Fallimento** (condizione: Intelligenza ≤7) — Zuppa di verdure (cibo, Int+2), Dipinto Falso (arredo salone, +1 Velocità +1 Felicità)
Dati: cond= int<=7 ; reward= cibo:Zuppa di verdure, arredo:Dipinto Falso
Testo: "You stare at the painting for hours, and the longer you look, the less you get it. In the end you take a wild guess... and blow it. The museum thanks you through gritted teeth and sends you off with a meal and — oh, the irony — the very fake you failed to spot."
Scena: pet grattacapo davanti a due quadri identici, un curatore contrariato

**Super successo** (condizione: Maleducato + talento Cleptomane) — +3 Int, +30 monete, Dipinto Artistico, Lente d'Ingrandimento (arredo salone, +2 Int), Dipinto Rubato (arredo salone, +2 Int, alto valore di rivendita), Felicità +10
Dati: priorita=1 ; cond= maleducato & talento:cleptomane ; reward= int+3, monete+30, arredo:Dipinto Artistico, arredo:Lente d'Ingrandimento, arredo:Dipinto Rubato, fel+10
Testo: "You expose the fake with class... and while you're at it, in all the commotion, a second painting 'falls off the wall and follows you home'. Nobody notices a thing. Double haul."
Scena: [DEDICATA] pet che si allontana fischiettando con due quadri sottobraccio, sala del museo dietro

**Super successo** (condizione: Intelligenza 13+) — +3 Int, +30 monete, Dipinto Artistico, Lente d'Ingrandimento (arredo salone, +2 Int), Felicità +10
Dati: priorita=2 ; cond= int>=13 ; reward= int+3, monete+30, arredo:Dipinto Artistico, arredo:Lente d'Ingrandimento, fel+10
Testo: "You don't just expose the fake: you reconstruct WHO painted it, WHEN and WHY, in front of a slack-jawed museum director. They shower you with coins and gift you the genuine canvas, plus your new lucky magnifying glass."
Scena: [DEDICATA] pet che indica trionfante un quadro smascherato, direttore a bocca aperta, monete che volano

## Missione 24: Midnight Race at the Museum
Brief: Past midnight the Civic Museum empties of guards and fills with underground racers ready to tear past the statues.
- Luogo: 📍 Civic Museum (at night)
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara, inseguimento
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sport ; stat=velocita ; tag=gara,inseguimento ; stadio=teen

**Standard** — +2 Velocità, Scarpe da Corsa (arredo, +1 Velocità), Felicità +5
Dati: reward= velocita+2, arredo:Scarpe da Corsa, fel+5
Testo: "When night falls, the museum sheds its skin: lights off, traffic cones between the columns, and a small pack of underground racers waiting for the start. A whispered countdown kicks things off and you're straight into the scrum, streaking past statues and centuries-old paintings while the guard on duty snores blissfully in his booth. You're not the lightning bolt of the evening, but you keep a clean pace and finish mid-pack without knocking over a single Etruscan vase. At the finish line you pick up a pair of running shoes somebody lost in the getaway: they're yours now."
Scena: pet che corre tra le teche del museo al buio, altri corridori sfocati

**Fallimento** (condizione: Velocità ≤7, oppure Maleducato + talento Bad Loser) — Sushi (cibo, Velocità+2)
Dati: cond= velocita<=7 | (maleducato & talento:badloser) ; reward= cibo:Sushi
Testo: "You start out fired up, but your legs don't get the memo — or maybe it's that you trip the first racer who overtakes you and get disqualified on the spot. The other runners, half amused, half sympathetic, treat you to some sushi."
Scena: pet col fiatone o che litiga con un corridore, gli altri che sfrecciano via

**Super successo** (condizione: Gentile + talento Cuore Magnetico) — +3 Velocità, Scarpe da Corsa, Coppa del Vincitore (arredo, +2 Velocità +1 Carisma), +30 monete, Felicità +10
Dati: priorita=1 ; cond= gentile & talento:cuoremagnetico ; reward= velocita+3, arredo:Scarpe da Corsa, arredo:Coppa del Vincitore, monete+30, fel+10
Testo: "You run like a dream, but the truly absurd part is the night guard: instead of stopping you, he just stands there watching, mouth open — and at the finish he even slips you a tip 'for the show'."
Scena: [DEDICATA] pet che taglia il traguardo mentre la guardia ammaliata applaude e gli porge monete

**Super successo** (condizione: Velocità 13+) — +3 Velocità, Scarpe da Corsa, Coppa del Vincitore (arredo, +2 Velocità +1 Carisma), Felicità +10
Dati: priorita=2 ; cond= velocita>=13 ; reward= velocita+3, arredo:Scarpe da Corsa, arredo:Coppa del Vincitore, fel+10
Testo: "At some point you stop running and start flying low: you streak through the halls grazing the display cases without ever touching them, read every corner before it comes, and pass the others like they're standing still. Nobody sees you start, nobody sees you finish — you cross the underground finish line with an embarrassing lead, first overall and without a single scratch on the artwork. You pocket the (strictly unofficial) winner's cup and vanish into the dark corridors before the sun comes up, or before anyone thinks to ask who on earth you were."
Scena: [DEDICATA] pet primo al traguardo con la coppa, sale del museo sfrecciate alle spalle

## Missione 25: FPS Tournament at the Arcade
Brief: The 'Bit & Byte' Arcade turns esports arena: headsets blasting, voice chat on fire, a shooter tournament kicking off.
- Luogo: 📍 "Bit & Byte" Arcade
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Velocità
- Tag: gara
- Durata: 1h
- Costo: 3 monete
- Dati: durata=1h ; costo=3 ; categoria=videogioco ; stat=velocita ; tag=gara ; stadio=teen

**Standard** — +2 Velocità, Console (arredo camera, +2 Velocità +1 Felicità), Felicità +5
Dati: reward= velocita+2, arredo:Console, fel+5
Testo: "The arcade turns into an esports arena: giant screens, headphones cranked to absurd volumes, and a voice chat alternating between dead-serious strategy and affectionate insults. You dive into the shooter tournament and hold your own, between lucky headshots and a few embarrassing deaths, finishing just off the podium. Not the grand final of your dreams, but you walk out with aching thumbs, adrenaline through the roof, and a console of your very own to set up in your room."
Scena: pet con cuffie e joystick davanti a uno schermo FPS, altri giocatori ai lati

**Fallimento** (condizione: Maleducato + talento Bad Loser) — −5 monete (danni), Sushi (cibo, Velocità+2)
Dati: priorita=1 ; cond= maleducato & talento:badloser ; reward= monete-5, cibo:Sushi
Testo: "You lose the first firefight and, instead of shaking hands, you smash the joystick against the cabinet. The manager hands you the bill for the damages. All you've got left is some consolation sushi."
Scena: pet infuriato che spacca un joystick, il gestore che indica il cartello dei prezzi

**Fallimento** (condizione: Velocità ≤7) — Sushi (cibo, Velocità+2)
Dati: priorita=2 ; cond= velocita<=7 ; reward= cibo:Sushi
Testo: "Your reflexes are on vacation today: eliminated in round one, zero glory. A kind opponent offers you sushi 'for next time'."
Scena: pet abbattuto davanti a uno schermo "ELIMINATO", avversario che gli passa del cibo

**Super successo** (condizione: Velocità 13+, oppure Nerd) — +3 Velocità, Console, perk Weapon Wielder (sblocca la capacità di equipaggiare armi nelle missioni), Felicità +10
Dati: cond= velocita>=13 | nerd ; reward= velocita+3, arredo:Console, perk:weaponwielder, fel+10
Testo: "At some point something clicks: you're not playing anymore, you're DOMINATING. Headshot after headshot, surgical aim, inhuman reflexes — the scoreboard becomes a list of your victims, and the voice chat, usually deafening, falls into reverent silence. You lift the pro console above your head like a trophy, and from that day on, word spreads that you REALLY know your way around a weapon — even outside the screen."
Scena: [DEDICATA] pet trionfante con la console pro sopra la testa, tabellone "VICTORY", folla in delirio

## Missione 26: Catch the Cyborg Pigeon
Brief: A cyborg pigeon obsessed with shiny things is looting the neighborhood in flashes: somebody's got to chase it across the rooftops.
- Luogo: 📍 Neighborhood Rooftops
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: inseguimento
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=inseguimento,companion ; stadio=teen

**Standard** — +2 Velocità, Gabbia per Uccelli (arredo mettibile ovunque, +1 Velocità +1 Felicità), Felicità +5
Dati: reward= velocita+2, arredo:Gabbia per Uccelli, fel+5
Testo: "A cyborg pigeon with a thing for shiny objects is terrorizing the neighborhood: it vanishes with keys, coins and a pair of sunglasses before you can even say 'hey!'. You give chase through courtyards, gutters and clotheslines, with dives and slides the neighbors commentate from their windows like it's the big match. After half an hour of acrobatics you corner it, and as a bonus you keep the little cage someone conveniently left right there."
Scena: pet che insegue un piccione robotico tra i panni stesi e le grondaie

**Fallimento** (condizione: Nerd + talento Topo di Biblioteca) — +1 Int, Pesce alla griglia (cibo, Velocità+1)
Dati: priorita=1 ; cond= nerd & talento:topodibiblioteca ; reward= int+1, cibo:Pesce alla griglia
Testo: "Halfway through the chase you stop: 'wait, why am I chasing a pigeon?'. You head home, open a book on robotic ornithology and actually learn something. The pigeon, meanwhile, sends its regards."
Scena: pet seduto che legge un libro mentre il piccione gli fa la linguaccia dalla finestra

**Fallimento** (condizione: Velocità ≤7) — Sushi (cibo, Velocità+2)
Dati: priorita=2 ; cond= velocita<=7 ; reward= cibo:Sushi
Testo: "That feathered brute is quicker than it looks: it loses you in three turns. The neighbors, disappointed but understanding, offer you something to eat."
Scena: pet col fiatone su un tetto, il piccione ormai lontano nel cielo

**Super successo** (condizione: Velocità 13+, oppure Gentile + talento Amante della Natura) — +3 Velocità, Gabbia per Uccelli, Piccione Cyborg (arredo companion, +2 Velocità fisso), Felicità +10
Dati: cond= velocita>=13 | (gentile & talento:amantedellanatura) ; reward= velocita+3, arredo:Gabbia per Uccelli, arredo:Piccione Cyborg, fel+10
Testo: "You chase it leaping rooftop to rooftop with dizzying agility, predicting every swerve like you're reading its processor (or, if you're the sweet type, you just talk to it softly until it decides to turn itself in). In the end the feathered little punk looks at you, weighs its options, and picks you: from that moment on, it flutters along wherever you go. Keep it in its cage, on proud display — a companion that, apparently, even passes a bit of its speed on to you."
Scena: [DEDICATA] pet che stringe felice il piccione cyborg, entrambi su un tetto al tramonto

## Missione 27: Wrestling Show
Brief: You climb into the Wrestling Arena ring, masked, stage name screamed by the announcer, facing padded man-mountains who mean business.
- Luogo: 📍 Wrestling Arena
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza ; stadio=teen

**Standard** — +2 Forza, −8 Salute (Ferite +8), Maschera da Wrestler (indossabile, +2 Forza +1 Carisma), Felicità +5
Dati: reward= forza+2, ferite+8, indossabile:Maschera da Wrestler, fel+5
Testo: "You climb into the arena ring wearing a mask, with a stage name screamed by the announcer. Against padded man-mountains you take suplexes and dish them right back: the crowd goes wild and you win your first match (and a few bruises)."
Scena: pet mascherato che esegue una mossa da wrestling su un avversario gigante, folla sugli spalti

**Fallimento** (condizione: Gentile + talento Coccolone) — Ferite +15, Bistecca (cibo, Forza+2)
Dati: priorita=1 ; cond= gentile & talento:coccolone ; reward= ferite+15, cibo:Bistecca
Testo: "You try cuddling your opponents instead of fighting them. They don't get it, you take twice the beating, and you end the night in more pieces than planned. But with a lovely consolation steak."
Scena: pet malconcio che tende le braccia per un abbraccio verso un wrestler perplesso

**Fallimento** (condizione: Forza ≤7) — Ferite +15, Bistecca (cibo, Forza+2)
Dati: priorita=2 ; cond= forza<=7 ; reward= ferite+15, cibo:Bistecca
Testo: "Tonight's man-mountain uses you as a doormat: pinned in ten seconds, you leave the ring more dented than glorious. At ringside, someone hands you a steak — 'for the black eye or for dinner, your call'."
Scena: pet steso al tappeto con l'arbitro che conta, avversario esultante

**Super successo** (condizione: Forza 13+, oppure Nerd + talento Cervellone) — +3 Forza, −5 Salute (Ferite +5), Maschera da Wrestler, Poster del Campione (arredo camera, +1 Forza +1 Carisma), Felicità +10
Dati: cond= forza>=13 | (nerd & talento:cervellone) ; reward= forza+3, ferite+5, indossabile:Maschera da Wrestler, arredo:Poster del Campione, fel+10
Testo: "It's not a match, it's a SHOW: spectacular moves, a battle cry (featuring that word they taught you) that freezes the whole arena, and your opponent flat on the mat in a flash. Champion — mask and commemorative poster included."
Scena: [DEDICATA] pet mascherato in posa di trionfo sul ring, cintura al fianco, folla in delirio

## Missione 28: The Scrap Invasion
Brief: A horde of tin-can, cable-wired little monsters is swarming out of the City Dump into the neighborhood: someone's got to stop them.
- Luogo: 📍 City Dump
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: mostro, studio
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=mostro,studio ; stadio=teen

**Standard** — +2 Forza, −12 Salute (Ferite +12), +15 monete, Pupazzo Mostriciattolo (arredo camera, +1 Forza +1 Int), Felicità +5
Dati: reward= forza+2, ferite+12, monete+15, arredo:Pupazzo Mostriciattolo, fel+5
Testo: "A horde of little monsters made of cans, cables and garbage invades the neighborhood. You smash them to bits while trying to figure out WHERE they're coming from: you pick up a few scratches, but come home with a trophy plushie and a full pocket."
Scena: pet che mena fendenti contro creaturine di spazzatura, quartiere sullo sfondo

**Fallimento** (condizione: Maleducato + talento Bad Loser) — Bistecca (cibo, Forza+2) (se ne va senza un graffio)
Dati: priorita=1 ; cond= maleducato & talento:badloser ; reward= cibo:Bistecca
Testo: "The mere idea of losing to actual GARBAGE short-circuits you: you drop everything and storm off huffing, without a scratch — but also without glory."
Scena: pet che si allontana a braccia conserte mentre i mostriciattoli lo inseguono goffi

**Fallimento** (condizione: Forza ≤7) — Ferite +12, +5 monete, Bistecca (cibo, Forza+2)
Dati: priorita=2 ; cond= forza<=7 ; reward= ferite+12, monete+5, cibo:Bistecca
Testo: "There are too many of them and not enough of you: they swarm you, and you get back up dented, with a few coins in your pocket. A neighbor patches you up with a steak."
Scena: pet sepolto sotto una montagna di mostriciattoli, una mano che spunta

**Super successo** (condizione: Forza 13+; auto anche con perk Doc Brown [tag studio] o Cacciatore di Mostri [tag mostro]) — +3 Forza, −6 Salute (Ferite +6), +25 monete, Pupazzo Mostriciattolo, Pistola Spara-Spazzatura (arma equipaggiabile, +4 Forza −2 Carisma; serve il perk Weapon Wielder), Felicità +10
Dati: cond= forza>=13 ; reward= forza+3, ferite+6, monete+25, arredo:Pupazzo Mostriciattolo, arma:Pistola Spara-Spazzatura, fel+10
Testo: "You sweep them away like crumbs, then follow the trail upstream to the BOSS — a giant landfill monster — and take it apart piece by piece. In the wreckage you find a garbage-blaster pistol: ugly, but devastating."
Scena: [DEDICATA] pet vittorioso sul boss-discarica smontato, pistola spara-spazzatura in pugno

## Missione 29: Test Your Strength at the Funfair
Brief: At the Funfair, the classic strongman hammer game is waiting for your swing: puck, tower, bell, and every eye on you.
- Luogo: 📍 Funfair
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Forza
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sport ; stat=forza ; stadio=teen

**Standard** — +2 Forza, +1 Carisma, Adesivo Martello (arredo cucina, +1 Forza), Felicità +5
Dati: reward= forza+2, carisma+1, arredo:Adesivo Martello, fel+5
Testo: "The funfair has the classic strongman game: swing the hammer, the puck goes up, the bell rings. You land a solid whack, reach halfway up the tower, and earn a round of applause plus a souvenir sticker for the fridge."
Scena: pet che cala un martellone su una pedana, la pallina a metà colonna, folla curiosa

**Fallimento** (condizione: Gentile + talento Amante della Natura) — +1 Carisma, Bistecca (cibo, Forza+2), Peluche Luna Park (arredo bagno, +1 Carisma)
Dati: priorita=1 ; cond= gentile & talento:amantedellanatura ; reward= carisma+1, cibo:Bistecca, arredo:Peluche Luna Park
Testo: "You raise the wooden hammer and... no, you just can't bring yourself to hit it, poor little thing. You refuse with dignity. The operator, touched, gives you a plushie and something to eat anyway."
Scena: pet che accarezza il martello di legno invece di usarlo, gestore che ride

**Fallimento** (condizione: Forza ≤7) — Bistecca (cibo, Forza+2), Peluche Luna Park (arredo bagno, +1 Carisma)
Dati: priorita=2 ; cond= forza<=7 ; reward= cibo:Bistecca, arredo:Peluche Luna Park
Testo: "The puck rises... a whole inch. The operator stifles a laugh and consoles you with some food and a plushie 'so you don't cry'."
Scena: pet deluso davanti alla pallina fermissima in basso, gestore che porge un peluche

**Super successo** (condizione: Forza 13+, oppure Nerd + talento Inventore) — +3 Forza, +30 monete, Martello Vero (arredo salone, +3 Forza), Felicità +10
Dati: cond= forza>=13 | (nerd & talento:inventore) ; reward= forza+3, monete+30, arredo:Martello Vero, fel+10
Testo: "COSMIC WHACK: the puck smashes through the bell and possibly the sky. (Or, if you're the inventive type, you build a mechanical hammer that sets the record all by itself.) You win a prize in coins, plus a real full-size hammer of your very own."
Scena: [DEDICATA] pet trionfante mentre la campana esplode in cima alla colonna, martellone in spalla

## Missione 30: Influencer for a Day
Brief: One day as an influencer: cameras rolling, a profile ready to blow up, and the haters already lurking in the comments.
- Luogo: 📍 Social Media Studio
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=teen

**Standard** — +2 Carisma, +15 monete (donazioni), Felicità +5
Dati: reward= carisma+2, monete+15, fel+5
Testo: "Your social profile blows up overnight. Between a solid post and a few haters to ignore, you ride the wave with decent class and cash in your first follower donations."
Scena: pet che si fa un selfie con lo sfondo di cuori e like che salgono

**Fallimento** (condizione: Sportivo + talento Predestinato) — Torta intera (cibo, Carisma+3), +3 monete
Dati: priorita=1 ; cond= sportivo & talento:predestinato ; reward= cibo:Torta intera, monete+3
Testo: "It all went to your head: 'I'm a STAR, me.' The first hater sets you off live on stream, and you lose half your followers in a minute. All that's left is a couple of donations and a consolation cake."
Scena: pet imbufalito che urla contro lo schermo del telefono, il contatore follower che crolla

**Fallimento** (condizione: Carisma ≤7) — Abbuffata in Diretta (cibo multi-porzione ×5, +2 stat casuale a morso), +3 monete
Dati: priorita=2 ; cond= carisma<=7 ; reward= cibo:Abbuffata in Diretta, monete+3
Testo: "One unfortunate post, one even worse reply, and the comment section turns into a pile-on. So you do the one thing that never fails online: you go live and start EATING. Five courses, zero words, thousands of hypnotized viewers. You didn't save your reputation, but the pantry is full and somebody even donated."
Scena: pet mogio che fissa un telefono pieno di commenti arrabbiati

**Super successo** (condizione: Carisma 13+, oppure Sportivo + talento Fisico Bestiale) — +3 Carisma, +40 monete, Laptop (arredo salone, +2 Carisma), perk Influencer (tag social: niente fallimento + sempre super successo nelle missioni tag social), Felicità +10
Dati: cond= carisma>=13 | (sportivo & talento:fisicobestiale) ; reward= carisma+3, monete+40, arredo:Laptop, perk:influencer, fel+10
Testo: "You go viral the right way: millions of hearts, haters silenced by pure charisma (or pure biceps), and sponsors fighting over you. You score a pro laptop and genuine influencer fame."
Scena: [DEDICATA] pet raggiante circondato da schermi con milioni di like, un laptop pro tra le mani

## Missione 31: Save the Wedding
Brief: You're a guest at a wedding collapsing in real time: the cake's wobbling, the newlyweds are at war, and nobody's stepping in.
- Luogo: 📍 Reception Hall
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; stadio=teen

**Standard** — +2 Carisma, Torta Nuziale (cibo, Carisma+2), Felicità +5
Dati: reward= carisma+2, cibo:Torta Nuziale, fel+5
Testo: "You're a guest, and the wedding is going off the rails: the cake is wobbling, the newlyweds are squabbling. With a few right words you pick up the pieces and get the party going again. You even land a nice slice of wedding cake."
Scena: pet che media tra due sposi imbronciati, torta nuziale traballante sullo sfondo

**Fallimento** (condizione: Sportivo + talento Fissato con la Dieta) — Spiedino (cibo, Forza+1)
Dati: priorita=1 ; cond= sportivo & talento:fissatoconladieta ; reward= cibo:Spiedino
Testo: "The chaos doesn't touch you: you're too busy NOT touching the cake ('it's pure sugar!'). You fix nothing, but you do leave with something healthy to eat."
Scena: pet che scansa con orrore un vassoio di torta, cercando qualcosa di più sano

**Fallimento** (condizione: Carisma ≤7) — Biscotto (cibo, Carisma+1)
Dati: priorita=2 ; cond= carisma<=7 ; reward= cibo:Biscotto
Testo: "You try to mediate and make everything worse: the cake collapses, the newlyweds argue even louder. You slink away in embarrassment, salvaging just one little treat from the buffet."
Scena: pet imbarazzato che si defila mentre la torta nuziale crolla dietro di lui

**Super successo** (condizione: Carisma 13+, oppure Gentile + talento Pacifista) — +3 Carisma, Torta Nuziale, Bouquet da Sposa (indossabile, +1 Carisma), Felicità +10
Dati: cond= carisma>=13 | (gentile & talento:pacifista) ; reward= carisma+3, cibo:Torta Nuziale, indossabile:Bouquet da Sposa, fel+10
Testo: "With textbook sweetness you make peace between the newlyweds, save the cake at the very last second, and turn the disaster into the wedding of the year. The couple, moved to tears, toss you the bouquet."
Scena: [DEDICATA] pet che afferra al volo il bouquet mentre gli sposi si baciano felici, coriandoli

## Missione 32: Karaoke
Brief: Karaoke night at the neighborhood bar: little stage, mic already hot, and every eye — and ear — on you.
- Luogo: 📍 Karaoke Bar
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: musica, social
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=musica,social ; stadio=teen

**Standard** — +2 Carisma, Microfono da Cantante (indossabile, +2 Carisma), Felicità +5
Dati: reward= carisma+2, indossabile:Microfono da Cantante, fel+5
Testo: "Karaoke night with the neighborhood pets. You hop on the little stage, grab the mic and sing — not brilliantly, but with an energy that infects the whole room. The bar gifts you the microphone 'for next time'."
Scena: pet che canta al microfono sul palchetto, testo della canzone su uno schermo dietro

**Fallimento** (condizione: Maleducato + talento Cleptomane) — Torta intera (cibo, Carisma+3)
Dati: priorita=1 ; cond= maleducato & talento:cleptomane ; reward= cibo:Torta intera
Testo: "Instead of singing, you try 'borrowing' a few coins from the tables. You get caught and booed out the door. All you're left with is a cake snatched on the way out."
Scena: pet trascinato fuori dai buttafuori con un dolce e qualche moneta in mano

**Fallimento** (condizione: Carisma ≤7) — Torta intera (cibo, Carisma+3)
Dati: priorita=2 ; cond= carisma<=7 ; reward= cibo:Torta intera
Testo: "Bum note after bum note, the audience covers its ears. You leave the stage to pity applause. Someone offers you a cake to help wash down the shame."
Scena: pet mortificato al microfono, pubblico che si copre le orecchie

**Super successo** (condizione: Carisma 13+, oppure talento Faccia di Bronzo; auto anche col perk Influencer [tag social]) — +3 Carisma, Microfono da Cantante, perk Singer (tag musica: niente fallimento + sempre super successo nelle missioni tag musica), Felicità +10
Dati: cond= carisma>=13 | talento:facciadibronzo ; reward= carisma+3, indossabile:Microfono da Cantante, perk:singer, fel+10
Testo: "Whether you sing like an angel or you're completely tone-deaf but utterly shameless, you win the crowd: singalongs, lighters in the air, encore after encore. You become a karaoke legend — microphone and singer fame included."
Scena: [DEDICATA] pet star sul palco col microfono, pubblico in delirio con le luci alzate

---

## Missione 81: Arm Wrestling at the Docks
Brief: Down at the dockside tavern, arm wrestling is religion: dockworkers, sailors, and a table ready to groan.
- Luogo: 📍 Dockside Tavern
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: gara
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=combattimento ; stat=forza ; tag=gara ; stadio=teen

**Standard** — +2 Forza, +20 monete, Felicità +5
Dati: reward= forza+2, monete+20, fel+5
Testo: "At the dockside tavern, arm wrestling is religion: dockworkers, sailors, and a table that's seen more elbows than glasses. You win some rounds, lose others, and earn the night's respect (and paycheck)."
Scena: pet a un tavolo di taverna gomito a gomito con uno scaricatore enorme

**Fallimento** (condizione: Forza ≤7) — Ferite +10, Barretta proteica (cibo, Forza+1)
Dati: cond= forza<=7 ; reward= ferite+10, cibo:Barretta proteica, fel-5
Testo: "Your first opponent slams your arm down with such momentum that you do a half spin on your chair. The tavern laughs good-naturedly and passes you a protein bar: 'eat up, kid, and come back in a month'."
Scena: pet a gambe all'aria accanto al tavolo, avversario che ride con simpatia

**Super successo** (condizione: Forza 13+, oppure talento Mani Leste — *il polso scatta prima che l'avversario capisca che si è iniziato*) — +3 Forza, +35 monete, Trofeo del Porto (arredo salone, +2 Forza), Felicità +10
Dati: cond= forza>=13 | talento:manileste ; reward= forza+3, monete+35, arredo:Trofeo del Porto, fel+10
Testo: "You flatten everyone, including the reigning champ who hadn't lost in three years. The historic table cracks right where you landed your final slam: they sign it and hand you the tavern trophy."
Scena: [DEDICATA] pet col braccio alzato sul tavolo crepato, taverna in delirio

## Missione 82: Bouncer for a Night
Brief: Tonight you're bouncer at the most exclusive rooftop party around: list in hand, game face on, zero exceptions.
- Luogo: 📍 Rooftop Party
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Tag: social
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza ; tag=social ; stadio=teen

**Standard** — +2 Forza, +25 monete, Felicità +5
Dati: reward= forza+2, monete+25, fel+5
Testo: "The most exclusive rooftop party in the neighborhood hires you as a bouncer: list in hand, arms crossed, serious face. A few gatecrashers try their luck; none get through. Absolute professional."
Scena: pet a braccia conserte davanti alla scala della terrazza, lista in mano

**Fallimento** (condizione: Forza ≤7) — Spiedino (cibo, Forza+1)
Dati: cond= forza<=7 ; reward= cibo:Spiedino, fel-5
Testo: "The gatecrashers climb over you, sneak around you, and one literally walks UNDER you. By the end of the night the rooftop has more crashers than guests. The leftover buffet is your severance package."
Scena: pet frastornato alla scala mentre gente festante gli sfila intorno

**Super successo** (condizione: Forza 13+, oppure Gentile + talento Pacifista — *convince gli imbucati ad andarsene offrendogli da bere: nessuno capisce come, ma funziona*) — +3 Forza, +40 monete, Felicità +10
Dati: cond= forza>=13 | (gentile & talento:pacifista) ; reward= forza+3, monete+40, fel+10
Testo: "Zero gatecrashers, zero incidents, and even the grumpy neighbor leaves convinced he had a great time. The host books you for EVERY party of the season, at double pay."
Scena: [DEDICATA] pet che accompagna fuori l'ultimo imbucato con gesto elegante, festa perfetta alle spalle

## Missione 83: Substitute Instructor
Brief: The gym instructor's out sick and the six o'clock class is all yours: ten students, one hour, your playlist.
- Luogo: 📍 Neighborhood Gym
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Forza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sport ; stat=forza ; stadio=teen

**Standard** — +2 Forza, +25 monete, Felicità +5
Dati: reward= forza+2, monete+25, fel+5
Testo: "The instructor is down with the flu and the 6 PM class is yours: ten students, an hour of circuit training, and your playlist. Everyone survives; some even say thanks."
Scena: pet col fischietto davanti a una fila di allievi in affanno

**Fallimento** (condizione: Forza ≤7) — Ferite +10, Barretta proteica (cibo, Forza+1)
Dati: cond= forza<=7 ; reward= ferite+10, cibo:Barretta proteica, fel-5
Testo: "You try to demonstrate the hardest exercise and get stuck in the lat machine. The class frees you through teamwork: technically speaking, an excellent group exercise."
Scena: pet incastrato nella macchina da palestra, allievi che tirano

**Super successo** (condizione: Forza 13+, oppure Nerd + talento Mente Analitica — *schede d'allenamento calcolate al millimetro per ogni allievo*) — +3 Forza, +40 monete, Fischietto dell'Istruttore (indossabile, +1 Forza +1 Carisma), Felicità +10
Dati: cond= forza>=13 | (nerd & talento:menteanalitica) ; reward= forza+3, monete+40, indossabile:Fischietto dell'Istruttore, fel+10
Testo: "Your class is so well built that the students ask to have you EVERY week. The owner hands you the official whistle: 'the substitute just got promoted'."
Scena: [DEDICATA] classe che applaude, pet col fischietto al collo appena consegnato

## Missione 84: The Ice Cream Truck
Brief: The ice cream truck dies mid-hill on Market Street, engine fried, with thirty desperate pups queued up behind it.
- Luogo: 📍 Market Street
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza ; stadio=teen

**Standard** — +2 Forza, Ghiacciolo (cibo, Carisma+1), +15 monete, Felicità +5
Dati: reward= forza+2, cibo:Ghiacciolo, monete+15, fel+5
Testo: "The ice cream truck has broken down on a hill, engine fried, with thirty desperate pups waiting. You push it all the way to the square, one meter at a time: the ice cream man pays you in coins and popsicles."
Scena: pet che spinge un furgone dei gelati in salita, cuccioli che tifano dal marciapiede

**Fallimento** (condizione: Forza ≤7) — −10 Igiene, Ghiacciolo (cibo, Carisma+1)
Dati: cond= forza<=7 ; reward= igiene-10, cibo:Ghiacciolo, fel-5
Testo: "The truck rolls backwards and takes you with it, clinging to the bumper like a highly useless hero. You both come to rest against a pile of sand: you're filthy, the truck is intact, and the ice cream man appreciates the thought."
Scena: pet impolverato aggrappato al paraurti, furgone nel cumulo di sabbia

**Super successo** (condizione: Forza 13+) — +3 Forza, +30 monete, Ghiacciolo (cibo, Carisma+1), Felicità +10
Dati: cond= forza>=13 ; reward= forza+3, monete+30, cibo:Ghiacciolo, fel+10
Testo: "You push the truck up the hill WITHOUT stopping once, between two cheering walls of crowd. The ice cream man throws open the hatch in the square and announces: 'free ice cream for everyone, courtesy of my engine!' You're the hero of the summer."
Scena: [DEDICATA] pet che spinge il furgone in cima tra gli applausi, gelati che spuntano dal portellone

## Missione 85: The Go-Kart Grand Prix
Brief: Twelve laps, tight corners and officially-banned elbows: the funfair go-kart Grand Prix is about to start.
- Luogo: 📍 Funfair Racetrack
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara, inseguimento
- Durata: 1h30
- Costo: 10 monete
- Dati: durata=1.5h ; costo=10 ; categoria=sport ; stat=velocita ; tag=gara,inseguimento ; stadio=teen

**Standard** — +2 Velocità, +25 monete, Felicità +5
Dati: reward= velocita+2, monete+25, fel+5
Testo: "The funfair go-kart Grand Prix: twelve laps, tight corners and elbows (forbidden but tolerated). You finish on the low step of the podium after a race packed with overtakes."
Scena: pet in un go-kart in piena curva, avversari incollati

**Fallimento** (condizione: Velocità ≤7) — Ferite +5, Sushi (cibo, Velocità+2)
Dati: cond= velocita<=7 ; reward= ferite+5, cibo:Sushi, fel-5
Testo: "Spin-out on lap two: you end up in the hay bales with your wheels spinning in the air. The crowd applauds anyway, because objectively speaking, your spin-out was spectacular."
Scena: pet a testa in giù nella paglia, go-kart con le ruote che girano

**Super successo** (condizione: Velocità 13+; auto anche col perk Sabotatore [gara] o Parkour Master [inseguimento]) — +3 Velocità, +40 monete, Kart a Pedali (arredo salone, +2 Velocità), Felicità +10
Dati: cond= velocita>=13 ; reward= velocita+3, monete+40, arredo:Kart a Pedali, fel+10
Testo: "You start dead last with an engine problem and reel in EVERYONE, sealing it with an around-the-outside pass on the final corner that will be retold at the funfair for years. The manager gives you the display kart."
Scena: [DEDICATA] sorpasso all'esterno sull'ultima curva, bandiera a scacchi che sventola

## Missione 86: The Last Cake Delivery
Brief: A three-tier cake has to reach the villa by six o'clock sharp, and traffic has other plans.
- Luogo: 📍 From the Bakery to the Villa
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=consegne ; stat=velocita ; stadio=teen

**Standard** — +2 Velocità, +25 monete, Felicità +5
Dati: reward= velocita+2, monete+25, fel+5
Testo: "The three-tier cake for the birthday at the villa MUST arrive by six, and traffic is a nightmare. Between shortcuts and heart-stopping braking, you deliver it with ten minutes to spare and the frosting untouched."
Scena: pet in equilibrio con una torta a tre piani, orologio della città sullo sfondo

**Fallimento** (condizione: Velocità ≤7) — −10 Igiene, Fetta di torta (cibo, Carisma+1)
Dati: cond= velocita<=7 ; reward= igiene-10, cibo:Fetta di torta, fel-5
Testo: "The villa's last step is your nemesis: you trip, and the cake gives you a mid-air hug. You salvage what's salvageable (one slice, for you) and the bakery rushes out plan B."
Scena: pet seduto coperto di glassa, una fetta superstite in mano

**Super successo** (condizione: Velocità 13+) — +3 Velocità, +45 monete, Felicità +10
Dati: cond= velocita>=13 ; reward= velocita+3, monete+45, fel+10
Testo: "You arrive half an hour early with the cake in perfect shape — so perfect they ask you to stay and serve it in white gloves. The lady of the house doubles your tip: 'the most elegant delivery pet I've ever seen'."
Scena: [DEDICATA] pet in posa da maggiordomo che presenta la torta intatta, ospiti ammirati

## Missione 87: The Market Pickpocket
Brief: A pickpocket's been fleecing shopping bags for days: today you catch him red-handed among the street market stalls.
- Luogo: 📍 Street Market
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: inseguimento
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=inseguimento ; stadio=teen

**Standard** — +2 Velocità, +30 monete, Felicità +5
Dati: reward= velocita+2, monete+30, fel+5
Testo: "A pickpocket has been cleaning out shopping bags for a week. You catch him red-handed and the chase is on through the stalls: you lose him twice, catch him on the third try. The vendors pass the hat for you."
Scena: inseguimento tra i banchi del mercato, arance che volano

**Fallimento** (condizione: Velocità ≤7) — Pesce alla griglia (cibo, Velocità+1)
Dati: cond= velocita<=7 ; reward= cibo:Pesce alla griglia, fel-5
Testo: "The pickpocket loses you in three turns and, to top it off, in the heat of the chase you plow straight through the egg stall. The fishmonger consoles you with a grilled fish: 'what matters is trying, kid. Though maybe... not through the eggs.'"
Scena: pet seduto tra le uova rotte, banco rovesciato, pescivendolo che sorride

**Super successo** (condizione: Velocità 13+, oppure Forza 10+ — *non serve corrergli dietro: lo placchi come un rugbista quando ti ripassa accanto*; auto anche col perk Parkour Master [inseguimento]) — +3 Velocità, +50 monete, perk Mr. Wolf (categoria Lavoretti: niente fallimento + sempre super successo nelle missioni Lavoretti), Felicità +10
Dati: cond= velocita>=13 | forza>=10 ; reward= velocita+3, monete+50, perk:mrwolf, fel+10
Testo: "You outsmart him: instead of chasing, you cut through the fish stall and he runs straight into your arms at the corner (or you simply tackle him mid-stride, rugby-style). You return every wallet to its rightful owner. The market crowns you: you're the one who solves problems."
Scena: [DEDICATA] borseggiatore consegnato al vigile, mercanti che sollevano il pet in trionfo

## Missione 88: The Quarry Crossing
Brief: The flooded quarry is waiting for the full crossing: the neighborhood's teen rite of passage, icy water included.
- Luogo: 📍 Flooded Quarry
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: natura
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sport ; stat=velocita ; tag=natura ; stadio=teen

**Standard** — +2 Velocità, Felicità +5
Dati: reward= velocita+2, fel+5
Testo: "The old flooded quarry is the neighborhood's secret swimming pool, and the full crossing is the teen rite of passage. You make it all the way, with a mid-crossing break on the little island to recover your breath and your dignity."
Scena: pet che nuota nella cava turchese, isolotto al centro

**Fallimento** (condizione: Nerd + talento Idrofobico) — +1 Intelligenza, Felicità +5
Dati: priorita=1 ; cond= nerd & talento:idrofobico ; reward= int+1, fel+5
Testo: "The water? Not in a million years. You stay on the shore cataloguing the quarry's frogs (three species, one probably new to science). You didn't swim a single meter, but the notebook is full."
Scena: pet all'asciutto che disegna rane sul taccuino, nuotatori sullo sfondo

**Fallimento** (condizione: Velocità ≤7) — Sushi (cibo, Velocità+2)
Dati: priorita=2 ; cond= velocita<=7 ; reward= cibo:Sushi, fel-5
Testo: "Halfway across, cramps turn you into a buoy. The swimmers tow you back to shore amid ironic applause. Some sushi from the snack stand restores a little of your honor."
Scena: pet a pancia in su che galleggia, due bagnanti che lo rimorchiano

**Super successo** (condizione: Velocità 13+, o auto col talento Amante della Natura via tag natura) — +3 Velocità, +30 monete, Trofeo Rana d'Oro (arredo bagno, +1 Velocità), Felicità +10
Dati: cond= velocita>=13 ; reward= velocita+3, monete+30, arredo:Trofeo Rana d'Oro, fel+10
Testo: "Full crossing, there and back, no breaks: a new quarry record, certified by the elder teens on the snack stand's little chalkboard. They hand you the 'Golden Frog' — the most coveted trophy of the summer."
Scena: [DEDICATA] pet sull'isolotto con la Rana d'Oro alzata, cava che applaude dall'acqua

## Missione 89: The Seniors' Club Chess Tournament
Brief: Between thick glasses and dead-serious games, the seniors' club welcomes young challengers with pure skepticism.
- Luogo: 📍 Seniors' Club
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: gara
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=studio ; stat=int ; tag=gara ; stadio=teen

**Standard** — +2 Intelligenza, +20 monete, Felicità +5
Dati: reward= int+2, monete+20, fel+5
Testo: "The seniors' club chess tournament accepts 'young talents' with barely concealed skepticism. You win three games out of five and earn the table's respect: 'the little one knows what they're doing'."
Scena: pet concentrato sulla scacchiera, anziani con l'occhialino che osservano

**Fallimento** (condizione: Intelligenza ≤7) — Cacio e Pepe Quantistica (cibo, Intelligenza+3)
Dati: cond= int<=7 ; reward= cibo:Cacio e Pepe Quantistica, fel-5
Testo: "The club elder checkmates you in four moves, all without ever pausing his war stories. They offer you the house special — a cacio e pepe made to the exact formula, zero lumps — plus one piece of advice: 'come back when you know what castling is, youngster'."
Scena: pet che fissa la scacchiera incredulo, decano che sorseggia il tè

**Super successo** (condizione: Intelligenza 13+, oppure Sportivo + talento Spirito Agonistico — *la tratta come una finale di campionato: concentrazione assoluta*; auto anche col perk Sabotatore [gara]) — +3 Intelligenza, +35 monete, Scacchiera d'Onice (arredo salone, +2 Intelligenza), Felicità +10
Dati: cond= int>=13 | (sportivo & talento:spiritoagonistico) ; reward= int+3, monete+35, arredo:Scacchiera d'Onice, fel+10
Testo: "You beat even the elder, who hadn't lost since the last century. A long pause, then the old man smiles: 'about time.' He gives you his onyx chessboard — the one nobody was even allowed to touch."
Scena: [DEDICATA] stretta di mano sulla scacchiera d'onice, circolo in piedi
## Missione 90: Tutoring Next Door
Brief: The pup upstairs is at war with fractions and his mom needs backup: today it's on you to save the situation.
- Luogo: 📍 The Neighbor's House
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; stadio=teen

**Standard** — +2 Intelligenza, +25 monete, Felicità +5
Dati: reward= int+2, monete+25, fel+5
Testo: "The pup upstairs is a walking math emergency and his mom pays well. Four hours of fractions explained with pizza slices: by the end something sticks — and so does the paycheck."
Scena: pet alla scrivania che spiega, cucciolo che finalmente annuisce

**Fallimento** (condizione: Intelligenza ≤7) — Biscotto (cibo, Carisma+1)
Dati: cond= int<=7 ; reward= cibo:Biscotto, fel-5
Testo: "The fractions knock him out first, then you: his mom finds the two of you asleep on the textbook, cheek to cheek on page 42. No pay, but she sends you home with snack-time cookies anyway."
Scena: pet e cucciolo addormentati sul libro di matematica, madre sulla soglia

**Super successo** (condizione: Intelligenza 13+) — +3 Intelligenza, +50 monete, Felicità +10
Dati: cond= int>=13 ; reward= int+3, monete+50, fel+10
Testo: "The pizza-slice method works so well the kid brings home his first A+. His mom, misty-eyed, doubles your pay and books you for the entire semester: you are now officially 'the Professor'."
Scena: [DEDICATA] cucciolo che sventola la verifica col dieci, pet portato in trionfo per casa

## Missione 91: The Broken Arcade Cabinet
Brief: Bare wires, dust, and a cabinet dead for a week: the arcade needs nosy hands, not the repair guy.
- Luogo: 📍 The Arcade
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Intelligenza
- Tag: invenzione
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=videogioco ; stat=int ; stadio=teen

**Standard** — +2 Intelligenza, +20 monete, Felicità +5
Dati: reward= int+2, monete+20, fel+5
Testo: "The arcade's most beloved cabinet has been dead for a week and the repair guy costs a fortune. You crack it open, follow the wires, find the culprit (a coin jammed in there since 2019) and bring it back to life."
Scena: pet dentro il cabinato aperto tra i fili, torcia tra i denti

**Fallimento** (condizione: Intelligenza ≤7) — Ferite +5, Torta Menzogniera (cibo, Intelligenza+2 — la torta era una bugia, la lezione no)
Dati: cond= int<=7 ; reward= ferite+5, cibo:Torta Menzogniera, fel-5
Testo: "You touch the wrong wire: zap, instant new hairstyle, and the cabinet now speaks Japanese. The manager gently walks you out, promising a consolation cake: inside the box, though, all you find is a note saying the cake was a lie. The lesson wasn't."
Scena: pet coi capelli dritti e le scintille intorno, cabinato che lampeggia ideogrammi

**Super successo** (condizione: Intelligenza 13+, oppure Forza 10+ — *manutenzione percussiva: UNA manata assestata nel punto esatto*; auto anche col perk Player One [Videogioco]; via alt flag grinder) — +3 Intelligenza, +35 monete, Gettone d'Oro (arredo salone, +1 Intelligenza +1 Felicità), Felicità +10
Dati: cond= int>=13 | forza>=10 | flag:grinder ; reward= int+3, monete+35, arredo:Gettone d'Oro, fel+10
Testo: "You don't just fix it: you UPGRADE it. The cabinet now has a secret mode you unlock with a double jump, and the arcade has never been this packed. The manager mints you a golden token: free games for life."
Scena: [DEDICATA] cabinato acceso con la folla intorno, gestore che consegna il gettone dorato

## Missione 92: The Mystery Mushroom
Brief: A mushroom never seen before has sprouted in the Big Park woods: giant, polka-dotted, faintly glowing. The ranger wants a report.
- Luogo: 📍 Big Park Woods
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: natura
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; tag=natura ; stadio=teen

**Standard** — +2 Intelligenza, Fungone Ingrandotto (cibo, Forza+2 Intelligenza+1), Felicità +5
Dati: reward= int+2, cibo:Fungone Ingrandotto, fel+5
Testo: "A mushroom NEVER seen before has popped up in the park woods: giant, polka-dotted, vaguely glowing. You study it, catalog it, photograph it from eight angles and file your report: 'edible, probably'. The park ranger lets you take a specimen home: 'if you suddenly get bigger, don't tell anyone I gave it to you'."
Scena: pet con la lente davanti a un fungo gigante a pois, taccuino aperto

**Fallimento** (condizione: Intelligenza ≤7) — Insalatona (cibo, Intelligenza+1), Felicità −5
Dati: cond= int<=7 ; reward= cibo:Insalatona, fel-5
Testo: "You sniff it from way too close: the spores make you see colors THAT DON'T EXIST for a solid hour. The ranger keeps an eye on you until you're back to normal, then sends you home with a big salad: 'regular vegetables from now on, please'."
Scena: pet con gli occhi a spirale seduto davanti al fungo, farfalle immaginarie intorno

**Super successo** (condizione: Intelligenza 13+, o auto col talento Amante della Natura via tag natura) — +3 Intelligenza, +30 monete, Felicità +10
Dati: cond= int>=13 ; reward= int+3, monete+30, fel+10
Testo: "You identify the mushroom: an ultra-rare species believed extinct, and your report goes straight to the natural history museum with your name listed as discoverer. The plaque reads 'cataloged by a young neighborhood naturalist'. That's you."
Scena: [DEDICATA] teca del museo col fungo e la targhetta, pet in posa orgogliosa accanto

## Missione 93: School Dance DJ
Brief: The school dance DJ bailed at the last minute: the decks are empty, the gym is packed and waiting.
- Luogo: 📍 School Gym
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social, musica
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social,musica ; stadio=teen

**Standard** — +2 Carisma, +25 monete, Felicità +5
Dati: reward= carisma+2, monete+25, fel+5
Testo: "The school dance DJ bailed, so the decks are yours. A few shaky transitions, one screeching microphone, but the dance floor fills up and stays packed till the very end."
Scena: pet alla consolle con le cuffie su un orecchio, palestra piena che balla

**Fallimento** (condizione: Carisma ≤7) — Fetta di torta (cibo, Carisma+1)
Dati: cond= carisma<=7 ; reward= cibo:Fetta di torta, fel-5
Testo: "You open with the wrong playlist — the one from car trips with grandma — and the floor empties in ninety seconds. The janitor takes over (and absolutely kills it, by the way). You're left with the buffet cake."
Scena: pista vuota, bidello alla consolle che alza le braccia, pet in disparte con la torta

**Super successo** (condizione: Carisma 13+; auto anche col perk Singer [musica] o Influencer [social]) — +3 Carisma, +40 monete, Cuffie da DJ (indossabile, +2 Carisma), Felicità +10
Dati: cond= carisma>=13 ; reward= carisma+3, monete+40, indossabile:Cuffie da DJ, fel+10
Testo: "You read the floor like an open book: every track at the perfect moment, the slow song timed to the second, the finale with everyone on everyone's shoulders. The school names you official DJ and hands over the regulation headphones."
Scena: [DEDICATA] palestra in delirio con le mani alzate, pet alla consolle con le cuffie nuove

## Missione 94: The Flea Market
Brief: A stall at the flea market, stacked with old toys and comics read a thousand times: today the haggling is serious.
- Luogo: 📍 Neighborhood Square
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Carisma
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=carisma ; stadio=teen

**Standard** — +2 Carisma, +30 monete, Felicità +5
Dati: reward= carisma+2, monete+30, fel+5
Testo: "A stall at the flea market: old toys, well-read comics and prime attic archaeology. You haggle, you smile, you discount at exactly the right moment — by closing time the stall is half empty and the coin pouch half full."
Scena: pet dietro un banchetto pieno di cianfrusaglie, cliente che contratta

**Fallimento** (condizione: Carisma ≤7) — −10 monete, Lampada Lava di Seconda Mano (arredo camera, +1 Felicità)
Dati: cond= carisma<=7 ; reward= monete-10, arredo:Lampada Lava di Seconda Mano, fel-5
Testo: "The problem with flea markets is they're FULL of beautiful things: you end up buying more than you sell. You come home ten coins poorer, carrying a lava lamp 'that was a bargain, I swear'."
Scena: pet che torna a casa carico di acquisti, lampada lava sotto il braccio

**Super successo** (condizione: Carisma 13+, oppure Maleducato + talento Cleptomane — *da imbonitore navigato sa vendere qualsiasi cosa; meglio non chiedere da dove viene metà della merce*) — +3 Carisma, +60 monete, Felicità +10
Dati: cond= carisma>=13 | (maleducato & talento:cleptomane) ; reward= carisma+3, monete+60, fel+10
Testo: "You sell EVERYTHING, including the stall table and the chair you were sitting on. Your last customer pays double 'because nobody can say no to that smile'. The market begs you to come back next Sunday."
Scena: [DEDICATA] banchetto completamente vuoto, pet in piedi (la sedia è venduta) col borsello gonfio

## Missione 95: The Neighborhood Play
Brief: The neighborhood play casts you as the second lead: a cape, a wooden sword, and a duel under the lights.
- Luogo: 📍 Parish Theater
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sociale ; stat=carisma ; stadio=teen

**Standard** — +2 Carisma, +20 monete, Felicità +5
Dati: reward= carisma+2, monete+20, fel+5
Testo: "The neighborhood play casts you as the second lead: thirty lines, a cape and a final duel with wooden swords. You pull it off with honor and exactly one memory blank, covered by a masterful coughing fit."
Scena: pet sul palco col mantello, spada di legno alzata, pubblico in penombra

**Fallimento** (condizione: Carisma ≤7) — Biscotto (cibo, Carisma+1)
Dati: cond= carisma<=7 ; reward= cibo:Biscotto, fel-5
Testo: "At the big moment the line vanishes from your head: silence, secondhand embarrassment, a prompter whispering way too loud and half the theater cracking up. Emergency curtain. Backstage, comfort cookies for everyone."
Scena: pet pietrificato sul palco a bocca aperta, suggeritore che gesticola dalla buca

**Super successo** (condizione: Carisma 13+, oppure Maleducato + talento Faccia di Bronzo — *improvvisa metà copione e il pubblico preferisce la SUA versione*) — +3 Carisma, +35 monete, Costume da Protagonista (indossabile, +1 Carisma +1 Intelligenza), Felicità +10
Dati: cond= carisma>=13 | (maleducato & talento:facciadibronzo) ; reward= carisma+3, monete+35, indossabile:Costume da Protagonista, fel+10
Testo: "You steal the show from everyone, lead included: three mid-scene ovations and an encore demanded at full volume. The director promotes you on the spot and lets you keep the costume: 'next year, the poster has your name on it'."
Scena: [DEDICATA] pet al centro del palco nell'inchino finale, fiori che volano dal pubblico

## Missione 96: The Block Party
Brief: The annual block party needs volunteers for EVERYTHING — stage, lights, music, cake — and today the square is counting on you.
- Luogo: 📍 Main Square
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma (ma ogni build ha la sua via)
- Tag: social
- Durata: 2h
- Costo: gratis
- Nota: BOSS multi-via (stile M7: più super possibili, vince il più specifico)
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=teen

**Standard** — +2 Carisma, +30 monete, Felicità +5
Dati: reward= carisma+2, monete+30, fel+5
Testo: "The annual block party needs volunteers for EVERYTHING: stage, lights, music, cakes. You do your part across a thousand errands, and the party comes together — as always — by collective miracle."
Scena: piazza in festa con bancarelle e luci, pet che corre con una cassa in braccio

**Fallimento** (condizione: Carisma ≤7) — Torta intera (cibo, Carisma+3)
Dati: cond= carisma<=7 ; reward= cibo:Torta intera, fel-5
Testo: "They put you on flyer duty and you invite half the city... for the wrong day. Saturday the square is empty, Sunday it's unscheduled chaos. You console yourself with a leftover cake: at least cake never gets the date wrong."
Scena: piazza deserta con le bandierine al vento, pet col pacco di volantini sbagliati

**Super successo A — l'Anima della Festa** (condizione: Carisma 13+) — +3 Carisma, +50 monete, Lanterne della Festa (arredo salone, +2 Felicità), perk Party Animal (categoria Sociale: niente fallimento + sempre super successo nelle missioni Sociale), Felicità +10
Dati: priorita=1 ; cond= carisma>=13 ; reward= carisma+3, monete+50, arredo:Lanterne della Festa, perk:partyanimal, fel+10
Testo: "You host, you entertain, you get the grandpas dancing and the pups giggling: the whole party orbits around you. At the end of the night the committee hands you the square's lanterns: 'hang them at home, same time next year'."
Scena: [DEDICATA] pet al centro della piazza illuminata dalle lanterne, girotondo intorno

**Super successo B — il Cervello della Festa** (condizione: Intelligenza 13+) — +3 Intelligenza, +50 monete, Lanterne della Festa (arredo salone, +2 Felicità), perk Party Animal (categoria Sociale: niente fallimento + sempre super successo nelle missioni Sociale), Felicità +10
Dati: priorita=2 ; cond= int>=13 ; reward= int+3, monete+50, arredo:Lanterne della Festa, perk:partyanimal, fel+10
Testo: "Shift charts, a map of the stalls, a plan B for rain and even a plan C for wind: your logistical masterpiece runs so smoothly that nobody notices how much work was behind it. The committee does, though."
Scena: [DEDICATA] pet con la planimetria della piazza spuntata voce per voce, festa perfetta sullo sfondo

**Super successo C — le Braccia della Festa** (condizione: Forza 13+) — +3 Forza, +50 monete, Lanterne della Festa (arredo salone, +2 Felicità), perk Party Animal (categoria Sociale: niente fallimento + sempre super successo nelle missioni Sociale), Felicità +10
Dati: priorita=3 ; cond= forza>=13 ; reward= forza+3, monete+50, arredo:Lanterne della Festa, perk:partyanimal, fel+10
Testo: "You build the stage SOLO, unload three vans and hoist the big tent that usually takes six volunteers and one argument. By the time the party starts, you're already a legend: 'the tent hero'."
Scena: [DEDICATA] pet che regge il tendone da solo mentre i volontari applaudono, palco montato alle spalle

## Missione 97: The Tall Grass Critter
Brief: Something never catalogued is hiding in the tall grass: tiny, zippy, with cheeks that spark.
- Luogo: 📍 Tall Grass, Big Park
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: mostro, inseguimento, companion
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sport ; stat=velocita ; tag=mostro,inseguimento,companion ; stadio=teen

**Standard** — +2 Velocità, Sfera Tascabile (arredo camera, +1 Felicità), Felicità +5
Dati: reward= velocita+2, arredo:Sfera Tascabile, fel+5
Testo: "Something never catalogued is hiding in the park's tall grass: tiny, zippy, with cheeks that spark. You chase it for hours, graze it TWICE, and at dawn it waves a little paw and vanishes. In the grass, though, you find the red-and-white ball it left behind: a souvenir. And a promise."
Scena: pet nell'erba alta che sfiora il mostriciattolo guizzante, scintille tra le spighe

**Fallimento** (condizione: Velocità ≤7) — Ferite +5, Ciambriso Gelatinoso (cibo, Velocità+2)
Dati: cond= velocita<=7 ; reward= ferite+5, cibo:Ciambriso Gelatinoso, fel-5
Testo: "You dive on it with all the enthusiasm in the world and it fries you with one mischievous spark: hair straight up, tail smoking. All that rises from the tall grass is its little giggle. The park warden offers you a jelly-filled doughnut — which is very obviously an onigiri, but don't correct him — and consoles you: 'everyone tries, nobody's ever caught it'."
Scena: pet coi capelli dritti e il codino fumante seduto nell'erba, risolino che sale dalle spighe

**Super successo** (condizione: Velocità 13+, oppure Gentile + talento Coccolone — *non lo catturi: lo COCCOLI finché non decide di restare lui*) — +3 Velocità, Mostriciattolo companion (arredo camera, +1 Velocità fisso), Costume dell'Allenatore (indossabile, +2 Velocità), perk Acchiappali Tutti (tag companion: niente fallimento + sempre super successo nelle missioni tag companion — i companion non ti scappano MAI più), Felicità +10
Dati: cond= velocita>=13 | (gentile & talento:coccolone) ; reward= velocita+3, arredo:Mostriciattolo, indossabile:Costume dell'Allenatore, perk:acchiappalitutti, fel+10
Testo: "You track it blade by blade until you cut off its escape with one perfect pounce (or you sit down, open your arms, and let it decide: it picks you). The critter surrenders with a satisfied squeak and parks itself on your shoulder. The park warden can't believe his eyes and hands you the legendary outfit: red cap and all. From today, gotta catch 'em all — or as they say around here: ACCHIAPPALI TUTTI."
Scena: [DEDICATA] pet col berretto rosso e il mostriciattolo sulla spalla, sfera alzata al cielo nell'erba alta al tramonto

## Missione 98: They Stole Our Colors
Brief: Some guy is ranting on camera in the square: 'THEY STOLE OUR COLORS!' The clip is already touring the whole city.
- Luogo: 📍 Interview Square
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: mistero, social
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; tag=mistero,social ; stadio=teen

**Standard** — +2 Intelligenza, +25 monete, Felicità +5
Dati: reward= int+2, monete+25, fel+5
Testo: "The local TV crew interviews a middle-aged guy in the square and he goes FULL conspiracy: 'THEY STOLE OUR COLORS! The colors! And the bubbles in the sparkling water too, it's less sparkly than it used to be!' The clip tours the whole city within the hour. And here's the thing — the neighborhood looks around and... kind of believes him: the walls DO seem duller. You investigate for half a day and find the answer: the cleaning company degreased the walls with a solvent that faded the murals. Paint fundraiser, case closed, and the guy stays loyal to the conspiracy."
Scena: uomo di mezza età che gesticola davanti al microfono della TV, pet che esamina un muro sbiadito con la lente

**Fallimento** (condizione: Intelligenza ≤7) — Acqua Frizzantissima (cibo), Felicità −5
Dati: cond= int<=7 ; reward= cibo:Acqua Frizzantissima, fel-5
Testo: "You set out to investigate and end up CONVERTED: after an hour of chatting with the guy you're right there next to him, holding a glass up to the light — 'the bubbles... he's right, they ARE small.' You spend the afternoon comparing sparkling waters instead of solving the case. At least you take a bottle of the good stuff home."
Scena: pet e il tizio fianco a fianco che fissano due bicchieri d'acqua frizzante controluce, molto seri

**Super successo** (condizione: Intelligenza 13+, oppure Carisma 10+ — *il tizio i suoi segreti li racconta solo a chi gli va a genio*) — +3 Intelligenza, +40 monete, Barattolo dei Colori Rubati (arredo salone, +1 Intelligenza +1 Felicità), Felicità +10
Dati: cond= int>=13 | carisma>=10 ; reward= int+3, monete+40, arredo:Barattolo dei Colori Rubati, fel+10
Testo: "You follow the clues all the way (or the guy himself, won over, points you to the right alley) and discover that a COLOR THIEF really exists: a street artist who was 'borrowing' paint from the murals at night for his secret masterpiece. You talk him into giving it all back: at dawn the neighborhood wakes up more colorful than ever, brand-new murals included. The guy, interviewed again, takes all the credit: 'I TOLD YOU SO!' He's now a neighborhood celebrity."
Scena: [DEDICATA] quartiere esploso di colori all'alba, il tizio di mezza età trionfante davanti alle telecamere, pet col barattolo di vernice in mano

---

# ADULTO — missioni da adulto (P3, stadio adulto; fail ≤15, super 32+, gate 45+/65+; Felicità std +5 / super +10)

Tutte scritte insieme, ruotano random per run (~15-17 attive dalle 32). Nuovi tag: cucina, paranormale, spazio, mistero. Nuovi perk (medagliette da super): Masterchef (cucina), Acchiappafantasmi (paranormale), Pony Express Galattico (Consegne), Astronauta (spazio). Le vie di super alt seguono la regola anti-ridondanza (build diversa dalla stat della soglia). Nuovi arredi/cibi/indossabili in coda al file, da aggiungere ad arredi.md/cibi.md.

## Missione 33: World Martial Arts Tournament
Brief: The World Arena fills with champions who don't blink for anyone: the gong is about to sound.
- Luogo: 📍 World Arena
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: gara
- Durata: 2h
- Costo: 15 monete
- Dati: durata=2h ; costo=15 ; categoria=combattimento ; stat=forza ; tag=gara ; stadio=adulto

**Standard** — +3 Forza, −15 Salute (Ferite +15), +30 monete
Dati: reward= forza+3, ferite+15, monete+30, fel+5
Testo: "The world bracket is a wall of champions, and you punch your way to the quarterfinals on parries and knee strikes. You don't take the title, but everyone knows your name — and a couple of ribs will make sure you remember it too."
Scena: pet in guardia su un ring illuminato, tabellone dei match sullo sfondo

**Fallimento** (condizione: Forza ≤15) — Ferite +25, Bistecca (cibo, Forza+2)
Dati: cond= forza<=15 ; reward= ferite+25, cibo:Bistecca, fel-5
Testo: "The gong rings and your first opponent disassembles you like badly built flat-pack furniture: pieces everywhere and no manual to put you back together. Out in round one, sore and gloomy, while the crowd politely applauds your flight path. The staff scrapes you off the mat and refuels you with a couple of steaks 'for the recovery'. The tournament goes on without you, but the steaks are excellent."
Scena: pet ammaccato a bordo ring, un inserviente che gli porge del cibo

**Super successo** (condizione: Forza 32+; auto anche con perk Street Fighter [Combattimento] o Sabotatore [gara]) — +5 Forza, −10 Salute, +60 monete, Cintura Mondiale (indossabile, +3 Forza)
Dati: cond= forza>=32 ; reward= forza+5, ferite+10, monete+60, indossabile:Cintura Mondiale, fel+10
Testo: "You drop them one by one with an ease that embarrasses the organizers. On the top step of the podium they buckle the world championship belt around your waist: heavy as a manhole cover and twice as shiny."
Scena: [DEDICATA] pet trionfante con la cintura mondiale sollevata sopra la testa, folla in delirio

## Missione 34: The Monster of Steamy Lake
Brief: Something huge and slimy rises back out of Steamy Lake, packing way more teeth than friendly requires.
- Luogo: 📍 Steamy Lake
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: mostro, natura
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=mostro,natura,companion ; stadio=adulto

**Standard** — +3 Forza, −18 Salute (Ferite +18), +25 monete, Trofeo Pinna (arredo bagno, +1 Forza +1 Felicità)
Dati: reward= forza+3, ferite+18, monete+25, arredo:Trofeo Pinna, fel+5
Testo: "Something big, slimy and over-equipped with teeth rises from the boiling lake. You barely drive it back, coming out waterlogged and bruised — but clutching a trophy fin ripped straight from the brawl."
Scena: pet che affronta una sagoma mostruosa tra i vapori del lago, spruzzi ovunque

**Fallimento** (condizione: Nerd + talento Idrofobico) — +1 Int, Sushi (cibo, Velocità+2)
Dati: priorita=1 ; cond= nerd & talento:idrofobico ; reward= int+1, cibo:Sushi, fel+5
Testo: "Water? Absolutely not: some lines you do not cross, not even for glory. You plant yourself on the shore, arms folded, and observe the monster with your notebook out, taking notes like a theater critic. You never fight it, but you end up knowing everything about it: habits, schedule, even the sound it makes when it yawns. And above all, you stayed dry — which already counts as a win."
Scena: pet sulla riva che prende appunti mentre il mostro sbuffa in acqua

**Fallimento** (condizione: Forza ≤15) — Ferite +28, Pesce alla griglia (cibo, Velocità+1)
Dati: priorita=2 ; cond= forza<=15 ; reward= ferite+28, cibo:Pesce alla griglia, fel-5
Testo: "The monster grabs you with one bored tentacle, treats you to a scenic lap of the lake and spits you back onto the shore like an olive pit. You land with a deeply unheroic noise, in front of witnesses. A fisherman, halfway between amused and sorry, offers you some already-grilled fish: 'no point casting today, the lake already caught you'. You have no comeback ready."
Scena: pet fradicio e stordito sulla riva, un pescatore che ride

**Super successo** (condizione: Forza 32+; auto anche con perk Cacciatore di Mostri [mostro]; via alt Gentile + talento Sussurra-Mostri) — +4 Forza, +40 monete, Mostro del Lago companion (arredo bagno, +2 Forza fisso)
Dati: cond= forza>=32 | (gentile & talento:sussurramostri) ; reward= forza+4, monete+40, arredo:Mostro del Lago, fel+10
Testo: "You don't defeat it: you WIN IT OVER. Between one grapple and one long stare (or a couple of sweet nothings, if that's your style) the monster understands you're not to be messed with — and decides it likes you anyway. It follows you home."
Scena: [DEDICATA] pet e mostro del lago che tornano insieme, il mostro che gli tiene l'ombrello

## Missione 35: Sparring with the Retired Champ
Brief: The retired champion up at the Mountain Gym doesn't talk much. He hits. Today it's your turn in the ring.
- Luogo: 📍 Mountain Gym
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Durata: 2h
- Costo: 10 monete
- Dati: durata=2h ; costo=10 ; categoria=combattimento ; stat=forza ; stadio=adulto

**Standard** — +3 Forza, −15 Salute (Ferite +15), Guantoni Consumati (indossabile, +2 Forza)
Dati: reward= forza+3, ferite+15, indossabile:Guantoni Consumati, fel+5
Testo: "The old champion doesn't talk much: he hits. Six hours of heavy bag, jump rope and slipping punches, and at the end he hands you his worn-out gloves with a nod worth more than any speech."
Scena: pet che si allena col sacco, un vecchio pugile robusto che osserva a braccia conserte

**Fallimento** (condizione: Forza ≤15) — Ferite +25, Barretta proteica (cibo, Forza+1)
Dati: cond= forza<=15 ; reward= ferite+25, cibo:Barretta proteica, fel-5
Testo: "Round one you're confident, round two hopeful, round three you finally get it: 'retired' doesn't mean 'weak' — it means he has more time to train. You spend the rest of the session collecting his towels more than actually boxing. The champ dismisses you with a pat that nearly flips you over and a protein bar as your only prize. To be eaten with dignity, if you have any left."
Scena: pet spelacchiato che raccoglie asciugamani, il campione che si asciuga la fronte

**Super successo** (condizione: Forza 32+; via alt Nerd + talento Mente Analitica) — +5 Forza, Accappatoio del Campione (indossabile, +3 Forza)
Dati: cond= forza>=32 | (nerd & talento:menteanalitica) ; reward= forza+5, indossabile:Accappatoio del Campione, fel+10
Testo: "You study him punch by punch (or match him blow for blow on raw power) until the champion, for the first time in years, takes a real hit. He pulls off his robe and throws it to you: 'keep it. You've earned it'."
Scena: [DEDICATA] pet con l'accappatoio del campione sulle spalle, il vecchio pugile che annuisce con rispetto

## Missione 36: The Racket Bullies
Brief: Down on Market Street a gang is shaking down every stall, and nobody's dared stop them yet.
- Luogo: 📍 Market Street
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: rapina
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=rapina ; stadio=adulto

**Standard** — +3 Forza, −15 Salute (Ferite +15), +35 monete (colletta dei negozianti)
Dati: reward= forza+3, ferite+15, monete+35, fel+5
Testo: "The racket bullies are shaking down every stall in the market. You persuade them to try a different neighborhood — bare-handed. The grateful shopkeepers pass the hat on the spot."
Scena: pet che affronta un gruppo di teppisti tra le bancarelle, negozianti che sbirciano

**Fallimento** (condizione: Forza ≤15) — Ferite +25, Torta intera (cibo, Carisma+3)
Dati: cond= forza<=15 ; reward= ferite+25, cibo:Torta intera, fel-5
Testo: "There are five of them and one of you: you run the numbers and the math strongly recommends retreat. You try the tough-guy voice anyway, and it comes out tiny. You withdraw battered but in one piece, which against bullies already counts as a result. The market baker consoles you with a whole cake 'for the courage' — the courage of showing up, she specifies."
Scena: pet malconcio che si allontana, una fornaia che gli porge una torta

**Super successo** (condizione: Forza 32+; via alt Maleducato + talento Boss di Quartiere) — +4 Forza, +70 monete, Chiavi del Quartiere (arredo salone, +2 Carisma)
Dati: cond= forza>=32 | (maleducato & talento:bossdiquartiere) ; reward= forza+4, monete+70, arredo:Chiavi del Quartiere, fel+10
Testo: "You don't chase them off: you HIRE them. Through sheer muscle (or an offer they can't refuse) the racket now answers to you — except from today it protects the neighborhood instead of plucking it. They even hand you the keys to the city. Symbolically."
Scena: [DEDICATA] pet al centro dei bulli ora rispettosi, chiavi del quartiere in mano

## Missione 37: Five Districts Marathon
Brief: Forty kilometers, five districts, zero shortcuts: the marathon is just waiting on the starting gun.
- Luogo: 📍 The Whole City
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara
- Durata: 2h
- Costo: 10 monete
- Dati: durata=2h ; costo=10 ; categoria=sport ; stat=velocita ; tag=gara ; stadio=adulto

**Standard** — +3 Velocità, +30 monete, Medaglia del Finisher (arredo camera, +1 Velocità +1 Felicità)
Dati: reward= velocita+3, monete+30, arredo:Medaglia del Finisher, fel+5
Testo: "Forty kilometers, five districts, a wall at kilometer thirty and the urge to quit at every intersection. But you cross the finish line, and the finisher's medal weighs like a knighthood."
Scena: pet stremato ma sorridente che taglia il traguardo, folla ai lati

**Fallimento** (condizione: Velocità ≤15) — +10 monete, Sushi (cibo, Velocità+2)
Dati: cond= velocita<=15 ; reward= monete+10, cibo:Sushi, fel-5
Testo: "Textbook start, champion's pace... for two districts. In the third, your legs hand in their resignation with immediate effect, conveniently right in front of the refreshment stand. Good news: that stand has a legendary buffet, and you stay there for a length of time no leaderboard will ever record. The marathon ends without you; the buffet, almost."
Scena: pet accasciato accanto a un tavolo del ristoro pieno di cibo

**Super successo** (condizione: Velocità 32+; auto anche con Sabotatore [gara]; via alt Sportivo + talento Energico) — +5 Velocità, +60 monete, Scarpe d'Oro (indossabile, +3 Velocità)
Dati: cond= velocita>=32 | (sportivo & talento:energico) ; reward= velocita+5, monete+60, indossabile:Scarpe d'Oro, fel+10
Testo: "You don't run: you float. You blow past the runners' wall like it's a road sign and cross the line with a lead that embarrasses second place. Golden shoes and a spot in the city record books."
Scena: [DEDICATA] pet primo al traguardo con le scarpe dorate, cronometro con tempo record

## Missione 38: Neighborhood Olympics
Brief: Sprints, jumps, trivia, karaoke: the Neighborhood Olympics are an absurd pentathlon with no mercy for slackers.
- Luogo: 📍 City Stadium
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: qualsiasi (tutte le prove)
- Tag: gara
- Durata: 2h
- Costo: 20 monete
- Nota: BOSS a gate (serve statMax alto)
- Dati: durata=2h ; costo=20 ; categoria=sport ; stat=qualsiasi ; tag=gara ; stadio=adulto ; ritenta=1

**Standard** (condizione: statMax 40+) — +2 a tutte le stat, +40 monete, Torcia Olimpica (arredo salone, +2 Felicità)
Dati: cond= statMax>=40 ; reward= forza+2, velocita+2, int+2, carisma+2, monete+40, arredo:Torcia Olimpica, fel+5
Testo: "Sprints, jumps, trivia, karaoke: the neighborhood Olympics are an absurd pentathlon. You finish near the top in everything, versatile and wrecked, and light the olympic torch on your own balcony."
Scena: pet multitasking tra più prove sportive, torcia olimpica accesa

**Fallimento** (condizione: statMax <40) — +15 monete, Scorta di Panini (cibo, 5 porzioni, +2 stat casuale), la missione resta in rosa
Dati: cond= statMax<40 ; reward= monete+15, cibo:Scorta di Panini, fel-5
Testo: "Eliminated in the qualifiers of every single event: technically that's a record too, just the wrong kind. Even in shot put, where the job was basically dropping it. But the olympic buffet is legendary, nobody checks passes and you're still wearing the tracksuit: the day still ends with a medal — the dining kind."
Scena: pet eliminato che si consola davanti a un tavolo del buffet olimpico

**Super successo** (condizione: statMax 65+; via alt Sportivo + talento Predestinato) — +3 a tutte le stat, +80 monete, Podio d'Oro (arredo salone, +2 a una stat RPG casuale ogni giorno), Mela Dorata Blocchettosa (cibo, +2 stat casuale)
Dati: cond= statMax>=65 | (sportivo & talento:predestinato) ; reward= forza+3, velocita+3, int+3, carisma+3, monete+80, arredo:Podio d'Oro, cibo:Mela Dorata Blocchettosa, fel+10
Testo: "You sweep the medals in every event, from weightlifting to the general knowledge quiz. The neighborhood dedicates a permanent golden podium to you in the square — and a home copy that powers you up every single morning. Waiting for you on the top step there's also the prize of prizes: a golden apple, all blocky edges, the kind you only get to bite when you win."
Scena: [DEDICATA] pet sul gradino più alto di un podio dorato coperto di medaglie

## Missione 39: Half-Pipe Contest
Brief: Ramp and air at the Harbor Skatepark: the local show-offs are just waiting for you to eat pavement.
- Luogo: 📍 Harbor Skatepark
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sport ; stat=velocita ; tag=gara ; stadio=adulto

**Standard** — +3 Velocità, Skateboard Pro (arredo camera, +2 Velocità)
Dati: reward= velocita+3, arredo:Skateboard Pro, fel+5
Testo: "Ramp, air, (almost) clean landing: you throw down your run to applause and a few 'ohhh's. You don't win, but you earn a pro deck and the respect of the harbor show-offs."
Scena: pet a mezz'aria sopra la rampa dell'half-pipe, skater che guardano

**Fallimento** (condizione: Velocità ≤15) — Ferite +15, Sushi (cibo, Velocità+2)
Dati: cond= velocita<=15 ; reward= ferite+15, cibo:Sushi, fel-5
Testo: "Perfect run-up, ambitious jump, landing... face-first. The faceplant is so epic it will be clipped, slow-motioned and set to music for years. They peel you off the bottom of the ramp, dust you off gently and offer you sushi 'for the courage (and for the face)'. The face will say thanks as soon as it can."
Scena: pet lungo disteso sulla rampa dopo un capitombolo, skater che accorrono

**Super successo** (condizione: Velocità 32+; auto anche con perk Tony Hawk [Sport]; via alt Nerd + talento Roombo) — +5 Velocità, +50 monete, Tavola Leggendaria (indossabile, +3 Velocità)
Dati: cond= velocita>=32 | (nerd & talento:roombo) ; reward= velocita+5, monete+50, indossabile:Tavola Leggendaria, fel+10
Testo: "You land the 900 on your first try (or, if you're the practical type, you first buff the ramp to a mirror shine with your robot vacuum). The skatepark falls silent, then erupts. They carry you home in triumph with the legendary deck."
Scena: [DEDICATA] pet in posa vittoriosa sulla tavola sopra la rampa, folla in delirio

## Missione 40: Speedrun World Record
Brief: Stopwatch running, worldwide chat tuned in: tonight at the Arcade, someone's making a run at the speedrun record.
- Luogo: 📍 The Arcade (worldwide livestream)
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Velocità
- Tag: gara, social
- Durata: 2h
- Costo: 5 monete
- Dati: durata=2h ; costo=5 ; categoria=videogioco ; stat=velocita ; tag=gara,social ; stadio=adulto

**Standard** — +3 Velocità, +25 monete
Dati: reward= velocita+3, monete+25, fel+5
Testo: "Six hours of attempts, frame-perfect glitch hunting and trembling hands: you graze the world record and settle for a personal best. The chat, though, adores you."
Scena: pet con cuffie e controller davanti a uno schronometro che scorre, chat che scrolla

**Fallimento** (condizione: Velocità ≤15, oppure Maleducato + talento Bad Loser) — Sushi (cibo, Velocità+2)
Dati: cond= velocita<=15 | (maleducato & talento:badloser) ; reward= cibo:Sushi, fel-5
Testo: "You blow the trick at minute three and reset. Then again. And again, while the worldwide chat drifts from cheering to snark (or, if you're a Bad Loser, you smash the keyboard on a planetary livestream). The record sits right where it was, unbeaten and sarcastic. By the end of the night you're left with some sushi, red eyes and a bit of shame to sleep off."
Scena: pet frustrato davanti allo schermo "RESET", chat piena di faccine

**Super successo** (condizione: Velocità 32+; auto anche con perk Player One [Videogioco] o Sabotatore [gara]; via alt Nerd + talento Overclock) — +5 Velocità, +60 monete, Tastiera d'Oro (arredo camera, +2 Velocità)
Dati: cond= velocita>=32 | (nerd & talento:overclock) ; reward= velocita+5, monete+60, arredo:Tastiera d'Oro, fel+10
Testo: "Perfect run, perfect frames, world record obliterated on a global livestream (overheating until you literally smoke, if you're running the Overclock). The chat explodes, the sponsors too. They ship you a solid gold keyboard."
Scena: [DEDICATA] pet trionfante col cronometro fermo su un tempo record, tastiera d'oro accanto

## Missione 41: Night of the Cursed Cabinet
Brief: At midnight the cabinet 'nobody finishes alive' switches itself on, and the retro-arcade holds its breath.
- Luogo: 📍 "The Black Token" Retro-Arcade
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Intelligenza
- Tag: paranormale, mistero
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=videogioco ; stat=int ; tag=paranormale,mistero ; stadio=adulto

**Standard** — +3 Int, +25 monete, Gettone Nero (arredo salone, +1 Int +1 Felicità)
Dati: reward= int+3, monete+25, arredo:Gettone Nero, fel+5
Testo: "The cabinet 'nobody finishes alive' is waiting for you at midnight. You uncover its secret: the ghost was corrupted firmware. You patch the bug and keep the black token as a lucky charm."
Scena: pet illuminato dallo schermo di un cabinato inquietante in un arcade buio

**Fallimento** (condizione: Intelligenza ≤15) — Zuppa di verdure (cibo, Int+2), −5 Felicità
Dati: cond= int<=15 ; reward= cibo:Zuppa di verdure, fel-5
Testo: "At 3 a.m. the cabinet makes a sound it should NOT make, the screen switches itself on, and something inside you decides for the both of you. You exit the arcade at double speed without ever looking back, setting the real record of the night. The manager, who has clearly seen things, sends you home with soup and plenty of apologies. The cabinet, witnesses swear, is still laughing."
Scena: pet che scappa dall'arcade nel buio, il cabinato che sfarfalla alle sue spalle

**Super successo** (condizione: Intelligenza 32+; auto anche con perk Player One [Videogioco]; via alt Nerd + talento Galaxy Brain) — +5 Int, +50 monete, Cabinato Maledetto (arredo salone, +2 Int; ogni tanto si accende da solo)
Dati: cond= int>=32 | (nerd & talento:galaxybrain) ; reward= int+5, monete+50, arredo:Cabinato Maledetto, fel+10
Testo: "You don't just beat it: you decompile the curse line by line until the ghost, defeated and honestly impressed, leaves you the cabinet in its will. Every now and then, in the living room, it switches itself on. But you're friends now."
Scena: [DEDICATA] pet trionfante davanti al cabinato con la scritta "YOU WIN", un fantasmino pixel che applaude

## Missione 42: Forbidden Archaeological Dig
Brief: Under the metro tracks sleeps a buried city nobody's supposed to touch — torch already in hand.
- Luogo: 📍 Ruins Under the Metro
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: mistero
- Durata: 2h
- Costo: 10 monete
- Dati: durata=2h ; costo=10 ; categoria=studio ; stat=int ; tag=mistero ; stadio=adulto

**Standard** — +3 Int, +30 monete, Vaso Antico (arredo salone, +2 Int)
Dati: reward= int+3, monete+30, arredo:Vaso Antico, fel+5
Testo: "Under the metro tracks lies a buried city you're not supposed to touch. You touch it responsibly: you map, you catalog, and you resurface with a thousand-year-old vase and zero cave-ins on your conscience."
Scena: pet con torcia e pennello tra rovine sotterranee, un vaso antico in primo piano

**Fallimento** (condizione: Intelligenza ≤15) — −10 monete (danni), Insalatona (cibo, Int+1)
Dati: cond= int<=15 ; reward= monete-10, cibo:Insalatona, fel-5
Testo: "You pick up the wrong artifact — the shiny one, obviously — and the entire ceiling decides to descend one level, with you underneath. You crawl out coated in millennial dust and very recent regrets. Waiting for you: a fine for the damage and an apology salad, served as cold as the head archaeologist's stare. The artifact, as irony would have it, was a paperweight."
Scena: pet impolverato che scappa da un crollo, un vaso rotto a terra

**Super successo** (condizione: Intelligenza 32+; auto anche con perk Doc Brown [Studio]; via alt Maleducato + talento Cleptomane) — +5 Int, +60 monete, Idolo Dorato (arredo salone, +3 Int, alto valore di rivendita)
Dati: cond= int>=32 | (maleducato & talento:cleptomane) ; reward= int+5, monete+60, arredo:Idolo Dorato, fel+10
Testo: "You decipher the lost map and find the treasure chamber (or the golden idol simply 'falls' into your backpack during the commotion). Millennia of history, now lighting up your living room."
Scena: [DEDICATA] pet che solleva un idolo dorato luminoso in una camera sepolta

## Missione 43: The Backyard Rocket
Brief: Tin cans, glue, and wildly oversized ambition: in the backyard, the countdown to launch has already begun.
- Luogo: 📍 Backyard Launch Pad
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: invenzione, spazio
- Durata: 2h
- Costo: 20 monete
- Dati: durata=2h ; costo=20 ; categoria=studio ; stat=int ; tag=invenzione,spazio ; stadio=adulto

**Standard** — +3 Int, +30 monete (sponsor di quartiere), Modellino Razzo (arredo camera, +2 Int)
Dati: reward= int+3, monete+30, arredo:Modellino Razzo, fel+5
Testo: "You build a rocket out of tin cans, glue and wildly disproportionate ambition. It launches crooked, but it launches, and the neighborhood sponsors pay for the show. The scale model stays in your bedroom."
Scena: pet accanto a un razzo artigianale che sputa fumo, vicini che guardano dalle finestre

**Fallimento** (condizione: Intelligenza ≤15) — Ferite +15, Zuppa di verdure (cibo, Int+2)
Dati: cond= int<=15 ; reward= ferite+15, cibo:Zuppa di verdure, fel-5
Testo: "Perfect countdown, perfect ignition, and the rocket blows up on the pad in a mushroom of smoke and confetti. What a show, though: the neighbors applaud the disaster from their balconies like it's New Year's Eve. They rinse your blackened face, straighten your singed antennas and hand you some soup. The yard smells of gunpowder and almost-glory."
Scena: pet annerito e spettinato davanti a una rampa fumante, vicini che applaudono

**Super successo** (condizione: Intelligenza 32+; auto anche con talento Inventore [invenzione]; via alt Sportivo + talento Montaggio alla Rocky) — +5 Int, +70 monete, perk Astronauta (tag spazio: niente fallimento + sempre super successo nelle missioni tag spazio), Casco Spaziale (indossabile, +2 Int)
Dati: cond= int>=32 | (sportivo & talento:montaggioallarocky) ; reward= int+5, monete+70, perk:astronauta, indossabile:Casco Spaziale, fel+10
Testo: "The rocket climbs straight as an arrow and grazes orbit (built in one epic overnight montage, if you're the relentless type). The whole city watches from below, jaws open. From today, space is home turf."
Scena: [DEDICATA] pet col casco spaziale accanto a un razzo perfetto che decolla verso le stelle

## Missione 44: The Case of the Missing Cats
Brief: Twelve cats gone missing and a neighborhood in panic: your pet grabs a trench coat and goes hunting for clues.
- Luogo: 📍 The Neighborhood (investigation)
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: mistero, natura
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=studio ; stat=int ; tag=mistero,natura ; stadio=adulto

**Standard** — +3 Int, +30 monete (la gratitudine di 12 gatti)
Dati: reward= int+3, monete+30, fel+5
Testo: "Twelve missing cats, a neighborhood in panic and one culprit: the cyborg pigeon, hoarding them out of jealousy. Case closed, cats home, reward collected."
Scena: pet detective con lente d'ingrandimento tra gatti che tornano a casa

**Fallimento** (condizione: Intelligenza ≤15) — Biscotto (cibo, Carisma+1)
Dati: cond= int<=15 ; reward= cibo:Biscotto, fel-5
Testo: "You chase the wrong lead for five hours, complete with stakeouts, deductions and a red-string board worthy of a thriller. Then you arrest (metaphorically) a bush: it had the ironclad alibi of being a bush. Meanwhile the cats stroll home on their own, as is feline tradition. The owners, grateful for the effort anyway, load you up with cookies and call you 'detective' without laughing. Mostly."
Scena: pet perplesso davanti a una lavagna di indizi che non tornano

**Super successo** (condizione: Intelligenza 32+; auto anche con talento Amante della Natura [natura]; via alt Nerd + talento Mente Analitica) — +5 Int, +50 monete, Cappello da Detective (indossabile, +2 Int +1 Carisma)
Dati: cond= int>=32 | (nerd & talento:menteanalitica) ; reward= int+5, monete+50, indossabile:Cappello da Detective, fel+10
Testo: "You reconstruct motives, alibis and trajectories (or you simply ASK the cats where they've been). You expose the entire feline conspiracy and earn the neighborhood's official detective hat."
Scena: [DEDICATA] pet col cappello da detective che indica il colpevole, gatti testimoni intorno

## Missione 45: Graduation Day
Brief: Packed lecture hall, stone-faced committee, a thesis to defend: graduation day has come, no turning back now.
- Luogo: 📍 City University
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 2h
- Costo: 20 monete
- Nota: BOSS a gate (ritentabile dopo un fallimento)
- Dati: durata=2h ; costo=20 ; categoria=studio ; stat=int ; stadio=adulto ; ritenta=1

**Standard** (condizione: Intelligenza 45+) — +3 Int, Pergamena di Laurea (arredo salone, +3 Int), +30 monete (dai parenti)
Dati: cond= int>=45 ; reward= int+3, arredo:Pergamena di Laurea, monete+30, fel+5
Testo: "Packed lecture hall, stone-faced committee, trick questions. You defend your thesis sweating bolts and bring it home: the diploma is yours, and nobody can ever say anything to you again."
Scena: pet con toga tra i banchi dell'aula magna, commissione solenne

**Fallimento** (condizione: Intelligenza <45) — Cacio e Pepe Quantistica (cibo, Int+3), la missione resta in rosa
Dati: cond= int<45 ; reward= cibo:Cacio e Pepe Quantistica, fel-5
Testo: "First two questions: flawless. Third question: total void, the kind you can hear humming in the room. You stammer something about robot photosynthesis — which doesn't exist, and now everybody knows it — and the advisor dismisses you with a gentle 'see you at the next session'. Outside, your relatives are throwing you a party anyway, with a scientifically flawless cacio e pepe: the degree can wait, dinner cannot."
Scena: pet a capo chino fuori dall'aula, parenti che lo consolano

**Super successo** (condizione: Intelligenza 65+; via alt Maleducato + talento Lavoro in Nero) — 110 e lode: +5 Int, Pergamena di Laurea, +60 monete, Corona d'Alloro (indossabile, +2 Int +1 Carisma)
Dati: cond= int>=65 | (maleducato & talento:lavoroinnero) ; reward= int+5, arredo:Pergamena di Laurea, monete+60, indossabile:Corona d'Alloro, fel+10
Testo: "You recite the thesis from memory and correct a typo in the committee president's own book (politely). Or, if you're the practical type, 'a friend' wrote it overnight, strictly off the books. Either way: highest honors, laurel crown, conscience negotiable."
Scena: [DEDICATA] pet con corona d'alloro sul podio dell'aula, commissione in piedi che applaude

## Missione 46: Ambassador of the Two Races
Brief: Robots and aliens haven't spoken in a generation, and someone has to play diplomat at the Council Palace.
- Luogo: 📍 Council Palace
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=adulto

**Standard** — +3 Carisma, +35 monete
Dati: reward= carisma+3, monete+35, fel+5
Testo: "Robots and aliens haven't spoken in a generation, and you're the designated bridge. Between one toast and one diplomatic misunderstanding, the peace treaty gets signed — partly thanks to you."
Scena: pet tra due delegazioni (robot e alieni) che si stringono la mano

**Fallimento** (condizione: Carisma ≤15) — Torta intera (cibo, Carisma+3)
Dati: cond= carisma<=15 ; reward= cibo:Torta intera, fel-5
Testo: "You mix up the ceremonial robot greeting with the ritual alien insult — a tiny detail, like meaning to say 'good morning' and declaring war instead — and in three seconds you've nearly rebooted a cold war. The delegations rise, the translators sweat, and you keep smiling in exactly the wrong way. They send you home with an apology cake and an open-ended entry ban. Diplomacy isn't your strong suit; cake is."
Scena: pet imbarazzato tra due delegazioni offese, guardie che lo accompagnano fuori

**Super successo** (condizione: Carisma 32+; via alt Gentile + talento Pacifista; via alt flag pulito) — +5 Carisma, +70 monete, Medaglione del Concilio (indossabile, +3 Carisma)
Dati: cond= carisma>=32 | (gentile & talento:pacifista) | flag:pulito ; reward= carisma+5, monete+70, indossabile:Medaglione del Concilio, fel+10
Testo: "With the right sentence at the right moment (or a disarming sweetness) you melt thirty years of frost. The two races sign a historic alliance and hang the Council medallion around your neck."
Scena: [DEDICATA] pet col medaglione al collo tra le due delegazioni festanti, bandiere di pace

## Missione 47: Prime-Time Talk Show Guest
Brief: Lights up, audience ready, a host who lives off one-liners: your pet is the guest of honor on prime-time TV.
- Luogo: 📍 TV Studios
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=adulto

**Standard** — +3 Carisma, +30 monete
Dati: reward= carisma+3, monete+30, fel+5
Testo: "Spotlights, canned applause and a host who lives off one-liners. You hold your own, land a couple of perfect anecdotes and the clip goes viral by nightfall."
Scena: pet sul divano di un talk show sotto le luci, conduttore che ride

**Fallimento** (condizione: Carisma ≤15) — Alette dell'Intervista Infuocata (cibo, Forza+2 Carisma+2)
Dati: cond= carisma<=15 ; reward= cibo:Alette dell'Intervista Infuocata, fel-5
Testo: "The host butters you up for twenty minutes, then guts you with the trick question, live and nationwide. You flounder with rare grace: impossible subtitles, control room in panic, a technician laughing off-camera. The audience, moved to pity, has them wheel out the tray of blazing wings from the closing segment: if you can't handle the questions, at least handle the heat. Tomorrow you'll be a meme — but a meme that didn't cry."
Scena: pet sudato sul divano mentre il conduttore sogghigna, pubblico che mormora

**Super successo** (condizione: Carisma 32+; auto anche con perk Influencer [social]; via alt Maleducato + talento Chissenefrega) — +5 Carisma, +60 monete, Poltrona del Talk (arredo salone, +2 Carisma)
Dati: cond= carisma>=32 | (maleducato & talento:chissenefrega) ; reward= carisma+5, monete+60, arredo:Poltrona del Talk, fel+10
Testo: "You take over the entire broadcast: you out-charm the host on his own couch (or, if you genuinely don't care what anyone thinks, with a shamelessness the audience ADORES). They let you keep the studio armchair."
Scena: [DEDICATA] pet che domina il talk show tra applausi scroscianti, conduttore spiazzato

## Missione 48: Neighborhood Elections
Brief: Rallies, handshakes, promises flying everywhere: it's election day in the square, and your pet is running for neighborhood mayor.
- Luogo: 📍 Town Hall Square
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social
- Durata: 2h
- Costo: 20 monete
- Nota: BOSS a gate
- Dati: durata=2h ; costo=20 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=adulto ; ritenta=1

**Standard** (condizione: Carisma 45+) — eletto: +3 Carisma, +50 monete, Fascia da Sindaco (indossabile, +2 Carisma +1 Int)
Dati: cond= carisma>=45 ; reward= carisma+3, monete+50, indossabile:Fascia da Sindaco, fel+5
Testo: "Rallies, puppy-kissing and reasonable promises: the campaign works and they elect you neighborhood mayor. The sash even suits you."
Scena: pet su un palco elettorale con la fascia da sindaco, folla di sostenitori

**Fallimento** (condizione: Carisma <45) — Torta intera (cibo, Carisma+3), la missione resta in rosa
Dati: cond= carisma<45 ; reward= cibo:Torta intera, fel-5
Testo: "You lose the election to the cyborg pigeon, a surprise candidate running on a single-issue platform: crumbs. The people have spoken, and the people said 'crumbs'. It's humiliating in a way not even the neighborhood history books will know how to phrase. But there's always next term — and meanwhile your campaign committee (you) consoles itself with a cake."
Scena: pet sconfitto accanto a un manifesto del piccione cyborg vincitore

**Super successo** (condizione: Carisma 65+; via alt Maleducato + talento Faccia di Bronzo) — plebiscito: +5 Carisma, +80 monete, Fascia da Sindaco, Statua in Piazza (arredo salone, +3 Carisma)
Dati: cond= carisma>=65 | (maleducato & talento:facciadibronzo) ; reward= carisma+5, monete+80, indossabile:Fascia da Sindaco, arredo:Statua in Piazza, fel+10
Testo: "You win by landslide on sheer charisma (or with a campaign so shameless, so rich in impossible promises, that the whole neighborhood falls for it en masse). They dedicate a statue to you in the square, still warm from the mold."
Scena: [DEDICATA] pet che inaugura la propria statua in piazza, folla oceanica che acclama
## Missione 49: Rock Festival Headliner
Brief: A sea of phone lights, a massive stage, your pet's name at the top of the bill: tonight it's headlining.
- Luogo: 📍 Festival Main Stage
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: musica, gara, social
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=musica,gara,social ; stadio=adulto

**Standard** — +3 Charisma, +40 coins, "Chitarra Elettrica" (bedroom furniture, +2 Charisma)
Dati: reward= carisma+3, monete+40, arredo:Chitarra Elettrica, fel+5
Testo: "You're headlining the festival, facing a stadium-sized sea of phone flashlights. The show goes off without a hitch, the crowd goes airborne, and you take home an electric guitar still smoking from the solos."
Scena: pet che suona su un palco enorme, mare di spettatori con luci alzate

**Fallimento** (condizione: Carisma ≤15) — "Torta intera" (food, Charisma+3), −5 Happiness
Dati: cond= carisma<=15 ; reward= cibo:Torta intera, fel-5
Testo: "Wrong note on song one, killer mic feedback on song two, boos from the lawn on song three: a flawless setlist — of disasters. You exit the stage under a hail of assorted vegetables, dodging roughly half. Backstage, someone hands you a whole cake, the night's only loot. Rock is cruel; catering, mercifully, is not."
Scena: pet mortificato che lascia il palco tra i fischi, un pubblico deluso

**Super successo** (condizione: Carisma 32+; auto anche con perk Singer [musica] o Sabotatore [gara]) — +5 Charisma, +80 coins, "Chitarra Fiammante" (wearable, +3 Charisma)
Dati: cond= carisma>=32 ; reward= carisma+5, monete+80, indossabile:Chitarra Fiammante, fel+10
Testo: "The solo of the century, the crowd chanting your name, encore after encore until sunrise. You smash your guitar on stage — tradition demands it — and they gift you a flaming new one that's even cooler."
Scena: [DEDICATA] pet rockstar in posa iconica con una chitarra fiammeggiante, stadio in delirio

## Missione 50: The Screaming Chef's Kitchen
Brief: Pots flying, a chef screaming like it's war: a shift in the Bestiale kitchen shows no mercy.
- Luogo: 📍 "Bestiale" Restaurant
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Intelligenza
- Tag: cucina
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=int ; tag=cucina ; stadio=adulto

**Standard** — +3 Int, +35 coins, "Set di Coltelli" (kitchen furniture, +2 Int)
Dati: reward= int+3, monete+35, arredo:Set di Coltelli, fel+5
Testo: "The chef screams, the plates fly, dinner service is trench warfare. You survive the shift with all fingers accounted for and earn yourself a professional knife set."
Scena: pet in divisa da cuoco tra fiamme e pentole, uno chef enorme che urla sullo sfondo

**Fallimento** (condizione: Intelligenza ≤15, oppure Sportivo + talento Fissato con la Dieta) — "Sganassone di Parmigiano" (food, Strength+2)
Dati: cond= int<=15 | (sportivo & talento:fissatoconladieta) ; reward= cibo:Sganassone di Parmigiano, fel-5
Testo: "You burn the butter while cooking butter — a feat the chef calls 'scientifically impossible' one second before switching to expletives (or you flat-out refuse to cook 'that greasy stuff', with identical results). You're chased out of the kitchen amid air-swung frying pans and creative synonyms for 'useless'. Before he slams the door on you, though, the chef lands a back-slap that could rearrange furniture and hands you a wedge of parmesan the size of an open palm: 'now go learn something, kid.'"
Scena: pet cacciato dalla cucina con un arrosto sottobraccio, chef paonazzo che urla

**Super successo** (condizione: Intelligenza 32+; via alt Nerd + talento Roombo) — +5 Int, +70 coins, perk Masterchef (cucina tag: no failures + always super success on cucina-tag missions), "Cappello da Chef" (wearable, +2 Int)
Dati: cond= int>=32 | (nerd & talento:roombo) ; reward= int+5, monete+70, perk:masterchef, indossabile:Cappello da Chef, fel+10
Testo: "Flawless service, Michelin-grade plates, a station scrubbed with surgical precision (the little vacuum robot actually makes the chef WEEP). The tyrant of the stovetop hugs you through tears and crowns you his heir."
Scena: [DEDICATA] pet col cappello da chef che riceve l'abbraccio commosso dello chef urlante, cucina scintillante

## Missione 51: The Haunted Mansion
Brief: The mansion on the hill has been howling for thirty years and the neighbors are done with it: someone has to climb up, at night, and knock.
- Luogo: 📍 Abandoned Mansion on the Hill
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Carisma
- Tag: paranormale, mistero
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=carisma ; tag=paranormale,mistero,companion ; stadio=adulto

**Standard** — +3 Charisma, +35 coins
Dati: reward= carisma+3, monete+35, fel+5
Testo: "The mansion has been howling for thirty years and the neighbors are done with it. You walk up, knock (politely), and discover the ghosts are just bored. A little chat, a set of house rules, and the hill sleeps again."
Scena: pet al tavolo con tre fantasmi lenzuolati che firmano un regolamento

**Fallimento** (condizione: Carisma ≤15) — "Frullaviola del Malaugurio" (food, Charisma+2 but Wounds+5), −5 Happiness
Dati: cond= carisma<=15 ; reward= cibo:Frullaviola del Malaugurio, fel-5
Testo: "The plan holds up beautifully until the first BOOOO from the chimney: at which point you descend the hill at a speed you didn't know you had and nobody can certify, because it was dark and you were screaming. The mansion stays haunted, you stay shaken — call it a draw. Next morning, on your doorstep: a purple smoothie, still cold, and a note. 'sorry. — the ghosts'. Polite, for ghosts (the smoothie, on the other hand, lays you out flat for a solid ten minutes)."
Scena: pet in fuga scomposta dalla villa, fantasmi affacciati con aria colpevole

**Super successo** (condizione: Carisma 32+; via alt Gentile + talento Santo Subito) — +5 Charisma, +70 coins, perk Acchiappafantasmi (paranormale tag: no failures + always super success on paranormale-tag missions), "Fantasmino" companion (bedroom furniture, +2 Charisma flat)
Dati: cond= carisma>=32 | (gentile & talento:santosubito) ; reward= carisma+5, monete+70, perk:acchiappafantasmi, arredo:Fantasmino, fel+10
Testo: "You don't convince them: you win them over (or exorcise them with pure love). By the end of the night the ghosts name you honored guest, and the littlest one packs its (transparent) bags and moves in with you."
Scena: [DEDICATA] pet che esce dalla villa all'alba con un fantasmino raggiante che gli svolazza intorno

## Missione 52: The Armored Train Heist
Brief: An armored train loaded with gold is speeding westbound, and your pet is already on the roof, ready for the heist of a lifetime.
- Luogo: 📍 Westbound Railway
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: rapina, inseguimento
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=rapina,inseguimento ; stadio=adulto

**Standard** — +3 Speed, +50 coins
Dati: reward= velocita+3, monete+50, fel+5
Testo: "An armored train full of gold bars, a rooftop sprint, and watchmaker timing: the heist goes down clean and the getaway is spotless. Nobody will ever know it was you."
Scena: pet che corre sul tetto di un treno in movimento al tramonto

**Fallimento** (condizione: Velocità ≤15) — −20 coins (fine), "Fetta di Panino Gigante" (food, +2 random stat)
Dati: cond= velocita<=15 ; reward= monete-20, cibo:Fetta di Panino Gigante, fel-5
Testo: "A plan drawn to the millimeter, split-second timing: shame you board the wrong car — the buffet car — and your criminal resolve melts at the appetizer table. They catch you mid-bite, crumbs all over you like prime evidence. Hefty fine, pride in the gutter, criminal career over before the opening credits. But the sandwich, let the record show, was genuinely excellent."
Scena: pet ammanettato con mezzo panino gigante in mano, controllori intorno

**Super successo** (condizione: Velocità 32+; auto anche con perk GTB [rapina] o Parkour Master [inseguimento]; via alt Maleducato + talento Mani Leste) — +5 Speed, +100 coins, "Sacco di Refurtiva" (living room furniture, +1 Speed, sky-high resale value)
Dati: cond= velocita>=32 | (maleducato & talento:manileste) ; reward= velocita+5, monete+100, arredo:Sacco di Refurtiva, fel+10
Testo: "You don't just empty the armored car: you clean out the mail car too, in the time it takes the conductor to sneeze. You vanish into thin air with a loot sack as big as you are."
Scena: [DEDICATA] pet che salta giù dal treno in corsa con un enorme sacco di bottino, guardie beffate

## Missione 53: Controlled Demolition
Brief: A condemned building is just waiting for a sledgehammer and some attitude: today your pet brings it down, brick by brick.
- Luogo: 📍 Condemned Building
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=forza ; stadio=adulto

**Standard** — +3 Strength, +40 coins, −10 Hygiene
Dati: reward= forza+3, monete+40, igiene-10, fel+5
Testo: "A condemned building, a sledgehammer, and official permission to let loose: you bring it down brick by brick in a cloud of dust. Pays well, stains worse."
Scena: pet che abbatte un muro con una mazza enorme, polvere ovunque

**Fallimento** (condizione: Forza ≤15) — Wounds +20, −15 Hygiene, "Bistecca" (food, Strength+2)
Dati: cond= forza<=15 ; reward= ferite+20, igiene-15, cibo:Bistecca, fel-5
Testo: "You study the pillars, choose with care, strike... the wrong one. The building decides to demolish itself, ahead of schedule and with you on the schedule. You crawl out from under a mountain of rubble, coughing dust and half-apologies. Your coworkers offer you a consolation steak: 'happens to everyone', they lie. It does not happen to everyone."
Scena: pet che spunta da un cumulo di macerie, colleghi che accorrono

**Super successo** (condizione: Forza 32+; via alt perk Weapon Wielder con un'arma equipaggiata; via alt Sportivo + talento Veterano del Ring) — +5 Strength, +80 coins, "Palla da Demolizione" (living room furniture, +3 Strength)
Dati: cond= forza>=32 | (perk:weaponwielder & arma) | (sportivo & talento:veteranodelring) ; reward= forza+5, monete+80, arredo:Palla da Demolizione, fel+10
Testo: "You bring down the entire building with one well-placed punch (without a scratch, if your body's been forged by a lifetime of beatdowns). The company gifts you the wrecking ball as a souvenir. It's enormous."
Scena: [DEDICATA] pet in posa da eroe davanti al palazzo che crolla dietro, palla da demolizione al fianco

## Missione 54: The Terrible Twins
Brief: Slingshots, glue in the fur, one missing hamster: the terrible twins from the penthouse upstairs await their next victim.
- Luogo: 📍 Rich Neighbors' Penthouse
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Carisma
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=carisma ; stadio=adulto

**Standard** — +3 Charisma, +40 coins
Dati: reward= carisma+3, monete+40, fel+5
Testo: "Babysitting the terrible twins from upstairs is a combat deployment: slingshots, glue in the fur, one missing hamster. But you get them to sleep and the place is (mostly) intact."
Scena: pet stremato tra due cuccioli scatenati che finalmente dormono

**Fallimento** (condizione: Carisma ≤15) — −10 coins (damages), "Biscotto" (food, Charisma+1)
Dati: cond= carisma<=15 ; reward= monete-10, cibo:Biscotto, fel-5
Testo: "Within the hour the penthouse is a war zone: chandelier down, couch flipped, cat on the ceiling — don't ask how, even the cat doesn't know. The twins, fresh as daisies, give you the look of two professionals who are just warming up. The parents come home, tally the damage, dock it from your pay, and send you off with a single cookie. The cat, for the record, is still up there."
Scena: pet sepolto sotto giocattoli e caos in un attico devastato, due cuccioli che ridono

**Super successo** (condizione: Carisma 32+; via alt Gentile + talento La Nonna Ti Vede; via alt Gentile + talento Coccolone) — +5 Charisma, +80 coins, "Trofeo Miglior Babysitter" (bedroom furniture, +2 Charisma)
Dati: cond= carisma>=32 | (gentile & talento:lanonnativede) | (gentile & talento:coccolone) ; reward= carisma+5, monete+80, arredo:Trofeo Miglior Babysitter, fel+10
Testo: "You tame them with the perfect blend of authority and sweetness (or the mysterious grandma appears and has them domesticated in four minutes flat). The parents come home to a spotless house and two angelic kids: you're a babysitting legend."
Scena: [DEDICATA] pet che riceve un trofeo dai genitori increduli, gemelli composti e sorridenti

## Missione 55: Orbital Delivery
Brief: The space elevator's busted, and that package still needs delivering — in orbit, zero gravity included.
- Luogo: 📍 Orbiting Station
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Tag: spazio
- Durata: 2h
- Costo: 20 monete
- Dati: durata=2h ; costo=20 ; categoria=consegne ; stat=velocita ; tag=spazio ; stadio=adulto

**Standard** — +3 Speed, +50 coins
Dati: reward= velocita+3, monete+50, fel+5
Testo: "The package needs delivering to orbit, and the space elevator is out of order. You improvise your way up, collect a zero-gravity signature, and float back down with the vertigo and the paycheck."
Scena: pet in tuta spaziale che consegna un pacco a una stazione orbitante, Terra sullo sfondo

**Fallimento** (condizione: Velocità ≤15) — −10 coins, "Sushi" (food, Speed+2)
Dati: cond= velocita<=15 ; reward= monete-10, cibo:Sushi, fel-5
Testo: "You let go for one instant — ONE instant — and the package floats off into deep space with the slow elegance of things lost forever. You watch it shrink and you'd swear it's waving goodbye. You come back empty-handed, and the fine arrives with perfect punctuality. But from up there you saw the whole planet: nobody's docking THAT from your pay."
Scena: pet che guarda impotente un pacco allontanarsi tra le stelle

**Super successo** (condizione: Velocità 32+; auto anche con perk Astronauta [spazio]) — +5 Speed, +80 coins, perk Pony Express Galattico (Consegne category: no failures + always super success on Consegne missions), "Casco da Corriere Spaziale" (wearable, +2 Speed)
Dati: cond= velocita>=32 ; reward= velocita+5, monete+80, perk:ponyexpressgalattico, indossabile:Casco da Corriere Spaziale, fel+10
Testo: "You dodge orbital debris, slingshot off gravity itself, and deliver the package ten minutes ahead of the galactic record. They name you official courier of the solar system."
Scena: [DEDICATA] pet che sfreccia tra le stelle col pacco, stazione orbitante che applaude

## Missione 56: The Cursed Package
Brief: A package that vibrates and whispers is waiting at the last address on the map — open it or don't, that's on you.
- Luogo: 📍 Last Address on the Map
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Tag: paranormale
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=consegne ; stat=velocita ; tag=paranormale,companion ; stadio=adulto

**Standard** — +3 Speed, +40 coins
Dati: reward= velocita+3, monete+40, fel+5
Testo: "A package that vibrates, whispers, and strongly advises against being opened. You do your job and deliver it WITHOUT opening it, like a professional. Well done, you."
Scena: pet che consegna un pacco inquietante e pulsante a una porta buia

**Fallimento** (condizione: Velocità ≤15) — "Biscotto" (food, Charisma+1), −10 Happiness
Dati: cond= velocita<=15 ; reward= cibo:Biscotto, fel-10
Testo: "You open it. Of course you open it: it said DO NOT OPEN, which to you is an invitation with an RSVP. The thing that comes out stares at you, files you under a category, and decides to follow you home every night for three days — only to make noises at 3 AM, though. Small-town curses. You're left with a cookie, a chill down your spine, and the absolute certainty that you'd open it again."
Scena: pet terrorizzato mentre un'ombra esce dal pacco aperto

**Super successo** (condizione: Velocità 32+; auto anche con perk Acchiappafantasmi [paranormale]; via alt Maleducato + talento Il Sonno degli Ingiusti) — +5 Speed, +70 coins, tamed "Pacco Maledetto" (bedroom furniture, +2 to a random RPG stat every day)
Dati: cond= velocita>=32 | (maleducato & talento:ilsonnodegliingiusti) ; reward= velocita+5, monete+70, arredo:Pacco Maledetto, fel+10
Testo: "You deliver in record time without a single flinch (or you nap on top of it so peacefully that the curse, deeply offended, leaves on its own). In the end the package decides it likes you and tames itself: every day it gifts you a different kind of energy."
Scena: [DEDICATA] pet che tiene in braccio un pacco ora docile e luminoso, che gli fa le fusa

## Missione 57: The Exploding Chili Pepper Fair
Brief: The exploding chili fair is set up in the square: real fire, real tears, and a crowd hungry for drama.
- Luogo: 📍 Fairground Square
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Tag: cucina, gara
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza ; tag=cucina,gara ; stadio=adulto

**Standard** — +3 Strength, +25 coins, "Salsa Infernale" (food, Strength+2)
Dati: reward= forza+3, monete+25, cibo:Salsa Infernale, fel+5
Testo: "The exploding chili eating contest is a painful rite of passage. You hang on until the semifinals through tears and gulps of air, and keep yourself a stash of hellfire sauce."
Scena: pet paonazzo che addenta un peperoncino gigante, pubblico che soffia via il fumo

**Fallimento** (condizione: Forza ≤15, oppure Sportivo + talento Fissato con la Dieta) — milk + "Biscotto" (food, Charisma+1)
Dati: cond= forza<=15 | (sportivo & talento:fissatoconladieta) ; reward= cibo:Latte, cibo:Biscotto, fel-5
Testo: "First chili: proud smile. Second chili: you see your ancestors, and your ancestors advise you to stop (or, if you're watching your macros, you refuse from the start: 'that is NOT food, it's a weapon with a stem'). The contest carries on while you breathe fire in a corner to warm applause. They put out your inner inferno with a liter of milk and a cookie. The reigning champion, a tiny grandpa, winks at you."
Scena: pet con la lingua di fuori che tracanna latte, pubblico che ride

**Super successo** (condizione: Forza 32+; auto anche con perk Masterchef [cucina] o Sabotatore [gara]; via alt Maleducato + talento Chissenefrega) — +5 Strength, +60 coins, "Cintura del Peperoncino" (wearable, +2 Strength)
Dati: cond= forza>=32 | (maleducato & talento:chissenefrega) ; reward= forza+5, monete+60, indossabile:Cintura del Peperoncino, fel+10
Testo: "You devour the deadliest chili at the fair without blinking (to you, pain is an abstract concept). The crowd crowns you champion and buckles on the chili pepper belt, red as your rivals' faces."
Scena: [DEDICATA] pet trionfante con la cintura del peperoncino, avversari sconfitti a bocca aperta

## Missione 58: The Phantom of the Opera House
Brief: For a century a phantom has sabotaged every show at the opera house, and tonight it's your turn on that cursed stage.
- Luogo: 📍 Opera House
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: paranormale, musica
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=paranormale,musica ; stadio=adulto

**Standard** — +3 Charisma, +35 coins
Dati: reward= carisma+3, monete+35, fel+5
Testo: "A phantom has sabotaged every show at the opera house for a century. You climb onto the cursed stage, sing his aria, and talk him into making peace with the audience. Curtain, applause."
Scena: pet che canta su un palco d'opera mentre un fantasma lo osserva dal loggione

**Fallimento** (condizione: Carisma ≤15) — "Torta intera" (food, Charisma+3)
Dati: cond= carisma<=15 ; reward= cibo:Torta intera, fel-5
Testo: "Your high C comes out like a broken intercom, and from the gallery the phantom boos you: heckled by a dead guy, in front of a full house. Even the prompter hides in the pit. You flee backstage chased by an echo of laughter from beyond the grave. Someone merciful left a cake on the prop trunk: the theater may be cruel, but it has style."
Scena: pet mortificato sul palco mentre un fantasma fischia dall'alto

**Super successo** (condizione: Carisma 32+; auto anche con perk Acchiappafantasmi [paranormale] o Singer [musica]; via alt Nerd + talento Galaxy Brain) — +5 Charisma, +70 coins, "Spartito Maledetto" (bedroom furniture, +2 Charisma)
Dati: cond= carisma>=32 | (nerd & talento:galaxybrain) ; reward= carisma+5, monete+70, arredo:Spartito Maledetto, fel+10
Testo: "You memorize the cursed aria in a single night and duet it with the phantom in a finale that raises real goosebumps. The theater shakes with applause (living and otherwise), and the phantom, finally at peace, gifts you his score."
Scena: [DEDICATA] pet e fantasma che cantano insieme sul palco, teatro in piedi ad applaudire

## Missione 59: Tour de Pizza
Brief: Twenty pizzas, half the city, thirty minutes on the clock: the Tour de Pizza waits for no one.
- Luogo: 📍 Harbor Pizzeria
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Tag: cucina
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=consegne ; stat=velocita ; tag=cucina ; stadio=adulto

**Standard** — +3 Speed, +40 coins, "Pizza" (food, +1 random stat)
Dati: reward= velocita+3, monete+40, cibo:Pizza, fel+5
Testo: "Twenty pizzas, half the city, thirty minutes or it's free: the Tour de Pizza is a race against a cooling oven. You deliver almost all of them hot, and keep one for yourself."
Scena: pet in motorino carico di pizze che sfreccia per la città al tramonto

**Fallimento** (condizione: Velocità ≤15) — −10 coins, "Pizza Ananassa" (food, +40 Hunger but Charisma−2)
Dati: cond= velocita<=15 ; reward= monete-10, cibo:Pizza Ananassa, fel-5
Testo: "You blast off the line, but traffic, an aggressive dog, and a shortcut that lied eat up your entire lead. You arrive with pizzas as cold and floppy as wet cardboard: the customers lift a slice, watch it droop, and refuse to pay. You eat your disappointment — at least THAT'S still warm. You do take one (cold) pizza home anyway: the one nobody claimed, the one with pineapple on it. Reheated, it's nearly edible."
Scena: pet mogio con una torre di scatole di pizza floscia, cliente contrariato sulla porta

**Super successo** (condizione: Velocità 32+; auto anche con perk Pony Express Galattico [Consegne]; via alt perk Masterchef) — +5 Speed, +80 coins, "Portapizze d'Oro" (kitchen furniture, +2 Speed)
Dati: cond= velocita>=32 ; reward= velocita+5, monete+80, arredo:Portapizze d'Oro, fel+10
Testo: "You deliver all twenty pizzas piping hot in record time, re-firing the cooling ones right on the scooter (if you know your way around a kitchen). The pizzeria names you courier of the year and hands you a golden pizza carrier."
Scena: [DEDICATA] pet trionfante col portapizze d'oro, clienti felici con pizze fumanti

## Missione 60: Meteorite Alert
Brief: The countdown's already running at the observatory: a meteorite is headed straight for the neighborhood.
- Luogo: 📍 Hilltop Observatory
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: spazio, invenzione
- Durata: 2h
- Costo: 20 monete
- Dati: durata=2h ; costo=20 ; categoria=studio ; stat=int ; tag=spazio,invenzione ; stadio=adulto

**Standard** — +3 Int, +50 coins, "Frammento di Meteorite" (living room furniture, +2 Int)
Dati: reward= int+3, monete+50, arredo:Frammento di Meteorite, fel+5
Testo: "A meteorite is headed straight for the neighborhood and it's on you to calculate the deflection. Trajectory corrected at the last second: the cosmic rock misses the city by a whisker and leaves you a fragment as a tip."
Scena: pet all'osservatorio davanti a calcoli e a un meteorite in avvicinamento nel cielo

**Fallimento** (condizione: Intelligenza ≤15) — Wounds +10, "Zuppa di verdure" (food, Int+2)
Dati: cond= int<=15 ; reward= ferite+10, cibo:Zuppa di verdure, fel-5
Testo: "You botch the trajectory math with the confidence of the greats: one decimal here, one catastrophe there. Luckily the meteorite botches it too — it snubs the neighborhood and belly-flops into the sea to a round of applause. Your contribution to planetary salvation: zero, but the terror was one hundred percent real. You walk away with a few scrapes and a bowl of soup for the nerves: saved by luck, not by merit. Happens to the best of us."
Scena: pet che si copre la testa mentre un meteorite sfreccia via, calcoli sbagliati sparsi

**Super successo** (condizione: Intelligenza 32+; auto anche con perk Astronauta [spazio] o talento Inventore [invenzione]; via alt Sportivo + talento Furia Cieca con Felicità <30) — +5 Int, +90 coins, "Nucleo del Meteorite" (living room furniture, +2 to a random RPG stat every day)
Dati: cond= int>=32 | (sportivo & talento:furiacieca & fel<30) ; reward= int+5, monete+90, arredo:Nucleo del Meteorite, fel+10
Testo: "You calculate the perfect deflection with textbook safety margins (or, if you're angry enough, you climb onto the roof and PUNCH IT BACK INTO SPACE). The neighborhood is safe and you keep the meteorite's core, pulsing with alien energy."
Scena: [DEDICATA] pet eroe che tiene in mano un nucleo di meteorite luminoso, cittadini che esultano

## Missione 61: The Citywide Treasure Hunt
Brief: A hundred rivals, one whole city, a single treasure: the hunt starts now and nobody plays fair.
- Luogo: 📍 The Whole City
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: mistero, inseguimento
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=mistero,inseguimento ; stadio=adulto

**Standard** — +3 Speed, +35 coins, "Mappa Incorniciata" (living room furniture, +1 Speed +1 Int)
Dati: reward= velocita+3, monete+35, arredo:Mappa Incorniciata, fel+5
Testo: "A citywide treasure hunt, with a hundred other contestants breathing down your neck. You race from clue to clue and finish on the podium, with a map worth framing as a souvenir."
Scena: pet che corre con una mappa in mano tra i vicoli, altri concorrenti alle spalle

**Fallimento** (condizione: Velocità ≤15) — "Sushi" (food, Speed+2)
Dati: cond= velocita<=15 ; reward= cibo:Sushi, fel-5
Testo: "Second at the first clue, second at the third, second at ALL of them: same rival, same razor-thin margin every time, a form of sporting torture designed by some mischievous deity. At the finish line the treasure goes to him, along with a smirk you'll be carrying around for a long, long time. You're left with some sushi, a mountain of frustration, and a map of a city you now know too well. Second place is just the first of the... no, never mind."
Scena: pet col fiatone che arriva a un indizio già preso da un rivale che esulta

**Super successo** (condizione: Velocità 32+; auto anche con perk Parkour Master [inseguimento]; via alt perk Doc Brown) — +5 Speed, +70 coins, "Forziere del Tesoro" (living room furniture, +2 Speed)
Dati: cond= velocita>=32 ; reward= velocita+5, monete+70, arredo:Forziere del Tesoro, fel+10
Testo: "You blaze from clue to clue ahead of everyone (or you crack the LAST riddle before even reading the first, if your brain is wired right). The chest is yours, and a hundred contestants get to eat your dust."
Scena: [DEDICATA] pet che apre un forziere luminoso per primo, rivali distanti che arrancano

## Missione 62: The Basement Colony
Brief: Something's moved into the basement: a colony of tiny garbage-monsters nobody can quite explain yet.
- Luogo: 📍 Building Basement
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: mostro
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=studio ; stat=int ; tag=mostro,companion ; stadio=adulto

**Standard** — +3 Int, +30 coins
Dati: reward= int+3, monete+30, fel+5
Testo: "A colony of tiny garbage-monsters has hatched in the basement, and before evicting them someone has to figure out what they are. You catalog them with rigorous scientific method, then gently redirect them elsewhere."
Scena: pet con lente e taccuino che studia minuscole creaturine tra i rottami di una cantina

**Fallimento** (condizione: Intelligenza ≤15) — −10 coins (damages), "Biscotto" (food, Charisma+1)
Dati: cond= int<=15 ; reward= monete-10, cibo:Biscotto, fel-5
Testo: "You study them with scientific patience; they study you with superior patience. While you're busy taking notes, the entire colony relocates into your fridge, which now hums with a life of its own and won't open without negotiations. The building docks the damages from your pay and kindly begs you to stop 'helping'. They do give you cookies — on the condition that you eat them far away from the basement."
Scena: pet sconcertato che apre un frigo brulicante di micro-mostri

**Super successo** (condizione: Intelligenza 32+; auto anche con perk Cacciatore di Mostri [mostro] o Doc Brown [Studio]) — +5 Int, +60 coins, "Micro-Mostro Regina" companion (bedroom furniture, +2 Int flat)
Dati: cond= int>=32 ; reward= int+5, monete+60, arredo:Micro-Mostro Regina, fel+10
Testo: "You identify every species by eye, map their hierarchy, and establish communication with the colony's Queen, who decides to adopt you. You take her home: she's ugly, but she keeps the basement spotless and she's great company."
Scena: [DEDICATA] pet con una piccola creatura-regina sulla spalla, cantina ordinata alle spalle

## Missione 63: The Great Blackout
Brief: Total blackout, the whole neighborhood dark: the generator needs muscle tonight, no way around it.
- Luogo: 📍 Neighborhood Power Plant
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=forza ; stadio=adulto

**Standard** — +3 Strength, +45 coins, −10 Hygiene
Dati: reward= forza+3, monete+45, igiene-10, fel+5
Testo: "Total blackout, neighborhood in the dark, and a generator that needs restarting by raw muscle. You crank rusty gears all night long until the lights come back, greased up to the elbows."
Scena: pet che gira una manovella gigante di un generatore, quartiere buio sullo sfondo

**Fallimento** (condizione: Forza ≤15) — Wounds +15, "Arrosto" (multi-serving food, ×3 Strength+1)
Dati: cond= forza<=15 ; reward= ferite+15, cibo:Arrosto, fel-5
Testo: "The generator's flywheel is more stubborn than you are, and on the third push it flings you into a wall with mechanical nonchalance. The neighborhood stays dark, you stay flattened, the generator stays still: three defeats for the price of one. But the neighbors light candles, scoop you up, and patch you back together with grandma's roast. In the dark, it tastes even more like home."
Scena: pet steso accanto a un generatore fermo, vicini con candele e un arrosto

**Super successo** (condizione: Forza 32+; via alt Gentile + talento Cuore di Casa) — +5 Strength, +80 coins, "Generatore di Scorta" (living room furniture, +2 Strength)
Dati: cond= forza>=32 | (gentile & talento:cuoredicasa) ; reward= forza+5, monete+80, arredo:Generatore di Scorta, fel+10
Testo: "You wrench the generator back to life with one herculean pull and the lights explode back on (or, if you're the warm-hearted type, you open your home to everyone and the blackout becomes the party of the year). The neighborhood gifts you a backup generator all your own."
Scena: [DEDICATA] pet eroe illuminato dalle luci tornate, quartiere che esulta alle finestre

## Missione 64: The Scrapheap Regatta
Brief: At the Old Harbor they race boats built from junk — the only rule is that none of them should really float.
- Luogo: 📍 Old Harbor
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara, invenzione, natura
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sport ; stat=velocita ; tag=gara,invenzione,natura ; stadio=adulto

**Standard** — +3 Speed, +35 coins, "Timone di Fortuna" (bathroom furniture, +2 Speed)
Dati: reward= velocita+3, monete+35, arredo:Timone di Fortuna, fel+5
Testo: "One rule at the Scrapheap Regatta: you build your boat out of junk. Yours — half a bathtub and a wardrobe door — floats by sheer miracle and finishes mid-pack. The helm's yours to keep."
Scena: pet al timone di una barca fatta di rottami, altre imbarcazioni ridicole intorno

**Fallimento** (condizione: Velocità ≤15) — "Sushi" (food, Speed+2)
Dati: cond= velocita<=15 ; reward= cibo:Sushi, fel-5
Testo: "Your boat has one tiny design flaw, barely a footnote: it doesn't float. You discover this three meters from the dock, in front of everyone, sinking with the elegance of a rock. The regatta carries on without you while you befriend the harbor seaweed. They fish you out with the big net — the one for special cases — and wrap you in a towel with some sushi. Your boat rests on the seabed, undefeated."
Scena: pet zuppo avvolto in un asciugamano sul molo, la sua barca che affonda dietro

**Super successo** (condizione: Velocità 32+; auto anche con Sabotatore [gara] o talento Inventore [invenzione]; via alt perk Popeye) — +5 Speed, +70 coins, "Vela Leggendaria" (living room furniture, +2 Speed +1 Happiness)
Dati: cond= velocita>=32 ; reward= velocita+5, monete+70, arredo:Vela Leggendaria, fel+10
Testo: "Your junk-heap has no business floating and instead it FLIES, shaving every buoy by a whisker (or, mid-race with dead wind, you crack open the spinach stash and paddle her back up front like an outboard motor). The harbor still tells the tale of that day."
Scena: [DEDICATA] pet che taglia il traguardo in piedi sulla sua carretta, vela rattoppata gonfia, porto in delirio

---

# GRANDI IMPRESE — il finale della run (P3; 1 estratta a caso tra le 2 della personalità, pin fisso sulla mappa da adulto)

## Missione 65: The Gym of the Gods
Brief: At the summit of Mount Jawline stands HIM: Giga Ciad, jaw to the wind, ready to judge you with a single glance.
- Luogo: 📍 Mount Jawline
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Forza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=forza ; stadio=adulto ; impresa=1 ; personalita=sportivo ; ritenta=1

**Fallimento** (condizione: Forza <50) — "Bistecca" ×2
Dati: cond= forza<50 ; reward= cibo:Bistecca, cibo:Bistecca, fel-5
Testo: "At the summit of Mount Jawline stands HIM: Giga Ciad, jaw to the wind, lifting a boulder with his pinky. You try to copy him and the boulder doesn't move a millimeter. Giga Ciad looks at you, nods slowly, and hands you two steaks: 'Return when you are ready, little king.'"
Scena: pet minuscolo che spinge un macigno immobile, Giga Ciad gigantesco in controluce che annuisce

**Standard** — +5 Strength, +150 coins, Medaglia dell'Impresa
Dati: reward= forza+5, monete+150, fel+5
Testo: "You lift the boulder. Not with grace, not without concerning noises from your spine, but you lift it. Giga Ciad sheds a single alpha tear and declares you 'worthy of the Gym of the Gods'. The jawline, he swears, will come in time."
Scena: pet che regge un macigno sopra la testa al tramonto, Giga Ciad che applaude lento

**Super successo** (condizione: Forza 70+; via alt Carisma 45+ — la gara di pose) — +5 Strength, +150 coins, Giga Ciad companion (+3 Strength flat), "Bistecca Salabraccio d'Oro" (food, Strength+4 Charisma+1)
Dati: cond= forza>=70 | carisma>=45 ; reward= forza+5, monete+150, arredo:Giga Ciad, cibo:Bistecca Salabraccio d'Oro, fel+10
Testo: "Either you lift the boulder ONE-HANDED, or you beat him at his own game: the pose-off. Profile, three-quarters, gaze fixed on the horizon. Giga Ciad tears up in black and white: 'Have not seen such a pose since 1987. Brother. Worthy.' To celebrate, he carves a gold-plated steak and lets the salt slide down his forearm with a slowness that borders on prayer. From today, he trains at your place."
Scena: [DEDICATA] pet in posa plastica su un piedistallo, Giga Ciad in bianco e nero che si asciuga una lacrima

## Missione 66: The Final Round
Brief: Rocco Baldoria's ninety years old with gloves older than you — and the Old Harbor ring shows zero mercy.
- Luogo: 📍 Old Harbor Arena
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Forza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=forza ; stadio=adulto ; impresa=1 ; personalita=sportivo ; ritenta=1

**Fallimento** (condizione: Forza <50) — Wounds +12, "Zuppa della nonna" ×2
Dati: cond= forza<50 ; reward= ferite+12, cibo:Zuppa della Nonna, cibo:Zuppa della Nonna, fel-5
Testo: "Rocco Baldoria is ninety years old with gloves older than you. By round three you're on the canvas counting chandeliers. He pulls you up and puts a bowl of soup in your hands: 'It ain't about how hard you hit, kid. Try again.'"
Scena: pet al tappeto che vede le stelle, Rocco anziano chinato su di lui col guantone teso

**Standard** — +5 Strength, +150 coins, Medaglia dell'Impresa
Dati: reward= forza+5, monete+150, fel+5
Testo: "Final round. Your legs are jelly, the arena's roaring, Rocco hits like a vintage freight train. But this time you're still standing at the bell. He lowers his gloves and smiles: 'You got a nice right hook, kid. But more than that — you got a nice WHY.'"
Scena: pet e Rocco al centro del ring alla campana finale, folla in delirio

**Super successo** (condizione: Forza 70+; via alt talento Veterano del Ring — incassare, non colpire) — +5 Strength, +150 coins, Rocco Baldoria companion (+3 Strength flat)
Dati: cond= forza>=70 | talento:veteranodelring ; reward= forza+5, monete+150, arredo:Rocco Baldoria, fel+10
Testo: "You don't win on points: you win on LEGEND. You take everything he's got, round after round, never stepping back — and in the end it's HIM who takes off the gloves. 'Sixty years in this game, kid, and I ain't never seen nobody take a beating like that. I'm training you myself. At your place.'"
Scena: [DEDICATA] Rocco che alza il braccio del pet al cielo, guantoni appesi alle corde

## Missione 67: The Skyscraper Exorcism
Brief: The Cursed Skyscraper screams from the fortieth floor up, and Padre Maronno's waiting right at the door.
- Luogo: 📍 Cursed Skyscraper
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Carisma
- Tag: paranormale
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=carisma ; tag=paranormale ; stadio=adulto ; impresa=1 ; personalita=gentile ; ritenta=1

**Fallimento** (condizione: Carisma <50) — "Biscotto" ×3
Dati: cond= carisma<50 ; reward= cibo:Biscotto, cibo:Biscotto, cibo:Biscotto, fel-5
Testo: "Padre Maronno looks you up and down: 'MARONN'! You want to TALK to the demons on the fortieth floor? They do not talk: they SCREAM.' By the tenth floor you're running for the exit with your ears ringing. The ghosts, feeling bad about it, leave cookies for you in the elevator."
Scena: pet che schizza fuori dal portone del grattacielo, finestre che lampeggiano viola

**Standard** — +5 Charisma, +150 coins, Medaglia dell'Impresa
Dati: reward= carisma+5, monete+150, fel+5
Testo: "Floor by floor, demon by demon: you listen, you nod, you offer tea. On the top floor the Head Demon signs the peace treaty and Padre Maronno is left (nearly) speechless: 'MARONN'... thirty years in the business, and never — NEVER — an exorcism by KIND WORDS.'"
Scena: pet che serve il tè a un demone enorme all'attico, Padre Maronno a bocca aperta sulla porta

**Super successo** (condizione: Carisma 70+; via alt talento Santo Subito — un miracolo al momento giusto) — +5 Charisma, +150 coins, Padre Maronno companion (+3 Charisma flat)
Dati: cond= carisma>=70 | talento:santosubito ; reward= carisma+5, monete+150, arredo:Padre Maronno, fel+10
Testo: "The demons don't leave: they RELOCATE — good manners, proper lease, floor -1. Padre Maronno crosses himself twice: 'This is not an exorcism, this is a real estate MIRACLE. MARONN'! You and me, from this day on, we work together.'"
Scena: [DEDICATA] Padre Maronno e pet davanti al grattacielo pacificato, demoni che salutano dalle finestre

## Missione 68: The Endless Run
Brief: Forrest Gampo's been running non-stop for three years down the Sunset Highway: today it's your turn to keep up.
- Luogo: 📍 Sunset State Highway
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Carisma
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=carisma ; stadio=adulto ; impresa=1 ; personalita=gentile ; ritenta=1

**Fallimento** (condizione: Carisma <50) — "Scatola di Cioccolatini"
Dati: cond= carisma<50 ; reward= cibo:Scatola di Cioccolatini, fel-5
Testo: "Forrest Gampo has been running for three years and people follow him because... well, because he's Forrest. You try to join the pack, but ten kilometers in nobody remembers your name. Forrest slows down and hands you a box: 'Life is like a box of chocolates. Try again tomorrow.'"
Scena: pet piegato in due sul ciglio della statale, il gruppo di corridori che si allontana nel tramonto

**Standard** — +5 Charisma, +150 coins, Medaglia dell'Impresa
Dati: reward= carisma+5, monete+150, fel+5
Testo: "You run beside Forrest for a whole day, and the strange thing happens: people start following YOU. At the end of the highway a small crowd is chanting your name. Forrest nods: 'You run good. But mostly, people BELIEVE you.'"
Scena: pet in testa a un gruppo di corridori al tramonto, Forrest che sorride in seconda fila

**Super successo** (condizione: Carisma 70+; via alt Velocità 45+ — la build del corridore) — +5 Charisma, +150 coins, Forrest Gampo companion (+3 Speed flat)
Dati: cond= carisma>=70 | velocita>=45 ; reward= carisma+5, monete+150, arredo:Forrest Gampo, fel+10
Testo: "Halfway down the road, Forrest stops dead, just like that famous day. He turns to the crowd, then to you: 'I'm pretty tired. You keep going.' And the endless run, from today, carries your name. Forrest follows you home: he says you remind him of somebody."
Scena: [DEDICATA] Forrest che passa idealmente il testimone al pet in mezzo alla statale, folla commossa

## Missione 69: The Photo of the Century
Brief: One photo, one fortune: Fabrice The Crown's locked himself in the Royal Suite, and security means business.
- Luogo: 📍 Royal Suite, Hotel Splendido
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Velocità
- Tag: inseguimento, social
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=velocita ; tag=inseguimento,social ; stadio=adulto ; impresa=1 ; personalita=maleducato ; ritenta=1

**Fallimento** (condizione: Velocità <50) — fine −20 coins, "Foto Autografata di Fabrice" (furniture, +1 Charisma)
Dati: cond= velocita<50 ; reward= monete-20, arredo:Foto Autografata di Fabrice, fel-5
Testo: "Fabrice The Crown wants THE photo: the most unreachable star on the planet, holed up in the Royal Suite. You launch into the chase but security nabs you in the second hallway. Fabrice, as a consolation prize, autographs a photo of HIMSELF: 'PAURINA, huh? Happens to the best.'"
Scena: pet trascinato via da due buttafuori giganti, Fabrice che firma una foto con ghigno da paparazzo

**Standard** — +5 Speed, +150 coins, Medaglia dell'Impresa
Dati: reward= velocita+5, monete+150, fel+5
Testo: "Service stairs, air duct, laundry cart: you reach the Royal Suite from a direction that doesn't even exist on the blueprints. CLICK. The photo of the century is yours, and Fabrice gives you a look of pure professional respect: 'Paurina. REAL PAURINA.'"
Scena: pet appeso al lampadario della suite con la macchina fotografica, flash che illumina tutto

**Super successo** (condizione: Velocità 70+; via alt talento Faccia di Bronzo — bussa alla suite e chiede un selfie) — +5 Speed, +150 coins, Fabrice The Crown companion (+3 Charisma flat)
Dati: cond= velocita>=70 | talento:facciadibronzo ; reward= velocita+5, monete+150, arredo:Fabrice The Crown, fel+10
Testo: "Either you're a lightning bolt no bodyguard can stop, or you pull the most absurd move of all: you KNOCK. 'Hi, I'm here for the selfie.' The star is so blindsided they say yes. Fabrice watches you work, and something inside him breaks: 'You are my heir. PAURINA!' From today, he works with you."
Scena: [DEDICATA] selfie a tre — pet, la star misteriosa e Fabrice che fa le corna dietro, flash dorato

## Missione 70: It's Over Nine Thousand
Brief: 'Let's see this power level of yours' — Veggeta's waiting in the Suburban Crater, scouter already blinking.
- Luogo: 📍 Suburban Crater
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: la più alta (statMax)
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=qualsiasi ; stadio=adulto ; impresa=1 ; personalita=maleducato ; ritenta=1

**Fallimento** (condizione: statMax <50) — "Insalatona" ×2
Dati: cond= statMax<50 ; reward= cibo:Insalatona, cibo:Insalatona, fel-5
Testo: "Veggeta awaits you in the crater, scouter blinking: 'Let's see this power level of yours.' BEEP. The scouter shows a number so low that Veggeta reads it aloud three times, laughing to himself. 'Eat. A LOT. And come back when the scouter stops laughing too, insect.'"
Scena: pet nel cratere, Veggeta di spalle che ride col visore in mano

**Standard** — +5 to your highest stat, +150 coins, Medaglia dell'Impresa
Dati: reward= statmax+5, monete+150, fel+5
Testo: "The scouter climbs, climbs, CLIMBS. Veggeta stops laughing. 'Impossible. IMPOSSIBLE!' He crushes it in his gloved fist, as tradition demands. 'You're not bad, insect. Not bad AT ALL.' Coming from him, that's a love letter."
Scena: Veggeta che frantuma il visore, pet in posa da combattimento tra i detriti

**Super successo** (condizione: statMax 70+; via alt talento Bad Loser — perde il 1° round ed esplode di rabbia: visore in errore) — +5 to your highest stat, +150 coins, Veggeta companion (+3 Strength flat)
Dati: cond= statMax>=70 | talento:badloser ; reward= statmax+5, monete+150, arredo:Veggeta, fel+10
Testo: "IT'S OVER NINE THOUSAND. The scouter explodes, the crater gets wider, and Veggeta goes silent for the first time in his life. Then he crosses his arms and looks away: 'I'll... train at your place. Don't make a thing of it, insect. It's only because your house is closer to the crater.'"
Scena: [DEDICATA] visore in mille pezzi a terra, Veggeta a braccia incrociate accanto al pet, aura dorata

## Missione 71: The Theorem of Everything
Brief: Apartment 4A, whiteboards everywhere: Sceldon guards his couch spot fiercer than his own equations.
- Luogo: 📍 Apartment 4A
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Intelligenza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=int ; stadio=adulto ; impresa=1 ; personalita=nerd ; ritenta=1

**Fallimento** (condizione: Intelligenza <50) — "Caffettiera Bruciacchiata" (kitchen furniture, +1 Int)
Dati: cond= int<50 ; reward= arredo:Caffettiera Bruciacchiata, fel-5
Testo: "Sceldon opens the door to Apartment 4A: 'Sit down. NO — that's my spot.' The whiteboard is covered in symbols that glare at you. Eight hours later, the only thing you've figured out is how to turn on the coffee maker — so he gifts it to you: 'Your contribution to science. Bazzinga.'"
Scena: pet perso davanti a una lavagna infinita, Sceldon che indica il SUO posto sul divano

**Standard** — +5 Intelligence, +150 coins, Medaglia dell'Impresa
Dati: reward= int+5, monete+150, fel+5
Testo: "Eight hours of equations, three whiteboards, one argument about the couch spot. But by the end, the Theorem of Everything has ONE more line, and you wrote it. Sceldon stares at it for a long time: 'It's not wrong. It's not WRONG. That is the highest compliment I have ever given.'"
Scena: pet e Sceldon davanti alla lavagna completata, gessetto ancora a mezz'aria

**Super successo** (condizione: Intelligenza 70+; via alt talento Overclock — calcola tutta la notte fumando dai circuiti) — +5 Intelligence, +150 coins, Sceldon companion (+3 Intelligence flat)
Dati: cond= int>=70 | talento:overclock ; reward= int+5, monete+150, arredo:Sceldon, fel+10
Testo: "You close the Theorem of Everything. EVERYTHING. Sceldon staggers, sits in the wrong spot without noticing, and utters the words no human has ever heard: 'You were right.' Then he moves in with you: he claims your couch has superior scientific potential."
Scena: [DEDICATA] lavagna col teorema completo che brilla, Sceldon seduto NEL POSTO SBAGLIATO, pet col gessetto alzato

## Missione 72: The Tin Suit
Brief: Tonino Stark's got a half-built suit and zero patience, up in the Rooftop Workshop where every tool matters.
- Luogo: 📍 Rooftop Workshop
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Intelligenza
- Tag: invenzione
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=int ; tag=invenzione ; stadio=adulto ; impresa=1 ; personalita=nerd ; ritenta=1

**Fallimento** (condizione: Intelligenza <50) — "Pizza"
Dati: cond= int<50 ; reward= cibo:Pizza, fel-5
Testo: "Tonino Stark has a suit to finish and zero patience: 'You. Intern. Hand me the fusion coupler. NO, that's a screwdriver.' Eight hours later the suit takes off with nobody in it and lands in the canal. Tonino orders a pizza: 'Genius can't be learned in a day. Pizza can.'"
Scena: armatura che vola via da sola dal tetto, Tonino e pet che la guardano sparire

**Standard** — +5 Intelligence, +150 coins, Medaglia dell'Impresa
Dati: reward= int+5, monete+150, fel+5
Testo: "Welds, circuits, a reactor making a sound that's concerning yet FASCINATING. The Tin Suit powers up, and this time it stays on the ground until you say otherwise. Tonino peers at you over his shades: 'Not bad, intern. Me my way, you your way... let's call it even.'"
Scena: armatura in piedi sul tetto che si illumina, Tonino e pet con le braccia incrociate davanti

**Super successo** (condizione: Intelligenza 70+; via alt Forza 45+ — piega i pezzi a mani nude) — +5 Intelligence, +150 coins, Tonino Stark companion (+3 Intelligence flat)
Dati: cond= int>=70 | forza>=45 ; reward= int+5, monete+150, arredo:Tonino Stark, fel+10
Testo: "Either you redesign the reactor from scratch, or you bend the plating with your BARE HANDS while Tonino watches in religious silence. The suit flies, lands, takes a bow. 'Okay, I'll admit it: I need a partner. How's the roof at your place?' Tonino Stark moves in."
Scena: [DEDICATA] armatura in volo col tramonto dietro, Tonino e pet sul tetto con due bibite, brindisi di latta

---
