window.PETQ = window.PETQ || {};

(function () {

  // Stato attivo per il recupero del tempo reale al ritorno in foreground (v. registraRipresa/
  // recuperaTempoReale sotto): il setInterval di clock.js si CONGELA quando l'app va in
  // background (mobile WebView Capacitor, o tab browser in background) e non si riavvia da solo
  // al ritorno, quindi serve un riferimento allo stato "vivo" per rifare il recupero offline.
  var statoAttivo = null;
  var ripresaRegistrata = false;

  function boot() {
    PETQ.content.load(function () {
      var state = PETQ.save.load();

      if (!state) {
        avviaIntro();
        return;
      }

      migraState(state);
      var rientro = catturaRientro(state);   // PRIMA del recupero: legge il "com'era"
      applicaDecadimentoOffline(state);
      // DOPO il recupero, PRIMA del login: l'orologio dei salvataggi vecchi si rimette in pari con
      // l'ora vera (solo in avanti, mai oltre mezzanotte — v. clock.js riallineaOraReale). Ripara
      // il ritardo accumulato dalle build pre-v250, che i fix non potevano riavvolgere.
      if (PETQ.clock && PETQ.clock.riallineaOraReale) PETQ.clock.riallineaOraReale(state);
      eseguiLoginGiornaliero(state);
      controllaCicloSonno(state);
      chiudiRientro(state, rientro);         // DOPO: le stat sono quelle di adesso
      PETQ.save.save(state);

      avviaTicking(state);
      renderIniziale(state);

      // Aggiornamenti OTA (ota.js): check silenzioso ad ogni avvio, forza=false — il throttle
      // (6h) sta TUTTO dentro controlla(), qui non serve nessuna guardia in piu'.
      if (PETQ.ota && PETQ.ota.controlla) PETQ.ota.controlla(false);
    });
  }

  // Controlla al boot/tick il ciclo sonno (GDD "Energia e sonno"): sveglia autonoma se sono
  // passate >=8h dall'inizio del sonno, altrimenti crollo automatico se sono le 23 e il pet e'
  // ancora sveglio. Le due funzioni sono mutuamente esclusive (una richiede state.sonno, l'altra
  // richiede !state.sonno) percio' l'ordine non conta ai fini della correttezza.
  //
  // FIX "il pet non saluta mai quando si sveglia" (fondatore, 3 ago 2026): PETQ.pet.controllaSveglia
  // CONSUMA il risveglio (mette state.sonno=null) e ritorna l'esito {battuta, moneteNotturne, ...},
  // ma questa funzione e' chiamata da TRE punti sotto (boot/tick/recuperaTempoReale) che ne
  // scartavano il valore di ritorno. La UI (ui.js controllaSonnoScaduto) chiama a sua volta
  // PETQ.pet.controllaSveglia PRIMA di ridisegnare, ma per allora state.sonno e' gia' null (appena
  // consumato qui) e non trova piu' nulla da mostrare: il fumetto della battuta e le monete
  // notturne sparivano nel nulla in OGNI percorso. Depositiamo l'esito in state.risveglioEsitoGiorno
  // — stesso schema "deposita ora, mostra al primo render utile" gia' usato da
  // state.companionEffettiGiorno/state.lavoroEsitoGiorno (care.js) — cosi' ui.js puo' consumarlo e
  // mostrarlo con una funzione controlla* dedicata (v. ui.js controllaRisveglioPendente).
  function controllaCicloSonno(state) {
    if (!state || !PETQ.pet) return null;
    var risveglio = PETQ.pet.controllaSveglia(state);
    if (risveglio) {
      state.risveglioEsitoGiorno = risveglio;
      return risveglio;
    }
    PETQ.pet.controllaCrolloAutomatico(state);
    return null;
  }

  // Sotto questa eta' (ms dalla creazione del pet) una partita si considera "appena iniziata
  // ora" anche se lo vediamo per la prima volta qui (es. primo refresh subito dopo l'intro):
  // non deve saltare il tutorial. Oltre questa soglia, un salvataggio senza i campi missioni
  // e' considerato pre-esistente (creato prima di questo modulo) e non deve piu' vedere il
  // tutorial. Vedi commento sotto per il perche' serve un'euristica invece di un flag diretto.
  var SOGLIA_PARTITA_APPENA_INIZIATA_MS = 10 * 60000; // 10 minuti

  // Migrazione silenziosa dei salvataggi pre-modulo-missioni (v. docs/SPEC-MODULO-MISSIONI.md
  // "Stato esteso"): i salvataggi esistenti hanno state.arredi:[] (array, formato vecchio mai
  // popolato nel prototipo) e nessuno dei campi nuovi (ferite, cureOggi, dispensa, missione,
  // categoriePastiOggi, tutorialFatto). Qui li aggiungiamo con i default della spec.
  //
  // Caso limite tutorialFatto: ui.js (fuori scope, non modificabile qui) crea le partite nuove
  // con lo stesso state.arredi:[] "vecchio formato" usato dai salvataggi pre-esistenti, quindi
  // non c'e' un campo strutturale che distingua "partita nuova mai passata da qui" da "salvataggio
  // di una partita vecchia". Si usa percio' l'eta' di state.pet.nascita rispetto ad ora: se il pet
  // e' stato creato da meno di SOGLIA_PARTITA_APPENA_INIZIATA_MS, e' quasi certamente la stessa
  // sessione appena creata da ui.js (il primo giro di boot() dopo un refresh arriva in pratica
  // subito dopo) e tutorialFatto parte false; altrimenti (pet piu' "vecchio" o assente) si tratta
  // di una partita gia' avviata prima del modulo missioni e tutorialFatto parte true.
  // Migrazione dispensa array-di-{nome} -> inventario array-di-{nome, qty}: stessa logica
  // duplicata in save.js (v. save.js migraDispensaAQty per il commento esteso), applicata
  // anche qui perche' main.js ha la sua migrazione indipendente eseguita al boot.
  function migraDispensaAQty(state) {
    if (!state || !Array.isArray(state.dispensa)) { if (state) state.dispensa = []; return; }
    var perNome = {};
    var ordine = [];
    for (var i = 0; i < state.dispensa.length; i++) {
      var voce = state.dispensa[i];
      var nome = typeof voce === 'string' ? voce : (voce && voce.nome);
      if (!nome) continue;
      var qty = (voce && typeof voce.qty === 'number' && voce.qty > 0) ? voce.qty : 1;
      if (!Object.prototype.hasOwnProperty.call(perNome, nome)) {
        perNome[nome] = 0;
        ordine.push(nome);
      }
      perNome[nome] += qty;
    }
    state.dispensa = ordine.map(function (nome) { return { nome: nome, qty: perNome[nome] }; });
  }

  function migraState(state) {
    if (!state) return;

    var haGiaCampiMissioni = typeof state.tutorialFatto === 'boolean';
    var etaPetMs = (state.pet && typeof state.pet.nascita === 'number') ? (Date.now() - state.pet.nascita) : Infinity;
    var eAppenaIniziata = etaPetMs < SOGLIA_PARTITA_APPENA_INIZIATA_MS;

    if (!state.arredi || typeof state.arredi !== 'object' || Array.isArray(state.arredi) ||
        !state.arredi.posseduti || !state.arredi.piazzati) {
      state.arredi = { posseduti: [], piazzati: { cucina: [], bagno: [], salone: [], camera: [] } };
    }
    // PROTOTIPO 2, Blocco 7: backfill 'camera' sui salvataggi vecchi (v. save.js migraState).
    if (state.arredi.piazzati && !Array.isArray(state.arredi.piazzati.camera)) {
      state.arredi.piazzati.camera = [];
    }
    if (typeof state.ferite !== 'number') state.ferite = 0;
    if (typeof state.cureOggi !== 'number') state.cureOggi = 0;
    migraDispensaAQty(state);
    if (typeof state.missione === 'undefined') state.missione = null;
    if (!state.missioniFatte || typeof state.missioniFatte !== 'object' || Array.isArray(state.missioniFatte)) {
      state.missioniFatte = {};
    }
    // Rotazione random missioni per run (P3): stessa sanificazione di save.js migraState (regola
    // duplicata qui come per missioniFatte sopra); solo FORMA, il contenuto lo fa il lazy init.
    if (!state.rotazioneMissioni || typeof state.rotazioneMissioni !== 'object' || Array.isArray(state.rotazioneMissioni)) {
      state.rotazioneMissioni = {};
    }
    // Impresa della run (P3, Grandi Imprese, missions.js impresaDellaRun): stessa sanificazione
    // duplicata in save.js migraState (v. li' per il commento esteso).
    if (typeof state.impresaRun === 'undefined') state.impresaRun = null;
    if (!Array.isArray(state.categoriePastiOggi)) state.categoriePastiOggi = [];
    // Pacing stat RPG (bilanciamento.md): contatore dei 2 pasti-con-stat/giorno (v. care.feed).
    if (typeof state.pastiStatOggi !== 'number') state.pastiStatOggi = 0;

    if (!haGiaCampiMissioni) {
      state.tutorialFatto = !eAppenaIniziata;
    }
    // Negozio unico (GDD "Economia" -> "Spesa e dispensa"): stessa regola di migrazione
    // duplicata in save.js/missions.js — tutorial gia' fatto = negozio gia' sbloccato (il
    // vecchio Market separato era comunque sempre accessibile).
    if (typeof state.negozioSbloccato !== 'boolean') {
      state.negozioSbloccato = !!state.tutorialFatto;
    }

    // Migrazione modulo Energia e sonno (v. save.js migraState, stessa regola duplicata qui
    // perche' main.js ha la sua migrazione indipendente eseguita al boot): energia parte a 70
    // come le altre stat di benessere per i salvataggi che non la conoscevano ancora.
    if (state.pet && state.pet.stats && typeof state.pet.stats.energia !== 'number') {
      state.pet.stats.energia = 70;
    }
    if (typeof state.sonno === 'undefined') state.sonno = null;

    // Migrazione Valigia / partenza (PROTOTIPO 2, Blocco 2): stessa regola duplicata in save.js
    // migraState — i salvataggi senza i nuovi campi partono a null/0.
    if (!state.valigiaTrig || typeof state.valigiaTrig !== 'object') {
      state.valigiaTrig = { fel: 0, sal: 0, doppio: 0 };
    }
    if (typeof state.valigia === 'undefined') state.valigia = null;
    if (typeof state.petPartito === 'undefined') state.petPartito = null;
    // Lettera dal pianeta (Blocco 4): v. save.js (stessa regola duplicata).
    if (typeof state.letteraPartito === 'undefined') state.letteraPartito = null;
    if (typeof state.eventoValigia === 'undefined') state.eventoValigia = null;
    // Pensione (PROTOTIPO 2, versione base P2): v. save.js (stessa regola duplicata). Array degli
    // snapshot dei pet ritirati (galleria + eredita'); default [] sui salvataggi vecchi.
    if (!Array.isArray(state.pensionati)) state.pensionati = [];
    // Perk CASA (P3, Grandi Imprese): v. save.js (stessa regola duplicata). PERSISTENTE
    // ATTRAVERSO LE RUN, default [] sui vecchi save.
    if (!Array.isArray(state.perkCasa)) state.perkCasa = [];
    // Leggende sbloccate (P3): STESSO ciclo di vita persistente di perkCasa, NASCOSTO. v. save.js
    // (stessa regola duplicata).
    if (!Array.isArray(state.leggendeSbloccate)) state.leggendeSbloccate = [];
    // Perk = MEDAGLIETTE (decisione fondatore, bilanciamento.md "Perk = MEDAGLIETTE"): v. save.js
    // (stessa regola duplicata). Badge permanenti da reward perk:<nome>; default [] sui vecchi save.
    if (!Array.isArray(state.perks)) state.perks = [];
    // Indossabili (PROTOTIPO 2): default per i salvataggi pre-esistenti.
    if (!Array.isArray(state.indossabili)) state.indossabili = [];
    if (typeof state.indossato === 'undefined') state.indossato = null;
    // Armeria (FASE SPRITE): v. save.js (stessa regola duplicata). Default per i vecchi save.
    if (typeof state.armaEquip === 'undefined') state.armaEquip = null;
    // Pianta Esotica (arredo stat_random_giornaliera): v. save.js (stessa regola duplicata).
    // L'ensure vero e proprio (setta la stat se la Pianta e' gia' piazzata) e' in fondo, dopo
    // che arredi/pet sono a posto.
    if (typeof state.piantaEsoticaStat === 'undefined') state.piantaEsoticaStat = null;
    // Ingrandimento casa (GDD "Slot arredo, tetto passivo e Ingrandimento casa"): v. save.js
    // (stessa regola duplicata). Default false.
    if (typeof state.ingrandimentoCasa !== 'boolean') state.ingrandimentoCasa = false;

    // Migrazione orologio di gioco (fix "sonno + orologio"): i salvataggi che non conoscono
    // ancora state.gameMinutes lo inizializzano dall'ora REALE corrente, per continuita'
    // (v. clock.js inizializzaOrologio/avanzaOrologio).
    if (typeof state.gameMinutes !== 'number' && PETQ.clock && PETQ.clock.inizializzaOrologio) {
      PETQ.clock.inizializzaOrologio(state);
    }

    // Migrazione "giorno di gioco canonico" (fix "nuovo giorno a mezzanotte di gioco", stessa
    // regola duplicata in save.js migraState): state.giornoGioco = contatore intero mantenuto
    // dall'orologio; lastLoginDay era una STRINGA data nei vecchi salvataggi, lo portiamo a un
    // intero = giornoGioco cosi' NON scatta un login spurio al primo boot post-update (il prossimo
    // mezzanotte di gioco lo fara'); state.missioniFatte aveva valori stringa data, incompatibili
    // con la nuova aritmetica su interi: eliminiamo le voci vecchie in formato stringa (azzera i
    // cooldown una tantum, accettabile).
    if (typeof state.giornoGioco !== 'number') state.giornoGioco = 0;
    if (typeof state.lastLoginDay !== 'number') state.lastLoginDay = state.giornoGioco;
    if (state.missioniFatte && typeof state.missioniFatte === 'object') {
      for (var kMiss in state.missioniFatte) {
        if (typeof state.missioniFatte[kMiss] !== 'number') { delete state.missioniFatte[kMiss]; }
      }
    }

    // Migrazione Talenti (PROTOTIPO 2, Blocco 9; esteso P3 per lo stadio adulto): stessa regola
    // duplicata in save.js migraState (v. commento esteso li'). Assegna retroattivamente nascita
    // (+teen se gia' teen o adulto, +adulto se gia' adulto) ai salvataggi pre-esistenti che non
    // hanno ancora pet.talenti.
    if (state.pet && !Array.isArray(state.pet.talenti)) {
      state.pet.talenti = [];
      if (PETQ.talenti && typeof PETQ.talenti.estrai === 'function') {
        var talentoNascita = PETQ.talenti.estrai(state.pet.personalita, 'nascita');
        if (talentoNascita) state.pet.talenti.push(talentoNascita);
        if (state.pet.stadio === 'teen' || state.pet.stadio === 'adulto') {
          var talentoTeen = PETQ.talenti.estrai(state.pet.personalita, 'teen');
          if (talentoTeen) state.pet.talenti.push(talentoTeen);
        }
        if (state.pet.stadio === 'adulto') {
          var talentoAdulto = PETQ.talenti.estrai(state.pet.personalita, 'adulto');
          if (talentoAdulto) state.pet.talenti.push(talentoAdulto);
        }
      }
    }

    // Refuso "Mani Lestre" -> "Mani Leste" (correzione talenti.md): rinomina sul pet attivo e
    // sui pensionati. Stessa regola duplicata in save.js migraState.
    rinominaTalento(state, 'Mani Lestre', 'Mani Leste');

    // M17 "Pimp My Pet" (modifica permanente all'evoluzione teen): default per i salvataggi
    // pre-esistenti (modSprite = modifica scelta, teenIntroFatto = flag schermata gia' vista).
    // Stessa regola duplicata in save.js migraState.
    if (state.pet) {
      if (typeof state.pet.modSprite === 'undefined') state.pet.modSprite = null;
      if (typeof state.pet.teenIntroFatto === 'undefined') state.pet.teenIntroFatto = false;
    }

    if (PETQ.pet && state.pet) {
      PETQ.pet.recomputeSalute(state.pet, state);
    }

    // Ensure Pianta Esotica (dopo che arredi/pet sono a posto): se la Pianta e' gia' piazzata in
    // un save vecchio setta la stat del giorno; se non e' piazzata, azzera. Stessa regola
    // duplicata in save.js migraState.
    if (PETQ.arredi && typeof PETQ.arredi.aggiornaPiantaEsotica === 'function') {
      PETQ.arredi.aggiornaPiantaEsotica(state, false);
    }
  }

  // Rinomina un talento su tutti i pet salvati (pet attivo + pensionati) per correggere un
  // refuso in talenti.md. Stessa funzione duplicata in save.js migraState. Difensiva.
  function rinominaTalento(state, da, a) {
    if (!state) return;
    function rinominaIn(talenti) {
      if (!Array.isArray(talenti)) return;
      for (var i = 0; i < talenti.length; i++) {
        if (talenti[i] && talenti[i].nome === da) talenti[i].nome = a;
      }
    }
    if (state.pet) rinominaIn(state.pet.talenti);
    if (Array.isArray(state.pensionati)) {
      for (var j = 0; j < state.pensionati.length; j++) {
        var voce = state.pensionati[j];
        if (voce && voce.pet) rinominaIn(voce.pet.talenti);
      }
    }
  }

  function avviaIntro() {
    if (PETQ.ui && PETQ.ui.boot) {
      PETQ.ui.boot();
    } else {
      console.warn('PETQ.ui.boot non disponibile: modulo grafica/gioco non ancora caricato');
    }
  }

  /* Quarta parete (Retention 2.0/A3): il recap e la reazione al rientro hanno bisogno di due
   * istantanee DIVERSE, e questo e' l'unico punto del codice dove esistono entrambe.
   *
   * Il "da quando manchi" va letto PRIMA di applicaDecadimentoOffline, che riporta lastSeen ad
   * adesso: letto dopo, l'assenza risulterebbe sempre zero e non scatterebbe mai nulla. Le stat
   * da raccontare ("ho avuto fame") vanno invece lette DOPO, perche' e' quella funzione a farle
   * scendere per il tempo passato. Stessa cosa per il sonno: il ciclo sonno del boot puo' aver
   * gia' svegliato il pet, e "stavo dormendo" e' vero comunque.
   *
   * Il risultato resta in state.quartaParetePendente e lo consuma la UI, stesso canale gia' usato
   * per gli effetti dei companion e per gli avvisi dello streak. */
  function catturaRientro(state) {
    if (!state || !PETQ.quartaParete) return null;
    // Il livello batteria si legge in modo asincrono: si avvia la lettura qui cosi' e' gia'
    // pronta per il rientro SUCCESSIVO (a questo giro il valore non c'e' ancora e la reazione
    // batteria semplicemente non scatta — meglio zitto che sbagliato).
    PETQ.quartaParete.aggiornaBatteria();
    return { daMs: state.lastSeen, dormiva: !!state.sonno };
  }

  function chiudiRientro(state, rientro) {
    if (!state || !rientro || !PETQ.quartaParete) return;
    var recap = PETQ.quartaParete.recap(state, rientro);
    // NB reazione() ha un effetto: segna il tipo come "gia' scattato" per le 20h successive.
    // Va chiamata UNA volta sola per rientro, ed e' per questo che sta qui e non nella UI, che
    // si ridisegna decine di volte.
    var reazione = PETQ.quartaParete.reazione(state, rientro.daMs);
    if (recap.length === 0 && !reazione) return;
    state.quartaParetePendente = { recap: recap, reazione: reazione };
  }

  function applicaDecadimentoOffline(state) {
    var ora = Date.now();
    var daMs = (typeof state.lastSeen === 'number') ? state.lastSeen : ora;
    // Fix "lo streak non vede mai un'assenza" (fondatore, 3 ago 2026): DUE grandezze diverse da
    // qui in poi, entrambe ricavate dallo stesso gap reale ma con cap indipendenti (v. clock.js
    // per il perche' del secondo cap). oreCalendario muove l'orologio/giornoGioco (e quindi lo
    // streak, che legge giornoGioco); oreDecadimento resta l'unica a toccare le stat del pet,
    // cap 12h INVARIATO — la protezione "non torni a un pet morto" non cambia.
    var oreCalendario = PETQ.clock.elapsedCalendarHours(daMs, ora);
    var oreDecadimento = PETQ.clock.elapsedGameHours(daMs, ora);

    // Fix "il tempo non passa a casa vuota" (fondatore, 31 lug 2026): l'orologio DI GIOCO e'
    // della CASA, non del pet — deve avanzare SEMPRE che sia passato tempo reale, anche se
    // state.pet e' null (pet in pensione). Guardato solo sull'esistenza del modulo clock, MAI
    // su state.pet. Il decadimento delle stat (applyDecay) resta invece legato al pet: se non
    // c'e' un pet non c'e' nulla da far calare, ma l'orologio non deve pagarne le conseguenze.
    if (oreCalendario > 0 && PETQ.clock && PETQ.clock.avanzaOrologio) {
      PETQ.clock.avanzaOrologio(state, oreCalendario);
    }

    if (oreDecadimento > 0 && state.pet && PETQ.pet && PETQ.pet.applyDecay) {
      PETQ.pet.applyDecay(state.pet, oreDecadimento, state);
    }

    state.lastSeen = ora;
  }

  function eseguiLoginGiornaliero(state) {
    if (PETQ.care && PETQ.care.dailyLogin) {
      PETQ.care.dailyLogin(state);
    }
  }

  // Corpo di UN tick di gioco: avanza il decadimento/orologio di deltaOreGioco, scatta il nuovo
  // giorno se serve, il ciclo sonno, salva e ridisegna. Estratto dalla callback di ticking cosi'
  // il debug "+1 ora" puo' invocarlo (PETQ.main.tick) e avanzare il tempo IN MODO IDENTICO al
  // ticking reale (stessa sequenza), invece di duplicare la logica.
  function tick(state, deltaOreGioco) {
    // Stesso fix di applicaDecadimentoOffline sopra: l'orologio avanza SEMPRE (guardato solo
    // sul modulo clock), PRIMA del decadimento pet (che resta guardato su state.pet) e prima di
    // eseguiLoginGiornaliero/controllaCicloSonno sotto, che leggono il giorno corrente.
    if (deltaOreGioco > 0 && PETQ.clock && PETQ.clock.avanzaOrologio) {
      PETQ.clock.avanzaOrologio(state, deltaOreGioco);
    }
    if (state.pet && PETQ.pet && PETQ.pet.applyDecay) {
      PETQ.pet.applyDecay(state.pet, deltaOreGioco, state);
    }
    // Nuovo giorno a META' SESSIONE (fix "nuovo giorno a mezzanotte di gioco"): applyDecay
    // sopra ha appena avanzato l'orologio di gioco (e quindi state.giornoGioco se e' passata
    // mezzanotte). eseguiLoginGiornaliero e' auto-guardato (no-op se non e' un nuovo giorno di
    // gioco), quindi e' sicuro chiamarlo ad ogni tick: quando l'HUD passa le 00:00 in sessione
    // il nuovo giorno scatta (monete, giorniVita, reset contatori, eventoValigia) e la UI lo
    // intercetta nel path di render (controllaEventoValigia/controllaEvoluzione).
    eseguiLoginGiornaliero(state);
    controllaCicloSonno(state);
    state.lastSeen = Date.now();
    PETQ.save.save(state);

    if (PETQ.ui && PETQ.ui.render) {
      PETQ.ui.render(state);
    }
  }

  function avviaTicking(state) {
    statoAttivo = state;
    registraRipresa();
    // Notifiche locali (notifiche.js): permesso chiesto una volta a gioco avviato, in
    // FOREGROUND (i prompt di sistema non si possono mostrare da background).
    if (PETQ.notifiche && PETQ.notifiche.richiediPermesso) PETQ.notifiche.richiediPermesso();
    PETQ.clock.startTicking(function (deltaOreGioco) {
      // Robustezza tempo in background (mobile): il setInterval si CONGELA quando l'app va in
      // background e, al ritorno, riparte passando il delta FISSO di un solo tick (piccolo), NON
      // il tempo reale trascorso. A velocita' normale (nessun moltiplicatore debug) usiamo SEMPRE
      // il tempo reale trascorso da lastSeen (via elapsedGameHours, che gia' cappa a 12h ed esclude
      // la notte) al posto del delta fisso del tick, MAI un massimo tra i due: un massimo e' un
      // PAVIMENTO, e registraRipresa/recuperaTempoReale ha gia' accreditato il gap e azzerato
      // lastSeen appena prima che questo battito congelato scatti, quindi oreReali qui e' quasi
      // sempre ~0 mentre il pavimento lo forzava comunque al delta fisso -> l'orologio di gioco
      // guadagnava fino a 30s in piu' ad ogni ripresa dal background (2-3 minuti in una sessione a
      // piu' cambi-app). elapsedGameHours e' gia' il tempo reale esatto dall'ultimo accredito: copre
      // sia il timer in ritardo (il gap reale e' sempre >= al periodo nominale) sia lastSeen appena
      // azzerato (gap ~0 -> niente overcredit). In debug (moltiplicatore>1) restiamo sul delta
      // passato: e' un test in foreground.
      var moltiplicatore = window.PETQ.debugTime || 1;
      if (moltiplicatore === 1 && typeof state.lastSeen === 'number') {
        var oreReali = PETQ.clock.elapsedGameHours(state.lastSeen, Date.now());
        deltaOreGioco = oreReali;
      }
      tick(state, deltaOreGioco);
      // Aggiornamenti OTA anche dal BATTITO (stessa lezione v134 del tempo-in-background: su
      // diversi Android gli eventi visibilitychange/focus/pageshow NON scattano — proprio il
      // telefono del fondatore — e l'app non fa quasi mai un avvio a freddo, quindi i soli
      // agganci boot+ripresa lasciavano il check OTA MUTO per sempre dopo il primo. Il throttle
      // di 6h sta DENTRO controlla(): chiamarla ad ogni tick e' un no-op quasi sempre).
      if (PETQ.ota && PETQ.ota.controlla) PETQ.ota.controlla(false);
    });
  }

  // Fix "il tempo passa solo con l'app aperta": su mobile (WebView Capacitor) e su browser con
  // tab in background, il setInterval di startTicking si CONGELA e non riparte da solo al
  // ritorno in foreground (la pagina non si ricarica). Qui rifacciamo la STESSA sequenza di
  // recupero del boot sullo stato attivo, cosi' il tempo reale trascorso in background viene
  // recuperato subito. E' sicuro richiamarla piu' volte di fila: applicaDecadimentoOffline e'
  // idempotente (azzera state.lastSeen a ora ad ogni chiamata) e le altre sono auto-guardate.
  function recuperaTempoReale() {
    var state = statoAttivo;
    // Fix "il tempo non passa a casa vuota" (fondatore, 31 lug 2026): la guardia era
    // `!state.pet`, quindi al rientro in foreground con la casa VUOTA (pet in pensione) l'intera
    // routine veniva saltata e l'orologio restava fermo finche' non arrivava un pet nuovo. Ora si
    // salta solo l'ASSENZA dello stato (unico caso davvero non gestibile): applicaDecadimentoOffline
    // avanza l'orologio comunque (v. sopra) e le altre chiamate qui sotto sono gia' tutte
    // auto-guardate su state.pet dove serve davvero un pet (dailyLogin, controllaCicloSonno,
    // quartaParete.recap/reazione).
    if (!state) return;
    var rientro = catturaRientro(state); // stesso ordine del boot, per lo stesso motivo
    applicaDecadimentoOffline(state);   // avanza il tempo reale trascorso in background (calendario cap 48h, decadimento stat cap 12h, lato clock.js)
    // Stesso riallineamento del boot (v. commento la'): il rientro dal background e' il momento in
    // cui il ritardo residuo dei salvataggi vecchi si vede di piu'. Solo in avanti, mai oltre
    // mezzanotte: chiamarlo a ogni rientro non puo' oscillare.
    if (PETQ.clock && PETQ.clock.riallineaOraReale) PETQ.clock.riallineaOraReale(state);
    eseguiLoginGiornaliero(state);      // nuovo giorno se maturato offline (auto-guardato)
    controllaCicloSonno(state);
    chiudiRientro(state, rientro);
    PETQ.save.save(state);
    if (PETQ.ui && PETQ.ui.render) PETQ.ui.render(state); // render fa scattare anche la chiusura missione (controllaMissioneScaduta) contro Date.now()

    // Aggiornamenti OTA (ota.js): il rientro in foreground e' il momento naturale per il check
    // (stesso motivo delle notifiche sopra), stesso throttle 6h dentro controlla() a evitare spam.
    if (PETQ.ota && PETQ.ota.controlla) PETQ.ota.controlla(false);
  }

  // Registra i listener di ripresa foreground UNA SOLA VOLTA (flag ripresaRegistrata). Copre sia
  // il browser (tab in background) sia la WebView Android (Capacitor): niente @capacitor/app
  // (non installato), solo eventi DOM standard che coprono entrambi i casi.
  function registraRipresa() {
    if (ripresaRegistrata) return;
    ripresaRegistrata = true;
    // Al ritorno in foreground i timer erano congelati (mobile WebView / tab in background):
    // rifacciamo il recupero del tempo reale dall'orologio, come al boot. Notifiche locali
    // (notifiche.js): all'uscita in background le pianifichiamo sullo stato attivo; al ritorno
    // le cancelliamo PRIMA del recupero (il giocatore e' gia' qui, non servono piu' gli avvisi
    // che lo richiamavano indietro).
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'hidden' && PETQ.notifiche) PETQ.notifiche.pianifica(statoAttivo);
      if (document.visibilityState === 'visible') {
        if (PETQ.notifiche) PETQ.notifiche.cancella();
        // Le notifiche pianificate all'uscita in background potrebbero NON essere mai state
        // consegnate (rientro immediato, come qui): la memoria anti-ripetizione dello stesso tipo
        // di fila (state.ultimoTipoNotifica, v. notifiche.js applicaRegoleAntiMolestia) si basa
        // proprio su quelle pianificazioni, quindi va svuotata insieme a loro. Senza questo, un
        // tipo pianificato e mai suonato (es. la streak del pomeriggio) blocca per sempre la
        // notifica VERA dello stesso tipo piu' tardi (es. la streak-saver della sera, il momento
        // in cui conta di piu'). Se invece la notifica ERA stata davvero consegnata e siamo
        // rientrati proprio toccandola, azzerare qui resta la scelta giusta lo stesso: il
        // giocatore l'ha gia' vista, quindi una ripetizione dello stesso tipo nella PROSSIMA
        // sessione di background non e' piu' la ripetizione "di fila" che la regola vuole evitare.
        if (statoAttivo) statoAttivo.ultimoTipoNotifica = null;
        recuperaTempoReale();
      }
    });
    window.addEventListener('focus', recuperaTempoReale);
    window.addEventListener('pageshow', recuperaTempoReale);
  }

  function renderIniziale(state) {
    if (PETQ.ui && PETQ.ui.boot) {
      PETQ.ui.boot(state);
    } else {
      console.warn('PETQ.ui.boot non disponibile: modulo grafica/gioco non ancora caricato');
    }
  }

  PETQ.main = {
    avviaTicking: avviaTicking,
    tick: tick, // usato dal debug "+1 ora" per avanzare il tempo come il ticking reale
    migraState: migraState,
    controllaCicloSonno: controllaCicloSonno,
    _migraDispensaAQty: migraDispensaAQty
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

})();
