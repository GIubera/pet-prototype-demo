# Bilanciamento — v1 (post-sessione missioni)

Il codice legge QUESTO file: cambiare un numero qui cambia il gioco. Le sezioni marcate PROPOSTA sono in attesa di conferma del fondatore.

## Decadimento stat benessere (per ora di gioco attivo; di notte in pausa)

| Stat | Calo/ora | Note |
|---|---|---|
| Fame | −6 | ~2 pasti al giorno per stare sopra 50 |
| Igiene | −8 | −15 extra se ci sono bisogni non puliti; con −8/ora servono ~2 lavaggi al giorno |
| Felicità | −2 | −5/ora se Fame o Igiene sotto 25; raddoppia se Salute < 25 |
| Salute | v. sezione Sistema Salute | non decade da sola: è 100 − Ferite − Malus condizioni |

Ritmo cura target (playtest v2, 4 lug 2026, su ~14 ore attive): **2 pasti, almeno 2 lavaggi, almeno 3 pulizie bisogni al giorno**. Bisogni legati alla digestione: 60-90 minuti di gioco dopo OGNI pasto lo spawn è quasi garantito (p 0.9), più un baseline casuale ridotto (0.05/ora). I numeri della digestione vivono nel codice (pet.js applyDecay / care.js feed), qui la regola.

## Ciclo vitale 14 GIORNI (DECISIONE fondatore 10 lug 2026 — sostituisce il ciclo ~25-30)

Ciclo accorciato per retention/loop roguelite (analisi: sotto i 12 giorni le build non fanno in tempo a divergere; 14 = 2 settimane, arco completo dentro la finestra di retention, ~5 run per la prima leggenda ≈ 10 settimane). La crescita stat regge perché il **giorno è DENSO** (v. sotto: 2 missioni + 1 allenamento da +2 + 3 pasti-stat ≈ raddoppio della crescita/giorno) → **le soglie delle missioni restano INVARIATE**.

| Cosa | Valore |
|---|---|
| Baby | giorni 1-3 (**3 giorni**) |
| Teen | giorni 4-8 (**5 giorni**) |
| Adulto | giorni 9-14 (**~6 giorni** + Grande Impresa), pensione attesa ~g14 |
| Missioni al giorno | **2** (talento Lavoro in Nero → 3) |
| Allenamenti al giorno | **1** (talento Predestinato → 2) |
| Pasti-con-stat al giorno | **3** (v. Pacing stat RPG) |

## Evoluzione (aggiornata al ciclo 14 giorni)

| Cosa | Valore |
|---|---|
| Baby → Teen | 3 giorni DI GIOCO (pet.giorniVita, avanza a ogni "nuovo giorno": login reale o debug "Nuovo giorno") |
| Teen → Adulto | 8 giorni DI GIOCO (baby 3 + teen 5) |
| Effetto sulle statistiche | NESSUNO per ora — solo stadio + aspetto (bodyVariant vede 'teen') + battuta pool `evoluzione`. TODO commentato in pet.js `controllaEvoluzione`: il fondatore deciderà se aggiungere un bonus (es. +1 RPG) |

## Soglie

| Cosa | Valore |
|---|---|
| Stat "critica" (sprite triste, notifiche) | < 25 |
| Variante magra | media Fame ultimi 2 giorni < 30 |
| Overlay sporco | Igiene < 30 |
| Malus missione da Salute | Salute < 40 → sprite sofferente + avviso prima di partire in missione |
| Soglia sovralimentazione | Fame ≥ 90 al momento del pasto (solo teen+: dare da mangiare con la pancia già piena fa ingrassare e +10 Ferite; il baby non ne risente) |

### Variante ciccione — soglie PER STADIO (PROTOTIPO 2, punto 1)

La variante esiste negli sprite da prima ma non appariva mai in P1 (regola "mai baby", e il pet era sempre baby). Col teen diventa raggiungibile: decisione fondatore, **difficile da teen**, **più facile da adulto** (P3, soglie ancora da tarare quando arriva lo stadio — struttura già pronta in codice, `pet.js` `SOGLIE_CICCIONE_PER_STADIO`).

| Stadio | Soglia (basta UNA condizione, come prima) |
|---|---|
| Baby | mai ciccione (nessuna soglia — il cucciolo non ingrassa così, GDD "Aspetto dinamico") |
| Teen | >8 pasti/giorno **o** >6 dolci/giorno **o** ≥4 sovralimentazioni recenti cumulative (era >5 pasti/>3 dolci/≥2 sovralimentazioni nel valore unico pre-evoluzione: alzate apposta per renderlo difficile da teen) |
| Adulto (P3) | da tarare — soglia più bassa delle altre, così l'eccesso da adulto è più facile che da teen |

## Sistema Salute (v1 — sostituisce la vecchia media pesata)

**Salute = 100 − Ferite − Malus condizioni** (limitata 0–100).

### Ferite (0–100) — i danni degli eventi
- Salgono SOLO da eventi espliciti: i danni Salute scritti nelle schede missione diventano Ferite (es. M7 standard: +15 Ferite; M7 fallimento: +25; M3 fallimento: +10)
- Guarigione naturale: −5 Ferite al giorno (applicata al risveglio/primo accesso del giorno)
- **Infermeria** (in bagno): azione "Cura" — costo 15 monete, −30 Ferite, max 2 cure al giorno. Con Ferite = 0 il bottone è disattivato ("sta benone"). Scenetta di cura (kit medico nel lab / capsula rigenerante nella ship)

### Malus condizioni — lo stato di vita (ricalcolato live, sparisce curando la causa)
| Causa | Malus |
|---|---|
| Fame < 25 da più di 6 ore di gioco | +15 |
| Igiene < 25 da più di 6 ore di gioco | +15 |
| Energia < 25 da più di 6 ore di gioco | +15 |
| 2+ bisogni non puliti in casa | +10 |
| Dieta squilibrata (2 giorni con una sola categoria, o solo dolci) | +10 |
| Cap totale malus | 50 |

Nota (punto 8, aggiunta fondatore): lo sfinimento prolungato ammala il pet come fame/igiene basse — stesso tracking "sotto soglia da quando 6h+"; una dormita che riporta l'Energia sopra soglia azzera il tracking e il malus sparisce da solo.

### Effetti della Salute
| Soglia | Cosa succede |
|---|---|
| < 40 | sprite sofferente, avviso in partenza missione |
| < 25 | Felicità decade al doppio |
| = 0 prolungata (24 ore reali) | fase valigia (SOLO da teen in poi; il baby resta malaticcio e triste, mai valigia) |

Nota di design: le missioni non sono mai bloccate dalla Salute bassa (filosofia casual) — il gioco avvisa, non vieta.

## Missioni — pet baby (prototipo)

Niente tiro di dado. Il giocatore sceglie 2 missioni al giorno (una alla volta, ciclo 14 giorni — era 1) da una rosa di 3 (su 10+ schede, in crescita nel P2, estrazione del giorno con copertura di almeno 3 stat diverse; il tutorial M0 è fuori rosa, solo giorno 1). Tre esiti deterministici:

| Esito | Frequenza | Come scatta |
|---|---|---|
| Standard | quasi sempre | default |
| Fallimento | raro | condizione sulla scheda (di solito personalità E stat molto bassa) |
| Super successo | raro | condizione sulla scheda (personalità O stat 3+) |

**Regole di precedenza (globali):**
1. Il super successo batte SEMPRE il fallimento (se un pet soddisfa entrambi, è super)
2. Tra più fallimenti (es. M6 A/B): vince il più specifico (A prima di B)
3. Tra più super (M7): Amicizia > Dominio > Intimidazione
4. Con perk di categoria attivo: super successo garantito — quello "generico" della scheda (per M7: Dominio), salvo condizioni di un super specifico soddisfatte
5. Le stat nelle condizioni = stat base + bonus passivi degli arredi PIAZZATI (v. cap sotto)

**Regola fissa**: il fallimento compensa sempre con qualcosa, in tema con la missione. Mai un "meno secco".

**Regola Felicità (fix playtest 7 lug, retroattivo su M1-M32)**: OGNI esito standard dà `fel+5` e OGNI super successo `fel+10` — completare una missione rende felici, sennò col decay (−2/h) il pet vive triste. I fallimenti restano senza (o col loro malus, es. −5, dove il design lo vuole). Vale anche per le missioni future (adulto incluso).

**✅ DECISO (playtest fondatore 7 lug) — inflazione stat, super troppo comuni a fine teen → OPZIONE 2: soglie super teen alzate.** Il problema era confermato dai conti (una stat non focalizzata a g12-15: base ~15-20 dal cibo/missioni + flat +7/9 nelle condizioni → il 10 effettivo lo sfondavano quasi tutte). Fix retroattivo applicato alle schede teen (M17-M32): **super 10+ → 13+** (M19 9→12, M22 dual 7&7→9&9), **gate boss M18: riesci 8+→10+, super 10+→13+**. Fail teen resta ≤7 (il problema erano i super, non i fallimenti). Le vie alternative a personalità+talento restano invariate (sono il percorso cross, non passano dalla stat). **Stessa proporzione (~×1.3) applicata ai parametri ADULTO** in docs/DESIGN-P3-ADULTO.md: super 25+→32+, gate 35+→45+, gate super 50+→65+, Imprese successo 40+→50+/super 55+→70+. NESSUNA modifica al motore richiesta (solo content). Le opzioni scartate (tetto cibo a 8, clamp flat +4) restano annotate qui come piano B se il playtest lungo mostra che il 13+ invecchia male. Combinazione consigliata: 1+3.

**Pool per la ROTAZIONE RANDOM per run (fondatore 10 lug)**: pool sovradimensionati su tutti e 3 gli stadi, la rotazione estrae un sottoinsieme diverso a ogni run (implementata, ROTAZIONE_PER_STADIO = baby 9 / teen 13 / adulto 16). **AGGIORNATO al ciclo 14 giorni + 2 missioni/giorno**: consumo per run = baby 6 (3gg×2) su 9 attive (pool 24), teen 10 (5gg×2) su 13 attive (pool 33), adulto ~12 (6gg×2) su 16 attive (pool 32 + Imprese fuori conta). Regola rosa piena: attive ≥ (giorni−1)×2+3 → minimi 7/11/13, tutti rispettati. Tra due run consecutive ~60-70% di missioni diverse in rosa. M96 è la boss multi-via teen (stile M7, 3 super per build).

**Missioni NON ripetibili** (DECISIONE fondatore 5 lug 2026, sostituisce il cooldown a 3 giorni): una missione completata **sparisce per sempre** dalla rosa (mai più ripetibile — "missioni uniche"). Niente riammissione: il mazzo si svuota man mano. **Rosa = 3** al giorno (il codice era 4, allineato a 3). Conseguenza: servono ~1 quest per giorno di stadio (baby 5gg → ~7 per rosa piena fino in fondo; teen ~10gg → ~12). Quando le uniche di uno stadio finiscono, per ORA il pet resta senza missioni (opzione A). Una rete di "quest filler ripetibili" a esaurimento è RIMANDATA alla release (opzione B, da decidere).

**Separazione baby / teen** (fondatore 5 lug 2026): le missioni sotto l'header `# TEEN` in missioni.md sono di stadio **teen**, quelle sopra sono **baby**. La rosa mostra SOLO le missioni dello stadio corrente del pet (un teen non vede mai le baby e viceversa). Tutorial M0 e intro-teen M17 restano fuori rosa.

**Perk = MEDAGLIETTE** (decisione fondatore 6 lug) — un perk NON è più un arredo/oggetto: è una **medaglietta/badge** che il pet ottiene dal super successo (token reward `perk:<nome>`) e che vive in una scheda-medaglie dedicata, **sempre attiva una volta ottenuta** (non si piazza, non occupa slot). I perk di categoria/tag sono booleani (niente fallimento + sempre super successo); Popeye è un passivo. **RETROATTIVO da fare** (opzione A, confermata): togliere "+ perk X" dalle righe arredo in arredi.md — i trofei restano collezionabili col loro bonus stat, il perk lo assegna la MISSIONE come medaglietta (il token `perk:` nel reward, non l'arredo piazzato). **I perk esistono SOLO nelle missioni che li assegnano** (se ogni categoria ne avesse uno non sarebbero speciali). Regola di scrittura: quando si nomina un perk va SEMPRE scritto cosa fa. Nel prototipo (P2):

| Nome perk | Categoria / tag | Effetto (finché l'arredo è piazzato) | Da dove viene |
|---|---|---|---|
| Player One | Videogioco | niente fallimento + sempre super successo nelle missioni Videogioco | M1, Coppa Arcade |
| Street Fighter | Combattimento | niente fallimento + sempre super successo nelle missioni Combattimento | M3, Completo da martial artist |
| Tony Hawk | Sport | niente fallimento + sempre super successo nelle missioni Sport | M8, Pattini da gara |
| Doc Brown | Studio | niente fallimento + sempre super successo nelle missioni Studio | M9, Coppa della Fiera |
| Sabotatore | tag `gara` | niente fallimento + sempre super successo in TUTTE le missioni col tag `gara` (overlap con altri perk innocuo) | M10, Telecomando Pirata |
| Parkour Master | tag `inseguimento` | niente fallimento + sempre super successo nelle missioni col tag `inseguimento` | M15, Scarpe da Parkour |
| Popeye (IT: Braccio di Ferro) | passivo | NON vinci-categoria: ogni volta che il pet mangia verdure prende anche +1 Forza | M13, Trofeo d'Oro |
| Weapon Wielder | (unlock) | NON vinci-categoria: sblocca la capacità di EQUIPAGGIARE armi nelle missioni (es. pistola spara-spazzatura, martello vero) — sistema equip armi, Blocco 6 | M25, super successo |
| Influencer | tag `social` | niente fallimento + sempre super successo nelle missioni tag `social` | M30, super successo |
| Singer | tag `musica` | niente fallimento + sempre super successo nelle missioni tag `musica` | M32, super successo |
| GTB (Gran Theft Burger) | tag `rapina` | niente fallimento + sempre super successo nelle missioni tag `rapina` | M18, grande successo (Maleducato + talento Boss di Quartiere + stat 10+) |
| Cacciatore di Mostri | tag `mostro` | niente fallimento + sempre super successo nelle missioni tag `mostro` | M20, super successo |
| Masterchef | tag `cucina` | niente fallimento + sempre super successo nelle missioni tag `cucina` | M50 (adulto), super successo |
| Acchiappafantasmi | tag `paranormale` | niente fallimento + sempre super successo nelle missioni tag `paranormale` | M51 (adulto), super successo |
| Astronauta | tag `spazio` | niente fallimento + sempre super successo nelle missioni tag `spazio` | M43 (adulto), super successo |
| Pony Express Galattico | categoria Consegne | niente fallimento + sempre super successo nelle missioni categoria Consegne (primo perk di categoria Consegne) | M55 (adulto), super successo |
| Party Animal | categoria Sociale | niente fallimento + sempre super successo nelle missioni Sociale | M96 (teen, boss Festa di Quartiere), super successo (tutte e 3 le vie) |
| Mr. Wolf | categoria Lavoretti | niente fallimento + sempre super successo nelle missioni Lavoretti ("risolvo problemi") | M87 (teen), super successo |
| Acchiappali Tutti | tag `companion` | niente fallimento + sempre super successo nelle missioni tag `companion` → i companion delle missioni non scappano MAI più (super garantito = companion garantito) | M97 (teen, Il Mostriciattolo dell'Erba Alta), super successo |

Con Party Animal (Sociale) e Mr. Wolf (Lavoretti) **TUTTE le categorie hanno ora un perk**. **Tag nuovo `companion`** (10 lug): marca le missioni il cui super successo dà una creatura-companion — retro-taggate M11 (Gattino Robot), M26 (Piccione Cyborg), M34 (Mostro del Lago), M51 (Fantasmino), M56 (Pacco Maledetto), M62 (Micro-Mostro Regina) + M97 stessa. (Nota release EN: nomi-citazione da rivalutare — parodia o storpiatura, es. "Street Brawler".)

**Tag nuovi introdotti dalle missioni ADULTO (P3):** `cucina`, `paranormale`, `spazio`, `mistero` — usati nelle condizioni e dai 4 perk adulto sopra (`mistero` non ha ancora un perk dedicato: è solo un tag tematico per raggruppare le missioni-indagine). Nessuna categoria nuova (combattimento/sport/videogioco/studio/sociale/lavoretti/consegne esistono già).

**Token DSL nuovi (batch missioni P2 baby M13-M16, da agganciare nel motore):** `tag=` sulle schede (usato da talenti e dai perk `gara`/`inseguimento`, oltre a `natura`/`invenzione`); `talento:X` nelle condizioni (la cond controlla se il pet HA un talento — es. Inventore/Energico/Idrofobico/Amante della Natura, non solo personalità+stat); `energiaMissione=0` (missione a costo energia nullo, es. montacarichi Nerd-Inventore); perk **passivo** (Popeye, non un vinci-categoria); **cibo multi-porzione** (Arrosto = 3 fette, v. cibi.md); **categoria nuova** `lavoretti`.

**Token/sistemi nuovi (batch missioni P2 TEEN M17-M20):** `teenIntro=1` (missione fuori rosa, giocata 1 volta all'evoluzione teen, come il tutorial M0); `scelta:<stat>` + `sprite:<nome>` (M17: scelta del giocatore → +2 permanente + variante sprite permanente, 8 look da disegnare); `statMax` nelle condizioni (la stat RPG più alta del pet — modello a soglia teen: `statMax>=8` per riuscire, `statMax<8` fallisce, `statMax>=10` super); `indossabile:<nome>` (vestiti equipaggiati SUL pet, Blocco 6, sistema equip separato dagli arredi); `perk:<nome>` come reward (assegna un perk); `talento:<nome>` con nomi a **più parole** (Boss di Quartiere → `bossdiquartiere`, Spirito Agonistico → `spiritoagonistico`: il matching deve togliere gli spazi dal nome del talento); **cibo a stat casuale** (Scorta di Panini / Fetta di Panino Gigante: +2 a una stat RPG estratta a caso). **Nota modello teen**: a differenza delle baby (fallimento raro/edge-case), le teen possono avere un GATE reale (M18 fallisce chi non ha una stat a 8+). **TODO retroattivo** (a fine scrittura teen): rivedere le baby M1-M16 e aggiungere tag dove sensato (es. M1/M8 tornei→`gara`, M7 Mostro nelle Fogne→`mostro`) così i perk coprono più missioni.

**Soglia fallimento standard TEEN = stat effettiva ≤7** (decisione fondatore 5 lug, su simulazione stat teen). Le missioni teen "normali" mettono il ramo fallimento sulla stat coinvolta a `≤7`: la stat trascurata (quella che il giocatore ha ignorato) resta bassa per buona parte del teen, quindi quelle missioni **possono fallire raramente ma davvero** (filosofia "poche volte ma deve poter succedere"); il casual fallisce a inizio poi cresce; chi ha investito la stat non fallisce mai la sua. Da verificare a playtest col cibo a 2 pasti-stat/giorno. ECCEZIONE: le "boss" a gate (es. M18) usano un modello diverso apposta (serve la stat A 8+ per riuscire, fallisce sotto). Nota: super/boss 8+/10+ da riverificare col primo playtest (coi numeri veri, non solo stimati); se ancora banali, alzare a 12+/15+.

## Missioni — pet adulto (P3, DESIGN anticipato)

Le 32 missioni adulto sono SCRITTE come schede M33-M64 in `missioni.md`, sezione `# ADULTO`. Fonte di design completa (finale, terne, roster leggende): `docs/DESIGN-P3-ADULTO.md`. Parametri (post-fix inflazione ×1.3, coerenti con l'OPZIONE 2 sopra):

| Cosa | Valore |
|---|---|
| Fallimento standard | stat effettiva **≤15** (edge-case, come le teen ma soglia più alta) |
| Super successo standard | stat **32+** (oppure via-alt personalità+talento, regola anti-ridondanza) |
| Boss a gate (es. M45 Laurea, M48 Elezioni) | riesci **45+**, super **65+** |
| Boss a gate — M38 Olimpiadi | riesci **40+**, super **65+** (abbassata il 3 ago 2026: col tetto stat per stadio la 45 era irraggiungibile al giorno 9) |
| Grandi Imprese finali | successo **50+**, super **70+** |
| Reward stat | standard +3 · super +4-5 |
| Felicità | standard +5 · super +10 (regola globale) |
| Tag nuovi | `cucina`, `paranormale`, `spazio`, `mistero` (v. tabella perk) |

**Regola anti-ridondanza (fondatore):** la via di super ALTERNATIVA alla soglia stat deve appartenere a una build DIVERSA da quella che la soglia ce l'ha già (mai "Int 25 O Nerd-inventore"). Tutte le vie-alt delle 32 puntano a talenti che esistono (baby/teen/adulto in `talenti.md`).

**Token DSL nuovo `ritenta=1`** (implementato 10 lug): sulle boss a gate che devono restare ritentabili (M45 Laurea, M48 Elezioni, M38 Olimpiadi; lo useranno anche le Grandi Imprese) il FALLIMENTO non consuma la missione — non finisce in `missioniFatte`, resta in rosa finché non riesce. Standard/super la chiudono normalmente. **RISOLTO fondatore (3 ago 2026) — M38:** soglia gate abbassata da 45 a 40 (misurato col motore: la statMax al giorno 9, primo da adulto, sta quasi sempre sotto 45 col tetto stat per stadio introdotto lo stesso giorno) + aggiunto `ritenta=1` come M45/M48. DA DECIDERE fondatore: estenderlo anche a M18 (boss teen)? Oggi lì un fallimento brucia la missione per sempre.

**Finale (Grandi Imprese):** 1 per personalità estratta a caso per run (non si sceglie); il super + la **pensione** del pet sblocca un **perk di ritiro** (medaglietta della CASA, buff permanente sui pet futuri) e un **10% nascosto** che le uova future schiudano il pet-leggenda giocabile. Dettaglio in `docs/DESIGN-P3-ADULTO.md`.

⚠ **GAP PARSER (da chiudere prima di andare live, compito istanza implementazione):** `parseMissioni` in `app/js/content.js` riconosce solo `# TEEN`/`# BABY` come separatori e il token `stadio=` accetta solo `baby`/`teen`. Quindi oggi le M33-M64 sotto `# ADULTO` verrebbero taggate `teen` e sfonderebbero nella rosa teen. Servono 2 micro-aggiunte (regex `# ADULTO`→'adulto' + accettare 'adulto' nel token `stadio=`). **NON rigenerare/pushare il bundle finché il parser non supporta 'adulto'.**

## Arredi e bonus passivi (PROPOSTA)

| Cosa | Valore |
|---|---|
| Slot arredo per stanza | **3** base, **4** con l'upgrade shop "Ingrandimento casa" (200 monete, globale; alza anche il tetto passivo e ingrandisce le stanze). Oltre il 4° = P3 |
| Tetto bonus passivo arredi | **+3 per stat RPG** (era +2; `arredi.bonusPassivi` clampa a 3) |
| Contano solo gli arredi PIAZZATI | sì (possederli non basta) |
| Cap contributo passivi per singola stat nelle condizioni missione | +2 |
| Vendita doppione | 50% del valore |

## Pacing stat RPG (PROPOSTA — evita che le soglie 3+ diventino banali)

| Cosa | Valore |
|---|---|
| Bonus stat del cibo | scatta per i primi TRE pasti-con-stat del giorno (ciclo 14 giorni, 10 lug — era 2). Motore ALLINEATO (care.js `feed`, contatore `state.pastiStatOggi` cap 3) |
| Allenamento | +2 alla stat scelta, 1/giorno (decisione fondatore 10 lug 2026: stessa matematica del 2x+1, meta' dei tap) |
| Missione standard | +1 (super: +2), 2 missioni/giorno |
| Crescita attesa | stat focalizzata a 3+ già nel giorno 2 (giorno denso: ~+10-14/giorno sulla stat focale) |
| Pasti al giorno | da tarare in playtest (punto delicato segnalato dal fondatore): col decadimento attuale ~2 pasti/giorno; se il ritmo pasti cambia, rivedere la regola dei "primi 2 pasti-con-stat" |

## Economia (v1)

| Cosa | Valore |
|---|---|
| Login giornaliero | 10 monete |
| Monete iniziali | 50 |
| Paghetta di ritorno missione | +5 monete fisse a ogni missione, in aggiunta ai reward della scheda (PROPOSTA: copre il rosso quotidiano) |
| Mancia post-missione | 1 moneta ogni 5 punti di Carisma |
| Costo pasto medio | ~8-12 monete (v. cibi.md) |
| Bilancio giornaliero atteso | AGGIORNATO ciclo 14gg/2 missioni: entrate ~35-45 (login 10 + paghetta 5×2 + reward media 6×2 + mance) · uscite ~25-35 (2-3 pasti ~16-26 + costi missione ~4 + infermeria ammortizzata) → attivo moderato, coerente con run corte (meno giorni per accumulare per gli arredi grossi). Da ritarare a playtest |

## Allenamento (momento interazione)

| Cosa | Valore |
|---|---|
| Sessioni al giorno | 1 |
| Effetto | +2 alla stat scelta, +5 Felicità |
| Durata allenamento | 90 minuti di GIOCO come ATTIVITÀ A TEMPO (decisione fondatore 4 lug 2026): non è un'azione istantanea né un salto d'orologio secco — il pet si allena con un countdown, è "occupato" (niente coccole/pappa/altra missione finché non finisce), esattamente come una missione ma a casa. La stat/felicità/energia si applicano SOLO al completamento. Proposta 90 min, da tarare |
| Insegna parola | max 1 al giorno, +5 Felicità |
| Frequenza uso parola imparata nelle battute contestuali | 30% (alzata da 20% — il fondatore non la vedeva mai) |

## Stat iniziali alla generazione

| Cosa | Valore |
|---|---|
| Benessere | tutte a 70 |
| RPG | budget di 3 punti base assegnati a caso una alla volta (impilabili sulla stessa stat), poi bonus di 1 alla stat "firma" |
| Stat firma | gentile→Carisma, maleducato→**Velocità**, nerd→Intelligenza, sportivo→Forza (decisione fondatore 5 lug 2026: maleducato era Intelligenza, spostato a Velocità per differenziarlo dal nerd) |

Nota per il parser (content.js parseBilanciamento): la riga "RPG" sopra deve contenere ESATTAMENTE due numeri — il primo è il budget, il secondo (ultimo) è il bonus firma. Totale iniziale = budget + firma (oggi 3+1=4). Se si aggiungono altri numeri a quella riga, il parser li legge male: tenerla pulita.

## Energia e sonno

Quinta stat di benessere (v. GDD "Energia e sonno", decisione fondatore 4 lug 2026). Numeri v1 di Claude, da tarare.

| Cosa | Valore |
|---|---|
| Decadimento Energia (per ora di gioco attivo) | −2 |
| Costo missione | −8 per ora di durata |
| Costo allenamento | −10 |
| Soglia rifiuto (missioni e allenamento) | < 20 |
| Ora del letto (da qui inizia il sonno notturno) | 21 |
| Ora del crollo automatico (se sveglio e non a letto) | 23 |
| Riposino (prima delle 21) — durata max | 2 ore di gioco |
| Riposino — durata minima prima di poter svegliare | 1 ora di gioco |
| Recupero riposino | +15 Energia per ora dormita (2h piene = +30) |
| Sonno notturno (dalle 21) — durata max / sveglia autonoma | 8 ore di gioco |
| Sonno notturno — durata minima prima di poter svegliare | 5 ore di gioco |
| Energia al risveglio notturno (≥5h, riposo pieno) | 100 |
| Energia al risveglio notturno (crollato alle 23) | 70 |
| Energia al risveglio (crollato/dormito male) | 70 |

Note di design: sotto la soglia rifiuto, oltre a bloccare missioni/allenamento, la Felicità cala più in fretta (stessa regola delle altre stat critiche). Se il giocatore sveglia il pet prima delle 6 ore, l'Energia torna proporzionale alle ore dormite (min 30) invece del valore pieno: è una scelta del giocatore, non una punizione fissa.

## Scene missione (decisione fondatore)

Cartoline pixel art (stile rect-composition + sprite, come le stanze): **generiche** per standard e fallimento (una per categoria/tono), **dedicate** per ogni super successo (~10). Nell'app si arricchiscono fino alla copertura completa. Le righe "Scena" nelle schede sono il brief.

## Archivio — modello probabilistico (fase adulta/app, NON usato nel prototipo)

| Parametro | Valore |
|---|---|
| Probabilità base (requisiti esattamente soddisfatti) | 55% |
| Bonus per punto stat sopra la soglia principale | +2% (cap totale 90%) |
| Malus per punto sotto la soglia | −3% |
| Esito parziale | se il tiro manca il successo di ≤15 punti |

## Tetto delle statistiche per stadio (DECISIONE fondatore — fix "le stat sfondano le soglie in anticipo")

Le stat RPG (Forza/Intelligenza/Velocità/Carisma) crescevano senza freno per tutta la vita del pet e sfondavano le soglie SEGRETE delle missioni giorni prima dello stadio a cui quelle soglie appartengono (misurato col motore vero, un pet normale con 1 allenamento + 2 pasti-stat al giorno: Forza g2=18 già sopra la soglia super TEEN 13, quando il teen inizia solo al g4). Fix: un TETTO per stadio, per singola statistica — sotto il tetto la stat sale normalmente, sopra un aumento non la alza più (letto dallo STADIO CORRENTE del pet, non dal giorno di vita).

| Cosa | Valore |
|---|---|
| Tetto stat per stadio (baby / teen / adulto) | 12 / 30 / 70 |

I valori NON sono arbitrari: ognuno sta appena SOTTO la soglia "super" dello stadio SUCCESSIVO — teen super 13 > tetto baby 12; adulto super 32 > tetto teen 30; Grandi Imprese super 70 = tetto adulto (nessuno stadio oltre l'adulto, lì tetto e soglia coincidono). Applicato da un'UNICA funzione cancello (`PETQ.pet.aggiungiStat`, app/js/pet.js): ogni punto del codice che fa crescere una stat RPG (cibo, allenamento, studio veloce, reward missione, talenti, progressione arredi/giocattoli, bonus alla nascita) passa da lì, così il tetto non si può aggirare né dimenticare in un punto nuovo.

Regole: i MALUS (delta negativi, es. i Cibi del Disonore che tolgono Carisma) passano SEMPRE — il tetto vale solo verso l'alto, la stat può scendere sotto zero come già oggi. I salvataggi VECCHI con una stat già sopra il tetto (es. Forza 80 da adulto) NON vengono abbassati: restano dov'erano, semplicemente smettono di salire finché non evolvono di stadio. Consolazione: quando un'azione che darebbe stat non fa salire nulla perché la stat è già al tetto, il pet riceve +2 Felicità una volta per azione (non per punto perso) — "non l'ha fatto crescere, ma gli è piaciuto lo stesso".
