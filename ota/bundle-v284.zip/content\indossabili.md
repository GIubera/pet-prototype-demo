# Battute indossabili — BOZZA (non ancora letta dal codice)

Battute che il pet dice quando indossa un capo (Blocco 6, arredi.md "Indossabili"). Serie
a tema per capo, uguale per tutte le personalità (il tema è guidato dal vestito, non dal
carattere). Una battuta per riga con `- `. Slot: `{nome}` `{utente}`.

STATO: bozza contenuti. Per attivarle serve (lato codice):
1. Un hook "indossa <capo>" che peschi dalla sezione col nome esatto del capo (come in arredi.md).
   Nel parser di content.js l'indossabile è oggi riconosciuto ma la feature battute è rimandata.
2. Aggiungere questo file a build-content.ps1 quando il formato è confermato.

I titoli `## <Capo>` usano i nomi ESATTI di arredi.md (sezione Indossabili).

---

## Completo da Chef
- Col cappello da chef mi sento un genio dei fornelli. Non so cucinare, ma il cappello sì.
- Adesso che sono chef, la ciotola diventa "degustazione". Stesso cibo, prezzo triplo.
- Assaggio, aggiusto, mando in sala. La sala è il divano. Il cameriere sei tu, {utente}.

## Parrucchino di Elvis
- Grazie mille. GRAZIE MILLE. Il Re è tornato e il palco è il salotto.
- Un colpo d'anca, un ricciolo perfetto e mezzo quartiere sviene. Non è colpa mia, è il parrucchino.
- Ho il ciuffo, ho il ritmo, ho il carisma. Mi manca solo un pubblico che non sia il frigo.

## Camice del Dottore
- Col camice mi sento autorevole. Di' "aaah". No, non a me: al piatto di cibo che mi porti.
- Il dottore raccomanda riposo, merenda e affetto. Il dottore si prescrive sempre cose belle.
- Visita completata. Sei sano, {utente}. Un po' distratto, ma di quello non si muore. Il conto: una carezza.

## Toga da Avvocato
- Obiezione! La mia ciotola risulta vuota e ho le prove. Chiedo cibo immediato, vostro onore.
- Ai sensi dell'articolo "voglio coccole", comma "adesso", esigo affetto. La legge è legge.
- Metto a verbale che oggi ti ho perdonato. È scritto, quindi è vero. Non abusarne.

## Maschera da Wrestler
- Sul ring di casa nessuno mi batte! Sfidante di stasera: il cuscino. Vince chi resta in piedi. (Vinco io.)
- Nell'angolo rosso, campione imbattuto di questa stanza: IO. Nell'angolo blu: nessuno ha osato.
- Questa cintura da campione me la sono conquistata. Va bene, l'ho vinta a un torneo che ho inventato io.

## Bouquet da Sposa
- Chi prende il bouquet si sposa! Lo lancio... verso di te, {utente}. Non scappare, è un onore.
- Profumo di fiori e aria di festa: manca solo la torta. Anzi, la torta è la cosa che manca DI PIÙ.
- Petali ovunque e cuore in fiore. Se piango è di gioia. E per il polline, un pochino.

## Microfono da Cantante
- Uno, due, prova microfono... GRAZIE PUBBLICO! Stasera dediche a raffica, la prima è per {utente}.
- Signore e signori, applausi per me! ...Grazie, grazie, troppo buoni. (Non ha applaudito nessuno. Applaudi tu.)
- Il bis me lo chiedo da solo, così sono sicuro che arrivi. E parte! Grazie, grazie infinite!
