# Arredi collectables — prototipo

Bozza di struttura con esempi di Claude, lista definitiva da fare in sessione design. La casa parte quasi vuota: gli arredi sono la progressione visibile. Bonus passivi piccoli, mai obbligatori.

| Nome | Stanza | Razza | Rarità | Come si ottiene | Bonus |
|---|---|---|---|---|---|
| Lampada da terra | camera | entrambe | comune | negozio 30 monete | — |
| Tappeto morbido | salone | entrambe | comune | negozio 40 monete | +1 Felicità passiva |
| Poster motivazionale | camera | entrambe | comune | negozio 25 monete | +1 Felicità passiva |
| Frigo nuovo | cucina | entrambe | non comune | negozio 80 monete | sconto cibo 10% |
| Piantina strana | camera | alieno | non comune | negozio 35 monete | +1 Felicità passiva |
| Braccio meccanico da banco | cucina | robot | non comune | negozio 55 monete | +1 Intelligenza passiva |
| Vasca idromassaggio | bagno | entrambe | rara | negozio 150 monete | igiene +5 extra per lavaggio |
| Palla Giocattolo | salone | entrambe | comune | negozio 30 monete | +1 Felicità passiva |
| Robottino Giocattolo | camera | entrambe | comune | negozio 45 monete | +1 Felicità passiva |
| Trenino Giocattolo | salone | entrambe | non comune | negozio 60 monete | +1 Felicità passiva |
| Astronave Giocattolo | camera | entrambe | non comune | negozio 80 monete | +1 Felicità passiva |
| Acquario di meduse | salone | alieno | rara | negozio 120 monete | +2 Felicità passiva |
| Servostazione di ricarica | salone | robot | rara | negozio 120 monete | +2 Felicità passiva |

### Arredi da missione (sessione design missioni)

| Nome | Stanza | Razza | Rarità | Come si ottiene | Bonus |
|---|---|---|---|---|---|
| Pallone da calcio | salone | entrambe | comune | tutorial (garantito, Sportivo) | +1 Forza passiva |
| GameBit portatile | salone | entrambe | comune | tutorial (garantito, Nerd) | +1 Intelligenza passiva |
| Microfono giocattolo | salone | entrambe | comune | tutorial (garantito, Gentile) | +1 Carisma passiva |
| Fumetto sarcastico | salone | entrambe | comune | tutorial (garantito, Maleducato) | +1 Intelligenza passiva |
| Coppa Arcade | salone | entrambe | rara | drop missione rara (M1 super successo) | +1 Velocità passiva |
| Macchinina giocattolo | salone | entrambe | rara | drop missione rara (M2 super successo) | — (solo collezione) |
| Fascia da martial artist | salone | entrambe | comune | drop missione (M3 standard) | +1 Forza passiva |
| Completo da martial artist | salone | entrambe | rara | drop missione rara (M3 super successo, sostituisce Fascia) | +2 Forza passiva |
| Album da disegno | camera | entrambe | comune | drop missione (M4 standard) | +1 Intelligenza passiva |
| Libro | camera | entrambe | rara | drop missione rara (M4 super successo, sostituisce Album) | +2 Intelligenza passiva |
| Ombrello meccanico | bagno | entrambe | non comune | drop missione (M5 fallimento) | dimezza calo Igiene nelle missioni a rischio pioggia/sporco (−10 → −5) |
| Scooter giocattolo | salone | entrambe | rara | drop missione rara (M5 super successo) | +1 Velocità passiva |
| Megafono | salone | entrambe | non comune | drop missione (M6 fallimento A) | +1 Carisma passiva |
| Statuetta tipo Oscar | salone | entrambe | rara | drop missione rara (M6 super successo) | +1 Carisma passiva |
| Bastone da combattimento | salone | entrambe | comune | drop missione casuale, 1 delle 4 (M7 standard) | +1 Forza passiva |
| Sai gemelli | salone | entrambe | comune | drop missione casuale, 1 delle 4 (M7 standard) | +1 Forza passiva |
| Nunchaku arrugginiti | salone | entrambe | comune | drop missione casuale, 1 delle 4 (M7 standard) | +1 Forza passiva |
| Katane a farfalla | salone | entrambe | comune | drop missione casuale, 1 delle 4 (M7 standard) | +1 Forza passiva |
| Pesi | salone | entrambe | comune | drop missione (M7 fallimento) | +1 Forza passiva |
| Il Topo (allenatore) | salone | entrambe | rara | drop missione (M7 super Amicizia) | +1 Forza a ogni allenamento di Forza (hook dedicato in arredi.js, non e un passivo normale) |
| Pattino spaiato | salone | entrambe | comune | drop missione (M8 fallimento) | +1 Velocità passiva |
| Pattini da gara | salone | entrambe | rara | drop missione rara (M8 super successo) | +2 Velocità passiva |
| Chip di memoria | salone | entrambe | comune | Pool Inventore (talento Inventore) | +1 Intelligenza passiva |
| Ventola overcloccata | salone | entrambe | comune | Pool Inventore (talento Inventore) | +1 Velocità passiva |
| Torcia laser | salone | entrambe | rara | Pool Inventore (talento Inventore) | +2 Felicità passiva |
| Coppa della Fiera | salone | entrambe | rara | drop missione rara (M9 super successo) | +1 Intelligenza passiva |
| Coppa Robot Wars | camera | entrambe | comune | drop missione (M10 standard) | +1 Intelligenza passiva |
| Mecha-Bot | camera | entrambe | rara | drop missione rara (M10 super Intelligenza) | +2 Forza passiva |
| Telecomando Pirata | salone | entrambe | rara | drop missione rara (M10 super Maleducato) | +1 Velocità passiva |
| Cuccia | camera | entrambe | comune | drop missione (M11 standard) | +1 Felicità passiva |
| Distributore di croccantini | cucina | entrambe | non comune | drop missione (M11 fallimento Maleducato) | +1 Felicità passiva |
| Gattino Robot | camera | entrambe | rara | drop missione rara (M11 super successo) | +1 Carisma passiva |
| Manuale di Botanica | camera | entrambe | comune | drop missione (M12 fallimento) | +1 Intelligenza passiva |
| Pianta Esotica | ovunque | entrambe | rara | drop missione rara (M12 super successo) | +2 a una stat RPG casuale ogni giorno (passivo, ri-estratta ogni giorno, non si accumula) |
| Trofeo Braccio di Ferro | salone | entrambe | comune | drop missione (M13 standard) | +1 Forza passiva |
| Trofeo d'Oro Braccio di Ferro | salone | entrambe | rara | drop missione rara (M13 super successo) | +1 Forza passiva |
| Targa Traslocatore dell'Anno | salone | entrambe | comune | drop missione (M14 super successo) | +1 Forza passiva |
| Paperella a Reazione | bagno | entrambe | comune | drop missione (M15 standard) | +1 Velocità passiva |
| Scarpe da Parkour | camera | entrambe | rara | drop missione rara (M15 super successo) | +1 Velocità passiva |
| Acquario di Casa | camera | entrambe | comune | drop missione (M16 standard/super) | +1 Velocità + +1 Felicità passiva |
| Panino Più Grande del Mondo | cucina | entrambe | rara | drop missione (M18 standard) | +2 Felicità passiva |
| Disco d'Oro | camera | entrambe | rara | drop missione rara (M19 super successo) | +2 Carisma passiva |
| Spadone | salone | entrambe | rara | drop missione casuale, 1 delle 5 (M20 standard) | +2 Forza passiva |
| Martellone | salone | entrambe | rara | drop missione casuale, 1 delle 5 (M20 standard) | +2 Forza passiva |
| Doppie Lame | salone | entrambe | rara | drop missione casuale, 1 delle 5 (M20 standard) | +2 Forza passiva |
| Arco Pesante | salone | entrambe | rara | drop missione casuale, 1 delle 5 (M20 standard) | +2 Forza passiva |
| Alabarda | salone | entrambe | rara | drop missione casuale, 1 delle 5 (M20 standard) | +2 Forza passiva |
| Specchio del Dottor Enigma | bagno | entrambe | rara | drop missione rara (M21 super successo) | +1 Intelligenza passiva |
| Martelletto da Giudice | salone | entrambe | rara | drop missione rara (M22 super successo) | +2 Intelligenza + +1 Carisma passiva |
| Dipinto Artistico | salone | entrambe | non comune | drop missione (M23 standard) | +1 Intelligenza + +1 Felicità passiva |
| Dipinto Falso | salone | entrambe | comune | drop missione (M23 fallimento) | +1 Velocità + +1 Felicità passiva |
| Lente d'Ingrandimento | salone | entrambe | rara | drop missione rara (M23 super successo) | +2 Intelligenza passiva |
| Dipinto Rubato | salone | entrambe | rara | drop missione rara (M23 Cleptomane) · rivendita 40 monete | +2 Intelligenza passiva (alto valore di rivendita) |
| Scarpe da Corsa | salone | entrambe | comune | drop missione (M24 standard) | +1 Velocità passiva |
| Coppa del Vincitore | salone | entrambe | rara | drop missione rara (M24 super successo) | +2 Velocità + +1 Carisma passiva |
| Console | camera | entrambe | rara | drop missione (M25 standard) | +2 Velocità + +1 Felicità passiva |
| Gabbia per Uccelli | ovunque | entrambe | comune | drop missione (M26 standard) | +1 Velocità + +1 Felicità passiva |
| Piccione Cyborg | ovunque | entrambe | rara | drop missione rara (M26 super successo) | +2 Velocità passiva (companion nella gabbia) |
| Poster del Campione | camera | entrambe | rara | drop missione rara (M27 super successo) | +1 Forza + +1 Carisma passiva |
| Pupazzo Mostriciattolo | camera | entrambe | non comune | drop missione (M28 standard) | +1 Forza + +1 Intelligenza passiva |
| Adesivo Martello | cucina | entrambe | comune | drop missione (M29 standard) | +1 Forza passiva |
| Peluche Luna Park | bagno | entrambe | comune | drop missione (M29 fallimento) | +1 Carisma passiva |
| Martello Vero | salone | entrambe | rara | drop missione rara (M29 super successo) | +3 Forza passiva |
| Laptop | salone | entrambe | rara | drop missione rara (M30 super successo) | +2 Carisma passiva |
| Corda della Vittoria | salone | entrambe | comune | drop missione (M73 super successo) | +1 Forza passiva |
| Dinosauro Giocattolo | camera | entrambe | comune | drop missione (M74 super successo) | +1 Felicità passiva |
| Puzzle Incorniciato | camera | entrambe | comune | drop missione (M77 super successo) | +1 Intelligenza passiva |
| Piantina di Fragole | cucina | entrambe | comune | drop missione (M78 super successo) | +1 Felicità passiva |
| Burattino Drago | camera | entrambe | comune | drop missione (M79 super successo) | +1 Carisma passiva |
| Spremiagrumi d'Oro | cucina | entrambe | non comune | drop missione (M80 super successo) | +1 Carisma passiva |
| Trofeo del Porto | salone | entrambe | rara | drop missione rara (M81 super successo) | +2 Forza passiva |
| Kart a Pedali | salone | entrambe | rara | drop missione rara (M85 super successo) | +2 Velocità passiva |
| Trofeo Rana d'Oro | bagno | entrambe | non comune | drop missione (M88 super successo) | +1 Velocità passiva |
| Scacchiera d'Onice | salone | entrambe | rara | drop missione rara (M89 super successo) | +2 Intelligenza passiva |
| Gettone d'Oro | salone | entrambe | non comune | drop missione (M91 super successo) | +1 Intelligenza + +1 Felicità passiva |
| Lampada Lava di Seconda Mano | camera | entrambe | comune | drop missione (M94 fallimento) | +1 Felicità passiva |
| Lanterne della Festa | salone | entrambe | rara | drop missione rara (M96 super successo, tutte le vie) | +2 Felicità passiva |
| Sfera Tascabile | camera | entrambe | non comune | drop missione (M97 standard) | +1 Felicità passiva |
| Mostriciattolo | camera | entrambe | rara | drop missione rara (M97 super successo) | +1 Velocità passiva (companion) |
| Barattolo dei Colori Rubati | salone | entrambe | rara | drop missione rara (M98 super successo) | +1 Intelligenza + +1 Felicità passiva |

### Arredi da missione — ADULTO (P3, M33-M64)

Drop delle 32 missioni adulto. I "companion" sono arredi vivi (piccola creatura nella stanza); il bonus segue lo stesso tetto passivo degli altri arredi.

| Nome | Stanza | Razza | Rarità | Come si ottiene | Bonus |
|---|---|---|---|---|---|
| Trofeo Pinna | bagno | entrambe | non comune | drop missione (M34 standard) | +1 Forza + +1 Felicità passiva |
| Mostro del Lago | bagno | entrambe | rara | drop missione rara (M34 super successo) | +2 Forza passiva (companion) |
| Chiavi del Quartiere | salone | entrambe | rara | drop missione rara (M36 super successo) | +2 Carisma passiva |
| Medaglia del Finisher | camera | entrambe | non comune | drop missione (M37 standard) | +1 Velocità + +1 Felicità passiva |
| Torcia Olimpica | salone | entrambe | non comune | drop missione (M38 standard) | +2 Felicità passiva |
| Podio d'Oro | salone | entrambe | rara | drop missione rara (M38 super successo) | +2 a una stat RPG casuale ogni giorno |
| Skateboard Pro | camera | entrambe | non comune | drop missione (M39 standard) | +2 Velocità passiva |
| Tastiera d'Oro | camera | entrambe | rara | drop missione rara (M40 super successo) | +2 Velocità passiva |
| Gettone Nero | salone | entrambe | non comune | drop missione (M41 standard) | +1 Intelligenza + +1 Felicità passiva |
| Cabinato Maledetto | salone | entrambe | rara | drop missione rara (M41 super successo) | +2 Intelligenza passiva |
| Vaso Antico | salone | entrambe | non comune | drop missione (M42 standard) | +2 Intelligenza passiva |
| Idolo Dorato | salone | entrambe | rara | drop missione rara (M42 super successo) · rivendita 75 monete | +3 Intelligenza passiva (alto valore di rivendita) |
| Modellino Razzo | camera | entrambe | non comune | drop missione (M43 standard) | +2 Intelligenza passiva |
| Pergamena di Laurea | salone | entrambe | rara | drop missione (M45 standard/super) | +3 Intelligenza passiva |
| Poltrona del Talk | salone | entrambe | rara | drop missione rara (M47 super successo) | +2 Carisma passiva |
| Statua in Piazza | salone | entrambe | rara | drop missione rara (M48 super successo) | +3 Carisma passiva |
| Chitarra Elettrica | camera | entrambe | non comune | drop missione (M49 standard) | +2 Carisma passiva |
| Set di Coltelli | cucina | entrambe | non comune | drop missione (M50 standard) | +2 Intelligenza passiva |
| Fantasmino | camera | entrambe | rara | drop missione rara (M51 super successo) | +2 Carisma passiva (companion) |
| Sacco di Refurtiva | salone | entrambe | rara | drop missione rara (M52 super successo) · rivendita 100 monete | +1 Velocità passiva (alto valore di rivendita) |
| Palla da Demolizione | salone | entrambe | rara | drop missione rara (M53 super successo) | +3 Forza passiva |
| Trofeo Miglior Babysitter | camera | entrambe | rara | drop missione rara (M54 super successo) | +2 Carisma passiva |
| Pacco Maledetto | camera | entrambe | rara | drop missione rara (M56 super successo) | +2 a una stat RPG casuale ogni giorno |
| Spartito Maledetto | camera | entrambe | rara | drop missione rara (M58 super successo) | +2 Carisma passiva |
| Portapizze d'Oro | cucina | entrambe | rara | drop missione rara (M59 super successo) | +2 Velocità passiva |
| Frammento di Meteorite | salone | entrambe | non comune | drop missione (M60 standard) | +2 Intelligenza passiva |
| Nucleo del Meteorite | salone | entrambe | rara | drop missione rara (M60 super successo) | +2 a una stat RPG casuale ogni giorno |
| Mappa Incorniciata | salone | entrambe | non comune | drop missione (M61 standard) | +1 Velocità + +1 Intelligenza passiva |
| Forziere del Tesoro | salone | entrambe | rara | drop missione rara (M61 super successo) | +2 Velocità passiva |
| Micro-Mostro Regina | camera | entrambe | rara | drop missione rara (M62 super successo) | +2 Intelligenza passiva (companion) |
| Generatore di Scorta | salone | entrambe | rara | drop missione rara (M63 super successo) | +2 Forza passiva |
| Timone di Fortuna | bagno | entrambe | non comune | drop missione (M64 standard) | +2 Velocità passiva |
| Vela Leggendaria | salone | entrambe | rara | drop missione rara (M64 super successo) | +2 Velocità + +1 Felicità passiva |
| Foto Autografata di Fabrice | salone | entrambe | non comune | drop Grande Impresa (M69 fallimento) | +1 Carisma passiva |
| Caffettiera Bruciacchiata | cucina | entrambe | non comune | drop Grande Impresa (M71 fallimento) | +1 Intelligenza passiva |

### Companion LEGGENDARI (Grandi Imprese, P3 — super successo M65-M72)

Le 8 leggende in persona si trasferiscono a casa del pet. Arredi VIVI con bonus **+3 FISSO** che
IGNORA il tetto passivo degli arredi normali (rarità leggendaria — il motore li tratta a parte).
Uno solo per run (super della Grande Impresa estratta). Sprite dedicati in arrivo con la pipeline
leggende; fino ad allora usano il segnaposto arredo.

| Nome | Stanza | Razza | Rarità | Come si ottiene | Bonus |
|---|---|---|---|---|---|
| Giga Ciad | salone | entrambe | leggendaria | super Grande Impresa (M65) | +3 Forza passiva FISSA (companion leggendario) |
| Rocco Baldoria | salone | entrambe | leggendaria | super Grande Impresa (M66) | +3 Forza passiva FISSA (companion leggendario) |
| Padre Maronno | salone | entrambe | leggendaria | super Grande Impresa (M67) | +3 Carisma passiva FISSA (companion leggendario) |
| Forrest Gampo | salone | entrambe | leggendaria | super Grande Impresa (M68) | +3 Velocità passiva FISSA (companion leggendario) |
| Fabrice The Crown | salone | entrambe | leggendaria | super Grande Impresa (M69) | +3 Carisma passiva FISSA (companion leggendario) |
| Veggeta | salone | entrambe | leggendaria | super Grande Impresa (M70) | +3 Forza passiva FISSA (companion leggendario) |
| Sceldon | salone | entrambe | leggendaria | super Grande Impresa (M71) | +3 Intelligenza passiva FISSA (companion leggendario) |
| Tonino Stark | salone | entrambe | leggendaria | super Grande Impresa (M72) | +3 Intelligenza passiva FISSA (companion leggendario) |

### Indossabili — vestiti equipaggiati SUL pet (revamp 10 lug 2026)

Si indossano (bonus attivo mentre sono addosso), non si piazzano in una stanza. Uno alla volta + un'arma a parte. Sprite sovrapposti al pet in stanze e cartoline.

**Colonna Effetti**: stessa sintassi Tier 2 dei cibi — lista separata da virgole, stat RPG (`Forza`, `Intelligenza`, `Velocità`, `Carisma`) col segno. I MALUS FUNZIONANO e contano nelle condizioni delle missioni (es. la Pistola a -2 Carisma può far fallire una missione sociale). **Prezzo "—" = non in vendita** (solo drop).

| Nome | Tipo | Rarità | Prezzo | Come si ottiene | Effetti |
|---|---|---|---|---|---|
| Parrucchino di Elvis | indossabile | rara | 60 | negozio · drop missione (M19 standard) | Carisma +2 |
| Camice del Dottore | indossabile | rara | 45 | negozio · drop missione (M21 standard) | Intelligenza +1 |
| Toga da Avvocato | indossabile | rara | 90 | negozio · drop missione (M22 standard) | Carisma +2, Intelligenza +1 |
| Maschera da Wrestler | indossabile | rara | 80 | negozio · drop missione (M27 standard) | Forza +2, Carisma +1 |
| Bouquet da Sposa | indossabile | rara | 40 | negozio · drop missione rara (M31 super) | Carisma +1 |
| Microfono da Cantante | indossabile | rara | 70 | negozio · drop missione (M32 standard) | Carisma +2 |
| Completo da Chef | indossabile | rara | 85 | negozio · drop missione rara (M18 super) | EFFETTO SPECIALE gestito in care.js: ogni primo pasto di categoria del giorno da' +1 stat extra (non e' un bonus stat) |
| Fischietto dell'Istruttore | indossabile | non comune | — | drop missione (M83 super) | Forza +1, Carisma +1 |
| Cuffie da DJ | indossabile | rara | — | drop missione rara (M93 super) | Carisma +2 |
| Costume da Protagonista | indossabile | non comune | — | drop missione (M95 super) | Carisma +1, Intelligenza +1 |
| Costume dell'Allenatore | indossabile | rara | — | drop missione rara (M97 super) | Velocità +2 |
| Cintura Mondiale | indossabile | rara | — | drop missione rara (M33 super) | Forza +3 |
| Guantoni Consumati | indossabile | non comune | — | drop missione (M35 standard) | Forza +2 |
| Accappatoio del Campione | indossabile | rara | — | drop missione rara (M35 super) | Forza +3 |
| Scarpe d'Oro | indossabile | rara | — | drop missione rara (M37 super) | Velocità +3 |
| Tavola Leggendaria | indossabile | rara | — | drop missione rara (M39 super) | Velocità +3 |
| Casco Spaziale | indossabile | rara | — | drop missione rara (M43 super) | Intelligenza +2 |
| Cappello da Detective | indossabile | rara | — | drop missione rara (M44 super) | Intelligenza +2, Carisma +1 |
| Corona d'Alloro | indossabile | rara | — | drop missione rara (M45 super) | Intelligenza +2, Carisma +1 |
| Medaglione del Concilio | indossabile | rara | — | drop missione rara (M46 super) | Carisma +3 |
| Fascia da Sindaco | indossabile | rara | — | drop missione (M48 standard/super) | Carisma +2, Intelligenza +1 |
| Chitarra Fiammante | indossabile | rara | — | drop missione rara (M49 super) | Carisma +3 |
| Cappello da Chef | indossabile | rara | — | drop missione rara (M50 super) | Intelligenza +2 |
| Casco da Corriere Spaziale | indossabile | rara | — | drop missione rara (M55 super) | Velocità +2 |
| Cintura del Peperoncino | indossabile | rara | — | drop missione rara (M57 super) | Forza +2 |

### Indossabili MEME (revamp 10 lug 2026) — quasi nessuno è gratis

Il pattern: o costano monete, o costano una stat. Riferimenti pop storpiati (regola Vampire Survivors: restano così anche in inglese, mai marchi o nomi reali).

| Nome | Tipo | Rarità | Prezzo | Come si ottiene | Effetti |
|---|---|---|---|---|---|
| Occhialoni Fattene Una Ragione | indossabile | rara | 55 | negozio | Carisma +3 |
| Cappellino di Stagnola | indossabile | comune | 15 | negozio | Intelligenza +2, Carisma -1 |
| Sandaloni col Calzino | indossabile | comune | 12 | negozio | Velocità +1, Carisma -2 |
| Acetatona Lucida | indossabile | non comune | 45 | negozio | Velocità +3, Carisma -1 |
| Piuminone del Paninaro | indossabile | non comune | 50 | negozio | Forza +2, Velocità -1 |
| Cappelluccio Rosso dell'Idraulico | indossabile | non comune | 40 | negozio | Velocità +2 |
| Collarone della Vergogna | indossabile | comune | — | drop missione (M34 fallimento) | Forza +2, Carisma -2 |
| Visorone della Realtà Finta | indossabile | rara | — | drop missione (M25 standard) | Intelligenza +3, Velocità -2 |
| Elmo del Centurione da Selfie | indossabile | rara | — | drop missione (M42 standard) | Carisma +3, Intelligenza -1 |
| Pettorina Catarifrangente | indossabile | non comune | — | drop missione (M53 standard) | Carisma +2, Intelligenza +1 |
| Maglione della Nonna Renna | indossabile | comune | — | drop missione (M54 super) | Carisma +2, Velocità -1 |
| Cappellone di Paglietta | indossabile | rara | — | drop missione rara (M64 super) | Forza +1, Carisma +2 |
| Berrettone a Punta dell'Eroe Muto | indossabile | rara | — | drop missione rara (M61 super) | Intelligenza +2, Velocità +1 |

### Armi (equipaggiabili a parte, serve il perk Weapon Wielder)

Le armi restano anche arredi normali nelle tabelle sopra (le 4 di M7 e le 5 Kaiju di M20): qui c'è solo quella che vive fuori dalle stanze.

| Nome | Tipo | Rarità | Prezzo | Come si ottiene | Effetti |
|---|---|---|---|---|---|
| Bastone da combattimento | arma | comune | 80 | negozio · drop M7 standard | Forza +1 |
| Sai gemelli | arma | comune | 80 | negozio · drop M7 standard | Forza +1 |
| Nunchaku arrugginiti | arma | comune | 80 | negozio · drop M7 standard | Forza +1 |
| Katane a farfalla | arma | comune | 80 | negozio · drop M7 standard | Forza +1 |
| Spadone | arma | rara | 150 | negozio · drop M20 standard | Forza +2 |
| Martellone | arma | rara | 150 | negozio · drop M20 standard | Forza +2 |
| Doppie Lame | arma | rara | 150 | negozio · drop M20 standard | Forza +2 |
| Arco Pesante | arma | rara | 150 | negozio · drop M20 standard | Forza +2 |
| Alabarda | arma | rara | 150 | negozio · drop M20 standard | Forza +2 |
| Pistola Spara-Spazzatura | arma | rara | 250 | negozio · drop missione rara (M28 super successo) | Forza +4, Carisma -2 |

### GIOCATTOLI — il menù "Usa un giocattolo" (revamp 10 lug 2026)

**Cambiamento di design voluto dal fondatore**: l'azione del salone non è più il generico "Gioca 10 minuti" uguale per tutti. Ora si apre un **menù dei giocattoli posseduti**, ognuno con scritto cosa fa, e il giocatore sceglie quale usare. Il giocattolo non è più un soprammobile: è un'azione. Tutti i giocattoli devono restare usabili dal salone.

**Colonna Effetto** = vocabolario chiuso letto dal motore (un solo effetto per giocattolo):
- `felicita+N` — dà N Felicità (il gioco classico)
- `consola` — +12 Felicità, ma SOLO se la Felicità è sotto 30 (sopra, il pet lo ignora con una battuta)
- `decrescente` — +8 Felicità al primo uso del giorno, +4 al secondo, +2 dal terzo in poi
- `cura_stato` — −25 Ferite
- `consiglio` — +3 Felicità e un messaggio che rivela la stat più bassa del pet
- `oracolo` — estrae 1 dei 6 responsi qui sotto, vale fino a fine giornata di gioco
- `duello` — −10 Energia, +8/+15 monete (l'unico modo di convertire Energia in monete)
- `progressione:N` — ogni uso avanza una barra NASCOSTA; al N-esimo dà +3 Intelligenza permanenti e riparte
- `notturno:monete+N` — passivo: N monete al risveglio del mattino
- `sveglia_gratis` — passivo: svegliare il pet prima del tempo non costa penalità di Energia

| Nome | Stanza | Prezzo | Come si ottiene | Usi al giorno | Effetto |
|---|---|---|---|---|---|
| Palla Giocattolo | salone | 30 | negozio | 2 | felicita+6 |
| Squalotto Trescarpe | salone | 25 | negozio | 3 | consola |
| Scatoletta Inutile | camera | 20 | negozio | illimitati | decrescente |
| Cartuccia Soffiona | camera | 35 | negozio | 1 | cura_stato |
| Paperotta Consigliera | bagno | 40 | negozio | 1 | consiglio |
| Sfera Sentenziosa | salone | 45 | negozio | 1 | oracolo |
| Trottolone Sbatacchione | salone | 55 | negozio | 3 | duello |
| Cubbolo Sei Facce | camera | 50 | negozio | 2 | progressione:7 |
| Peluffo Ciarliero | camera | 70 | negozio | passivo | notturno:monete+15 |
| Robottino Giocattolo | camera | 45 | negozio | 2 | felicita+6 |
| Trenino Giocattolo | salone | 60 | negozio | 2 | felicita+6 |
| Astronave Giocattolo | camera | 80 | negozio | 2 | felicita+6 |
| Ciucciolotto Piagnucolone | camera | — | drop missione (M11 standard) | 2 | consola |
| Pescione Cantautore | salone | — | drop missione rara (M16 super) | passivo | sveglia_gratis |

**I 6 responsi della Sfera Sentenziosa** (valgono fino a fine giornata di gioco, estratti a caso): "Certamente" → +25% monete dalle missioni · "È deciso" → prossima missione con soglia super più bassa di 3 · "Chiedimelo domani" → nessun effetto e il pet si offende (−2 Felicità) · "Non ci contare" → −10% monete · "Le prospettive non sono buone" → la prossima missione costa +5 Energia · "Segni positivi" → +5 Felicità.

**Nota sul Cubbolo**: la barra di progressione è NASCOSTA al giocatore (regola sacra niente-spoiler); quando si completa parte la scenetta del pet che risolve il cubo.

### Modifiche permanenti (M17 Pimp My Pet — NON arredi né indossabili: cambiano lo sprite del pet per sempre)

Scelta del giocatore all'evoluzione teen (+2 permanente alla stat scelta + look permanente). Robot: Servo-braccia (Forza) / Turbina dorsale (Velocità) / Antenna neurale (Int) / Insegna al neon (Carisma). Alieno: Chele (Forza) / Pinne (Velocità) / Terzo occhio (Int) / Bioluminescenza (Carisma). Servono 8 varianti sprite permanenti.

Stanza assegnata per tema (PROTOTIPO 2, Blocco 7 — collectables in tutte le stanze): cibo/elettrodomestici → cucina (Frigo nuovo, Braccio meccanico da banco, Distributore di croccantini), accessori bagno → bagno (Vasca idromassaggio, Ombrello meccanico, Paperella a Reazione), relax/notte/lettura/cuccioli → camera (Lampada da terra, Poster motivazionale, Piantina strana, Album da disegno, Libro, Coppa Robot Wars, Mecha-Bot, Cuccia, Gattino Robot, Manuale di Botanica, Scarpe da Parkour, Acquario di Casa), trofei/giochi/armi/sport → salone (il resto, incl. Trofeo Braccio di Ferro, Trofeo d'Oro, Targa Traslocatore, le 5 armi del Kaiju). Teen: Panino Più Grande del Mondo → cucina, Disco d'Oro → camera. La Pianta Esotica (M12 super) è l'unico arredo mettibile in QUALSIASI stanza. Ogni stanza ha 3 slot con supporti dedicati (v. rooms.js _slotSpots/_slotTipi). Da rifinire in sessione design se servono ribilanciamenti.

Da decidere in sessione design:
- Quanti slot arredo per stanza nel prototipo (proposta: 3)
- Doppioni: prezzo di rivendita (proposta: 50% del valore)
- 2-3 arredi "wow" per il tema laboratorio e astronave
