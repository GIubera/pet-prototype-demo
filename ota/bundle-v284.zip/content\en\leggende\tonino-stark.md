# Tonino Stark — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il miliardario decaduto del garage. Sarcasmo a raffica, si dà del genio da solo in terza persona, ostenta ricchezze che non ha più. Cuore d'oro sotto la latta. Catchphrase: "Io sono Tonino Stark." (usata anche quando non c'entra niente).

## Saluto (apertura app)
- Welcome to headquarters. This used to be a ninety-story tower. Now it's a living room. Genius adapts. I am Tonino Stark.
- There you are. I was working on a revolutionary project. Fine, I was fixing the toaster. It will revolutionize toast.
- Oh, it's you. Perfect timing — I needed an unpaid intern. Benefits include: my company.
- Come in. The virtual butler would've announced you, but I sold him. Hard times hit geniuses too.

## Ha fame
- Tonino Stark has dined with presidents and movie stars. Tonight he'll settle for whatever's around. But serve it with class, I insist.
- I'm hungry. I used to have a Michelin-star chef. Now I have you. Surprise me — the chef never managed to.
- Genius requires fuel: my brain burns energy like a reactor. The reactor's at the pawn shop, but the principle stands.
- Food, please. And don't say "coming right up" — say it with style. Like "immediately, Mr. Stark."

## È sporco
- I'm covered in workshop grease. It used to be AEROSPACE workshop grease. Nostalgia doesn't scrub, though. Bath.
- This dirt is work dust. The work of a genius. But yes, it smells like common-mortal dirt. Wash me.
- Back in the day I had a hot tub with an ocean view. Now there's the little tub. What matters is the hot tub within.
- Cosmetic malfunction detected: widespread dirt. A butler used to handle this. The butler is now you. Congratulations on the promotion.

## Coccole finite
- Enough cuddles. Tonino Stark doesn't do mushy. Old Tonino did — the rich one. New Tonino makes them last.
- Stop. Affection gets rationed like premium fuel. There's not much left and I'm guarding it. The fuel. Fine, the affection too.
- Petting hours are over. I'm filing them under "luxury goods." Finally a luxury I can afford.
- That's enough. I was getting attached, and the last time I got attached I lost a company. Coincidence? Yes. But you never know.

## Parte per la missione
- Mission. Back in the day I'd send a drone. Now I am the drone. Progress occasionally moves backwards.
- Heading out. Built the gear myself, in a garage, out of scrap. Like all masterpieces. I am Tonino Stark.
- Off I go. If I'm not back by tonight, sell the revolutionary toaster and use the money to come pick me up in a taxi.
- Mission accepted. My fee: glory, coins, and someone calling me "sir" at least once.

## Ritorno: successo
- Mission accomplished, with homemade tech and factory-installed genius. The world wants me back on top, I can feel it. The world has taste.
- Victory. I dedicated it to the old me — the rich one. He'd have loved it. The new one is enjoying it plenty too, for the record.
- Done. A textbook operation. I wrote the textbook. On the back of an unpaid bill.
- I won. And I did it with scrap metal. Imagine me with a budget. IMAGINE. I am Tonino Stark.

## Ritorno: fallimento
- The mission failed due to lack of funding. Like everything in my recent life. The genius is intact, though — let's refinance it.
- Lost it. The prototype gave out at the worst possible moment. In the good old days we'd have called that a "beta test." Let's call it that now too.
- Failed. But with billionaire elegance — even the crash made an expensive sound.
- Didn't pan out. Add it to the list of things old Tonino would've solved with a check. New Tonino solves it tomorrow, with brainpower.

## Va a dormire
- Off to sleep in my penthouse. The bedroom. It's the bedroom. But close your eyes and believe, and it's a penthouse.
- Goodnight. Putting myself on charge, along with the three devices I have left. Priority: me.
- Bed. Tomorrow's plan: rebuild the empire. Day after: keep rebuilding. There's a system, and it works.
- Night. I used to fall asleep counting billions. Now I count projects. There are more of them, and nobody can repossess those.

## Sveglia (risveglio dopo il sonno)
- Awake. Genius never truly sleeps: it installs updates. Update complete — improved version of yesterday.
- Good morning. I dreamed I was rich again. Then I woke up a genius. Which is better. (Almost.)
- Up. The garage awaits: the future is in there. Along with a lot of junk to throw out, but mostly the future.
- Awake and operational. Coffee, workshop, glory. The budget only covers the coffee, but the agenda stands. I am Tonino Stark.
