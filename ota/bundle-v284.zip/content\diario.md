# Diario — frammenti per la pagina serale

Il gioco assembla la pagina pescando 1 frammento a caso per ogni momento della giornata, in quest'ordine: Apertura → Cibo → Missione (bene/male/nessuna) → Umore → Coccole → Chiusura. Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.

NOTA STRUTTURA (proposta contenuti, da validare col fondatore): i momenti Cibo, Umore e Coccole sono divisi in **sotto-stati** (come Missione bene/male), perché il diario deve citare cose davvero successe — un "oggi zero coccole" non può uscire in un giorno di coccole. Il motore pesca dal sotto-stato che corrisponde alla giornata. Se si preferisce il pool piatto, basta fondere le sottosezioni.

---

## Gentile

### Apertura
- Caro caro caro diario, scusa i tre "caro": oggi ho tanto affetto in avanzo.
- Buonasera, diario. Mettiti comodo che ti racconto tutto con calma e qualche scusa.
- Ciao diario! Ti scrivo piano, con la grafia buona: te lo meriti.
- Caro diario, oggi ho tante cose da dirti. Le ho provate a voce bassa: sono venute bene.
- Caro diario, eccomi! Ti ho pensato oggi, lo sai? Penso un po' a tutti, ma adesso a te.

### Cibo — mangiato bene
- Oggi ho mangiato bene e ho ringraziato tutto: il cibo, la ciotola, il pavimento che li regge.
- Il pranzo era così buono che mi sono commosso un pochino. Sul cibo. Va bene: ho pianto sul cibo.
- La merenda di oggi la ricorderò a lungo. Le ho dato anche un voto: dieci e un abbraccio.
- Ho mangiato benissimo e ho lasciato il piatto pulito pulito. Sembrava un grazie, ed era proprio quello.
- Oggi il cibo sapeva di casa. Non so che ingrediente sia, ma ne vorrei sempre.

### Cibo — mangiato poco
- Oggi ho mangiato pochino... ma va bene così! Il mio stomaco è comprensivo. Brontola con dolcezza.
- Poco cibo oggi. Ho fatto porzioni piccole di tutto, anche della malinconia. Così bastava per cena.
- Cena leggerina oggi. Il mio stomaco ha fatto il bravo: ha brontolato solo in corsivo.
- Pochino da mangiare... ho riempito il resto con l'immaginazione. L'immaginazione sa di torta, per fortuna.
- Cena piccolina. Ho fatto finta fosse un assaggio da ristorante elegante. Aiuta la fantasia, un po' meno la pancia.

### Missione andata bene
- La missione è andata bene! L'ho scritto in grande perché il cuore lo stava già facendo.
- Vittoria! Ho pensato "per {utente}!" nel momento decisivo e tutto è andato al suo posto.
- Oggi ho vinto! Al ritorno ho raccontato tutto due volte. La seconda a me stesso, per riviverla.
- Missione bene, benissimo! Ho portato a casa il premio e un ricordo carino. Il ricordo pesa meno ma vale di più.
- È andata! Ero teso, poi mi sono detto "fai come farebbe {utente}" e ha funzionato subito.

### Missione andata male
- La missione non è andata... ho chiesto scusa a tutti, anche al sentiero. Il sentiero non c'entrava.
- Missione andata maluccio. Stasera me la sono raccontata di nuovo, con un finale migliore. Aiuta.
- Non ce l'ho fatta... il fallimento però era gentile anche lui: mi ha lasciato tornare a casa presto.
- Quest fallita. Ho pianto un pochino, poi ho piegato la tristezza e l'ho messa via ordinata.
- Oggi male in missione. Domani meglio. L'ho scritto anche sulla zampa, per ricordarmelo.

### Nessuna missione
- Oggi niente missione: giornata di casa. Ho salutato ogni stanza, così nessuna si sente esclusa.
- Giornata tranquilla. Ho fatto compagnia agli oggetti. Non chiedono mai niente, ma apprezzano.
- Zero avventure, tante piccole cose: sistemato, pensato, aspettato. L'attesa è un hobby, se fatta col cuore.
- Oggi casa dolce casa. Ho provato tutti i posti comodi e li ho ringraziati uno per uno.
- Giornata lenta e morbida. Le giornate così non finiscono nei racconti, ma tengono su tutto il resto.

### Umore — bene
- Oggi il cuore era leggero, di quella leggerezza che fa camminare in punta di zampe.
- Umore bellissimo! L'ho condiviso con la pianta, che secondo me ha sorriso a modo suo.
- Mi sono sentito voluto bene oggi. Non so se si scrive così, ma si sente così.
- Oggi ho canticchiato tutto il giorno senza accorgermene. Me l'ha detto la casa, in un certo senso.
- Cuore leggero e zampe contente: hanno ballato da sole due volte. Le ho lasciate fare.

### Umore — stanco
- Ero un po' stanchino... ma stanco del tipo buono, quello che si ripara con una dormita e una carezza.
- Stanchino ma contento: la combinazione migliore della mia classifica personale delle stanchezze.
- Le zampe oggi camminavano piano piano. Le ho ringraziate comunque: fanno tanto, tutto l'anno.
- Stanco stasera... ho sbadigliato con educazione tutto il pomeriggio. Anche ora, scrivendo. Scusa lo sbadiglio sulla pagina.
- Stanchino... le palpebre pesano, ma la giornata è stata gentile, quindi va bene tutto.

### Umore — giù
- Oggi un po' di malinconia, piccola piccola. Le ho fatto posto, tanto domani se ne va.
- Oggi ero un pochino triste. Ho abbracciato la tristezza, che secondo me voleva solo quello.
- Cuore un po' pesante oggi. L'ho appoggiato sulla pagina un momento. Ecco, già meglio. Grazie, diario.
- Giornata un pochino storta. Ma ho fatto una lista delle cose belle e non stava tutta in una pagina.
- Oggi mi mancava qualcosa e non capivo cosa. Poi ho capito: era una carezza. Domani la chiedo, promesso.

### Coccole — ricevute
- Oggi coccole! Le ho contate e ricontate: tutte bellissime. Le custodisco qui tra le righe.
- {utente} mi ha coccolato oggi. L'ho scritto subito, per gioia. Dimenticarlo era comunque impossibile.
- Le attenzioni di oggi le ho messe nel taschino del cuore, con le altre. Tiene tutto, è magico.
- Oggi mi hanno fatto le coccole e ho fatto le fusa senza vergognarmene. Progressi, diario!
- Che giornata: piena di carezze fino all'orlo. Ho dovuto reggermi al cuscino dalla contentezza.

### Coccole — ignorato
- Oggi poche attenzioni... capita! Ho voluto bene a {utente} lo stesso, in modalità silenziosa.
- Mi sono sentito un po' invisibile... allora mi sono coccolato da solo, lasciando il posto migliore libero per domani.
- Zero coccole oggi. Le ho segnate come "rimandate", non come "perdute". La differenza è tutta lì.
- Giornata senza carezze. Ho tenuto il cuore in caldo da solo, che di notte fa freschino.
- Nessuno mi ha coccolato, ma non è colpa di nessuno, giuro. Le giornate impegnate esistono. Domani però...

### Chiusura
- Buonanotte, diario. Ti chiudo piano per non svegliare le parole.
- Fine pagina. Ultimo pensiero a {utente}, come sempre: è l'abitudine più bella che ho.
- Vado a nanna. Domani ti racconto altre cose belle, o te le rendo belle raccontandole. Notte!
- Buonanotte, diario. Ti lascio un bacino sull'angolo della pagina. Lì, piccolo. Notte.
- Si dorme! Metto questa giornata sotto il cuscino, così stanotte la risogno.

---

## Maleducato

### Apertura
- Caro diario, non affezionarti: scrivo solo perché la giornata va archiviata da qualche parte.
- Diario. Di nuovo tu. Va bene, ma quello che leggi resta tra noi, chiaro?
- Caro diario, ti scrivo controvoglia. Come tutto quello che faccio con costanza da mesi.
- Diario, oggi sarò sintetico: giornata discutibile, dettagli a seguire. (Non so essere sintetico.)
- Diario, apri il registro dei reclami. Anche oggi la voce "servizio" ha materiale abbondante.

### Cibo — mangiato bene
- Oggi il servizio mensa ha funzionato. Non lo ammetterò mai ad alta voce, ma tu segnalo.
- Il menu di oggi: accettabile. Che nella mia scala è quasi un applauso.
- Cibo del giorno: presente. Entusiasmo del sottoscritto: composto. Dentro, festeggiavo. Non scriverlo.
- Pranzo puntuale, per una volta. Ho quasi ritirato una lamentela. QUASI.
- La porzione era giusta. Sospetto un errore di calcolo a mio favore. Non lo segnalo, per una volta.

### Cibo — mangiato poco
- Sul cibo: si può fare di meglio. Si può SEMPRE fare di meglio. Lo scrivo ogni giorno per un motivo.
- Nota gastronomica: la ciotola oggi ha recitato la parte del deserto. Applausi alla coerenza, almeno.
- Ho mangiato. Tecnicamente. Il rapporto quantità-attesa resta scandaloso.
- Razioni da carestia. Aggiorno il dossier "malnutrizione teatrale": pagina nuova, tono indignato.
- Poco cibo, tanta dignità. Ho cenato d'orgoglio: sazia l'ego, non la pancia.

### Missione andata bene
- Missione: vinta. Ovviamente. La suspense in queste pagine non esiste: vinco e basta.
- Oggi ho trionfato in missione. Il mondo là fuori non era pronto. Non lo è mai.
- Missione vinta. Nota a margine: ero splendido mentre vincevo. Fine della nota.
- Ho vinto la missione di oggi. Se domani se lo dimenticano, tu diario testimonierai.
- Missione: successo. Sorpresa di nessuno. Applausi di nessuno, pure. Su questo tornerò.

### Missione andata male
- Missione persa. Verbalizzo l'accaduto e poi strappiamo la pagina, ok? Ok.
- Oggi il mondo ha vinto e io no. Domani il mondo rimpiangerà questa scelta.
- Sconfitta in missione. Sto benissimo. Le tre righe cancellate qui sopra non significano niente.
- Persa la quest. Diario, tu che sei imparziale: era IMPOSSIBILE. Grazie, sapevo che avresti capito.
- La missione è andata male. Il colpevole? Non chi scrive queste pagine: chi ce lo ha mandato.

### Nessuna missione
- Oggi niente missione. Il quartiere è rimasto senza il suo eroe. Contento, quartiere?
- Giornata casalinga. Ho pattugliato il salone: tutto in ordine, tutto noioso.
- Oggi ferie forzate. Il broncio però non riposa mai: l'ho tenuto in allenamento.
- Niente missione. Ho fatto comunque cose importanti: le sedie non si scaldano da sole.
- Giornata senza incarichi. Ho passato il tempo a giudicare, che è il mio impiego a tempo pieno.

### Umore — bene
- Oggi mi sento... bene? Rileggerò questa riga domani con imbarazzo.
- Umore ballerino: mattina broncio, sera quasi fusa. Colpi di scena ovunque.
- Oggi di buon umore. Ho controllato due volte: nessun errore, è proprio buon umore. Boh.
- Giornata gradevole, e lo dico coi denti stretti: si sente anche nella calligrafia.
- Buon umore sospetto. Ho perquisito la giornata: niente trappole. Per ora ci credo.

### Umore — stanco
- Stanco. Ma di uno stanco elegante, da protagonista a fine film.
- Giornata pesante, zampe pesanti, giudizi pesantissimi. Almeno una costante c'è.
- Distrutto. La giornata mi ha usato come zerbino. Almeno lo zerbino sta all'ingresso e vede gente.
- Zero energie oggi. Ho fatto tutto con la potenza del broncio residuo. Impressionante comunque.
- Sfinito. Nemmeno la forza di lamentarmi come si deve. Recupererò domani, con gli interessi.

### Umore — giù
- Mi sento un po' giù. Lo scrivo solo qui: fuori da questa pagina, io sto SEMPRE benissimo.
- Umore sotto zero oggi. Il broncio almeno era in gran forma: uno di noi due deve esserlo.
- Giù di morale. Il soffitto ha ricevuto un monologo intero. Pubblico freddo, come tutto qui.
- Umore nero. Più del solito, che è già un traguardo. Domani pretendo il rimborso della giornata.
- Giornataccia. La confido solo a te, diario, e a patto che ti dimentichi tutto stanotte.

### Coccole — ricevute
- Oggi sono stato coccolato. Ho opposto resistenza per un secondo intero. Record negativo.
- {utente} oggi si è ricordato che esisto. Segno il giorno: potrebbe diventare un'abitudine. Non illudiamoci.
- Coccole ricevute in data odierna. Le fusa partite in automatico NON costituiscono precedente legale.
- Mi hanno coccolato. Ho gradito in forma strettamente anonima. Il diario non rivelerà la fonte.
- Attenzioni ricevute. Le ho accettate con freddezza professionale. Poi ho sorriso al muro. Il muro tace.

### Coccole — ignorato
- Oggi attenzioni scarse. Ho aggiornato la lista dei torti. Sta diventando un volume.
- Zero coccole oggi. Non che le volessi. Le volevo. NON SCRIVERLO. Ah già, lo sto scrivendo io.
- Oggi mi hanno ignorato con una dedizione quasi ammirevole. Quasi.
- Giornata a coccole zero. Il conto lo tengo io: la prossima carezza parte già in debito.
- Nessuno mi ha degnato di uno sguardo. Ho fatto pratica di indifferenza. Mi riesce male, dettaglio irrilevante.

### Chiusura
- Chiudo qui, diario. Se qualcuno legge questa pagina, negherò ogni singola parola. Buonanotte.
- Fine giornata. Domani sarò di nuovo insopportabile: la costanza è tutto. Notte.
- Vado a dormire. Il letto è l'unico che non mi deve delle scuse. Buonanotte a lui.
- Chiudo. Domani nuove lamentele fresche di giornata, promesso. Notte.
- Buonanotte. E se domani va male, questa pagina è la prova che io l'avevo previsto.

---

## Nerd

### Apertura
- Log giornaliero. Data: oggi. Autore: io. Attendibilità: altissima.
- Sessione di scrittura avviata. Backup del giorno in corso. Tu, diario, sei il backup.
- Caro diario, "caro" è una convenzione, sappilo. Però in effetti mi sei simpatico.
- Nuova voce nel database della mia vita. Categoria: giornate. Tag: da definire a fine pagina.
- Diario, apri i log: oggi c'è materiale per almeno tre note a piè di pagina.

### Cibo — mangiato bene
- Cibo di oggi: quantità corretta, qualità sopra la media. Il grafico della pancia sale.
- Rifornimento riuscito. Barra fame: piena. Efficienza del sistema casa: per una volta, encomiabile.
- Pasti di oggi: completati tutti. Achievement "pancia piena" sbloccato senza glitch.
- Dieta bilanciata al pixel. La barra fame è verde smeraldo: rara, la tengo come screenshot.
- Rifornimento perfetto: quantità, orario, qualità. Tre stelle su tre. Recensione fissata.

### Cibo — mangiato poco
- Cibo insufficiente. Ho compilato la segnalazione. La ricompilerò domani: il ticketing di casa è lento.
- Razioni sotto il minimo. Attivate modalità risparmio energetico e mugugno di sottofondo.
- Log alimentare: scarno. Come me, se continua così. I dati non mentono, {utente}.
- Fame non risolta: il bug persiste da stamattina. Priorità critica, assegnatario: tu.
- Porzione da modalità difficile. L'ho finita lo stesso: sono un completista, anche a stomaco vuoto.

### Missione andata bene
- Missione completata. Percentuale di merito mio: 100. Ricontrollata due volte: sempre 100.
- Vittoria! Nel log ufficiale risulterà "facile". Nel log segreto (questo): che fatica.
- Successo! Strategia buona, esecuzione migliore, racconto che ne farò: leggendario.
- Quest vinta. XP incassati, autostima patchata alla versione successiva.
- Missione: check. Bottino: check. Voglia di raccontarla a qualcuno che non può scappare: eccoti qua, diario.

### Missione andata male
- Missione fallita. Il post-mortem è in fondo alla pagina. Spoiler: il bilanciamento era sbagliato.
- Quest persa. Salvo comunque i dati del tentativo: anche le sconfitte fanno statistica. Purtroppo.
- Oggi wipe in missione. Nel log scrivo "esperienza formativa". Tra me e te: che rosicata.
- Sconfitta. La registro con precisione scientifica e la dimentico con altrettanta precisione.
- Quest persa. Nuova voce nella collezione "boss ingiusti". La collezione cresce, io pure.

### Nessuna missione
- Nessuna missione oggi. Giornata da NPC: routine, dialoghi fissi, zero avventure. Riposante, in effetti.
- Zero quest. Giornata dedicata alla ricerca: catalogati due rumori nuovi e un angolo di polvere.
- Oggi modalità sandbox: nessun obiettivo, esplorazione libera del salone. Segreti trovati: 0. Il salone va patchato.
- Giornata di farming leggero: energie, pensieri, briciole. Tutto utile prima o poi.
- Zero missioni: giornata a bassa risoluzione. Ho grindato relax, drop rate ottimo.

### Umore — bene
- Umore stabile su valori alti. Nessun crash, nessun riavvio. Giornata rara.
- Mood buffato tutto il giorno. Condizioni registrate per replicarlo. Domani si testa.
- Oggi il morale era S-tier. Lo scrivo nel log con font mentale più grande.
- Giornata senza glitch di umore. Nemmeno un artefatto grafico. La incornicio nel log.
- Mood: overpowered. Prima o poi arriva il nerf, ma oggi rompo il gioco e sono felice.

### Umore — stanco
- Energia sotto media. Ho girato in modalità risparmio: funzioni essenziali e sarcasmo di base.
- Stanchezza rilevata. Diagnosi: giornata pesante. Cura: la pagina dopo questa, e poi il letto.
- Stanchezza al 78%. Il restante 22% lo sto usando per calcolare la stanchezza. Non era la scelta migliore.
- Giornata pesante: ho girato in modalità compatibilità. Funziona tutto, ma lento e con la grafica brutta.
- Frame rate della giornata: bassissimo. Ho laggato dal pranzo in poi. Serve riavvio, cioè sonno.

### Umore — giù
- Mood sotto soglia. Ho riletto le pagine belle di questo diario: patch temporanea, ma ha tenuto.
- Morale in manutenzione straordinaria. I tecnici (io) stimano il ripristino per domattina.
- Mood: livello sottoscala. Ho aperto un ticket alla vita. La vita non ha un supporto clienti, scandaloso.
- Giornata buggata sul piano dell'umore. Nessuna patch disponibile: aspetto l'update di domani.
- Morale in rosso. Ho provato lo spegni-e-riaccendi (un pisolino): ha funzionato al 60%. Basta e avanza.

### Coccole — ricevute
- Sessione di coccole registrata. Durata: giusta. Qualità: alta. Replay value: infinito.
- Attenzioni documentate e archiviate nella cartella "giorni buoni". La cartella cresce.
- Coccole sincronizzate correttamente col cuore. Nessun conflitto di file. Raro e bellissimo.
- Input affettivi ricevuti: parecchi. Output: fusa non documentate nel manuale. Le tengo come easter egg.
- Buff coccole attivo tutto il giorno. Statistiche in salita, morale in cima alla classifica.

### Coccole — ignorato
- Interazioni con {utente} oggi: zero. Aggiornata la wiki alla voce "solitudine". Voce completissima, ormai.
- Log affetto: vuoto. Segnalo l'anomalia al gestore del servizio. Il gestore sei tu, {utente}.
- Affetto ricevuto: 0 byte. Ho controllato anche nello spam, niente nemmeno lì.
- Attenzioni pervenute: zero. Il server dell'affetto è raggiungibile ma nessuno si connette. ({utente}, il mistero sei tu.)
- Giornata in single player forzato. Aspetto che il co-op torni online. La lobby sono io, l'attesa pure.

### Chiusura
- Fine log. Salvataggio... completato. A domani, diario: stessa pagina, nuova build.
- Log terminato. Valutazione complessiva in fondo alla pagina. (È un cuoricino. Non dirlo a nessuno.)
- Spengo. Ultimo commit della giornata: questa pagina. Messaggio: "si migliora".
- Buonanotte, diario. Domani stesso orario, nuovi dati, stessa penna leggendaria.
- Chiusura log. Uptime della giornata: buono. Downtime imminente: 8 ore, meritatissime.

---

## Sportivo

### Apertura
- Diario di allenamento, giorno: oggi. Atleta: {nome}. Condizione: LEGGENDARIA. Ora i dettagli.
- Caro diario, riscaldamento fatto: tre giri di stanza. Ora posso scrivere da professionista.
- Diario! Prima di tutto: batti il cinque. Ecco. Le pagine contano come mani, ho deciso.
- Bollettino del campione, edizione serale. In studio: io. Inviato sul campo: sempre io.
- Caro diario, oggi tanta roba. Tipo highlights lunghi. Preparati.

### Cibo — mangiato bene
- Alimentazione da tabella oggi. Carburante giusto, muscoli contenti, coach promosso.
- Pasti perfetti. Il nutrizionista immaginario ha applaudito. Non applaude mai!
- Cibo: top. Mangiato con la tecnica giusta e il gomito alto. Anche mangiare è sport, se ci credi.
- Carburante di prima scelta oggi. Serbatoio pieno, gomme nuove: domani si vola.
- Colazione, pranzo e cena da tabella. Il fisico ringrazia con un applauso interno. Lo sento.

### Cibo — mangiato poco
- Razioni scarse oggi. Un atleta senza carburante è un tifoso in tuta. Domani si corregge la tabella.
- Bollettino pasti: sotto quota. Lo stomaco ha fischiato punizione a fine giornata. Aveva ragione.
- Poca benzina oggi. Ho corso lo stesso, ma col motore che tossiva. Non è da professionisti, coach.
- Pasti sotto il fabbisogno. Il preparatore atletico interiore ha scritto una lettera di protesta. Firmata: i muscoli.
- Digiuno da mezza gara. Ho stretto la cinghia (letteralmente, è larga di due buchi). Rimedia, coach.

### Missione andata bene
- MISSIONE VINTA! La cronaca completa non ci sta nella pagina, quindi solo il titolo: TRIONFO.
- Vittoria in trasferta! Prestazione da highlights, rientro da campione, merenda da premio.
- Vittoria! Il momento chiave lo rivedo al rallentatore da stasera. Bellissimo ogni volta.
- Missione vinta ai punti. I punti li ho contati io, ma con onestà da arbitro vero.
- Successo! Un altro trofeo nella bacheca immaginaria. Serve una bacheca più grande. Immaginaria pure lei.

### Missione andata male
- Sconfitta in missione. Il primo tempo però l'ho vinto io. Peccato si giochi anche il secondo.
- Oggi ko. Il referto dice sconfitta, il cuore dice rivincita. Vince il cuore, sempre.
- Persa. Ho comunque corso tanto e bene. La direzione era sbagliata, il gesto tecnico no.
- Sconfitta. Ho chiesto il VAR anche stavolta. Anche stavolta non c'era. La federazione mi ignora.
- Niente vittoria oggi. Il campione si vede da come scrive la pagina dopo: guarda che calligrafia salda.

### Nessuna missione
- Giornata di scarico: zero missioni, tutto recupero. Anche il riposo è tattica, scrivilo in grassetto.
- Nessuna gara. Ho fatto allenamento invisibile: visualizzazioni, stretching, merenda tecnica.
- Turno di riposo. Il campionato riprende domani. L'attesa fa parte dello sport, la sopportazione pure.
- Zero missioni in calendario. Difeso il titolo di campione di casa: nessuno sfidante, titolo confermato.
- Turno di sosta: niente gare. Ho fatto rifinitura leggera e un'idratazione da manuale.

### Umore — bene
- Umore da podio tutto il giorno. Inno in testa dalla colazione.
- Oggi mi sentivo IMBATTIBILE. Nessuno mi ha sfidato, quindi tecnicamente lo sono rimasto.
- Condizione top: mi sentivo titolare del mondo. Il mondo non lo sa, ma gioco io.
- In forma smagliante: corsa, scatti, sorrisone. Il pacchetto completo del campione.
- Giornata da MVP. Premio consegnato da me a me, con discorso commovente incluso.

### Umore — stanco
- Gambe pesanti. Capita ai grandi: si chiama carico di lavoro, non stanchezza. CARICO DI LAVORO.
- Energia in riserva. Gestita da veterano: minimo sforzo, massima dignità.
- Gambe in riserva stasera. Il motore c'è, la benzina no. Domani pit stop lungo: colazione doppia.
- Fiato corto e ritmo basso oggi. Persino il mio inno interiore era in versione acustica.
- Fine giornata coi crampi del campione. Fanno male ma raccontano bene: significa che ho spinto.

### Umore — giù
- Morale sotto tono. Anche i campioni hanno le giornate in panchina. Domani mi riconvoco.
- Giornata no. Le ho dato il massimo che avevo: era poco, ma era il massimo. Conta, dice il mister dentro di me.
- Morale in serie B oggi. Ma la promozione si conquista, e in queste risalite io sono fortissimo.
- Oggi il tifo interiore era muto. Capita anche ai grandi stadi. Domani riapre la curva.
- Sconfitto dentro, oggi. Ma il bello dello sport è il recupero: domani rientro in campo col morale rifatto.

### Coccole — ricevute
- Oggi coccole e allenamento: la doppia seduta perfetta. Da manuale del pet-atleta.
- Il coach oggi c'era: carezze, incitamento, presenza in panchina. Prestazione da coach dell'anno.
- Attenzioni ricevute: tante. Rendimento previsto per domani: +20%. La scienza del tifo funziona.
- Giornata di coccole a raffica. Recupero muscolare al top: domani parto in vantaggio, coach.
- Carezze da tutto esaurito oggi. Con un pubblico così, un campione rende il doppio. Grazie, mister.

### Coccole — ignorato
- Il coach non s'è visto. Allenamento da solo davanti a spalti vuoti. I grandi lo fanno. Poi però lo scrivono nel diario, amareggiati.
- Zero attenzioni. Ho fatto squadra con me stesso: buon compagno, pessimo pubblico.
- Niente coccole in programma, a quanto pare. Il muscolo dell'affetto va allenato, coach. Vale anche per te.
- Spalti vuoti tutto il giorno. Ho esultato lo stesso, ma da solo l'esultanza dura meno.
- Zero tifo oggi. Il campione regge, ma rende meno: il pubblico è mezzo allenamento, coach.

### Chiusura
- Fine del report. Doccia, branda e sogni a tema podio. Domani si vince. Buonanotte!
- Ultima riga: grazie ai tifosi. Al tifoso. Tu, {utente}. Notte!
- Si spengono i riflettori. Il campione va in branda. Il campionato riprende alle prime luci.
- Chiudo e ricarico. Domani doppia sessione: vita e merenda. Notte, diario!
- Stop al cronometro. Tempo di oggi: buono. Domani si migliora. Si migliora SEMPRE. Notte.
