window.PETQ = window.PETQ || {};

(function () {

  // Aggiornamenti OTA self-hosted (plugin @capgo/capacitor-updater, gia' installato e
  // sincronizzato dal regista — v. android/, non toccata qui). Un manifest statico su GitHub
  // Pages dice qual e' l'ultima build web disponibile; se e' piu' nuova della build in
  // esecuzione, scarichiamo lo zip e lo mettiamo in coda con next() — si attiva SOLO al prossimo
  // riavvio/rientro in background, MAI subito (set() riavvierebbe l'app a meta' sessione).
  // Modalita' MANUALE del plugin (autoUpdate:false in capacitor.config.json, lo config il
  // regista): qui non c'e' nessun controllo automatico periodico, solo quello che main.js
  // richiama da boot()/recuperaTempoReale().
  //
  // Stesso contratto di notifiche.js/iap.js: plugin che PUO' mancare (browser, file://, o sync
  // non ancora fatto dal regista) -> ogni funzione qui e' un no-op silenzioso, MAI un throw
  // verso il chiamante. Lookup del plugin PIGRO (funzione, non var fissata al caricamento) come
  // in iap.js: window.Capacitor.Plugins puo' comparire DOPO il caricamento di questo file, e
  // _test() deve poter sostituire plugin/fetch a runtime nei collaudi in browser senza
  // ricaricare la pagina.
  var _pluginOverride = null;
  var _fetchOverride = null;
  // Guardia anti-doppio-download A TEMPO (verifica avversariale ago 2026): un booleano puro
  // restava bloccato per sempre se la promise nativa di download()/next() non si risolveva mai
  // (bridge appeso) — nessun ramo lo riabbassava e ogni OTA futuro restava inibito fino al
  // riavvio. Con un timestamp la guardia SCADE da sola dopo GUARDIA_DOWNLOAD_MS.
  var _downloadDaMs = 0; // 0 = nessun download in corso
  var GUARDIA_DOWNLOAD_MS = 5 * 60 * 1000;
  // Un controllo che non risponde MAI (fetch appesa, bridge muto) lascerebbe il chiamante senza
  // esito: ogni controlla() risponde al piu' tardi dopo questo timeout (v. rispondi in controlla).
  var RISPOSTA_TIMEOUT_MS = 20 * 1000;

  function plugin() {
    if (_pluginOverride) return _pluginOverride;
    return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater) || null;
  }

  function fetchDaUsare() {
    if (_fetchOverride) return _fetchOverride;
    return (typeof fetch === 'function') ? fetch : null;
  }

  var MANIFEST_URL = 'https://giubera.github.io/pet-prototype-demo/ota/latest.json';
  var CHIAVE_CHECK = 'petq_ota_ultimo_check';
  var CHIAVE_SCARICATA = 'petq_ota_scaricata';
  var CHIAVE_ESITO = 'petq_ota_ultimo_esito'; // ultimo esito NON-throttle, per la riga nel Profilo
  var THROTTLE_MS = 6 * 60 * 60 * 1000; // 6 ore

  // Helper localStorage con try/catch (stesso stile di save.js): non deve MAI lanciare, qui meno
  // che altrove visto che ogni funzione del modulo e' garantita no-throw.
  function leggi(chiave) {
    try { return localStorage.getItem(chiave); } catch (e) { return null; }
  }
  function scrivi(chiave, valore) {
    try { localStorage.setItem(chiave, valore); } catch (e) { /* silenzioso */ }
  }
  function rimuovi(chiave) {
    try { localStorage.removeItem(chiave); } catch (e) { /* silenzioso */ }
  }
  function leggiInt(chiave) {
    var raw = leggi(chiave);
    if (raw === null) return null;
    var n = parseInt(raw, 10);
    return isNaN(n) ? null : n;
  }

  // Build corrente da window.PETQ_BUILD (index.html, es. 'v279' -> 279). Si spoglia tutto cio'
  // che non e' cifra invece di limitarsi a togliere una 'v' iniziale: piu' robusto a eventuali
  // formati futuri (es. 'v279-beta') e comunque equivalente sul formato attuale. Mai bloccare per
  // un parse fallito: 0 e' sempre "piu' vecchio di qualunque manifest reale", quindi nel dubbio
  // il confronto in controlla() procede comunque verso un eventuale aggiornamento.
  function buildCorrente() {
    var n = parseInt(String(window.PETQ_BUILD).replace(/[^0-9]/g, ''), 10);
    return isNaN(n) ? 0 : n;
  }

  // notifyAppReady: DEVE essere chiamato il prima possibile, PRIMA di qualunque richiesta di
  // rete (dice la doc del plugin) — e' la nostra rete di sicurezza anti-rollback: un bundle OTA
  // che non lo chiama entro ~10s viene rollbackato automaticamente al bundle precedente. Percio'
  // sta QUI, nel corpo del modulo (eseguito al parse del file), e ota.js e' il PRIMO script di
  // index.html, prima perfino di content-bundle.js (il parse piu' pesante): cosi' su un telefono
  // lento il timeout non rischia mai di scattare per colpa del caricamento degli altri moduli.
  (function notificaSubito() {
    var p = plugin();
    if (!p) return;
    try {
      p.notifyAppReady().catch(function () { /* silenzioso, v. contratto no-op del modulo */ });
    } catch (e) {
      console.log('[ota] notifyAppReady fallita', e);
    }
  })();

  // Pulizia della chiave 'scaricata' all'avvio: se la build in esecuzione ha gia' raggiunto o
  // superato la versione che avevamo messo in coda, quella voce e' storia vecchia — o
  // l'aggiornamento e' stato applicato, o un AAB nativo piu' nuovo l'ha scavalcato
  // (resetWhenUpdate scarta i bundle OTA ma non sa nulla del nostro localStorage). Senza questa
  // pulizia il pannello debug mostrerebbe "in attesa: N" per sempre (verifica avversariale).
  (function puliziaScaricata() {
    var inAttesa = leggiInt(CHIAVE_SCARICATA);
    if (inAttesa !== null && inAttesa <= buildCorrente()) rimuovi(CHIAVE_SCARICATA);
  })();

  // Applica il manifest gia' scaricato e parsato: confronta la versione, decide se scaricare, e
  // chiama SEMPRE cb con un esito. Isolata da controlla() perche' e' la parte con piu' rami (e
  // l'unica avvolta in un try/catch dedicato, cosi' un errore imprevisto qui non lascia mai la
  // guardia _downloadInCorso bloccata a true).
  function applicaManifest(manifest, rispondi) {
    try {
      // Validazione STRETTA (verifica avversariale): versione INTERA >= 1 (un float come 137.5
      // supererebbe il typeof ma disallineerebbe per sempre la cache anti-riscarico, che rilegge
      // con parseInt) e url https non vuota — il manifest lo scriviamo noi con build-ota.ps1,
      // qualunque altra forma e' un errore di filiera e va respinta, non rincorsa.
      if (!manifest || typeof manifest.versione !== 'number' || manifest.versione % 1 !== 0 ||
          manifest.versione < 1 ||
          typeof manifest.url !== 'string' || manifest.url.indexOf('https://') !== 0) {
        console.log('[ota] manifest malformato', manifest);
        rispondi({ esito: 'errore', dettaglio: 'manifest malformato' });
        return;
      }

      if (manifest.versione <= buildCorrente()) {
        rispondi({ esito: 'aggiornato', dettaglio: manifest.versione });
        return;
      }

      if (leggiInt(CHIAVE_SCARICATA) === manifest.versione) {
        rispondi({ esito: 'scaricato', dettaglio: manifest.versione }); // gia' in coda, non riscaricare
        return;
      }

      if (_downloadDaMs && (Date.now() - _downloadDaMs) < GUARDIA_DOWNLOAD_MS) {
        rispondi({ esito: 'errore', dettaglio: 'download gia in corso' });
        return;
      }

      var p = plugin();
      if (!p) { rispondi({ esito: 'no-plugin' }); return; } // difensivo: non dovrebbe capitare qui

      _downloadDaMs = Date.now();
      p.download({ url: manifest.url, version: String(manifest.versione) }).then(function (info) {
        return p.next({ id: info.id }).then(function () {
          _downloadDaMs = 0;
          scrivi(CHIAVE_SCARICATA, String(manifest.versione));
          rispondi({ esito: 'scaricato', dettaglio: manifest.versione });
        });
      }).catch(function (err) {
        _downloadDaMs = 0;
        console.log('[ota] download/next fallito', err);
        rispondi({ esito: 'errore', dettaglio: err });
      });
    } catch (err) {
      _downloadDaMs = 0;
      console.log('[ota] elaborazione manifest fallita', err);
      rispondi({ esito: 'errore', dettaglio: err });
    }
  }

  // Controlla se c'e' un aggiornamento e lo scarica in coda (next()) se serve. Silenzioso per il
  // giocatore: nessuna UI qui, solo l'esito passato a cb (usato dal pannello debug per mostrare
  // lo stato). forza=true salta il throttle di 6h (bottone "Controlla ora" del debug); le
  // chiamate automatiche da main.js passano sempre forza=false.
  function controlla(forza, cb) {
    // rispondi = cb "exactly-once + no-throw" (verifica avversariale): (1) un'eccezione lanciata
    // dalla cb del CHIAMANTE non deve rientrare nei nostri try/catch e produrre una seconda o
    // terza chiamata a cb con un finto esito 'errore'; (2) una fetch o un bridge appesi per
    // sempre non devono lasciare il chiamante senza risposta — il timer sotto garantisce un
    // esito entro RISPOSTA_TIMEOUT_MS (il download nativo eventualmente in corso prosegue e va
    // a buon fine da solo: rispondi e' gia' consumata e la sua cb tardiva e' un no-op).
    var risposto = false;
    function rispondi(esito) {
      if (risposto) return;
      risposto = true;
      // Esito persistito per la riga OTA del Profilo (diagnosi sul telefono senza cavo, 24 ago
      // 2026): si registra ogni esito VERO — il throttle no, coprirebbe l'ultimo esito utile.
      if (esito && esito.esito && esito.esito !== 'throttle') {
        var det = '';
        if (esito.dettaglio !== undefined && esito.dettaglio !== null) {
          var grezzo = esito.dettaglio.message ? esito.dettaglio.message : esito.dettaglio;
          det = ' ' + String(grezzo).slice(0, 60);
        }
        scrivi(CHIAVE_ESITO, esito.esito + det);
      }
      if (!cb) return;
      try { cb(esito); } catch (e) { console.log('[ota] cb del chiamante ha lanciato', e); }
    }

    var p = plugin();
    if (!p) { rispondi({ esito: 'no-plugin' }); return; }

    var ultimoCheck = leggiInt(CHIAVE_CHECK);
    if (!forza && ultimoCheck !== null && (Date.now() - ultimoCheck) < THROTTLE_MS) {
      rispondi({ esito: 'throttle', dettaglio: ultimoCheck });
      return;
    }

    // Si registra il TENTATIVO di check (non solo il successo) prima ancora di partire con la
    // fetch: e' il throttle che deve limitare quanto spesso bussiamo al manifest, riuscita o no.
    scrivi(CHIAVE_CHECK, String(Date.now()));

    var f = fetchDaUsare();
    if (!f) {
      console.log('[ota] fetch non disponibile');
      rispondi({ esito: 'errore', dettaglio: 'fetch assente' });
      return;
    }

    setTimeout(function () { rispondi({ esito: 'errore', dettaglio: 'timeout' }); }, RISPOSTA_TIMEOUT_MS);

    try {
      f(MANIFEST_URL, { cache: 'reload' }).then(function (res) {
        // GitHub Pages su 404 risponde con una pagina HTML: res.json() rigetterebbe comunque,
        // ma lo status va controllato ESPLICITAMENTE — dietro un futuro proxy/CDN un body JSON
        // ben formato su uno status non-2xx verrebbe scambiato per un manifest legittimo.
        if (!res || !res.ok) { throw new Error('HTTP ' + (res ? res.status : 'nessuna risposta')); }
        return res.json();
      }).then(function (manifest) {
        applicaManifest(manifest, rispondi);
      }).catch(function (err) {
        console.log('[ota] controllo fallito', err);
        rispondi({ esito: 'errore', dettaglio: err });
      });
    } catch (err) {
      // fetch finto (o vero) che lancia SINCRONO invece di rigettare la promise: coperto qui,
      // il .catch() sopra copre solo il caso asincrono.
      console.log('[ota] controllo fallito', err);
      rispondi({ esito: 'errore', dettaglio: err });
    }
  }

  // Stato riassuntivo per il pannello debug (ui.js, sezione "OTA"): pura lettura, nessun
  // side-effect, mai un throw.
  function stato() {
    return {
      pluginPresente: !!plugin(),
      build: buildCorrente(),
      ultimoCheck: leggiInt(CHIAVE_CHECK),
      inAttesa: leggiInt(CHIAVE_SCARICATA),
      ultimoEsito: leggi(CHIAVE_ESITO)
    };
  }

  // Hook SOLO COLLAUDO (stesso ruolo di iap.js._test): sostituisce plugin e (se passata, v.
  // arguments.length come iap.js._test) la funzione fetch usata da controlla(). Azzera anche le
  // due chiavi localStorage e la guardia anti-doppio-download, cosi' ogni test riparte da uno
  // stato pulito. MAI da chiamare in codice di produzione.
  function _test(pluginFinto, fetchFinto) {
    _pluginOverride = pluginFinto || null;
    if (arguments.length >= 2) _fetchOverride = fetchFinto || null;
    _downloadDaMs = 0;
    try { localStorage.removeItem(CHIAVE_CHECK); } catch (e) { /* silenzioso */ }
    try { localStorage.removeItem(CHIAVE_SCARICATA); } catch (e) { /* silenzioso */ }
  }

  window.PETQ.ota = {
    controlla: controlla,
    stato: stato,
    _test: _test
  };

})();
