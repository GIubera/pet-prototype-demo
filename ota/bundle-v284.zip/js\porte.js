/* PETQ.porte — le QUATTRO PORTE (Batch B: Dilemmi + Lavori)
 *
 * Perimetro: docs/DESIGN-DILEMMI-LAVORI.md sezione "## 1. LE QUATTRO PORTE" (testi/destinazioni)
 * e "## 5. SPEC MOTORE" punto 10. I testi, i giorni e le destinazioni sono COPIATI dal doc: se
 * non tornano, ha ragione il doc.
 *
 * SOLO le porte sbloccano feature (regola del doc): questo modulo NON reimplementa le scelte che
 * esistono gia' altrove, le CHIAMA — PORTA 2 e PORTA 3 delegano a PETQ.lavoro.sceltaLavoretto /
 * sceltaCarriera (con le loro guardie di stadio/lavoretto-origine), e i 4 lavoretti/8 carriere si
 * leggono da PETQ.lavoro._lavoretti()/_carriere() cosi' i due elenchi non possono mai divergere.
 *
 * QUESTO MODULO NON DISEGNA NULLA: espone dati e funzioni pure (a parte le scritture di stato
 * dentro scegli()). La UI ci pensa il regista.
 */
(function () {
  'use strict';
  window.PETQ = window.PETQ || {};

  // Soglie in pet.giorniVita (il contatore dell'eta' del pet, v. pet.js/care.js): copiate dal doc
  // "giorno 2" / "giorno 4" / "giorno 9-10" — usiamo il numero cosi' com'e', senza inventare un
  // offset di visualizzazione (il campo che conta per il motore e' sempre giorniVita).
  var GIORNO_CORSO = 1;      // PORTA 1, baby (giorno 1 su decisione del fondatore: col 2 la
                             // finestra durava un giorno solo, perche' il baby evolve al 3)
  var GIORNO_LAVORETTO = 4;  // PORTA 2, teen
  var GIORNO_SVOLTA = 9;     // PORTA 4, adulto (finestra doc "giorno 9-10": la porta si apre dal 9)

  // ---------- PORTA 1 — "Il Corso Pomeridiano" (baby, giorno 2) ----------
  // Niente spoiler (regola sacra del progetto): l'etichetta e' SOLO il nome del corso, mai cosa
  // sblocca. Il perk vero e' definito nel doc (RETENTION §B3) e vive in state.perks come tutti gli
  // altri badge (v. missions.js applicaRewardToken, token perk:<nome>, array lowercase dedup) —
  // qui replichiamo lo stesso id di perk a mano perche' non arriva da una scheda missione.
  var CORSI = {
    disegno: { etichetta: 'Corso di Disegno', perk: 'corso_disegno' },
    musica: { etichetta: 'Corso di Musica', perk: 'corso_musica' },
    cucina: { etichetta: 'Corso di Cucina', perk: 'corso_cucina' }
  };

  // ---------- PORTA 4 — "La Svolta" (adulto, giorno 9-10) ----------
  // Volantini per personalita', dal doc §1 tabella PORTA 4. Le chiavi 'a'/'b' portano il testo del
  // volantino (che ALLUDE, non nomina mai la leggenda) e l'id della Grande Impresa che sbloccano
  // (m65..m72, le stesse schede impresa=1 che PETQ.missions.impresaDellaRun sa gia' validare per
  // personalita'). La C e' sempre la stessa battuta per tutte le personalita' (il doc segna "idem"
  // sulle righe Gentile/Maleducato/Nerd) e non punta a nessuna missione: lascia la roulette.
  var VOLANTINI = {
    sportivo: {
      a: { testo: 'SEI DEGNO? Palestra sul Monte Mascellone, solo veri guerrieri', missione: 'm65' },
      b: { testo: "Arena del Porto: cercasi sfidante per l'addio del Campione", missione: 'm66' }
    },
    gentile: {
      a: { testo: 'Il grattacielo ha di nuovo gli incubi. Cercasi anima buona, portare torta', missione: 'm67' },
      b: { testo: 'LA GRANDE CORSA attraversa la città. Si parte all\'alba, si arriva chissà', missione: 'm68' }
    },
    maleducato: {
      a: { testo: 'Cercasi fotografo SENZA SCRUPOLI per la notte dei vip. Pagamento in fama', missione: 'm69' },
      b: { testo: "SFIDA APERTA NEL CRATERE: 'VERMI, FATEVI SOTTO'. Firmato: il Principe", missione: 'm70' }
    },
    nerd: {
      a: { testo: "Seminario: l'ultimo passaggio del Teorema di Tutto. Silenzio obbligatorio", missione: 'm71' },
      b: { testo: "Garage pieno di rottami 'tecnologici' cerca socio. Astenersi sani di mente", missione: 'm72' }
    }
  };
  var TESTO_VOLANTINO_C = 'Butti entrambi: decida il destino';

  // Elenco delle porte valide (usato per rifiutare id sconosciuti in modo silenzioso, mai un throw).
  var PORTE_VALIDE = { corso: 1, lavoretto: 1, carriera: 1, svolta: 1 };

  function traduci(s) {
    return (window.PETQ.i18n && PETQ.i18n.t) ? PETQ.i18n.t(s) : s;
  }

  // Struttura difensiva, stesso schema di streak.js/lavoro.js: qualunque salvataggio (vecchio,
  // manomesso, di un'altra versione) esce di qui con state.porte.fatte SEMPRE un oggetto sano.
  function assicura(state) {
    if (!state) return null;
    var p = state.porte;
    if (!p || typeof p !== 'object') p = {};
    if (!p.fatte || typeof p.fatte !== 'object') p.fatte = {};
    state.porte = p;
    return p;
  }

  // I 4 lavoretti letti DAL MODULO VERO (mai ricopiati a mano): se domani PETQ.lavoro cambia un
  // nome o ne aggiunge uno, la Porta 2 lo eredita senza bisogno di toccare questo file.
  function lavorettiDisponibili() {
    if (!window.PETQ.lavoro || typeof PETQ.lavoro._lavoretti !== 'function') {
      console.warn('PETQ.porte: PETQ.lavoro non disponibile, Porta 2 senza opzioni');
      return {};
    }
    return PETQ.lavoro._lavoretti() || {};
  }

  function carriereDisponibili() {
    if (!window.PETQ.lavoro || typeof PETQ.lavoro._carriere !== 'function') {
      console.warn('PETQ.porte: PETQ.lavoro non disponibile, Porta 3 senza opzioni');
      return {};
    }
    return PETQ.lavoro._carriere() || {};
  }

  /* porteDaMostrare: la porta PENDENTE adesso, o null.
   *
   * Una porta si mostra UNA volta sola (se e' gia' in state.porte.fatte non si ripropone), solo
   * allo stadio giusto e solo dal giorno del doc in poi (pet.giorniVita, il campo dell'eta' — non
   * ne inventiamo un altro). Gli stadi sono mutuamente esclusivi quindi l'ordine dei controlli qui
   * sotto non crea ambiguita': un pet e' baby O teen O adulto, mai due insieme.
   *
   * PORTA 3 "Carriera": nasce ALL'EVOLUZIONE ad adulto (nessuna soglia di giorni propria, lo
   * stadio stesso e' il gate) e prima usciva SOLO dalla scenetta di evoluzione (ui.js, bottone
   * "Continua" -> opzioniPorta/scegli('carriera', ...) chiamati direttamente). FIX (bug segnalato
   * dal fondatore, "la carriera si puo' perdere per sempre"): quel trigger e' un'occasione UNICA —
   * se sfugge (app chiusa/in background proprio in quel momento, ricarica durante il flash
   * dell'evoluzione, salto da debug che forza lo stadio) le opzioni restavano valide e pronte ma
   * IRRAGGIUNGIBILI per il resto della run. Ora e' pendente anche da qui, come le altre tre: se
   * non e' ancora stata fatta E ha almeno un'opzione (opzioniPorta torna [] se il lavoretto di
   * Porta 2 non e' mai stato scelto — in tal caso si scende al controllo della Svolta, MAI una
   * porta senza uscita). PRECEDENZA sulla Svolta: la Carriera e' pronta dal giorno
   * dell'evoluzione (8), la Svolta si apre solo dal giorno GIORNO_SVOLTA (9), quindi il controllo
   * carriera va PRIMA. Il rischio di doppia proposta (mostrarla sia dalla scenetta sia da questo
   * elenco, o mostrarla sopra l'annuncio "sei diventato ADULTO" ancora a video) e' risolto lato
   * UI, che qui — modulo che non tocca il DOM — non puo' e non deve gestire: ui.js marca la porta
   * a schermo con l'id 'petq-porta' (controllaPortaPendente non rimonta se c'e' gia') e non
   * innesca questo elenco mentre l'annuncio di evoluzione e' ancora aperto (id
   * 'petq-schermo-evoluzione', v. controllaEvoluzioneScaduta/controllaPortaPendente in ui.js).
   */
  function porteDaMostrare(state) {
    var p = assicura(state);
    if (!p || !state.pet) return null;
    var pet = state.pet;
    var giorni = (typeof pet.giorniVita === 'number') ? pet.giorniVita : 0;

    if (pet.stadio === 'baby' && giorni >= GIORNO_CORSO && !p.fatte.corso) return 'corso';
    if (pet.stadio === 'teen' && giorni >= GIORNO_LAVORETTO && !p.fatte.lavoretto) return 'lavoretto';
    if (pet.stadio === 'adulto') {
      if (!p.fatte.carriera) {
        var opzCarriera = opzioniPorta(state, 'carriera');
        if (opzCarriera && opzCarriera.length > 0) return 'carriera';
      }
      if (giorni >= GIORNO_SVOLTA && !p.fatte.svolta) return 'svolta';
    }
    return null;
  }

  /* opzioniPorta: le opzioni da mostrare per una porta, gia' filtrate/personalizzate.
   * Ogni opzione: { id, etichetta, descrizione? }. Mai un throw: id sconosciuto o precondizione
   * mancante (es. carriera senza lavoretto) tornano [] con un console.warn. */
  function opzioniPorta(state, idPorta) {
    if (!state || !PORTE_VALIDE[idPorta]) return [];

    if (idPorta === 'corso') {
      var out = [];
      for (var k in CORSI) {
        if (!Object.prototype.hasOwnProperty.call(CORSI, k)) continue;
        out.push({ id: k, etichetta: traduci(CORSI[k].etichetta) });
      }
      return out;
    }

    if (idPorta === 'lavoretto') {
      var lav = lavorettiDisponibili();
      var outL = [];
      for (var idL in lav) {
        if (!Object.prototype.hasOwnProperty.call(lav, idL)) continue;
        outL.push({ id: idL, etichetta: traduci(lav[idL].nome) });
      }
      return outL;
    }

    if (idPorta === 'carriera') {
      // Le 2 carriere possibili dipendono dal lavoretto scelto in Porta 2 (doc §2, colonna "Da"):
      // filtriamo PETQ.lavoro._carriere() per quel campo, non ne scriviamo una copia qui.
      var lId = (window.PETQ.lavoro && typeof PETQ.lavoro.assicura === 'function')
        ? (PETQ.lavoro.assicura(state) || {}).id
        : (state.lavoro && state.lavoro.id) || null;
      if (!lId) {
        console.warn('PETQ.porte: nessun lavoretto scelto, Porta 3 senza opzioni');
        return [];
      }
      var carr = carriereDisponibili();
      var outC = [];
      for (var idC in carr) {
        if (!Object.prototype.hasOwnProperty.call(carr, idC)) continue;
        if (carr[idC].da !== lId) continue;
        outC.push({ id: idC, etichetta: traduci(carr[idC].nome) });
      }
      return outC;
    }

    if (idPorta === 'svolta') {
      var pers = state.pet && state.pet.personalita;
      var vol = VOLANTINI[pers];
      if (!vol) {
        // Personalita' mancante/sconosciuta (salvataggio corrotto): meglio offrire solo la
        // roulette che bloccare la porta o inventare un volantino a caso.
        console.warn('PETQ.porte: personalita "' + pers + '" senza volantini, solo roulette');
        return [{ id: 'c', etichetta: traduci(TESTO_VOLANTINO_C) }];
      }
      return [
        { id: 'a', etichetta: traduci(vol.a.testo) },
        { id: 'b', etichetta: traduci(vol.b.testo) },
        { id: 'c', etichetta: traduci(TESTO_VOLANTINO_C) }
      ];
    }

    return [];
  }

  /* scegli: applica la scelta e registra la porta come fatta. Ritorna { ok, msg, effetti }.
   * Una porta gia' segnata in state.porte.fatte non si puo' rifare (ognuna e' "per tutta la run",
   * doc §1): rifarla applicherebbe il premio/effetto una seconda volta. */
  function scegli(state, idPorta, idOpzione) {
    var p = assicura(state);
    if (!p || !state.pet) return { ok: false, msg: 'nessun pet', effetti: null };
    if (!PORTE_VALIDE[idPorta]) return { ok: false, msg: 'porta sconosciuta', effetti: null };
    if (p.fatte[idPorta]) return { ok: false, msg: 'questa porta e\' gia\' stata scelta', effetti: null };

    var pet = state.pet;

    if (idPorta === 'corso') {
      if (pet.stadio !== 'baby') return { ok: false, msg: 'il corso si prende da baby', effetti: null };
      var corso = CORSI[idOpzione];
      if (!corso) return { ok: false, msg: 'corso sconosciuto', effetti: null };
      // Stesso schema di missions.js applicaRewardToken per perk:<nome>: array in state.perks,
      // lowercase, dedup — cosi' il resto del gioco (badges, richiedePerk=) non vede differenza
      // tra un perk arrivato da missione e uno arrivato da porta.
      if (!Array.isArray(state.perks)) state.perks = [];
      if (state.perks.indexOf(corso.perk) === -1) state.perks.push(corso.perk);
      p.fatte.corso = idOpzione;
      return { ok: true, msg: corso.etichetta, effetti: { tipo: 'perk', perk: corso.perk } };
    }

    if (idPorta === 'lavoretto') {
      if (!window.PETQ.lavoro || typeof PETQ.lavoro.sceltaLavoretto !== 'function') {
        return { ok: false, msg: 'modulo lavoro assente', effetti: null };
      }
      var rl = PETQ.lavoro.sceltaLavoretto(state, idOpzione);
      if (rl.ok) p.fatte.lavoretto = idOpzione;
      return { ok: rl.ok, msg: rl.msg, effetti: rl.ok ? { tipo: 'lavoretto', id: idOpzione } : null };
    }

    if (idPorta === 'carriera') {
      if (!window.PETQ.lavoro || typeof PETQ.lavoro.sceltaCarriera !== 'function') {
        return { ok: false, msg: 'modulo lavoro assente', effetti: null };
      }
      var rc = PETQ.lavoro.sceltaCarriera(state, idOpzione);
      if (rc.ok) p.fatte.carriera = idOpzione;
      return { ok: rc.ok, msg: rc.msg, effetti: rc.ok ? { tipo: 'carriera', id: idOpzione } : null };
    }

    if (idPorta === 'svolta') {
      if (pet.stadio !== 'adulto') return { ok: false, msg: 'la svolta si prende da adulto', effetti: null };

      if (idOpzione === 'c') {
        // Roulette (doc: "NON impostare nulla e lascia il comportamento attuale"): state.impresaRun
        // resta quello che era (di norma non ancora settato) e sara' PETQ.missions.impresaDellaRun
        // a estrarlo a caso fra le imprese della personalita', come faceva PRIMA di questa porta.
        p.fatte.svolta = idOpzione;
        return { ok: true, msg: TESTO_VOLANTINO_C, effetti: { tipo: 'svolta', scelta: 'roulette' } };
      }

      var pers = pet.personalita;
      var vol = VOLANTINI[pers];
      if (!vol || !vol[idOpzione]) return { ok: false, msg: 'opzione svolta sconosciuta', effetti: null };

      // Aggancio all'Impresa della run: lo stesso meccanismo che gia' esiste in missions.js
      // (impresaDellaRun) legge state.impresaRun se e' GIA' presente e valido per la personalita'
      // del pet, e in tal caso lo usa SENZA ri-estrarre a caso — scriverlo qui e' quindi
      // sufficiente per "decidere" quale Grande Impresa uscira', senza inventare un secondo
      // meccanismo di selezione. Gli id (m65..m72) sono le schede impresa=1 vere del content.
      state.impresaRun = vol[idOpzione].missione;
      p.fatte.svolta = idOpzione;
      return {
        ok: true,
        msg: vol[idOpzione].testo,
        effetti: { tipo: 'svolta', scelta: idOpzione, impresa: state.impresaRun }
      };
    }

    return { ok: false, msg: 'porta sconosciuta', effetti: null };
  }

  window.PETQ.porte = {
    assicura: assicura,
    porteDaMostrare: porteDaMostrare,
    opzioniPorta: opzioniPorta,
    scegli: scegli,
    _porte: function () {
      return {
        corsi: CORSI,
        volantini: VOLANTINI,
        testoVolantinoC: TESTO_VOLANTINO_C,
        giorni: { corso: GIORNO_CORSO, lavoretto: GIORNO_LAVORETTO, svolta: GIORNO_SVOLTA }
      };
    }
  };
})();
