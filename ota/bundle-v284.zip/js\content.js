window.PETQ = window.PETQ || {};

(function () {

  var PERSONALITA_FILES = ['gentile', 'maleducato', 'nerd', 'sportivo'];

  // Mappa id leggenda (v. pet.js LEGGENDE_INFO, m65..m72) -> slug file content/leggende/<slug>.md.
  // Solo 4 file esistono oggi (giga-ciad/rocco-baldoria/padre-maronno/veggeta): gli altri 4 li
  // scrivera' il socio piu' avanti. Il loader (load/caricaTutti sotto) DEVE tollerare gli slug
  // ancora senza file: nessuna eccezione, il pool per quell'id resta semplicemente assente da
  // data.leggende e dialog.js fa fallback sulla personalita' generica (v. dialog.js say()).
  var LEGGENDE_SLUG = {
    m65: 'giga-ciad',
    m66: 'rocco-baldoria',
    m67: 'padre-maronno',
    m68: 'forrest-gampo',
    m69: 'fabrice-the-crown',
    m70: 'veggeta',
    m71: 'sceldon',
    m72: 'tonino-stark'
  };
  var LEGGENDE_IDS = ['m65', 'm66', 'm67', 'm68', 'm69', 'm70', 'm71', 'm72'];

  var SEZIONE_MAP = [
    { match: 'notifica valigia', chiave: 'notifica_valigia' },
    // Notifiche push dedicate (16 lug 2026, sezioni-template in scrittura al socio): DEVONO
    // stare PRIMA del match generico 'notifica' (substring, primo vince).
    { match: 'notifica missione', chiave: 'notifica_missione' },
    { match: 'notifica allenamento', chiave: 'notifica_allenamento' },
    // Retention 2.0 / Batch A1: due pool nuovi. Anche questi PRIMA del match generico 'notifica',
    // che essendo una sottostringa se li mangerebbe entrambi (primo che matcha vince).
    { match: 'notifica carica a rischio', chiave: 'notifica_streak' },
    { match: 'notifica silenzio lungo', chiave: 'notifica_silenzio' },
    // Retention 2.0 / A3 (quarta parete): il pet parla IN GIOCO e nota il mondo-telefono.
    { match: 'reazione assenza lunga', chiave: 'reazione_assenza' },
    { match: 'reazione ora assurda', chiave: 'reazione_oraassurda' },
    { match: 'reazione batteria scarica', chiave: 'reazione_batteria' },
    { match: 'reazione tema scuro', chiave: 'reazione_temascuro' },
    { match: 'valigia', chiave: 'valigia' },
    { match: 'rientro', chiave: 'rientro' },
    { match: 'lettera', chiave: 'lettera' },
    { match: 'addio', chiave: 'addio' },
    { match: 'evoluzione', chiave: 'evoluzione' },
    { match: 'saluto', chiave: 'saluto' },
    { match: 'ha fame', chiave: 'fame' },
    { match: 'sporco', chiave: 'sporco' },
    { match: 'felice', chiave: 'felice' },
    { match: 'coccole finite', chiave: 'coccole_finite' },
    { match: 'trascurato', chiave: 'triste' },
    { match: 'parte per la missione', chiave: 'missione_partenza' },
    { match: 'ritorno: successo', chiave: 'missione_successo' },
    { match: 'ritorno: fallimento', chiave: 'missione_fallimento' },
    { match: 'notifica', chiave: 'notifica' },
    { match: 'parola imparata', chiave: 'parola' },
    { match: 'ha sonno', chiave: 'sonno' },
    { match: 'va a dormire', chiave: 'dormire' },
    { match: 'sveglia', chiave: 'sveglia' },
    { match: 'dormito male', chiave: 'dormito_male' },
    // Gioca + Passeggiata serale (battute del socio, agganciate 9 lug 2026). ATTENZIONE ordine
    // (match per sottostringa, primo vince): 'gioca col giocattolo' DEVE precedere 'gioca',
    // altrimenti il giocattolo finirebbe nel pool 'gioca'. Le 5 passeggiata_* non collidono.
    { match: 'gioca col giocattolo', chiave: 'gioca_giocattolo' },
    { match: 'gioca', chiave: 'gioca' },
    { match: 'passeggiata partenza', chiave: 'passeggiata_partenza' },
    { match: 'passeggiata monete', chiave: 'passeggiata_monete' },
    { match: 'passeggiata incontro', chiave: 'passeggiata_incontro' },
    { match: 'passeggiata pozzanghera', chiave: 'passeggiata_pozzanghera' },
    { match: 'passeggiata panorama', chiave: 'passeggiata_panorama' },
    // Esiti passeggiata aggiuntivi (9 lug 2026): nessuna collisione (seconda parola distinta).
    { match: 'passeggiata rottame', chiave: 'passeggiata_rottame' },
    { match: 'passeggiata piccione', chiave: 'passeggiata_piccione' },
    { match: 'passeggiata assaggio', chiave: 'passeggiata_assaggio' },
    { match: 'passeggiata acquazzone', chiave: 'passeggiata_acquazzone' },
    { match: 'passeggiata persi', chiave: 'passeggiata_persi' },
    { match: 'passeggiata cielo', chiave: 'passeggiata_cielo' },
    { match: 'passeggiata bulletto', chiave: 'passeggiata_bulletto' }
  ];

  var SEZIONE_CHIAVI = ['saluto', 'fame', 'sporco', 'felice', 'coccole_finite', 'triste',
    'missione_partenza', 'missione_successo', 'missione_fallimento', 'notifica', 'parola',
    'valigia', 'notifica_valigia', 'notifica_missione', 'notifica_allenamento',
    'notifica_streak', 'notifica_silenzio', // Retention 2.0 / A1
    'reazione_assenza', 'reazione_oraassurda', 'reazione_batteria', 'reazione_temascuro', // A3
    'rientro', 'lettera', 'addio', 'evoluzione',
    'sonno', 'dormire', 'sveglia', 'dormito_male',
    'gioca', 'gioca_giocattolo', 'passeggiata_partenza', 'passeggiata_monete',
    'passeggiata_incontro', 'passeggiata_pozzanghera', 'passeggiata_panorama',
    'passeggiata_rottame', 'passeggiata_piccione', 'passeggiata_assaggio',
    'passeggiata_acquazzone', 'passeggiata_persi', 'passeggiata_cielo', 'passeggiata_bulletto'];

  var DEFAULT_BILANCIAMENTO = {
    decadimento: { fame: 6, igiene: 8, felicita: 2 },
    soglie: { critica: 25, magro: 30, sporco: 30, malusSalute: 40, sovralimentazione: 90 },
    economia: { login: 10, monetePartenza: 50 },
    allenamento: { sessioni: 1, effetto: 2, felicita: 5 },
    iniziali: { benessere: 70, budget: 3, firma: 1 },
    // Tetto stat RPG per stadio (bilanciamento.md "Tetto delle statistiche per stadio"): rete di
    // sicurezza SOLO, i valori veri arrivano dal parser sotto (parseBilanciamento). Stessi numeri
    // del ripiego fisso in pet.js (TETTO_STAT_DEFAULT) — se li cambi tienili allineati.
    tettoStat: { baby: 12, teen: 30, adulto: 70 },
    energia_sonno: {
      decadimento: 2,
      costoMissionePerOra: 8,
      costoAllenamento: 10,
      sogliaRifiuto: 20,
      oraLetto: 21,
      oraCrollo: 23,
      riposinoDurataMax: 2,
      riposinoDurataMin: 1,
      riposinoRecuperoOra: 15,
      sveglioAutonomoOre: 8,
      sonnoMinimoOre: 5,
      risveglioBuono: 100,
      risveglioCattivo: 70
    }
  };

  function vuotaPersonalita() {
    var p = {};
    for (var i = 0; i < SEZIONE_CHIAVI.length; i++) p[SEZIONE_CHIAVI[i]] = [];
    return p;
  }

  window.PETQ.content = {
    data: {
      personalita: {},
      cibi: [],
      arredi: [],
      // Sezioni dedicate di content/arredi.md (stesso file, tabelle diverse dagli arredi):
      // indossabili = vestiti equipaggiati SUL pet (+ i MEME), armi = slot arma a parte,
      // giocattoli = voci del menu "Usa un giocattolo".
      indossabili: [],
      armi: [],
      giocattoli: [],
      bilanciamento: null,
      missioni: [],
      // Carte dilemma (Batch B): il mazzo giornaliero, da content/carte.md.
      carte: [],
      diario: {},
      talenti: {},
      poolInventore: [],
      battuteTalenti: {},
      leggende: {}
    },
    load: load,
    _parseBilanciamento: parseBilanciamento, // esposto per test di parsing (pattern _get*/_assert* del codebase)
    _parseCibi: parseCibi,
    _estraiEffettiCibo: estraiEffettiCibo,
    _parseArredi: parseArredi,
    _estraiBonusArredo: estraiBonusArredo,
    _parseIndossabili: parseIndossabili,
    _parseArmi: parseArmi,
    _parseGiocattoli: parseGiocattoli,
    _parseDiario: parseDiario,
    _parseMissioni: parseMissioni,
    _parseTalenti: parseTalenti,
    _parsePoolInventore: parsePoolInventore,
    _parseBattuteTalenti: parseBattuteTalenti
  };

  function load(callback) {
    var percorsi = [];
    for (var i = 0; i < PERSONALITA_FILES.length; i++) {
      percorsi.push('personalita/' + PERSONALITA_FILES[i]);
    }
    percorsi.push('cibi');
    percorsi.push('arredi');
    percorsi.push('bilanciamento');
    percorsi.push('missioni');
    // Carte dilemma (Batch B). SECONDO elenco da aggiornare, oltre a quello di build-content.ps1:
    // il bundle puo' contenere il file, ma se il nome non e' qui il caricatore non lo CHIEDE e
    // data.carte resta vuoto senza un solo errore — il mazzo non esiste e non si capisce perche'.
    percorsi.push('carte');
    percorsi.push('diario');
    percorsi.push('talenti');
    percorsi.push('battute-talenti');
    for (var iLeg = 0; iLeg < LEGGENDE_IDS.length; iLeg++) {
      percorsi.push('leggende/' + LEGGENDE_SLUG[LEGGENDE_IDS[iLeg]]);
    }

    caricaTutti(percorsi, function (raw) {
      var data = window.PETQ.content.data;

      data.personalita = {};
      for (var i = 0; i < PERSONALITA_FILES.length; i++) {
        var nomeFile = PERSONALITA_FILES[i];
        var testo = raw['personalita/' + nomeFile] || '';
        data.personalita[nomeFile] = parsePersonalita(testo);
      }

      data.cibi = parseCibi(raw['cibi'] || '');
      // arredi.md contiene QUATTRO cataloghi distinti (arredi, indossabili, armi, giocattoli):
      // stesso testo grezzo, quattro parser che leggono solo le sezioni di loro competenza.
      var rawArredi = raw['arredi'] || '';
      data.arredi = parseArredi(rawArredi);
      data.indossabili = parseIndossabili(rawArredi);
      data.armi = parseArmi(rawArredi);
      data.giocattoli = parseGiocattoli(rawArredi);
      data.missioni = parseMissioni(raw['missioni'] || '');
      data.carte = parseCarte(raw['carte'] || '');
      data.diario = parseDiario(raw['diario'] || '');
      data.talenti = parseTalenti(raw['talenti'] || '');
      data.poolInventore = parsePoolInventore(raw['talenti'] || '');
      data.battuteTalenti = parseBattuteTalenti(raw['battute-talenti'] || '');

      // Battute LEGGENDA (P3): riusa parsePersonalita (stesso formato a 9 sezioni dei file
      // personalita/*.md). File orfani/non ancora scritti dal socio -> raw[percorso] e' '' (sia
      // da bundle file:// che da fetch 404/errore, v. caricaTutti): si salta con grazia, niente
      // eccezione, e data.leggende[id] resta semplicemente assente (dialog.js say() fa fallback
      // sulla personalita' generica quando manca).
      data.leggende = {};
      for (var jLeg = 0; jLeg < LEGGENDE_IDS.length; jLeg++) {
        var idLeg = LEGGENDE_IDS[jLeg];
        var testoLeg = raw['leggende/' + LEGGENDE_SLUG[idLeg]];
        if (!testoLeg) continue; // file mancante/non nel bundle/fetch fallita: salta
        try {
          data.leggende[idLeg] = parsePersonalita(testoLeg);
        } catch (e) {
          console.warn('PETQ.content: errore parsing battute leggenda "' + idLeg + '", pool assente (fallback personalita)', e);
        }
      }

      var bilOk = null;
      try {
        bilOk = parseBilanciamento(raw['bilanciamento'] || '');
      } catch (e) {
        bilOk = null;
      }
      if (bilOk) {
        data.bilanciamento = bilOk;
      } else {
        console.warn('PETQ.content: parse bilanciamento fallito, uso i default');
        data.bilanciamento = clona(DEFAULT_BILANCIAMENTO);
      }

      if (typeof callback === 'function') callback();
    });
  }

  // ---------- lingua corrente (i18n bilingue, contratto localStorage 'petq_lingua') ----------
  // content.js NON dipende dall'ordine di init del save (PETQ.save potrebbe non essere ancora
  // pronto quando content.load parte): legge localStorage DIRETTAMENTE qui, con una funzione
  // locale dedicata. localStorage puo' lanciare (modalita' privata, quota, ambienti senza
  // storage, file:// in alcuni browser): try/catch, fallback finale 'it'. Default quando la
  // chiave e' assente/non valida: 'it' se la lingua del browser (navigator.language) inizia
  // con 'it', altrimenti 'en' (lancio internazionale = default inglese, italiani riconosciuti
  // dal browser restano in italiano). Il cambio lingua e' scritto da un altro modulo (UI toggle)
  // via localStorage + location.reload(): niente hot-swap, la lingua e' fissa per tutto il load.
  function linguaCorrente() {
    try {
      var v = localStorage.getItem('petq_lingua');
      if (v === 'it' || v === 'en') return v;
    } catch (e) { /* localStorage non disponibile: si passa al default sotto */ }
    try {
      var nav = (navigator.language || '').toLowerCase();
      return (nav.indexOf('it') === 0) ? 'it' : 'en';
    } catch (e) {
      return 'it';
    }
  }

  // ---------- dual loader ----------

  // Se linguaCorrente()==='en', per ogni percorso p prova PRIMA la variante inglese ('en/'+p:
  // chiave 'en/'+p nel bundle file://, fetch '../content/en/'+p+'.md' su http/https); se il
  // contenuto inglese e' assente/vuoto (file non ancora scritto dal socio) o il fetch fallisce,
  // usa in silenzio il contenuto italiano di p (fallback PER-FILE, non per-tutto-il-caricamento:
  // un file en/ mancante non deve far cadere in italiano anche i file en/ gia' presenti).
  // Quando la lingua e' 'it' il comportamento e' IDENTICO a prima (nessuna richiesta extra).
  // out e' sempre keyed sui percorsi ORIGINALI (mai col prefisso 'en/'): il chiamante (load())
  // non deve sapere nulla della lingua.
  function caricaTutti(percorsi, doneCb) {
    var vuoiEn = (linguaCorrente() === 'en');

    if (location.protocol === 'file:') {
      var raw = window.CONTENT_RAW || {};
      var out = {};
      for (var i = 0; i < percorsi.length; i++) {
        var p = percorsi[i];
        var testoIt = raw[p] || '';
        out[p] = vuoiEn ? (raw['en/' + p] || testoIt) : testoIt;
      }
      doneCb(out);
      return;
    }

    // percorsi da recuperare via fetch: sempre gli italiani (servono comunque per il fallback),
    // piu' gli inglesi in coda se vuoiEn.
    var percorsiDaCaricare = percorsi.slice();
    if (vuoiEn) {
      for (var iEn = 0; iEn < percorsi.length; iEn++) {
        percorsiDaCaricare.push('en/' + percorsi[iEn]);
      }
    }

    var risultatiGrezzi = {};
    var rimanenti = percorsiDaCaricare.length;
    if (rimanenti === 0) { doneCb({}); return; }

    percorsiDaCaricare.forEach(function (chiave) {
      fetch('../content/' + chiave + '.md')
        .then(function (res) { return res.ok ? res.text() : ''; })
        .catch(function () { return ''; })
        .then(function (testo) {
          risultatiGrezzi[chiave] = testo;
          rimanenti--;
          if (rimanenti === 0) finalizza();
        });
    });

    function finalizza() {
      var out = {};
      for (var i = 0; i < percorsi.length; i++) {
        var p = percorsi[i];
        var testoIt = risultatiGrezzi[p] || '';
        out[p] = vuoiEn ? (risultatiGrezzi['en/' + p] || testoIt) : testoIt;
      }
      doneCb(out);
    }
  }

  // ---------- parser battute (personalita) ----------

  function parsePersonalita(testo) {
    var out = vuotaPersonalita();
    if (!testo) return out;

    var righe = testo.split(/\r?\n/);
    var chiaveCorrente = null;

    for (var i = 0; i < righe.length; i++) {
      var riga = righe[i].trim();
      if (riga === '') continue;

      if (riga.indexOf('## ') === 0) {
        var titolo = riga.substring(3).trim();
        chiaveCorrente = mappaSezione(titolo);
        continue;
      }

      if (riga.indexOf('- ') === 0 && chiaveCorrente) {
        var battuta = riga.substring(2).trim();
        battuta = battuta.replace(/^\[ESEMPIO\]\s*/i, '');
        if (battuta !== '') {
          out[chiaveCorrente].push(battuta);
        }
      }
    }

    return out;
  }

  function mappaSezione(titolo) {
    var t = titolo.toLowerCase();
    for (var i = 0; i < SEZIONE_MAP.length; i++) {
      if (t.indexOf(SEZIONE_MAP[i].match) !== -1) {
        return SEZIONE_MAP[i].chiave;
      }
    }
    return null;
  }

  // ---------- parser diario (PROTOTIPO-2.md punto 6, content/diario.md) ----------
  // Struttura: sezioni "## <Personalita>" (gentile/maleducato/nerd/sportivo, stesse chiavi di
  // PERSONALITA_FILES) con sottosezioni "### <Titolo momento>" -> lista "- frammento".
  // Match tollerante per SUBSTRING su titolo normalizzato (minuscolo, senza accenti/em-dash):
  // "Cibo — mangiato bene" contiene sia 'cibo' che 'bene', "Umore — giù" contiene 'umore' e
  // 'giu' una volta normalizzati gli accenti. L'ordine delle regole conta: le voci piu'
  // specifiche (con sotto-stato) vanno PRIMA delle generiche altrimenti "Missione andata bene"
  // matcherebbe solo la prima regola che contiene 'missione'.
  var DIARIO_CHIAVI = ['apertura', 'cibo_bene', 'cibo_poco', 'missione_bene', 'missione_male',
    'missione_nessuna', 'umore_bene', 'umore_stanco', 'umore_giu', 'coccole_ricevute',
    'coccole_ignorato', 'chiusura'];

  var DIARIO_SEZIONE_MAP = [
    { match: ['apertura'], chiave: 'apertura' },
    { match: ['cibo', 'bene'], chiave: 'cibo_bene' },
    { match: ['cibo', 'poco'], chiave: 'cibo_poco' },
    { match: ['nessuna missione'], chiave: 'missione_nessuna' },
    { match: ['missione', 'bene'], chiave: 'missione_bene' },
    { match: ['missione', 'male'], chiave: 'missione_male' },
    { match: ['umore', 'bene'], chiave: 'umore_bene' },
    { match: ['umore', 'stanc'], chiave: 'umore_stanco' },
    { match: ['umore', 'giu'], chiave: 'umore_giu' },
    { match: ['coccol', 'ricevut'], chiave: 'coccole_ricevute' },
    { match: ['coccol', 'ignorat'], chiave: 'coccole_ignorato' },
    { match: ['chiusura'], chiave: 'chiusura' }
  ];

  // normalizza minuscolo + toglie accenti (così "giù"/"perdute" matchano 'giu'/ecc.) e i
  // trattini/em-dash del titolo ("Cibo — mangiato bene" -> "cibo mangiato bene")
  function normalizzaTitolo(t) {
    return (t || '').toLowerCase()
      .replace(/[àá]/g, 'a').replace(/[èé]/g, 'e').replace(/[ìí]/g, 'i')
      .replace(/[òó]/g, 'o').replace(/[ùú]/g, 'u')
      .replace(/[—–]/g, ' ');
  }

  function mappaSezioneDiario(titolo) {
    var t = normalizzaTitolo(titolo);
    for (var i = 0; i < DIARIO_SEZIONE_MAP.length; i++) {
      var termini = DIARIO_SEZIONE_MAP[i].match;
      var tuttiPresenti = true;
      for (var j = 0; j < termini.length; j++) {
        if (t.indexOf(termini[j]) === -1) { tuttiPresenti = false; break; }
      }
      if (tuttiPresenti) return DIARIO_SEZIONE_MAP[i].chiave;
    }
    return null;
  }

  function vuotoDiarioPersonalita() {
    var p = {};
    for (var i = 0; i < DIARIO_CHIAVI.length; i++) p[DIARIO_CHIAVI[i]] = [];
    return p;
  }

  // Ritorna { gentile: {apertura:[...], cibo_bene:[...], ...}, maleducato: {...}, ... }
  // Stesso schema riga-per-riga di parsePersonalita: "## Personalita" apre un blocco
  // personalita, "### Momento" apre la sotto-chiave dentro quel blocco, "- frammento" accoda.
  function parseDiario(testo) {
    var out = {};
    for (var i = 0; i < PERSONALITA_FILES.length; i++) out[PERSONALITA_FILES[i]] = vuotoDiarioPersonalita();
    if (!testo) return out;

    var righe = testo.split(/\r?\n/);
    var personalitaCorrente = null;
    var chiaveCorrente = null;

    for (var r = 0; r < righe.length; r++) {
      var riga = righe[r].trim();
      if (riga === '') continue;

      if (riga.indexOf('### ') === 0) {
        var titoloMomento = riga.substring(4).trim();
        chiaveCorrente = mappaSezioneDiario(titoloMomento);
        if (!chiaveCorrente) {
          console.warn('PETQ.content: sottosezione diario non riconosciuta: "' + titoloMomento + '"');
        }
        continue;
      }

      if (riga.indexOf('## ') === 0) {
        var titoloPersonalita = riga.substring(3).trim().toLowerCase();
        personalitaCorrente = (out[titoloPersonalita]) ? titoloPersonalita : null;
        if (!personalitaCorrente) {
          console.warn('PETQ.content: personalita diario non riconosciuta: "' + titoloPersonalita + '"');
        }
        chiaveCorrente = null;
        continue;
      }

      if (riga.indexOf('- ') === 0 && personalitaCorrente && chiaveCorrente) {
        var frammento = riga.substring(2).trim();
        if (frammento !== '') out[personalitaCorrente][chiaveCorrente].push(frammento);
      }
    }

    return out;
  }

  // ---------- parser talenti (PROTOTIPO 2, Blocco 9, content/talenti.md) ----------
  // Struttura del file: sezioni "## <Personalita> — firma <Stat>" (una per personalita', stesse
  // chiavi di PERSONALITA_FILES), ognuna con due tabelle sotto "### Nascita (estrai 1)" e
  // "### Teen (estrai 1)": colonne | Talento | Rarita | Effetto | Dati |. Rarita: 🟡 = raro
  // (true), ⚪ (o qualunque altro simbolo/etichetta "normale") = normale (false). "Dati" e' la
  // stringa DSL grezza (token separati da " ; ", stesso stile del DSL missioni): il parser la
  // spacca in un array "effetti" ma NON interpreta i singoli token (motore futuro, v.
  // PETQ.talenti in talenti.js per il registry di cosa e' agganciato vs TODO).
  // Ritorna { <personalita>: { nascita: [ {nome,raro,effettoTesto,dati,effetti[]} x3 ], teen: [...] } }.
  // Tollerante: sezioni/tabelle mancanti o malformate producono array vuoti + console.warn,
  // mai un'eccezione che blocca il resto del caricamento.

  var TALENTI_STADI = ['nascita', 'teen', 'adulto'];

  function vuotoTalentiPersonalita() {
    var p = {};
    for (var i = 0; i < TALENTI_STADI.length; i++) p[TALENTI_STADI[i]] = [];
    return p;
  }

  function parseTalenti(testo) {
    var out = {};
    for (var i = 0; i < PERSONALITA_FILES.length; i++) out[PERSONALITA_FILES[i]] = vuotoTalentiPersonalita();
    if (!testo) return out;

    var righe = testo.split(/\r?\n/);

    // individua i blocchi "## <Personalita> — ..." (una sezione per personalita'; ferma al
    // prossimo "## " di livello pari, es. "## Pool Inventore" o "## Dipendenze / da fare in P2",
    // che non sono personalita' e vanno ignorati con un warning se non riconosciuti).
    var blocchi = [];
    var corrente = null;
    for (var r = 0; r < righe.length; r++) {
      var riga = righe[r];
      if (riga.indexOf('## ') === 0) {
        if (corrente) blocchi.push(corrente);
        var titolo = riga.substring(3).trim();
        // "Sportivo — firma Forza" -> prima parola prima del trattino/em-dash, minuscolo
        var nomePers = titolo.split(/[—–-]/)[0].trim().toLowerCase();
        corrente = { personalita: (out[nomePers]) ? nomePers : null, titolo: titolo, righe: [] };
        continue;
      }
      if (corrente) corrente.righe.push(riga);
    }
    if (corrente) blocchi.push(corrente);

    for (var b = 0; b < blocchi.length; b++) {
      var blocco = blocchi[b];
      if (!blocco.personalita) continue; // sezioni non-personalita' (Pool Inventore, Dipendenze, Come estendere...)
      try {
        out[blocco.personalita] = parseSezionePersonalitaTalenti(blocco.righe, blocco.personalita);
      } catch (e) {
        console.warn('PETQ.content: errore parsing talenti per "' + blocco.personalita + '", terne vuote', e);
      }
    }

    return out;
  }

  // Dentro la sezione di una personalita': individua le sotto-sezioni "### Nascita ...",
  // "### Teen ..." e "### Adulto ..." (stadio = lista aperta per estensioni future, v. talenti.md
  // "Come estendere"). Il match e' per SOTTOSTRINGA sul titolo minuscolo (indexOf), non uguaglianza
  // stretta: tollera il testo extra dopo il nome stadio negli header reali, es. "### Adulto
  // (estrai 1) — PROPOSTA P3 (in attesa conferma fondatore; quaterna 30/30/30/10)".
  function parseSezionePersonalitaTalenti(righe, nomePersonalita) {
    var out = vuotoTalentiPersonalita();
    var stadioCorrente = null;
    var righeStadio = {};
    for (var i = 0; i < TALENTI_STADI.length; i++) righeStadio[TALENTI_STADI[i]] = [];

    for (var i = 0; i < righe.length; i++) {
      var riga = righe[i];
      var mSotto = riga.match(/^###\s+(.+)$/);
      if (mSotto) {
        var titoloStadio = mSotto[1].toLowerCase();
        if (titoloStadio.indexOf('nascita') !== -1) stadioCorrente = 'nascita';
        else if (titoloStadio.indexOf('adulto') !== -1) stadioCorrente = 'adulto';
        else if (titoloStadio.indexOf('teen') !== -1) stadioCorrente = 'teen';
        else stadioCorrente = null; // es. eventuali sotto-sezioni future non ancora note
        continue;
      }
      if (stadioCorrente) righeStadio[stadioCorrente].push(riga);
    }

    for (var s = 0; s < TALENTI_STADI.length; s++) {
      var stadio = TALENTI_STADI[s];
      var tabella = primaTabella(righeStadio[stadio].join('\n'));
      if (!tabella) {
        console.warn('PETQ.content: nessuna terna "' + stadio + '" trovata per personalita "' + nomePersonalita + '"');
        continue;
      }
      var terna = [];
      for (var j = 0; j < tabella.righe.length; j++) {
        var c = tabella.righe[j];
        if (c.length < 4) continue;
        var nome = (c[0] || '').trim();
        if (nome === '' || /^talento$/i.test(nome)) continue; // salta eventuale riga header ripetuta
        var rarita = (c[1] || '');
        var raro = rarita.indexOf('🟡') !== -1 || /raro/i.test(rarita);
        var effettoTesto = (c[2] || '').trim();
        // la colonna Dati e' scritta come codice inline in markdown (`token ; token`): tolti i
        // backtick prima di splittare, altrimenti restano attaccati al primo/ultimo token.
        var dati = (c[3] || '').trim().replace(/^`+|`+$/g, '').trim();
        terna.push({
          nome: nome,
          raro: raro,
          effettoTesto: effettoTesto,
          dati: dati,
          effetti: splitToken(dati, ';')
        });
      }
      // Atteso: terna (3 = 2 normali + 1 raro, nascita/teen) o quaterna (4 = 3 normali + 1 raro,
      // alcune sezioni Adulto P3, v. talenti.md "quaterna 30/30/30/10"). Qualunque altro conteggio
      // e' sospetto (file mal formattato) e va segnalato.
      if (terna.length !== 3 && terna.length !== 4) {
        console.warn('PETQ.content: terna "' + stadio + '" di "' + nomePersonalita + '" ha ' + terna.length + ' talenti invece di 3 (o 4 per una quaterna)');
      }
      out[stadio] = terna;
    }

    return out;
  }

  // ---------- parser Pool Inventore (talento Nerd raro "Inventore", content/talenti.md) ----------
  // La sezione "## Pool Inventore ..." di talenti.md contiene una tabella | # | Oggetto | Effetto |
  // con 7 righe. Ritorna [ { nome, effetto } x7 ] preservando l'ORDINE (l'invenzione settimanale
  // pesca a caso da questo array, v. PETQ.talenti.applicaInvenzione). Non interpretiamo qui gli
  // effetti (testo libero "+30 Energia subito", "arredo, +1 Int passivo", ecc.): l'interpretazione
  // e' in talenti.js applicaInvenzione, cosi' il parser resta puramente strutturale come per i
  // talenti (che espongono la colonna Dati grezza, non gia' risolta).
  // Tollerante: sezione/tabella mancante -> array vuoto + console.warn, mai un'eccezione.
  function parsePoolInventore(testo) {
    if (!testo) return [];
    var righe = testo.split(/\r?\n/);

    // isola le righe della sezione "## Pool Inventore" (fino al prossimo "## " di pari livello)
    var dentro = false;
    var righeSezione = [];
    for (var r = 0; r < righe.length; r++) {
      var riga = righe[r];
      if (riga.indexOf('## ') === 0) {
        var titolo = riga.substring(3).trim().toLowerCase();
        dentro = (titolo.indexOf('pool inventore') !== -1);
        continue;
      }
      if (dentro) righeSezione.push(riga);
    }

    var tabella = primaTabella(righeSezione.join('\n'));
    if (!tabella) {
      console.warn('PETQ.content: sezione "Pool Inventore" non trovata o senza tabella');
      return [];
    }

    var out = [];
    for (var i = 0; i < tabella.righe.length; i++) {
      var c = tabella.righe[i];
      if (c.length < 3) continue; // colonne attese: # | Oggetto | Effetto
      var nome = (c[1] || '').trim();
      if (nome === '' || /^oggetto$/i.test(nome)) continue; // salta header ripetuto/righe vuote
      var effetto = (c[2] || '').trim();
      out.push({ nome: nome, effetto: effetto });
    }

    if (out.length !== 7) {
      console.warn('PETQ.content: Pool Inventore ha ' + out.length + ' voci invece di 7');
    }
    return out;
  }

  // ---------- parser battute legate ai talenti (content/battute-talenti.md) ----------
  // File a se' (NON passa da SEZIONE_MAP / mappaSezione, che fa match per sottostringa e non va
  // usato qui, v. nota in testa a battute-talenti.md). Struttura:
  //   ## <Personalita>                         (sportivo/gentile/nerd/maleducato)
  //   ### <Talento> — <momento>                (una sottosezione = una voce)
  //   Condizione: `talento:<nomeNormalizzato>` · Momento: <descrizione prosa>
  //   - battuta
  //   - battuta
  // Ritorna { sportivo:[...], gentile:[...], nerd:[...], maleducato:[...] }, ogni voce:
  //   { talento:<nome normalizzato senza spazi, lowercase, dalla riga Condizione talento:X>,
  //     momento:<testo prosa della riga Momento>, chiave:<chiave-momento machine-readable, o null>,
  //     sostitutivo:<bool: true se il momento contiene "SOSTITUISCE">, battute:[...] }.
  // Tollerante: sezioni/righe malformate producono voci saltate + console.warn, mai un'eccezione.

  // Tabella keyword→chiave dedicata (come SEZIONE_MAP ma per le battute-talenti). Ogni regola:
  // { match:[termini AND, tutti presenti nel Momento normalizzato], chiave }. Ordine: le regole
  // piu' specifiche PRIMA delle generiche (es. "coccole finite" prima di "coccola"; "invenzione
  // flop" prima di "invenzione riuscita"). Il Momento e' normalizzato con normalizzaTitolo
  // (minuscolo, accenti e trattini tolti) prima del match.
  var BATTUTA_TALENTO_CHIAVE_MAP = [
    { match: ['rifiuta', 'dolce'], chiave: 'rifiuta_dolce' },
    { match: ['offre un dolce'], chiave: 'rifiuta_dolce' },
    { match: ['viene lavato'], chiave: 'lavato' },
    { match: ['lo lava'], chiave: 'lavato' },
    { match: ['combattimento bloccata'], chiave: 'categoria_bloccata' },
    { match: ['esclusa dalla rosa'], chiave: 'categoria_bloccata' },
    { match: ['igiene bassa'], chiave: 'sporco' },
    { match: ['e sporco'], chiave: 'sporco' },
    { match: ['coccole finite'], chiave: 'coccole_finite' },
    { match: ['cap coccole'], chiave: 'coccole_finite' },
    { match: ['coccola ricevuta'], chiave: 'coccola' },
    { match: ['ritorno da missione'], chiave: 'missione_ritorno' },
    { match: ['ritorno da qualsiasi missione'], chiave: 'missione_ritorno' },
    { match: ['fine allenamento'], chiave: 'allenamento_fine' },
    { match: ['allenamento'], chiave: 'allenamento_fine' },
    { match: ['risveglio'], chiave: 'risveglio' },
    { match: ['login'], chiave: 'login' },
    { match: ['furto'], chiave: 'furto' },
    { match: ['oggetto gratis'], chiave: 'furto' },
    { match: ['invenzione', 'flop'], chiave: 'invenzione_ko' },
    { match: ['invenzione', 'fallat'], chiave: 'invenzione_ko' },
    { match: ['invenzione', 'riuscita'], chiave: 'invenzione_ok' },
    { match: ['mancia'], chiave: 'mancia' },
    { match: ['impara una parola'], chiave: 'parola_imparata' }
  ];

  function chiaveBattutaTalento(momento) {
    var t = normalizzaTitolo(momento || '');
    for (var i = 0; i < BATTUTA_TALENTO_CHIAVE_MAP.length; i++) {
      var termini = BATTUTA_TALENTO_CHIAVE_MAP[i].match;
      var tutti = true;
      for (var j = 0; j < termini.length; j++) {
        if (t.indexOf(termini[j]) === -1) { tutti = false; break; }
      }
      if (tutti) return BATTUTA_TALENTO_CHIAVE_MAP[i].chiave;
    }
    return null;
  }

  // momenti gia' segnalati in console (dedupe del warn qui sotto, persiste tra i riparse)
  var warnMomentiVisti = {};

  function parseBattuteTalenti(testo) {
    var out = {};
    for (var i = 0; i < PERSONALITA_FILES.length; i++) out[PERSONALITA_FILES[i]] = [];
    if (!testo) return out;

    var righe = testo.split(/\r?\n/);
    var personalitaCorrente = null;
    var voceCorrente = null;

    function chiudiVoce() {
      if (voceCorrente && personalitaCorrente) {
        if (voceCorrente.talento && voceCorrente.battute.length > 0) {
          out[personalitaCorrente].push(voceCorrente);
        } else {
          console.warn('PETQ.content: voce battute-talenti scartata (talento o battute mancanti): "' +
            (voceCorrente.momento || voceCorrente.talento || '?') + '"');
        }
      }
      voceCorrente = null;
    }

    for (var r = 0; r < righe.length; r++) {
      var riga = righe[r].trim();
      if (riga === '') continue;

      // "## <Personalita>": nuova sezione personalita' (chiude la voce aperta)
      if (riga.indexOf('## ') === 0 && riga.indexOf('### ') !== 0) {
        chiudiVoce();
        var nomePers = riga.substring(3).trim().toLowerCase();
        personalitaCorrente = (out[nomePers]) ? nomePers : null;
        continue;
      }

      // "### <Talento> — <momento>": nuova voce (chiude la precedente)
      if (riga.indexOf('### ') === 0) {
        chiudiVoce();
        if (personalitaCorrente) {
          voceCorrente = { talento: '', momento: '', chiave: null, sostitutivo: false, battute: [] };
        }
        continue;
      }

      if (!voceCorrente || !personalitaCorrente) continue;

      // riga meta "Condizione: `talento:<nome>` · Momento: <prosa>"
      // (il separatore puo' essere `·` o altro; estraiamo talento e momento con regex distinte
      // cosi' l'ordine/il separatore non contano)
      var mTal = riga.match(/talento\s*:\s*([^`·\n]+)/i);
      if (mTal && !voceCorrente.talento) {
        voceCorrente.talento = mTal[1].trim().replace(/`/g, '').replace(/\s+/g, '').toLowerCase();
      }
      var mMom = riga.match(/momento\s*:\s*(.+)$/i);
      if (mMom && !voceCorrente.momento) {
        var momentoTesto = mMom[1].trim();
        voceCorrente.momento = momentoTesto;
        voceCorrente.sostitutivo = /sostituisce/i.test(momentoTesto);
        voceCorrente.chiave = chiaveBattutaTalento(momentoTesto);
        // Warn DEDUPLICATO (una volta per momento distinto, non a ogni riparse): molte voci del
        // socio sono "write-ahead" (momenti senza hook ancora, per design) e il file viene
        // parsato piu' volte (bundle + fetch live) -> senza dedupe la console si riempie di
        // decine di warn identici che nascondono gli errori veri al tester.
        if (voceCorrente.chiave === null && !warnMomentiVisti[momentoTesto]) {
          warnMomentiVisti[momentoTesto] = true;
          console.warn('PETQ.content: momento battute-talenti senza chiave riconosciuta (write-ahead?): "' + momentoTesto + '"');
        }
      }

      // battuta ("- ..."); il marker [ESEMPIO] eventuale viene strippato come per parsePersonalita
      if (riga.indexOf('- ') === 0) {
        var battuta = riga.substring(2).trim().replace(/^\[ESEMPIO\]\s*/i, '');
        // salta la riga "NOTA REFUSO: ..." (nota per il fondatore, non e' una battuta)
        if (battuta !== '' && !/^NOTA\b/i.test(battuta)) {
          voceCorrente.battute.push(battuta);
        }
      }
    }
    chiudiVoce();

    return out;
  }

  // ---------- parser tabelle md (utility comune) ----------

  // Estrae la prima tabella markdown del testo: ritorna { header:[...], righe:[[...],[...]] }
  function primaTabella(testo) {
    if (!testo) return null;
    var righe = testo.split(/\r?\n/);
    var righeTabella = [];
    var dentro = false;

    for (var i = 0; i < righe.length; i++) {
      var r = righe[i].trim();
      var eRigaTabella = r.indexOf('|') !== -1;

      if (!dentro && eRigaTabella) {
        dentro = true;
      } else if (dentro && !eRigaTabella) {
        break;
      }

      if (dentro) righeTabella.push(r);
    }

    if (righeTabella.length < 2) return null;

    var header = splitCelle(righeTabella[0]);
    var corpo = [];
    for (var j = 1; j < righeTabella.length; j++) {
      if (/^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$/.test(righeTabella[j])) continue; // riga separatore ---
      var celle = splitCelle(righeTabella[j]);
      if (celle.length === 0) continue;
      corpo.push(celle);
    }

    return { header: header, righe: corpo };
  }

  // Estrae TUTTE le tabelle markdown del testo (blocchi di righe contenenti "|"
  // separati da almeno una riga non-tabella): ritorna un array di { header:[...], righe:[[...],[...]] }.
  // Utile per content/arredi.md che ha due tabelle con lo stesso header da concatenare.
  function tutteLeTabelle(testo) {
    if (!testo) return [];
    var righe = testo.split(/\r?\n/);
    var risultati = [];
    var blocco = [];

    function chiudiBlocco() {
      if (blocco.length >= 2) {
        var header = splitCelle(blocco[0]);
        var corpo = [];
        for (var j = 1; j < blocco.length; j++) {
          if (/^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$/.test(blocco[j])) continue; // riga separatore ---
          var celle = splitCelle(blocco[j]);
          if (celle.length === 0) continue;
          corpo.push(celle);
        }
        if (corpo.length > 0) risultati.push({ header: header, righe: corpo });
      }
      blocco = [];
    }

    for (var i = 0; i < righe.length; i++) {
      var r = righe[i].trim();
      var eRigaTabella = r.indexOf('|') !== -1;
      if (eRigaTabella) {
        blocco.push(r);
      } else if (blocco.length > 0) {
        chiudiBlocco();
      }
    }
    chiudiBlocco();

    return risultati;
  }

  // Spezza un file markdown in sezioni { titolo, righe[] } su QUALSIASI header (#, ##, ###...).
  // Il testo prima del primo header finisce in una sezione con titolo ''. Serve a content/arredi.md,
  // dove tabelle con lo STESSO numero di colonne hanno significati diversi a seconda della sezione
  // (arredi vs indossabili vs armi vs giocattoli): l'unico modo sicuro di smistarle e' il titolo.
  function sezioniMd(testo) {
    var out = [{ titolo: '', righe: [] }];
    if (!testo) return out;
    var righe = testo.split(/\r?\n/);
    for (var i = 0; i < righe.length; i++) {
      var m = righe[i].match(/^#{1,6}\s+(.*)$/);
      if (m) {
        out.push({ titolo: m[1].trim(), righe: [] });
        continue;
      }
      out[out.length - 1].righe.push(righe[i]);
    }
    return out;
  }

  function splitCelle(riga) {
    var r = riga.trim();
    if (r.indexOf('|') === 0) r = r.substring(1);
    if (r.lastIndexOf('|') === r.length - 1) r = r.substring(0, r.length - 1);
    var parti = r.split('|');
    var out = [];
    for (var i = 0; i < parti.length; i++) out.push(parti[i].trim());
    return out;
  }

  // I soci a volte incollano il nome (colonna 0) ancora in grassetto markdown, copiando la riga
  // da un'altra tabella o da una lista puntata ("**Torta Bold**"): senza questa pulizia gli
  // asterischi restano ATTACCATI al nome e da quel momento il nome non matcha piu' NIENTE
  // (negozio, token reward cibo:/arredo:/indossabile:/arma:/giocattolo:, condizioni missione) —
  // un refuso silenzioso e difficile da diagnosticare per chi scrive content/. Strip SOLO
  // iniziale/finale (comune ai 4 parser a tabella: cibi/arredi/indossabili+armi/giocattoli),
  // fatto PRIMA di ogni altro uso del nome.
  function ripulisciNomeTabella(raw) {
    var s = (raw || '').trim();
    s = s.replace(/^\*+\s*/, '').replace(/\s*\*+$/, '');
    return s.trim();
  }

  function primoNumero(testo) {
    if (!testo) return 0;
    var m = testo.match(/-?\d+([.,]\d+)?/);
    if (!m) return 0;
    return parseFloat(m[0].replace(',', '.'));
  }

  function tuttiINumeri(testo) {
    if (!testo) return [];
    var m = testo.match(/-?\d+([.,]\d+)?/g);
    if (!m) return [];
    return m.map(function (s) { return parseFloat(s.replace(',', '.')); });
  }

  // ---------- parser cibi ----------
  // Colonne attese per posizione: Nome | Categoria | Costo | +Fame | Effetti | Note

  // content/cibi.md ha PIU' tabelle con lo stesso header (Base e classici, I MEME, I CIBI DEL
  // DISONORE, Solo da missione): si concatenano tutte le righe di tutte le tabelle trovate
  // (tutteLeTabelle), stessa scelta di parseArredi. Con primaTabella sarebbero esistiti in gioco
  // solo i cibi della PRIMA sezione. L'ordine resta quello del file: i 23 classici per primi.
  function parseCibi(testo) {
    var tabelle = tutteLeTabelle(testo);
    if (tabelle.length === 0) return [];

    var out = [];
    for (var t = 0; t < tabelle.length; t++) {
      var tabella = tabelle[t];
      for (var i = 0; i < tabella.righe.length; i++) {
        var c = tabella.righe[i];
        if (c.length < 5) {
          console.warn('PETQ.content: riga cibo scartata, colonne insufficienti (' + c.length + '/5 attese Nome|Categoria|Costo|+Fame|Effetti): "' + (c[0] || '?') + '"');
          continue;
        }

        var nome = ripulisciNomeTabella(c[0]);
        if (nome === '') continue;

        var categoria = (c[1] || '').toLowerCase();
        var costo = primoNumero(c[2]);
        var fame = primoNumero(c[3]);

        var celStat = c[4] || '';
        var effetti = estraiEffettiCibo(celStat);
        var statInfo = primoEffettoRpg(effetti);

        // Colonna Note (indice 5, ultima): oltre alla prosa decorativa puo' contenere l'etichetta
        // MULTI-PORZIONE con moltiplicatore (v. estraiPorzioniCibo). Puo' mancare su righe
        // malformate: c[5]||'' evita un undefined che manderebbe in errore il match.
        var celNote = c[5] || '';
        var porzioni = estraiPorzioniCibo(celNote);

        out.push({
          nome: nome,
          categoria: categoria,
          costo: costo,
          fame: fame,
          // Retro-compatibilita': stat/statNome restano il PRIMO effetto RPG del cibo (era l'unico
          // possibile prima del Tier 2). Ci contano care.feed (extra talenti/Chef), ui.descriviCibo
          // e ciboFallback: NON rimuoverli finche' quei chiamanti non passano tutti a `effetti`.
          stat: statInfo.valore,
          statNome: statInfo.nome,
          // Tier 2 (cibi multi-effetto con malus, 10 lug 2026): lista ORDINATA di
          // {tipo:'rpg'|'rpg_casuale'|'benessere', nome, valore}. Vuota per i cibi senza effetti.
          // 'rpg_casuale' ha nome null: la stat la estrae il motore a ogni porzione (v. care.feed).
          effetti: effetti,
          // MULTI-PORZIONE (decisione fondatore, 27 lug 2026): quante porzioni consegna UN acquisto
          // o UN reward missione di questo cibo. Intero >=1, default 1 (quasi tutto il catalogo).
          porzioni: porzioni
        });
      }
    }
    return out;
  }

  // Nomi effetto riconosciuti nella colonna Effetti dei cibi. Match per SOTTOSTRINGA (stessa
  // tolleranza del vecchio STAT_ALIAS) cosi' 'Velocita'/'Velocità' e 'Felicita'/'Felicità'
  // cadono nello stesso posto senza dipendere dagli accenti che scrivono i soci.
  var EFFETTO_ALIAS = [
    { match: 'forza', tipo: 'rpg', nome: 'forza' },
    { match: 'intelligen', tipo: 'rpg', nome: 'intelligenza' },
    { match: 'veloc', tipo: 'rpg', nome: 'velocita' },
    { match: 'carisma', tipo: 'rpg', nome: 'carisma' },
    { match: 'fame', tipo: 'benessere', nome: 'fame' },
    { match: 'igiene', tipo: 'benessere', nome: 'igiene' },
    { match: 'felicit', tipo: 'benessere', nome: 'felicita' },
    { match: 'energia', tipo: 'benessere', nome: 'energia' },
    { match: 'ferit', tipo: 'benessere', nome: 'ferite' }
  ];

  // I soci scrivono le tabelle da GitHub web, dove il trattino diventa spesso il meno
  // "tipografico": U+2212 (meno matematico) o U+2013 (en-dash). Senza questa normalizzazione
  // 'Carisma −2' veniva letto +2 IN SILENZIO.
  // L'em-dash U+2014 ('—') ha DUE usi nelle tabelle e vanno distinti:
  //  - da solo e' il segnaposto "nessun effetto"/"non in vendita" -> NON si tocca;
  //  - davanti a una cifra e' un meno vero (l'autocorrezione di GitHub trasforma '--' in '—'),
  //    quindi 'Carisma —2' va letto -2 e non +2 in silenzio.
  // Il replace converte SOLO il secondo caso e mangia anche gli spazi in mezzo ('Carisma — 2'
  // -> 'Carisma -2'): il segno deve restare attaccato alla cifra o il match numerico successivo
  // lo perderebbe di nuovo.
  function normalizzaMeno(testo) {
    return (testo || '')
      .replace(/−/g, '-')
      .replace(/–/g, '-')
      .replace(/—\s*(?=\d)/g, '-');
  }

  // '+2 stat RPG casuale' / '+1 stat RPG casuale': la stat non e' scritta nella tabella, la
  // estrae il motore a ogni porzione (v. care.feed). Effetto dedicato {tipo:'rpg_casuale',
  // nome:null, valore:N}: e' un effetto RPG a tutti gli effetti (consuma lo slot dei pasti-con-stat)
  // ma senza nome, quindi NON puo' passare dal ramo EFFETTO_ALIAS qui sotto.
  var RE_RPG_CASUALE = /([+-]?\d+)\s*stat\s*rpg\s*casual/i;

  // Separatori delle voci nella colonna Effetti. Oltre a virgola/punto e virgola/interpunto i
  // soci scrivono anche in prosa ('Felicita +5 e Igiene -5') o con la barra ('Forza +3 /
  // Velocita -1'): senza questi separatori le due voci finivano nella STESSA parte e la seconda
  // veniva persa in silenzio (vinceva il primo alias trovato, col numero sbagliato). La 'e' si
  // riconosce solo come congiunzione ISOLATA (spazi attorno), mai come lettera dentro le parole.
  var RE_SEPARATORI_EFFETTI = /[,;·]|\s+[eE]\s+|\//;

  // Colonna Effetti: lista separata da virgole, ogni voce = nome effetto + valore con segno
  // ('Forza +3, Velocita -1', 'Forza +1, Igiene -15', 'Carisma -2'). Ritorna un array ordinato
  // di {tipo, nome, valore}. Le celle senza effetti riconoscibili ('—', vuoto) ritornano []
  // senza rumore in console: sono legittime, non errori di battitura.
  function estraiEffettiCibo(cella) {
    var testo = normalizzaMeno(cella || '');
    var parti = testo.split(RE_SEPARATORI_EFFETTI);
    var out = [];
    for (var i = 0; i < parti.length; i++) {
      var parte = parti[i];
      if (typeof parte !== 'string') continue;
      var t = parte.toLowerCase();
      // prima il caso senza nome-stat: 'stat RPG casuale' non contiene nessun alias, ma il
      // controllo sta qui davanti per non dipendere da quell'assenza in futuro.
      var mCas = parte.match(RE_RPG_CASUALE);
      if (mCas) {
        out.push({ tipo: 'rpg_casuale', nome: null, valore: parseInt(mCas[1], 10) });
        continue;
      }
      for (var j = 0; j < EFFETTO_ALIAS.length; j++) {
        var alias = EFFETTO_ALIAS[j];
        if (t.indexOf(alias.match) === -1) continue;
        var m = parte.match(/[+-]?\d+([.,]\d+)?/);
        if (!m) break; // nome senza numero: voce ignorata
        out.push({
          tipo: alias.tipo,
          nome: alias.nome,
          valore: parseFloat(m[0].replace(',', '.'))
        });
        break;
      }
    }
    return out;
  }

  // Primo effetto RPG della lista (o {null, 0}): alimenta cibo.stat/cibo.statNome.
  function primoEffettoRpg(effetti) {
    for (var i = 0; i < effetti.length; i++) {
      if (effetti[i].tipo === 'rpg') return { nome: effetti[i].nome, valore: effetti[i].valore };
    }
    return { nome: null, valore: 0 };
  }

  // MULTI-PORZIONE (colonna Note dei cibi, decisione fondatore 27 lug 2026): un'etichetta tipo
  // "MULTI-PORZIONE ×3 fette" dice che un acquisto/reward di quel cibo consegna N porzioni invece
  // di 1 sola (il prezzo/reward resta unico, si paga/vince una volta e si ricevono N porzioni).
  // Regex tollerante: case-insensitive, "multi" e "porzione/porzioni" possono avere uno spazio o
  // un trattino in mezzo o niente, e il moltiplicatore puo' essere scritto sia col carattere
  // tipografico × (quello davvero usato oggi in cibi.md) sia con la lettera x/X, con o senza
  // spazio prima della cifra ("×3", "x5", "× 3"). Le righe senza l'etichetta (quasi tutto il
  // catalogo) semplicemente non matchano.
  var RE_PORZIONI = /multi[\s-]*porzion[ei]\s*[×xX]\s*(\d+)/i;
  function estraiPorzioniCibo(nota) {
    // Tollerante per contratto (CLAUDE.md "parser tolleranti"): una Note scritta male non deve MAI
    // rompere il caricamento dei cibi, ricade sempre su 1 porzione (il comportamento di sempre).
    try {
      var m = (nota || '').match(RE_PORZIONI);
      if (!m) return 1;
      var n = parseInt(m[1], 10);
      if (!n || isNaN(n) || n <= 0) return 1;
      return n;
    } catch (e) {
      return 1;
    }
  }

  // Alias ESATTI (match completo del token, non substring) per normalizzare un nome-stat RPG al
  // nome canonico. Le schede del fondatore usano indifferentemente il nome per esteso
  // (intelligenza) o l'abbreviazione (int) sia nelle CONDIZIONI (int>=3) che nei REWARD (int+2):
  // questo normalizzatore le rende equivalenti (regola CLAUDE.md "parser tolleranti"). Match
  // ESATTO apposta, cosi' i token non-stat come 'fel'/'monete'/'ferite'/'igiene' NON collidono e
  // proseguono verso i loro rami dedicati. Usato da parseTermine (cond) e da missions.applicaRewardToken.
  var STAT_CANON_ESATTI = {
    forza: 'forza', 'for': 'forza', fo: 'forza',
    intelligenza: 'intelligenza', intelligen: 'intelligenza', intel: 'intelligenza', 'int': 'intelligenza',
    velocita: 'velocita', 'velocità': 'velocita', veloc: 'velocita', vel: 'velocita',
    carisma: 'carisma', car: 'carisma'
  };
  function normalizzaStatNome(raw) {
    var s = (raw || '').trim().toLowerCase();
    return Object.prototype.hasOwnProperty.call(STAT_CANON_ESATTI, s) ? STAT_CANON_ESATTI[s] : null;
  }

  // ---------- parser arredi ----------
  // Colonne attese per posizione: Nome | Stanza | Razza | Rarita | Come si ottiene | Bonus
  // content/arredi.md ha PIU' tabelle di arredi con lo stesso header (base, da missione, adulto,
  // companion leggendari): si concatenano tutte le righe di tutte le tabelle DELLE SEZIONI ARREDI.
  // ATTENZIONE: le sezioni Indossabili / Indossabili MEME / Armi / GIOCATTOLI dello stesso file
  // hanno tabelle a 6 colonne IDENTICHE nella forma ma con un significato completamente diverso
  // (Tipo/Rarita/Prezzo/Fonte/Effetti, non Stanza/Razza/Rarita/Fonte/Bonus). Prendere "tutte le
  // tabelle del file" le faceva entrare in data.arredi come arredi finti. Lo smistamento e' per
  // TITOLO DI SEZIONE (tipoSezioneArredi), mai per numero di colonne.

  // Classifica una sezione di content/arredi.md dal suo titolo. Match sull'INIZIO del titolo
  // normalizzato (minuscolo, senza accenti/em-dash) e non per sottostringa: il titolo
  // "Modifiche permanenti (M17 Pimp My Pet — NON arredi ne' indossabili: ...)" CONTIENE la parola
  // "indossabili" pur non essendo quella sezione. Tutto cio' che non e' riconosciuto resta
  // 'arredi' (comportamento storico: una sezione nuova scritta dai soci finisce fra gli arredi).
  function tipoSezioneArredi(titolo) {
    var t = normalizzaTitolo(titolo || '').trim();
    if (t.indexOf('indossabil') === 0) return 'indossabili';
    if (t.indexOf('armi') === 0) return 'armi';
    if (t.indexOf('giocattol') === 0) return 'giocattoli';
    return 'arredi';
  }

  // Tutte le tabelle delle sezioni di quel tipo, nell'ordine del file.
  function tabelleSezioniArredi(testo, tipo) {
    var sezioni = sezioniMd(testo);
    var out = [];
    for (var i = 0; i < sezioni.length; i++) {
      if (tipoSezioneArredi(sezioni[i].titolo) !== tipo) continue;
      var tabelle = tutteLeTabelle(sezioni[i].righe.join('\n'));
      for (var j = 0; j < tabelle.length; j++) out.push(tabelle[j]);
    }
    return out;
  }

  // Prezzo in monete da una cella: numero = comprabile, "—"/vuoto = solo drop (null).
  function prezzoDaCella(cella) {
    var m = (cella || '').match(/\d+/);
    return m ? parseInt(m[0], 10) : null;
  }

  function parseArredi(testo) {
    var tabelle = tabelleSezioniArredi(testo, 'arredi');
    if (tabelle.length === 0) return [];

    var out = [];
    for (var t = 0; t < tabelle.length; t++) {
      var tabella = tabelle[t];
      for (var i = 0; i < tabella.righe.length; i++) {
        var c = tabella.righe[i];
        if (c.length < 6) {
          console.warn('PETQ.content: riga arredo scartata, colonne insufficienti (' + c.length + '/6 attese Nome|Stanza|Razza|Rarita|Come si ottiene|Bonus): "' + (c[0] || '?') + '"');
          continue;
        }

        var nome = ripulisciNomeTabella(c[0]);
        if (nome === '') continue;

        var bonusRaw = c[5] || '';
        var estratto = null;
        try {
          estratto = estraiBonusArredo(bonusRaw);
        } catch (e) {
          console.warn('PETQ.content: bonus arredo non parsabile per "' + nome + '": "' + bonusRaw + '"', e);
        }
        if (!estratto) {
          estratto = { bonusStat: null, bonusValore: 0, perk: null, soloCollezione: false, effettoSpeciale: null, effetti: [] };
        }

        var fonte = c[4] || '';
        var mSostituisce = fonte.match(/sostituisce\s+(?:l['’]|la\s+|il\s+)?([A-Za-zÀ-ú]+)/i);

        // prezzoNegozio (PROTOTIPO 2, Blocco 7 — TAB NEGOZIO): prezzo d'acquisto in monete se la
        // colonna "Come si ottiene" dice "negozio N monete", null altrimenti. Solo gli arredi con
        // questa fonte sono COMPRABILI: gli arredi da drop/perk/trofeo missione (che non hanno
        // "negozio" nella fonte) restano ricompense uniche e NON vanno in vendita — cosi' non si
        // svaluta l'economia missioni. Stesso pattern del prezzo di rivendita in arredi.js
        // calcolaRicavoVendita (fallback quando manca il campo `rivendita` qui sotto).
        var mPrezzo = fonte.match(/negozio\s+(\d+)/i);
        var prezzoNegozio = mPrezzo ? parseInt(mPrezzo[1], 10) : null;

        // rivendita (correzione fondatore, arredi "colpo grosso" la cui colonna Bonus PROMETTE
        // testualmente un alto valore di rivendita): CHIAVE DIVERSA da "negozio N monete" apposta,
        // cosi' non diventano acquistabili in negozio (restano solo drop). E' la cifra ESATTA che
        // il giocatore INCASSA (arredi.js calcolaRicavoVendita/vendi() la usa senza dimezzarla).
        // Parser tollerante: se manca, il campo resta null e il comportamento e' identico a prima
        // (fallback prezzo negozio/2 o VALORE_FALLBACK/2 in arredi.js). Mai throw.
        var mRivendita = fonte.match(/rivendita\s+(\d+)/i);
        var rivendita = mRivendita ? parseInt(mRivendita[1], 10) : null;

        out.push({
          nome: nome,
          stanza: (c[1] || '').toLowerCase(),
          razza: (c[2] || '').toLowerCase(),
          rarita: (c[3] || '').toLowerCase(),
          fonte: fonte,
          bonus: bonusRaw,
          // Legacy (letti da arredi.bonusPassivi e dalle condizioni missione): PRIMO effetto RPG.
          // Restano per non rompere i chiamanti esistenti; il dato completo e' in `effetti`.
          bonusStat: estratto.bonusStat,
          bonusValore: estratto.bonusValore,
          // Lista ORDINATA di {tipo:'rpg'|'benessere', nome, valore}, stessa forma dei cibi:
          // un arredo puo' avere PIU' bonus ("+2 Intelligenza + +1 Carisma passiva") e la
          // Felicita passiva e' un effetto vero (benessere/felicita), non piu' un effetto speciale.
          effetti: estratto.effetti,
          perk: estratto.perk,
          soloCollezione: estratto.soloCollezione,
          effettoSpeciale: estratto.effettoSpeciale,
          prezzoNegozio: prezzoNegozio,
          rivendita: rivendita,
          sostituisceParziale: mSostituisce ? mSostituisce[1].trim() : null,
          sostituisce: null
        });
      }
    }

    // risolve il nome parziale ("Fascia", "Album") al nome esatto della tabella
    // (es. "Fascia da martial artist", "Album da disegno") cercando un arredo il cui
    // nome CONTIENE la parola indicata dopo "sostituisce" nella colonna fonte.
    for (var s = 0; s < out.length; s++) {
      if (!out[s].sostituisceParziale) continue;
      var parziale = out[s].sostituisceParziale.toLowerCase();
      var match = null;
      for (var k = 0; k < out.length; k++) {
        if (k === s) continue;
        if (out[k].nome.toLowerCase().indexOf(parziale) !== -1) { match = out[k].nome; break; }
      }
      if (match) {
        out[s].sostituisce = match;
      } else {
        console.warn('PETQ.content: "sostituisce ' + out[s].sostituisceParziale + '" non risolto per arredo "' + out[s].nome + '"');
      }
    }

    return out;
  }

  // I soci separano i bonus multipli di un arredo col PIU' ("+2 Intelligenza + +1 Carisma
  // passiva"), che nella sintassi dei cibi non e' un separatore: qui il " + " isolato davanti a
  // un numero con segno diventa una virgola, cosi' estraiEffettiCibo (UNA sola funzione di
  // estrazione effetti in tutto il file) vede due voci invece di una sola.
  // Il lookahead pretende una cifra dopo: "igiene +5 extra per lavaggio" NON viene toccato
  // (li' il + e' attaccato alla cifra, non isolato fra spazi).
  function normalizzaPiuArredo(testo) {
    return (testo || '').replace(/\s+\+\s+(?=[+-]?\d)/g, ', ');
  }

  // Estrae dal testo libero della colonna "Bonus" di arredi.md i campi strutturati
  // usati dal motore missioni/arredi: effetti (lista completa, come i cibi),
  // bonusStat/bonusValore (LEGACY = primo effetto RPG, letti da arredi.bonusPassivi),
  // perk (categoria sbloccata se piazzato), soloCollezione (nessun bonus meccanico),
  // effettoSpeciale (chiave riconosciuta o testo raw se non riconosciuto).
  // La "Felicita passiva" NON e' piu' un effettoSpeciale fantasma ('felicita_passiva', che
  // nessun modulo leggeva): e' un effetto vero {tipo:'benessere', nome:'felicita'} dentro effetti.
  function estraiBonusArredo(testo) {
    var t = (testo || '').trim();
    var out = { bonusStat: null, bonusValore: 0, perk: null, soloCollezione: false, effettoSpeciale: null, effetti: [] };

    if (t === '' || t === '—' || t === '-') {
      out.soloCollezione = true;
      return out;
    }
    if (/solo collezione/i.test(t)) {
      out.soloCollezione = true;
    }

    // bonus passivi su stat/benessere: "+1 Forza passiva", "+2 Intelligenza + +1 Carisma passiva",
    // "+1 Velocita + +1 Felicita passiva". Si estraggono TUTTI (prima ne sopravviveva uno solo).
    // Il gate su "passiv" evita di leggere come bonus i numeri dentro i testi degli effetti
    // speciali (es. "dimezza calo Igiene ... (−10 → −5)" darebbe un falso igiene -10).
    if (/passiv/i.test(t)) {
      out.effetti = estraiEffettiCibo(normalizzaPiuArredo(t));
    }
    var rpg = primoEffettoRpg(out.effetti);
    if (rpg.nome) {
      out.bonusStat = rpg.nome;
      out.bonusValore = rpg.valore;
    }

    // perk: "perk Videogioco" / "perk Combattimento" / "perk Sport" / "perk Sabotatore" / "perk Studio (Doc Brown)" / "perk Parkour Master"
    // Sabotatore = perk arredo di TAG (super sulle gare taggate 'gara', v. missions.scegliEsito).
    // Studio = perk arredo di CATEGORIA 'studio' (Doc Brown, come Videogioco/Combattimento/Sport):
    // il match si ferma a "studio", il "(Doc Brown)" resta fuori (va bene).
    // Parkour = perk arredo di TAG (Scarpe da Parkour): AUTO-SUPER sulle missioni tag 'inseguimento',
    // senza esclusioni (v. missions.scegliEsito). Il match si ferma a "parkour", "Master" resta fuori.
    var mPerk = t.match(/perk\s+(videogioco|combattimento|sport|sabotatore|studio|parkour)/i);
    if (mPerk) out.perk = mPerk[1].toLowerCase();

    // effetti speciali riconosciuti (non ancora tutti implementati nel motore: quelli
    // con chiave dedicata sono pronti per essere agganciati senza ritoccare il parser).
    // bonusValore lo scrivono SOLO se non l'ha gia' preso un bonus stat vero (oggi nessun arredo
    // ha entrambe le cose, la guardia evita che un domani uno dei due sparisca in silenzio).
    if (/dimezza calo igiene/i.test(t)) {
      out.effettoSpeciale = 'igiene_dimezza_pioggia';
    } else if (/sconto cibo/i.test(t)) {
      out.effettoSpeciale = 'sconto_cibo';
      if (!out.bonusStat) out.bonusValore = primoNumero(t) || 10;
    } else if (/igiene.*extra.*lavaggio/i.test(t)) {
      out.effettoSpeciale = 'igiene_extra_lavaggio';
      if (!out.bonusStat) out.bonusValore = primoNumero(t) || 5;
    } else if (/stat\s+rpg\s+casuale/i.test(t)) {
      // Pianta Esotica: +N a UNA stat RPG casuale, ri-estratta ogni giorno, non si accumula.
      // La stat del giorno e' gestita a runtime in arredi.aggiornaPiantaEsotica/bonusPassivi.
      out.effettoSpeciale = 'stat_random_giornaliera';
      if (!out.bonusStat) out.bonusValore = primoNumero(t) || 2;
    } else if (out.effetti.length === 0 && !mPerk && !out.soloCollezione) {
      // testo libero non riconosciuto: lo teniamo come effetto speciale raw, segnalando
      console.warn('PETQ.content: bonus arredo non riconosciuto, tenuto come testo libero: "' + t + '"');
      out.effettoSpeciale = t;
    }

    return out;
  }

  // ---------- parser indossabili e armi (content/arredi.md, sezioni dedicate) ----------
  // Colonne attese per posizione: Nome | Tipo | Rarita | Prezzo | Come si ottiene | Effetti
  // Prezzo: numero = comprabile al negozio, "—" = solo drop (null).
  // Effetti: STESSA sintassi Tier 2 dei cibi ("Carisma +2, Intelligenza +1", "Forza +2, Carisma -2"),
  // estratta da estraiEffettiCibo: i malus sono veri e contano nelle condizioni delle missioni.
  // Una riga (Completo da Chef) non ha stat ma un testo che inizia con "EFFETTO SPECIALE": va in
  // effettoSpeciale e NON deve produrre nessun effetto stat (il motore lo gestisce a parte, care.js).
  // Le sezioni "Indossabili" e "Indossabili MEME" si concatenano nell'ordine del file.

  var RE_EFFETTO_SPECIALE = /^\s*effetto\s+speciale/i;

  function parseRigheEquipaggiamento(tabelle, etichetta) {
    var out = [];
    for (var t = 0; t < tabelle.length; t++) {
      var tabella = tabelle[t];
      for (var i = 0; i < tabella.righe.length; i++) {
        var c = tabella.righe[i];
        if (c.length < 6) {
          console.warn('PETQ.content: riga scartata nella sezione "' + etichetta + '" di arredi.md, colonne insufficienti (' + c.length + '/6 attese Nome|Tipo|Rarita|Prezzo|Come si ottiene|Effetti): "' + (c[0] || '?') + '"');
          continue;
        }

        var nome = ripulisciNomeTabella(c[0]);
        if (nome === '' || /^nome$/i.test(nome)) continue; // salta header ripetuti/righe vuote

        var celEffetti = c[5] || '';
        var speciale = null;
        var effetti = [];
        if (RE_EFFETTO_SPECIALE.test(celEffetti)) {
          speciale = celEffetti.trim();
        } else {
          effetti = estraiEffettiCibo(celEffetti);
        }

        out.push({
          nome: nome,
          tipo: (c[1] || '').trim().toLowerCase(),
          rarita: (c[2] || '').trim().toLowerCase(),
          prezzo: prezzoDaCella(c[3]),
          fonte: (c[4] || '').trim(),
          effetti: effetti,
          effettoSpeciale: speciale
        });
      }
    }
    if (out.length === 0) {
      console.warn('PETQ.content: nessuna riga trovata per la sezione "' + etichetta + '" di arredi.md');
    }
    return out;
  }

  function parseIndossabili(testo) {
    return parseRigheEquipaggiamento(tabelleSezioniArredi(testo, 'indossabili'), 'Indossabili');
  }

  function parseArmi(testo) {
    return parseRigheEquipaggiamento(tabelleSezioniArredi(testo, 'armi'), 'Armi');
  }

  // ---------- parser giocattoli (content/arredi.md, sezione "### GIOCATTOLI") ----------
  // Colonne attese per posizione: Nome | Stanza | Prezzo | Come si ottiene | Usi al giorno | Effetto
  // "Usi al giorno": numero, "illimitati" (-> null) o "passivo" (-> 'passivo', non e' un'azione
  // del menu ma un effetto che vive da solo).
  // "Effetto": vocabolario CHIUSO (un solo effetto per giocattolo), v. arredi.md sezione
  // GIOCATTOLI. Ogni voce diventa {tipo, valore}: valore 0 per gli effetti senza numero.
  var GIOCATTOLO_EFFETTI = [
    { re: /^felicita\s*\+\s*(\d+)$/, tipo: 'felicita' },
    { re: /^progressione\s*:\s*(\d+)$/, tipo: 'progressione' },
    { re: /^notturno\s*:\s*monete\s*\+\s*(\d+)$/, tipo: 'notturno_monete' },
    { re: /^consola$/, tipo: 'consola' },
    { re: /^decrescente$/, tipo: 'decrescente' },
    { re: /^cura_stato$/, tipo: 'cura_stato' },
    { re: /^consiglio$/, tipo: 'consiglio' },
    { re: /^oracolo$/, tipo: 'oracolo' },
    { re: /^duello$/, tipo: 'duello' },
    { re: /^sveglia_gratis$/, tipo: 'sveglia_gratis' }
  ];

  // La cella arriva normalizzata (minuscolo, senza accenti/em-dash) e ripulita dai backtick:
  // i soci scrivono l'effetto come codice inline (`felicita+6`) tanto quanto in chiaro.
  function estraiEffettoGiocattolo(cella) {
    var t = normalizzaTitolo((cella || '').replace(/`/g, '')).trim();
    for (var i = 0; i < GIOCATTOLO_EFFETTI.length; i++) {
      var m = t.match(GIOCATTOLO_EFFETTI[i].re);
      if (!m) continue;
      return { tipo: GIOCATTOLO_EFFETTI[i].tipo, valore: m[1] ? parseInt(m[1], 10) : 0 };
    }
    return null;
  }

  // numero | null (illimitati) | 'passivo'
  function estraiUsiGiorno(cella) {
    var t = normalizzaTitolo(cella || '').trim();
    if (t.indexOf('illimitat') === 0) return null;
    if (t.indexOf('passiv') === 0) return 'passivo';
    var m = t.match(/\d+/);
    return m ? parseInt(m[0], 10) : null;
  }

  function parseGiocattoli(testo) {
    var tabelle = tabelleSezioniArredi(testo, 'giocattoli');
    var out = [];
    for (var t = 0; t < tabelle.length; t++) {
      var tabella = tabelle[t];
      for (var i = 0; i < tabella.righe.length; i++) {
        var c = tabella.righe[i];
        if (c.length < 6) {
          console.warn('PETQ.content: riga giocattolo scartata, colonne insufficienti (' + c.length + '/6 attese Nome|Stanza|Prezzo|Come si ottiene|Usi al giorno|Effetto): "' + (c[0] || '?') + '"');
          continue;
        }

        var nome = ripulisciNomeTabella(c[0]);
        if (nome === '' || /^nome$/i.test(nome)) continue;

        var effetto = estraiEffettoGiocattolo(c[5]);
        if (!effetto) {
          // vocabolario chiuso: un effetto non riconosciuto e' un refuso del file, non un
          // caso legittimo. Si segnala e si tiene la riga con effetto null (il consumatore
          // salta il giocattolo invece di crashare).
          console.warn('PETQ.content: effetto giocattolo non riconosciuto per "' + nome + '": "' + (c[5] || '') + '"');
        }

        out.push({
          nome: nome,
          stanza: (c[1] || '').trim().toLowerCase(),
          prezzo: prezzoDaCella(c[2]),
          fonte: (c[3] || '').trim(),
          usiGiorno: estraiUsiGiorno(c[4]),
          effetto: effetto
        });
      }
    }
    if (out.length === 0) {
      console.warn('PETQ.content: nessun giocattolo trovato in arredi.md');
    }
    return out;
  }

  // ---------- parser missioni ----------
  // Formato atteso (v. docs/SPEC-MODULO-MISSIONI.md): schede separate da "## Missione N ...",
  // righe tecniche "Dati: ..." (scheda-livello e per-esito), blocchi esito introdotti da "**Nome**",
  // prosa in "Testo:"/"Scena:". M0 (tutorial) ha un pattern diverso: righe "- Dati: cond=... ; reward=..."
  // multiple che condividono lo stesso Testo/Scena finali (slot {oggetto}).

  /* ---------- parser delle CARTE DILEMMA (Batch B, content/carte.md) ----------
   * Formato a righe etichettate, come le schede missione: il contratto completo e' scritto in
   * testa a carte.md. Qui la sola cosa da sapere leggendo il codice e' che una carta ha 2-3
   * opzioni e che ogni opzione puo' avere TRE forme di esito diverse (certa, 50/50, condizionata
   * alla personalita'), non una sola — e' la ragione per cui questo parser esiste invece di
   * riusare quello delle missioni.
   * Tollerante come tutti i parser del progetto: una riga che non riconosce la salta e tira
   * dritto, perche' questo file lo toccheranno anche i soci. */
  function tokenDaLista(s) {
    var v = (s || '').trim();
    if (v === '' || v === '—' || v === '-') return []; // trattino lungo = non succede niente
    var pezzi = v.split(',');
    var out = [];
    for (var i = 0; i < pezzi.length; i++) {
      var p = pezzi[i].trim();
      if (p !== '') out.push(p);
    }
    return out;
  }

  function parseCarte(testo) {
    var out = [];
    if (!testo) return out;
    var righe = testo.split(/\r?\n/);
    var carta = null;
    var opzione = null;

    function chiudiOpzione() {
      if (carta && opzione) carta.opzioni.push(opzione);
      opzione = null;
    }
    function chiudiCarta() {
      chiudiOpzione();
      if (carta) out.push(carta);
      carta = null;
    }

    for (var i = 0; i < righe.length; i++) {
      var t = righe[i].trim();
      if (t === '') continue;

      // ORDINE OBBLIGATORIO: "###" prima di "##", altrimenti il match della carta si mangia anche
      // le opzioni (### comincia con ##) e ogni opzione diventerebbe una carta nuova senza opzioni.
      var mOpz = t.match(/^###\s+([A-Z])\s*·\s*(.+)$/);
      if (mOpz) {
        if (!carta) continue; // opzione orfana: si ignora invece di inventare una carta
        chiudiOpzione();
        opzione = {
          lettera: mOpz[1], testo: mOpz[2].trim(),
          esito: [], esiti5050: [], esitoPersonalita: null, richiedeFlag: null, coda: ''
        };
        continue;
      }

      var mCarta = t.match(/^##\s+(C\d+)\s*·\s*(.+)$/);
      if (mCarta) {
        chiudiCarta();
        carta = {
          id: mCarta[1].toLowerCase(), titolo: mCarta[2].trim(), situazione: '',
          stadio: 'baby', personalita: null, richiedeFlag: null, richiedePerk: null,
          lavoro: null, varianteFlag: null, varianteTitolo: null, opzioni: []
        };
        continue;
      }

      if (t.charAt(0) === '#') continue; // commenti e titolo del file
      if (!carta) continue;

      var mDati = t.match(/^Dati:\s*(.+)$/i);
      if (mDati) {
        var coppie = mDati[1].split(';');
        for (var c = 0; c < coppie.length; c++) {
          var kv = coppie[c].split('=');
          if (kv.length < 2) continue;
          var k = kv[0].trim().toLowerCase();
          var v = kv.slice(1).join('=').trim();
          if (k === 'stadio') carta.stadio = v.toLowerCase();
          else if (k === 'personalita') carta.personalita = v.toLowerCase();
          else if (k === 'richiedeflag') carta.richiedeFlag = v.toLowerCase();
          else if (k === 'richiedeperk') carta.richiedePerk = v.toLowerCase();
          else if (k === 'lavoro') carta.lavoro = v.toLowerCase();
          else if (k === 'varianteflag') carta.varianteFlag = v.toLowerCase();
          else if (k === 'variantetitolo') carta.varianteTitolo = v;
        }
        continue;
      }

      var mSit = t.match(/^Situazione:\s*(.+)$/i);
      if (mSit) { carta.situazione = mSit[1].trim(); continue; }

      if (!opzione) continue;

      // "Esito se personalita=X:" PRIMA di "Esito:", che come prefisso se la mangerebbe.
      var mPers = t.match(/^Esito se personalita\s*=\s*([a-zà-ù]+)\s*:\s*(.+)$/i);
      if (mPers) {
        opzione.esitoPersonalita = { personalita: mPers[1].trim().toLowerCase(), token: tokenDaLista(mPers[2]) };
        continue;
      }
      var m5050 = t.match(/^Esito 50\/50:\s*(.*)$/i);
      if (m5050) { opzione.esiti5050.push(tokenDaLista(m5050[1])); continue; }
      var mEsito = t.match(/^Esito:\s*(.*)$/i);
      if (mEsito) { opzione.esito = tokenDaLista(mEsito[1]); continue; }
      var mCoda = t.match(/^Coda:\s*(.+)$/i);
      if (mCoda) { opzione.coda = mCoda[1].trim(); continue; }
      var mCond = t.match(/^Cond:\s*richiedeFlag\s*=\s*(.+)$/i);
      if (mCond) { opzione.richiedeFlag = mCond[1].trim().toLowerCase(); continue; }
    }
    chiudiCarta();
    return out;
  }

  function parseMissioni(testo) {
    var out = [];
    if (!testo) return out;

    var righe = testo.split(/\r?\n/);

    // individua i blocchi "## Missione ..." (ignora backlog/linee guida fuori da questi blocchi
    // perche' non iniziano con "## Missione"). Le missioni sono separate per stadio da un header
    // di PRIMO livello "# TEEN ..." / "# ADULTO ..." (un solo cancelletto): le schede sotto quel
    // separatore restano in quello stadio finche' non ne arriva un altro (bilanciamento.md
    // "Separazione baby/teen", estesa a P3 con lo stadio adulto). Il default e' 'baby' finche'
    // non si incontra il primo separatore; "# BABY ..." puo' riportare esplicitamente a baby.
    var blocchi = [];
    var corrente = null;
    var stadioCorrente = 'baby';
    for (var i = 0; i < righe.length; i++) {
      var r = righe[i];
      var mTitolo = r.match(/^##\s+Missione\s+(\d+)/i);
      if (mTitolo) {
        if (corrente) blocchi.push(corrente);
        corrente = { numero: parseInt(mTitolo[1], 10), titoloRiga: r.trim(), righe: [], stadio: stadioCorrente };
        continue;
      }
      // separatore di stadio (header di primo livello, un solo '#'): chiude il blocco aperto e
      // cambia lo stadio delle missioni successive. Gestito PRIMA del push generico delle righe
      // cosi' la riga "# TEEN"/"# BABY" non finisce dentro le righe di un blocco.
      if (/^#\s+TEEN\b/i.test(r)) {
        if (corrente) { blocchi.push(corrente); corrente = null; }
        stadioCorrente = 'teen';
        continue;
      }
      if (/^#\s+BABY\b/i.test(r)) {
        if (corrente) { blocchi.push(corrente); corrente = null; }
        stadioCorrente = 'baby';
        continue;
      }
      if (/^#\s+ADULTO\b/i.test(r)) {
        if (corrente) { blocchi.push(corrente); corrente = null; }
        stadioCorrente = 'adulto';
        continue;
      }
      if (r.indexOf('## ') === 0) {
        // altra sezione di secondo livello (backlog, linee guida): chiude il blocco corrente
        if (corrente) { blocchi.push(corrente); corrente = null; }
        continue;
      }
      if (corrente) corrente.righe.push(r);
    }
    if (corrente) blocchi.push(corrente);

    for (var b = 0; b < blocchi.length; b++) {
      try {
        var scheda = parseSchedaMissione(blocchi[b]);
        if (scheda) out.push(scheda);
      } catch (e) {
        console.warn('PETQ.content: errore parsing scheda missione, la salto', e);
      }
    }

    return out;
  }

  function parseSchedaMissione(blocco) {
    var titolo = blocco.titoloRiga.replace(/^##\s+/, '').trim();
    var id = 'm' + blocco.numero;
    var isTutorial = /tutorial/i.test(titolo);
    var fuoriRosa = /fuori rosa/i.test(titolo);

    var scheda = {
      id: id,
      numero: blocco.numero,
      titolo: titolo,
      tutorial: isTutorial,
      fuoriRosa: fuoriRosa || isTutorial,
      // teenIntro: missione speciale "intro all'evoluzione" (M17 Pimp My Pet), fuori rosa, senza
      // durata/esiti normali. La schermata di scelta della modifica permanente (scelta=1, sprite:*,
      // indossabili) e' una feature dedicata RIMANDATA: qui il parser la riconosce solo per non
      // emettere i warning "durata mancante"/"senza esiti". Impostato da applicaDatiScheda (teenIntro=1).
      teenIntro: false,
      scelta: false,
      // ritenta: missione RITENTABILE dopo un fallimento (boss a gate tipo M45 Laurea/M48 Elezioni
      // e le Grandi Imprese P3): il fallimento NON la marca in missioniFatte, quindi resta in rosa
      // finche' non riesce (bilanciamento.md "Missioni — pet adulto"). Standard/super la chiudono
      // normalmente. Impostato dal token "ritenta=1" nella riga Dati (v. applicaDatiScheda).
      ritenta: false,
      // impresa: scheda "Grande Impresa" (P3, categoria=impresa, M65-M72): NON entra ne' nella
      // rotazione per-run ne' nella rosa giornaliera normale (esclusione fatta da missions.js,
      // non qui: il parser si limita a marcarla). Impostato dal token "impresa=1" (bool, come
      // teenIntro) nella riga Dati.
      impresa: false,
      // personalita: SOLO per le schede impresa=1 (le altre restano null) — la personalita' a cui
      // e' agganciata l'Impresa (una delle 4, v. PERSONALITA_VALIDE sotto), estratta 1/2 a testa
      // da missions.impresaDellaRun. Token "personalita=<valore>" nella riga Dati, normalizzato
      // lowercase; un valore non tra le 4 valide viene ignorato con un warning (resta null).
      personalita: null,
      // Stadio (baby/teen/adulto): default dal separatore "# TEEN"/"# BABY"/"# ADULTO" in
      // missioni.md, deciso in parseMissioni ('baby' per le schede prima del primo separatore o
      // se non impostato). Il campo esplicito "stadio=baby|teen|adulto" nella riga Dati (che il
      // fondatore mette nelle schede teen/adulto) PREVALE su questo default: v. applicaDatiScheda,
      // chiamata dopo l'init e che lo sovrascrive.
      stadio: blocco.stadio || 'baby',
      // lavoro: gate missione su carriera del lavoretto/lavoro adulto (Retention 2.0 Batch B,
      // DESIGN-DILEMMI-LAVORI.md SPEC MOTORE §6, es. "lavoro=riderleggendario" su M99): null =
      // nessun gate, la missione entra in rosa per chiunque (comportamento di sempre). Il
      // filtro vero e proprio vive in missions.js rosaDelGiorno (funzione generica riusabile
      // per un futuro "leggenda="), qui si legge solo il valore dalla scheda.
      lavoro: null,
      luogo: '',
      razza: 'entrambe',
      categoria: null,
      stat: [],
      tag: [],
      durata: null,
      durataMs: 0,
      costo: 0,
      brief: null, // riga "Brief:" scheda-livello (dossier missione), v. sotto
      esiti: []
    };

    // 1) riga Dati: scheda-livello: la prima riga "Dati:" (con o senza "- ") che contiene
    // durata=/costo=/categoria=/stat=/tutorial= e NON contiene "cond=" (quella e' gia' un esito)
    var righe = blocco.righe;
    var idxDatiScheda = -1;
    for (var i = 0; i < righe.length; i++) {
      var r = righe[i].trim();
      var isDati = /^-?\s*Dati:/i.test(r);
      if (isDati && !/cond\s*=/.test(r)) {
        var contenuto = r.replace(/^-?\s*Dati:/i, '');
        applicaDatiScheda(scheda, contenuto);
        idxDatiScheda = i;
        break;
      }
    }

    if (!scheda.tutorial && !scheda.teenIntro && (!scheda.durata || !(scheda.durataMs > 0))) {
      console.warn('PETQ.content: durata mancante o non valida per ' + scheda.id + ', uso default 1h');
      scheda.durata = scheda.durata || '1h';
      scheda.durataMs = 3600000;
    }

    // 2) metadati prosa (fallback se la riga Dati non copre tutto, es. luogo/razza)
    for (var j = 0; j < righe.length; j++) {
      var rr = righe[j].trim();
      var mLuogo = rr.match(/^-\s*Luogo:\s*(.+)$/i);
      if (mLuogo) { scheda.luogo = mLuogo[1].trim(); continue; }
      var mRazza = rr.match(/^-\s*Razza:\s*(.+)$/i);
      if (mRazza) { scheda.razza = mRazza[1].trim().toLowerCase(); continue; }
      var mCat = rr.match(/^-\s*Categoria:\s*(.+)$/i);
      if (mCat && !scheda.categoria) { scheda.categoria = mCat[1].trim().toLowerCase(); continue; }
    }

    // 3) esiti: due pattern possibili.
    // Pattern A (M0/tutorial): righe multiple "- Dati: cond=... ; reward=..." che condividono
    // Brief: riga scheda-livello (dossier missione, richiesta fondatore 17 lug 2026 "le missioni
    // sono poco descrittive"): 1-2 frasi che raccontano l'EVENTO senza spoiler di condizioni
    // segrete. Prima occorrenza vince; virgolette avvolgenti opzionali strippate come per Testo.
    for (var iBrief = 0; iBrief < righe.length; iBrief++) {
      var mBrief = righe[iBrief].trim().match(/^-?\s*Brief\s*:\s*(.+)$/i);
      if (mBrief) {
        scheda.brief = mBrief[1].trim().replace(/^"(.*)"$/, '$1');
        break;
      }
    }

    // un unico "- Testo:"/"- Scena:" successivo (con slot tipo {oggetto}).
    // Pattern B (standard): blocchi "**Nome esito** (...) — ..." poi "Dati: ..." poi "Testo:" poi "Scena:".
    if (scheda.tutorial) {
      parseEsitiTutorial(scheda, righe);
    } else {
      parseEsitiStandard(scheda, righe);
    }

    if (!scheda.tutorial && !scheda.teenIntro && scheda.esiti.length === 0) {
      console.warn('PETQ.content: scheda ' + id + ' senza esiti riconosciuti');
    }

    // Riga "**Standard**" dimenticata copiando una scheda (refuso, non un caso di design): il
    // motore (missions._scegliEsito) non ha nessuna via di ripiego quando ne' un fallimento ne'
    // un super scattano, e il giocatore nella media vede a schermo "Impossibile calcolare
    // l'esito della missione." senza che nessuno l'abbia mai saputo al caricamento. tutorial/
    // teenIntro escluse: il tutorial (M0) non usa il tipo 'standard' (pattern a parte, un esito
    // per personalita'), e teenIntro (M17) non ha proprio esiti in questo DSL (schermata
    // dedicata fuori dal motore) — sono i default voluti, non malformazioni.
    if (!scheda.tutorial && !scheda.teenIntro) {
      var haEsitoStandard = false;
      for (var iStd = 0; iStd < scheda.esiti.length; iStd++) {
        if (scheda.esiti[iStd].tipo === 'standard') { haEsitoStandard = true; break; }
      }
      if (!haEsitoStandard) {
        console.warn('PETQ.content: scheda ' + id + ' (missione ' + scheda.numero + ') senza nessun esito "Standard": un pet ne troppo debole ne troppo forte per fallimento/super non trovera\' nessun esito valido ("Impossibile calcolare l\'esito della missione.")');
      }
    }

    return scheda;
  }

  function applicaDatiScheda(scheda, contenuto) {
    var campi = splitToken(contenuto, ';');
    for (var i = 0; i < campi.length; i++) {
      var kv = campi[i].split('=');
      if (kv.length < 2) continue;
      var chiave = kv[0].trim().toLowerCase();
      var valore = kv.slice(1).join('=').trim();
      if (chiave === 'durata') { scheda.durata = valore; scheda.durataMs = parseDurata(valore); }
      else if (chiave === 'costo') scheda.costo = primoNumero(valore);
      else if (chiave === 'categoria') scheda.categoria = valore.toLowerCase();
      else if (chiave === 'stat') scheda.stat = valore.toLowerCase().split(',').map(function (s) { var v = s.trim(); return normalizzaStatNome(v) || v; }).filter(Boolean);
      else if (chiave === 'tag') scheda.tag = valore.toLowerCase().split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      else if (chiave === 'tutorial') scheda.tutorial = valore === '1' || valore.toLowerCase() === 'true';
      else if (chiave === 'teenintro') { scheda.teenIntro = valore === '1' || valore.toLowerCase() === 'true'; if (scheda.teenIntro) scheda.fuoriRosa = true; }
      else if (chiave === 'scelta') scheda.scelta = valore === '1' || valore.toLowerCase() === 'true';
      // Stadio esplicito dal campo Dati (il fondatore lo mette nelle schede teen/adulto): PREVALE
      // sull'header "# TEEN"/"# BABY"/"# ADULTO". applicaDatiScheda gira DOPO l'init di
      // scheda.stadio (= blocco.stadio || 'baby', dall'header) quindi qui lo SOVRASCRIVE. Solo
      // valori validi 'baby'/'teen'/'adulto' vincono; qualsiasi altro valore viene ignorato
      // (resta quello dell'header).
      else if (chiave === 'stadio') { var st = valore.toLowerCase(); if (st === 'baby' || st === 'teen' || st === 'adulto') scheda.stadio = st; }
      // lavoro=<carriera>: normalizzato minuscolo/senza spazi come le chiavi-carriera del design
      // (es. "riderleggendario"), cosi' combacia col valore che scrivera' il modulo lavoro
      // (letto difensivamente da missions.js come state.lavoro.carriera, gia' nello stesso formato).
      else if (chiave === 'lavoro') { scheda.lavoro = valore.trim().toLowerCase().replace(/\s+/g, ''); }
      // ritenta=1: il fallimento non consuma la missione (resta in rosa, v. init di scheda.ritenta)
      else if (chiave === 'ritenta') { scheda.ritenta = valore === '1' || valore.toLowerCase() === 'true'; }
      // impresa=1: Grande Impresa (P3), bool come teenintro (v. init di scheda.impresa sopra).
      else if (chiave === 'impresa') { scheda.impresa = valore === '1' || valore.toLowerCase() === 'true'; }
      // personalita=<gentile|maleducato|nerd|sportivo>: solo sulle schede impresa=1 (v. init).
      // Normalizzata lowercase; valore non tra le 4 valide -> warning, ignorato (resta null).
      else if (chiave === 'personalita') {
        var persNorm = valore.trim().toLowerCase();
        if (PERSONALITA_VALIDE.indexOf(persNorm) !== -1) {
          scheda.personalita = persNorm;
        } else {
          console.warn('PETQ.content: personalita non valida "' + valore + '" in ' + scheda.id + ', ignorata');
        }
      }
    }
  }

  function parseDurata(valore) {
    var m = valore.match(/([\d.,]+)\s*h/i);
    if (m) return parseFloat(m[1].replace(',', '.')) * 3600000;
    var n = primoNumero(valore);
    return n ? n * 3600000 : 0;
  }

  function splitToken(testo, sep) {
    if (!testo) return [];
    var parti = testo.split(sep);
    var out = [];
    for (var i = 0; i < parti.length; i++) {
      var t = parti[i].trim();
      if (t !== '') out.push(t);
    }
    return out;
  }

  // Pattern tutorial (M0): 4 righe "- Dati: cond=X ; reward=Y" (una per personalita), poi una riga
  // condivisa "- Testo (slot {oggetto}): ..." e "- Scena: ...". Per M0 l'esito e' sempre tipo
  // 'tutorial' e la "chiave" e' la personalita stessa (fonte di verita' per lo smistamento in gioco).
  function parseEsitiTutorial(scheda, righe) {
    var testoCondiviso = '';
    var scenaCondivisa = '';
    var righeDati = [];

    for (var i = 0; i < righe.length; i++) {
      var r = righe[i].trim();
      var mDati = r.match(/^-?\s*Dati:\s*cond=(.*)$/i);
      if (mDati) { righeDati.push(r.replace(/^-?\s*Dati:/i, '')); continue; }
      var mTesto = r.match(/^-?\s*Testo[^:]*:\s*(.+)$/i);
      if (mTesto) { testoCondiviso = ripulisciTesto(mTesto[1]); continue; }
      var mScena = r.match(/^-?\s*Scena:\s*(.+)$/i);
      if (mScena) { scenaCondivisa = mScena[1].trim(); continue; }
    }

    // Riga "- Testo (slot {oggetto}): ..." dimenticata: testoCondiviso resta '' e TUTTI e 4 gli
    // esiti (uno per personalita') uscirebbero con la cartolina muta, senza nessun avviso al
    // caricamento. A differenza di teenIntro/tutorial-senza-esiti (dove il testo vuoto e' il
    // default legittimo, v. sopra), qui gli esiti CI SONO (righeDati non vuoto): un testo vuoto
    // non e' mai voluto per il regalo di benvenuto del tutorial.
    if (righeDati.length > 0 && testoCondiviso === '') {
      console.warn('PETQ.content: riga "Testo:" mancante nella scheda tutorial ' + scheda.id + ' (i 4 esiti condivideranno un testo vuoto)');
    }

    for (var j = 0; j < righeDati.length; j++) {
      var campi = splitToken(righeDati[j], ';');
      var esito = {
        tipo: 'tutorial',
        chiave: null,
        personalita: null,
        cond: null,
        priorita: null,
        reward: [],
        testo: testoCondiviso,
        scena: scenaCondivisa,
        scenaId: scenaIdDa(scheda, 'tutorial', scenaCondivisa)
      };
      for (var k = 0; k < campi.length; k++) {
        var kv = campi[k].split('=');
        if (kv.length < 2) continue;
        var chiave = kv[0].trim().toLowerCase();
        var valore = kv.slice(1).join('=').trim();
        if (chiave === 'cond') {
          esito.cond = parseCondizione(valore);
          esito.personalita = valore.trim().toLowerCase();
          esito.chiave = esito.personalita;
        } else if (chiave === 'reward') {
          esito.reward = splitToken(valore, ',');
        }
      }
      if (!esito.chiave) {
        console.warn('PETQ.content: esito tutorial senza personalita riconosciuta in ' + scheda.id);
        esito.chiave = 'tutorial_' + j;
      }
      scheda.esiti.push(esito);
    }
  }

  // Pattern standard: blocchi "**Titolo esito** (...) — sintesi" seguiti da riga "Dati:",
  // poi "Testo:" poi "Scena:". Tipo derivato dal titolo (standard/fallimento/super),
  // chiave usata per ordine di apparizione (fallimenti) e nome (M7 super con priorita).
  function parseEsitiStandard(scheda, righe) {
    var blocchi = [];
    var corrente = null;
    for (var i = 0; i < righe.length; i++) {
      var r = righe[i];
      var mTitolo = r.match(/^\*\*(.+?)\*\*/);
      if (mTitolo) {
        if (corrente) blocchi.push(corrente);
        corrente = { titolo: mTitolo[1].trim(), righe: [] };
        continue;
      }
      if (corrente) corrente.righe.push(r);
    }
    if (corrente) blocchi.push(corrente);

    for (var b = 0; b < blocchi.length; b++) {
      var blocco = blocchi[b];
      var titolo = blocco.titolo;
      var tLower = titolo.toLowerCase();
      var tipo = 'standard';
      if (tLower.indexOf('fallim') !== -1) tipo = 'fallimento';
      // "Super successo" e "Grande successo" sono lo STESSO tier super (decisione fondatore 6 lug
      // 2026): il "grande successo" e' solo un super con priorita' piu' alta e condizione piu'
      // specifica (es. M18: grande=p1 Maleducato+Boss, super=p2 generico), stessa meccanica dei
      // multi-super di M7 (Amicizia/Dominio/Intimidazione). Entrambi -> tipo 'super'.
      else if (tLower.indexOf('super') !== -1 || tLower.indexOf('grande success') !== -1) tipo = 'super';

      var esito = {
        tipo: tipo,
        chiave: slugEsito(titolo, tipo),
        cond: null,
        priorita: null,
        reward: [],
        testo: '',
        scena: '',
        scenaId: null
      };

      var trovataRigaDati = false;
      var scenaProsa = '';
      for (var i = 0; i < blocco.righe.length; i++) {
        var r = blocco.righe[i].trim();
        if (r === '') continue;

        var mDati = r.match(/^Dati:\s*(.+)$/i);
        if (mDati) {
          trovataRigaDati = true;
          var campi = splitToken(mDati[1], ';');
          for (var k = 0; k < campi.length; k++) {
            var kv = campi[k].split('=');
            if (kv.length < 2) continue;
            var chiave = kv[0].trim().toLowerCase();
            var valore = kv.slice(1).join('=').trim();
            if (chiave === 'cond') esito.cond = parseCondizione(valore);
            else if (chiave === 'reward') esito.reward = splitToken(valore, ',');
            else if (chiave === 'priorita') esito.priorita = primoNumero(valore);
          }
          continue;
        }

        var mTesto = r.match(/^Testo:\s*(.+)$/i);
        if (mTesto) { esito.testo = ripulisciTesto(mTesto[1]); continue; }

        var mScena = r.match(/^Scena:\s*(.+)$/i);
        if (mScena) { scenaProsa = mScena[1].trim(); esito.scena = scenaProsa; continue; }
      }

      if (!trovataRigaDati) {
        console.warn('PETQ.content: manca riga Dati per esito "' + titolo + '" in ' + scheda.id);
        esito.cond = null;
        esito.reward = [];
      }

      // Riga "Testo:" dimenticata nel blocco esito: oggi produceva testo:'' in silenzio (il
      // giocatore vede la cartolina muta). Nessun caso di design con testo vuoto legittimo per
      // questo pattern (standard/fallimento/super hanno sempre prosa): sempre un refuso, sempre
      // un warning al caricamento.
      if (esito.testo === '') {
        console.warn('PETQ.content: manca riga "Testo:" per l\'esito "' + titolo + '" in ' + scheda.id + ' (il giocatore vedra\' una cartolina senza testo)');
      }

      esito.scenaId = scenaIdDa(scheda, tipo, scenaProsa, titolo);

      if (tipo === 'super' && esito.priorita === null) {
        // priorita assente sulle schede con un solo super: non serve per la risoluzione,
        // ma normalizziamo a 99 (bassa precedenza) per rendere l'ordinamento deterministico
        esito.priorita = 99;
      }

      scheda.esiti.push(esito);
    }
  }

  // Slug stabile per l'esito dentro la scheda (contratto SPEC-MODULO-MISSIONI.md): usa il
  // testo tra parentesi/dopo trattino quando presente per distinguere A/B o
  // Dominio/Intimidazione/Amicizia (es. "Fallimento A" -> 'a', "Super successo — Dominio" ->
  // 'dominio'), altrimenti il tipo stesso quando e' unico nella scheda ("Standard" -> 'standard').
  function slugEsito(titolo, tipo) {
    var resto = titolo
      .replace(/^standard$/i, '')
      .replace(/fallim\w*/i, '')
      .replace(/super\s*success\w*/i, '')
      .trim();
    resto = resto.replace(/^[—\-–:\s]+/, '').trim();
    if (resto === '') return tipo;
    var slug = resto.toLowerCase()
      .replace(/[^a-z0-9àèéìòù\s]/gi, '')
      .trim()
      .replace(/\s+/g, '_');
    return slug || tipo;
  }

  function ripulisciTesto(t) {
    var s = (t || '').trim();
    s = s.replace(/^"(.*)"$/, '$1');
    return s;
  }

  // id scena secondo convenzione spec: std_<categoria>, fail_generica, super_m1..m8,
  // super_m7_dominio|intimidazione|amicizia. Il tutorial (m0) non e' nella lista dei 10
  // dedicati della spec: riusa comunque lo schema super_m<N> (qui super_m0), un solo id
  // condiviso dai 4 esiti per personalita' (stesso spirito "regalo di benvenuto").
  function scenaIdDa(scheda, tipo, scenaProsa, titoloEsito) {
    if (tipo === 'tutorial') return 'super_m' + scheda.numero;
    // Fallimento: scena dedicata per-missione SE esiste (fail_m<N> in sprites.js — richiesta
    // fondatore 12 ago 2026 per m18: "cartolina dettagliata e pertinente al racconto del
    // fallimento"). drawCartolina ripiega da solo su fail_generica per gli id che non esistono,
    // quindi le missioni senza arte dedicata si comportano ESATTAMENTE come prima.
    if (tipo === 'fallimento') return 'fail_m' + scheda.numero;
    // Standard: le missioni baby (M1-M8) tengono la scena per-CATEGORIA (fondali gia' fatti,
    // approvati dal fondatore). Le teen/nuove (M9+) hanno una scena PER-MISSIONE su misura
    // (std_m<N>, disegnata dalla loro descrizione — regola fondatore "ogni quest la sua scena,
    // niente riciclo"). Il super resta super_m<N> (per M9+ = scena std_m<N> + trofeo, v. sprites.js).
    if (tipo === 'standard') {
      return (scheda.numero >= 9) ? ('std_m' + scheda.numero) : ('std_' + (scheda.categoria || 'generica'));
    }
    // super
    if (scheda.numero === 7 && titoloEsito) {
      var tl = titoloEsito.toLowerCase();
      if (tl.indexOf('dominio') !== -1) return 'super_m7_dominio';
      if (tl.indexOf('intimidazione') !== -1) return 'super_m7_intimidazione';
      if (tl.indexOf('amicizia') !== -1) return 'super_m7_amicizia';
    }
    return 'super_m' + scheda.numero;
  }

  // ---------- parser espressioni condizione ----------
  // Grammatica: espr = and ('|' and)* ; and = termine ('&' termine)*
  // termine = '(' espr ')' | personalita (gentile|maleducato|nerd|sportivo)
  //         | talento:<nome> | confronto stat (forza>=3, velocita<=0, ecc.)
  // Le parentesi raggruppano (& lega piu' stretto di | ; le parentesi scavalcano la precedenza).
  // Ritorna un albero {op:'|'|'&', figli:[...]} o {op:'personalita', valore} o
  //   {op:'talento', valore} o {op:'cmp', stat, cmp, val}
  // valutabile con valutaCondizione(albero, ctx) dove ctx = {personalita, stat:{forza,...}, talenti:[...]}

  var PERSONALITA_VALIDE = ['gentile', 'maleducato', 'nerd', 'sportivo'];

  function parseCondizione(espr) {
    if (!espr || espr.trim() === '') return null;
    try {
      var pezziOr = splitTopLevel(espr, '|');
      var nodiOr = [];
      for (var i = 0; i < pezziOr.length; i++) {
        var pezziAnd = splitTopLevel(pezziOr[i], '&');
        var nodiAnd = [];
        for (var j = 0; j < pezziAnd.length; j++) {
          var termine = parseTermine(pezziAnd[j]);
          if (termine) nodiAnd.push(termine);
        }
        if (nodiAnd.length === 0) continue;
        nodiOr.push(nodiAnd.length === 1 ? nodiAnd[0] : { op: '&', figli: nodiAnd });
      }
      if (nodiOr.length === 0) {
        // ATTENZIONE alla trappola (non confondere coi due return null sopra/sotto): qui la
        // STRINGA condizione ERA presente (l'abbiamo gia' superato il check "espr vuota" in
        // testa alla funzione) ma NESSUN termine e' sopravvissuto al parsing — tutti malformati
        // (virgola al posto di &, "=>"/"=<" invertiti, "perk:"/"flag:" con spazio nel nome,
        // simboli unicode >=/−, ecc: parseTermine li ha gia' scartati uno per uno con un warning
        // ciascuno qui sopra). SE tornassimo null qui, per missions._valutaCond/valutaCondizione
        // null significa "nessuna condizione" = esito SEMPRE VERO — un esito 'super' con la
        // condizione rovinata scatterebbe per QUALSIASI pet, in silenzio (il bug piu' grave
        // dell'audit). Sentinella {op:'mai'}: valutaCondizione/_valutaCond la trattano come
        // SEMPRE FALSA, mai un premio regalato per un refuso. NON tocca il caso "condizione
        // assente del tutto" (espr vuota/undefined): quello resta il return null di riga sopra,
        // il default voluto del motore per gli esiti standard senza cond.
        console.warn('PETQ.content: condizione interamente malformata (nessun termine valido riconosciuto), forzata a "mai vera": "' + espr + '"');
        return { op: 'mai' };
      }
      return nodiOr.length === 1 ? nodiOr[0] : { op: '|', figli: nodiOr };
    } catch (e) {
      console.warn('PETQ.content: espressione condizione non valida: "' + espr + '"', e);
      return null;
    }
  }

  // split su un separatore (singolo carattere '|' o '&') SOLO a profondita' di parentesi 0.
  // Scorre i caratteri tenendo un contatore depth (+1 su '(', -1 su ')', mai sotto 0);
  // trimma ogni pezzo e scarta i vuoti — cosi' senza parentesi il risultato e' identico a
  // splitToken (comportamento retro-compatibile per le missioni M1..M13). sep e' un char.
  function splitTopLevel(testo, sep) {
    if (!testo) return [];
    var out = [];
    var depth = 0;
    var corrente = '';
    for (var i = 0; i < testo.length; i++) {
      var c = testo.charAt(i);
      if (c === '(') {
        depth++;
        corrente += c;
      } else if (c === ')') {
        if (depth > 0) depth--;
        corrente += c;
      } else if (c === sep && depth === 0) {
        var t = corrente.trim();
        if (t !== '') out.push(t);
        corrente = '';
      } else {
        corrente += c;
      }
    }
    var ultimo = corrente.trim();
    if (ultimo !== '') out.push(ultimo);
    return out;
  }

  function parseTermine(t) {
    var s = (t || '').trim().toLowerCase();
    if (s === '') return null;

    // Parentesi di raggruppamento: se l'intero termine e' un gruppo "(...)", estrai il
    // contenuto interno e ricicla il parser completo (RICORSIONE: dentro le parentesi
    // valgono di nuovo | & altre parentesi e tutti i tipi di termine). Dato che
    // splitTopLevel ora rispetta le parentesi, qui un termine e' atomico oppure un solo
    // gruppo — ma restiamo difensivi sul bilanciamento.
    if (s.charAt(0) === '(') {
      var depth = 0;
      var chiusura = -1;
      for (var k = 0; k < s.length; k++) {
        var ch = s.charAt(k);
        if (ch === '(') depth++;
        else if (ch === ')') {
          depth--;
          if (depth === 0) { chiusura = k; break; }
        }
      }
      if (chiusura === s.length - 1) {
        // la parentesi aperta iniziale si bilancia esattamente all'ultimo carattere:
        // l'intero termine e' un gruppo -> parsa il contenuto interno.
        return parseCondizione(s.substring(1, chiusura));
      }
      // parentesi non bilanciate o che non avvolgono tutto il termine: degrada a warning.
      console.warn('PETQ.content: parentesi non bilanciate nel termine condizione: "' + t + '"');
      return null;
    }

    if (PERSONALITA_VALIDE.indexOf(s) !== -1) {
      return { op: 'personalita', valore: s };
    }

    // Termine talento: vero se il pet possiede il talento con quel nome (case-insensitive;
    // s e' gia' lowercase). Es. "talento:inventore", "talento: energico".
    var mTal = s.match(/^talento\s*:\s*(.+)$/);
    if (mTal) {
      // Nome talento normalizzato SENZA spazi (e gia' lowercase): cosi' "talento:bossdiquartiere"
      // combacia col talento reale "Boss di Quartiere" a prescindere da come il fondatore scrive gli
      // spazi nel riferimento. La stessa normalizzazione (strip spazi + lowercase) e' applicata ai
      // nomi dei talenti del pet in missions._valutaCond (ctx.talenti), cosi' i due lati coincidono.
      var nomeTal = mTal[1].trim().replace(/\s+/g, '');
      if (nomeTal !== '') return { op: 'talento', valore: nomeTal };
      console.warn('PETQ.content: termine talento senza nome: "' + t + '"');
      return null;
    }

    // Termine statMax/statMin: confronto sulla stat RPG piu' ALTA (max) o piu' BASSA (min) del
    // pet. Es. "statMax>=10" = almeno una stat a 10+; "statMax<8" = nessuna stat arriva a 8.
    // Usato dalle missioni boss teen (M18/M20). Va PRIMA della regex stat generica sotto (che
    // altrimenti catturerebbe 'statmax' come nome-stat e fallirebbe la normalizzazione → warning).
    var mAgg = s.match(/^stat(max|min)\s*(>=|<=|>|<|==)\s*(-?\d+)$/);
    if (mAgg) {
      return { op: 'statagg', agg: mAgg[1], cmp: mAgg[2], val: parseInt(mAgg[3], 10) };
    }

    // Termine perk: vero se il pet possiede la MEDAGLIETTA (state.perks, v. missions.js
    // _valutaCond -> ctx.perks). Aggiunto per l'audit 17 lug 2026: la prosa di M53 prometteva
    // la via "perk Weapon Wielder con arma equipaggiata" ma il DSL non sapeva esprimerla.
    var mPerk = s.match(/^perk\s*:\s*([a-z0-9]+)$/);
    if (mPerk) {
      return { op: 'perk', valore: mPerk[1] };
    }

    // Termine flag: vero se il pet ha quel flag piantato (state.flags, v. missions.js
    // _valutaCond -> ctx.flags). Stesso schema di perk: sopra (presenza in un array di stringa).
    // Nomi flag usano minuscolo e underscore (es. "flag:coinquilino", "flag:socio_del_piccione"),
    // coerenti col REGISTRO FLAG di DESIGN-DILEMMI-LAVORI.md; s e' gia' lowercase qui sopra.
    // ATTENZIONE (verifica esplicita del fondatore): NON e' 'scelta:', che e' un token A PARTE
    // usato solo dentro le righe Dati di M17 (scelta-stat "Pimp My Pet", gestita da una
    // schermata dedicata fuori da questo DSL) — riusare quel nome romperebbe M17. I due
    // restano token distinti: 'flag:' qui, 'scelta:' altrove.
    var mFlagCond = s.match(/^flag\s*:\s*([a-z0-9_]+)$/);
    if (mFlagCond) {
      return { op: 'flag', valore: mFlagCond[1] };
    }

    // Termine arma (nudo): vero se il pet ha un'arma EQUIPAGGIATA (state.armaEquip ->
    // ctx.armaEquip). Si combina tipicamente con perk:weaponwielder (M53).
    if (s === 'arma') {
      return { op: 'arma' };
    }

    // Benessere: fel<num (alias felicita/felicità) — confronto sulla Felicita' del pet
    // (pet.stats, stat di BENESSERE, non RPG). DEVE stare PRIMA della regex stat generica
    // (che altrimenti proverebbe a normalizzare 'fel' come stat RPG). Aggiunto per M60
    // ("Furia Cieca con Felicita' <30", audit 17 lug 2026).
    var mFel = s.match(/^(fel|felicita|felicità)\s*(>=|<=|>|<|==)\s*(-?\d+)$/);
    if (mFel) {
      return { op: 'benessere', stat: 'felicita', cmp: mFel[2], val: parseInt(mFel[3], 10) };
    }

    var m = s.match(/^([a-zà-ù]+)\s*(>=|<=|>|<|==)\s*(-?\d+)$/);
    if (m) {
      var nomeStat = normalizzaStatNome(m[1]);
      if (nomeStat) return { op: 'cmp', stat: nomeStat, cmp: m[2], val: parseInt(m[3], 10) };
    }

    console.warn('PETQ.content: termine condizione non riconosciuto: "' + t + '"');
    return null;
  }

  // ---------- parser bilanciamento ----------
  // Cerca per substring dell'etichetta nelle righe di tabella del file; regole dedicate per campo.

  function parseBilanciamento(testo) {
    if (!testo) return null;

    var righe = testo.split(/\r?\n/);
    var righeTabella = [];
    for (var i = 0; i < righe.length; i++) {
      var r = righe[i].trim();
      if (r.indexOf('|') !== -1) righeTabella.push(r);
    }
    if (righeTabella.length === 0) return null;

    function trovaRiga(substr) {
      var s = substr.toLowerCase();
      for (var i = 0; i < righeTabella.length; i++) {
        if (righeTabella[i].toLowerCase().indexOf(s) !== -1) return righeTabella[i];
      }
      return null;
    }

    // Cerca per ETICHETTA ESATTA (prima cella della riga), non per sottostringa.
    // Serve quando un'etichetta e' PREFISSO di un'altra: 'Effetto' (allenamento) e 'Effetto sulle
    // statistiche' (evoluzione) convivono nel file, e trovaRiga('effetto') restituiva la seconda
    // perche' compare prima — quindi l'effetto dell'allenamento veniva letto dal "+1 RPG" di un
    // TODO sull'evoluzione. Coincideva col valore giusto, quindi il bug e' rimasto invisibile
    // finche' il valore non e' cambiato (retention 2.0: allenamento +2).
    function trovaRigaEsatta(etichetta) {
      var atteso = etichetta.toLowerCase();
      for (var i = 0; i < righeTabella.length; i++) {
        var celle = righeTabella[i].split('|');
        // celle[0] e' vuota (la riga comincia con '|'), l'etichetta e' celle[1]
        var prima = (celle.length > 1 ? celle[1] : '').trim().toLowerCase();
        // via il grassetto markdown, che nel file compare su alcune etichette
        prima = prima.replace(/\*/g, '').trim();
        if (prima === atteso) return righeTabella[i];
      }
      return null;
    }

    function numeroDaEtichetta(substr, indiceNumero) {
      var r = trovaRiga(substr);
      if (!r) return null;
      var nums = tuttiINumeri(r);
      if (nums.length === 0) return null;
      var idx = (typeof indiceNumero === 'number') ? indiceNumero : 0;
      if (idx < 0) idx = nums.length + idx;
      return (idx >= 0 && idx < nums.length) ? nums[idx] : null;
    }

    var out = clona(DEFAULT_BILANCIAMENTO);
    var trovatoAlmenoUno = false;

    // terzo elemento = indice del numero da prendere nella riga (0=primo, -1=ultimo);
    // serve perche' alcune etichette/spiegazioni contengono numeri "di contorno"
    // prima della soglia vera (es. "ultimi 2 giorni < 30" -> serve l'ultimo, 30)
    var mappa = [
      ['fame', ['decadimento', 'fame'], 0],
      ['igiene', ['decadimento', 'igiene'], 0],
      ['felicità', ['decadimento', 'felicita'], 0],
      ['stat "critica"', ['soglie', 'critica'], 0],
      ['variante magra', ['soglie', 'magro'], -1],
      ['overlay sporco', ['soglie', 'sporco'], -1],
      ['malus missione da salute', ['soglie', 'malusSalute'], 0],
      ['soglia sovralimentazione', ['soglie', 'sovralimentazione'], 0],
      ['login giornaliero', ['economia', 'login'], 0],
      ['monete iniziali', ['economia', 'monetePartenza'], 0],
      ['sessioni al giorno', ['allenamento', 'sessioni'], 0],
      ['decadimento energia', ['energia_sonno', 'decadimento'], -1],
      ['costo missione', ['energia_sonno', 'costoMissionePerOra'], 0],
      ['costo allenamento', ['energia_sonno', 'costoAllenamento'], -1],
      ['soglia rifiuto', ['energia_sonno', 'sogliaRifiuto'], -1],
      ['ora del letto', ['energia_sonno', 'oraLetto'], -1],
      ['ora del crollo automatico', ['energia_sonno', 'oraCrollo'], -1],
      ['riposino (prima delle 21) — durata max', ['energia_sonno', 'riposinoDurataMax'], -1],
      ['riposino — durata minima', ['energia_sonno', 'riposinoDurataMin'], -1],
      ['recupero riposino', ['energia_sonno', 'riposinoRecuperoOra'], 0],
      ['sonno notturno (dalle 21) — durata max', ['energia_sonno', 'sveglioAutonomoOre'], -1],
      ['sonno notturno — durata minima', ['energia_sonno', 'sonnoMinimoOre'], -1],
      ['energia al risveglio notturno (≥5h', ['energia_sonno', 'risveglioBuono'], -1],
      ['energia al risveglio notturno (crollato', ['energia_sonno', 'risveglioCattivo'], -1],
      ['energia al risveglio (crollato/dormito male)', ['energia_sonno', 'risveglioCattivo'], -1]
    ];

    for (var i = 0; i < mappa.length; i++) {
      var val = numeroDaEtichetta(mappa[i][0], mappa[i][2]);
      if (val !== null) {
        out[mappa[i][1][0]][mappa[i][1][1]] = val;
        trovatoAlmenoUno = true;
      }
    }

    // riga "Effetto | +2 alla stat scelta, +5 Felicità": primo numero = effetto, secondo = felicita
    // bonus. Etichetta ESATTA (v. trovaRigaEsatta sopra): con la ricerca per sottostringa pescava
    // "Effetto sulle statistiche" dell'evoluzione, che compare prima nel file.
    var rigaEffetto = trovaRigaEsatta('effetto');
    if (rigaEffetto) {
      var numsEffetto = tuttiINumeri(rigaEffetto);
      if (numsEffetto.length >= 1) { out.allenamento.effetto = numsEffetto[0]; trovatoAlmenoUno = true; }
      if (numsEffetto.length >= 2) { out.allenamento.felicita = numsEffetto[1]; }
    }

    // riga "Benessere | tutte a 70": primo numero = benessere iniziale
    var valBenessere = numeroDaEtichetta('benessere', 0);
    if (valBenessere !== null) { out.iniziali.benessere = valBenessere; trovatoAlmenoUno = true; }

    // riga "RPG | budget di 3 punti base ... poi +1 alla stat firma"
    // FORMATO CONTRATTUALE (GDD "Alla nascita", playtest v2): la riga contiene "punti base";
    // il PRIMO numero della riga = budget totale da distribuire a caso (impilabile),
    // l'ULTIMO numero = bonus alla stat firma. Totale iniziale = budget + firma.
    var rigaRpg = trovaRiga('punti base');
    if (rigaRpg) {
      var numsRpg = tuttiINumeri(rigaRpg);
      if (numsRpg.length >= 1) { out.iniziali.budget = numsRpg[0]; trovatoAlmenoUno = true; }
      if (numsRpg.length >= 2) { out.iniziali.firma = numsRpg[numsRpg.length - 1]; }
    }

    // riga "Tetto stat per stadio (baby / teen / adulto) | 12 / 30 / 70": 3 numeri in ordine.
    // Etichetta ESATTA (trovaRigaEsatta, v. sopra) e non per sottostringa: il file ha GIA' righe
    // con prima cella "Baby"/"Teen"/"Adulto" per conto proprio (Ciclo vitale, Variante ciccione)
    // — una ricerca per sottostringa o anche un match esatto su solo "baby" beccherebbe QUELLA
    // riga, non questa. L'etichetta della riga del tetto e' un'unica stringa a se', niente
    // ambiguita' possibile.
    var rigaTetto = trovaRigaEsatta('tetto stat per stadio (baby / teen / adulto)');
    if (rigaTetto) {
      var numsTetto = tuttiINumeri(rigaTetto);
      if (numsTetto.length >= 3) {
        out.tettoStat = { baby: numsTetto[0], teen: numsTetto[1], adulto: numsTetto[2] };
        trovatoAlmenoUno = true;
      }
    }

    return trovatoAlmenoUno ? out : null;
  }

  function clona(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  // ---------- valutazione condizioni (condivisa con PETQ.missions) ----------
  // ctx = { personalita: 'gentile', stat: {forza:n, intelligenza:n, velocita:n, carisma:n},
  //         talenti: ['energico', 'inventore', ...] (nomi-talento del pet in lowercase) }
  function valutaCondizione(nodo, ctx) {
    if (!nodo) return false;
    // Sentinella di parseCondizione (condizione scritta ma interamente malformata, v. sopra):
    // SEMPRE falsa. Esplicito apposta invece di lasciarlo cadere nel default 'return false'
    // finale: un domani un nuovo 'op' aggiunto sopra il default potrebbe cambiargli
    // comportamento senza che nessuno se ne accorga.
    if (nodo.op === 'mai') return false;
    if (nodo.op === '|') {
      for (var i = 0; i < nodo.figli.length; i++) {
        if (valutaCondizione(nodo.figli[i], ctx)) return true;
      }
      return false;
    }
    if (nodo.op === '&') {
      for (var j = 0; j < nodo.figli.length; j++) {
        if (!valutaCondizione(nodo.figli[j], ctx)) return false;
      }
      return true;
    }
    if (nodo.op === 'personalita') {
      return ctx.personalita === nodo.valore;
    }
    if (nodo.op === 'talento') {
      return !!(ctx.talenti && ctx.talenti.indexOf(nodo.valore) !== -1);
    }
    if (nodo.op === 'cmp') {
      var v = (ctx.stat && typeof ctx.stat[nodo.stat] === 'number') ? ctx.stat[nodo.stat] : 0;
      switch (nodo.cmp) {
        case '>=': return v >= nodo.val;
        case '<=': return v <= nodo.val;
        case '>': return v > nodo.val;
        case '<': return v < nodo.val;
        case '==': return v === nodo.val;
      }
      return false;
    }
    if (nodo.op === 'perk') {
      return !!(ctx.perks && ctx.perks.indexOf(nodo.valore) !== -1);
    }
    if (nodo.op === 'flag') {
      return !!(ctx.flags && ctx.flags.indexOf(nodo.valore) !== -1);
    }
    if (nodo.op === 'arma') {
      return !!ctx.armaEquip;
    }
    if (nodo.op === 'benessere') {
      // Default 100 (pieno) se il valore manca dal ctx: un termine tipo fel<30 resta FALSO
      // in assenza di dati — conservativo, mai un super regalato per un campo mancante.
      var b = (ctx.benessere && typeof ctx.benessere[nodo.stat] === 'number') ? ctx.benessere[nodo.stat] : 100;
      switch (nodo.cmp) {
        case '>=': return b >= nodo.val;
        case '<=': return b <= nodo.val;
        case '>': return b > nodo.val;
        case '<': return b < nodo.val;
        case '==': return b === nodo.val;
      }
      return false;
    }
    if (nodo.op === 'statagg') {
      // statMax/statMin: confronto sull'aggregato delle 4 stat RPG (piu' alta o piu' bassa).
      var st = ctx.stat || {};
      var vals = [st.forza || 0, st.intelligenza || 0, st.velocita || 0, st.carisma || 0];
      var agg = (nodo.agg === 'min') ? Math.min.apply(null, vals) : Math.max.apply(null, vals);
      switch (nodo.cmp) {
        case '>=': return agg >= nodo.val;
        case '<=': return agg <= nodo.val;
        case '>': return agg > nodo.val;
        case '<': return agg < nodo.val;
        case '==': return agg === nodo.val;
      }
      return false;
    }
    return false;
  }

  window.PETQ.content.parseCondizione = parseCondizione;
  window.PETQ.content.valutaCondizione = valutaCondizione;
  window.PETQ.content.normalizzaStatNome = normalizzaStatNome;

})();
