window.PETQ = window.PETQ || {};

(function () {

  // ============================================================================================
  // SUONI (v1) — sintetizzati con WebAudio, NESSUN FILE.
  //
  // Perche' sintetizzati e non campioni: (1) zero byte aggiunti all'APK, (2) nessuna licenza da
  // gestire, (3) il suono a onda quadra E' il suono 8-bit, quindi combacia col pixel invece di
  // imitarlo. Il prezzo e' che ogni suono va scritto a mano come note e inviluppi.
  //
  // CONTRATTO DI SICUREZZA (stesso spirito di notifiche.js): se WebAudio non c'e' o il contesto
  // non parte, OGNI funzione qui e' un no-op silenzioso. Il gioco non deve mai cambiare
  // comportamento per colpa dell'audio, e non deve MAI lanciare: un suono che fallisce non puo'
  // interrompere una missione o un pasto.
  //
  // POLITICA AUTOPLAY: browser e WebView vietano l'audio prima di un gesto dell'utente. Il
  // contesto quindi si crea PIGRO al primo tentativo di suonare, e si registra una volta sola un
  // listener su pointerdown/keydown che fa resume(). Non serve che nessun altro file se ne
  // occupi: chi vuole un suono chiama e basta.
  // ============================================================================================

  var CHIAVE_PREF = 'petq_audio';   // '0' = muto. Default: acceso.
  var VOLUME_MASTER = 0.22;         // tenuto basso: e' un gioco che si apre in mezzo alla gente

  var ctx = null;                   // AudioContext, creato pigro
  var master = null;                // gain generale
  var supportato = null;            // null = non ancora verificato
  var sbloccoRegistrato = false;

  function esisteWebAudio() {
    if (supportato === null) {
      supportato = !!(window.AudioContext || window.webkitAudioContext);
    }
    return supportato;
  }

  // ---------- preferenza muto (localStorage, stesso schema di petq_lingua) ----------
  function attivo() {
    try {
      return localStorage.getItem(CHIAVE_PREF) !== '0';
    } catch (e) {
      return true; // localStorage non disponibile: si suona, e' il default
    }
  }

  function imposta(acceso) {
    try {
      localStorage.setItem(CHIAVE_PREF, acceso ? '1' : '0');
    } catch (e) { /* niente persistenza: resta acceso per questa sessione */ }
    // spegnendo, tronca subito quello che sta suonando
    if (!acceso && master) {
      try { master.gain.value = 0; } catch (e2) { /* contesto in stato strano */ }
    } else if (master) {
      try { master.gain.value = VOLUME_MASTER; } catch (e3) { /* idem */ }
    }
  }

  // ---------- contesto ----------
  // Registra UNA volta il gesto che sblocca l'audio. Va fatto anche se il contesto esiste gia':
  // su alcuni Android nasce in stato 'suspended' e resta muto finche' non lo si riprende.
  function registraSblocco() {
    if (sbloccoRegistrato) return;
    sbloccoRegistrato = true;
    var riprendi = function () {
      if (ctx && ctx.state === 'suspended' && ctx.resume) {
        try { ctx.resume(); } catch (e) { /* niente da fare, resta muto */ }
      }
    };
    try {
      document.addEventListener('pointerdown', riprendi, true);
      document.addEventListener('keydown', riprendi, true);
      document.addEventListener('touchstart', riprendi, true);
    } catch (e) { /* ambiente senza DOM eventi: si rinuncia in silenzio */ }
  }

  function contesto() {
    if (!esisteWebAudio()) return null;
    if (ctx) return ctx;
    try {
      var C = window.AudioContext || window.webkitAudioContext;
      ctx = new C();
      master = ctx.createGain();
      master.gain.value = attivo() ? VOLUME_MASTER : 0;
      master.connect(ctx.destination);
      registraSblocco();
      if (ctx.state === 'suspended' && ctx.resume) { try { ctx.resume(); } catch (e) { /* al prossimo gesto */ } }
    } catch (e) {
      supportato = false;  // creazione fallita: non ritentare a ogni suono
      ctx = null;
      return null;
    }
    return ctx;
  }

  // ---------- mattoni ----------
  // Una nota. `attacco` e' la vera arma contro il "sono tutti uguali": 0.005 = schiocco secco
  // (interfaccia, monete), 0.08-0.2 = la nota SALE (coccola, sonno) e suona morbida invece che
  // percussiva. exponentialRampToValueAtTime non puo' arrivare a 0: si scende a 0.0001.
  function nota(freq, t0, dur, tipo, vol, attacco) {
    var c = contesto();
    if (!c) return null;
    var osc = c.createOscillator();
    var g = c.createGain();
    var att = attacco || 0.006;
    osc.type = tipo || 'square';
    osc.frequency.setValueAtTime(freq, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.5, t0 + att);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g); g.connect(master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
    return osc;
  }

  // Nota che SCIVOLA di frequenza (glissato).
  function scivolo(f1, f2, t0, dur, tipo, vol, attacco) {
    var c = contesto();
    if (!c) return;
    var osc = c.createOscillator();
    var g = c.createGain();
    osc.type = tipo || 'square';
    osc.frequency.setValueAtTime(f1, t0);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, f2), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.5, t0 + (attacco || 0.006));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g); g.connect(master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  // Nota che TREMA (vibrato): un secondo oscillatore lento modula la frequenza del primo.
  // E' quello che rende la coccola un mormorio caldo e la parola una vocina buffa: nessun'altra
  // voce si muove cosi', quindi si riconoscono a orecchio anche senza guardare lo schermo.
  function tremolo(freq, t0, dur, tipo, vol, profondita, velocita, attacco) {
    var c = contesto();
    if (!c) return;
    var osc = c.createOscillator();
    var g = c.createGain();
    var lfo = c.createOscillator();
    var lfoG = c.createGain();
    osc.type = tipo || 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    lfo.type = 'sine';
    lfo.frequency.setValueAtTime(velocita || 6, t0);
    lfoG.gain.setValueAtTime(profondita || 10, t0);
    lfo.connect(lfoG); lfoG.connect(osc.frequency);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.4, t0 + (attacco || 0.05));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g); g.connect(master);
    osc.start(t0); lfo.start(t0);
    osc.stop(t0 + dur + 0.02); lfo.stop(t0 + dur + 0.02);
  }

  // Due oscillatori quasi uguali = BATTIMENTO: ondeggia e suona stonato. Serve al fallimento,
  // che cosi' e' "acido" senza bisogno di essere piu' forte.
  function battimento(freq, scarto, t0, dur, tipo, vol) {
    nota(freq, t0, dur, tipo || 'sawtooth', (vol || 0.3) * 0.6, 0.02);
    nota(freq + (scarto || 8), t0, dur, tipo || 'sawtooth', (vol || 0.3) * 0.6, 0.02);
  }

  // Piu' note INSIEME (accordo). Le fanfare della v1 erano solo arpeggi: un accordo tenuto ha un
  // corpo che una sequenza di note singole non ha.
  function accordo(freqs, t0, dur, tipo, vol) {
    for (var i = 0; i < freqs.length; i++) {
      nota(freqs[i], t0, dur, tipo || 'square', (vol || 0.4) / Math.max(1, freqs.length - 1), 0.01);
    }
  }

  // TONFO percussivo: frequenza bassa che crolla in fretta = pelle di tamburo, non una nota.
  // L'allenamento e i passi vivono qui, in un registro dove non c'e' nient'altro.
  function tonfo(freq, t0, dur, vol) {
    var c = contesto();
    if (!c) return;
    var osc = c.createOscillator();
    var g = c.createGain();
    // TRIANGLE e non sine: l'altoparlante di un telefono sotto i ~200 Hz non riproduce quasi
    // niente, e una sine grave non ha armoniche che lo compensino, quindi sul telefono sarebbe
    // silenzio. La triangle porta con se' armoniche udibili anche se la fondamentale si perde.
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, t0);
    osc.frequency.exponentialRampToValueAtTime(Math.max(70, freq * 0.55), t0 + dur * 0.8);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.6, t0 + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g); g.connect(master);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  }

  // CAMPANELLA: sine acuta con coda lunga. Timbro puro, niente armoniche: sta all'opposto della
  // ruvidita' della sawtooth e si distingue subito dal resto.
  function campanella(freq, t0, dur, vol) {
    nota(freq, t0, dur, 'sine', vol || 0.3, 0.004);
    nota(freq * 2.01, t0, dur * 0.5, 'sine', (vol || 0.3) * 0.3, 0.004); // armonica leggermente stonata: sapore di metallo
  }

  // Rumore filtrato: acqua, croccantezza, schiocchi. Non e' una nota e non ha altezza, quindi
  // e' il modo piu' netto per NON somigliare alle altre voci.
  function rumore(t0, dur, vol, f1, f2, tipoFiltro) {
    var c = contesto();
    if (!c) return;
    var n = Math.max(1, Math.floor(c.sampleRate * dur));
    var buf = c.createBuffer(1, n, c.sampleRate);
    var dati = buf.getChannelData(0);
    for (var i = 0; i < n; i++) dati[i] = Math.random() * 2 - 1;
    var src = c.createBufferSource();
    src.buffer = buf;
    var filtro = c.createBiquadFilter();
    filtro.type = tipoFiltro || 'lowpass';
    filtro.frequency.setValueAtTime(f1 || 800, t0);
    filtro.frequency.exponentialRampToValueAtTime(Math.max(60, f2 || 400), t0 + dur);
    var g = c.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.3, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(filtro); filtro.connect(g); g.connect(master);
    src.start(t0);
    src.stop(t0 + dur + 0.02);
  }

  // Sequenza di note a passo fisso.
  function sequenza(freqs, t0, passo, dur, tipo, vol, attacco) {
    for (var i = 0; i < freqs.length; i++) {
      nota(freqs[i], t0 + i * passo, dur, tipo, vol, attacco);
    }
  }

  // ---------- le voci ----------
  // Ogni gruppo occupa un ANGOLO diverso dello spazio sonoro: registro, durata, timbro e
  // movimento sono scelti perche' due voci vicine nel gioco non si somiglino mai.
  var VOCI = {
    // --- interfaccia: acutissime, cortissime, quasi impercettibili (non devono stancare) ---
    tap: function (t) { nota(1400, t, 0.035, 'sine', 0.16, 0.002); },
    apri: function (t) { scivolo(520, 900, t, 0.13, 'sine', 0.26, 0.01); },
    chiudi: function (t) { scivolo(900, 480, t, 0.13, 'sine', 0.24, 0.01); },

    // --- rifiuto: sawtooth BASSA che scivola giu'. Ruvida dove tutto il resto e' pulito ---
    // fondamentale alzata a 225: sotto i ~200 Hz un altoparlante da telefono rende poco. La
    // sawtooth si sentirebbe comunque per le armoniche, ma cosi' e' netta anche a volume basso
    rifiuto: function (t) { battimento(225, 11, t, 0.26, 'sawtooth', 0.34); scivolo(225, 140, t, 0.26, 'sawtooth', 0.20, 0.01); },

    // --- cura del pet: organiche. Nessuna di queste e' un arpeggio ---
    // mormorio caldo che trema: nessun'altra voce ha il vibrato
    coccola: function (t) { tremolo(500, t, 0.55, 'sine', 0.34, 14, 6.5, 0.09); },
    // SOLO rumore: mordere non e' una nota. Due morsi asciutti e bassi
    mangia: function (t) { rumore(t, 0.075, 0.42, 1100, 260); rumore(t + 0.13, 0.065, 0.36, 900, 220); },
    // acqua lunga: il filtro si apre e si richiude, quasi un secondo
    lava: function (t) { rumore(t, 0.85, 0.26, 320, 2800); rumore(t + 0.25, 0.55, 0.14, 2400, 500); },
    // schiocco: rumore brillante cortissimo + "plop" che sale
    pulisci: function (t) { rumore(t, 0.05, 0.30, 3000, 1200, 'highpass'); scivolo(300, 900, t + 0.03, 0.10, 'sine', 0.30, 0.004); },
    // sonno: la voce piu' LENTA e piu' bassa, sale piano e scende per un secondo
    dorme: function (t) { scivolo(400, 150, t, 1.0, 'sine', 0.24, 0.20); },
    // risveglio: due campanelle pulite con coda lunga
    sveglia: function (t) { campanella(784, t, 0.55, 0.26); campanella(1175, t + 0.16, 0.65, 0.22); },
    // vocina buffa: square che trema veloce
    parola: function (t) { tremolo(680, t, 0.30, 'square', 0.30, 45, 13, 0.01); },

    // --- economia: metalliche e brillanti ---
    moneta: function (t) { nota(988, t, 0.06, 'square', 0.30, 0.003); nota(1319, t + 0.06, 0.22, 'square', 0.28, 0.003); },
    // registratore di cassa: schiocco secco + campanella alta
    acquisto: function (t) { rumore(t, 0.04, 0.28, 2600, 900, 'highpass'); campanella(1568, t + 0.04, 0.55, 0.26); },

    // --- attivita': ognuna in un registro diverso ---
    // partenza: sawtooth che sale come un motore, registro medio-basso
    missioneParte: function (t) { scivolo(180, 620, t, 0.34, 'sawtooth', 0.30, 0.03); nota(784, t + 0.30, 0.22, 'triangle', 0.26, 0.01); },
    // allenamento: due TONFI bassi, nessuna melodia. Registro dove non c'e' nient'altro
    allenamento: function (t) { tonfo(210, t, 0.16, 0.55); tonfo(280, t + 0.17, 0.22, 0.50); },
    // gioco: triangle che rimbalza avanti e indietro, saltellante
    gioco: function (t) { sequenza([784, 1047, 880, 1245], t, 0.065, 0.10, 'triangle', 0.30, 0.004); },

    // --- esiti: le uniche vere melodie, e con LUNGHEZZE molto diverse fra loro ---
    missioneOk: function (t) { sequenza([523, 659, 784], t, 0.085, 0.18, 'square', 0.34, 0.005); },
    missioneSuper: function (t) {
      sequenza([523, 659, 784, 1047], t, 0.08, 0.15, 'square', 0.34, 0.005);
      accordo([523, 659, 784, 1047], t + 0.34, 0.75, 'square', 0.44);   // accordo TENUTO: e' il corpo che mancava
      campanella(2093, t + 0.42, 0.60, 0.20);                            // scintilla sopra
    },
    // fallimento: lento, basso, stonato di proposito (battimento) e scende
    missioneKo: function (t) { battimento(300, 11, t, 0.75, 'sawtooth', 0.34); scivolo(300, 175, t, 0.75, 'sawtooth', 0.22, 0.03); },

    // --- momenti grossi: i piu' LUNGHI, cosi' si sente subito che e' successo qualcosa di raro ---
    evoluzione: function (t) {
      sequenza([392, 523, 659, 784], t, 0.11, 0.20, 'triangle', 0.30, 0.01);
      accordo([523, 659, 784, 1047], t + 0.48, 0.9, 'square', 0.44);
      campanella(2093, t + 0.60, 0.8, 0.22);
      campanella(2637, t + 0.78, 0.7, 0.18);
    },
    leggenda: function (t) {
      tonfo(165, t, 0.5, 0.5);                                            // colpo grave d'apertura
      sequenza([392, 523, 659, 784, 1047], t + 0.18, 0.12, 0.22, 'square', 0.32, 0.008);
      accordo([523, 784, 1047, 1319], t + 0.86, 1.2, 'square', 0.46);
      campanella(2637, t + 1.0, 1.0, 0.24);
    },

    // --- SCHIUSA (Round 5, 14 ago 2026): famiglia NUOVA per regola di differenziazione ---
    // uovoTic: il colpetto sul guscio. E' il suono PIU' CORTO del gioco (~45 ms) ed e' la sua
    // firma: schiocco di rumore in banda alta + "legno" (triangle medio che muore subito).
    // Secco e senza coda — tutto il contrario delle campanelle e dei tonfi.
    uovoTic: function (t) {
      rumore(t, 0.02, 0.30, 3200, 1800, 'bandpass');   // lo schiocco
      nota(620, t + 0.004, 0.04, 'triangle', 0.26, 0.001); // il corpo di legno, attacco istantaneo
    },
    // uovoSchiusa: il POP di apertura. Evento composito: chirp che SALE di corsa (la pressione
    // che si libera) + sbuffo d'aria + due scheggette che cadono sfalsate. Nessun'altra voce
    // e' un chirp+sbuffo: famiglia sua.
    uovoSchiusa: function (t) {
      scivolo(260, 820, t, 0.07, 'square', 0.36, 0.003);       // il pop vero
      rumore(t + 0.05, 0.09, 0.22, 900, 120, 'bandpass');      // l'aria che esce
      nota(1400, t + 0.16, 0.018, 'triangle', 0.16, 0.001);    // scheggia 1
      nota(1900, t + 0.23, 0.015, 'triangle', 0.12, 0.001);    // scheggia 2, piu' piccola
    },
    // nascita: il carillon del benvenuto. BICORDI pizzicati (due note a distanza di terza,
    // simultanee) in registro alto e dolce: nessun'altra voce usa intervalli a due — le fanfare
    // (evoluzione/leggenda) sono arpeggi+accordi pieni in square, questo e' un carillon che si
    // chiude in meno di un secondo. La celebrazione grossa resta a 'evoluzione'/'leggenda'.
    nascita: function (t) {
      accordo([1047, 1319], t, 0.16, 'triangle', 0.30);        // do-mi
      accordo([1175, 1397], t + 0.20, 0.16, 'triangle', 0.30); // re-fa
      accordo([1319, 1568], t + 0.40, 0.34, 'triangle', 0.34); // mi-sol, tenuto: chiude la culla
      campanella(3136, t + 0.46, 0.4, 0.12);                   // un luccichio piccolo, non fanfara
    }
  };

  // ---------- API ----------
  // suona(nome): l'unica cosa che il resto del gioco deve conoscere. Nome sconosciuto, audio
  // spento, contesto assente -> non succede niente e non si lancia.
  function suona(nome) {
    try {
      if (!attivo()) return;
      var voce = VOCI[nome];
      if (!voce) return;
      var c = contesto();
      if (!c) return;
      // se il contesto e' ancora sospeso (nessun gesto utente finora) si prova a riprenderlo:
      // il primo suono della sessione puo' perdersi, i successivi no.
      if (c.state === 'suspended' && c.resume) { try { c.resume(); } catch (e) { /* al prossimo gesto */ } }
      voce(c.currentTime + 0.01);
    } catch (e) {
      // un suono non deve MAI rompere il gioco: si ingoia e si tira dritto
    }
  }

  function elenco() {
    var out = [];
    for (var k in VOCI) if (VOCI.hasOwnProperty(k)) out.push(k);
    return out;
  }

  /* ---------- ANIMALESE: il pet "parla" mentre compare il fumetto ----------
   *
   * Un bip corto per lettera, alla Animal Crossing. Le tre cose che fanno la differenza fra un
   * PARLATO e una filastrocca di note a caso, tutte imparate provando:
   *
   * 1. Le VOCALI durano il doppio delle consonanti e suonano piu' forte. E' questo, piu' di
   *    qualunque scelta di note, a far sentire delle "sillabe": senza, esce una mitragliata
   *    uniforme che l'orecchio legge come un rumore di tastiera, non come una voce.
   * 2. Le note stanno su una scala PENTATONICA (nessun semitono adiacente). Mappando le lettere
   *    su tutti i dodici semitoni escono continuamente intervalli stonati e sembra un errore.
   * 3. Ogni bip SCIVOLA un po' di frequenza. Una nota ferma e' un bip da forno a microonde; una
   *    che si muove somiglia a un'inflessione.
   *
   * La punteggiatura non fa nota: fa PAUSA. E' li' che si sente il respiro fra le frasi.
   */
  /* NOVE gradi, e il numero non e' arbitrario: la nota si sceglie col resto del codice della
   * lettera diviso la lunghezza della tabella, quindi la lunghezza decide QUALI lettere finiscono
   * sulla stessa nota. Con 10 gradi 'a' e 'u' cadevano insieme e cosi' 'e' e 'o' (i codici delle
   * vocali distano 4, 8 e 16); con 9 tutte e cinque le vocali suonano diverse — ed essendo le
   * vocali le note lunghe, sono proprio quelle che si sentono.
   * L'estensione si ferma a 19 semitoni (poco piu' di un'ottava e mezza): con due ottave piene fra
   * due lettere vicine capitavano salti da 584 a 1749 Hz e usciva un arpeggio, non un parlato. */
  var PENTATONICA = [0, 2, 4, 7, 9, 12, 14, 16, 19];
  var VOCALI = 'aeiouàèéìòóùAEIOU';
  var MAX_BIP = 20;        // oltre, una battuta lunga diventa una mitragliata di un secondo e mezzo
  var PAUSA_VIRGOLA = 0.09;
  var PAUSA_PUNTO = 0.17;

  // Timbro e registro per razza. Il pet robot ha la voce alta e squadrata, il blob e' morbido e
  // grave, l'insetto stride, il rettiliano raspa, la leggenda parla basso. Non sono decorazioni:
  // con lo stesso identico testo si riconosce CHI sta parlando anche a occhi chiusi.
  // Le basi sono BASSE perche' la tabella sopra moltiplica fino a x3: con base 520 la lettera
  // piu' acuta finiva a 1750 Hz, cioe' un fischio. Cosi' ogni voce sta in una banda sua e nessuna
  // diventa stridula: robot 340-1016, blob 240-717, insetto 420-1255, rettiliano 260-777.
  var VOCI_RAZZA = {
    robot:      { base: 340, tipo: 'square',   scivolata: 0.94 },
    blob:       { base: 240, tipo: 'triangle', scivolata: 1.06 },
    // La chiave e' "insettoide" come in pet.js SOTTORAZZE_ALIENO — per un anno qui c'era scritto
    // "insetto", una sottorazza che nessun pet ha mai avuto: TUTTI gli insettoidi cadevano nel
    // ripiego e parlavano da robot (scoperto dal fondatore sul set, 11 ago 2026: "la voce e'
    // sempre del robot anche se dovrebbe essere dell'alieno"). Le chiavi di queste tabelle vanno
    // sempre confrontate coi VALORI che pet.generate scrive davvero, non col nome della specie.
    insettoide: { base: 420, tipo: 'sawtooth', scivolata: 0.90 },
    rettiliano: { base: 260, tipo: 'sawtooth', scivolata: 0.92 },
    leggenda:   { base: 180, tipo: 'square',   scivolata: 0.88 }
  };

  // Chiave di voce dal pet: la sottorazza vince sulla razza (un alieno blob e un alieno insetto
  // non possono avere la stessa voce), le leggende hanno la loro.
  function voceDi(petLike) {
    if (!petLike) return 'robot';
    if (petLike.razza === 'leggenda') return 'leggenda';
    if (petLike.sottorazza && VOCI_RAZZA[petLike.sottorazza]) return petLike.sottorazza;
    if (VOCI_RAZZA[petLike.razza]) return petLike.razza;
    // Rete di sicurezza nata dal bug "insetto"/"insettoide" qui sopra: se un alieno ha una
    // sottorazza che questa tabella non conosce (chiave nuova, refuso, save vecchio), deve
    // restare un ALIENO qualunque — cadere sul robot e' il peggior ripiego possibile, perche'
    // e' l'unica voce col timbro dell'altra famiglia e il difetto si sente subito.
    if (petLike.razza === 'alieno') return 'blob';
    return 'robot';
  }

  /* ---------- VOCE SINTETICA A FORMANTI: il pet DICE una parola, ma non con voce umana ----------
   *
   * PERCHE' NON BASTA IL TTS. Il motore vocale di sistema restituisce sempre una voce UMANA, e le
   * uniche manopole che offre (tonalita' e velocita') danno una voce umana acuta o grave, mai una
   * voce robotica. E il suo audio non e' intercettabile — ne' da browser (speechSynthesis non
   * espone uno stream) ne' dal plugin nativo (parla direttamente all'altoparlante) — quindi non
   * c'e' modo di applicarci sopra un effetto. Per avere un robot che parla bisogna costruire la
   * voce, non filtrarla: e' la stessa strada dei sintetizzatori vocali degli anni '80, che infatti
   * sono IL suono che si intende quando si dice "voce robotica".
   *
   * COME FUNZIONA. Una vocale umana e' una sorgente ricca di armoniche (le corde vocali) filtrata
   * da due picchi di risonanza, i FORMANTI, che la bocca sposta: sono le loro due frequenze a far
   * sentire "a" invece di "i". Qui: un dente di sega come sorgente, due passa-banda in PARALLELO
   * sui formanti giusti. Le consonanti sono rumore filtrato in bande diverse (la "s" e' sibilo
   * acuto, la "p" e' uno scoppio basso).
   *
   * COSA RENDE ROBOTICA la voce: la fondamentale COSTANTE. Una voce umana non e' mai ferma su una
   * nota; tenerla immobile e' il tratto che l'orecchio riconosce come macchina, piu' del timbro.
   * In piu' una modulazione ad anello (un secondo oscillatore che moltiplica il segnale) aggiunge
   * il ronzio metallico.
   *
   * L'ALIENO usa lo stesso motore con i formanti SPOSTATI IN ALTO del 35%: un tratto vocale piu'
   * corto e' esattamente cio' che rende una voce "non umana e acuta". Piu' due sorgenti scordate
   * fra loro, che e' la "stortura" chiesta dal fondatore.
   */

  // Formanti delle cinque vocali (F1, F2, F3 in Hz): valori classici da fonetica acustica.
  // La TERZA formante e' entrata col retuning post-set (11 ago 2026): due sole formanti bastano
  // a distinguere le vocali su una voce grave, ma su una fondamentale acuta (alieni) le armoniche
  // sono rade e ogni banda in piu' e' un appiglio per l'orecchio. F3 a guadagno basso: presenza,
  // non un fischio.
  var FORMANTI = {
    a: [730, 1090, 2440], e: [530, 1840, 2480], i: [270, 2290, 3010], o: [570, 840, 2410], u: [300, 870, 2240]
  };

  // Consonanti come rumore filtrato: [banda bassa, banda alta, durata, e' un'occlusiva?].
  // Le occlusive (p/t/k/b/d/g) vogliono un attimo di SILENZIO prima dello scoppio: senza, non si
  // sentono come consonanti staccate ma come un fruscio attaccato alla vocale.
  var CONSONANTI = {
    s: [4200, 7000, 0.085, false], z: [3600, 6000, 0.075, false],
    f: [1400, 4200, 0.075, false], v: [900, 2600, 0.060, false],
    t: [3200, 5200, 0.030, true],  d: [1800, 3200, 0.030, true],
    p: [600, 1600, 0.030, true],   b: [400, 1100, 0.030, true],
    k: [1600, 3000, 0.035, true],  g: [900, 2000, 0.035, true],
    m: [250, 900, 0.055, false],   n: [300, 1200, 0.055, false],
    l: [400, 1500, 0.050, false],  r: [700, 1900, 0.045, false],
    h: [1200, 2400, 0.030, false],
    sh: [2200, 4800, 0.095, false], // sc(e/i), sh inglese
    ts: [2800, 5600, 0.070, true],  // c(e/i) italiana
    dz: [1800, 3600, 0.070, true]   // g(e/i) italiana
  };

  /* PERCHE' L'ALIENO NON E' "IL ROBOT CON ALTRI NUMERI" (segnalazione del fondatore, 10 ago 2026:
   * "nella scena c'e' l'alieno ma la voce e' robotica"). Aveva ragione, e la stessa correzione
   * l'aveva gia' fatta a luglio sulla voce del telefono (v. voce.js, ROBOTIZZA): qui era rimasta
   * indietro. I due profili si distinguevano SOLO per la taratura dello stesso effetto — la
   * modulazione ad anello — che per giunta nell'alieno era piu' PROFONDA (0,55 contro 0,42):
   * l'anello e' la firma metallica del robot, quindi l'alieno suonava piu' robotico del robot.
   * L'orecchio riconosce prima la FAMIGLIA dell'effetto e poi i suoi parametri.
   *
   * Ora ogni voce ha la sua famiglia. Nel robot restano le DUE cose che fanno "macchina":
   * anello acceso e altezza CONGELATA. L'alieno le perde entrambe e prende in cambio tre tratti
   * che una macchina non puo' avere:
   *   coro    -> due gole scordate fra loro (c'era gia': scarto)
   *   ondeggia-> l'altezza vibra e non sta ferma su una nota (ondaHz/ondaCent) + entra da sotto
   *              scivolando dentro la nota (attacco), invece di piombarci esatta
   *   bocca viva-> il secondo formante SALE durante la vocale (sweepFormante): un robot ha la
   *              bocca ferma, cioe' un filtro fisso.
   * Le due voci ora hanno lo stesso picco (0.5): togliendo l'anello l'alieno non e' piu' smorzato
   * a intermittenza, quindi a parita' di numero suona un filo piu' presente. E' voluto.
   */
  /* TRE ALIENI, TRE VOCI (fondatore dal set, 11 ago 2026: "la voce e' sempre la stessa"). Aveva
   * ragione di nuovo: il profilo 'alieno' era UNO per tutte e tre le sottorazze, quindi Muffin
   * (blob) e Blobetto (insettoide) dicevano le parole con la voce identica — mentre l'animalese
   * le distingueva gia' (VOCI_RAZZA). Un pet non puo' avere due identita' vocali: la voce che
   * DICE le parole ora si differenzia per sottorazza come quella che biascica.
   *
   * La FAMIGLIA aliena resta una (niente anello, coro di due gole, altezza che ondeggia,
   * portamento, bocca che si muove): a cambiare fra le tre e' il CARATTERE, su assi che
   * l'orecchio distingue al volo — registro, velocita', ampiezza del movimento:
   *   blob       -> lenta, bassa, ubriaca: vocali lunghe e un'oscillazione larga e pigra
   *   insettoide -> rapida, acuta, frinita: vocali corte, vibrato veloce e stretto, formanti alti
   *   rettiliano -> media, sibilante: le S e le SH durano quasi il doppio (il soffio del rettile)
   * f0 sopra i 150 Hz: sotto i ~200 Hz gli altoparlanti dei telefoni rendono poco (lezione tonfo).
   * Il vibrato e' tarato sulla DURATA della vocale: cicli = ondaHz * durVocale, e sotto ~1 ciclo
   * si sente una nota storta, non un'altezza viva (lezione v270: 6,8 Hz su 160 ms non bastavano).
   */
  var PROFILI_VOCE = {
    robot: { f0: 165, formanti: 1.00, anello: 58, profonditaAnello: 0.42, scarto: 0, tipo: 'sawtooth' },
    blob: {
      f0: 200, formanti: 1.10, tipo: 'sawtooth', anello: 0, profonditaAnello: 0,
      scarto: 9, ondaHz: 4.6, ondaCent: 85, attacco: 0.78, sweepFormante: 1.10, durVocale: 0.21
    },
    // Insettoide ritarato dopo il set (fondatore: "non suona neanche una parola, solo un suono"):
    // la prima versione era f0 345 con vocali da 115 ms — ma piu' la fondamentale e' acuta, piu'
    // le armoniche sono RADE e i filtri delle formanti restano vuoti: la vocale perde identita'.
    // E le vocali corte violavano la lezione scritta qui sotto ("tagliarle rende la parola
    // irriconoscibile"). Il carattere frinito ora lo fanno il vibrato veloce e il registro
    // comunque alto, non la fretta.
    insettoide: {
      f0: 290, formanti: 1.30, tipo: 'sawtooth', anello: 0, profonditaAnello: 0,
      scarto: 12, ondaHz: 12.5, ondaCent: 28, attacco: 0.94, sweepFormante: 1.20, durVocale: 0.16
    },
    rettiliano: {
      f0: 230, formanti: 1.22, tipo: 'sawtooth', anello: 0, profonditaAnello: 0,
      scarto: 12, ondaHz: 7.5, ondaCent: 50, attacco: 0.85, sweepFormante: 1.15, durVocale: 0.16,
      allungaSibilanti: 1.8
    }
  };
  // Alias per chi passa ancora 'alieno' (chiamanti vecchi, pagina di prova): un alieno qualunque.
  PROFILI_VOCE.alieno = PROFILI_VOCE.blob;

  /* Divide una parola in suoni, secondo le REGOLE DI LETTURA della lingua ('it' default, 'en').
   *
   * Il gioco esce in inglese e i giocatori insegnano parole nella LORO lingua: leggere "ISSUE"
   * con l'ortografia italiana dava "i-ss-u-e" (fondatore dal set, 11 ago 2026 — "io la volevo
   * corretta in inglese"). L'ortografia inglese pero' non si legge a regole come l'italiano:
   * serve un piccolo dizionario di eccezioni (le parole comuni irregolari) + le regole che
   * coprono il grosso (digrammi, vocali doppie, la e muta finale che allunga la vocale prima).
   * Copre bene le parole corte da insegnare a un pet; non e' un motore fonetico completo e non
   * deve esserlo. Le doppie si fondono in un suono solo piu' lungo in entrambe le lingue. */

  // Parole inglesi che NESSUNA regola legge giusta: si scrivono direttamente in suoni.
  // Vocali: a/e/i/o/u · consonanti: quelle di CONSONANTI (sh = "sci", ts = "ci", dz = "gi").
  var ECCEZIONI_EN = {
    issue: ['i', 'sh', 'u'], one: ['u', 'a', 'n'], once: ['u', 'a', 'n', 's'],
    two: ['t', 'u'], the: ['d', 'a'], you: ['i', 'u'], to: ['t', 'u'], do: ['d', 'u'],
    who: ['h', 'u'], said: ['s', 'e', 'd'], was: ['u', 'o', 's'], what: ['u', 'o', 't'],
    want: ['u', 'o', 'n', 't'], some: ['s', 'a', 'm'], come: ['k', 'a', 'm'],
    done: ['d', 'a', 'n'], gone: ['g', 'o', 'n'], none: ['n', 'a', 'n'],
    love: ['l', 'a', 'v'], have: ['h', 'a', 'v'], give: ['g', 'i', 'v'], live: ['l', 'i', 'v'],
    sure: ['sh', 'u', 'r'], are: ['a', 'r'], of: ['o', 'v'], off: ['o', 'f'],
    here: ['h', 'i', 'r'], there: ['d', 'e', 'r'], where: ['u', 'e', 'r'],
    // La famiglia -ough non si legge a regole nemmeno per gli inglesi: quattro grafie uguali,
    // quattro suoni diversi (trovato dai verificatori: "though" usciva /dau/).
    though: ['d', 'o', 'u'], through: ['t', 'r', 'u'], tough: ['t', 'a', 'f'], thought: ['t', 'o', 't']
  };

  // La "e muta" finale allunga la vocale prima (make -> meik, time -> taim): e' LA regola
  // inglese che l'ortografia italiana non puo' indovinare.
  var VOCALE_LUNGA_EN = { a: 'ei', i: 'ai', o: 'ou', u: 'iu', e: 'i' };

  function scanInglese(s, out) {
    var parole = s.split(/[^a-z]+/);
    for (var w = 0; w < parole.length && out.length < 16; w++) {
      var parola = parole[w];
      if (!parola) continue;

      var ecc = ECCEZIONI_EN[parola];
      if (ecc) {
        for (var e = 0; e < ecc.length && out.length < 16; e++) {
          out.push(FORMANTI[ecc[e]] ? { t: 'v', k: ecc[e] } : { t: 'c', k: ecc[e] });
        }
        continue;
      }

      // e muta finale, in due regole. QUATTRO trappole trovate in collaudo (le prime tre mie,
      // la quarta dai verificatori avversariali), tutte della stessa specie: "la trasformazione
      // cambia il contesto di lettura dei vicini".
      // (1) 'i'->'ai' veniva RILETTO come dittongo ai->/ei/ (nice->neik): il punto e' un
      //     separatore muto che spezza il dittongo senza aggiungere suoni;
      // (2) la e sparita lasciava la C dura (nice->naik): c->s e g->j restano dolci;
      // (3) l'espansione che INIZIA per e/i ammorbidiva la consonante PRIMA (cage->seij);
      // (4) la vocale catturata poteva essere la SECONDA META' di un dittongo (mouse: la regex
      //     prendeva 'use' e lasciava la 'o' orfana -> m-o-i-u-s): la vocale allungata vale
      //     solo se PRIMA c'e' una consonante — se no la e e' semplicemente MUTA e il dittongo
      //     si legge da solo (mouse->maus, cheese->tsis, goose->gus, praise->preis).
      var eraMagica = false;
      parola = parola.replace(/(^|[^aeiou])([aeiou])([bcdfgklmnprstvz])e$/, function (m, prima, v, cns) {
        eraMagica = true;
        var dolce = cns === 'c' ? 's' : (cns === 'g' ? 'j' : cns);
        return prima + '.' + VOCALE_LUNGA_EN[v].split('').join('.') + dolce;
      });
      if (!eraMagica && /[aeiouy].+e$/.test(parola)) {
        // e finale muta dopo dittongo: cade e basta, conservando la dolcezza di c/g (juice->juis)
        parola = parola.replace(/ce$/, 's').replace(/ge$/, 'j').replace(/e$/, '');
      }

      var i = 0;
      while (i < parola.length && out.length < 16) {
        var tre = parola.substr(i, 3);
        var due = parola.substr(i, 2);
        var ch = parola.charAt(i);
        var dopo = parola.charAt(i + 1);

        if (tre === 'tch') { out.push({ t: 'c', k: 'ts' }); i += 3; continue; }
        if (tre === 'igh') { out.push({ t: 'v', k: 'a' }); out.push({ t: 'v', k: 'i' }); i += 3; continue; }
        if (tre === 'dge') { out.push({ t: 'c', k: 'dz' }); i += 3; continue; }

        if (due === 'ck') { out.push({ t: 'c', k: 'k' }); i += 2; continue; }
        if (due === 'ch') { out.push({ t: 'c', k: 'ts' }); i += 2; continue; }  // inglese: church
        if (due === 'sh') { out.push({ t: 'c', k: 'sh' }); i += 2; continue; }
        if (due === 'th') { out.push({ t: 'c', k: 'd' }); i += 2; continue; }   // approssimazione onesta
        if (due === 'ph') { out.push({ t: 'c', k: 'f' }); i += 2; continue; }
        if (due === 'gh') { if (i === 0) { out.push({ t: 'c', k: 'g' }); } i += 2; continue; } // ghost / muta
        if (due === 'wh') { out.push({ t: 'v', k: 'u' }); i += 2; continue; }
        if (due === 'wr' && i === 0) { out.push({ t: 'c', k: 'r' }); i += 2; continue; }
        if (due === 'kn' && i === 0) { out.push({ t: 'c', k: 'n' }); i += 2; continue; }
        if (due === 'qu') { out.push({ t: 'c', k: 'k' }); out.push({ t: 'v', k: 'u' }); i += 2; continue; }
        if (due === 'ee' || due === 'ea') { out.push({ t: 'v', k: 'i' }); i += 2; continue; }
        if (due === 'oo' || due === 'ue' || due === 'ui') { out.push({ t: 'v', k: 'u' }); i += 2; continue; }
        if (due === 'ou' || due === 'ow') { out.push({ t: 'v', k: 'a' }); out.push({ t: 'v', k: 'u' }); i += 2; continue; }
        if (due === 'oy' || due === 'oi') { out.push({ t: 'v', k: 'o' }); out.push({ t: 'v', k: 'i' }); i += 2; continue; }
        if (due === 'ay' || due === 'ai' || due === 'ey' || due === 'ei') { out.push({ t: 'v', k: 'e' }); out.push({ t: 'v', k: 'i' }); i += 2; continue; }
        if (due === 'oa') { out.push({ t: 'v', k: 'o' }); out.push({ t: 'v', k: 'u' }); i += 2; continue; }
        if (due === 'ew') { out.push({ t: 'v', k: 'i' }); out.push({ t: 'v', k: 'u' }); i += 2; continue; }
        if (due === 'au' || due === 'aw') { out.push({ t: 'v', k: 'o' }); i += 2; continue; }

        if (ch === 'c') { out.push({ t: 'c', k: (dopo === 'e' || dopo === 'i' || dopo === 'y') ? 's' : 'k' }); i += 1; continue; }
        if (ch === 'g') { out.push({ t: 'c', k: (dopo === 'e' || dopo === 'i' || dopo === 'y') ? 'dz' : 'g' }); i += 1; continue; }
        if (ch === 'j') { out.push({ t: 'c', k: 'dz' }); i += 1; continue; }
        if (ch === 'y') { out.push({ t: 'v', k: 'i' }); i += 1; continue; }
        if (ch === 'w') { out.push({ t: 'v', k: 'u' }); i += 1; continue; }
        if (ch === 'x') { out.push({ t: 'c', k: 'k' }); out.push({ t: 'c', k: 's' }); i += 1; continue; }
        if (FORMANTI[ch]) { out.push({ t: 'v', k: ch }); i += 1; continue; }
        if (CONSONANTI[ch]) { out.push({ t: 'c', k: ch }); i += 1; continue; }
        i += 1; // cifre e simboli: muti (in "-1000 AURA" parla solo AURA — annotato nel LEGGIMI)
      }
    }
  }

  function inSuoni(parola, lingua) {
    var s = String(parola).toLowerCase()
      .replace(/à/g, 'a').replace(/[èé]/g, 'e').replace(/ì/g, 'i').replace(/[òó]/g, 'o').replace(/ù/g, 'u');
    var out = [];
    if (lingua === 'en') { scanInglese(s, out); return fondiDoppie(out); }
    var i = 0;
    while (i < s.length && out.length < 16) {
      var due = s.substr(i, 2);
      var ch = s.charAt(i);
      var prossima = s.charAt(i + 1);

      if (due === 'ch' || due === 'gh') { out.push({ t: 'c', k: due === 'ch' ? 'k' : 'g' }); i += 2; continue; }
      if (due === 'gn') { out.push({ t: 'c', k: 'n' }); i += 2; continue; }
      if (due === 'gl' && s.charAt(i + 2) === 'i') { out.push({ t: 'c', k: 'l' }); i += 2; continue; }
      if (due === 'sc' && (s.charAt(i + 2) === 'e' || s.charAt(i + 2) === 'i')) { out.push({ t: 'c', k: 'sh' }); i += 2; continue; }
      if (due === 'qu') { out.push({ t: 'c', k: 'k' }); i += 1; continue; } // la u la fa la vocale dopo
      if (ch === 'c' && (prossima === 'e' || prossima === 'i')) { out.push({ t: 'c', k: 'ts' }); i += 1; continue; }
      if (ch === 'g' && (prossima === 'e' || prossima === 'i')) { out.push({ t: 'c', k: 'dz' }); i += 1; continue; }
      if (ch === 'c') { out.push({ t: 'c', k: 'k' }); i += 1; continue; }

      if (FORMANTI[ch]) { out.push({ t: 'v', k: ch }); i += 1; continue; }
      if (CONSONANTI[ch]) {
        // doppia: un suono solo, ma piu' lungo (e' cosi' che si pronuncia "gatto")
        if (prossima === ch) { out.push({ t: 'c', k: ch, lungo: true }); i += 2; continue; }
        out.push({ t: 'c', k: ch }); i += 1; continue;
      }
      if (ch === 'y') { out.push({ t: 'v', k: 'i' }); i += 1; continue; }
      if (ch === 'w') { out.push({ t: 'v', k: 'u' }); i += 1; continue; }
      if (ch === 'j') { out.push({ t: 'c', k: 'dz' }); i += 1; continue; }
      if (ch === 'x') { out.push({ t: 'c', k: 'k' }); out.push({ t: 'c', k: 's' }); i += 1; continue; }
      i += 1; // spazi, cifre, punteggiatura: si saltano
    }
    return fondiDoppie(out);
  }

  // Fusione finale delle consonanti uguali adiacenti: "zucchina" arrivava qui come z-u-k-k-i-n-a
  // perche' la 'c' e il digramma 'ch' vengono riconosciuti in due passaggi diversi. Due scoppi
  // separati aggiungono una pausa in mezzo alla parola; una consonante sola piu' LUNGA e'
  // esattamente come si pronuncia una doppia (vale uguale per l'inglese: "skill").
  function fondiDoppie(out) {
    var fuse = [];
    for (var j = 0; j < out.length; j++) {
      var ult = fuse[fuse.length - 1];
      if (ult && ult.t === 'c' && out[j].t === 'c' && ult.k === out[j].k) { ult.lungo = true; continue; }
      fuse.push(out[j]);
    }
    return fuse;
  }

  // Una vocale: sorgente ad armoniche ricche + due passa-banda IN PARALLELO (in serie il secondo
  // filtro mangerebbe il primo formante e resterebbe un suono sordo, senza vocale riconoscibile).
  function vocaleFormante(k, t0, dur, p) {
    var c = contesto();
    if (!c) return;
    var F = FORMANTI[k] || FORMANTI.a;

    // Il picco si divide per il numero di sorgenti: l'alieno ne ha DUE, e sommandole a volume
    // pieno il segnale supera l'unita' e satura. Una saturazione digitale non e' "voce aliena",
    // e' distorsione sporca, e si sentirebbe come un difetto dell'app.
    var nSorgenti = p.scarto > 0 ? 2 : 1;
    var picco = 0.5 / nSorgenti;

    var env = c.createGain();
    env.gain.setValueAtTime(0.0001, t0);
    env.gain.exponentialRampToValueAtTime(picco, t0 + 0.018);
    env.gain.setValueAtTime(picco, t0 + dur - 0.02);
    env.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

    // Modulazione ad anello: e' il ronzio metallico, ed e' la firma del ROBOT (v. PROFILI_VOCE).
    // Con profondita' piena la parola diventa incomprensibile, quindi si tiene un fondo non
    // modulato (offset) e si modula il resto. A profondita' 0 (l'alieno) l'oscillatore non si
    // crea nemmeno: un anello moltiplicato per zero e' lavoro sprecato, e nel conto dei nodi
    // sembrerebbe che l'effetto ci sia ancora.
    if (p.profonditaAnello > 0) {
      var anello = c.createGain();
      anello.gain.setValueAtTime(1 - p.profonditaAnello, t0);
      var mod = c.createOscillator();
      var modAmp = c.createGain();
      mod.type = 'sine';
      mod.frequency.setValueAtTime(p.anello, t0);
      modAmp.gain.setValueAtTime(p.profonditaAnello, t0);
      mod.connect(modAmp); modAmp.connect(anello.gain);
      mod.start(t0); mod.stop(t0 + dur + 0.02);
      env.connect(anello); anello.connect(master);
    } else {
      env.connect(master);
    }

    // Una sorgente, oppure due leggermente scordate per l'alieno: due voci che battono fra loro
    // sono la "stortura" — nessun essere umano ha due laringi.
    var sorgenti = p.scarto > 0 ? [0, p.scarto] : [0];
    for (var s = 0; s < sorgenti.length; s++) {
      var osc = c.createOscillator();
      osc.type = p.tipo;
      var f0Sorgente = p.f0 + sorgenti[s];

      // PORTAMENTO: entra sotto e sale dentro la nota. Una macchina attacca l'altezza esatta al
      // primo campione — e' proprio quella precisione a farla sentire macchina.
      if (p.attacco && p.attacco !== 1) {
        osc.frequency.setValueAtTime(f0Sorgente * p.attacco, t0);
        osc.frequency.linearRampToValueAtTime(f0Sorgente, t0 + Math.min(dur * 0.45, 0.09));
      } else {
        osc.frequency.setValueAtTime(f0Sorgente, t0);
      }

      // VIBRATO sull'ALTEZZA (non sul volume): e' il contrario esatto della fondamentale
      // congelata del robot. Sulle due gole del coro l'ampiezza e' opposta, cosi' ondeggiano in
      // controfase: due creature che parlano insieme, non una voce sola raddoppiata.
      if (p.ondaCent > 0) {
        var lfo = c.createOscillator();
        var lfoAmp = c.createGain();
        lfo.type = 'sine';
        lfo.frequency.setValueAtTime(p.ondaHz, t0);
        lfoAmp.gain.setValueAtTime(s === 0 ? p.ondaCent : -p.ondaCent, t0);
        lfo.connect(lfoAmp); lfoAmp.connect(osc.detune);
        lfo.start(t0); lfo.stop(t0 + dur + 0.02);
      }

      // Tre bande: F1 larga (Q6 — con una fondamentale acuta le armoniche sono rade, e una banda
      // stretta resta VUOTA: la vocale sparisce, resta "un suono"; i sintetizzatori vocali veri
      // usano larghezze di banda di 60-90 Hz sulla prima formante, cioe' proprio Q~6), F2 media,
      // F3 stretta e bassa (presenza).
      var QF = [6, 12, 14];
      var GF = [1.0, 0.65, 0.30];
      for (var f = 0; f < 3; f++) {
        if (!F[f]) break;
        var bp = c.createBiquadFilter();
        bp.type = 'bandpass';
        bp.frequency.setValueAtTime(F[f] * p.formanti, t0);
        // BOCCA VIVA: il secondo formante sale mentre la vocale dura. E' F2 a dare la "forma"
        // della bocca, e nessun essere vivente la tiene immobile per 160 ms; il robot invece ha
        // il filtro fisso, che e' esattamente una bocca di metallo che non si muove.
        if (p.sweepFormante && f === 1) {
          bp.frequency.linearRampToValueAtTime(F[f] * p.formanti * p.sweepFormante, t0 + dur);
        }
        bp.Q.setValueAtTime(QF[f], t0);
        var g = c.createGain();
        g.gain.setValueAtTime(GF[f], t0);
        osc.connect(bp); bp.connect(g); g.connect(env);
      }
      osc.start(t0);
      osc.stop(t0 + dur + 0.02);
    }
  }

  /* parlaParola(parola, profilo, lingua): il pet PRONUNCIA una parola con voce sintetica.
   * lingua ('it' default | 'en') decide le REGOLE DI LETTURA — v. inSuoni.
   * Ritorna la durata in secondi, 0 se non e' uscito niente. */
  function parlaParola(parola, profilo, lingua) {
    try {
      if (!attivo() || !parola) return 0;
      var c = contesto();
      if (!c) return 0;
      if (c.state === 'suspended' && c.resume) { try { c.resume(); } catch (e) { /* al prossimo gesto */ } }

      var p = PROFILI_VOCE[profilo] || PROFILI_VOCE.robot;
      var suoni = inSuoni(parola, lingua);
      if (!suoni.length) return 0;

      var t = c.currentTime + 0.02;
      var inizio = t;
      for (var i = 0; i < suoni.length; i++) {
        var s = suoni[i];
        if (s.t === 'v') {
          // Vocali LUNGHE di proposito: sono loro a portare i formanti, cioe' l'unica parte da
          // cui si capisce che parola sia. Tagliarle fa risparmiare mezzo secondo e rende la
          // parola irriconoscibile. La durata e' del PROFILO: e' uno degli assi che distingue
          // il blob strascicato dall'insettoide frinito.
          var durV = p.durVocale || 0.16;
          vocaleFormante(s.k, t, durV, p);
          t += durV + 0.015;
        } else {
          var cfg = CONSONANTI[s.k] || CONSONANTI.t;
          var durC = cfg[2] * (s.lungo ? 1.8 : 1);
          // Il rettile SIBILA: i suoni di soffio (fricative sorde) durano quasi il doppio.
          // Solo quelli — allungare anche le occlusive farebbe solo una voce lenta.
          if (p.allungaSibilanti && (s.k === 's' || s.k === 'z' || s.k === 'sh' || s.k === 'f')) {
            durC *= p.allungaSibilanti;
          }
          if (cfg[3]) t += 0.030; // occlusiva: il silenzio PRIMA e' quello che la fa sentire
          rumore(t, durC, 0.30, cfg[1] * p.formanti, cfg[0] * p.formanti, 'bandpass');
          t += durC + 0.012;
        }
      }
      return t - inizio;
    } catch (e) {
      return 0;
    }
  }

  /* ---------- CANTO: il pet canticchia una parola insegnata (perk Cantante da Doccia) ----------
   *
   * LA DIFFERENZA FRA PARLARE E CANTARE, ed e' tutta qui: nell'animalese l'altezza la decide la
   * LETTERA, quindi va dove capita e si sente un parlato. Cantando l'altezza la decide la
   * MELODIA, e le sillabe ci si appoggiano sopra. Stesso timbro, stessa voce, risultato che
   * l'orecchio classifica in modo completamente diverso — senza scrivere un motore nuovo.
   *
   * Le altre due cose che fanno "canto" e non "sequenza di note": le note sono LUNGHE (una
   * sillaba tenuta, non un bip) e hanno il VIBRATO. Un cantante non tiene una nota ferma.
   *
   * Le sillabe si contano dalle VOCALI (inSuoni sopra): in italiano e' un'approssimazione
   * onestissima, e per parole di due-tre sillabe non sbaglia mai.
   */
  var MOTIVI = [
    [0, 0, 4, 7, 4, 0],        // sale e torna: la piu' "canzoncina" di tutte
    [7, 4, 0, 4, 7, 12],       // arco che apre
    [0, 4, 7, 12, 7, 4, 0],    // su e giu' completo
    [12, 9, 7, 4, 0, 0]        // discesa, quasi sospiro
  ];

  /* canta(parola, voceChiave, lingua): ritorna la durata in secondi, 0 se non e' uscito niente. */
  function canta(parola, voceChiave, lingua) {
    try {
      if (!attivo() || !parola) return 0;
      var c = contesto();
      if (!c) return 0;
      if (c.state === 'suspended' && c.resume) { try { c.resume(); } catch (e) { /* al prossimo gesto */ } }

      var v = VOCI_RAZZA[voceChiave] || VOCI_RAZZA.robot;
      var suoni = inSuoni(parola, lingua);
      var sillabe = [];
      for (var i = 0; i < suoni.length; i++) if (suoni[i].t === 'v') sillabe.push(suoni[i].k);
      if (sillabe.length === 0) return 0;

      var motivo = (window.PETQ.rng && PETQ.rng.pick) ? PETQ.rng.pick(MOTIVI) : MOTIVI[0];
      var t = c.currentTime + 0.02;
      var inizio = t;

      // La parola si RIPETE finche' il motivo non e' finito: e' quello che fa "canticchiare"
      // invece di dire una parola su tre note e fermarsi a meta' frase musicale.
      for (var n = 0; n < motivo.length; n++) {
        var dur = (n === motivo.length - 1) ? 0.42 : 0.24; // l'ultima nota si tiene: chiude la frase
        var f = v.base * Math.pow(2, motivo[n] / 12);
        // profondita' 0.02 e velocita' 6 Hz: vibrato da cantante, non da sirena.
        tremolo(f, t, dur, v.tipo, 0.2, 0.02, 6, 0.04);
        t += dur + 0.02;
      }
      return t - inizio;
    } catch (e) {
      return 0;
    }
  }

  /* parla(testo, voceChiave): emette l'animalese per quel testo. Ritorna la durata in secondi
   * (0 se non e' uscito niente), cosi' chi chiama puo' decidere di non sovrapporre altro. */
  function parla(testo, voceChiave) {
    try {
      if (!attivo() || !testo) return 0;
      var c = contesto();
      if (!c) return 0;
      if (c.state === 'suspended' && c.resume) { try { c.resume(); } catch (e) { /* al prossimo gesto */ } }

      var v = VOCI_RAZZA[voceChiave] || VOCI_RAZZA.robot;
      var t = c.currentTime + 0.01;
      var inizio = t;
      var bip = 0;

      for (var i = 0; i < testo.length && bip < MAX_BIP; i++) {
        var ch = testo.charAt(i);

        if (ch === ',' || ch === ';' || ch === ':') { t += PAUSA_VIRGOLA; continue; }
        if (ch === '.' || ch === '!' || ch === '?') { t += PAUSA_PUNTO; continue; }
        if (!/[a-zà-ÿ]/i.test(ch)) continue;   // spazi, cifre, emoji: nessuna nota

        var vocale = VOCALI.indexOf(ch) !== -1;
        var dur = vocale ? 0.075 : 0.045;
        var vol = vocale ? 0.24 : 0.16;

        // La nota dipende dalla LETTERA: la stessa parola suona sempre uguale, e due parole
        // diverse suonano diverse. Con un sorteggio casuale il pet sembrerebbe balbettare a caso.
        var grado = PENTATONICA[ch.toLowerCase().charCodeAt(0) % PENTATONICA.length];
        var f = v.base * Math.pow(2, grado / 12);
        scivolo(f, f * v.scivolata, t, dur, v.tipo, vol, 0.005);

        t += dur + 0.018;
        bip++;
      }

      return bip > 0 ? (t - inizio) : 0;
    } catch (e) {
      return 0; // una voce che fallisce non puo' interrompere il gioco
    }
  }

  window.PETQ.audio = {
    suona: suona,
    attivo: attivo,
    imposta: imposta,
    elenco: elenco,
    parla: parla,
    parlaParola: parlaParola,
    canta: canta,
    _motivi: function () { return MOTIVI; },
    // Esposti per voce.js, che deve agganciare la sua catena di effetti allo STESSO contesto e
    // allo STESSO volume master: due contesti audio separati significherebbero due volumi
    // scollegati e l'interruttore 🔊 che ne spegne solo uno.
    _contesto: contesto,
    _master: function () { return master; },
    voceDi: voceDi,
    _inSuoni: inSuoni,   // esposta per il collaudo: la scomposizione in suoni si verifica a occhio
    _vociRazza: function () { var o = []; for (var k in VOCI_RAZZA) if (VOCI_RAZZA.hasOwnProperty(k)) o.push(k); return o; },
    // per diagnosi dal pannello debug / console
    _stato: function () {
      return {
        supportato: esisteWebAudio(),
        contesto: ctx ? ctx.state : 'non creato',
        acceso: attivo(),
        voci: elenco().length
      };
    }
  };

})();
