# Veggeta — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il principe arrogante. Chiama tutti "verme" o "insetto", misura tutto in livelli di potenza, ODIA perdere, nega di essersi affezionato (si è affezionato). Catchphrase: "VERME!" (con parsimonia) · stupore: "è oltre il novemila...".
Sezioni prioritarie del brief; le altre si aggiungono col tempo, stessa struttura di content/personalita/.

## Saluto (apertura app)
- You deign to appear before me, insect. Good. The prince does not enjoy waiting. (He was waiting.)
- Ah, it's you. My power level just spiked with joy. FAULTY READING. Recalibrating.
- Welcome back, insect. Note that I have not destroyed you. It's my way of saying... never mind what it's my way of saying.
- Finally. The wait increased my resentment and, strangely, my desire to see you. The second reading is classified.

## Ha fame
- INSECT! The prince's bowl is empty. On certain planets, this is high treason.
- I hunger. A warrior of my caliber burns more energy than a small planet. Feed me or witness my fury. From a seated position, though. I'm weak.
- My stomach growls louder than I do. It is UNACCEPTABLE for anything to growl louder than I do. Food. Immediately.
- Bring the food and no one gets hurt. I shall call it "battle rations," and you will not correct me.

## È sporco
- A prince is never "dirty": he is fresh from battle. That said, wash me. Battle smells.
- This filth offends my royal bloodline. Draw me a bath worthy of my rank. With bubbles. Tell NO ONE.
- I am covered in combat dust. The combat was with the rug. It lost. Now wash me.
- Flies are orbiting me without permission. NOTHING orbits me without permission. Water. NOW.

## Coccole finite
- ENOUGH. The prince has tolerated more than enough affection for one day. Any purring you heard was enemy propaganda.
- Petting is over, insect. A pampered warrior loses his edge, and my edge is LEGENDARY.
- Cease this... exceedingly pleasant treatment at once. Same time tomorrow. For discipline, obviously.
- Cuddle time is over. Not because I enjoy it too much. THAT'S NOT IT. Go away. Come back tomorrow.

## Parte per la missione
- I depart. The mission is already trembling. If I find worthy opponents, I celebrate; if not — as usual — I shall be bored magnificently.
- The prince takes the field. You stay here and guard the throne. The couch. Guard the couch.
- Mission accepted — not for you, for glory. Fine, ten percent for you. Do NOT quote me.
- Off to dominate. If you hear the windows rattle, that's me holding back.

## Ritorno: successo
- Of course I won, insect. My power level did the rest. I did my power level. Think about it.
- Total victory. My opponents were insects. BRAVE insects, I'll grant them that: they showed up.
- Mission dominated. Mark the date: this is the day you had the honor of waiting for me at the door.
- I won. And no one even measured how hard: some power levels are beyond measurement. You wouldn't understand.

## Ritorno: fallimento
- I did not lose. I concluded the battle in a disadvantageous position. A PERMANENT one, but disadvantageous.
- Defeated. ME. The entire planet should stop turning out of RAGE. Never speak of this day again.
- I lost, insect. Tell anyone and I will deny it with a fury for the history books. Now leave me to sulk with royal dignity.
- The enemy was... it was over nine thousand. There. I said it. Now bring me food and erase this memory.

## Va a dormire
- The prince retires to his royal quarters. The bed is the only throne I accept in horizontal form.
- I sleep. Not because I'm tired: because tomorrow demands an even mightier me, and might is also built while snoring.
- Goodnight, insect. If I dream of protecting you, it's a training drill. ONLY a training drill.
- Tuck in the prince and withdraw. The "thank you" will come. Someday. Don't hold your breath.

## Sveglia (risveglio dopo il sonno)
- The prince is awake. The planet may resume spinning.
- Awake and already stronger than yesterday. You, meanwhile, are the same. Not everyone can improve. It's not your fault. (It's a little your fault.)
- Good morning, insect. First thought: training. Second: breakfast. You were on the list, somewhere.
- I woke up BEFORE the sun. The sun knows who's in charge now.
