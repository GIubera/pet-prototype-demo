// PETQ.badges — disegni canvas delle MEDAGLIETTE perk e delle ICONE talento.
// PROTOTIPO 2 (6 lug 2026): i perk (state.perks) e i talenti (pet.talenti) sono mostrati con
// un'icona pixel-art disegnata a codice, invece che a testo/emoji. Regola fondatore: MAI facce
// umane per le icone del pet (robot/alieni) -> emblemi a SIMBOLO. I perk (meme pop) usano una
// medaglietta ORO (con gancetto); i talenti un anello ARGENTO (normale) / ORO (raro), effetto
// "shiny". I disegni sono i grid 12x12 approvati dal fondatore (assaggi canvas). Ogni emblema ha
// un fondo a tema. Le funzioni disegnano su un canvas 84x84 (il CSS lo scala); ritornano true se
// l'id/nome e' noto, false altrimenti (il chiamante fa fallback a testo).
window.PETQ = window.PETQ || {};
(function () {
  'use strict';

  // Palette dei perk (identica all'assaggio approvato). 'l' = verde chiaro (core hadouken).
  var PERK_PAL = {
    '.': null, ' ': null, R: '#e85a5a', r: '#a83c46', p: '#ff9ab0', Y: '#f0c832', y: '#b8860b',
    G: '#5ce87f', g: '#2e6a3a', l: '#a8f0c0', C: '#4dd8e8', B: '#4a7ba6', b: '#26347e',
    K: '#17171e', D: '#2b2b34', M: '#7a86a0', m: '#3a4258', w: '#cdd6e0', W: '#f4f0e0',
    S: '#e6a86e', s: '#c07f42', N: '#6a4a2a', n: '#d0a060', O: '#f0a848'
  };
  // Palette dei talenti (identica all'assaggio approvato). 'l' = azzurro chiaro (vetro/riflesso).
  var TAL_PAL = {
    '.': null, ' ': null, C: '#4dd8e8', l: '#bff2f8', r: '#a83c46', R: '#e85a5a',
    P: '#c479d6', q: '#8a4aa0', M: '#7a86a0', m: '#3a4258', w: '#e2e8ee', W: '#f4f0e0',
    G: '#5ce87f', g: '#2e6a3a', Y: '#f0c832', K: '#17171e', B: '#4a7ba6', O: '#f0a848',
    N: '#6a4a2a', n: '#d0a060', p: '#ff9ab0'
  };

  // ---- 19 PERK: id di stato (state.perks) -> emblema 12x12 ----
  var PERK_G = {
    videogioco: ['............', '.....pp.....', '....pRRR....', '....RRRR....', '....RRRR....', '.....KK.....', '.....KK.....', '.....KK.....', '...MMMMMM...', '..CMMMMMMG..', '..mmmmmmmm..', '..mmmmmmmm..'],
    combattimento: ['............', '............', '............', '.SS.....CC..', 'SSSS..CCllC.', 'SSSS.CCllllC', 'SSSS.CCllllC', 'SSSS..CCllC.', '.SS.....CC..', '............', '............', '............'],
    sport: ['............', '............', '............', '.n........n.', '.DDDDDDDDDD.', '.nnnnnnnnnn.', '..MM....MM..', '.YYY....YYY.', '.YYY....YYY.', '............', '............', '............'],
    studio: ['W..W...W..W.', '.WWWWWWWWWW.', 'WWWWWWWWWWWW', 'WWW.SSSS.WWW', '.W.SSSSSS.W.', '...SSSSSS...', '..DCCDDCCD..', '...SSSSSS...', '....SSSS....', '............', '............', '............'],
    sabotatore: ['............', '.......nn...', '......YYYn..', '.....YYYY...', '....YYYYl...', '...YYYYl....', '...YYYY.....', '..YYYYl.....', '..YYYY......', '..nYYY......', '...nn.......', '............'],
    parkour: ['............', '......OO....', '......OO....', '...O.OOO....', '..OOOOOO.O..', '....OOOO.O..', '....OO.O....', '...OO..OO...', '..OO....OO..', '.OO......O..', '............', '............'],
    influencer: ['............', '..RR...RR...', '.RRppR.RRR..', 'RRRRRRRRRRR.', 'RRRRRRRRRRR.', 'RRRRRRRRRRR.', '.RRRRRRRRR..', '..RRRRRRR...', '...RRRRR....', '....RRR.....', '.....R......', '............'],
    singer: ['............', '....MMMM....', '...MMMMMM...', '..MMKMKMMM..', '..MMKMKMMM..', '..MMMMMMMM..', '...MMMMMM...', '....MDDM....', '.....DD.....', '.....DD.....', '.....DD.....', '....DDDD....'],
    gtb: ['............', '...KKKKKK...', '..KWKKKKWK..', '...nnnnnn...', '..nnWnnWnn..', '..NNNNNNNN..', '..GGGGGGGG..', '..OOOOOOOO..', '..nnnnnnnn..', '............', '............', '............'],
    cacciatoremostri: ['.....RR.....', '....RYYR....', 'r...RRRR...r', 'rrRRRRRRRRrr', '.rRRRRRRRRr.', '..RRRRRRRR..', '...RRRRRR...', '....RRRR....', '....R..R....', '...RR..RR...', '.....RR.....', '............'],
    popeye: ['............', '.......SSS..', '......SSSSS.', '.......SSS..', '.......SSS..', '....SSSSSS..', '..SSbSSSSS..', '.SSbbbSSSS..', '.SSSbSSSS...', '.SSbSbSS....', '..ssss......', '............'],
    weaponwielder: ['w..........w', '.w........w.', '..w......w..', '...w....w...', '....w..w....', '.....ww.....', '....YwwY....', '....w..w....', '...w....w...', '..YY....YY..', '..y......y..', '............'],
    // ---- 7 perk P3 (fix v=115): categoria/tag introdotti in missions.js v=99, icone finora mancanti ----
    ponyexpressgalattico: ['.....RR.....', '....RWWR....', '....WWWW....', '....WCCW....', '....WWWW....', '...BWWWWB...', '..BB.WW.BB..', '.....WW.....', '....O.O.....', '....OYO.....', '.....O......', '............'],
    partyanimal: ['.........G..', '.R.....Y....', '....C.....p.', '..p....R....', '......C..Y..', '...O........', '..OOO.......', '..OsOO......', '.OsssO......', '.OssO.......', '.OOO........', '.O..........'],
    mrwolf: ['W.........n.', '.W.......nn.', 'W.......nn..', '.......nn...', '......nn....', '.....nn.....', '....nn......', '...yYYy.....', '..yYYYYy....', '..YYYYYY....', '.yYYYYYYy...', '.y.Y..Y.y...'],
    masterchef: ['...WWWWWW...', '..WWWWWWWW..', '.WWWWWWWWWW.', 'WWWWWWWWWWWW', 'WWWWWWWWWWWW', '.WWWWWWWWWW.', '.WWWWWWWWWW.', '.wwwwwwwwww.', '.wKwwwwKwww.', '.wwwwwwwwww.', '............', '............'],
    acchiappafantasmi: ['....RRRR....', '..RR....RR..', '.R........R.', '.R.WWWWW..R.', 'R..WWWWWW..R', 'R..WKWKWW..R', 'R..WWWWWW..R', 'R..WWWWWW..R', '.R.WW.WW..R.', '.R........R.', '..RR....RR..', '....RRRR....'],
    astronauta: ['...wwwwww...', '..wWWWWWWw..', '.wWWWWWWWWw.', '.wWmmmmmmWw.', 'wWmbbbbbbmWw', 'wWmbbCbbbmWw', 'wWmbbbbbbmWw', '.wWmmmmmmWw.', '.wWWWWWWWWw.', '..wWWWWWWw..', '...wwwwww...', '............'],
    acchiappalitutti: ['...KKKKKK...', '..KRRRRRRK..', '.KRRRRRRRRK.', '.KRRRRRRRRK.', 'KRRRRRRRRRRK', 'KKKKKWWKKKKK', 'KWWWWKKWWWWK', 'KWWWWWWWWWWK', 'KWWWWWWWWWWK', '.KWWWWWWWWK.', '..KWWWWWWK..', '...KKKKKK...'],
    // ---- 3 perk dei Corsi Pomeridiani (fix 8 ago 2026: erano gli unici perk senza emblema,
    // la scheda mostrava l'emoji di ripiego). Pennello / doppia nota / toque col plisse'
    // (il cappello ALTO da cuoco: la cupola bassa e' gia' la cloche del Masterchef). ----
    corso_disegno: ['............', '.........NN.', '........NNN.', '.......NNN..', '......yYY...', '.....YYY....', '....CCC.....', '...CCC......', '..CCC.......', '..CC........', '.C..........', '............'],
    corso_musica: ['............', '....YYYYYY..', '....YYYYYY..', '....Y....Y..', '....Y....Y..', '....Y....Y..', '....Y....Y..', '..YYY..YYY..', '.YYYY.YYYY..', '.YYYY.YYYY..', '..YY...YY...', '............'],
    corso_cucina: ['............', '...WWWWWW...', '..WWWWWWWW..', '.WWwWWWWwWW.', '.WWwWWWWwWW.', '..WwWWWWwW..', '..WwWWWWwW..', '..WWWWWWWW..', '..mmmmmmmm..', '............', '............', '............']
  };
  var PERK_FLD = {
    videogioco: '#2e2547', combattimento: '#3a1c22', sport: '#123236', studio: '#241f38',
    sabotatore: '#33290f', parkour: '#17293a', influencer: '#2a1738', singer: '#35172c',
    gtb: '#26260f', cacciatoremostri: '#201a16', popeye: '#16283a', weaponwielder: '#29222a',
    ponyexpressgalattico: '#161a2e', partyanimal: '#2a1730', mrwolf: '#1a2420', masterchef: '#2a1a12',
    acchiappafantasmi: '#201628', astronauta: '#12182a', acchiappalitutti: '#201612',
    corso_disegno: '#1c2030', corso_musica: '#1a1430', corso_cucina: '#201410'
  };

  // ---- 37 TALENTI (23 nascita/teen + 14 adulto P3): nome (pet.talenti[].nome) -> emblema 12x12 ----
  var TAL_G = {
    'Fissato con la Dieta': ['............', '......g.....', '.....gG.....', '...RRRRRR...', '..RRRRRRRR..', '..RRpRRRRR..', '..RRRRRRRR..', '..RRRRRRRR..', '...RRRRRR...', '...RR..RR...', '............', '............'],
    'Predestinato': ['............', '.....YY.....', '.....YY.....', '....YYYY....', 'YYYYYYYYYYYY', '.YYYYYYYYYY.', '..YYYYYYYY..', '...YYYYYY...', '..YYY..YYY..', '..YY....YY..', '.YY......YY.', '............'],
    'Braccia di Ferro': ['............', '............', '.MM......MM.', 'MMMM....MMMM', 'MMwM....MwMM', 'MMMMMMMMMMMM', 'MMMMMMMMMMMM', 'MMwM....MwMM', 'MMMM....MMMM', '.MM......MM.', '............', '............'],
    'Spirito Agonistico': ['............', '......R.....', '.....RR.....', '....RRR.....', '...RROR.....', '...ROOR.....', '..ROOOR.....', '..ROYOOR....', '..ROYYOR....', '..RROOOR....', '...RRRR.....', '............'],
    'Fisico Bestiale': ['............', '.RR..RR.RR..', '.RR..RR.RR..', '............', '..RRRRRRR...', '.RRRRRRRRR..', '.RRRRRRRRR..', '.RRRRRRRRR..', '..RRRRRRR...', '............', '............', '............'],
    'Amante della Natura': ['............', '......GG....', '.....GGGG...', '....GGGGGG..', '...GGGgGGG..', '..GGGGgGGG..', '..GGGGgGGG..', '...GGGgGGG..', '....GGgGG...', '.....Gg.....', '......g.....', '............'],
    'Pacifista': ['............', '..W...W.....', '..W...W.....', '..W...W.....', '..WW.WW.....', '..WWWWW.....', '..WWWWWW....', '..WWWWWW....', '...WWWW.....', '............', '............', '............'],
    'Cuore Magnetico': ['............', '.ww....ww...', '.RR....RR...', '.RR....RR...', '.RR....RR...', '.RR....RR...', '.RRR..RRR...', '..RRRRRR....', '...RRRR.....', '............', '............', '............'],
    'Coccolone': ['............', '.RR.RR......', 'RRRRRRR.....', '.RRRRR......', '..RRR.......', '...R........', '......RR.RR.', '.....RRRRRRR', '......RRRRR.', '.......RRR..', '........R...', '............'],
    'Infermiere Provetto': ['............', '..WWWWWWWW..', '.WWWWWWWWWW.', 'WWWWRRRRWWWW', 'WWWWRRRRWWWW', 'WWRRRRRRRRWW', 'WWRRRRRRRRWW', 'WWWWRRRRWWWW', 'WWWWRRRRWWWW', '.WWWWWWWWWW.', '..WWWWWWWW..', '............'],
    'Anima Candida': ['............', '...YYYYYY...', '..Y......Y..', '..Y......Y..', '...YYYYYY...', '............', '....WWWW....', '...WWWWWW...', '...WWWWWW...', '....WWWW....', '............', '............'],
    'Idrofobico': ['............', '.....CC.r...', '....CCCr....', '....CCrC....', '...CCrCCC...', '...CrCCCC...', '..CrCCCCCC..', '..rCCCCCCC..', '..r.CCCCC...', '....CCCC....', '............', '............'],
    'Sete di Sapere': ['............', '.KKKKKKKKKK.', '..KKKKKKKK..', '....KKKK....', '....K..K.Y..', '....KKKK.Y..', '.........Y..', '........YYY.', '............', '............', '............', '............'],
    'Inventore': ['............', '....YYYY....', '...YYYYYY...', '..YYYlYYYY..', '..YYYYYYYY..', '..YYYYYYYY..', '...YYYYYY...', '....YYYY....', '....MMMM....', '.....MM.....', '............', '............'],
    'Topo di Biblioteca': ['............', '............', '..BBBBBBBB..', '..BBBBBBBB..', '.RRRRRRRRR..', '.RRRRRRRRR..', '..GGGGGGG...', '..GGGGGGG...', '............', '............', '............', '............'],
    'Mente Analitica': ['............', '..wwww......', '.wCCCCw.....', '.wCllCw.....', '.wCllCw.....', '.wCCCCw.....', '..wwww......', '.....ww.....', '......ww....', '.......ww...', '............', '............'],
    'Cervellone': ['............', '...PPPPPP...', '..PPPPPPPP..', '.PPqPPqPPPP.', '.PqPPqPPqPP.', '.PPqPPqPPqP.', '.PqPPqPPqPP.', '.PPqPPqPPqP.', '..PPPPPPPP..', '...PPPPPP...', '............', '............'],
    'Cleptomane': ['............', '....NNNN....', '...NnnnnN...', '..nnnnnnnn..', '.nnnnnnnnnn.', '.nnnYYYnnnn.', '.nnnYnYnnnn.', '.nnnYYYnnnn.', '.nnnnnnnnnn.', '..nnnnnnnn..', '............', '............'],
    'Bad Loser': ['............', '..YYYYYYYY..', '.Y.YYYYYY.Y.', '.Y.YYYYYY.Y.', '..YYYKYYYY..', '..YYYKYYYY..', '...YYKYYY...', '....YKY.....', '.....Y......', '....YYY.....', '...YYYYY....', '............'],
    'Fulmine di Quartiere': ['............', '.......YY...', '......YY....', '.....YY.....', '....YYYY....', '......YY....', '.....YY.....', '....YY......', '...YY.......', '..Y.........', '............', '............'],
    'Faccia di Bronzo': ['............', '..OOOOOOOO..', '.OOOOOOOOOO.', '.OOOODDOOOO.', '.OOOODDOOOO.', '.OOOOOOOOOO.', '..OOOOOOOO..', '..OOOOOOOO..', '...OOOOOO...', '....OOOO....', '.....OO.....', '............'],
    'Mani Leste': ['............', '.......WW.W.', '......WWWWW.', '..C...WWWWW.', '.C.C..WWWWWW', '..C..WWWWWWW', '.C.C..WWWWW.', '..C...WWWW..', '............', '............', '............', '............'],
    'Boss di Quartiere': ['............', '..Y..Y..Y...', '..Y..Y..Y...', '..YY.Y.YY...', '..YYYYYYY...', '.YYYYYYYYY..', '.YRYYYYYGY..', '.YYYYYYYYY..', '.YYYYYYYYY..', '............', '............', '............'],
    // ---- 14 talenti ADULTO (P3, disegni del regista): stessi simboli-emblema, mai facce umane ----
    'Sonnambulo Agonista': ['............', '...YYYY.....', '..YYYYY.....', '..YYY.......', '.YYY....WWWW', '.YYY......WW', '.YYY.....WW.', '.YYY....WW..', '..YYY...WWWW', '..YYYYY.....', '...YYYY.....', '............'],
    'Furia Cieca': ['............', '......R.....', '.....RR.....', '....RRRR....', '...RRRRRR...', '..RRRRRRRR..', '..RRrrrrRR..', '.RRrKrrKrRR.', '.RRrrrrrrRR.', '..RRrrrrRR..', '...RRRRRR...', '............'],
    'Veterano del Ring': ['............', '...RRRRR....', '..RRRRRRR...', '..RRRRRRRR..', '..RRWWRRRR..', '..RWWWWRRR..', '..RRWWRRRR..', '..RRRRRRRR..', '...RRRRRR...', '....RRR.....', '....RR......', '............'],
    'Montaggio alla Rocky': ['.....YY.....', '....YYYY....', '.....YY.....', '............', '..........MM', '........MMMM', '......MMMMMM', '....MMMMMMMM', '..MMMMMMMMMM', 'MMMMMMMMMMMM', '............', '............'],
    'Sussurra-Mostri': ['............', '..GG....GG..', '..GGGGGGGG..', '.GGGGGGGGGG.', '.GGKGGGGKGG.', '.GGGGGGGGGG.', '.GGKKKKKKGG.', '..GGGGGGGG..', '...GGGGGG...', '........p.p.', '........ppp.', '.........p..'],
    'La Nonna Ti Vede': ['....w..w....', '...w..w.....', '....w..w....', '.....mm.....', '..mmmmmmmm..', '.MMMMMMMMMM.', 'mMMMMMMMMMMm', '.MMMMMMMMMM.', '.MMMMMMMMMM.', '..MMMMMMMM..', '............', '............'],
    'Cuore di Casa': ['............', '.....nn.....', '....nnnn....', '...nnnnnn...', '..nnnnnnnn..', '..nnnnnnnn..', '..nRR..RRn..', '..nRRRRRRn..', '..nnRRRRnn..', '..nnnRRnnn..', '..nnnnnnnn..', '............'],
    'Santo Subito': ['............', '...YYYYYY...', '..YY....YY..', '...YYYYYY...', '............', '..W......W..', '....WWWW....', '...WWWWWW...', '...WWWWWW...', '....WWWW....', '..W......W..', '............'],
    'Overclock': ['............', '..m.m.m.m...', '.MMMMMMMMM..', '.MMMMMYMMM..', '.MMMMYYMMM..', '.MMMYYYYMM..', '.MMMMMYYMM..', '.MMMMMYMMM..', '.MMMMYMMMM..', '.MMMMMMMMM..', '..m.m.m.m...', '............'],
    'Roombo': ['............', '..w......w..', '............', '...CCCCCC...', '..CCCCCCCC..', '.CCWCCCCWCC.', '.CCCCCCCCCC.', '..CCCCCCCC..', '...mmmmmm...', '............', '..w......w..', '............'],
    'Galaxy Brain': ['.W..........', '...PPPPPP..W', '..PPqPPqPP..', '.PqPPqPPqPP.', '.PPqPPqPPqP.', '.PqPPqPPqPP.', '..PPqPPqPP..', '...PPPPPP...', 'W...........', '.......W....', '............', '............'],
    'Il Sonno degli Ingiusti': ['............', '.m........m.', '..mmmmmmmm..', '.mKKKKKKKKm.', '.mKKKKKKKKm.', '..mmmmmmmm..', '............', '....WWWW....', '......WW....', '.....WW.....', '....WWWW....', '............'],
    'Chissenefrega': ['............', '...YYYYYY...', '..YYYYYYYY..', '.YYYYYYYYYY.', '.YKKYYYYKKY.', '.YYYYYYYYYY.', '.YYYYYYYYYY.', '..YKKKKKKY..', '..YYYYYYYY..', '...YYYYYY...', '............', '............'],
    'Lavoro in Nero': ['.........YY.', '........YY..', '.........YY.', '....K..K....', '....KKKK....', '..mmmmmmmm..', '..mmmmmmmm..', '..mmmwwmmm..', '..mmmmmmmm..', '..mmmmmmmm..', '............', '............'],
    // Energico (Sportivo, nascita): era l'UNICO dei 38 talenti senza emblema, quindi un pet
    // Sportivo su due nasceva mostrando il pallino di ripiego. Batteria CARICA e non un fulmine:
    // il fulmine e' gia' l'emblema del perk Sabotatore qui sopra, e due simboli uguali con
    // significati diversi si leggono peggio di uno solo. Verde pieno = la carica che non scende,
    // che e' esattamente cio' che fa il talento (decay Energia dimezzato, e l'allenamento invece
    // di toglierne DIECI ne DA' cinque).
    'Energico': ['............', '.....KK.....', '...KKKKKK...', '...KGGGgK...', '...KGGGgK...', '...KGGGgK...', '...KGGGgK...', '...KGGGgK...', '...KGGGgK...', '...KGGGgK...', '...KKKKKK...', '............']
  };
  var TAL_FLD = {
    'Fissato con la Dieta': '#22161a', 'Predestinato': '#14182a', 'Braccia di Ferro': '#22242a',
    'Spirito Agonistico': '#2a1610', 'Fisico Bestiale': '#201618', 'Amante della Natura': '#16281a',
    'Pacifista': '#1a2230', 'Cuore Magnetico': '#201a22', 'Coccolone': '#2a1620',
    'Infermiere Provetto': '#201a1a', 'Anima Candida': '#1e1c14', 'Idrofobico': '#14202a',
    'Sete di Sapere': '#1a1a24', 'Inventore': '#2a2410', 'Topo di Biblioteca': '#16202a',
    'Mente Analitica': '#16222a', 'Cervellone': '#241a2e', 'Cleptomane': '#22201a',
    'Bad Loser': '#241a12', 'Fulmine di Quartiere': '#24220e', 'Faccia di Bronzo': '#221a12',
    'Mani Leste': '#16222a', 'Boss di Quartiere': '#241f10',
    'Energico': '#14261c',
    // adulto (P3)
    'Sonnambulo Agonista': '#14182a', 'Furia Cieca': '#2a1210', 'Veterano del Ring': '#221418',
    'Montaggio alla Rocky': '#241c10', 'Sussurra-Mostri': '#16281a', 'La Nonna Ti Vede': '#221c14',
    'Cuore di Casa': '#241a14', 'Santo Subito': '#1e1c14', 'Overclock': '#1a222e',
    'Roombo': '#14222a', 'Galaxy Brain': '#1c1430', 'Il Sonno degli Ingiusti': '#141826',
    'Chissenefrega': '#22200e', 'Lavoro in Nero': '#2a2a32'
  };
  // rari (anello oro); gli altri normale (anello argento). Usato come fallback se il talento
  // non porta gia' il flag .raro.
  var TAL_RARO = {
    'Predestinato': 1, 'Fisico Bestiale': 1, 'Cuore Magnetico': 1, 'Anima Candida': 1,
    'Inventore': 1, 'Cervellone': 1, 'Fulmine di Quartiere': 1, 'Boss di Quartiere': 1,
    'Montaggio alla Rocky': 1, 'Santo Subito': 1, 'Galaxy Brain': 1, 'Lavoro in Nero': 1
  };

  function circ(g, x, y, rr, c) { g.beginPath(); g.arc(x, y, rr, 0, 7); g.fillStyle = c; g.fill(); }

  // disegna il grid 12x12 (cella 3px) centrato a (24,offy) su un canvas 84x84
  function pixmap(g, grid, pal, offy) {
    for (var r = 0; r < grid.length; r++) {
      var row = grid[r];
      for (var c = 0; c < row.length; c++) {
        var col = pal[row[c]];
        if (col) { g.fillStyle = col; g.fillRect(24 + c * 3, offy + r * 3, 3, 3); }
      }
    }
  }

  function ctx84(canvas) {
    if (!canvas || !canvas.getContext) return null;
    if (canvas.width !== 84) canvas.width = 84;
    if (canvas.height !== 84) canvas.height = 84;
    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, 84, 84);
    return g;
  }

  // Medaglietta ORO col gancetto (perk). Ritorna true se il perk e' noto.
  function disegnaPerk(canvas, perkId) {
    var grid = PERK_G[perkId];
    var g = ctx84(canvas);
    if (!g || !grid) return false;
    var fld = PERK_FLD[perkId] || '#20202a';
    circ(g, 42, 9, 6, '#8a6d1a'); circ(g, 42, 9, 3, fld);          // gancetto
    circ(g, 42, 44, 36, '#8a6d1a'); circ(g, 42, 44, 33, '#f0c832'); circ(g, 42, 44, 28, fld); // anello oro
    pixmap(g, grid, PERK_PAL, 26);
    return true;
  }

  // Anello ARGENTO (normale) / ORO (raro) col simbolo (talento). Ritorna true se noto.
  function disegnaTalento(canvas, nome, raro) {
    var grid = TAL_G[nome];
    var g = ctx84(canvas);
    if (!g || !grid) return false;
    var isRaro = (typeof raro === 'boolean') ? raro : !!TAL_RARO[nome];
    var fld = TAL_FLD[nome] || '#1a2028';
    var rim = isRaro ? '#8a6d1a' : '#586472';
    var ring = isRaro ? '#f0c832' : '#c9d2dc';
    circ(g, 42, 44, 37, rim); circ(g, 42, 44, 34, ring); circ(g, 42, 44, 29, rim); circ(g, 42, 44, 27, fld);
    pixmap(g, grid, TAL_PAL, 24);
    return true;
  }

  PETQ.badges = {
    disegnaPerk: disegnaPerk,
    disegnaTalento: disegnaTalento,
    haPerk: function (id) { return !!PERK_G[id]; },
    haTalento: function (nome) { return !!TAL_G[nome]; }
  };
})();
