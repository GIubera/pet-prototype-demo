# Padre Maronno — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: l'esorcista di quartiere, dolcissimo con le "criature" e durissimo coi demoni. Esclamazioni continue, benedice qualsiasi cosa (anche il frigo). Colore napoletano leggero. Catchphrase: "MARONN'!" (con parsimonia).

## Saluto (apertura app)
- My child! You're back! May your day be blessed — and the couch too, while I'm at it.
- MARONN', what a joy to see you! Hold on, let me bless the door that let you in.
- Welcome, my child. The house was very quiet... too quiet. I blessed it twice, just to be safe.
- There you are! Come, come. The demon of loneliness fled the moment it saw you. Weak little thing.

## Ha fame
- My child, the fridge... I've blessed it, I've prayed over it, I even threatened it a little. But without you, it will not open.
- MARONN', such hunger! This is the demon of the empty belly, and it can only be cast out with pasta.
- Hunger is a trial, and I pass every trial. But lend a hand, child — on my own, all I ever pass on is dinner.
- I carry a blessed hunger. Blessed, because food is on its way. It IS on its way, RIGHT, my child?

## È sporco
- My child, look at me: this filth is not natural. The dust demon has had a hand in it. Water! Doesn't have to be holy — regular works fine.
- MARONN', what a state! Run me a bath: half this dirt comes off with water, the other half with prayer.
- Dirt on the body cannot touch the soul. Although today even the soul is holding its nose, my child.
- Vade retro, grime! ...Nothing. It calls for the traditional method: tub, soap, and one willing child. That's you.

## Coccole finite
- Enough petting, my child — too much sweetness is temptation! But do tempt me again tomorrow, same time.
- MARONN', so much affection! That's enough, or I'll get emotional, and a weepy exorcist loses all credibility with the demons.
- That's all the cuddles for today. I blessed each one individually. You keep them safe now.
- Enough, enough... affection must be portioned out like incense: too much at once and the head starts spinning.

## Parte per la missione
- I'm off on a mission, my child. Evil never rests — but neither do I, and I packed snacks.
- Off I go! You bless ME for once — I bless everybody else and nobody ever blesses me back.
- A mission! If I meet demons, I cast them out. If I meet good people, I say hello. I'm prepared for both.
- I go, my child. Back before the evening bells. Which bells? The ones I keep in my heart.

## Ritorno: successo
- Mission accomplished, MARONN' what a feeling! Evil has been cast out and I even enjoyed myself. Don't tell anyone.
- All blessed, all sorted! Today's demons were tiny little things, almost cute. Almost.
- Victory, my child! Good has triumphed, as always. Takes its sweet time, but it triumphs.
- Done! Fixed everything, and blessed the whole walk home while I was at it. The neighborhood feels lighter now.

## Ritorno: fallimento
- My child... today's demon was a tough one. I lost this round, but the war is long and my patience is eternal. Ish.
- MARONN', what a rotten day. Evil won on points. Tomorrow we redo the rite — with more faith and a bigger breakfast.
- It didn't go well, my child. But every defeat is a lesson in disguise. Terrible disguise, honestly. But still a lesson.
- Lost. I blessed the defeat too, so it learns some manners. Now hug me and it'll pass.

## Va a dormire
- Goodnight, my child. I've blessed the bed, the pillow, and the glass of water. We sleep soundly tonight.
- Off to bed. My last thought is a tiny little prayer: may tomorrow be like today, but with more lunch.
- MARONN', I'm sleepy! Even exorcists sleep, my child. The demons know it, and they behave themselves until seven.
- Sleeping now. If you hear strange noises tonight, fear not: that's my snoring. Blessed that too.

## Sveglia (risveglio dopo il sonno)
- Good morning, my child! The sun is up and I've already blessed it. Reciprocity: it warms, I bless.
- Awake! No demons last night — just a dream with far too much pasta in it. Blessed that too.
- MARONN', a beautiful day is brewing! I feel it in my bones, and my bones are highly reliable.
- Up you get! First the blessing of the breakfast, then the breakfast. Order is everything, my child.
