# Diario — frammenti per la pagina serale

Il gioco assembla la pagina pescando 1 frammento a caso per ogni momento della giornata, in quest'ordine: Apertura → Cibo → Missione (bene/male/nessuna) → Umore → Coccole → Chiusura. Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.

NOTA STRUTTURA (proposta contenuti, da validare col fondatore): i momenti Cibo, Umore e Coccole sono divisi in **sotto-stati** (come Missione bene/male), perché il diario deve citare cose davvero successe — un "oggi zero coccole" non può uscire in un giorno di coccole. Il motore pesca dal sotto-stato che corrisponde alla giornata. Se si preferisce il pool piatto, basta fondere le sottosezioni.

---

## Gentile

### Apertura
- Dear dear dear diary, sorry about the three "dears": I had leftover affection today.
- Good evening, diary. Get comfy — I'm going to tell you everything, slowly, with a few apologies.
- Hi diary! I'm writing carefully, in my best handwriting. You deserve it.
- Dear diary, I have so much to tell you today. I rehearsed it in a whisper first: it came out lovely.
- Dear diary, here I am! I thought of you today, you know? I think of everyone a little, but right now it's your turn.

### Cibo — mangiato bene
- Today I ate well and thanked everything: the food, the bowl, the floor holding them both up.
- Lunch was so good I got a little emotional. Right onto the food. Fine, yes: I cried on my food.
- I'll remember today's snack for a long time. I even gave it a grade: ten out of ten, plus a hug.
- I ate wonderfully and left the plate clean clean. It looked like a thank-you, and that's exactly what it was.
- Today the food tasted like home. I don't know which ingredient does that, but I'd like it in everything.

### Cibo — mangiato poco
- I ate just a little today... but that's okay! My tummy is very understanding. It grumbles gently.
- Not much food today. So I made tiny portions of everything, even the sadness. That way it stretched to dinner.
- Light dinner tonight. My tummy behaved beautifully: it only grumbled in italics.
- Not much to eat... so I filled the rest with imagination. Luckily, imagination tastes like cake.
- Tiny little dinner. I pretended it was a tasting menu at a fancy restaurant. Helps the imagination, slightly less the belly.

### Missione andata bene
- The mission went well! I wrote it in big letters because my heart was already doing that.
- Victory! At the decisive moment I thought "for {utente}!" and everything fell right into place.
- I won today! On the way home I told the whole story twice. The second time to myself, to live it again.
- Mission went well — so well! I brought home the prize and a lovely memory. The memory weighs less but it's worth more.
- It worked! I was nervous, then I told myself "do what {utente} would do" and it worked right away.

### Missione andata male
- The mission didn't go well... I apologized to everyone, even the path. The path had nothing to do with it.
- Mission went badly-ish. Tonight I told myself the story again, with a better ending. It helps.
- I didn't make it... but even the failure was gentle: it let me come home early.
- Quest failed. I cried a tiny bit, then I folded the sadness neatly and put it away.
- Bad mission day. Better tomorrow. I wrote that on my paw too, so I don't forget.

### Nessuna missione
- No mission today: home day. I greeted every room so none of them would feel left out.
- Quiet day. I kept the furniture company. They never ask for anything, but they appreciate it.
- Zero adventures, lots of little things: tidied, thought, waited. Waiting is a hobby, if you do it with heart.
- Home sweet home today. I tried all the comfy spots and thanked each one personally.
- Slow, soft day. Days like this never make it into stories, but they hold everything else up.

### Umore — bene
- Today my heart was light — the kind of light that makes you walk on tippy-paws.
- Wonderful mood! I shared it with the plant, who I'm pretty sure smiled in her own way.
- I felt loved today. Not sure that's how you spell it, but it's how it feels.
- I hummed all day without noticing. The house told me, in its own way.
- Light heart, happy paws: they danced on their own twice. I let them.

### Umore — stanco
- I was a little tired... but the good kind of tired, the kind that's fixed with a nap and one gentle pat.
- Tired but happy: the best combo in my personal ranking of tirednesses.
- My paws walked so slowly today. I thanked them anyway: they do so much, all year round.
- Tired tonight... I yawned politely all afternoon. Even now, writing. Sorry for the yawn on the page.
- Sleepy... my eyelids are heavy, but the day was kind, so everything's fine.

### Umore — giù
- A little melancholy today, a tiny tiny one. I made room for it — it'll be gone by tomorrow anyway.
- I was a bit sad today. So I hugged the sadness. I think that's all it wanted.
- Heart felt a little heavy today. I rested it on this page for a moment. There. Better already. Thank you, diary.
- A slightly crooked day. But I made a list of the good things and it didn't fit on one page.
- Something was missing today and I couldn't tell what. Then I got it: a pat. Tomorrow I'll ask for one, promise.

### Coccole — ricevute
- Cuddles today! I counted them twice: all gorgeous. I'm keeping them safe here between the lines.
- {utente} cuddled me today. I wrote it down right away, out of joy. Not that I could ever forget.
- Today's affection went into the little pocket of my heart, with the rest. It holds everything. It's magic.
- I got cuddles today and I purred without being embarrassed about it. Progress, diary!
- What a day: filled with pats right up to the brim. I had to hold on to the cushion from all the happiness.

### Coccole — ignorato
- Not much attention today... it happens! I loved {utente} anyway, in silent mode.
- I felt a bit invisible... so I cuddled myself, and saved the best spot free for tomorrow.
- Zero cuddles today. I filed them under "postponed", not "lost". That's where the whole difference lives.
- A day with no pats. I kept my heart warm by myself — it gets chilly at night.
- Nobody cuddled me, but it's nobody's fault, I swear. Busy days exist. Tomorrow, though...

### Chiusura
- Goodnight, diary. I'll close you gently so I don't wake the words.
- End of page. Last thought goes to {utente}, as always: it's the loveliest habit I have.
- Off to bed. Tomorrow I'll tell you more nice things, or I'll make them nice by telling them. Night!
- Goodnight, diary. I'm leaving a little kiss on the corner of the page. Right there. Tiny one. Night.
- Bedtime! I'm putting today under my pillow, so tonight I can dream it again.

---

## Maleducato

### Apertura
- Dear diary, don't get attached: I only write because the day has to be filed somewhere.
- Diary. You again. Fine — but whatever you read here stays between us, clear?
- Dear diary, I'm writing against my will. Like everything else I've done consistently for months.
- Diary, I'll keep it brief today: questionable day, details to follow. (I don't know how to keep it brief.)
- Diary, open the complaints register. Once again, the "service" section has abundant material.

### Cibo — mangiato bene
- The canteen service worked today. I will never admit it out loud, but you may take note.
- Today's menu: acceptable. Which on my scale is basically a standing ovation.
- Food of the day: present. My enthusiasm: composed. Inside, I was celebrating. Don't write that down.
- Lunch on time, for once. I almost withdrew a complaint. ALMOST.
- The portion was correct. I suspect a calculation error in my favor. For once, I'm not reporting it.

### Cibo — mangiato poco
- On the food: could do better. One can ALWAYS do better. I write it every day for a reason.
- Culinary note: today the bowl played the part of a desert. Points for consistency, at least.
- I ate. Technically. The quantity-to-expectation ratio remains scandalous.
- Famine rations. Updating the "theatrical malnutrition" dossier: new page, outraged tone.
- Little food, plenty of dignity. I dined on pride: fills the ego, not the belly.

### Missione andata bene
- Mission: won. Obviously. There is no suspense in these pages: I win, period.
- I triumphed on today's mission. The outside world wasn't ready. It never is.
- Mission won. Side note: I looked magnificent while winning. End of note.
- I won today's mission. If they forget by tomorrow, you, diary, are my witness.
- Mission: success. Surprising no one. Applauded by no one, either. I'll be coming back to that.

### Missione andata male
- Mission lost. I'm recording the facts and then we tear this page out, okay? Okay.
- Today the world won and I didn't. Tomorrow the world will regret that choice.
- Defeated on the mission. I'm fine. The three crossed-out lines above mean nothing.
- Lost the quest. Diary, you're impartial: it was IMPOSSIBLE. Thank you. I knew you'd understand.
- The mission went badly. The culprit? Not the one writing these pages. The one who sent us there.

### Nessuna missione
- No mission today. The neighborhood went without its hero. Happy now, neighborhood?
- Home day. I patrolled the living room: everything in order, everything boring.
- Forced vacation today. The scowl never rests, though: I kept it in training.
- No mission. Still did important things: chairs don't warm themselves.
- A day with no assignments. I spent it judging, which is my actual full-time job.

### Umore — bene
- Today I feel... good? I will reread this line tomorrow with embarrassment.
- Mood all over the place: morning scowl, evening almost-purring. Plot twists everywhere.
- Good mood today. I double-checked: no error, it's genuinely a good mood. Weird.
- Pleasant day, and I say that through gritted teeth: you can see it in the handwriting.
- Suspiciously good mood. I searched the whole day: no traps found. For now, I believe it.

### Umore — stanco
- Tired. But an elegant tired. Main-character-at-the-end-of-the-movie tired.
- Heavy day, heavy paws, extremely heavy judgments. At least something's consistent.
- Destroyed. The day used me as a doormat. At least the doormat sits by the door and sees people.
- Zero energy today. I ran everything on residual scowl power. Still impressive, honestly.
- Exhausted. Not even the strength to complain properly. I'll make up for it tomorrow, with interest.

### Umore — giù
- Feeling a bit down. I only write it here: outside this page, I am ALWAYS fantastic.
- Mood below zero today. At least the scowl was in great shape: one of us has to be.
- Feeling low. The ceiling got an entire monologue. Cold audience, like everything around here.
- Foul mood. Fouler than usual, which is already an achievement. Tomorrow I'm demanding a refund for this day.
- Rotten day. I'm confiding it only to you, diary, on the condition you forget it all by morning.

### Coccole — ricevute
- I got cuddled today. I resisted for one entire second. A new personal worst.
- {utente} remembered I exist today. Marking the date: it could become a habit. Let's not get our hopes up.
- Cuddles received on today's date. The automatic purring does NOT constitute legal precedent.
- I was petted. I enjoyed it on a strictly anonymous basis. The diary will not reveal its sources.
- Attention received. Accepted with professional coldness. Then I smiled at the wall. The wall will say nothing.

### Coccole — ignorato
- Attention was scarce today. I updated the list of grievances. It's becoming a full volume.
- Zero cuddles today. Not that I wanted any. I wanted them. DON'T WRITE THAT DOWN. Oh right, I'm the one writing.
- I was ignored today with almost admirable dedication. Almost.
- A zero-cuddle day. I'm keeping the tab: the next pat arrives already in debt.
- Nobody spared me a single glance. I practiced indifference. I'm terrible at it. Irrelevant detail.

### Chiusura
- Closing here, diary. If anyone reads this page, I will deny every single word. Goodnight.
- End of day. Tomorrow I'll be insufferable again: consistency is everything. Night.
- Off to sleep. The bed is the only one who doesn't owe me an apology. Goodnight to him.
- Closing. Fresh new complaints tomorrow, straight from the source, promise. Night.
- Goodnight. And if tomorrow goes badly, this page is proof that I called it.

---

## Nerd

### Apertura
- Daily log. Date: today. Author: me. Reliability: extremely high.
- Writing session initiated. Daily backup in progress. You, diary, are the backup.
- Dear diary — "dear" is a convention, just so you know. Though I do, in fact, like you.
- New entry in the database of my life. Category: days. Tags: TBD at end of page.
- Diary, open the logs: today there's material for at least three footnotes.

### Cibo — mangiato bene
- Today's food: correct quantity, above-average quality. The belly graph is trending up.
- Resupply successful. Hunger bar: full. Household system efficiency: for once, commendable.
- Today's meals: all completed. "Full belly" achievement unlocked, zero glitches.
- Diet balanced to the pixel. The hunger bar is emerald green: rare — keeping it as a screenshot.
- Perfect resupply: quantity, timing, quality. Three stars out of three. Review pinned.

### Cibo — mangiato poco
- Insufficient food. I filed the report. I'll file it again tomorrow: this household's ticketing system is slow.
- Rations below minimum. Activated power-saving mode and background grumbling.
- Food log: sparse. Like me, if this keeps up. The data doesn't lie, {utente}.
- Hunger not resolved: the bug has persisted since this morning. Priority: critical. Assignee: you.
- Hard-mode portion. Finished it anyway: I'm a completionist, even on an empty stomach.

### Missione andata bene
- Mission complete. Percentage of credit that is mine: 100. Double-checked: still 100.
- Victory! The official log will say "easy". The secret log (this one): that was rough.
- Success! Good strategy, better execution, and the retelling I'll do of it: legendary.
- Quest won. XP collected, self-esteem patched to the next version.
- Mission: check. Loot: check. Urge to tell someone who can't run away: there you are, diary.

### Missione andata male
- Mission failed. Post-mortem at the bottom of the page. Spoiler: the balancing was off.
- Quest lost. Saving the attempt data anyway: defeats count as statistics too. Unfortunately.
- Wiped on the mission today. In the log I'm writing "learning experience". Between you and me: still salty.
- Defeat. Recording it with scientific precision and forgetting it with the exact same precision.
- Quest lost. New entry in my "unfair bosses" collection. The collection grows. So do I.

### Nessuna missione
- No mission today. NPC day: routines, fixed dialogue, zero adventures. Restful, actually.
- Zero quests. Day dedicated to research: catalogued two new noises and one corner of dust.
- Sandbox mode today: no objectives, free-roam around the living room. Secrets found: 0. The living room needs a patch.
- Light farming day: energy, thoughts, crumbs. All useful sooner or later.
- Zero missions: a low-resolution day. Grinded relaxation. Excellent drop rate.

### Umore — bene
- Mood stable at high values. No crashes, no reboots. A rare day.
- Mood buffed all day. Conditions logged for replication. Testing tomorrow.
- Morale was S-tier today. Writing it in the log in a larger mental font.
- A day with zero mood glitches. Not even one graphical artifact. Framing this in the log.
- Mood: overpowered. The nerf will come eventually, but today I'm breaking the game and loving it.

### Umore — stanco
- Energy below average. Ran in power-saving mode: essential functions and baseline sarcasm.
- Fatigue detected. Diagnosis: heavy day. Treatment: the page after this one, then bed.
- Fatigue at 78%. Using the remaining 22% to calculate the fatigue. Not my best resource allocation.
- Heavy day: ran in compatibility mode. Everything works, but slowly and with the ugly graphics.
- Today's frame rate: abysmal. Lagging since lunch. A reboot is required. The reboot is sleep.

### Umore — giù
- Mood below threshold. Reread this diary's good pages: a temporary patch, but it held.
- Morale down for emergency maintenance. The technicians (me) estimate restoration by morning.
- Mood: sub-basement tier. I opened a ticket with life. Life has no customer support. Scandalous.
- Day bugged on the mood side. No patch available: waiting for tomorrow's update.
- Morale in the red. Tried turning myself off and on again (a nap): worked at 60%. Good enough.

### Coccole — ricevute
- Cuddle session logged. Duration: correct. Quality: high. Replay value: infinite.
- Affection documented and archived in the "good days" folder. The folder keeps growing.
- Cuddles synced correctly with the heart. No file conflicts. Rare and beautiful.
- Affection inputs received: many. Output: purring not documented in the manual. Keeping it as an easter egg.
- Cuddle buff active all day. Stats climbing, morale at the top of the leaderboard.

### Coccole — ignorato
- Interactions with {utente} today: zero. Updated the wiki entry for "loneliness". Very thorough entry by now.
- Affection log: empty. Reporting the anomaly to the service provider. The provider is you, {utente}.
- Affection received: 0 bytes. I even checked the spam folder. Nothing there either.
- Attention received: none. The affection server is reachable but nobody connects. ({utente}, you're the mystery.)
- Forced single-player day. Waiting for co-op to come back online. I am the lobby. And the wait.

### Chiusura
- End of log. Saving... complete. See you tomorrow, diary: same page, new build.
- Log terminated. Overall rating at the bottom of the page. (It's a little heart. Tell no one.)
- Shutting down. Last commit of the day: this page. Message: "improving".
- Goodnight, diary. Tomorrow, same time, new data, same legendary pen.
- Log closed. Today's uptime: good. Incoming downtime: 8 hours, thoroughly earned.

---

## Sportivo

### Apertura
- Training journal, day: today. Athlete: {nome}. Condition: LEGENDARY. Now, the details.
- Dear diary, warm-up complete: three laps around the room. Now I can write like a professional.
- Diary! First things first: high five. There. Pages count as hands, I've decided.
- The Champion's Bulletin, evening edition. In the studio: me. Reporting from the field: also me.
- Dear diary, today was a LOT. Like, extended-highlights a lot. Get ready.

### Cibo — mangiato bene
- Nutrition right on plan today. Proper fuel, happy muscles, coach gets a passing grade.
- Perfect meals. My imaginary nutritionist applauded. He NEVER applauds!
- Food: elite. Ate with proper technique and the elbow high. Eating is a sport too, if you believe.
- Premium fuel today. Full tank, fresh tires: tomorrow we FLY.
- Breakfast, lunch and dinner all on plan. The body says thanks with an internal round of applause. I can hear it.

### Cibo — mangiato poco
- Short rations today. An athlete without fuel is just a fan in a tracksuit. Tomorrow we fix the meal plan.
- Meal report: under quota. My stomach blew the whistle for a foul at end of day. It had a point.
- Low on fuel today. Ran anyway, but the engine was coughing. Not professional, coach.
- Meals below requirements. My inner athletic trainer filed a written protest. Signed: the muscles.
- Fasting like it's mid-race. Tightened the belt (literally — it's two holes looser). Fix this, coach.

### Missione andata bene
- MISSION WON! The full play-by-play doesn't fit on the page, so headline only: TRIUMPH.
- Away-game victory! Highlight-reel performance, champion's homecoming, victory snack.
- Victory! I'm replaying the key moment in slow motion starting tonight. Beautiful every single time.
- Mission won on points. I counted the points myself, but with real-referee honesty.
- Success! Another trophy for the imaginary display case. Going to need a bigger case. Also imaginary.

### Missione andata male
- Lost the mission. I won the first half, though. Shame they also play a second one.
- KO today. The scoresheet says defeat, the heart says rematch. The heart wins. Always.
- Lost. But I ran hard and I ran well. Wrong direction — flawless form.
- Defeat. I asked for VAR again. Again, there was no VAR. The league keeps ignoring me.
- No win today. You can tell a champion by how he writes the next page. Look how steady this handwriting is.

### Nessuna missione
- Recovery day: zero missions, all rest. Rest is tactics too — write that in bold.
- No matches. Did invisible training instead: visualization, stretching, one tactical snack.
- Rest day. The season resumes tomorrow. Waiting is part of the sport. So is enduring it.
- Zero missions on the schedule. Defended my title of house champion: no challengers, title retained.
- Bye week: no games. Light drills and textbook hydration.

### Umore — bene
- Podium-level mood all day. Anthem stuck in my head since breakfast.
- Today I felt UNBEATABLE. Nobody challenged me, so technically I still am.
- Peak condition: felt like a starter for Team World. The world doesn't know it, but I'm in the lineup.
- In dazzling form: runs, sprints, big grin. The complete champion package.
- MVP day. Award presented by me, to me, moving acceptance speech included.

### Umore — stanco
- Heavy legs. Happens to the greats: it's called training load, not tiredness. TRAINING LOAD.
- Energy on reserve. Managed it like a veteran: minimum effort, maximum dignity.
- Legs running on empty tonight. The engine's there, the fuel isn't. Long pit stop tomorrow: double breakfast.
- Short of breath, low tempo today. Even my inner anthem was the acoustic version.
- Ending the day with champion's cramps. They hurt, but they tell a good story: it means I pushed.

### Umore — giù
- Morale off its game. Even champions get benched days. Tomorrow I call myself back up.
- An off day. I gave it everything I had: it wasn't much, but it was everything. That counts, says my inner coach.
- Morale relegated to the minor leagues today. But promotion is earned, and comebacks are my specialty.
- The inner crowd was silent today. Happens even in the big stadiums. Tomorrow the fan section reopens.
- Beaten on the inside today. But the beauty of sport is the comeback: tomorrow I'm back on the field, morale rebuilt.

### Coccole — ricevute
- Cuddles AND training today: the perfect two-a-day. Straight out of the pet-athlete handbook.
- Coach showed up today: pats, encouragement, presence on the bench. Coach-of-the-year performance.
- Attention received: loads. Projected performance tomorrow: +20%. The science of cheering is real.
- Rapid-fire cuddles all day. Muscle recovery: optimal. Tomorrow I start with a head start, coach.
- Sold-out levels of pats today. With a crowd like this, a champion performs double. Thanks, coach.

### Coccole — ignorato
- Coach was a no-show. Trained alone in front of empty stands. The greats do that. Then they write about it in their diary, bitterly.
- Zero attention. I teamed up with myself: good teammate, terrible crowd.
- No cuddles on the schedule, apparently. The affection muscle needs training too, coach. That includes you.
- Empty stands all day. Celebrated anyway, but a solo celebration doesn't last as long.
- Zero fans today. A champion holds up, but performs worse: the crowd is half the training, coach.

### Chiusura
- End of report. Shower, bunk, podium-themed dreams. Tomorrow we win. Goodnight!
- Last line: thanks to the fans. To the fan. You, {utente}. Night!
- Lights out in the stadium. The champion hits the bunk. The season resumes at first light.
- Closing up and recharging. Tomorrow, a double session: life and snacks. Night, diary!
- Stop the clock. Today's time: good. Tomorrow we improve. We ALWAYS improve. Night.
