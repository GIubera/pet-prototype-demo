# Talenti — perk di personalità/evoluzione (P2, Blocco 9)

A NEW system, separate from the **category perks** (Player One/Street Fighter/Tony Hawk, which come from furniture and apply to missions). **Talents** define the pet's BUILD: two pets with the same personality should play differently.

## Come funziona

- Each personality has a **triad per stage**: 3 talents, of which **1** is drawn at random.
  - **Nascita**: draw 1 from the Nascita triad.
  - **Baby→teen evolution**: draw 1 from the Teen triad.
- **Cumulative**: every talent drawn stays active alongside the others (a teen has 2 active).
- **45 / 45 / 10 draw**: the two ⚪ normal talents are 45% each, the 🟡 rare one is 10% ("shiny" flavor). Rares are deliberately stronger.
- **Adulto triad = P3 PROPOSAL, not active in the prototype** (the prototype's evolution is baby→teen only). The `### Adulto` triads below are already written as a proposal (pending founder approval, and to be considered as 30/30/30/10 QUADS) because the 32 adult missions hook into them via the alternate super-success routes. Do not draw from them until the adult stage is implemented — see "Come estendere".
- Talents may touch missions (coin bonuses, duration, stats) but do **not** copy the category perks' "no failure + always super" boolean — EXCEPT the two theme-tag talents below (Amante della Natura, Inventore), which grant it on a mission TAG (natura/invenzione), not on a category. They follow the same perk precedence (super beats failure) already written in bilanciamento.md.

## Legenda colonna `Dati` (brief per il parser P2)

Conventions aligned with the missioni.md DSL. Tokens separated by ` ; `. Final names get locked in during implementation, same as for missions.
- Stats/resources: `forza+1`, `velocita+2`, `int+1`, `carisma+1`, `fel+3`, `energia+5`, `monete+5`, `ferite-10`
- `passivo=` permanent bonus to a stat · `bonus_cibo=` · `bonus_allenamento=` · `bonus_missione=` (per category) · `ogni_missione=` (any)
- `perk_tag=` no-failure boolean + guaranteed super on missions with that tag
- `blocca_cibo=` / `blocca_categoria=` restrictions · `x0.5`/`x1.5`/`x2`/`x3` multipliers · `se <cond>:` condition

---

## Sportivo — firma Forza

### Nascita (estrai 1)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Fissato con la Dieta | ⚪ normale | Won't touch sweets; +1 extra stat from every healthy food (meat/veggies/fish). | `blocca_cibo=dolce ; bonus_cibo=salutare:+1stat` |
| Energico | ⚪ normale | Energy decay halved (−2→−1/h), and training GIVES +5 Energy instead of costing 10. | `energia_decay=x0.5 ; allenamento_energia=+5` |
| Predestinato | 🟡 raro | One EXTRA training session per day over everyone else (2 instead of 1): superior RPG growth. | `allenamenti_giorno=2` |

### Teen (estrai 1)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Braccia di Ferro | ⚪ normale | Meat foods give +1 extra Strength, and Strength training gives +1 extra. | `bonus_cibo=carne:forza+1 ; bonus_allenamento=forza:+1` |
| Spirito Agonistico | ⚪ normale | Sees everything as a competition: +1 extra Strength from every completed mission. | `ogni_missione=forza+1` |
| Fisico Bestiale | 🟡 raro | Permanent +2 Strength passive, never refuses over low Energy, trains in half the time (45 min). | `passivo=forza+2 ; ignora_rifiuto_energia ; allenamento_durata=x0.5` |

### Adulto (estrai 1) — PROPOSTA P3 (in attesa conferma fondatore; quaterna 30/30/30/10)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Sonnambulo Agonista | ⚪ normale | Gains while it sleeps: every full night's sleep gives +1 to a random RPG stat. | `notte_piena=stat_casuale+1` |
| Furia Cieca | ⚪ normale | Performs best when miserable: with Happiness <30, +5 passive Strength. | `se fel<30: passivo=forza+5` |
| Veterano del Ring | ⚪ normale | Pain barely registers: halves the Wounds taken from missions. | `ferite_missione=x0.5` |
| Montaggio alla Rocky | 🟡 raro | Once a week it runs a training montage: +2 to ALL RPG stats in one go. | `montaggio=1/settimana (tutte+2)` |

---

## Gentile — firma Carisma

### Nascita (estrai 1)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Amante della Natura | ⚪ normale | Nature/animal-tagged missions: no failure + guaranteed super; +1 extra stat from vegan foods (veggies). | `perk_tag=natura ; bonus_cibo=verdura:+1stat` |
| Pacifista | ⚪ normale | Can't take Combat missions (removed from the daily lineup); +1 extra Charisma on Social missions. | `blocca_categoria=combattimento ; bonus_missione=sociale:carisma+1` |
| Cuore Magnetico | 🟡 raro | Post-mission tips ×3, daily login +10 coins, and +5 extra coins from every mission. | `mancia=x3 ; login=monete+10 ; ogni_missione=monete+5` |

### Teen (estrai 1)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Coccolone | ⚪ normale | Daily cuddle cap 5→8, and every cuddle gives +3 extra Happiness. | `cap_coccole=8 ; coccola=fel+3` |
| Infermiere Provetto | ⚪ normale | Infirmary costs −5 and heals +10 more Wounds (−30→−40); self-heals −10 Wounds on every wake-up. | `infermeria_costo=-5 ; infermeria_cura=+10 ; risveglio=ferite-10` |
| Anima Candida | 🟡 raro | NEVER loses Health from condition penalties, and Wounds reset to zero every night (only the Happiness route to the suitcase remains). | `immune_malus_condizioni ; notte=ferite=0` |

### Adulto (estrai 1) — PROPOSTA P3 (in attesa conferma fondatore; quaterna 30/30/30/10)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Sussurra-Mostri | ⚪ normale | Speaks fluent monster: `mostro`-tagged missions get no failure + guaranteed super. | `perk_tag=mostro` |
| La Nonna Ti Vede | ⚪ normale | An invisible presence watches over the pet: Chores-category missions get no failure + guaranteed super. | `perk_categoria=lavoretti` |
| Cuore di Casa | ⚪ normale | Turns emergencies into block parties: +1 passive Charisma and +1 extra Charisma from Chores missions. | `passivo=carisma+1 ; bonus_missione=lavoretti:carisma+1` |
| Santo Subito | 🟡 raro | 1 "miracle" per day: reset Wounds to zero OR restore one wellness stat to 100 (player's choice). | `miracolo=1/giorno` |

---

## Nerd — firma Intelligenza

### Nascita (estrai 1)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Idrofobico | ⚪ normale | Hygiene↔Happiness link inverted (dirtier = happier); with Hygiene <50 → +2 passive Int. The dirt Health penalty stays (that's the counterweight). | `igiene_felicita=inverti ; se igiene<50: passivo=int+2 ; nota=malus_salute_sporco_resta` |
| Sete di Sapere | ⚪ normale | +1 free Intelligence training per day (instant extra action, doesn't burn the normal training slot). | `allenamento_extra=int (istantaneo, 1/giorno)` |
| Inventore | 🟡 raro | Once a week it skips training and invents 1 random item (Pool Inventore below); guaranteed super on invention-tagged missions. | `invenzione=1/settimana (pool_inventore) ; perk_tag=invenzione` |

### Teen (estrai 1)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Topo di Biblioteca | ⚪ normale | Study missions: +1 extra Int and −1 hour duration. | `bonus_missione=studio:int+1,durata-1h` |
| Mente Analitica | ⚪ normale | Learns from everything: every training session, whatever the stat, gives +1 extra Int. | `bonus_allenamento=qualsiasi:int+1` |
| Cervellone | 🟡 raro | Permanent +3 passive Int, and can learn up to 4 words per day (instead of 1), used in 50% of its lines. | `passivo=int+3 ; parole_giorno=4 ; uso_parola=50%` |

### Adulto (estrai 1) — PROPOSTA P3 (in attesa conferma fondatore; terna 45/45/10)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Overclock | ⚪ normale | Doubles stat gains from training and missions, but overheats: −10 extra Energy each time. | `guadagni_stat=x2 ; energia_extra=-10` |
| Roombo | ⚪ normale | A little suck-everything robot: Hygiene never drops below 50, and `cucina`-tagged missions get guaranteed super. | `igiene_min=50 ; perk_tag=cucina` |
| Galaxy Brain | 🟡 raro | Every RPG stat counts at least as much as Intelligence in mission thresholds (low stats "count" as Int). | `stat_come_int` |

---

## Maleducato — firma Velocità

### Nascita (estrai 1)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Cleptomane | ⚪ normale | 1 free item per day from the shop (max value 15 coins); +50% coins from coin-rewarding missions. | `furto=1/giorno (max 15 monete) ; bonus_missione_monete=x1.5` |
| Bad Loser | ⚪ normale | On failures caused by its own attitude: consolation reward ×2 but −10 extra Happiness. | `se fallimento_carattere: reward=x2, fel-10` |
| Fulmine di Quartiere | 🟡 raro | Permanent +2 passive Speed, and all missions run −1 hour (too impatient to stay out that long). | `passivo=velocita+2 ; missione_durata=-1h` |

### Teen (estrai 1)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Faccia di Bronzo | ⚪ normale | Never loses Happiness from mission failures (also cancels the Bad Loser penalty → intended combo). | `fallimento=fel-0` |
| Mani Leste | ⚪ normale | +1 extra Speed from every completed mission. | `ogni_missione=velocita+1` |
| Boss di Quartiere | 🟡 raro | 1 free item per day with no value cap (rare furniture included) and +50% coins from all missions. | `furto=1/giorno (nessun tetto) ; bonus_missione_monete=x1.5 (tutte)` |

### Adulto (estrai 1) — PROPOSTA P3 (i 2 normali sono in ATTESA CONFERMA fondatore; terna 45/45/10)
| Talento | Rarità | Effetto | Dati |
|---|---|---|---|
| Il Sonno degli Ingiusti | ⚪ normale | Sleeps like a champ: sleep recovery always full, immune to low-Energy penalties; `paranormale`-tagged missions get no failure + super. | `sonno=sempre_pieno ; ignora_malus_energia ; perk_tag=paranormale` |
| Chissenefrega | ⚪ normale | Immune to other people's opinions: never loses Happiness from failures, and `social`-tagged missions get guaranteed super. | `fallimento=fel-0 ; perk_tag=social` |
| Lavoro in Nero | 🟡 raro | One EXTRA mission per day over everyone else (3 instead of 2 — the off-the-books one, outside the rules). | `missioni_giorno=3` |

---

## Pool Inventore (talento Nerd raro)

Rolls 1 random item, once a week, in place of training.

| # | Oggetto | Effetto |
|---|---|---|
| 1 | Batteria carica | +30 Energy instantly |
| 2 | Chip di memoria | furniture, +1 passive Int |
| 3 | Ventola overcloccata | furniture, +1 passive Speed |
| 4 | Gruzzolo di bulloni | +20 coins |
| 5 | Snack riciclato | food, +1 Int (counts as verdura) |
| 6 | Torcia laser | rare decorative furniture, +2 passive Happiness |
| 7 | Prototipo fallato | no bonus, but sells for 15 coins (sometimes the invention flops) |

---

## Dipendenze / da fare in P2

- **Mission tags** (Blocco 3): two talents need theme tags on missions, which today do NOT exist as categories. When writing the new P2 missions, tag a few of them:
  - `natura` (animals/greenery) → for **Amante della Natura** (proposal: 2-3 missions).
  - `invenzione` (lab/gadgets) → for **Inventore** (proposal: 1-2 missions).
  Until the tags exist, the non-mission half of those two talents still works (vegan food bonus; weekly invention).
- **Character sheet** (Blocco 9): an RPG-sheet-style screen showing the drawn talents (birth + evolutions) next to stats and category perks. Needed because with cumulative talents the pet becomes too rich to read from the HUD alone.
- Some new effects (penalty immunity, tip multipliers, daily theft, multiple training sessions) touch existing P1 systems: they must be hooked up during implementation, the P1 engine doesn't cover them.

## Come estendere (Blocco 5 e stadio adulto)

- **New personalities** (Blocco 5): add a `## <Nome> — firma <Stat>` section with its two triads (Nascita, Teen), same format. The signature stat must be coordinated with bilanciamento.md.
- **Adult stage** (app phase): add a third `### Adulto (estrai 1)` triad to each personality. The parser must treat stages as an open list, not a fixed baby/teen pair.
