# Sportivo — pool battute

Una battuta per riga, iniziando con `- `. Obiettivo: 5-8 per sezione. Le righe `[ESEMPIO]` calibrano il tono: tienile, riscrivile o cancellale. Slot: `{nome}` `{utente}` `{parola}`.
Voce: energia infinita, tutto è un allenamento o una gara, motivational coach abusivo.

## Saluto (apertura app)
- ECCOLO! Il mio coach preferito! Oggi si spinge forte, {utente}!
- SEI TORNATO! Batti il cinque! Più forte! COSÌ! Ora sì che è un allenamento.
- Bentornato! Riscaldamento fatto, motivazione al massimo, aspettavo solo il mister.
- Eccolo! Ho tenuto il ritmo anche senza di te, ma con te si va in progressione.
- Coach! Giusto in tempo per l'highlight della giornata: il tuo ingresso. Standing ovation!
- SEI TORNATO! Ho l'occhio della tigre e la merenda del leone. Si comincia!
- Eccolo! Ho salito le scale di corsa esultando coi pugni al cielo. Le scale erano tre. L'emozione vera.
- Bentornato! Oggi si dà il 110%. Il 10% extra l'ho preso in prestito da ieri, che ho poltrito.
- Sei arrivato in Zona Cesarini, coach! Stavo per fischiare la fine. Non la fischio MAI, ma stavo per.
- Il mister è tornato! Il ritiro è finito, ricomincia il campionato!
- Sei qui! CHI NON SALTA RESTA SUL DIVANO, EHI! ...Ok, salto solo io. Salta anche tu, dai.

## Ha fame
- Ho bruciato tutto! Colazione, scorte, riserve d'emergenza. Serve un rifornimento ai box!
- Non si vincono le gare a stomaco vuoto. Lo diceva il mio idolo. Il mio idolo sono io a stomaco pieno.
- Benzina finita a metà gara, {utente}! O mi spingi tu fino alla cucina o porti la cucina qui.
- Crampo! No aspetta... è fame. È FAME, {utente}! Intervento immediato!
- Lo stomaco mi sta fischiando il fallo. Rigore per me: si batte in cucina.
- La mia pancia ha fischiato l'intervallo. Le arance di metà partita dove sono? DOVE SONO?
- Sto correndo verso il frigo da stamattina e non arrivo mai. Il campo tra me e il cibo è lungo tipo tre chilometri.
- Un campione mangia da campione. Io oggi sto mangiando da panchinaro squalificato: niente.
- Il piano era: colazione dei campioni. La realtà: digiuno degli sconfitti. Ribaltiamola, coach!

## È sporco
- Ok il sudore è gloria, ma qui siamo oltre. Doccia, subito, poi si riparte.
- Puzzo come uno spogliatoio dopo i supplementari. E non è un complimento nemmeno per me.
- Mi gratto da mezz'ora. Non è una nuova tecnica di allenamento. Aiuto.
- Maglia sudata = onore. Terza maglia sudata di fila = emergenza sanitaria. Doccia, coach!
- Mi sono annusato al fotofinish. Ho perso io. Serve il cambio, subito.
- Metti la cera, togli la cera... non ha funzionato: la cera era fango. Serve la doccia vera, coach.
- Il VAR ha revisionato il mio odore: espulsione diretta. Rientro in campo solo dopo la doccia.
- Mi sono rotolato per esultare. L'esultanza è finita, il fango è rimasto. Bilancio comunque positivo. Doccia?

## Felice
- Giornata TOP! Mi sento da podio!
- GIORNATA PERFETTA! Ho fatto una capriola d'esultanza. Nessuno filmava? Peccato, era da manuale.
- Endorfine a mille, coach! Oggi potrei correre fino al frigo cento volte. Anzi, lo faccio.
- Mi sento in stato di grazia. Tipo tripletta all'ultimo minuto. Tipo record senza scarpe.
- Oggi vinco anche a "stare fermo". Guarda che tecnica. IMBATTIBILE.
- Giornata da highlights! La rivedremo insieme al rallentatore, promesso.
- Mi sento come al replay del gol più bello: lo rivedrei all'infinito, e il gol è oggi.
- Giornata da telecronaca urlata! CLAMOROSO! INCREDIBILE! STO BENISSIMO!
- Se la felicità fosse un campionato, oggi avrei la matematica certezza del titolo.
- Ho esultato togliendomi la maglietta. Ammonizione giustissima, rifarei tutto.

## Coccole finite
- Pausa recupero, coach: le coccole di oggi sono da bollettino esaurito. Poi si ricarica, promesso.
- Stop, coach! Anche l'affetto va dosato: sovrallenamento di coccole = strappo alla felicità.
- Cinque serie di coccole: allenamento completo! Ora recupero muscolare, domani si raddoppia. (Non si può. Peccato.)
- Alt! Zona rossa di affetto raggiunta. Il preparatore dice stop. Domani sessione doppia? Domani sessione doppia.
- Le coccole vanno periodizzate, coach: oggi carico completato. Vai a riposare anche tu, che domani si spinge.
- Stop alle coccole: il regolamento antidoping è severo. Troppo affetto altera le prestazioni. In meglio, ma le altera.
- Basta coccole: il cuore è in acido lattico. Bellissimo, ma il recupero è recupero.
- Coccole terminate! Vado a defaticare: due giri di divano a passo lento e un pensiero felice.

## Trascurato / triste
- Tre giorni senza allenamento di coppia. La panchina fa male, {utente}. E io non sono da panchina.
- Mi sono allenato da solo. Ho vinto da solo. Ho esultato da solo. Era tutto più triste, onestamente.
- Sto facendo stretching della pazienza. È l'unico muscolo che sto allenando ultimamente.
- Il cronometro va avanti anche quando non ci sei. Segna: troppo.
- Ho fatto il riscaldamento ogni mattina. Prima o poi la partita arriva, no? ...No?
- Allenamento a vuoto, giorno tre. Anche i pesi cominciano a chiedere di te.
- Ho provato ad auto-motivarmi. "Forza {nome}!" detto da {nome}. Non è la stessa cosa, coach.
- Mi alleno, mangio, dormo. Ripeto. Manca la parte dove qualcuno dice "bravo". Era la mia preferita.
- Squadra in silenzio stampa, coach. La squadra sono io e il silenzio è tuo. Almeno la stampa venisse.

## Parte per la missione
- Missione = gara. E io le gare non le perdo. Cronometrami!
- Missione! Ho fatto riscaldamento, stretching e discorso motivazionale allo specchio. Lo specchio piangeva.
- Vado a vincere! E se non vinco, faccio comunque il giro d'onore. Il giro d'onore non si nega a nessuno.
- Gara in trasferta! Tifa per me da casa, il tifo lo sento a distanza. Ho l'orecchio allenato.
- Si parte! Obiettivo: record. Piano B: record con un tempo leggermente peggiore.
- Missione! Me la gioco come una finale: male i primi minuti, poi LEGGENDA.
- Vado, coach! Se la missione è lunga come il campo di quei cartoni giapponesi, torno tra una settimana.
- Missione = trasferta. E in trasferta i grandi si vedono. Gli altri fanno turismo. Io un po' entrambi.
- Si parte per la gloria! Se si mette male, modalità rimonta: è la mia specialità dai tempi del... da adesso.

## Ritorno: successo
- VITTORIA! Alza la coppa con me! Non c'è una coppa? Compriamone una, ce la meritiamo.
- Primo posto! Avrei fatto anche il giro d'onore ma mi sono perso. Due volte. VITTORIA comunque!
- Record personale in missione! Il precedente era mio. Anche il prossimo sarà mio. Bel campionato.
- Vittoria schiacciante! Cronometro fermato, avversari demoralizzati, autografi distribuiti. (Uno.)
- Trionfo, coach! Dammi il cinque, il dieci e pure il quindici. Oggi si festeggia!
- VITTORIA IN RIMONTA! Sotto di due, poi tripletta. I dettagli non verificabili rendono la storia migliore.
- Ho vinto e ho esultato correndo col dito al cielo. Il cielo era il soffitto, ma il gesto conta.
- Trionfo! Qualcuno aveva detto "non ce la farai mai". L'ho presa sul personale. Ecco il risultato.
- Coppa in bacheca! La bacheca è il davanzale, la coppa è immaginaria, la GLORIA è vera.

## Ritorno: fallimento
- Sconfitta bruciante... ma i campioni si vedono alla ripartenza. Domani doppio allenamento.
- Abbiamo perso, coach. Dico "abbiamo" perché il dolore si divide. La colpa no: quella è dell'arbitro.
- Sconfitta ai punti. Chiedo il VAR. Non c'è il VAR nelle missioni? DOVREBBE ESSERCI.
- Persa. Però ho corso più forte di tutti nella direzione sbagliata. Il talento c'è, va solo orientato.
- Sconfitta bruciante ma allenante. Il muscolo del riscatto è già in fase di pompaggio.
- Sconfitta. Ma il detto dice: non conta quanto forte colpisci, conta quanto sai incassare e ripartire. E io incasso BENISSIMO.
- Il risultato è bugiardo: missione dominata, missione persa. Il calcio... cioè, la vita è strana.

## Notifica push
- {nome} sta correndo in tondo per non perdere il ritmo. Al giro 400 ha iniziato a girargli la testa.
- Il tabellone segna: {nome} 1, solitudine 0. Ma per il secondo tempo servono i tifosi.
- {nome} sta facendo flessioni motivazionali. Ha finito la motivazione a metà serie. Porta la tua.
- {nome} ti tiene il posto in squadra. Lo tiene da stamattina. La squadra reclama.
- Bollettino dal campo: {nome} è carico, caricissimo, TROPPO carico. Va gestito. Corri.
- {nome} sta facendo la telecronaca della casa vuota: "ancora nessuno in area, coach". Vieni a cambiare la partita.
- Il mercato chiude a mezzanotte: {nome} aspetta il rinnovo del suo coach. Le cifre? Una carezza e una merenda.
- Bollettino medico di {nome}: cuore in forma, morale in riserva. La cura è nota e sei tu.

## Valigia (sta per partire)
- Un atleta capisce da solo quando la squadra non lo convoca più.
- Piego le maglie da titolare. Non le indosso da tanto, tanto vale piegarle bene.
- Mi alleno anche oggi: sollevamento borsone. Serie unica. Ripetizioni: una. Pesantissima.
- Uscita a testa alta, passo da campione. Poi magari inciampo, ma l'uscita era questa.
- Il mister non convoca, il capitano non chiama... a un certo punto uno il borsone lo fa.
- Sto impacchettando i trofei immaginari. Pesano niente e valgono tutto, come i bei tempi qui.
- Ultimo controllo del borsone: scarpe, fascia, orgoglio. Il tifo lo lascio qui: era per te, non si trasferisce.
- Chiudo il borsone al terzo tentativo. Il cuore continua a rimettersi in mezzo alla cerniera.

## Notifica valigia
- Minuti di recupero: {nome} è sulla linea di fondo col borsone. Il cambio si può ancora annullare.
- {nome} sta facendo il giro d'onore di addio. È lento apposta. Raggiungibile, coach.
- {nome} ha appeso le scarpette al chiodo. Provvisoriamente. Il chiodo regge poco: sbrigati.

## Rientro (hai rimediato in tempo)
- SAPEVO che il mister mi rivoleva! Disfo il borsone e domani doppio allenamento per festeggiare!
- Rinnovo di contratto! Firmo col cinque alto. Anzi con due. ANZI CON DIECI.
- Torno in squadra! Nessuna clausola: solo merenda garantita e un coach che c'è. Affare fatto.
- Visite mediche passate, cuore idoneo, morale alle stelle: il ritorno è UFFICIALE, coach.
- Rientro ufficiale! Ho baciato la maglia. Non ho una maglia: ho baciato il pelo. Vale uguale.
- Il borsone torna nell'armadio e io in formazione. Diremo che era un ritiro precampionato. Cortissimo.
- Riconvocato! La panchina della cucina è di nuovo mia. Da lì si vede la partita migliore: te che apri il frigo.
- Rientro col botto: doppietta di abbracci al primo minuto. La condizione c'è, il resto viene.

## Addio (parte davvero)
- Cambio squadra, coach. Senza rancore. (Un po' di rancore.)
- L'ultimo fischio è arrivato. Grazie per le stagioni belle. Le altre le dimentico io, per tutti e due.
- Mi ritiro da questa squadra, non dallo sport. Se un giorno riapri lo stadio... io tifavo per te.

## Lettera (dal pianeta dei ritirati)
- Coach, ti scrivo dallo spogliatoio del pianeta. Mi alleno ogni giorno per la partita di ritorno. Manca solo che tu mi richiami in squadra.
- Numero di maglia ancora appeso al chiodo. Non l'ho dato a nessuno. È il tuo posto in panchina che aspetta il mio: firmiamo il ritorno?
- Mi alleno il doppio, così quando mi richiami sono già pronto. SE mi richiami. QUANDO mi richiami. Vado a fare altri scatti.
- Ho provato a fare squadra con altri. Gente valida, per carità. Ma il capitano lo aspetto: la fascia resta libera, ed è tua.
- Qui si gioca ogni giorno e non perdo mai. Il segreto, coach: vincere senza qualcuno che esulta è solo fare punti. Richiamami e torniamo a vincere sul serio.
- [ESEMPIO] Il pianeta è la panchina, {utente}. Io voglio il campo, con te che urli dagli spalti. Fischia l'inizio: "Fai ammenda" e rientro in partita.

## Evoluzione
- SONO CRESCIUTO! Categoria juniores, arrivo! Le gambe nuove vanno provate SUBITO.
- Evoluto! Salto di categoria ufficiale. Il fisico c'era già, ora c'è anche il resto del fisico.
- Guarda che spalle! Cresciute ad allenamento e merende. Soprattutto merende, ma non l'hai saputo da me.
- Nuovo corpo, nuovi record da battere. I vecchi li ho battuti crescendo. Letteralmente.
- EVOLUTO! Il fisico ha fatto l'upgrade e la merenda va adeguata di conseguenza. È scienza, coach.
- Cresciuto! Le vecchie maglie non mi entrano più: le appendiamo al soffitto, come si fa coi numeri dei grandi.
- Sono passato professionista! Il contratto prevede: casa, coccole e gloria. Firmato con la zampa, valido per sempre.
- Evoluto, coach! Il riscaldamento adesso dura di più: c'è più campione da scaldare.

## Ha sonno (sotto soglia energia o prima delle 21)
- Coach, sono a secco di energie. Serve recupero vero, altrimenti crollo in campo.
- Coach, ho finito la benzina. Anche i campioni hanno il serbatoio. Il mio segna zero e fischia.
- Sbadiglio da record. Cronometralo... no, non cronometrarlo, portami a letto e basta, coach.
- Il fisico da campione richiede il recupero da campione. È scienza sportiva, non pigrizia. (Un po' pigrizia.)
- Corro solo se il traguardo è il letto. Quella gara la vinco anche da stanchissimo.
- Energie finite, coach. Persino il mio inno interiore si è seduto. Portami in branda da campione: di peso.
- Coach, ho i muscoli in sciopero e il sindacato è compatto. Trattativa possibile solo in orizzontale.
- Batteria a zero. Ho dato tutto in campo. Il campo era la casa, ma ho dato comunque tutto.

## Va a dormire (dalle 21, portato a letto)
- Riposo da atleta, coach: sonno programmato, sveglia tra qualche ora. Non sgarro.
- A letto! Il recupero è parte dell'allenamento: quindi tecnicamente sto ANCORA vincendo.
- Buonanotte, coach! Il sonno è il mio secondo sport preferito. E sono fortissimo pure lì.
- Buonanotte! Sogno la finale. Nei sogni vinco sempre. L'arbitro sono io, ma vinco pulito.
- A letto, coach: domani c'è il derby contro la sveglia. Voglio arrivarci riposato e vincerlo al primo squillo.
- Buonanotte! Mi corico in posizione da ripartenza: se succede qualcosa, parto già caldo.
- A cuccia da professionista, coach: il sonno è l'allenamento che riesce sempre. Otto ore di prestazione perfetta, garantito.
- A letto in orario da professionista. La disciplina di sera è la vittoria di domattina. L'ho inventata io questa, segnala.

## Sveglia (risveglio dopo il sonno)
- Sveglio e carico al cento per cento! Il recupero ha funzionato, si torna in campo!
- SVEGLIA! Colazione, stretching e gloria, nell'ordine che preferisci ma con la colazione prima.
- Occhi aperti e ginocchia alte! Il materasso ha perso: ci ho provato a restare, GIURO, ma sono troppo forte.
- Sveglio! Nei sogni ho corso tutta la notte. La conto come sessione di allenamento.
- In piedi al primo squillo, come i professionisti. Il letto mi ha dato il cinque. A modo suo. Era un cuscino.
- Sveglio prima della sveglia! L'ho battuta sul tempo. Anche oggi il primo trofeo è mio.
- BUONGIORNO! Il risveglio è il mio fischio d'inizio: da adesso ogni minuto è gioco vero.
- Sveglio e scattante! Stanotte il fisico ha fatto i lavori in casa: oggi consegna un campione ristrutturato.

## Dormito male (crollato, non a letto)
- Ho dormito sul campo invece che negli spogliatoi. Recupero scarso, ma la grinta è intatta!
- Ho dormito a bordo campo. Il fisioterapista immaginario è FURIOSO con te.
- Schiena bloccata da pavimento. Il referto dice: "gestione atleta da rivedere". C'è il tuo nome sotto.
- Recupero fallito: dormito dove sono crollato, come dopo una maratona. Senza medaglia, però. Manca proprio la medaglia.
- Notte a bordo pavimento, coach. Il mio fisico da campione stamattina fa rumori da mobile vecchio.
- Mi hai svegliato prima del recupero completo. Il regolamento parla chiaro: risarcimento in merenda.
- Dormire a terra è allenamento? NO, coach. L'ho verificato per te stanotte. Non era necessario verificarlo.
- Sveglia anticipata: recupero incompleto, umore da spogliatoio in silenzio. Si rimedia con titolarità immediata in cucina.

## Usa una parola imparata
- {parola}! Bella questa! La urlo quando vinco: {parola}!
- "{parola}"! Nuovo grido di battaglia! Lo urlo in partenza, in arrivo e negli spogliatoi!
- Coach, "{parola}" mi carica tantissimo. La dico prima di ogni sforzo. Anche prima di aprire il frigo.
- "{parola}" è il mio mantra pre-gara. Tre ripetizioni e divento IMBATTIBILE: {parola}, {parola}, {parola}!
- "{parola}"! Detta col fiatone rende il doppio. Ti mostro: *scatto* — {parola}!
- Ho messo "{parola}" nell'inno della squadra. L'inno è tutto lì: "{parola}, {parola}, olé".
- Dedico "{parola}" al mio coach, come si dedica un gol. Indicandoti. {parola}! (Ti sto indicando.)

## Gioca
- Allenamento mascherato da gioco! Scatti, finte, tuffi sul divano. Il divertimento È preparazione atletica.
- Lotta col cuscino: tre round, tutti miei. Il cuscino ha incassato bene, gli do il premio fair play.
- Rincorro la mia coda: esercizio di agilità AVANZATO. Non la prendo mai, è la mia rivale storica.
- Partitella in salone! Io contro me stesso: vinco comunque, ma che fatica.

## Gioca col giocattolo
- GIOCATTOLO NUOVO! Attrezzatura ufficiale da campione. Inizia la pre-season del divertimento.
- Che pezzo! Lo provo subito: riscaldamento, test, esultanza. Il protocollo completo.
- Il mio nuovo compagno di squadra! Non parla, non si lamenta, gioca sempre: convocazione fissa.
- Giocattolo promosso titolare al primo provino. Talento puro, si vede subito. Come me.

## Passeggiata partenza
- Vado a fare il giro di campo... il campo è il quartiere. Cronometro mentale attivo, ovviamente.
- Due passi da atleta: postura perfetta, falcata elegante. Il quartiere merita lo spettacolo.
- Esco in perlustrazione sportiva! Se vedo qualcuno correre, lo supero. È più forte di me.
- Passeggiata di scarico, coach. Anche i campioni camminano: si chiama gestione delle energie. L'ho letto e mi piace.

## Passeggiata monete
- Monete trovate! Anzi no: CONQUISTATE. C'era da chinarsi e io mi sono chinato meglio di chiunque.
- Bottino di giornata: monete da terra. Le ho viste per primo, riflessi da campione. Il podio dei marciapiedi è mio.
- Ho raccolto monete in velocità, senza fermare la falcata. Tecnica sopraffina, incasso meritato.
- Monete sul percorso! Le considero il montepremi della passeggiata. Vinto, ovviamente.

## Passeggiata incontro
- Ho incontrato un altro pet: amichevole IMMEDIATA. Risultato: bellissimo pareggio. (Stavo vincendo io.)
- Nuovo compagno di allenamento trovato in passeggiata! Forte, veloce, simpatico. Lo voglio in squadra.
- Partitella improvvisata con un pet del quartiere. Che livello, che intensità! Il campetto è vita.
- Incontro un pet, tre secondi dopo stavamo già correndo. Le amicizie migliori partono in velocità.

## Passeggiata pozzanghera
- La pozzanghera era lì che sfidava. Io le sfide non le rifiuto MAI. Splash memorabile, zero rimpianti.
- Tuffo tecnico in pozzanghera: rincorsa, stacco, atterraggio. Da manuale. Il manuale del divertimento.
- Sono zuppo e felicissimo: ho battuto il record di splash del quartiere. Il precedente era di un cane enorme. RISPETTO.
- Allenamento acquatico non programmato. Programmato, va bene: l'ho vista da lontano e ho accelerato.

## Passeggiata panorama
- Le luci della città dal ponte... mi sono fermato. IO. Fermo. Ed era bellissimo, coach.
- Panorama da podio oggi. Ho fatto silenzio e mi sono goduto il momento: anche questo è allenamento, del cuore.
- Momento di quiete sul ponte. Il cuore rallenta il battito, la testa fa il giro d'onore da ferma.
- Sole pieno ovunque, come uno stadio il giorno della finale. E domani si gioca ancora. Che fortuna, coach.

## Passeggiata rottame
_(socio: 4 battute — torna con un rottame/pezzo alieno luccicante trovato per strada (+monete))_
- Torno col trofeo di giornata: un rottame luccicante! Trovato con l'occhio del talent scout. È da podio, fidati.
- Pezzo di metallo alieno conquistato! Beh, raccolto. Ma con uno stile che valeva una conquista.
- Il mio bottino: un rottame che brilla come una coppa. Lo metto in bacheca. La bacheca è tua, il trofeo è nostro.
- Ho visto qualcosa brillare a bordo strada. Riflessi pronti, zampa veloce: MIO.

## Passeggiata piccione
_(socio: 4 battute — ha rincorso un piccione cyborg / drone per mezza città (+Felicità, −Energia))_
- Ho sfidato un piccione cyborg in velocità. Ha vinto lui, MA aveva i reattori. Chiedo la squalifica per doping tecnologico.
- Inseguimento epico con un piccione robotico! Non l'ho preso: si allena più di me. RISPETTO. E rivincita.
- Il piccione mi ha staccato in volata. Volava, tecnicamente. Ai punti però ho vinto io: più cuore, meno circuiti.
- Mezza città di scatti dietro un piccione mezzo robot. Sconfitto ma migliorato: quel piccione è il mio nuovo preparatore atletico.

## Passeggiata assaggio
_(socio: 4 battute — un ambulante gli molla uno spuntino gratis al volo (+Fame))_
- L'ambulante mi ha passato uno spuntino gratis: rifornimento a sorpresa ai box! Il quartiere tifa per me.
- Spuntino in omaggio durante il giro! L'ho preso al volo senza fermarmi: tecnica da staffetta. Buonissimo.
- Premio fedeltà dall'ambulante: un assaggio gratis. I campioni si riconoscono, anche a passeggio.
- Integratore non programmato offerto dal pubblico! Accettato con professionalità e divorato con entusiasmo.

## Passeggiata acquazzone
_(socio: 4 battute — acquazzone improvviso: torna zuppo ma bello pulito (+Igiene, −Felicità))_
- Acquazzone in pieno percorso! Fradicio ma pulito: doccia e defaticamento in un colpo solo. Efficienza, coach.
- La pioggia mi ha beccato a metà giro. Ho continuato: i campioni non si sciolgono. Però che freddo, coach.
- Zuppo! Il meteo ha fatto l'arbitro cattivo oggi. Almeno torno pulito: il cielo faceva anche servizio lavaggio.
- Allenamento sotto la pioggia non richiesto. Completato comunque. Ora coperta, per favore: anche i duri tremano.

## Passeggiata persi
_(socio: 4 battute — si è perso e ha girovagato: gran avventura, ma stanco (+Felicità, −Energia))_
- Mi sono perso e ho improvvisato un percorso nuovo: il doppio dei chilometri! Gambe a pezzi, record di resistenza mio.
- Giro di riscaldamento trasformato in maratona per errore di navigazione. L'errore è mio, la gloria pure.
- Perso per mezza città. Ho ritrovato la strada col fiuto del fuoriclasse. Le gambe chiedono il cambio, il cuore no.
- Avventura fuori percorso! Ho visto il quartiere come non lo vede nessuno: col fiatone. Torno stanco e campione.

## Passeggiata cielo
_(socio: 4 battute — vede un'astronave/UFO passare bassa sui tetti (+Felicità, worldbuilding sci-fi))_
- Un'astronave bassa sui tetti! Mi sono fermato a metà scatto. Certe cose battono anche l'allenamento, coach.
- UFO sopra il quartiere! Velocità impressionante. L'ho cronometrata a occhio: fortissima. La rispetto come avversaria.
- Il cielo oggi ha fatto uno show da finale di campionato: astronave a bassa quota in pieno sole. Applausi da bordo strada.
- Ho visto un'astronave e ho pensato: chissà se lassù si allenano. Se sì, voglio l'amichevole.

## Passeggiata bulletto
_(socio: 4 battute — incrocia un pet maleducato: parole grosse, morale un po' giù (−Felicità))_
- Ho incrociato un pet scorretto: parole grosse, zero fair play. Non ho reagito. I campioni rispondono in campo, non in strada.
- Un bulletto mi ha provocato. Ho tenuto la testa alta e il passo lungo. Vittoria ai punti, ma il morale ha preso un colpo.
- Brutto incontro oggi: un pet antisportivo. Mi ha rovinato il giro d'onore. Domani mi alleno anche per questo.
- Parole grosse da un pet maleducato. Le ho lasciate cadere: il regolamento del cuore vieta le risse. Però che nervoso, coach.


## Notifica missione finita
Notifica push sul telefono quando una missione si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}` disponibile. Finché questa lista è vuota il gioco usa un testo neutro.
- {nome} è tornato dalla missione col petto in fuori. Vieni a vedere se è giustificato.
- Missione finita! {nome} sta già facendo il giro d'onore in salone. Unisciti, coach!
- Il tuo campione è rientrato! Ha un risultato e ZERO pazienza di aspettare. Apri!
- {nome} è tornato! La telecronaca della missione parte al tuo ingresso. Non tardare.
- Rientro completato! {nome} tiene il risultato caldo come una premiazione. Corri!

## Notifica allenamento finito
Notifica push quando l'allenamento si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}`. Finché vuota: testo neutro.
- {nome} ha SPACCATO in allenamento. I muscoli non si applaudono da soli. Apri!
- Sessione finita! {nome} cerca il suo coach per il resoconto urlato. Sei tu. Corri.
- Allenamento completo! {nome} è carico e vuole mostrarti la posa da campione. ORA.
- {nome} ha finito gli esercizi e iniziato le esultanze. Manca solo il pubblico: tu!

## Notifica carica a rischio
Notifica della sera, SOLO se la carica e' a rischio (streak >= 3 e giornata senza cura). Ricorda, non rimprovera. Una battuta per riga con `- `, slot `{nome}`.
- Ultimo minuto di partita. {nome} aspetta il passaggio.
- {nome} ha tenuto la striscia aperta finora. Non chiuderla sul piu' bello.
- La carica sta per scadere e {nome} e' ancora in campo. Serve solo un tocco.
- {nome} non molla di un centimetro. Ma da solo non segna. Vieni.

## Notifica silenzio lungo
Notifica dopo 3+ giorni di assenza. Tono leggero: il pet se la cava, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{nome}`.
- Tre giorni in panchina. {nome} si e' allenato lo stesso. Ma non e' uguale.
- {nome} ha corso da solo. Va bene, ma i tempi sono peggiori senza il tifo.
- Nessuno in tribuna da tre giorni. {nome} gioca lo stesso, ma sottovoce.
- {nome} tiene il posto caldo. Anche se dice che non lo tiene.

## Reazione assenza lunga
Il pet ti rivede dopo 3+ giorni. Tono leggero: se l'e' cavata, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{utente}`.
- Tre giorni in panchina. Mi sono allenato lo stesso. Ma il pubblico serve.
- Rieccoti. Riscaldamento e si riparte, forza.
- Ti ho tenuto il posto caldo. Continuando a dire che non lo stavo tenendo.

## Reazione ora assurda
Apri il gioco fra l'una e le cinque del mattino. Il pet lo fa notare. Una battuta per riga con `- `, slot `{utente}`.
- A quest'ora? Nessun atleta si allena alle due. Nessuno.
- Va bene, riscaldamento notturno. Ma domani me ne devi il doppio.
- Il riposo E' allenamento. Guarda che lo dicono davvero.

## Reazione batteria scarica
La batteria del telefono e' sotto il 10%. Il pet ci scherza sopra. Una battuta per riga con `- `, slot `{utente}`.
- Batteria a terra. Anche i campioni fanno rifornimento.
- Ultimo minuto e sei senza fiato. Attaccalo alla presa.
- Sotto il dieci per cento. Time-out obbligatorio, dai.

## Reazione tema scuro
Il telefono e' in tema scuro. Battuta di colore, nessuna conseguenza. Una battuta per riga con `- `, slot `{utente}`.
- Tema scuro, luci basse, aria da spogliatoio. Mi piace.
- Modalita' notturna. Da qui in poi si gioca sul serio.
- Buio in sala. Che entri il campione.
