window.PETQ = window.PETQ || {};

(function () {

  // i18n bilingue (v. ui.js/i18n.js): SOLO i rifiuti/hint scritti a mano per il giocatore (i msg
  // di avvia/risolvi qui sotto). MAI i token DSL (cond/reward delle schede) ne' le chiavi dati.
  var traduci = (PETQ.i18n && PETQ.i18n.t) || function (s) { return s; };

  var STAT_NOMI = ['forza', 'intelligenza', 'velocita', 'carisma'];

  // Mappa categoria missione -> perk che la rende "garantita super" se piazzato in casa.
  // Da bilanciamento.md "Perk per categoria": i perk esistono SOLO nelle missioni che li
  // assegnano (decisione fondatore), quindi non tutte le categorie sono presenti qui.
  var PERK_PER_CATEGORIA = {
    videogioco: 'videogioco',
    combattimento: 'combattimento',
    sport: 'sport',
    studio: 'studio',
    // P3 (fix v=99): questi perk erano nella tabella di bilanciamento.md e nei reward delle
    // schede fin da v=85/v=98, ma le mappe qui erano rimaste a P2 -> venivano ASSEGNATI e mai
    // APPLICATI (nessun super garantito). Ora ogni categoria ha il suo perk, come da tabella.
    consegne: 'ponyexpressgalattico',
    sociale: 'partyanimal',
    lavoretti: 'mrwolf'
  };

  // Perk = MEDAGLIETTE (decisione fondatore, bilanciamento.md "Perk = MEDAGLIETTE"): i perk NON
  // sono piu' arredi da piazzare ma BADGE che il pet ottiene da un reward token perk:<nome> e che
  // restano SEMPRE attivi (state.perks). PERK_PER_TAG mappa un tag di missione -> perk-badge che
  // rende "garantita super" (e niente fallimento forzato) qualunque missione con quel tag. Overlap
  // con i perk-categoria innocuo (decisione fondatore: basta il match, nessuna esclusione).
  var PERK_PER_TAG = {
    gara: 'sabotatore',
    inseguimento: 'parkour',
    social: 'influencer',
    musica: 'singer',
    rapina: 'gtb',
    mostro: 'cacciatoremostri',
    // P3 (fix v=99, stesso discorso della mappa categorie qui sopra)
    cucina: 'masterchef',
    paranormale: 'acchiappafantasmi',
    spazio: 'astronauta',
    companion: 'acchiappalitutti'
  };

  // Le 4 armi di M7 (fallback hardcoded se il parsing dinamico da content.data.arredi
  // con fonte "M7 standard" non le trova, vedi armiM7()).
  var ARMI_M7_FALLBACK = ['Bastone da combattimento', 'Sai gemelli', 'Nunchaku arrugginiti', 'Katane a farfalla'];

  // Le 5 armi Kaiju (arredi drop di M20, +2 Forza ciascuna): reward token armaCasualeKaiju
  // (M20 standard, 1 arma a caso) e tutteArmiKaiju (M20 super, tutte e 5). Nomi fissi come
  // in content/arredi.md.
  var ARMI_KAIJU = ['Spadone', 'Martellone', 'Doppie Lame', 'Arco Pesante', 'Alabarda'];

  var NOME_ALLENATORE = 'Il Topo (allenatore)';

  // Negozio unico (GDD "Economia" -> "Spesa e dispensa", fix fondatore): il pet nasce con la
  // dispensa VUOTA (lo stock iniziale "3 crocchette" e' stato spostato qui, cosi' il regalo
  // del tutorial ha senso). Il tutorial del Negozio (m0) rifornisce la dispensa con un po' di
  // cibo di partenza, oltre al regalo di personalita' gia' esistente: 3 Crocchette semplici
  // (il cibo base economico) + 2 porzioni di un cibo scelto a caso tra gli altri disponibili
  // (varieta', cosi' il primo pasto non e' per forza il piu' anonimo). Numeri scelti per
  // coprire circa un giorno di cura (bilanciamento.md: ~2 pasti/giorno) senza gia' risolvere
  // tutta l'economia del gioco.
  var TUTORIAL_CROCCHETTE_QTY = 3;
  var TUTORIAL_CIBO_EXTRA_QTY = 2;
  var TUTORIAL_CIBO_BASE = 'Crocchette semplici';

  // Missioni NON ripetibili (bilanciamento.md "Missioni NON ripetibili", decisione fondatore):
  // una missione completata esce dalla rosa PER SEMPRE (nessun cooldown, nessuna riammissione).
  // La rosa mostra fino a DIM_ROSA schede tra quelle mai fatte; se ne restano meno, ne mostra
  // meno (2, 1) e se il pool si esaurisce resta vuota (opzione A voluta dal fondatore). Il
  // tutorial m0 e' escluso dal meccanismo (fuoriRosa, non passa mai da qui).
  // COOLDOWN_GIORNI non e' piu' usato (esclusione permanente al posto del cooldown a tempo):
  // lasciato solo perche' esportato in _cooldownGiorni per compat. dei test.
  var COOLDOWN_GIORNI = 3; // non piu' usato

  // Rotazione random delle missioni PER RUN (decisione fondatore, P3): per gli stadi elencati
  // qui, ad ogni RUN (= vita di un pet) viene estratto un SOTTOINSIEME CASUALE di N schede tra
  // tutte quelle del pool di quello stadio; rosaDelGiorno pesca SOLO da quel sottoinsieme (invece
  // che da tutto il pool). Il meccanismo e' GENERALE e VOLUTAMENTE per-stadio: per attivarlo su
  // un altro stadio basta aggiungere una voce qui (es. baby: 12) — NESSUN'ALTRA modifica al
  // codice sotto e' richiesta, il resto della pipeline (lazy init, guardie, reintegro) legge
  // questa mappa in modo generico. Uno stadio SENZA voce qui si comporta come oggi (nessuna
  // rotazione: rosaDelGiorno pesca da tutto il pool dello stadio, invariato).
  // ATTIVATA SU TUTTI GLI STADI (10 lug 2026): il fondatore voleva la rotazione ovunque e la
  // sessione-design ha portato i pool a 24 baby (M1-16+M73-80) e 33 teen (M18-32+M81-98).
  // Numeri attivi/run: baby 9 e teen 13 (centro delle forbici proposte 8-10 / 12-14 —
  // correggibili qui in un secondo, sono solo config). Adulto 16/32 come da batch 2.
  var ROTAZIONE_PER_STADIO = { baby: 9, teen: 13, adulto: 16 };

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  function oggiStr(d) {
    d = d || new Date();
    var mese = String(d.getMonth() + 1).padStart(2, '0');
    var giorno = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + mese + '-' + giorno;
  }

  // differenza in giorni di calendario tra due stringhe 'YYYY-MM-DD' (b - a). Usa mezzogiorno
  // UTC per evitare sfasamenti da cambio ora legale sulle differenze di data locale.
  function diffGiorniStr(a, b) {
    var da = new Date(a + 'T12:00:00Z').getTime();
    var db = new Date(b + 'T12:00:00Z').getTime();
    return Math.round((db - da) / 86400000);
  }

  // Guardia difensiva: garantisce i campi di stato usati da questo modulo, utile se chiamato
  // prima che lo stato sia passato da PETQ.save.load (stesso concetto di arredi.assicuraArrediStruct).
  function assicuraStatoMissioni(state) {
    if (!state) return;
    if (PETQ.arredi && typeof PETQ.arredi._assicuraArrediStruct === 'function') {
      PETQ.arredi._assicuraArrediStruct(state);
    }
    if (typeof state.ferite !== 'number') state.ferite = 0;
    // Perk = MEDAGLIETTE (decisione fondatore, bilanciamento.md "Perk = MEDAGLIETTE"): array di
    // nomi-perk badge (lowercase, dedup), sempre attivi una volta ottenuti. Guardia difensiva.
    if (!Array.isArray(state.perks)) state.perks = [];
    if (!Array.isArray(state.dispensa)) state.dispensa = [];
    if (typeof state.missione === 'undefined') state.missione = null;
    if (typeof state.coins !== 'number') state.coins = 0;
    state.tutorialFatto = !!state.tutorialFatto;
    // Negozio unico (GDD "Economia" -> "Spesa e dispensa"): migrazione salvataggi vecchi —
    // se il tutorial risulta gia' fatto (partita pre-esistente) il negozio era gia'
    // implicitamente disponibile (era il Market separato, sempre attivo), quindi si sblocca
    // qui senza dover rifare il tutorial. Se manca del tutto, segue tutorialFatto.
    if (typeof state.negozioSbloccato !== 'boolean') {
      state.negozioSbloccato = !!state.tutorialFatto;
    }
    // Cooldown missioni: mappa {id: 'YYYY-MM-DD' ultima esecuzione}, settata alla RISOLUZIONE
    // (v. risolvi). Migrazione: i salvataggi vecchi non ce l'hanno, si parte da mappa vuota
    // (nessuna missione in cooldown finche' non se ne completa una nuova).
    if (!state.missioniFatte || typeof state.missioniFatte !== 'object' || Array.isArray(state.missioniFatte)) {
      state.missioniFatte = {};
    }
    // Rotazione random per run (v. ROTAZIONE_PER_STADIO sopra): mappa {stadio: [id,...]}, vive e
    // muore col pet ESATTAMENTE come missioniFatte sopra. Guardia difensiva analoga: NON estrae
    // nulla qui (l'estrazione vera e propria e' lazy, alla prima rosaDelGiorno dello stadio
    // interessato, v. sottoinsiemeRotazione), si limita a garantire che la struttura sia un
    // oggetto valido cosi' il resto del codice puo' leggerci/scriverci senza controlli extra.
    if (!state.rotazioneMissioni || typeof state.rotazioneMissioni !== 'object' || Array.isArray(state.rotazioneMissioni)) {
      state.rotazioneMissioni = {};
    }
    // Impresa della run (P3): id-scheda estratto per questo pet (v. impresaDellaRun), o null
    // finche' non e' ancora adulto/estratta. Guardia di FORMA (esiste il campo?), stessa
    // sanificazione duplicata in save.js/main.js migraState.
    if (typeof state.impresaRun === 'undefined') state.impresaRun = null;
  }

  function dataMissioni() {
    var data = window.PETQ.content && window.PETQ.content.data;
    return (data && data.missioni) || [];
  }

  // MULTI-PORZIONE (colonna Note di content/cibi.md, v. content.js estraiPorzioniCibo, decisione
  // fondatore 27 lug 2026): un reward "cibo:Nome" deve consegnare cibo.porzioni porzioni, non
  // sempre 1 (es. cibo:Arrosto -> +3). Cerca la scheda nel catalogo per nome con la STESSA via
  // d'accesso gia' usata poco sotto per il pool del regalo tutorial (window.PETQ.content.data.cibi):
  // fallback 1 se il cibo non e' nel catalogo (token con refuso, o dispensa ancora senza content
  // caricato) o non ha il campo, cosi' un reward mal scritto non rompe mai l'assegnazione.
  function porzioniCiboCatalogo(nome) {
    var tuttiCibi = (window.PETQ.content && window.PETQ.content.data && window.PETQ.content.data.cibi) || [];
    for (var i = 0; i < tuttiCibi.length; i++) {
      if (tuttiCibi[i].nome === nome) return tuttiCibi[i].porzioni || 1;
    }
    return 1;
  }

  // Un cibo puo' finire nel regalo di benvenuto del tutorial? Tre condizioni (10 lug 2026, col
  // catalogo meme/disonore il vecchio "tutti tranne le Crocchette" pescava roba sbagliata 1 volta
  // su 5):
  //  1. non e' la base gia' regalata (varieta');
  //  2. costo > 0: i cibi con costo '—' NON sono in vendita, sono premi di missione (Mela Dorata
  //     Blocchettosa, Zuppa della Nonna, Alette dell'Intervista Infuocata...) — regalarli al
  //     primo minuto di gioco svaluta i drop e mostra roba che il giocatore non sa da dove venga;
  //  3. nessun effetto negativo: i "CIBI DEL DISONORE" (Carbonera alla Panna, Fettuccine
  //     Alfredone, Pizza Ananassa, Spaghetto Tronco...) tolgono Carisma — un regalo di benvenuto
  //     che PEGGIORA il pet e' una pessima prima impressione.
  // Il controllo legge la lista effetti Tier 2 (v. content.js estraiEffettiCibo) con fallback
  // sulla vecchia coppia stat/statNome per gli oggetti-cibo costruiti a mano.
  function ciboAdattoAlRegaloTutorial(c) {
    if (!c || !c.nome || c.nome === TUTORIAL_CIBO_BASE) return false;
    if ((c.costo || 0) <= 0) return false;
    var effetti = (c.effetti && c.effetti.length) ? c.effetti :
      (c.statNome ? [{ nome: c.statNome, valore: c.stat || 0 }] : []);
    for (var i = 0; i < effetti.length; i++) {
      if ((effetti[i].valore || 0) < 0) return false;
    }
    return true;
  }

  // Rifornisce la dispensa del regalo di benvenuto del tutorial (v. costanti sopra): riusa
  // applicaRewardToken('cibo:Nome') gia' esistente per non duplicare la logica di incremento
  // qty. Il "cibo a caso" pesca dai soli cibi idonei (v. ciboAdattoAlRegaloTutorial); se il
  // filtro svuota il pool (content non caricato, catalogo ridotto) si ripiega sulle Crocchette
  // semplici: il tutorial deve chiudersi comunque con un regalo valido, mai a mani vuote.
  function rifornisciDispensaTutorial(state, rewardsOut) {
    for (var i = 0; i < TUTORIAL_CROCCHETTE_QTY; i++) {
      applicaRewardToken(state, 'cibo:' + TUTORIAL_CIBO_BASE, rewardsOut);
    }
    var tuttiCibi = (window.PETQ.content && window.PETQ.content.data && window.PETQ.content.data.cibi) || [];
    var candidati = tuttiCibi.filter(ciboAdattoAlRegaloTutorial);
    var nomeScelto = (candidati.length > 0) ? PETQ.rng.pick(candidati).nome : TUTORIAL_CIBO_BASE;
    for (var j = 0; j < TUTORIAL_CIBO_EXTRA_QTY; j++) {
      applicaRewardToken(state, 'cibo:' + nomeScelto, rewardsOut);
    }
  }

  function trovaScheda(id) {
    var elenco = dataMissioni();
    for (var i = 0; i < elenco.length; i++) {
      if (elenco[i].id === id) return elenco[i];
    }
    return null;
  }

  // ---------- rosa del giorno ----------

  // Hash semplice e stabile di una stringa in un intero a 32bit (somma pesata dei codici
  // carattere), usato come seed per il generatore mulberry32 dedicato alla rosa del giorno.
  function hashStringa(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) {
      h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
    }
    return h >>> 0;
  }

  // stesso algoritmo mulberry32 di rng.js, duplicato qui in un generatore LOCALE e indipendente
  // per non toccare lo stato del rng globale (usato per altri scopi: poop, drop armi, ecc.):
  // la rosa del giorno deve essere deterministica per data ma non deve alterare la sequenza
  // pseudocasuale globale ne' dipendere da quando viene chiamata nella sessione di gioco.
  function mulberry32Locale(a) {
    return function () {
      a |= 0;
      a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  var DIM_ROSA = 3;

  // Esclusione PERMANENTE delle missioni gia' fatte (bilanciamento.md "Missioni NON ripetibili",
  // decisione fondatore): una missione con id presente in state.missioniFatte e' esclusa per
  // sempre dalla rosa. Nessuna riammissione, nessun uso di COOLDOWN_GIORNI: conta solo la
  // PRESENZA della chiave (il valore memorizzato resta il giorno di gioco, per record).
  function escludiFatte(candidate, state) {
    var fatte = (state && state.missioniFatte && typeof state.missioniFatte === 'object') ? state.missioniFatte : {};
    return candidate.filter(function (m) { return fatte[m.id] == null; });
  }

  // Gate GENERICO missione su chiave=valore letta dalla scheda (Retention 2.0 Batch B,
  // DESIGN-DILEMMI-LAVORI.md SPEC MOTORE §6 "lavoro=<carriera>"): una scheda con
  // scheda[chiave] valorizzata entra in rosa SOLO se combacia col valore corrente passato dal
  // chiamante; una scheda che NON dichiara quella chiave (falsy: null/undefined/'') non e'
  // gated affatto e passa sempre — il filtro riguarda solo chi lo dichiara esplicitamente.
  // Parametrica sulla CHIAVE apposta (richiesta esplicita del fondatore, "costruirlo
  // RIUSABILE"): un futuro gate "leggenda=<nome>" (DESIGN-MISSIONI-LEGGENDE.md) eredita lo
  // STESSO meccanismo chiamando passaGateChiave(m, 'leggenda', leggendaCorrente) — niente if
  // speciale duplicato per ogni nuova chiave.
  function passaGateChiave(scheda, chiave, valoreCorrente) {
    var richiesto = scheda && scheda[chiave];
    if (!richiesto) return true;
    return richiesto === valoreCorrente;
  }

  // Rotazione random per run (v. ROTAZIONE_PER_STADIO in cima al modulo): garantisce che
  // state.rotazioneMissioni[stadio] esista e sia valido, estraendo N id CASUALI E DISTINTI dal
  // pool completo dello stadio SOLO se manca ancora (LAZY INIT — mai ri-estratto finche' esiste,
  // esattamente come richiesto: il sottoinsieme deve restare stabile per tutta la run). Il pool
  // qui e' quello COMPLETO dello stadio (tutte le schede, incluse quelle gia' fatte: il
  // sottoinsieme di rotazione e' indipendente da missioniFatte, che filtra dopo). Guardie:
  //  - pool <= N schede -> il sottoinsieme e' TUTTO il pool (niente rotazione effettiva, N e'
  //    solo un tetto massimo, non un minimo da forzare).
  //  - id nel sottoinsieme salvato che non esistono piu' nel pool (content cambiato sotto i
  //    piedi) -> scartati e reintegrati con estrazioni nuove fino a N, con un console.warn
  //    (tollerante, non deve mai rompere il boot).
  // Nessun caso speciale per boss/ritenta (m38/m45/m48 e affini): "tutte ruotano" e' la richiesta
  // esplicita del fondatore. Se in futuro servisse un elenco di schede "sempre presenti" (es.
  // boss di gate mai fuori rotazione), andrebbe aggiunto QUI (un filtro extra prima dello shuffle
  // o un merge forzato dopo), non altrove.
  // Persiste SUBITO (PETQ.save.save) quando estrae/reintegra, seguendo il pattern del resto del
  // codice per mutazioni di stato fuori dal tick normale (v. es. ui.js finalizzaNuovoPetInCasa +
  // debug panel: ogni mutazione manuale di state chiama save() subito dopo).
  function assicuraRotazioneStadio(state, stadio) {
    var n = ROTAZIONE_PER_STADIO[stadio];
    if (typeof n !== 'number' || n <= 0) return; // stadio senza voce -> nessuna rotazione, non tocca nulla
    assicuraStatoMissioni(state);

    // Grandi Imprese (P3, scheda.impresa): stadio=adulto ma NON fanno parte del pool di
    // rotazione per-run (hanno la loro estrazione dedicata 1-di-2 per personalita', v.
    // impresaDellaRun sotto): senza questa esclusione finirebbero nel pool delle 32+8 adulto.
    var poolCompleto = dataMissioni().filter(function (m) {
      return !m.fuoriRosa && m.id !== 'm0' && !m.impresa && (m.stadio || 'baby') === stadio;
    });
    var idPool = {};
    for (var p = 0; p < poolCompleto.length; p++) idPool[poolCompleto[p].id] = true;

    var attuale = state.rotazioneMissioni[stadio];
    var eGiaValido = Array.isArray(attuale);
    var mutato = false;

    if (eGiaValido) {
      // scarta id che non esistono piu' nel pool (content cambiato): tollerante, con warning.
      var superstiti = attuale.filter(function (id) { return idPool[id]; });
      if (superstiti.length !== attuale.length) {
        console.warn('PETQ.missions: rotazione run per stadio "' + stadio + '" conteneva id non piu\' validi, scartati e reintegrati');
        attuale = superstiti;
        mutato = true;
      }
    } else {
      attuale = [];
      mutato = true;
    }

    // reintegro/estrazione iniziale fino a N (o fino a esaurire il pool, se piu' piccolo di N)
    if (attuale.length < Math.min(n, poolCompleto.length)) {
      var giaDentro = {};
      for (var g = 0; g < attuale.length; g++) giaDentro[attuale[g]] = true;
      var mancanti = poolCompleto.filter(function (m) { return !giaDentro[m.id]; }).map(function (m) { return m.id; });
      var ordineCasuale = (PETQ.rng && typeof PETQ.rng.shuffle === 'function') ? PETQ.rng.shuffle(mancanti) : mancanti;
      var daAggiungere = n - attuale.length;
      attuale = attuale.concat(ordineCasuale.slice(0, Math.max(0, daAggiungere)));
      mutato = true;
    }

    if (mutato) {
      state.rotazioneMissioni[stadio] = attuale;
      if (PETQ.save && typeof PETQ.save.save === 'function') PETQ.save.save(state);
    }
  }

  // Impresa della run (P3, Grandi Imprese): la Grande Impresa estratta per QUESTO pet, tra le 2
  // schede impresa=1 della sua personalita' (v. content/missioni.md "# GRANDI IMPRESE"). Lazy
  // init ESATTAMENTE come assicuraRotazioneStadio sopra (stesso pattern): stabile, persistita
  // SUBITO (save()) appena estratta, mai ri-estratta finche' state.impresaRun esiste ed e' ancora
  // valida. L'estrazione scatta solo quando il pet e' adulto (prima ritorna null, senza toccare
  // nulla: niente Impresa finche' non si arriva li'). Guardie: id salvato non piu' presente nel
  // content (content cambiato sotto i piedi) -> warning + ri-estrazione; nessuna scheda impresa
  // per la personalita' del pet -> null senza eccezioni (non dovrebbe capitare, 2 per personalita'
  // nel design attuale, ma resta tollerante).
  /* ATTESA DELLA SVOLTA (Batch B, PORTA 4 — decisione del fondatore, opzione B).
   *
   * Prima l'Impresa si estraeva alla PRIMA chiamata utile, cioe' nell'istante in cui il pet
   * diventava adulto (giorno 8). Siccome la UI disegna subito un pin fisso e apribile, il
   * giocatore leggeva il Brief con il NOME della leggenda dentro ("in cima al Monte Mascellone
   * c'e' LUI: Giga Ciad") un giorno intero PRIMA che i volantini della Svolta glielo alludessero
   * — e i volantini per design ALLUDONO e non nominano mai. Il sorteggio anticipato bruciava
   * esattamente la sorpresa che la porta esiste per creare, e rendeva insensata l'opzione "decida
   * il destino": avrebbe solo confermato un'estrazione avvenuta il giorno prima.
   *
   * Ora: finche' la Svolta e' in attesa non si estrae nulla e impresaDellaRun ritorna null, quindi
   * il pin non compare e non c'e' niente da spoilerare. Decide la porta (porte.scegli), oppure la
   * roulette dell'opzione C nell'istante in cui il giocatore la scegle.
   *
   * RETE DI SICUREZZA: se la porta non venisse mai aperta, dal giorno GIORNO_IMPRESA_COMUNQUE si
   * estrae come si e' sempre fatto. Meglio un'Impresa non scelta che una run adulta senza Grande
   * Impresa, che sarebbe un finale che non arriva mai. */
  var GIORNO_IMPRESA_COMUNQUE = 11;

  function svoltaInAttesa(state) {
    // Difensiva su TUTTO: porte.js puo' non essere caricato (ordine dei tag, demo pubblica) e il
    // salvataggio puo' essere vecchio. In quel caso "non in attesa" -> comportamento di sempre.
    if (!window.PETQ.porte) return false;
    var giorni = (state.pet && typeof state.pet.giorniVita === 'number') ? state.pet.giorniVita : 0;
    if (giorni >= GIORNO_IMPRESA_COMUNQUE) return false;
    var p = state.porte;
    var fatte = (p && p.fatte && typeof p.fatte === 'object') ? p.fatte : {};
    return !fatte.svolta;
  }

  function impresaDellaRun(state) {
    if (!state || !state.pet || state.pet.stadio !== 'adulto') return null;
    assicuraStatoMissioni(state);
    if (typeof state.impresaRun === 'undefined') state.impresaRun = null;

    var personalita = state.pet.personalita;
    var poolImprese = dataMissioni().filter(function (m) {
      return m.impresa && m.personalita === personalita;
    });

    if (state.impresaRun) {
      var ancoraValida = poolImprese.some(function (m) { return m.id === state.impresaRun; });
      if (!ancoraValida) {
        console.warn('PETQ.missions: impresaRun salvata "' + state.impresaRun + '" non piu\' valida per personalita "' + personalita + '", ri-estraggo');
        state.impresaRun = null;
      }
    }

    if (!state.impresaRun) {
      if (poolImprese.length === 0) {
        console.warn('PETQ.missions: nessuna Grande Impresa trovata per personalita "' + personalita + '"');
        return null;
      }
      // Niente estrazione finche' la Svolta deve ancora parlare (v. commento sopra): il pin non
      // compare e la porta resta l'unica cosa che decide.
      if (svoltaInAttesa(state)) return null;
      var scelta = (PETQ.rng && typeof PETQ.rng.pick === 'function') ? PETQ.rng.pick(poolImprese) : poolImprese[0];
      state.impresaRun = scelta.id;
      if (PETQ.save && typeof PETQ.save.save === 'function') PETQ.save.save(state);
    }

    return trovaScheda(state.impresaRun);
  }

  // Estrae fino a DIM_ROSA (3) schede tra quelle mai fatte, con seed = hash del giorno di gioco,
  // garantendo copertura di almeno 3 stat diverse tra le scelte (forza/intelligenza/velocita/
  // carisma) quando il pool lo permette. Deterministico: stesso giorno di gioco -> stesso set,
  // sempre (usato anche per verificare la stabilita' nei test). Se la copertura minima non e'
  // raggiungibile per mancanza di schede valide, restituisce comunque le estratte con un
  // console.warn (non blocca il boot). Le missioni gia' fatte sono escluse per sempre (v.
  // escludiFatte): se il pool scende sotto 3 la rosa mostra MENO di 3 (niente ripescaggio); se
  // e' vuoto ritorna [] (il pet resta senza missioni, "opzione A" voluta dal fondatore).
  function rosaDelGiorno(state) {
    // Split baby/teen (bilanciamento.md "Separazione baby/teen", decisione fondatore "non far
    // ruotare le baby nelle teen"): un pet baby vede SOLO missioni baby, un teen SOLO teen. Lo
    // stadio della scheda arriva dal parser (content.js, header "# TEEN"/"# BABY" in missioni.md;
    // default 'baby' per le schede sopra il separatore). Un eventuale pet 'adulto' (P3) non ha
    // missioni corrispondenti -> rosa vuota, accettabile.
    var stadioPet = (state && state.pet && state.pet.stadio) ? state.pet.stadio : 'baby';
    // Talenti (Gruppo B, blocca_categoria=<categoria>, Pacifista): le missioni della categoria
    // bloccata sono escluse dalla rosa (mai piu' proposte, coerente con l'esclusione permanente).
    var bloccaCategoria = (PETQ.talenti && PETQ.talenti.categoriaBloccata) ? PETQ.talenti.categoriaBloccata : null;
    // Carriera corrente del pet, letta in modo difensivo: il modulo che la scrive (PETQ.lavoro)
    // puo' non esserci ancora o il salvataggio puo' essere vecchio. Senza carriera, le schede con
    // "lavoro=" restano fuori rosa e tutte le altre passano — che e' il comportamento di sempre.
    var carrieraCorrente = (state && state.lavoro && state.lavoro.carriera) ? state.lavoro.carriera : null;
    var tutte = dataMissioni().filter(function (m) {
      if (m.fuoriRosa || m.id === 'm0') return false;
      // Grandi Imprese (P3, scheda.impresa): stadio=adulto ma MAI nella rosa giornaliera normale
      // (sono un PIN FISSO gestito a parte da ui.js statoMappa/impresaDellaRun, v. sotto) —
      // altrimenti finirebbero pescate come una qualsiasi delle missioni adulto.
      if (m.impresa) return false;
      if ((m.stadio || 'baby') !== stadioPet) return false;
      if (bloccaCategoria && state && bloccaCategoria(state, m.categoria)) return false;
      // Gate carriera (Batch B): una scheda con "lavoro=<carriera>" entra in rosa SOLO con quella
      // carriera. Passa dalla funzione GENERICA qui sopra e non da un if scritto a mano, cosi' il
      // futuro gate "leggenda=" e' una riga e non un secondo meccanismo (richiesta del fondatore).
      if (!passaGateChiave(m, 'lavoro', carrieraCorrente)) return false;
      return true;
    });

    // Rotazione random per run (v. ROTAZIONE_PER_STADIO + assicuraRotazioneStadio sopra): se lo
    // stadio del pet ha una voce in config, la rosa pesca SOLO dal sottoinsieme di run (lazy init
    // alla prima chiamata, poi stabile finche' il pet e' in vita). Le missioni fuoriRosa/tutorial
    // sono gia' escluse da 'tutte' sopra e non passano da qui (la rotazione riguarda solo il pool
    // che arriva a rosaDelGiorno). Stadi senza voce in config: 'tutte' non viene toccato,
    // comportamento invariato (pesca da tutto il pool dello stadio).
    if (typeof ROTAZIONE_PER_STADIO[stadioPet] === 'number') {
      assicuraRotazioneStadio(state, stadioPet);
      var sottoinsieme = (state.rotazioneMissioni && Array.isArray(state.rotazioneMissioni[stadioPet]))
        ? state.rotazioneMissioni[stadioPet]
        : null;
      if (sottoinsieme) {
        var inRotazione = {};
        for (var r = 0; r < sottoinsieme.length; r++) inRotazione[sottoinsieme[r]] = true;
        tutte = tutte.filter(function (m) { return inRotazione[m.id]; });
      }
    }

    var candidate = escludiFatte(tutte, state);
    if (candidate.length === 0) {
      console.warn('PETQ.missions: nessuna scheda disponibile per la rosa del giorno');
      return [];
    }

    // Seed = hash del GIORNO DI GIOCO (intero), non della data reale: stabile entro lo stesso
    // giorno di gioco (giornoGioco e' costante finche' l'orologio non passa mezzanotte -> stessa
    // rosa), cambia al nuovo giorno. Prefisso 'g' cosi' e' comunque una stringa distintiva.
    var seed = hashStringa('g' + PETQ.clock.giornoCorrente(state));
    var rand = mulberry32Locale(seed);

    // Fisher-Yates deterministico con il generatore locale, poi si prova a soddisfare la
    // copertura stat scambiando schede finche' possibile (numero di tentativi limitato per
    // restare deterministico e non degenerare in loop).
    function estraiOrdine() {
      var idx = candidate.map(function (_, i) { return i; });
      for (var i = idx.length - 1; i > 0; i--) {
        var j = Math.floor(rand() * (i + 1));
        var tmp = idx[i]; idx[i] = idx[j]; idx[j] = tmp;
      }
      return idx;
    }

    function copertura(schede) {
      var stat = {};
      for (var i = 0; i < schede.length; i++) {
        var st = schede[i].stat || [];
        for (var j = 0; j < st.length; j++) stat[st[j]] = true;
      }
      return Object.keys(stat).length;
    }

    var ordine = estraiOrdine();
    var scelta = ordine.slice(0, DIM_ROSA).map(function (i) { return candidate[i]; });

    // se la copertura e' gia' >=3 o non ci sono abbastanza schede per migliorare, va bene cosi'
    if (copertura(scelta) < 3 && candidate.length > DIM_ROSA) {
      // riprova con permutazioni successive dello stesso stream deterministico finche' non
      // trova una combinazione valida o esaurisce i tentativi (cap 20, resta deterministico
      // perche' il generatore e' seedato sempre allo stesso modo per la stessa data)
      for (var tentativo = 0; tentativo < 20; tentativo++) {
        var ord2 = estraiOrdine();
        var tent = ord2.slice(0, DIM_ROSA).map(function (i) { return candidate[i]; });
        if (copertura(tent) >= 3) { scelta = tent; break; }
      }
      if (copertura(scelta) < 3) {
        console.warn('PETQ.missions: copertura stat della rosa del giorno sotto 3 dopo vari tentativi');
      }
    }

    return scelta;
  }

  function tutorialDaProporre(state) {
    assicuraStatoMissioni(state);
    if (state.tutorialFatto) return null;
    var m0 = trovaScheda('m0');
    if (!m0) {
      console.warn('PETQ.missions: scheda tutorial m0 non trovata in content.data.missioni');
      return null;
    }
    return m0;
  }

  // Risolve il tutorial M0: nessuna durata/avvio (e' un regalo di benvenuto istantaneo),
  // esito unico deciso dalla personalita' del pet (mai fallimento, come da scheda), stesso
  // formato di ritorno di risolvi() cosi' la UI puo' riusare la stessa schermata "esito".
  // Marca state.tutorialFatto = true cosi' non viene riproposto dal giorno 2 (v. tutorialDaProporre).
  function risolviTutorial(state) {
    assicuraStatoMissioni(state);
    var scheda = trovaScheda('m0');
    if (!scheda) {
      return { ok: false, msg: traduci('Scheda tutorial non trovata.') };
    }
    if (state.tutorialFatto) {
      return { ok: false, msg: traduci('Tutorial gia\' completato.') };
    }

    var personalita = state.pet ? state.pet.personalita : null;
    var esito = null;
    for (var i = 0; i < (scheda.esiti || []).length; i++) {
      if (scheda.esiti[i].personalita === personalita) { esito = scheda.esiti[i]; break; }
    }
    if (!esito) {
      console.warn('PETQ.missions: nessun esito tutorial per personalita "' + personalita + '", uso il primo disponibile');
      esito = scheda.esiti[0] || null;
    }
    if (!esito) {
      return { ok: false, msg: traduci('Scheda tutorial senza esiti.') };
    }

    var rewards = [];
    for (var j = 0; j < (esito.reward || []).length; j++) {
      try {
        applicaRewardToken(state, esito.reward[j], rewards);
      } catch (e) {
        console.warn('PETQ.missions: errore applicando reward tutorial "' + esito.reward[j] + '"', e);
      }
    }

    // Negozio unico (GDD "Economia" -> "Spesa e dispensa"): il tutorial, oltre al regalo di
    // personalita' sopra, rifornisce la dispensa di partenza e sblocca il Negozio (m0) come
    // shop sempre accessibile (v. statoMappa/pannelloShop in ui.js).
    try {
      rifornisciDispensaTutorial(state, rewards);
    } catch (e) {
      console.warn('PETQ.missions: errore rifornendo la dispensa del tutorial', e);
    }
    state.negozioSbloccato = true;
    state.tutorialFatto = true;

    return {
      ok: true,
      tipo: 'tutorial',
      missioneId: scheda.id,
      chiaveEsito: esito.chiave,
      testo: esito.testo || '',
      scenaId: scenaIdPer(scheda, esito),
      rewards: rewards
    };
  }

  // ---------- avvio / stato missione in corso ----------

  // Durata effettiva di una missione dopo i talenti (Gruppo B, PROTOTIPO 2 Blocco 9):
  // somma il delta globale (missione_durata=-1h, Fulmine di Quartiere) e quello di categoria
  // (bonus_missione=<categoria>:...,durata-1h, Topo di Biblioteca) alla durata base della
  // scheda, poi clampa a un minimo di 1 ora (durata mai a 0 o negativa: "min sensato" richiesto
  // dal brief). Espone il dettaglio per i test (_durataMissioneEffettivaMs).
  var DURATA_MISSIONE_MIN_MS = 3600000; // 1h

  function durataMissioneEffettivaMs(state, scheda) {
    var base = scheda.durataMs || 3600000;
    var deltaOreGlobale = (PETQ.talenti && PETQ.talenti.missioneDurataDeltaH) ? PETQ.talenti.missioneDurataDeltaH(state) : 0;
    var deltaOreCategoria = 0;
    if (scheda.categoria && PETQ.talenti && PETQ.talenti.bonusMissioneCategoria) {
      deltaOreCategoria = PETQ.talenti.bonusMissioneCategoria(state, scheda.categoria).durataDeltaH;
    }
    var effettiva = base + (deltaOreGlobale + deltaOreCategoria) * 3600000;
    return Math.max(DURATA_MISSIONE_MIN_MS, effettiva);
  }

  // Missioni SOLO di giorno (decisione fondatore, playtest 7 lug 2026): finestra [6:00, 19:00).
  // Di sera/notte niente partenze — le eccezioni (perk "lavoro in nero", missioni tag notte)
  // arriveranno in P3. Il tutorial m0 NON passa da avvia() e resta sempre fattibile.
  var ORA_MISSIONI_INIZIO = 6;
  var ORA_MISSIONI_FINE = 19;

  function orarioMissioniAperto(state) {
    var og = (PETQ.clock && PETQ.clock.oraGioco) ? PETQ.clock.oraGioco(state) : { ore: 12 };
    return og.ore >= ORA_MISSIONI_INIZIO && og.ore < ORA_MISSIONI_FINE;
  }

  function avvia(state, id) {
    assicuraStatoMissioni(state);
    var scheda = trovaScheda(id);
    if (!scheda || scheda.tutorial) {
      return { ok: false, msg: traduci('Missione non valida.') };
    }
    if (state.missione) {
      return { ok: false, msg: traduci('Una missione e\' gia\' in corso.') };
    }
    if (!orarioMissioniAperto(state)) {
      return { ok: false, msg: traduci('A quest\'ora non si parte: le missioni si fanno dalle 6:00 alle 19:00.') };
    }
    // limite missioni/giorno (fix playtest, esteso P3 BATCH 4 "missioni_giorno=2", Lavoro in
    // Nero): missioniOggiCount viene marcato alla RISOLUZIONE (v. risolvi) e confrontato col
    // tetto dei talenti (default 1, 2 con Lavoro in Nero — stesso pattern di
    // allenamentiPerGiorno/parolePerGiorno). state.missioneGiorno resta INVARIATO (giorno
    // dell'ultima missione RISOLTA, letto da ui.js missioneEsauritaOggi per l'hint sulla mappa e
    // usato come marcatore "e' successo qualcosa oggi"): il vero gate ora e' il contatore
    // separato sotto, cosi' un pet senza Lavoro in Nero si comporta ESATTAMENTE come prima
    // (max 1) e uno con Lavoro in Nero puo' avviarne una seconda lo stesso giorno di gioco. Il
    // tutorial M0 non passa da qui e non conta (risolviTutorial e' una funzione separata).
    var maxMissioniGiorno = (PETQ.talenti && PETQ.talenti.missioniPerGiorno) ? PETQ.talenti.missioniPerGiorno(state) : 1;
    var missioniFatteOggi = (state.missioniOggiGiorno === PETQ.clock.giornoCorrente(state)) ? (state.missioniOggiCount || 0) : 0;
    if (missioniFatteOggi >= maxMissioniGiorno) {
      // Testo neutro sul numero: il tetto e' 2 di default (decisione fondatore 10 lug, "giorno
      // denso") e 3 con Lavoro in Nero — il vecchio "Una missione al giorno" mentiva.
      return { ok: false, msg: traduci('Missioni finite per oggi: torna domani.') };
    }
    if (state.sonno) {
      return { ok: false, msg: (state.pet && state.pet.nome ? state.pet.nome : traduci('Il pet')) + traduci(' sta dormendo.') };
    }
    if (state.allenamento) {
      return { ok: false, msg: (state.pet && state.pet.nome ? state.pet.nome : traduci('Il pet')) + traduci(' si sta allenando.') };
    }
    if (state.gioco) {
      return { ok: false, msg: (state.pet && state.pet.nome ? state.pet.nome : traduci('Il pet')) + traduci(' sta giocando: aspetta che finisca.') };
    }
    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo A, "ignora_rifiuto_energia", Fisico Bestiale):
    // niente rifiuto missione per Energia bassa, stessa guardia usata in care.train.
    var ignoraEnergiaMissione = PETQ.talenti && PETQ.talenti.ignoraRifiutoEnergia && PETQ.talenti.ignoraRifiutoEnergia(state);
    if (!ignoraEnergiaMissione && PETQ.pet && PETQ.pet.energiaSottoSoglia && PETQ.pet.energiaSottoSoglia(state.pet)) {
      return { ok: false, msg: traduci('Troppo stanco per partire in missione.'), battutaPool: 'sonno' };
    }
    var costo = scheda.costo || 0;
    if ((state.coins || 0) < costo) {
      return { ok: false, msg: traduci('Monete insufficienti.') };
    }

    var durataEffettivaMs = durataMissioneEffettivaMs(state, scheda);
    state.coins -= costo;
    state.missione = {
      id: id,
      fine: Date.now() + durataEffettivaMs,
      costo: costo, // salvato qui cosi' risolvi() puo' applicare rimborsoCosto senza ripescare la scheda
      durataEffettivaMs: durataEffettivaMs // salvata cosi' risolvi() calcola il costo Energia sulla durata REALE (post talenti), non quella base della scheda
    };

    // Streak "Giorni di carica": mandare il pet in missione e' cura a tutti gli effetti (lo
    // segui, lo prepari, lo aspetti) — il doc di design la elenca fra le azioni valide.
    // Qui e non prima: contano solo le partenze ANDATE A BUON FINE.
    if (window.PETQ.streak && PETQ.streak.registraAzioneCura) {
      PETQ.streak.registraAzioneCura(state);
    }

    return { ok: true, msg: (scheda.titolo || id) + ' avviata.' };
  }

  function inCorso(state) {
    assicuraStatoMissioni(state);
    if (!state.missione) return null;
    return trovaScheda(state.missione.id);
  }

  function tempoRimasto(state) {
    assicuraStatoMissioni(state);
    if (!state.missione) return 0;
    var restante = state.missione.fine - Date.now();
    return restante > 0 ? restante : 0;
  }

  // ---------- valutazione condizioni (stat effettiva = base + bonus passivi piazzati, cap 2) ----------

  // Bonus passivo totale per stat = arredi piazzati (cap +2, v. arredi.bonusPassivi) + talenti
  // attivi (passivo=stat+N, nessun cap dedicato, v. talenti.js bonusStatTutte). Le condizioni
  // missione (requisiti stat) devono vedere la stat "vera" del pet incluso QUALSIASI bonus
  // passivo, non solo quello degli arredi: stesso principio del GDD "niente spoiler alla
  // scelta" applicato in modo coerente a tutte le fonti di bonus permanente.
  // Indossabili (PROTOTIPO 2): un solo vestito indossato alla volta (state.indossato) da' un
  // bonus stat passivo MENTRE indossato. Sorgente separata dagli arredi (nessun cap dedicato,
  // come i talenti). "Completo da Chef" NON e' qui: e' un effetto speciale sul cibo (care.feed),
  // non un bonus-stat. Difensivo: il bonus scatta solo se il vestito indossato e' davvero posseduto.
  // FONTE DI VERITA' = content/arredi.md (sezioni "Indossabili"/"Indossabili MEME", parsate da
  // content.js parseIndossabili -> PETQ.content.data.indossabili con gli effetti nel formato Tier 2
  // dei cibi). La mappa qui sotto NON e' piu' la fonte di verita': resta SOLO come rete di
  // sicurezza per il caso in cui il contenuto non sia caricato (boot prima di content.load, test
  // che costruiscono lo stato a mano, content-bundle rotto su file://). Senza fallback un vestito
  // indossato smetterebbe di dare bonus IN SILENZIO, che e' peggio di un valore un po' vecchio.
  // NON aggiungere qui i vestiti nuovi: si aggiungono nella tabella di arredi.md e basta.
  var EFFETTI_INDOSSABILI = {
    'Parrucchino di Elvis':  { carisma: 2 },
    'Camice del Dottore':    { intelligenza: 1 },
    'Toga da Avvocato':      { carisma: 2, intelligenza: 1 },
    'Maschera da Wrestler':  { forza: 2, carisma: 1 },
    'Microfono da Cantante': { carisma: 2 },
    'Bouquet da Sposa':      { carisma: 1 },
    // Batch rotazione TEEN (M83/M93/M95, 10 lug — valori da arredi.md sezione Indossabili)
    'Fischietto dell\'Istruttore': { forza: 1, carisma: 1 },
    'Cuffie da DJ':               { carisma: 2 },
    'Costume da Protagonista':    { carisma: 1, intelligenza: 1 },
    'Costume dell\'Allenatore':   { velocita: 2 },
    // ADULTO (P3, M33-M64 — dormienti finche' lo stadio adulto non esiste; valori da arredi.md
    // sezione Indossabili). 'Cappello da Chef' e' un bonus-stat normale (l'effetto-cibo resta
    // esclusiva del Completo da Chef teen).
    'Cintura Mondiale':          { forza: 3 },
    'Guantoni Consumati':        { forza: 2 },
    'Accappatoio del Campione':  { forza: 3 },
    'Scarpe d\'Oro':             { velocita: 3 },
    'Tavola Leggendaria':        { velocita: 3 },
    'Casco Spaziale':            { intelligenza: 2 },
    'Cappello da Detective':     { intelligenza: 2, carisma: 1 },
    'Corona d\'Alloro':          { intelligenza: 2, carisma: 1 },
    'Medaglione del Concilio':   { carisma: 3 },
    'Fascia da Sindaco':         { carisma: 2, intelligenza: 1 },
    'Chitarra Fiammante':        { carisma: 3 },
    'Cappello da Chef':          { intelligenza: 2 },
    'Casco da Corriere Spaziale': { velocita: 2 },
    'Cintura del Peperoncino':   { forza: 2 }
    // 'Completo da Chef' -> effetto speciale nel cibo, non un bonus-stat
  };
  function sommaStatVuota() {
    return { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
  }

  // effetti[] (formato Tier 2 condiviso coi cibi, v. content.js estraiEffettiCibo) -> mappa stat.
  // Si sommano SOLO gli effetti tipo 'rpg': i malus sono numeri col segno e passano di qui come
  // gli altri (Sandaloni col Calzino = Velocita +1 / Carisma -2). Le voci 'benessere' (Felicita)
  // non sono bonus-stat e vengono ignorate qui (per gli arredi le usa arredi.felicitaPassivaCasa).
  function statDaEffetti(effetti) {
    var somma = sommaStatVuota();
    if (!effetti || !effetti.length) return somma;
    for (var i = 0; i < effetti.length; i++) {
      var e = effetti[i];
      if (!e || e.tipo !== 'rpg' || !e.nome) continue;
      if (typeof somma[e.nome] === 'number') somma[e.nome] += (e.valore || 0);
    }
    return somma;
  }

  // Cerca una voce per nome in una delle liste di PETQ.content.data (indossabili/armi/arredi).
  // Ritorna null se il contenuto non e' caricato: i chiamanti ricadono sulla mappa hardcodata.
  function voceContenuto(chiaveLista, nome) {
    var data = PETQ.content && PETQ.content.data;
    var lista = (data && data[chiaveLista]) || [];
    for (var i = 0; i < lista.length; i++) {
      if (lista[i] && lista[i].nome === nome) return lista[i];
    }
    return null;
  }

  function statDaMappa(mappa, nome) {
    var somma = sommaStatVuota();
    var eff = mappa[nome];
    if (!eff) return somma;
    for (var i = 0; i < STAT_NOMI.length; i++) {
      var s = STAT_NOMI[i];
      if (typeof eff[s] === 'number') somma[s] += eff[s];
    }
    return somma;
  }

  function bonusIndossato(state) {
    var somma = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    // DIFESA dati legacy (decisione fondatore: le leggende, pet.razza === 'leggenda', non
    // indossano vestiti — la UI e' gia' stata sistemata per non permetterlo, v. ui.js
    // riga "indossato: (pet.razza === 'leggenda') ? null : ..." nella build del petLike per lo
    // sprite). Ma un salvataggio VECCHIO puo' avere una leggenda con state.indossato ancora
    // valorizzato da prima di quella regola: senza questo controllo il bonus stat continuerebbe
    // ad applicarsi silenziosamente anche se la leggenda non lo mostra addosso. Ritorna lo
    // stesso valore neutro di "niente equipaggiato" (v. sopra), niente di nuovo da inventare.
    if (state && state.pet && state.pet.razza === 'leggenda') return somma;
    if (!state || !state.indossato) return somma;
    // solo se davvero posseduto (difensivo contro state.indossato "orfano" dopo un reset)
    if (Array.isArray(state.indossabili) && state.indossabili.indexOf(state.indossato) === -1) return somma;
    // 1) contenuto (fonte di verita'). Una voce trovata vale anche se ha effetti vuoti: e' il caso
    // del Completo da Chef, che ha un EFFETTO SPECIALE sul cibo (care.feed) e nessun bonus-stat —
    // ritornare zero e' la risposta GIUSTA, non un dato mancante, quindi niente fallback qui.
    var voce = voceContenuto('indossabili', state.indossato);
    if (voce) return statDaEffetti(voce.effetti);
    // 2) rete di sicurezza (contenuto non caricato, v. commento su EFFETTI_INDOSSABILI)
    return statDaMappa(EFFETTI_INDOSSABILI, state.indossato);
  }

  // Armeria (FASE SPRITE): arma impugnata (state.armaEquip, slot singolo) -> bonus Forza passivo
  // MENTRE impugnata. Sorgente separata come gli indossabili (nessun cap dedicato). L'equip e' gated
  // dal perk Weapon Wielder nell'UI; qui il bonus scatta se armaEquip e' valorizzato (lo si valorizza
  // solo dall'Armeria, gated). 4 M7 = +1 Forza, 5 Kaiju = +2 Forza, Pistola = +4 Forza / -2 Carisma.
  // Come per gli indossabili: la FONTE DI VERITA' e' content/arredi.md. L'arma esclusiva (Pistola
  // Spara-Spazzatura) sta nella sezione "Armi" -> content.data.armi; le altre 9 (4 di M7 + 5 Kaiju)
  // sono anche ARREDI normali e i loro effetti stanno nelle tabelle arredi -> content.data.arredi.
  // Si guardano entrambe, in quest'ordine. Mappa hardcodata = solo rete di sicurezza (v. sopra).
  var EFFETTI_ARMA = {
    'Bastone da combattimento': { forza: 1 }, 'Sai gemelli': { forza: 1 }, 'Nunchaku arrugginiti': { forza: 1 }, 'Katane a farfalla': { forza: 1 },
    'Spadone': { forza: 2 }, 'Martellone': { forza: 2 }, 'Doppie Lame': { forza: 2 }, 'Arco Pesante': { forza: 2 }, 'Alabarda': { forza: 2 },
    'Pistola Spara-Spazzatura': { forza: 4, carisma: -2 }
  };
  // true se l'arma e' davvero tra gli arredi del giocatore (posseduti o piazzati in una stanza).
  // Difensivo, stesso principio di bonusIndossato: le armi sono arredi VENDIBILI, e se vendi
  // quella equipaggiata il bonus non deve restare appeso.
  function armaPosseduta(state, nome) {
    if (!state || !state.arredi || !nome) return false;
    var poss = state.arredi.posseduti || [];
    for (var i = 0; i < poss.length; i++) { if (poss[i] && poss[i].nome === nome) return true; }
    var piaz = state.arredi.piazzati || {};
    for (var stanza in piaz) {
      if (!Object.prototype.hasOwnProperty.call(piaz, stanza)) continue;
      var lista = piaz[stanza] || [];
      for (var j = 0; j < lista.length; j++) { if (lista[j] && lista[j].nome === nome) return true; }
    }
    return false;
  }

  function bonusArmaEquip(state) {
    var somma = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    if (!state || !state.armaEquip) return somma;
    if (!armaPosseduta(state, state.armaEquip)) return somma; // arma venduta -> niente bonus fantasma
    var voce = voceContenuto('armi', state.armaEquip) || voceContenuto('arredi', state.armaEquip);
    if (voce) return statDaEffetti(voce.effetti);
    return statDaMappa(EFFETTI_ARMA, state.armaEquip);
  }

  function bonusStatCombinato(state) {
    var daArredi = (PETQ.arredi && PETQ.arredi.bonusPassivi) ? PETQ.arredi.bonusPassivi(state) : {};
    var daTalenti = (PETQ.talenti && PETQ.talenti.bonusStatTutte) ? PETQ.talenti.bonusStatTutte(state) : {};
    var daIndossato = bonusIndossato(state);
    var daArma = bonusArmaEquip(state);
    var somma = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    for (var i = 0; i < STAT_NOMI.length; i++) {
      var s = STAT_NOMI[i];
      somma[s] = (daArredi[s] || 0) + (daTalenti[s] || 0) + (daIndossato[s] || 0) + (daArma[s] || 0);
    }
    return somma;
  }

  function statEffettiva(pet, bonusStat, nomeStat) {
    var base = (pet && pet.rpg && typeof pet.rpg[nomeStat] === 'number') ? pet.rpg[nomeStat] : 0;
    var bonus = (bonusStat && typeof bonusStat[nomeStat] === 'number') ? bonusStat[nomeStat] : 0;
    return base + bonus;
  }

  // Valutatore condizioni esposto per i test (prefisso _ = interno ma accessibile).
  // cond e' l'albero gia' pre-parsato da PETQ.content.parseCondizione (fatto una volta in
  // content.js al parsing della scheda); qui costruiamo solo il ctx e deleghiamo la
  // valutazione ricorsiva a PETQ.content.valutaCondizione (stessa grammatica, stessa fonte
  // di verita', evita di duplicare il valutatore ad albero in due file).
  // ctx per il valutatore condiviso: personalita + stat effettive (base + bonus arredi/talenti)
  // + talenti = lista dei nomi-talento del pet in lowercase (per i termini "talento:<nome>").
  // `state` e' un 4o parametro OPZIONALE (aggiunto P3 BATCH 4): serve solo per interrogare
  // PETQ.talenti.haGalaxyBrain (che richiede lo `state` completo, non solo `pet`). Retro-
  // compatibile: i call site che non lo passano (o i test) si comportano come prima, Galaxy
  // Brain semplicemente non scatta senza state (stesso principio difensivo del resto del modulo).
  function _valutaCond(cond, pet, bonusStat, state) {
    if (!cond) return true; // standard: nessuna condizione, sempre vera
    // Sentinella {op:'mai'} di content.parseCondizione (condizione scritta ma interamente
    // malformata, refuso non recuperabile): SEMPRE falsa, mai un esito (specie un super)
    // regalato per un errore di battitura nella scheda. Esplicito qui invece di lasciare che
    // PETQ.content.valutaCondizione la scarti in fondo, cosi' il "sempre falso" e' garantito
    // anche se un domani questo file smettesse di delegare la valutazione a content.js.
    if (cond.op === 'mai') return false;
    var statCtx = {
      forza: statEffettiva(pet, bonusStat, 'forza'),
      intelligenza: statEffettiva(pet, bonusStat, 'intelligenza'),
      velocita: statEffettiva(pet, bonusStat, 'velocita'),
      carisma: statEffettiva(pet, bonusStat, 'carisma')
    };
    // Talenti (P3 BATCH 4, "stat_come_int", Galaxy Brain): SOLO nella valutazione delle
    // condizioni missione, ogni stat RPG vale almeno quanto l'Intelligenza (le stat basse
    // "valgono" come l'Int, v. talenti.md). Applicato QUI su una copia locale di statCtx, MAI su
    // pet.rpg/bonusStat: l'HUD e i valori reali restano intoccati, coerente col brief ("non deve
    // toccare l'HUD ne' i valori reali: solo la VALUTAZIONE delle condizioni missione").
    if (state && PETQ.talenti && PETQ.talenti.haGalaxyBrain && PETQ.talenti.haGalaxyBrain(state)) {
      var intEff = statCtx.intelligenza;
      statCtx.forza = Math.max(statCtx.forza, intEff);
      statCtx.velocita = Math.max(statCtx.velocita, intEff);
      statCtx.carisma = Math.max(statCtx.carisma, intEff);
      // intelligenza stessa resta invariata (max con se stessa e' un no-op)
    }
    var ctx = {
      personalita: pet ? pet.personalita : null,
      stat: statCtx,
      // Estensione DSL (audit 17 lug 2026, vie promesse dalla prosa di M53/M60): perk-medaglietta
      // del pet (termine "perk:<nome>"), arma equipaggiata (termine "arma"), Felicita' di
      // benessere (termine "fel<num>"). Tutti letti da state: senza state (vecchi call site/test)
      // i termini valutano FALSO/pieno — difensivo, coerente col resto del modulo.
      perks: (state && Array.isArray(state.perks)) ? state.perks : [],
      // flags: Retention 2.0 Batch B (DESIGN-DILEMMI-LAVORI.md SPEC MOTORE §2, termine
      // "flag:<nome>" nel DSL condizioni). Stessa guardia difensiva di perks: senza state o
      // senza state.flags il termine valuta FALSO (mai un gate segreto sbloccato per un dato
      // mancante).
      flags: (state && Array.isArray(state.flags)) ? state.flags : [],
      armaEquip: !!(state && state.armaEquip),
      benessere: {
        felicita: (pet && pet.stats && typeof pet.stats.felicita === 'number') ? pet.stats.felicita : 100
      },
      talenti: (pet && Array.isArray(pet.talenti))
        ? pet.talenti.map(function (t) {
            // normalizza SENZA spazi + lowercase, cosi' "Boss di Quartiere" combacia col
            // riferimento "talento:bossdiquartiere" (stessa normalizzazione in content.parseTermine)
            return (t && t.nome ? String(t.nome) : '').trim().toLowerCase().replace(/\s+/g, '');
          }).filter(Boolean)
        : []
    };
    return PETQ.content.valutaCondizione(cond, ctx);
  }

  // ---------- scelta esito (regole di precedenza) ----------

  // Ritorna l'oggetto esito scelto secondo le regole:
  // 1) super (per priorita crescente: 1=Amicizia, 2=Dominio, 3=Intimidazione), poi fallimenti
  //    (ordine di apparizione nella scheda), altrimenti standard. Super batte sempre fallimento.
  // 2) perk di categoria attivo -> super garantito: per missioni con un solo super, scatta
  //    sempre (bypassa la sua cond); per M7 (tre super) forza Dominio (priorita 2) SOLO se
  //    Amicizia/Intimidazione non sono gia' soddisfatte autonomamente.
  function scegliEsito(scheda, pet, bonusStat, perksAttivi, state) {
    var esiti = scheda.esiti || [];
    var superList = esiti.filter(function (e) { return e.tipo === 'super'; });
    var fallList = esiti.filter(function (e) { return e.tipo === 'fallimento'; });
    var standardList = esiti.filter(function (e) { return e.tipo === 'standard'; });

    // ordina i super per priorita crescente (1 prima); chi non ha priorita va in fondo
    superList = superList.slice().sort(function (a, b) {
      var pa = (typeof a.priorita === 'number') ? a.priorita : 99;
      var pb = (typeof b.priorita === 'number') ? b.priorita : 99;
      return pa - pb;
    });

    var perkCategoria = scheda.categoria ? PERK_PER_CATEGORIA[scheda.categoria] : null;
    var perkAttivoQui = perkCategoria && perksAttivi.indexOf(perkCategoria) !== -1;

    // Vie TAG. Le schede portano un array scheda.tag (v. content.js).
    // - talentoTagQui: un talento perk_tag del pet copre uno dei tag della scheda (Amante della
    //   Natura -> 'natura', Inventore -> 'invenzione'): super GARANTITO + NIENTE fallimento.
    // - tagPerkQui: un perk-MEDAGLIETTA per-tag del pet (PERK_PER_TAG, es. sabotatore->gara,
    //   parkour->inseguimento, cacciatoremostri->mostro) copre uno dei tag della scheda. Forza il
    //   super MA NON sopprime i fallimenti (a differenza del talento). NESSUNA esclusione col
    //   perk-categoria: overlap innocuo (decisione fondatore), basta il match del tag.
    var tags = scheda.tag || [];
    var talentoTagQui = tags.some(function (tg) {
      return PETQ.talenti && PETQ.talenti.perkTagAttivo && PETQ.talenti.perkTagAttivo(state, tg);
    });
    var tagPerkQui = tags.some(function (tg) {
      var p = PERK_PER_TAG[tg];
      return p && perksAttivi.indexOf(p) !== -1;
    });

    // Talenti (P3 BATCH 4, "perk_categoria=lavoretti", La Nonna Ti Vede): generalizzazione di
    // talentoTagQui ma su CATEGORIA scheda invece che su tag (v. talenti.js perkCategoriaAttivo).
    // Stessa precedenza/comportamento di talentoTagQui: super GARANTITO + NIENTE fallimento.
    var talentoCategoriaQui = scheda.categoria && PETQ.talenti && PETQ.talenti.perkCategoriaAttivo &&
      PETQ.talenti.perkCategoriaAttivo(state, scheda.categoria);

    // Oracolo (giocattolo Sfera Sentenziosa, responso "E' deciso"): la SOGLIA SUPER della prossima
    // missione scende di 3. Non esiste un campo "soglia" nelle schede (le vie super sono condizioni
    // stat), quindi "soglia piu' bassa di 3" si realizza alzando di 3 le stat SOLO nella valutazione
    // delle condizioni super qui sotto: e' la stessa cosa vista dal lato opposto ed e' l'unico punto
    // toccato (fallimenti e standard restano valutati sulle stat vere). Copia locale di bonusStat:
    // MAI toccare pet.rpg ne' l'HUD, stesso principio del talento Galaxy Brain in _valutaCond.
    var scontoSuper = (PETQ.giocattoli && PETQ.giocattoli.scontoSogliaSuper) ? PETQ.giocattoli.scontoSogliaSuper(state) : 0;
    var bonusStatSuper = bonusStat;
    if (scontoSuper > 0) {
      bonusStatSuper = {};
      for (var bs = 0; bs < STAT_NOMI.length; bs++) {
        bonusStatSuper[STAT_NOMI[bs]] = (bonusStat[STAT_NOMI[bs]] || 0) + scontoSuper;
      }
    }

    // 1) super la cui condizione e' soddisfatta autonomamente, in ordine di priorita
    for (var i = 0; i < superList.length; i++) {
      if (_valutaCond(superList[i].cond, pet, bonusStatSuper, state)) {
        return superList[i];
      }
    }

    // 2) perk-categoria/talento/perk-tag/perk-categoria-talento attivo -> super garantito. Per
    // schede con un solo super, e' quello (bypassa cond). Per M7 (tre super), il perk
    // Combattimento forza il super "generico" cioe' quello con priorita piu' alta tra quelli
    // SENZA condizione di personalita specifica gia' esclusa sopra: dato che nessuna cond e'
    // stata soddisfatta al punto 1, il generico e' Dominio (priorita=2, per costruzione delle
    // schede attuali; non e' hardcoded sul nome "dominio" ma sul fatto che e' l'unico rimasto
    // candidato "di forza pura" nella scheda M7 reale).
    // AUTO-SUPER DISABILITATO sulle Grandi Imprese (P3, scheda.impresa): il finale si vince SOLO
    // con le condizioni scritte sulla scheda (stat alta o la via alternativa dedicata, es.
    // talento:facciadibronzo) — i perk di categoria/tag e i talenti perk_tag/perk_categoria NON
    // devono garantire il super qui, altrimenti un perk trasversale come Chissenefrega
    // (perk_tag=social) auto-supererebbe M69 (tag social) solo per il tag, bypassando il senso
    // del finale. Bypassato interamente per scheda.impresa: si scende dritti ai fallimenti/
    // standard sotto (il blocco 2b appena sotto e' bypassato per lo stesso motivo).
    if (!scheda.impresa && (perkAttivoQui || talentoTagQui || tagPerkQui || talentoCategoriaQui) && superList.length > 0) {
      var forzato = superList.length === 1
        ? superList[0]
        : trovaSuperGenerico(superList);
      if (forzato) return forzato;
    }

    // 2b) talento perk_tag/perk_categoria -> "NIENTE fallimento" anche nel caso di bordo in cui
    // non ci sia alcun super da forzare (superList vuota): salta i fallimenti e vai diritto allo
    // standard. I perk-medaglietta per-tag invece NON sopprimono i fallimenti: se non c'e' super,
    // degradano al comportamento normale (prosegue ai fallimenti sotto). Bypassato per
    // scheda.impresa (v. commento sopra): sulle Imprese i fallimenti restano SEMPRE quelli
    // scritti in scheda, mai soppressi da un talento perk_tag/perk_categoria.
    if (!scheda.impresa && (talentoTagQui || talentoCategoriaQui) && standardList.length > 0) {
      return standardList[0];
    }

    // 3) fallimenti: per priorita crescente quando dichiarata (m6/m9/m10 la dichiarano nelle
    // schede con doppio fallimento sovrapponibile), altrimenti in ordine di apparizione.
    // Fix audit 17 lug 2026: prima la priorita sui fallimenti era IGNORATA (solo ordine di
    // apparizione) — comportamento identico oggi (l'ordine nel file combacia con le priorita
    // dichiarate) ma ora la dichiarazione fa fede anche se un giorno le righe si spostano.
    var fallOrdinati = fallList.slice().sort(function (a, b) {
      var pa = (typeof a.priorita === 'number') ? a.priorita : 99;
      var pb = (typeof b.priorita === 'number') ? b.priorita : 99;
      return pa - pb;
    });
    for (var j = 0; j < fallOrdinati.length; j++) {
      if (_valutaCond(fallOrdinati[j].cond, pet, bonusStat, state)) {
        return fallOrdinati[j];
      }
    }

    // 4) standard (default)
    if (standardList.length > 0) return standardList[0];

    console.warn('PETQ.missions: nessun esito standard trovato per ' + scheda.id + ', scheda malformata');
    return null;
  }

  // Il super "generico" di una scheda multi-super e' quello con chiave 'dominio' se presente
  // (M7); altrimenti, per generalita' futura, quello con priorita mediana/piu' alta tra quelli
  // rimasti (fallback che non blocca se un giorno si aggiungono altre schede multi-super).
  function trovaSuperGenerico(superList) {
    for (var i = 0; i < superList.length; i++) {
      if (superList[i].chiave === 'dominio') return superList[i];
    }
    console.warn('PETQ.missions: super "generico" non identificato per chiave, uso il primo per priorita');
    return superList[0] || null;
  }

  // Talenti (Gruppo B, Bad Loser, "se fallimento_carattere: ..."): un fallimento e' "di
  // carattere" quando la sua cond include una condizione di PERSONALITA' che coincide con
  // quella del pet (es. "cond= maleducato & carisma<=0" per un pet maleducato) — cioe' il
  // fallimento e' scattato (anche) per come e' fatto il pet, non solo per stat basse. Cerca
  // ricorsivamente nell'albero condizione gia' pre-parsato (stessa forma di valutaCondizione).
  function contieneCondPersonalita(nodo, personalita) {
    if (!nodo || !personalita) return false;
    if (nodo.op === 'personalita') return nodo.valore === personalita;
    if (nodo.op === '&' || nodo.op === '|') {
      for (var i = 0; i < nodo.figli.length; i++) {
        if (contieneCondPersonalita(nodo.figli[i], personalita)) return true;
      }
    }
    return false;
  }

  // ---------- risoluzione + applicazione reward ----------

  function scenaIdPer(scheda, esito) {
    if (esito.scenaId) return esito.scenaId; // gia' calcolato da content.js con la stessa convenzione
    // Stessa convenzione di content.js scenaIdDa: fail_m<N> se esiste l'arte dedicata,
    // drawCartolina ripiega su fail_generica per gli id sconosciuti.
    if (esito.tipo === 'fallimento') return 'fail_m' + scheda.numero;
    if (esito.tipo === 'standard' || esito.tipo === 'tutorial') return 'std_' + (scheda.categoria || 'generica');
    if (scheda.numero === 7) return 'super_m7_' + (esito.chiave || 'dominio');
    return 'super_m' + scheda.numero;
  }

  function armiM7() {
    var data = window.PETQ.content && window.PETQ.content.data;
    var elenco = (data && data.arredi) || [];
    var trovate = elenco.filter(function (a) { return /m7 standard/i.test(a.fonte || ''); }).map(function (a) { return a.nome; });
    if (trovate.length === 4) return trovate;
    if (trovate.length > 0) {
      console.warn('PETQ.missions: trovate solo ' + trovate.length + ' armi M7 da content.arredi, uso lista hardcoded');
    }
    return ARMI_M7_FALLBACK;
  }

  // opzioni = { moltNumerico, moltMonete } (Talenti Gruppo B, opzionale, default 1 entrambi):
  // moltNumerico scala il DELTA GREZZO dei token stat/fel/igiene/ferite (Bad Loser, "reward=x2"
  // sui fallimenti di carattere: raddoppia il numero scritto in scheda, qualunque sia il segno,
  // cosi' un fallimento resta un fallimento ma il "premio di consolazione" pesa il doppio).
  // moltMonete scala SOLO il token monete (bonus_missione_monete=x1.5, Cleptomane/Boss di
  // Quartiere): se entrambi sono passati sul token monete, si applicano moltiplicati insieme
  // (caso raro: nessun talento attuale li combina sullo stesso pet, ma il comportamento resta
  // coerente se mai capitasse un fallimento_carattere che paga anche monete).
  function applicaRewardToken(state, token, rewardsOut, opzioni) {
    var t = (token || '').trim();
    if (t === '') return;
    var moltNumerico = (opzioni && typeof opzioni.moltNumerico === 'number') ? opzioni.moltNumerico : 1;
    var moltMonete = (opzioni && typeof opzioni.moltMonete === 'number') ? opzioni.moltMonete : 1;

    // statMax+N (M70 "Oltre il Novemila", Grande Impresa Maleducato): riscrive il token sulla
    // stat RPG piu' ALTA del pet nel MOMENTO della risoluzione (a parita' vince, in quest'ordine,
    // forza/intelligenza/velocita/carisma) e PROSEGUE nel ramo stat normale sotto — non un ramo a
    // parte: cosi' Overclock raddoppia esattamente come gli altri guadagni stat (stesso codice,
    // nessuna duplicazione) e il reward finisce nei rewardsOut come un normalissimo "+N <stat>".
    var mStatMax = t.match(/^statmax\s*([+-]\d+)$/i);
    if (mStatMax) {
      var statAlta = 'forza';
      if (state.pet && state.pet.rpg) {
        var ordineParita = ['forza', 'intelligenza', 'velocita', 'carisma'];
        var vMax = -Infinity;
        for (var oi = 0; oi < ordineParita.length; oi++) {
          var vCorrente = (typeof state.pet.rpg[ordineParita[oi]] === 'number') ? state.pet.rpg[ordineParita[oi]] : 0;
          if (vCorrente > vMax) { vMax = vCorrente; statAlta = ordineParita[oi]; }
        }
      }
      t = statAlta + mStatMax[1];
    }

    // Nome stat: regex "larga" (una parola + delta) poi normalizzata via content.normalizzaStatNome,
    // cosi' accetta sia il nome per esteso (intelligenza+2) sia l'abbreviazione (int+2) usata dal
    // fondatore nelle schede. Se il token NON e' una stat (es. monete+15, fel+5, ferite+3) statNorm
    // e' null e si prosegue verso i rami dedicati sotto.
    // Segno OPZIONALE (default '+', vale per tutti i 6 rami numerici qui sotto: stat/fel/monete/
    // igiene/energia/ferite): un token tipo "forza5"/"monete15" senza segno e' la trascrizione
    // piu' plausibile di "+5 Forza"/"+15 monete" dalla prosa del fondatore, e prima veniva
    // scartato con un warning (premio sparito in silenzio). parseInt("5",10) e' gia' positivo di
    // suo, quindi basta allargare la regex: nessuna logica di default aggiuntiva serve sotto.
    // NESSUN falso match possibile sui token con prefisso "parola:" (cibo:/arredo:/perk:/flag:/
    // rendita:/indossabile:/giocattolo:/arma:/sprite:/allenatore:): il ':' non e' ne' uno spazio
    // (\s*) ne' una cifra/segno, quindi spezza sempre il match ancorato ^...$ qui sotto, segno
    // opzionale o no. Verificato anche a mano coi 6 token dell'audit (v. myverify6/scratchpad).
    var mStat = t.match(/^([a-zà-ù]+)\s*([+-]?\d+)$/i);
    var statNorm = (mStat && PETQ.content && PETQ.content.normalizzaStatNome) ? PETQ.content.normalizzaStatNome(mStat[1]) : null;
    if (mStat && statNorm) {
      var stat = statNorm;
      var delta = Math.round(parseInt(mStat[2], 10) * moltNumerico);
      // Talenti (P3 BATCH 4, "guadagni_stat=x2", Overclock): raddoppia (o piu') i guadagni di
      // stat RPG da REWARD MISSIONE, stesso principio del raddoppio in care.completaAllenamento
      // (Overclock unifica allenamento+missioni, v. talenti.md). Applicato SOLO se il delta e'
      // POSITIVO (un guadagno): un eventuale reward negativo di stat (nessuno nel design attuale,
      // ma per coerenza) non va "raddoppiato in negativo" da un talento che dice "guadagni".
      // L'energia extra scatta solo se il moltiplicatore ha davvero effetto (delta>0).
      var overclockStat = (PETQ.talenti && PETQ.talenti.overclockInfo) ? PETQ.talenti.overclockInfo(state) : { mult: 1, energiaExtra: 0 };
      if (overclockStat.mult !== 1 && delta > 0) {
        delta = Math.round(delta * overclockStat.mult);
        if (overclockStat.energiaExtra !== 0 && state.pet && state.pet.stats) {
          state.pet.stats.energia = clamp(state.pet.stats.energia + overclockStat.energiaExtra, 0, 100);
        }
      }
      // Tetto per stadio (bilanciamento.md "Tetto delle statistiche per stadio"): passa dal
      // cancello unico PETQ.pet.aggiungiStat, che ritorna quanto e' stato REALMENTE applicato —
      // usato anche nel reward (valore mostrato al giocatore), cosi' non promette un guadagno
      // che il tetto ha bloccato. I delta negativi (nessuno oggi nei reward, ma per coerenza)
      // passano comunque sempre, il cancello li applica senza toccare il tetto.
      var applicatoToken = (state.pet && state.pet.rpg && typeof state.pet.rpg[stat] === 'number') ?
        PETQ.pet.aggiungiStat(state.pet, stat, delta) : 0;
      rewardsOut.push({ tipo: 'stat', stat: stat, valore: applicatoToken });
      return;
    }

    var mFel = t.match(/^fel\s*([+-]?\d+)$/i);
    if (mFel) {
      var dFel = Math.round(parseInt(mFel[1], 10) * moltNumerico);
      if (state.pet) state.pet.stats.felicita = clamp(state.pet.stats.felicita + dFel, 0, 100);
      rewardsOut.push({ tipo: 'felicita', valore: dFel });
      return;
    }

    var mMonete = t.match(/^monete\s*([+-]?\d+)$/i);
    if (mMonete) {
      var dMonete = Math.round(parseInt(mMonete[1], 10) * moltNumerico * moltMonete);
      state.coins = (state.coins || 0) + dMonete;
      rewardsOut.push({ tipo: 'monete', valore: dMonete });
      return;
    }

    var mIgiene = t.match(/^igiene\s*([+-]?\d+)$/i);
    if (mIgiene) {
      var dIgiene = Math.round(parseInt(mIgiene[1], 10) * moltNumerico);
      // Ombrello meccanico piazzato: dimezza il calo Igiene nelle missioni a rischio
      // pioggia/sporco (bilanciamento.md/arredi.md: "-10 -> -5"). Nel prototipo l'unico
      // reward negativo di Igiene e' M5 (rischio pioggia): applichiamo il dimezzamento a
      // qualunque calo Igiene di missione quando l'effetto e' attivo, essendo l'unico caso.
      if (dIgiene < 0 && PETQ.arredi && PETQ.arredi.haEffettoSpeciale &&
          PETQ.arredi.haEffettoSpeciale(state, 'igiene_dimezza_pioggia')) {
        dIgiene = Math.ceil(dIgiene / 2); // -10 -> -5, -15 -> -8 (arrotonda verso 0, mai peggio)
      }
      if (state.pet) state.pet.stats.igiene = clamp(state.pet.stats.igiene + dIgiene, 0, 100);
      rewardsOut.push({ tipo: 'igiene', valore: dIgiene });
      return;
    }

    // Token "energia±N" (Retention 2.0 Batch B, DESIGN-DILEMMI-LAVORI.md SPEC MOTORE §3): NUOVO,
    // comportamento IDENTICO al ramo igiene qui sopra (clamp 0..100, rispetta moltNumerico). Non
    // c'era bisogno di spostarlo prima del matcher generico mStat piu' in alto: quel matcher
    // scatta solo se PETQ.content.normalizzaStatNome(...) riconosce il nome, e 'energia' NON e'
    // nella tabella STAT_CANON_ESATTI (solo forza/intelligenza/velocita/carisma + alias) — quindi
    // "energia+10" arriva qui invariato, esattamente come "igiene+10" ci arriva.
    var mEnergia = t.match(/^energia\s*([+-]?\d+)$/i);
    if (mEnergia) {
      var dEnergia = Math.round(parseInt(mEnergia[1], 10) * moltNumerico);
      if (state.pet) state.pet.stats.energia = clamp(state.pet.stats.energia + dEnergia, 0, 100);
      rewardsOut.push({ tipo: 'energia', valore: dEnergia });
      return;
    }

    var mFerite = t.match(/^ferite\s*([+-]?\d+)$/i);
    if (mFerite) {
      var dFerite = Math.round(parseInt(mFerite[1], 10) * moltNumerico);
      // Talenti (P3 BATCH 4, "ferite_missione=x0.5", Veterano del Ring): dimezza le Ferite
      // SUBITE dalle missioni, cioe' SOLO i delta POSITIVI (un reward negativo "ferite-N" e' una
      // GUARIGIONE, non un danno: non va toccato da un talento che dimezza il dolore subito).
      // Arrotondato per DIFETTO (Math.floor, v. talenti.js feriteMissioneMult), mai sotto 0.
      if (dFerite > 0) {
        var feriteMult = (PETQ.talenti && PETQ.talenti.feriteMissioneMult) ? PETQ.talenti.feriteMissioneMult(state) : 1;
        if (feriteMult !== 1) dFerite = Math.max(0, Math.floor(dFerite * feriteMult));
      }
      state.ferite = clamp((state.ferite || 0) + dFerite, 0, 100);
      if (state.pet) PETQ.pet.recomputeSalute(state.pet, state);
      rewardsOut.push({ tipo: 'ferite', valore: dFerite });
      return;
    }

    // Token "flag:-<nome>" (RIMOZIONE): controllato PRIMA di "flag:<nome>" perche' quel regex
    // generico catturerebbe anche "-nome" come nome-flag valido. Usato dalle carte-catena del
    // Batch B Dilemmi (es. C12/C41 tolgono un flag piantato in precedenza). Dedup implicito:
    // se il flag non c'e' non fa nulla (nessun errore).
    // NB il nome si normalizza MINUSCOLO qui e nel ramo sotto: il termine condizione in
    // content.js parseTermine lavora su una stringa gia' lowercase, quindi un reward scritto
    // "flag:Coinquilino" avrebbe piantato un flag che la condizione "flag:coinquilino" non
    // avrebbe MAI trovato — e un gate che non scatta non da' errori, semplicemente non succede
    // niente e si cerca il bug altrove per un'ora.
    var mFlagRimuovi = t.match(/^flag:-(.+)$/i);
    if (mFlagRimuovi) {
      var nomeFlagVia = mFlagRimuovi[1].trim().toLowerCase();
      if (nomeFlagVia !== '') {
        if (!Array.isArray(state.flags)) state.flags = []; // guardia: salvataggi vecchi senza flags
        var idxFlagVia = state.flags.indexOf(nomeFlagVia);
        if (idxFlagVia !== -1) state.flags.splice(idxFlagVia, 1);
        rewardsOut.push({ tipo: 'flag', flag: nomeFlagVia, rimosso: true });
      }
      return;
    }

    // Token "flag:<nome>" (Retention 2.0 Batch B, DESIGN-DILEMMI-LAVORI.md SPEC MOTORE §1):
    // pianta un flag narrativo/di stato in state.flags (array di stringhe, dedup) — letto poi
    // dal termine condizione "flag:<nome>" (v. content.js parseTermine/valutaCondizione, ctx.flags
    // costruito in _valutaCond sotto). Stesso trattamento del reward perk: sopra, ma su un array
    // SEPARATO (i flag NON sono medagliette permanenti mostrate al giocatore: sono memoria
    // narrativa/gancio meccanico interno, v. REGISTRO FLAG del design).
    var mFlagReward = t.match(/^flag:(.+)$/i);
    if (mFlagReward) {
      var nomeFlagPianta = mFlagReward[1].trim().toLowerCase();
      if (nomeFlagPianta !== '') {
        if (!Array.isArray(state.flags)) state.flags = [];
        if (state.flags.indexOf(nomeFlagPianta) === -1) state.flags.push(nomeFlagPianta);
        rewardsOut.push({ tipo: 'flag', flag: nomeFlagPianta });
      }
      return;
    }

    /* Token "rendita:+N" / "rendita:-N" (DESIGN-DILEMMI-LAVORI.md SPEC MOTORE §9, usato dalle
     * carte C15 e C41): modifica PERMANENTE della paga del turno notturno, che la somma alla sola
     * componente monete fissa (v. lavoro.js, che legge state.renditaBonus).
     * Somma algebrica e non sostituzione: le carte-catena possono alzare e poi riabbassare la
     * rendita, e due carte che si sovrascrivessero a vicenda perderebbero la prima delle due.
     * Nessuna collisione col matcher generico delle stat: quello vuole "parola±N" senza due punti. */
    var mRendita = t.match(/^rendita:\s*([+-]\d+)$/i);
    if (mRendita) {
      var dRendita = parseInt(mRendita[1], 10);
      if (typeof state.renditaBonus !== 'number') state.renditaBonus = 0;
      state.renditaBonus += dRendita;
      rewardsOut.push({ tipo: 'rendita', valore: dRendita });
      return;
    }

    var mArredo = t.match(/^arredo:(.+)$/i);
    if (mArredo) {
      var nomeArredo = mArredo[1].trim();
      PETQ.arredi.aggiungi(state, nomeArredo);
      rewardsOut.push({ tipo: 'arredo', nome: nomeArredo });
      return;
    }

    // Inventario/frigo (GDD "Economia" -> "Spesa e dispensa"): dispensa e' un array di
    // {nome, qty}. Il cibo gratis dalle missioni incrementa la qty della riga esistente,
    // o ne crea una nuova con qty pari a cibo.porzioni se il pet non ne possiede ancora (MULTI-
    // PORZIONE, v. porzioniCiboCatalogo sopra: es. cibo:Scorta di Panini -> +5 in un colpo solo,
    // stesso senso dell'acquisto a pagamento in ui.js eseguiAcquisto).
    var mCibo = t.match(/^cibo:(.+)$/i);
    if (mCibo) {
      var nomeCibo = mCibo[1].trim();
      var porzioniCibo = porzioniCiboCatalogo(nomeCibo);
      if (!Array.isArray(state.dispensa)) state.dispensa = [];
      var vociEsistenti = state.dispensa.filter(function (v) { return v.nome === nomeCibo; });
      if (vociEsistenti.length > 0) {
        vociEsistenti[0].qty = (vociEsistenti[0].qty || 0) + porzioniCibo;
      } else {
        state.dispensa.push({ nome: nomeCibo, qty: porzioniCibo });
      }
      rewardsOut.push({ tipo: 'cibo', nome: nomeCibo });
      return;
    }

    if (/^armaCasuale$/i.test(t)) {
      var armi = armiM7();
      var scelta = PETQ.rng.pick(armi);
      PETQ.arredi.aggiungi(state, scelta);
      rewardsOut.push({ tipo: 'arma', nome: scelta });
      return;
    }

    if (/^tutteArmi$/i.test(t)) {
      var tutte = armiM7();
      for (var i = 0; i < tutte.length; i++) PETQ.arredi.aggiungi(state, tutte[i]);
      rewardsOut.push({ tipo: 'tutteArmi', nomi: tutte });
      return;
    }

    // Armi Kaiju (drop M20): 1 arma CASUALE tra le 5 (M20 standard). Riusa lo stesso path del
    // token arredo:<nome> (PETQ.arredi.aggiungi gestisce dedup/qty), scelta con PETQ.rng.pick.
    // Difensivo: se PETQ.rng manca cade sulla prima arma, se PETQ.arredi manca non aggiunge.
    if (/^armaCasualeKaiju$/i.test(t)) {
      var sceltaKaiju = (PETQ.rng && typeof PETQ.rng.pick === 'function') ? PETQ.rng.pick(ARMI_KAIJU) : ARMI_KAIJU[0];
      if (PETQ.arredi && typeof PETQ.arredi.aggiungi === 'function') PETQ.arredi.aggiungi(state, sceltaKaiju);
      rewardsOut.push({ tipo: 'arredo', nome: sceltaKaiju });
      return;
    }

    // Armi Kaiju (drop M20 super): TUTTE e 5 le armi, stesso path di arredo:<nome>.
    if (/^tutteArmiKaiju$/i.test(t)) {
      for (var ak = 0; ak < ARMI_KAIJU.length; ak++) {
        if (PETQ.arredi && typeof PETQ.arredi.aggiungi === 'function') PETQ.arredi.aggiungi(state, ARMI_KAIJU[ak]);
        rewardsOut.push({ tipo: 'arredo', nome: ARMI_KAIJU[ak] });
      }
      return;
    }

    var mAllenatore = t.match(/^allenatore:(7g|perm)$/i);
    if (mAllenatore) {
      if (mAllenatore[1].toLowerCase() === '7g') {
        PETQ.arredi.aggiungi(state, NOME_ALLENATORE, { scadenzaMs: Date.now() + 7 * 24 * 3600000 });
        rewardsOut.push({ tipo: 'allenatore', durata: '7g' });
      } else {
        // permanente: nessuna scadenzaMs, arredi.aggiungi si occupa di sostituire il temporaneo
        PETQ.arredi.aggiungi(state, NOME_ALLENATORE);
        rewardsOut.push({ tipo: 'allenatore', durata: 'perm' });
      }
      // NOTA: il bonus "+1 Forza extra ad ogni allenamento Forza a casa" di questo arredo
      // speciale NON e' collegato a PETQ.care.train in questo giro (fuori scope esplicito
      // nella richiesta): l'arredo e' posseduto/piazzabile con effettoSpeciale
      // 'bonus_allenamento_forza' ma l'hook dentro care.train resta un TODO.
      return;
    }

    // Perk = MEDAGLIETTE (decisione fondatore, bilanciamento.md "Perk = MEDAGLIETTE"): il reward
    // perk:<nome> assegna un BADGE permanente al pet (state.perks, array di nomi lowercase, dedup).
    // Non e' piu' un arredo da piazzare: una volta ottenuto e' sempre attivo. Accetta QUALSIASI
    // nome-perk (categoria, tag, popeye, weaponwielder): la logica d'effetto e' altrove
    // (scegliEsito per categoria/tag, care.feed per popeye). weaponwielder si salva qui come badge
    // ma NON ha ancora effetto (sblocco equip armi = sistema grande, Blocco 6, rimandato).
    var mPerk = t.match(/^perk:(.+)$/i);
    if (mPerk) {
      var pk = mPerk[1].trim().toLowerCase();
      if (pk !== '') {
        if (!Array.isArray(state.perks)) state.perks = [];
        if (state.perks.indexOf(pk) === -1) state.perks.push(pk);
        rewardsOut.push({ tipo: 'perk', perk: pk });
      }
      return;
    }

    if (/^rimborsoCosto$/i.test(t)) {
      var costoOriginale = (state.missione && typeof state.missione.costo === 'number') ? state.missione.costo : 0;
      state.coins = (state.coins || 0) + costoOriginale;
      rewardsOut.push({ tipo: 'rimborso', valore: costoOriginale });
      return;
    }

    // energiaMissione=0 (M14 super): NON e' un reward sul pet, e' un flag che azzera il costo
    // Energia della missione, gestito direttamente in risolvi() PRIMA del decremento. Qui lo
    // riconosciamo come no-op solo per non emettere il warning "token non riconosciuto".
    if (/^energiaMissione\s*=\s*0$/i.test(t)) {
      return;
    }

    // Indossabili (PROTOTIPO 2): reward indossabile:<nome> -> aggiunge il vestito ai posseduti
    // (state.indossabili, dedup). NON lo indossa in automatico: l'equip e' una scelta del giocatore
    // (Armadio nella scheda). L'effetto (bonus stat / Chef) scatta solo mentre indossato.
    var mIndoss = t.match(/^indossabile:(.+)$/i);
    if (mIndoss) {
      var nomeIndoss = mIndoss[1].trim();
      if (nomeIndoss !== '') {
        if (!Array.isArray(state.indossabili)) state.indossabili = [];
        if (state.indossabili.indexOf(nomeIndoss) === -1) state.indossabili.push(nomeIndoss);
        rewardsOut.push({ tipo: 'indossabile', nome: nomeIndoss });
      }
      return;
    }

    // Giocattoli (revamp 28 lug 2026): reward giocattolo:<nome> -> aggiunge il giocattolo ai
    // posseduti (state.giocattoli, dedup fatto da PETQ.giocattoli.aggiungi) e da li' compare nel
    // menu "Usa un giocattolo" del salone. Stessa forma di indossabile:/arredo: — nessun equip
    // automatico, nessun uso consumato. I 4 giocattoli che sono ANCHE arredi non passano di qui
    // (arrivano col token arredo:<nome>, e il possesso lo vede gia' giocattoli.possiede).
    // Difensivo: senza il modulo giocattoli (o con un nome che non e' in catalogo) NON si scrive
    // niente nello stato e non si annuncia un premio che il giocatore non troverebbe.
    var mGiocattolo = t.match(/^giocattolo:(.+)$/i);
    if (mGiocattolo) {
      var nomeGiocattolo = mGiocattolo[1].trim();
      if (nomeGiocattolo !== '' && PETQ.giocattoli && typeof PETQ.giocattoli.aggiungi === 'function') {
        var esitoG = PETQ.giocattoli.aggiungi(state, nomeGiocattolo);
        if (esitoG && esitoG.ok) {
          rewardsOut.push({ tipo: 'giocattolo', nome: nomeGiocattolo });
        } else {
          console.warn('PETQ.missions: giocattolo reward sconosciuto: "' + nomeGiocattolo + '"');
        }
      }
      return;
    }

    // Armeria (FASE SPRITE): reward arma:<nome> -> salva l'arma tra i posseduti come un arredo
    // (le armi SONO arredi normali). Prima cadeva nel warning finale e la Pistola di M28 andava persa.
    var mArma = t.match(/^arma:(.+)$/i);
    if (mArma) {
      var nomeArma = mArma[1].trim();
      if (nomeArma !== '' && PETQ.arredi && typeof PETQ.arredi.aggiungi === 'function') {
        PETQ.arredi.aggiungi(state, nomeArma);
        rewardsOut.push({ tipo: 'arredo', nome: nomeArma });
      }
      return;
    }

    // M17 "Pimp My Pet" (robustezza motore reward): token sprite:<nome> -> modifica permanente
    // dell'aspetto (state.pet.modSprite, chiave MOD_SPR in sprites.js, disegnata da drawOverlayEquip).
    // La schermata dedicata mostraTeenIntro applica la scelta senza passare di qui, ma le righe
    // Dati: della scheda M17 usano questo token: cosi' non cade nel warning e il campo combacia.
    var mSprite = t.match(/^sprite:(.+)$/i);
    if (mSprite) {
      var nomeSprite = mSprite[1].trim();
      if (nomeSprite !== '' && state.pet) {
        state.pet.modSprite = nomeSprite;
        rewardsOut.push({ tipo: 'sprite', nome: nomeSprite });
      }
      return;
    }

    console.warn('PETQ.missions: token reward non riconosciuto: "' + t + '"');
  }

  // Mancia post-missione (GDD "Economia": "mance post-missione che scalano col carisma";
  // bilanciamento.md "Mancia post-missione: 1 moneta ogni 5 punti di Carisma"): fonte di
  // economia gia' prevista dal design ma MAI agganciata al motore missioni fino a questo
  // batch (nessun reward token la generava). La aggiungiamo qui perche' il talento Cuore
  // Magnetico (mancia=x3) ha bisogno di qualcosa su cui moltiplicare. Usa la stat Carisma
  // EFFETTIVA (base + bonus passivi arredi/talenti, stesso principio di bonusStatCombinato)
  // cosi' i bonus permanenti di Carisma alzano anche la mancia, coerente col resto del motore.
  // Arrotondamento per difetto (Math.floor): niente monete frazionarie.
  var MANCIA_CARISMA_PER_MONETA = 5;

  function calcolaMancia(state, bonusStat) {
    if (!state || !state.pet) return 0;
    var carismaEffettivo = statEffettiva(state.pet, bonusStat, 'carisma');
    var base = Math.floor(Math.max(0, carismaEffettivo) / MANCIA_CARISMA_PER_MONETA);
    var mult = (PETQ.talenti && PETQ.talenti.manciaMult) ? PETQ.talenti.manciaMult(state) : 1;
    return Math.round(base * mult);
  }

  function risolvi(state) {
    assicuraStatoMissioni(state);
    if (!state.missione) {
      return { ok: false, msg: traduci('Nessuna missione in corso.') };
    }
    if (tempoRimasto(state) > 0) {
      return { ok: false, msg: traduci('La missione non e\' ancora finita.') };
    }

    var scheda = trovaScheda(state.missione.id);
    if (!scheda) {
      state.missione = null;
      return { ok: false, msg: traduci('Scheda missione non trovata.') };
    }

    var bonusStat = bonusStatCombinato(state);
    // Perk = MEDAGLIETTE (decisione fondatore, bilanciamento.md "Perk = MEDAGLIETTE"): la fonte
    // dei perk per scegliEsito e' ora state.perks (badge ottenuti da reward perk:<nome>), NON piu'
    // gli arredi piazzati (PETQ.arredi.perkAttivi resta esposto ma non e' piu' usato qui).
    var perks = Array.isArray(state.perks) ? state.perks : [];
    var esito = scegliEsito(scheda, state.pet, bonusStat, perks, state);

    if (!esito) {
      state.missione = null;
      return { ok: false, msg: traduci('Impossibile calcolare l\'esito della missione.') };
    }

    // Costo energia missione (GDD/bilanciamento.md "Energia e sonno"): 8 x ore di durata,
    // clampato a 0 (mai sotto zero, mai reso "negativo" oltre il minimo della stat). Usa la
    // durata EFFETTIVA (post talenti missione_durata/bonus_missione durata) gia' salvata
    // sull'istanza di missione in corso, non la durata base della scheda: una missione
    // accorciata dai talenti costa anche meno Energia, coerente col "meno tempo via".
    // Eccezione (M14 super Nerd-Inventore): se l'esito scelto contiene il token "energiaMissione=0"
    // il costo Energia della missione e' AZZERATO (missione a costo energia nullo). Non e' un
    // reward sul pet (non passa da applicaRewardToken): e' un flag che modifica il costo, letto qui
    // dai reward dell'esito PRIMA di applicare il decremento. Difensivo se esito.reward non e' array.
    var rewardEsito = Array.isArray(esito.reward) ? esito.reward : [];
    var energiaMissioneNulla = false;
    for (var em = 0; em < rewardEsito.length; em++) {
      if (typeof rewardEsito[em] === 'string' && /^energiaMissione\s*=\s*0$/i.test(rewardEsito[em].trim())) {
        energiaMissioneNulla = true;
        break;
      }
    }
    if (!energiaMissioneNulla && state.pet && state.pet.stats && PETQ.pet && PETQ.pet.bilEnergiaSonno) {
      var es = PETQ.pet.bilEnergiaSonno();
      var durataEffettivaMs = (state.missione && typeof state.missione.durataEffettivaMs === 'number') ? state.missione.durataEffettivaMs : (scheda.durataMs || 0);
      var oreDurata = durataEffettivaMs / 3600000;
      var costoEnergia = es.costoMissionePerOra * oreDurata;
      // Oracolo ("Le prospettive non sono buone"): la PROSSIMA missione costa +5 Energia. Si somma
      // al costo normale (non lo sostituisce) e vale solo per questa risoluzione: il responso viene
      // consumato in fondo a risolvi (consumaOracoloMissione).
      var energiaExtraOracolo = (PETQ.giocattoli && PETQ.giocattoli.energiaExtraMissione) ? PETQ.giocattoli.energiaExtraMissione(state) : 0;
      costoEnergia += energiaExtraOracolo;
      state.pet.stats.energia = clamp((typeof state.pet.stats.energia === 'number' ? state.pet.stats.energia : 70) - costoEnergia, 0, 100);
    }

    // Talenti (Gruppo B, Bad Loser): il fallimento e' "di carattere" se la sua cond include una
    // condizione di personalita' che coincide con quella del pet (v. contieneCondPersonalita).
    // Serve PRIMA di applicare i reward, perche' decide il moltiplicatore da passare al loop.
    var personalita = state.pet ? state.pet.personalita : null;
    var fallimentoDiCarattere = esito.tipo === 'fallimento' && contieneCondPersonalita(esito.cond, personalita);
    var badLoser = (fallimentoDiCarattere && PETQ.talenti && PETQ.talenti.badLoserEffetto) ? PETQ.talenti.badLoserEffetto(state) : null;

    // Talenti (Gruppo B, bonus_missione_monete=x1.5, Cleptomane/Boss di Quartiere): moltiplica
    // SOLO il token monete del reward, su qualsiasi esito (super/standard/fallimento) che ne dia.
    var moltMonete = (PETQ.talenti && PETQ.talenti.bonusMissioneMoneteMult) ? PETQ.talenti.bonusMissioneMoneteMult(state) : 1;

    // Oracolo (Sfera Sentenziosa, responsi "Certamente" +25% e "Non ci contare" -10%): moltiplica
    // le MONETE DALLE MISSIONI. Passa dallo stesso canale del talento Cleptomane (moltMonete sul
    // token monete della scheda) e si moltiplica con esso: un pet fortunato e ladro prende entrambi.
    // Dura tutta la giornata di gioco (a differenza dei due responsi "prossima missione").
    var moltOracolo = (PETQ.giocattoli && PETQ.giocattoli.moltMoneteMissione) ? PETQ.giocattoli.moltMoneteMissione(state) : 1;
    moltMonete = moltMonete * moltOracolo;

    var opzioniReward = {
      moltNumerico: badLoser ? badLoser.moltReward : 1,
      moltMonete: moltMonete
    };

    var rewards = [];
    for (var i = 0; i < (esito.reward || []).length; i++) {
      try {
        applicaRewardToken(state, esito.reward[i], rewards, opzioniReward);
      } catch (e) {
        console.warn('PETQ.missions: errore applicando reward "' + esito.reward[i] + '"', e);
      }
    }

    // Talenti (Gruppo B, Bad Loser): -10 Felicita' EXTRA sui fallimenti di carattere, oltre
    // all'eventuale fel- gia' nel reward. Applicato qui (non nel loop sopra) perche' non e' un
    // token della scheda ma un effetto aggiuntivo del talento.
    if (badLoser && badLoser.felExtra && state.pet) {
      state.pet.stats.felicita = clamp(state.pet.stats.felicita + badLoser.felExtra, 0, 100);
      rewards.push({ tipo: 'felicita', valore: badLoser.felExtra, talento: 'Bad Loser' });
    }

    // Talenti (Gruppo B, Faccia di Bronzo, "fallimento=fel-0"): annulla QUALSIASI perdita di
    // Felicita' accumulata dal fallimento in questa risoluzione (sia il fel- della scheda sia
    // l'extra di Bad Loser sopra: combo voluta esplicitamente dal design). Applicato per ultimo,
    // sommando indietro l'ammontare netto negativo registrato nei rewards di tipo 'felicita'.
    if (esito.tipo === 'fallimento' && PETQ.talenti && PETQ.talenti.fallimentoFelBloccato && PETQ.talenti.fallimentoFelBloccato(state)) {
      var feliceDaAnnullare = 0;
      for (var k = 0; k < rewards.length; k++) {
        if (rewards[k].tipo === 'felicita' && rewards[k].valore < 0) feliceDaAnnullare += rewards[k].valore;
      }
      if (feliceDaAnnullare < 0 && state.pet) {
        state.pet.stats.felicita = clamp(state.pet.stats.felicita - feliceDaAnnullare, 0, 100); // sottrae un negativo = somma
        rewards.push({ tipo: 'felicita', valore: -feliceDaAnnullare, talento: 'Faccia di Bronzo' });
      }
    }

    // Talenti (Gruppo B, ogni_missione=<stat|monete>+N, Spirito Agonistico/Mani Lestre/Cuore
    // Magnetico): bonus fisso ad OGNI missione completata (qualsiasi esito, incluso fallimento:
    // il brief lo richiede esplicito - "qualsiasi esito non-null"), su stat RPG e/o monete.
    if (PETQ.talenti && PETQ.talenti.bonusOgniMissione) {
      var ogniMissione = PETQ.talenti.bonusOgniMissione(state);
      for (var s = 0; s < STAT_NOMI.length; s++) {
        var statNome = STAT_NOMI[s];
        if (ogniMissione[statNome] && state.pet && state.pet.rpg) {
          // Tetto per stadio: passa dal cancello unico (v. sopra), valore reward = quanto e'
          // stato REALMENTE applicato.
          var applicatoOgni = PETQ.pet.aggiungiStat(state.pet, statNome, ogniMissione[statNome]);
          rewards.push({ tipo: 'stat', stat: statNome, valore: applicatoOgni, talento: 'ogni_missione' });
        }
      }
      if (ogniMissione.monete) {
        state.coins = (state.coins || 0) + ogniMissione.monete;
        rewards.push({ tipo: 'monete', valore: ogniMissione.monete, talento: 'ogni_missione' });
      }
    }

    // Talenti (Gruppo B, bonus_missione=<categoria>:<stat>+N, Topo di Biblioteca/Pacifista):
    // bonus stat extra SOLO se la missione e' della categoria giusta (la parte durata e' gia'
    // stata applicata all'avvio, v. durataMissioneEffettivaMs).
    if (scheda.categoria && PETQ.talenti && PETQ.talenti.bonusMissioneCategoria) {
      var catBonus = PETQ.talenti.bonusMissioneCategoria(state, scheda.categoria).statExtra;
      for (var c = 0; c < STAT_NOMI.length; c++) {
        var sn = STAT_NOMI[c];
        if (catBonus[sn] && state.pet && state.pet.rpg) {
          // Tetto per stadio: passa dal cancello unico (v. sopra), valore reward = quanto e'
          // stato REALMENTE applicato.
          var applicatoCat = PETQ.pet.aggiungiStat(state.pet, sn, catBonus[sn]);
          rewards.push({ tipo: 'stat', stat: sn, valore: applicatoCat, talento: 'bonus_missione' });
        }
      }
    }

    // Mancia post-missione (v. calcolaMancia sopra): su OGNI missione risolta con esito valido
    // (super/standard/fallimento), scala col Carisma effettivo e coi talenti (mancia=x3).
    var mancia = calcolaMancia(state, bonusStat);

    /* Hook del flag "venduto" (DESIGN-DILEMMI-LAVORI.md SPEC MOTORE §8, piantato dalla carta C13
     * "Lo Sponsor Losco"): chi ha accettato di fare il testimonial della bibita SBLORF, alla
     * PROSSIMA missione con tag gara non prende mancia — il pubblico si ricorda. Poi il flag si
     * consuma, cosi' il conto e' pagato una volta sola e non diventa una tassa perpetua.
     * Il flag si toglie ANCHE se la mancia era gia' zero (Carisma basso): altrimenti resterebbe
     * appeso e colpirebbe una gara successiva, cioe' due volte per una scelta sola. */
    var tagsScheda = (scheda && Array.isArray(scheda.tag)) ? scheda.tag : [];
    if (Array.isArray(state.flags) && state.flags.indexOf('venduto') !== -1 &&
        tagsScheda.indexOf('gara') !== -1) {
      mancia = 0;
      state.flags.splice(state.flags.indexOf('venduto'), 1);
      rewards.push({ tipo: 'flag', flag: 'venduto', rimosso: true, manciaAzzerata: true });
    }

    if (mancia > 0) {
      state.coins = (state.coins || 0) + mancia;
      rewards.push({ tipo: 'monete', valore: mancia, talento: 'mancia' });
    }

    // Grande Impresa (P3, scheda.impresa): standard/super assegnano la Medaglia dell'Impresa
    // (titolo, mostrata sulla scheda del pet vivo e poi sulla card del pensionato, v. ui.js) al
    // pet VIVO; il super aggiunge ANCHE il flag impresaSuper, letto da pet.mandaInPensione per
    // sbloccare il perk di ritiro CASA + l'uovo leggendario (solo alla PENSIONE, mai qui). Niente
    // sul fallimento: la scheda resta in rosa via ritenta=1 (gia' gestito sopra) e si ritenta.
    if (scheda.impresa && (esito.tipo === 'standard' || esito.tipo === 'super') && state.pet) {
      state.pet.medagliaImpresa = { id: scheda.id, titolo: scheda.titolo };
      if (esito.tipo === 'super') {
        state.pet.impresaSuper = { id: scheda.id };
      }
    }

    var risultato = {
      ok: true,
      tipo: esito.tipo,
      missioneId: scheda.id,
      chiaveEsito: esito.chiave,
      testo: esito.testo || '',
      scenaId: scenaIdPer(scheda, esito),
      rewards: rewards
    };

    state.missione = null;
    // limite 1 missione al giorno (fix playtest): marca il giorno (di gioco, intero) alla
    // risoluzione; avvia() rifiuta finche' non cambia giorno di gioco (il debug "Nuovo giorno"
    // azzera questo campo). Letto da ui.js missioneEsauritaOggi (hint mappa): NON e' piu' il
    // gate vero (v. avvia()), ma resta il marcatore "e' successo qualcosa oggi".
    state.missioneGiorno = PETQ.clock.giornoCorrente(state);
    // Talenti (P3 BATCH 4, "missioni_giorno=2", Lavoro in Nero): contatore SEPARATO da
    // missioneGiorno sopra, confrontato in avvia() col tetto dei talenti (default 1). Stesso
    // pattern giorno-di-riferimento + contatore di trainDay/trainCount in care.train.
    var giornoOra = PETQ.clock.giornoCorrente(state);
    if (state.missioniOggiGiorno !== giornoOra) {
      state.missioniOggiGiorno = giornoOra;
      state.missioniOggiCount = 0;
    }
    state.missioniOggiCount = (state.missioniOggiCount || 0) + 1;
    // Diario (PROTOTIPO-2.md punto 6): traccia l'esito della missione DI OGGI per la pagina
    // diario serale (PETQ.diario.componiPagina legge questo campo). 'super'/'standard' -> riga
    // "Missione andata bene", 'fallimento' -> "andata male". Azzerato al nuovo giorno da
    // care.dailyLogin (mai persistere l'esito di ieri). Il tutorial (m0, risolviTutorial) non
    // passa da qui: e' un regalo di benvenuto una tantum, non "la missione di oggi".
    state.esitoMissioneGiorno = esito.tipo;
    // Cooldown missioni (bilanciamento.md "Cooldown missioni"): marca l'ultima esecuzione
    // ALLA RISOLUZIONE (non all'avvio), cosi' una missione abbandonata a meta' (mai possibile
    // nel prototipo, ma per coerenza futura) non entrerebbe in cooldown senza essere completata.
    // Il tutorial m0 non passa mai da qui (risolviTutorial e' una funzione separata).
    // Eccezione RITENTA (schede con ritenta=1, boss a gate/Grandi Imprese): il FALLIMENTO non
    // marca la missione come fatta — resta in rosa e si puo' ritentare finche' non riesce
    // (design fondatore, bilanciamento.md "Missioni — pet adulto"). Standard/super la chiudono.
    if (!scheda.tutorial && !(scheda.ritenta && esito.tipo === 'fallimento')) {
      state.missioniFatte[scheda.id] = PETQ.clock.giornoCorrente(state);
    }

    // Oracolo: i due responsi che valgono "sulla PROSSIMA missione" (soglia super -3, +5 Energia)
    // si consumano QUI, a missione risolta — hanno gia' fatto il loro effetto sopra. I due responsi
    // sulle monete NON si consumano: valgono per tutta la giornata di gioco (scadono da soli).
    if (PETQ.giocattoli && PETQ.giocattoli.consumaOracoloMissione) {
      PETQ.giocattoli.consumaOracoloMissione(state);
    }

    return risultato;
  }

  window.PETQ.missions = {
    rosaDelGiorno: rosaDelGiorno,
    impresaDellaRun: impresaDellaRun,
    avvia: avvia,
    inCorso: inCorso,
    tempoRimasto: tempoRimasto,
    risolvi: risolvi,
    tutorialDaProporre: tutorialDaProporre,
    risolviTutorial: risolviTutorial,
    bonusStatCombinato: bonusStatCombinato,
    bonusIndossato: bonusIndossato,
    bonusArmaEquip: bonusArmaEquip,
    orarioMissioniAperto: orarioMissioniAperto,
    _valutaCond: _valutaCond,
    _scegliEsito: scegliEsito,
    _escludiFatte: escludiFatte,
    _diffGiorniStr: diffGiorniStr,
    _dimRosa: DIM_ROSA,
    _cooldownGiorni: COOLDOWN_GIORNI, // non piu' usato (esclusione permanente), esportato per compat. test
    // Talenti Gruppo B (esposti per i test + eventuali chiamanti UI futuri)
    _durataMissioneEffettivaMs: durataMissioneEffettivaMs,
    _contieneCondPersonalita: contieneCondPersonalita,
    _calcolaMancia: calcolaMancia,
    _applicaRewardToken: applicaRewardToken,
    // Regalo di benvenuto del tutorial (esposti per i test: il pool deve restare senza cibi
    // del disonore e senza drop non comprabili, v. ciboAdattoAlRegaloTutorial)
    _rifornisciDispensaTutorial: rifornisciDispensaTutorial,
    _ciboAdattoAlRegaloTutorial: ciboAdattoAlRegaloTutorial,
    _manciaCarismaPerMoneta: MANCIA_CARISMA_PER_MONETA,
    // Rotazione random per run (P3): config generale + funzione di estrazione/lazy-init, esposte
    // per debug/test (v. ROTAZIONE_PER_STADIO e assicuraRotazioneStadio sopra).
    _rotazionePerStadio: ROTAZIONE_PER_STADIO,
    _assicuraRotazioneStadio: assicuraRotazioneStadio,
    // Indossabili/armi da CONTENUTO (fase 2 giocattoli): esposti per i test e per chi deve
    // leggere gli effetti di una voce di arredi.md senza riscrivere il giro degli effetti.
    _statDaEffetti: statDaEffetti,
    _voceContenuto: voceContenuto,
    _effettiIndossabiliFallback: EFFETTI_INDOSSABILI,
    _effettiArmaFallback: EFFETTI_ARMA
  };

})();
