/* PETQ.lavoro — il TURNO NOTTURNO (Batch B: Dilemmi + Lavori)
 *
 * Perimetro: docs/DESIGN-DILEMMI-LAVORI.md — PORTA 2 (i 4 lavoretti teen), §2 (le 8 carriere
 * adulte), §5 punti 7 e 9. I numeri qui sotto sono COPIATI da quelle tabelle: se non tornano,
 * ha ragione il doc.
 *
 * Come funziona, in una riga: il pet esce a lavorare mentre dorme e la paga arriva al risveglio.
 * Zero tap: e' un guadagno che si incassa svegliandosi, non un'altra cosa da ricordarsi di fare —
 * era il vincolo del fondatore ("turno NOTTURNO passivo").
 *
 * QUESTO MODULO NON APPLICA NIENTE. risolviNotte() calcola e RITORNA cosa e' successo; chi lo
 * chiama passa i token all'applicatore del motore (missions.applicaRewardToken). Applicarli qui
 * significherebbe riscrivere quella logica una seconda volta, e due copie divergono sempre.
 */
(function () {
  'use strict';
  window.PETQ = window.PETQ || {};

  // Soglie di salto, dal doc §5.7. L'energia sotto 20 e' la stessa soglia di rifiuto usata dal
  // sonno (bilanciamento.md "Energia e sonno"); la salute critica la si legge dal contenuto e
  // NON la si inventa qui — e' lo stesso 25 con cui il resto del gioco definisce "critico".
  var ENERGIA_MIN_TURNO = 20;
  var SALUTE_CRITICA_RIPIEGO = 25;

  // Il bilanciamento si legge da PETQ.content.DATA.bilanciamento (oggetto), non da una
  // PETQ.content.bilanciamento() che NON ESISTE: chiamandola come funzione questo modulo cadeva
  // SEMPRE sul ripiego cablato qui sotto, ignorando content/bilanciamento.md. Invisibile finche' i
  // due numeri coincidono (oggi entrambi 25), ma il giorno che il fondatore cambia la soglia nel
  // file il lavoro notturno continuerebbe a usare quella vecchia, in silenzio e senza errori.
  // E' la stessa famiglia del bug di luglio su parseBilanciamento ("Effetto" letto per
  // sottostringa): un valore sbagliato che si nota solo quando lo cambi.
  function bilanciamento() {
    var c = window.PETQ.content;
    return (c && c.data && c.data.bilanciamento) ? c.data.bilanciamento : {};
  }

  function saluteCritica() {
    var b = bilanciamento();
    var s = b.soglie && b.soglie.critica;
    return (typeof s === 'number') ? s : SALUTE_CRITICA_RIPIEGO;
  }

  /* ---------- TABELLE (dal doc, non inventate) ----------
   * rendita: { monete, ricorrenti: [{ogniNotti, effetto}], lotteria: {min,max} }
   * "effetto" e' un token del DSL reward del motore, cosi' il turno non ha bisogno di un secondo
   * vocabolario di effetti tutto suo.
   * 'oggetto:poolinventore' e' un token NOSTRO che il chiamante risolve pescando da
   * content.data.poolInventore (il pool esiste gia' in content/arredi.md per il talento
   * Inventore): meglio riusare quella lista che scriverne una seconda qui, che divergerebbe.
   */
  var LAVORETTI = {
    consegnepizza: {
      nome: 'Consegne di pizza', vocazione: 'sportivo',
      rendita: { monete: 12, ricorrenti: [{ ogniNotti: 1, effetto: 'energia-5' }] }
    },
    commessodischi: {
      nome: 'Commesso al negozio di dischi', vocazione: 'gentile',
      rendita: { monete: 8, ricorrenti: [{ ogniNotti: 3, effetto: 'carisma+1' }] }
    },
    assistenteprof: {
      nome: 'Assistente del Prof. Strambo', vocazione: 'nerd',
      rendita: { monete: 6, ricorrenti: [{ ogniNotti: 3, effetto: 'int+1' }, { ogniNotti: 4, effetto: 'oggetto:poolinventore' }] }
    },
    streamergiochi: {
      nome: 'Streamer di videogiochi', vocazione: 'maleducato',
      rendita: { monete: 4, ricorrenti: [{ ogniNotti: 4, effetto: 'monete+25' }] }
    }
  };

  // Gli id delle carriere sono quelli usati dal doc nei gate `lavoro=` delle M99-M106: devono
  // combaciare CARATTERE PER CARATTERE, o il gate non aprira' mai la quest corrispondente.
  var CARRIERE = {
    riderleggendario:  { nome: 'Rider Leggendario',  da: 'consegnepizza',   rendita: { monete: 18 } },
    pizzaioloinproprio:{ nome: 'Pizzaiolo in Proprio', da: 'consegnepizza', rendita: { monete: 15, ricorrenti: [{ ogniNotti: 2, effetto: 'cibo:Pizza' }] } },
    djresident:        { nome: 'DJ Resident',        da: 'commessodischi',  rendita: { monete: 14 } },
    talentscout:       { nome: 'Talent Scout',       da: 'commessodischi',  rendita: { monete: 0, lotteria: { min: 5, max: 25 } } },
    ricercatorejunior: { nome: 'Ricercatore Junior', da: 'assistenteprof',  rendita: { monete: 10, ricorrenti: [{ ogniNotti: 2, effetto: 'int+1' }] } },
    inventoreingarage: { nome: 'Inventore in Garage', da: 'assistenteprof', rendita: { monete: 8, ricorrenti: [{ ogniNotti: 3, effetto: 'oggetto:poolinventore' }] } },
    streamerpartner:   { nome: 'Streamer Partner',   da: 'streamergiochi',  rendita: { monete: 6, ricorrenti: [{ ogniNotti: 4, effetto: 'monete+40' }] } },
    editorvideo:       { nome: 'Editor Video',       da: 'streamergiochi',  rendita: { monete: 13 } }
  };

  // Struttura difensiva, stesso schema di streak.js: qualunque salvataggio esce di qui sano.
  function assicura(state) {
    if (!state) return null;
    var l = state.lavoro;
    if (!l || typeof l !== 'object') l = {};
    if (typeof l.id !== 'string' || !LAVORETTI[l.id]) l.id = null;
    if (typeof l.carriera !== 'string' || !CARRIERE[l.carriera]) l.carriera = null;
    if (typeof l.nottiFatte !== 'number' || l.nottiFatte < 0) l.nottiFatte = 0;
    if (!l.contatori || typeof l.contatori !== 'object') l.contatori = {};
    state.lavoro = l;
    return l;
  }

  // Il lavoro ATTIVO: la carriera adulta vince sul lavoretto teen, perche' la sostituisce.
  function lavoroCorrente(state) {
    var l = assicura(state);
    if (!l) return null;
    if (l.carriera && CARRIERE[l.carriera]) return { chiave: l.carriera, def: CARRIERE[l.carriera] };
    if (l.id && LAVORETTI[l.id]) return { chiave: l.id, def: LAVORETTI[l.id] };
    return null;
  }

  // Perche' il turno NON si fa. Ritorna null se invece si fa.
  function motivoSalto(state) {
    if (state.missione) return 'missione in corso: la notte era gia' + '’' + ' impegnata';
    var st = state.pet && state.pet.stats;
    if (!st) return 'nessun pet';
    if (typeof st.energia === 'number' && st.energia < ENERGIA_MIN_TURNO) return 'troppo stanco per il turno';
    if (typeof st.salute === 'number' && st.salute < saluteCritica()) return 'non in salute: niente turno';
    return null;
  }

  /* La vocazione (+25%) tocca SOLO la componente monete FISSA, e arrotonda PER DIFETTO.
   * Sono due dettagli scritti nel doc e vanno rispettati entrambi: applicarla anche a lotteria e
   * ricorrenti trasformerebbe un bonus di colore in un moltiplicatore su tutto. */
  function moneteConVocazione(state, def) {
    var base = (def.rendita && typeof def.rendita.monete === 'number') ? def.rendita.monete : 0;
    var pers = state.pet && state.pet.personalita;
    if (def.vocazione && pers === def.vocazione) return Math.floor(base * 1.25);
    // Le carriere non hanno vocazione propria: la ereditano dal lavoretto d'origine (doc PORTA 3).
    if (!def.vocazione && def.da && LAVORETTI[def.da] && pers === LAVORETTI[def.da].vocazione) {
      return Math.floor(base * 1.25);
    }
    return base;
  }

  function lotteria(def) {
    var lot = def.rendita && def.rendita.lotteria;
    if (!lot) return 0;
    var min = (typeof lot.min === 'number') ? lot.min : 0;
    var max = (typeof lot.max === 'number') ? lot.max : min;
    // PETQ.rng e non Math.random: e' il generatore del GIOCO, e questa e' una vincita di gioco.
    if (window.PETQ.rng && PETQ.rng.randInt) return PETQ.rng.randInt(min, max);
    return Math.floor((min + max) / 2); // ripiego neutro se il modulo non c'e'
  }

  /* risolviNotte: calcola l'esito del turno. NON scrive stat, NON aggiunge oggetti: ritorna. */
  function risolviNotte(state) {
    var vuoto = { saltato: true, motivo: null, monete: 0, extra: [], nottiFatte: 0 };
    if (!state) return vuoto;
    var l = assicura(state);
    var corrente = lavoroCorrente(state);
    if (!corrente) { vuoto.motivo = 'nessun lavoro'; return vuoto; }

    var salto = motivoSalto(state);
    if (salto) {
      // Saltando NON avanzano ne' le notti ne' i contatori dei ricorrenti (esplicito nel doc):
      // una notte non lavorata non deve avvicinare il premio delle 3 notti.
      return { saltato: true, motivo: salto, monete: 0, extra: [], nottiFatte: l.nottiFatte };
    }

    var def = corrente.def;
    var monete = moneteConVocazione(state, def) + lotteria(def);

    // Modificatore temporaneo della rendita (carte C15/C41): somma algebrica, mai sotto zero.
    if (typeof state.renditaBonus === 'number') monete += state.renditaBonus;
    if (monete < 0) monete = 0;

    l.nottiFatte++;

    var extra = [];
    var ric = (def.rendita && def.rendita.ricorrenti) || [];
    for (var i = 0; i < ric.length; i++) {
      var r = ric[i];
      if (!r || typeof r.ogniNotti !== 'number' || r.ogniNotti < 1) continue;
      // Un contatore per POSIZIONE del ricorrente (non per effetto): due ricorrenti con lo stesso
      // token resterebbero comunque indipendenti.
      var k = corrente.chiave + ':' + i;
      var n = (typeof l.contatori[k] === 'number') ? l.contatori[k] : 0;
      n++;
      if (n >= r.ogniNotti) {
        n = 0;
        extra.push({ token: r.effetto, ogniNotti: r.ogniNotti });
      }
      l.contatori[k] = n;
    }

    return { saltato: false, motivo: null, monete: monete, extra: extra, nottiFatte: l.nottiFatte };
  }

  function sceltaLavoretto(state, id) {
    if (!state || !state.pet) return { ok: false, msg: 'nessun pet' };
    if (!LAVORETTI[id]) return { ok: false, msg: 'lavoretto sconosciuto' };
    if (state.pet.stadio !== 'teen') return { ok: false, msg: 'il lavoretto si prende da teen' };
    var l = assicura(state);
    l.id = id;
    l.carriera = null;
    l.nottiFatte = 0;
    l.contatori = {};
    return { ok: true, msg: LAVORETTI[id].nome };
  }

  function sceltaCarriera(state, id) {
    if (!state || !state.pet) return { ok: false, msg: 'nessun pet' };
    var c = CARRIERE[id];
    if (!c) return { ok: false, msg: 'carriera sconosciuta' };
    if (state.pet.stadio !== 'adulto') return { ok: false, msg: 'la carriera si prende da adulto' };
    var l = assicura(state);
    if (!l.id) return { ok: false, msg: 'serve prima un lavoretto' };
    // La carriera nasce da UN lavoretto preciso (doc §2): sceglierne una di un altro ramo
    // vorrebbe dire saltare la biforcazione, che e' il senso della porta.
    if (c.da !== l.id) return { ok: false, msg: 'questa carriera non nasce da quel lavoretto' };
    l.carriera = id;
    l.contatori = {};
    return { ok: true, msg: c.nome };
  }

  window.PETQ.lavoro = {
    assicura: assicura,
    risolviNotte: risolviNotte,
    lavoroCorrente: lavoroCorrente,
    sceltaLavoretto: sceltaLavoretto,
    sceltaCarriera: sceltaCarriera,
    _lavoretti: function () { return LAVORETTI; },
    _carriere: function () { return CARRIERE; },
    _saluteCritica: saluteCritica,
    _energiaMin: ENERGIA_MIN_TURNO
  };
})();
