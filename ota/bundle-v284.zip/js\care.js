window.PETQ = window.PETQ || {};

(function () {

  // i18n bilingue (v. ui.js/i18n.js): SOLO i messaggi "telaio" scritti a mano qui sotto (toast di
  // cura/allenamento/coccole), MAI le stringhe dati (nomi cibi/talenti usati come chiave altrove).
  var traduci = (PETQ.i18n && PETQ.i18n.t) || function (s) { return s; };

  function bilanciamento() {
    var data = window.PETQ.content && window.PETQ.content.data;
    if (data && data.bilanciamento) return data.bilanciamento;
    console.warn('PETQ.care: bilanciamento non disponibile, uso default locali');
    return {
      decadimento: { fame: 6, igiene: 8, felicita: 2 },
      soglie: { critica: 25, magro: 30, sporco: 30, malusSalute: 40, sovralimentazione: 90 },
      economia: { login: 10, monetePartenza: 50 },
      allenamento: { sessioni: 1, effetto: 2, felicita: 5 },
      iniziali: { benessere: 70, base: 5, firma: 3 }
    };
  }

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  function oggiStr() {
    var d = new Date();
    var mese = String(d.getMonth() + 1).padStart(2, '0');
    var giorno = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + mese + '-' + giorno;
  }

  // Inventario/frigo (GDD "Economia" -> "Spesa e dispensa"): state.dispensa e' un array di
  // {nome, qty}. Decrementa di 1 la qty del cibo indicato; se arriva a 0 la voce sparisce
  // dal frigo. Ritorna true se ha trovato e consumato una porzione, false altrimenti (frigo
  // vuoto per quel cibo: il chiamante decide come reagire, v. feed sotto).
  function consumaDaDispensa(state, nomeCibo) {
    if (!state || !Array.isArray(state.dispensa)) return false;
    for (var i = 0; i < state.dispensa.length; i++) {
      if (state.dispensa[i].nome === nomeCibo) {
        state.dispensa[i].qty = (state.dispensa[i].qty || 0) - 1;
        if (state.dispensa[i].qty <= 0) state.dispensa.splice(i, 1);
        return true;
      }
    }
    return false;
  }

  // Soglia sovralimentazione (bilanciamento.md "Soglie"): dare da mangiare quando la Fame e'
  // GIA' ALTA (>= 90) e' "mangiare troppo": contribuisce alla variante ciccione (v. pet.js
  // bodyVariant, contatore state.pet.sovralimentazioniRecenti) e infligge +10 Ferite (sistema
  // Ferite esistente, stesso meccanismo dei danni missione). ECCEZIONE: il baby non ne risente
  // (ne' ciccione ne' ferite) — decisione fondatore, il baby non ingrassa e non si ammala cosi'.
  var SOGLIA_SOVRALIMENTAZIONE_DEFAULT = 90;
  var FERITE_SOVRALIMENTAZIONE = 10;

  function sogliaSovralimentazione() {
    var bil = bilanciamento();
    var v = bil.soglie && bil.soglie.sovralimentazione;
    return (typeof v === 'number') ? v : SOGLIA_SOVRALIMENTAZIONE_DEFAULT;
  }

  // Stat RPG del pet, nell'ordine canonico (stesse chiavi di pet.rpg / STAT_LABEL_TRAIN in fondo
  // al file). Usata dall'effetto cibo 'rpg_casuale' qui sotto.
  var STAT_RPG_NOMI = ['forza', 'intelligenza', 'velocita', 'carisma'];

  // Effetto '+N stat RPG casuale' (v. content.js RE_RPG_CASUALE): estrae UNA delle 4 stat RPG
  // con lo stesso rng seedabile del resto del gioco (PETQ.rng.pick). L'estrazione avviene DENTRO
  // feed, quindi nei cibi multi-porzione (Scorta di Panini ×5, Er Pacco da Sotto ×3, Abbuffata
  // in Diretta ×5) la stat cambia a ogni morso: ogni porzione e' una chiamata a feed a se'.
  // Ritorna null se il pet non ha nessuna stat RPG valida (save corrotto): il chiamante non
  // deve nemmeno consumare lo slot del pasto-con-stat in quel caso.
  function statRpgCasuale(pet) {
    var candidate = [];
    for (var i = 0; i < STAT_RPG_NOMI.length; i++) {
      if (pet && pet.rpg && typeof pet.rpg[STAT_RPG_NOMI[i]] === 'number') candidate.push(STAT_RPG_NOMI[i]);
    }
    if (candidate.length === 0) return null;
    return PETQ.rng.pick(candidate);
  }

  // Il pet ha almeno una stat RPG su cui applicare l'estrazione? (guardia da usare PRIMA di far
  // consumare lo slot del pasto-con-stat a un effetto che non produrrebbe nulla)
  function statRpgCasualeDisponibile(pet) {
    for (var i = 0; i < STAT_RPG_NOMI.length; i++) {
      if (pet && pet.rpg && typeof pet.rpg[STAT_RPG_NOMI[i]] === 'number') return true;
    }
    return false;
  }

  // Feed: il pagamento avviene allo SHOP (GDD "Spesa e dispensa"), non qui. feed() consuma
  // 1 porzione dall'inventario (state.dispensa) e applica gli effetti; niente scalo monete.
  // cibo = {nome, categoria, fame, stat, statNome, effetti} (v. content.js parseCibi /
  // ciboFallback in ui.js). effetti = lista Tier 2 di {tipo:'rpg'|'rpg_casuale'|'benessere',
  // nome, valore}: un cibo puo' avere PIU' stat RPG (anche in negativo) e toccare il benessere.
  /* ---------- CUOCO DI CASA (perk corso_cucina, Corso Pomeridiano) ----------
   * Una volta al giorno il pet ti cucina: prende un cibo che hai GIA' in dispensa e lo serve
   * migliorato — piu' sazio e con un effetto piu' generoso.
   *
   * PERCHE' NON "un cibo gratis al giorno" (prima idea del fondatore, scartata insieme): quello lo
   * fa GIA' il Topo Chef del Supporter Pack (+1 Crocchette al giorno). Un corso gratuito che
   * duplica una cosa venduta la svaluta. Qui la differenza e' netta: il Topo Chef AGGIUNGE cibo,
   * il Cuoco MIGLIORA quello che hai — e da un mestiere alla dispensa, che oggi e' passiva.
   *
   * IMPLEMENTAZIONE, la parte che vale: NON si tocca feed(). Si passa a feed una COPIA del cibo
   * col bonus dentro. Cosi' tutta la catena che feed conosce gia' (consumo della porzione, cap
   * pasti-stat, talenti, sovralimentazione, streak, suoni) resta identica e non c'e' un secondo
   * percorso di alimentazione da tenere in riga col primo.
   */
  var CUOCO_FAME_MULT = 1.2;   // +20% di sazio
  var CUOCO_STAT_EXTRA = 1;    // +1 sul primo effetto RPG del piatto

  function haPerkCuoco(state) {
    return !!(state && Array.isArray(state.perks) && state.perks.indexOf('corso_cucina') !== -1);
  }

  function cuocoUsatoOggi(state) {
    if (!state) return true;
    return state.cuocoGiorno === PETQ.clock.giornoCorrente(state);
  }

  function cucinaEServi(state, cibo) {
    if (!state || !state.pet || !cibo) return { ok: false, msg: traduci('errore interno') };
    if (!haPerkCuoco(state)) return { ok: false, msg: traduci('Il pet non ha fatto il corso di cucina.') };
    if (cuocoUsatoOggi(state)) return { ok: false, msg: traduci('Ha già cucinato oggi.') };

    // Copia col bonus. Copia PROFONDA degli effetti: modificare l'array del catalogo
    // significherebbe potenziare quel cibo per sempre, anche mangiato senza il cuoco.
    var piatto = {};
    for (var k in cibo) if (Object.prototype.hasOwnProperty.call(cibo, k)) piatto[k] = cibo[k];
    piatto.fame = Math.round((cibo.fame || 0) * CUOCO_FAME_MULT);
    piatto.effetti = [];
    var primoRpgFatto = false;
    for (var i = 0; i < (cibo.effetti || []).length; i++) {
      var e = cibo.effetti[i];
      var copia = { tipo: e.tipo, nome: e.nome, valore: e.valore };
      // Solo il PRIMO effetto RPG prende l'extra, e solo se e' un guadagno: gonfiare un malus
      // (i Cibi del Disonore hanno Carisma negativo) vorrebbe dire che cucinare peggiora le cose.
      if (!primoRpgFatto && e.tipo === 'rpg' && e.valore > 0) {
        copia.valore = e.valore + CUOCO_STAT_EXTRA;
        primoRpgFatto = true;
      }
      piatto.effetti.push(copia);
    }
    if (primoRpgFatto) piatto.stat = (cibo.stat || 0) + CUOCO_STAT_EXTRA;

    var r = feed(state, piatto);
    if (!r.ok) return r; // rifiutato (dieta, dispensa vuota...): il turno del cuoco NON si consuma
    state.cuocoGiorno = PETQ.clock.giornoCorrente(state);
    return {
      ok: true,
      msg: (state.pet.nome || traduci('Il pet')) + traduci(' ha cucinato: ') + traduci(cibo.nome) + '.',
      base: r.msg
    };
  }

  function feed(state, cibo) {
    if (!state || !state.pet || !cibo) return { ok: false, msg: traduci('errore interno') };

    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo A, "Fissato con la Dieta"): blocca_cibo=dolce
    // impedisce di somministrare quella categoria. Controllato PRIMA di consumare dalla
    // dispensa: il pasto va rifiutato, non "sprecato" (v. anche renderAzioniCucina in ui.js,
    // che disabilita gia' la card nel frigo con lo stesso motivo).
    if (PETQ.talenti && PETQ.talenti.ciboBloccato && PETQ.talenti.ciboBloccato(state, cibo.categoria)) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto'); // rifiuto: talento Fissato con la Dieta blocca la categoria
      return { ok: false, msg: traduci('Il talento Fissato con la Dieta non tocca i dolci.') };
    }

    if (!consumaDaDispensa(state, cibo.nome)) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto'); // rifiuto: frigo vuoto per quel cibo
      return { ok: false, msg: traduci('Non ne hai in frigo: compralo al Negozio.') };
    }

    var pet = state.pet;
    var famePrima = pet.stats.fame;
    pet.stats.fame = clamp(pet.stats.fame + (cibo.fame || 0), 0, 100);

    // Lista effetti Tier 2. Fallback per gli oggetti-cibo costruiti a mano da altro codice
    // (v. ciboFallback in ui.js) che hanno solo la vecchia coppia stat/statNome: la si
    // riconverte in un unico effetto RPG, cosi' il resto della funzione ha una sola strada.
    var effetti = Array.isArray(cibo.effetti) ? cibo.effetti : [];
    if (effetti.length === 0 && cibo.statNome) {
      effetti = [{ tipo: 'rpg', nome: cibo.statNome, valore: cibo.stat || 0 }];
    }

    // Pacing stat RPG (bilanciamento.md "Pacing stat RPG", decisione fondatore): il bonus stat
    // del cibo scatta solo per i PRIMI 2 pasti-CON-STAT del giorno (non piu' "primo per
    // categoria"): dal 3o pasto-con-stat in poi lo spam non da' piu' stat. Il bonus fame invece
    // si applica sempre (comportamento invariato, vedi sopra).
    // Il tracking delle CATEGORIE resta, ma SEPARATO dal bonus stat: serve solo al malus "dieta
    // squilibrata" (2 giorni con una sola categoria / solo dolci), quindi ogni pasto registra la
    // sua categoria indipendentemente dallo stat. Il contatore state.pastiStatOggi conta invece
    // quanti pasti-con-stat sono gia' stati dati oggi (cibi senza stat non lo consumano).
    // Talenti (Gruppo A, "bonus_cibo=<categoria>:+1stat"/"bonus_cibo=salutare:+1stat", es.
    // Braccia di Ferro/Amante della Natura/Fissato con la Dieta): l'EXTRA si applica SOLO
    // quando scatta anche il bonus base (stessa guardia dei 2 pasti-con-stat), mai in spam.
    // Completo da Chef (indossabile): il PRIMO pasto di ogni categoria del giorno da' +1 stat extra
    // sulla stat del cibo. Va calcolato PRIMA che la categoria venga registrata in categoriePastiOggi
    // (sotto), e applicato solo se il cibo ha una stat. Indipendente dal cap dei 2-pasti-con-stat
    // (effetto vestito separato, stesso spirito del passivo Popeye qui sotto).
    var chefPrimaCategoria = state.indossato === 'Completo da Chef' &&
      cibo.categoria && Array.isArray(state.categoriePastiOggi) &&
      state.categoriePastiOggi.indexOf(cibo.categoria) === -1;
    if (!Array.isArray(state.categoriePastiOggi)) state.categoriePastiOggi = [];
    if (cibo.categoria && state.categoriePastiOggi.indexOf(cibo.categoria) === -1) {
      state.categoriePastiOggi.push(cibo.categoria); // solo per il malus "dieta squilibrata"
    }
    if (typeof state.pastiStatOggi !== 'number') state.pastiStatOggi = 0;
    // Tier 2 (cibi multi-effetto con malus): il cap dei 3 pasti-con-stat vale per l'INTERO cibo,
    // non per singolo effetto — se c'e' spazio si applicano TUTTI i suoi effetti RPG e il
    // contatore sale di 1 SOLO; se il cap e' esaurito non se ne applica nessuno.
    // NIENTE PAVIMENTO sulle stat RPG (decisione fondatore): possono andare sotto zero.
    // 'rpg_casuale' (+N stat RPG casuale) conta come effetto RPG a tutti gli effetti: rientra in
    // questa lista, quindi consuma lo stesso UNICO slot e non si applica a cap esaurito. La stat
    // vera si estrae solo al momento di applicarla (v. statRpgCasuale sopra).
    var effettiRpg = [];
    for (var iEf = 0; iEf < effetti.length; iEf++) {
      if (effetti[iEf].tipo === 'rpg' && pet.rpg && typeof pet.rpg[effetti[iEf].nome] === 'number') {
        effettiRpg.push(effetti[iEf]);
      } else if (effetti[iEf].tipo === 'rpg_casuale' && statRpgCasualeDisponibile(pet)) {
        effettiRpg.push(effetti[iEf]);
      }
    }
    var daStat = effettiRpg.length > 0 && state.pastiStatOggi < 3;
    if (daStat) {
      // L'extra dei talenti va alla stat PRINCIPALE del cibo (cibo.statNome = primo effetto RPG),
      // una volta sola, esattamente come prima del Tier 2: mai una volta per effetto.
      var extraTalento = (PETQ.talenti && PETQ.talenti.bonusCiboExtra) ?
        PETQ.talenti.bonusCiboExtra(state, cibo.categoria) : 0;
      // Tetto per stadio (bilanciamento.md "Tetto delle statistiche per stadio"): passa SEMPRE da
      // PETQ.pet.aggiungiStat, l'UNICA funzione autorizzata ad alzare pet.rpg (v. pet.js).
      for (var iRpg = 0; iRpg < effettiRpg.length; iRpg++) {
        var efRpg = effettiRpg[iRpg];
        if (efRpg.tipo === 'rpg_casuale') {
          var statEstratta = statRpgCasuale(pet);
          if (statEstratta) PETQ.pet.aggiungiStat(pet, statEstratta, efRpg.valore || 0);
        } else {
          PETQ.pet.aggiungiStat(pet, efRpg.nome, efRpg.valore || 0);
        }
      }
      if (extraTalento && cibo.statNome && typeof pet.rpg[cibo.statNome] === 'number') {
        PETQ.pet.aggiungiStat(pet, cibo.statNome, extraTalento);
      }
      state.pastiStatOggi += 1;
    }

    // Perk = MEDAGLIETTE — Popeye (decisione fondatore, bilanciamento.md "Perk = MEDAGLIETTE"):
    // passivo del badge 'popeye' — ogni volta che il pet mangia VERDURA prende +1 Forza EXTRA.
    // Indipendente dal cap dei 2-pasti-con-stat (e' un effetto perk separato, non un bonus cibo).
    if (Array.isArray(state.perks) && state.perks.indexOf('popeye') !== -1 &&
        cibo.categoria === 'verdura' && pet.rpg && typeof pet.rpg.forza === 'number') {
      PETQ.pet.aggiungiStat(pet, 'forza', 1);
    }

    // applica il +1 Chef (calcolato sopra prima della registrazione categoria)
    if (chefPrimaCategoria && cibo.statNome && pet.rpg && typeof pet.rpg[cibo.statNome] === 'number') {
      PETQ.pet.aggiungiStat(pet, cibo.statNome, 1);
    }

    if (!pet.pastiOggi) pet.pastiOggi = [];
    // digestioneOre: 60-90 minuti di GIOCO dopo il pasto scatta il bisogno
    // (v. pet.js applyDecay, ritmo cura playtest v2)
    pet.pastiOggi.push({
      nome: cibo.nome, categoria: cibo.categoria, quando: Date.now(),
      digerito: false, oreDigerite: 0,
      digestioneOre: 1 + PETQ.rng.rand() * 0.5
    });

    // Tier 2 — effetti di BENESSERE (fame/igiene/felicita/energia/ferite): si applicano SEMPRE,
    // NON consumano lo slot dei pasti-con-stat (un cibo che sporca sporca anche al 4o pasto) e
    // NON sostituiscono la colonna +Fame: un effetto 'fame' e' un EXTRA che si somma a quella.
    // Le stat di benessere restano clampate 0..100 (il pavimento vale per loro, non per le RPG).
    // Le ferite vanno su state.ferite come nel ramo sovralimentazione qui sotto: la Salute la
    // ricalcola la recomputeSalute condivisa in fondo, una volta sola per pasto.
    for (var iBen = 0; iBen < effetti.length; iBen++) {
      var efBen = effetti[iBen];
      if (efBen.tipo !== 'benessere') continue;
      if (efBen.nome === 'ferite') {
        state.ferite = clamp((state.ferite || 0) + (efBen.valore || 0), 0, 100);
      } else if (pet.stats && typeof pet.stats[efBen.nome] === 'number') {
        pet.stats[efBen.nome] = clamp(pet.stats[efBen.nome] + (efBen.valore || 0), 0, 100);
      }
    }

    // Sovralimentazione (bilanciamento.md "Soglie"): scatta se la Fame era GIA' >= soglia
    // PRIMA di questo pasto (mangiare quando si e' gia' pieni), mai per il baby.
    var eBaby = pet.stadio === 'baby';
    var sovralimentato = !eBaby && famePrima >= sogliaSovralimentazione();
    if (sovralimentato) {
      pet.sovralimentazioniRecenti = (pet.sovralimentazioniRecenti || 0) + 1;
      state.ferite = clamp((state.ferite || 0) + FERITE_SOVRALIMENTAZIONE, 0, 100);
    }

    PETQ.pet.recomputeSalute(pet, state);

    var msg = (pet.nome || traduci('Il pet')) + traduci(' ha mangiato: ') + traduci(cibo.nome) + '.';
    if (PETQ.audio) PETQ.audio.suona('mangia'); // pasto andato a buon fine
    return { ok: true, msg: msg, sovralimentato: sovralimentato };
  }

  function wash(state) {
    if (!state || !state.pet) return { ok: false, msg: traduci('errore interno') };
    state.pet.stats.igiene = 100;
    // Vasca idromassaggio (arredo 'igiene_extra_lavaggio', 150 monete — effetto dichiarato in
    // arredi.md e MAI implementato fino alla fase giocattoli): +5 Igiene extra per lavaggio. Il
    // lavaggio porta gia' l'Igiene al massimo, quindi l'extra diventa un CREDITO che assorbe il
    // primo calo successivo (pet.applyDecay lo consuma prima di intaccare la stat): e' l'unico
    // modo di far valere davvero quei punti sopra il tetto invece di buttarli via al primo tick.
    // Non si accumula fra un bagno e l'altro: ogni lavaggio lo RIPORTA al valore pieno.
    var extraVasca = (PETQ.arredi && PETQ.arredi.igieneExtraLavaggio) ? PETQ.arredi.igieneExtraLavaggio(state) : 0;
    state.igieneCredito = extraVasca > 0 ? extraVasca : 0;
    PETQ.pet.recomputeSalute(state.pet, state);
    if (PETQ.audio) PETQ.audio.suona('lava'); // lavaggio andato a buon fine (wash() qui non ha rami di rifiuto)
    return { ok: true, msg: traduci('Pulito e profumato.'), igieneExtra: state.igieneCredito };
  }

  function cleanPoop(state) {
    if (!state) return { ok: false, msg: traduci('errore interno') };
    state.poop = 0;
    if (state.pet) {
      state.pet.stats.felicita = clamp(state.pet.stats.felicita + 3, 0, 100);
      PETQ.pet.recomputeSalute(state.pet, state);
    }
    return { ok: true, msg: traduci('Casa pulita.') };
  }

  // Coccola: felicità+3, max 5 al giorno (default). Numero max/giorno non specificato altrove
  // nella config: tracciato in state.coccoleDay/state.coccoleCount (default locale, segnalato).
  // Cap talenti (PROTOTIPO 2, Blocco 9, "Coccolone"): il cap 5 diventa 8 se il pet ha quel
  // talento attivo — letto ad ogni chiamata da PETQ.talenti.capCoccole (hook dedicato, stesso
  // spirito di PETQ.arredi.bonusAllenamento per il Topo).
  var COCCOLA_EFFETTO = 5; // +3 -> +5 (decisione fondatore, playtest 7 lug 2026: "+15/die non bastavano")
  var COCCOLA_MAX_DIE_DEFAULT = 5;

  function capCoccoleGiorno(state) {
    if (PETQ.talenti && typeof PETQ.talenti.capCoccole === 'function') {
      return PETQ.talenti.capCoccole(state);
    }
    return COCCOLA_MAX_DIE_DEFAULT;
  }

  function coccola(state) {
    if (!state || !state.pet) return { ok: false, msg: traduci('errore interno') };
    var oggi = PETQ.clock.giornoCorrente(state);
    if (state.coccoleDay !== oggi) {
      state.coccoleDay = oggi;
      state.coccoleCount = 0;
    }
    var capOggi = capCoccoleGiorno(state);
    if ((state.coccoleCount || 0) >= capOggi) {
      // Cap raggiunto (GDD "Coccole" / bilanciamento playtest 4 lug 2026): battuta di
      // personalita' dedicata (pool 'coccole_finite', testi del socio) invece del messaggio
      // generico. msg resta come fallback per la UI se il pool risulta vuoto (v. ui.js
      // eseguiCoccola, stesso pattern di battutaPool gia' usato da care.train per 'sonno').
      if (PETQ.audio) PETQ.audio.suona('rifiuto'); // rifiuto: cap coccole/giorno raggiunto
      return { ok: false, msg: traduci('Basta coccole per oggi, torna domani.'), battutaPool: 'coccole_finite' };
    }
    state.coccoleCount = (state.coccoleCount || 0) + 1;
    // Talenti "coccola=fel+N" (Coccolone, P2 — agganciato nel P3 batch 4: era l'unico token
    // rimasto inerte): felicita' extra per singola coccola, in aggiunta all'effetto base.
    var felExtra = (PETQ.talenti && PETQ.talenti.coccolaFelExtra) ? PETQ.talenti.coccolaFelExtra(state) : 0;
    state.pet.stats.felicita = clamp(state.pet.stats.felicita + COCCOLA_EFFETTO + felExtra, 0, 100);
    PETQ.pet.recomputeSalute(state.pet, state);
    if (PETQ.audio) PETQ.audio.suona('coccola'); // coccola andata a buon fine
    return { ok: true, msg: traduci('Coccola fatta.') };
  }

  // Durata allenamento (bilanciamento.md "Durata allenamento", decisione fondatore 4 lug 2026,
  // sessione "attivita' a tempo"): l'allenamento NON e' piu' istantaneo ne' un salto d'orologio
  // secco. E' un ibrido tra le MISSIONI (dura, blocca le azioni, si vede un countdown) e il
  // SONNO (la durata e' in ORE DI GIOCO che si accumulano via PETQ.pet.applyDecay, cosi' il
  // moltiplicatore debug ×60/×600 lo accelera come tutto il resto). train() qui sotto NON
  // applica piu' subito l'effetto: AVVIA l'attivita' (state.allenamento), l'effetto/felicita'/
  // costo energia si applicano al COMPLETAMENTO (v. pet.js controllaAllenamentoScaduto), per
  // coerenza con "il pet e' occupato mentre si allena" (a differenza del vecchio salto secco).
  //
  // Talenti (PROTOTIPO 2, Blocco 9, Gruppo A): state.trainDay resta la data dell'ULTIMO
  // allenamento avviato (serve a sapere quando azzerare il contatore sotto e resta letto da
  // ui.js per l'hint "gia' fatto oggi" nel caso comune di 1/giorno); state.trainCount conta
  // quanti allenamenti sono stati AVVIATI oggi, confrontato con
  // PETQ.talenti.allenamentiPerGiorno(state) (default 1, 2 con "Predestinato"). Marcati
  // all'AVVIO (non al completamento), stesso principio di prima: niente secondo avvio oltre il
  // limite anche se il primo e' ancora "in corso" a cavallo di mezzanotte.
  var DURATA_ALLENAMENTO_ORE = 0.75;

  function allenamentiFattiOggi(state) {
    if (!state) return 0;
    return (state.trainDay === PETQ.clock.giornoCorrente(state)) ? (state.trainCount || 0) : 0;
  }

  function train(state, statNome) {
    if (!state || !state.pet) return { ok: false, msg: traduci('errore interno') };
    if (state.sonno) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto'); // rifiuto: pet addormentato
      return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' sta dormendo.') };
    }
    if (state.allenamento) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto'); // rifiuto: gia' in allenamento
      return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' si sta gia\' allenando.') };
    }
    var oggi = PETQ.clock.giornoCorrente(state);
    var maxGiorno = (PETQ.talenti && PETQ.talenti.allenamentiPerGiorno) ?
      PETQ.talenti.allenamentiPerGiorno(state) : 1;
    if (allenamentiFattiOggi(state) >= maxGiorno) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto'); // rifiuto: tetto giornaliero raggiunto
      return { ok: false, msg: traduci('Allenamento già fatto oggi.') };
    }
    if (!state.pet.rpg || typeof state.pet.rpg[statNome] !== 'number') {
      // guardia difensiva (statNome non valido/save corrotto), non un vero rifiuto di gameplay:
      // niente suono, stesso trattamento del guard 'errore interno' in cima alla funzione.
      return { ok: false, msg: traduci('Statistica non valida.') };
    }
    var ignoraEnergia = PETQ.talenti && PETQ.talenti.ignoraRifiutoEnergia && PETQ.talenti.ignoraRifiutoEnergia(state);
    if (!ignoraEnergia && PETQ.pet.energiaSottoSoglia(state.pet)) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto'); // rifiuto: energia sotto soglia
      return { ok: false, msg: traduci('Troppo stanco per allenarsi.'), battutaPool: 'sonno' };
    }

    // Marcato all'AVVIO (non al completamento).
    if (state.trainDay !== oggi) {
      state.trainDay = oggi;
      state.trainCount = 0;
    }
    state.trainCount = (state.trainCount || 0) + 1;

    var durataMult = (PETQ.talenti && PETQ.talenti.durataAllenamentoMult) ?
      PETQ.talenti.durataAllenamentoMult(state) : 1;
    state.allenamento = { stat: statNome, oreFatte: 0, oreTot: DURATA_ALLENAMENTO_ORE * durataMult };
    if (PETQ.audio) PETQ.audio.suona('allenamento'); // allenamento avviato davvero (non il completamento)

    return {
      ok: true,
      msg: (state.pet.nome || traduci('Il pet')) + traduci(' inizia ad allenarsi.'),
      avviato: true
    };
  }

  // Completa l'allenamento in corso: applica effetto stat (+ bonus arredi + bonus talenti),
  // felicita' bonus e costo/guadagno energia (v. bilanciamento.md "Allenamento"/"Energia e
  // sonno"), poi azzera state.allenamento. Va richiamata SOLO quando oreFatte >= oreTot (v.
  // pet.js controllaAllenamentoScaduto, stesso pattern di risolviRisveglio/missions.risolvi: il
  // "quando" lo decide il chiamante, questa funzione applica sempre se c'e' un'attivita' attiva).
  function completaAllenamento(state) {
    if (!state || !state.pet || !state.allenamento) return { ok: false, msg: traduci('Nessun allenamento in corso.') };

    var statNome = state.allenamento.stat;
    var bil = bilanciamento();
    var effetto = (bil.allenamento && typeof bil.allenamento.effetto === 'number') ? bil.allenamento.effetto : 1;
    var felicitaBonus = (bil.allenamento && typeof bil.allenamento.felicita === 'number') ? bil.allenamento.felicita : 5;
    var es = PETQ.pet.bilEnergiaSonno();

    if (PETQ.arredi && PETQ.arredi.bonusAllenamento) {
      effetto += PETQ.arredi.bonusAllenamento(state, statNome);
    }

    // Talenti (Gruppo A, "bonus_allenamento=<stat>:+N" / "bonus_allenamento=qualsiasi:<stat>+N",
    // es. Braccia di Ferro/Mente Analitica): extra per-stat, sommato DOPO l'arredo cosi' finisce
    // sempre nello stesso numero mostrato in "Allenamento finito: +N". Puo' toccare stat DIVERSE
    // da quella allenata (Mente Analitica da' +1 Int allenando qualsiasi cosa): applichiamo la
    // stat allenata con `effetto` (base+arredi+extra-stessa-stat) e le eventuali stat extra
    // diverse separatamente.
    var extraPerStat = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    if (PETQ.talenti && PETQ.talenti.bonusAllenamentoExtra) {
      extraPerStat = PETQ.talenti.bonusAllenamentoExtra(state, statNome);
    }
    effetto += extraPerStat[statNome] || 0;

    // Talenti (P3 BATCH 4, "guadagni_stat=x2 ; energia_extra=-10", Overclock): raddoppia (o piu',
    // il moltiplicatore e' letto dal token) il guadagno TOTALE da allenamento su TUTTE le stat
    // coinvolte (stat allenata + eventuali extra di altre stat, es. combo con Mente Analitica),
    // applicato DOPO aver sommato arredi+talenti Gruppo A (il testo dice "raddoppia i guadagni
    // stat da allenamento" senza distinguere le fonti). L'energia extra scatta SOLO se il
    // moltiplicatore e' davvero >1 E il guadagno sulla stat allenata non era zero (niente
    // surriscaldamento "a vuoto" su un allenamento che non darebbe comunque nulla).
    var overclock = (PETQ.talenti && PETQ.talenti.overclockInfo) ? PETQ.talenti.overclockInfo(state) : { mult: 1, energiaExtra: 0 };
    if (overclock.mult !== 1) {
      effetto = Math.round(effetto * overclock.mult);
      for (var ko in extraPerStat) {
        if (!Object.prototype.hasOwnProperty.call(extraPerStat, ko)) continue;
        if (ko === statNome) continue; // gia' incluso in `effetto` sopra
        extraPerStat[ko] = Math.round(extraPerStat[ko] * overclock.mult);
      }
    }

    // Tetto per stadio (bilanciamento.md "Tetto delle statistiche per stadio"): passa dal cancello
    // unico PETQ.pet.aggiungiStat, che ritorna quanto e' stato REALMENTE applicato (puo' essere
    // meno di `effetto`/`extraPerStat[k]` se il tetto ha morso) — usato sotto per il messaggio,
    // cosi' non promette un guadagno che non e' successo.
    var applicatoBase = 0;
    if (state.pet.rpg && typeof state.pet.rpg[statNome] === 'number') {
      applicatoBase = PETQ.pet.aggiungiStat(state.pet, statNome, effetto);
    }
    var extraAltreStat = [];
    for (var k in extraPerStat) {
      if (!Object.prototype.hasOwnProperty.call(extraPerStat, k)) continue;
      if (k === statNome) continue; // gia' incluso in `effetto` sopra
      if (extraPerStat[k] > 0 && state.pet.rpg && typeof state.pet.rpg[k] === 'number') {
        var applicatoExtra = PETQ.pet.aggiungiStat(state.pet, k, extraPerStat[k]);
        if (applicatoExtra > 0) {
          extraAltreStat.push('+' + applicatoExtra + ' ' + traduci(STAT_LABEL_TRAIN[k]));
        }
      }
    }

    state.pet.stats.felicita = clamp(state.pet.stats.felicita + felicitaBonus, 0, 100);

    // Talenti (Gruppo A, "allenamento_energia=+N", Energico): l'allenamento DA' energia invece
    // di toglierla. energiaAllenamentoOverride ritorna il delta gia' col segno giusto (es. +5),
    // il chiamante lo SOMMA invece di sottrarre il costo normale.
    var overrideEnergia = (PETQ.talenti && PETQ.talenti.energiaAllenamentoOverride) ?
      PETQ.talenti.energiaAllenamentoOverride(state) : null;
    if (overrideEnergia !== null) {
      state.pet.stats.energia = clamp(state.pet.stats.energia + overrideEnergia, 0, 100);
    } else {
      state.pet.stats.energia = clamp(state.pet.stats.energia - es.costoAllenamento, 0, 100);
    }

    // Overclock (segue): il surriscaldamento si applica DOPO il costo/guadagno energia normale
    // sopra (Energico ed Overclock non sono mai sullo stesso pet nel design attuale — personalita'
    // diverse — ma se mai capitasse, l'ordine resta "prima il costo/guadagno base, poi l'extra").
    // Controllo su applicatoBase (il guadagno REALMENTE applicato, dopo il tetto per stadio), non
    // su `effetto` (il guadagno richiesto): se il tetto ha azzerato tutto il guadagno, il
    // surriscaldamento non ha "davvero effetto" e non deve costare energia a vuoto.
    if (overclock.mult !== 1 && overclock.energiaExtra !== 0 && applicatoBase !== 0) {
      state.pet.stats.energia = clamp(state.pet.stats.energia + overclock.energiaExtra, 0, 100);
    }

    state.allenamento = null;
    PETQ.pet.recomputeSalute(state.pet, state);

    var msg = traduci('Allenamento finito: +') + applicatoBase + ' ' + traduci(STAT_LABEL_TRAIN[statNome]) + '!';
    if (extraAltreStat.length > 0) msg += ' (' + extraAltreStat.join(', ') + ')';

    return {
      ok: true,
      msg: msg,
      stat: statNome,
      effetto: applicatoBase
    };
  }

  var STAT_LABEL_TRAIN = { forza: 'Forza', intelligenza: 'Intelligenza', velocita: 'Velocità', carisma: 'Carisma' };

  // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "parole_giorno=4", Cervellone): quante parole si
  // possono insegnare OGGI (default 1, 4 con Cervellone). Stesso pattern di
  // allenamentiFattiOggi/allenamentiPerGiorno: state.wordDay resta la data dell'ultimo
  // insegnamento (serve solo per sapere quando azzerare state.wordCount sotto), state.wordCount
  // conta quante parole sono state insegnate OGGI, confrontato col tetto dei talenti.
  function paroleInsegnateOggi(state) {
    if (!state) return 0;
    return (state.wordDay === PETQ.clock.giornoCorrente(state)) ? (state.wordCount || 0) : 0;
  }

  function teachWord(state, parola) {
    if (!state || !state.pet) return { ok: false, msg: traduci('errore interno') };
    var oggi = PETQ.clock.giornoCorrente(state);
    var maxGiorno = (PETQ.talenti && PETQ.talenti.parolePerGiorno) ? PETQ.talenti.parolePerGiorno(state) : 1;
    if (paroleInsegnateOggi(state) >= maxGiorno) {
      return { ok: false, msg: traduci('Parola già insegnata oggi.') };
    }
    var pulita = (parola || '').trim();
    if (pulita === '') {
      return { ok: false, msg: traduci('Scrivi una parola valida.') };
    }

    var bil = bilanciamento();
    var felicitaBonus = (bil.allenamento && typeof bil.allenamento.felicita === 'number') ? bil.allenamento.felicita : 5;

    if (!state.parole) state.parole = [];
    state.parole.push(pulita);
    state.pet.stats.felicita = clamp(state.pet.stats.felicita + felicitaBonus, 0, 100);
    if (state.wordDay !== oggi) {
      state.wordDay = oggi;
      state.wordCount = 0;
    }
    state.wordCount = (state.wordCount || 0) + 1;
    PETQ.pet.recomputeSalute(state.pet, state);

    return { ok: true, msg: (state.pet.nome || traduci('Il pet')) + traduci(' ha imparato: ') + pulita + '.' };
  }

  // "Studio veloce" (PROTOTIPO 2, Blocco 9, Gruppo A, talento Nerd "Sete di Sapere",
  // allenamento_extra=int): +1 Intelligenza ISTANTANEO, 1/giorno, che NON consuma il turno di
  // allenamento normale (state.allenamento resta libero, trainCount non si tocca). Traccia il
  // giorno in state.studioVeloceDay, stesso pattern di wordDay/trainDay. Visibile in UI SOLO se
  // il pet ha il talento (v. ui.js renderAzioniSalone, controllo su
  // PETQ.talenti.allenamentoExtraStat).
  function studioVeloce(state) {
    if (!state || !state.pet) return { ok: false, msg: traduci('errore interno') };
    var statExtra = (PETQ.talenti && PETQ.talenti.allenamentoExtraStat) ? PETQ.talenti.allenamentoExtraStat(state) : null;
    if (!statExtra) {
      return { ok: false, msg: traduci('Nessun talento di studio veloce attivo.') };
    }
    if (state.sonno) {
      return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' sta dormendo.') };
    }
    if (state.missione) {
      return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' è in missione.') };
    }
    var oggi = PETQ.clock.giornoCorrente(state);
    if (state.studioVeloceDay === oggi) {
      return { ok: false, msg: traduci('Studio veloce già fatto oggi, torna domani.') };
    }
    if (!state.pet.rpg || typeof state.pet.rpg[statExtra] !== 'number') {
      return { ok: false, msg: traduci('Statistica non valida.') };
    }

    state.studioVeloceDay = oggi;
    // Tetto per stadio: passa dal cancello unico PETQ.pet.aggiungiStat. Il messaggio sotto resta
    // "+1" testuale (chiave i18n esistente, tradotta): lo studio veloce da' sempre esattamente 1
    // punto quando NON e' al tetto; se il tetto ha gia' morso `applicatoStudio` e' 0 e la stat non
    // sale (il campo `effetto` sotto riporta il valore REALE per chi in futuro vorra' mostrarlo).
    var applicatoStudio = PETQ.pet.aggiungiStat(state.pet, statExtra, 1);
    PETQ.pet.recomputeSalute(state.pet, state);

    return {
      ok: true,
      msg: (state.pet.nome || traduci('Il pet')) + traduci(' fa uno studio veloce: +1 ') + traduci(STAT_LABEL_TRAIN[statExtra] || statExtra) + '!',
      stat: statExtra,
      effetto: applicatoStudio
    };
  }

  // ==================== Companion del Supporter Pack ====================
  // 4 arredi vivi (Topo Chef, Lumaca delle Pulizie, Piccione Postino, Criceto Dinamo — disegnati
  // e animati dal fondatore in rooms.js: ARREDI + COMPANION_MOTO) che si comportano come "Il
  // Topo (allenatore)" gia' esistente: si POSSIEDONO (sincronizzati col Supporter Pack, v.
  // save.js sincronizzaCompanionSupporter) e si PIAZZANO in una stanza. Qui diamo il loro effetto
  // quotidiano, UNA VOLTA AL GIORNO ciascuno, SOLO se sono PIAZZATI — il possesso da solo non
  // basta, stesso principio del bonus del Topo allenatore (v. arredi.bonusAllenamento, che legge
  // i piazzati, non i posseduti). Se il Supporter si spegne i companion RESTANO posseduti (non si
  // toglie roba dalle mani di chi ce l'ha) ma qui sotto l'effetto si spegne comunque, perche'
  // companionPiazzato da solo non basta: serve ANCHE state.supporter === true (v. guardia in
  // applicaEffettiCompanion sotto) — la regola del fondatore e' "l'effetto si applica solo se
  // supporter e' true E il companion e' piazzato".

  // Vero se il companion (per nome) e' piazzato in una QUALSIASI stanza (non basta il possesso).
  function companionPiazzato(state, nome) {
    if (!state || !state.arredi || !state.arredi.piazzati) return false;
    var piaz = state.arredi.piazzati;
    for (var stanza in piaz) {
      if (!Object.prototype.hasOwnProperty.call(piaz, stanza)) continue;
      var lista = piaz[stanza] || [];
      for (var i = 0; i < lista.length; i++) {
        if (lista[i] && lista[i].nome === nome) return true;
      }
    }
    return false;
  }

  // Cibo scelto per il Topo Chef: 'Crocchette semplici' (content/cibi.md, tabella "Base e
  // classici" — "il cibo economico di tutti i giorni", costo 5, +25 Fame, NESSUN effetto/malus).
  // E' anche il cibo gia' usato altrove come fallback/regalo neutro: niente nomi inventati, niente
  // cibi del "Disonore" (quelli tolgono Carisma, v. content/cibi.md sezione dedicata).
  var CIBO_TOPO_CHEF = 'Crocchette semplici';
  var MONETE_PICCIONE_MIN = 15;
  var MONETE_PICCIONE_MAX = 25;
  var ENERGIA_CRICETO = 30;

  // Applica gli effetti quotidiani dei companion PIAZZATI (e SOLO se state.supporter e' true,
  // decisione del fondatore: l'effetto si spegne insieme al Supporter anche se il companion resta
  // piazzato). Ritorna un array di record {tipo, ...dati}, uno per ogni companion che ha davvero
  // dato l'effetto oggi (array vuoto se nessuno) — NON tocca lastLoginDay ne' nessun contatore
  // giornaliero: la guardia "una volta al giorno vero" resta SOLO dentro dailyLogin (sotto).
  // Richiamabile ANCHE a comando dal pannello debug ("Companion: effetto ora", ui.js): quel
  // bottone deve poter collaudare l'effetto SUBITO senza aspettare la mezzanotte di gioco (regola
  // progetto: ogni cosa a tempo dev'essere saltabile da debug), e chiamando questa stessa funzione
  // (invece di duplicarne la logica) i due percorsi restano identici.
  function applicaEffettiCompanion(state) {
    var effetti = [];
    if (!state || !state.pet || state.supporter !== true) return effetti;

    if (companionPiazzato(state, 'Topo Chef')) {
      if (!Array.isArray(state.dispensa)) state.dispensa = [];
      var trovato = false;
      for (var i = 0; i < state.dispensa.length; i++) {
        if (state.dispensa[i].nome === CIBO_TOPO_CHEF) {
          state.dispensa[i].qty = (state.dispensa[i].qty || 0) + 1;
          trovato = true;
          break;
        }
      }
      if (!trovato) state.dispensa.push({ nome: CIBO_TOPO_CHEF, qty: 1 });
      effetti.push({ tipo: 'topoChef', cibo: CIBO_TOPO_CHEF });
    }

    if (companionPiazzato(state, 'Lumaca delle Pulizie')) {
      // decisione esplicita del fondatore: TUTTE le cacche, non una sola.
      state.poop = 0;
      effetti.push({ tipo: 'lumaca' });
    }

    if (companionPiazzato(state, 'Piccione Postino')) {
      var monete = PETQ.rng.randInt(MONETE_PICCIONE_MIN, MONETE_PICCIONE_MAX);
      state.coins = (state.coins || 0) + monete;
      effetti.push({ tipo: 'piccione', monete: monete });
    }

    if (companionPiazzato(state, 'Criceto Dinamo')) {
      state.pet.stats.energia = clamp((state.pet.stats.energia || 0) + ENERGIA_CRICETO, 0, 100);
      effetti.push({ tipo: 'criceto', energia: ENERGIA_CRICETO });
    }

    return effetti;
  }

  // ==================== Turno di lavoro notturno (Retention 2.0 Batch B, DESIGN-DILEMMI-LAVORI.md
  // §5.7 e §7) ====================
  // lavoro.risolviNotte() (lavoro.js:133) CALCOLA l'esito del turno ma non lo applica mai da sola
  // (lo dice il commento in cima a quel modulo: "chi lo chiama deve applicarlo") — finora nessuno
  // la chiamava affatto, quindi il turno non pagava mai. Il fondatore ha deciso: si riscuote AL
  // CAMBIO GIORNO, qui dentro dailyLogin, che e' gia' auto-guardato "una volta per giorno di
  // gioco" da state.lastLoginDay (v. sopra). Aggiungiamo COMUNQUE un guard dedicato
  // (state.lavoroGiorno, stesso schema di state.montaggioGiorno/state.trainDay/state.cuocoGiorno):
  // cintura di sicurezza in piu' se in futuro questa funzione venisse richiamata da un altro punto
  // — non deve MAI pagare due volte lo stesso turno.

  // Frasi GIA' PRONTE per il recap (non il testo grezzo di lavoro.js motivoSalto, che e' una nota
  // interna — nel suo codice usa perfino un trucco di concatenazione per un apostrofo tipografico,
  // segno che non e' pensato come copy per il giocatore). classificaMotivoSalto() legge il testo
  // grezzo per SOTTOSTRINGA (non uguaglianza esatta): regge anche se lavoro.js aggiusta la
  // formulazione in futuro, invece di dipendere carattere per carattere da una stringa fragile.
  var MOTIVO_SALTO_FRASE = {
    missione: 'una missione teneva occupata la notte',
    energia: 'era troppo stanco per il turno',
    salute: 'non stava bene per il turno',
    senzaPet: 'non c\'era il pet'
  };

  function classificaMotivoSalto(motivo) {
    var m = (motivo || '').toLowerCase();
    if (m.indexOf('missione') !== -1) return 'missione';
    if (m.indexOf('stanco') !== -1) return 'energia';
    if (m.indexOf('salute') !== -1) return 'salute';
    if (m.indexOf('pet') !== -1) return 'senzaPet';
    return null;
  }

  // Token 'oggetto:poolinventore' (v. lavoro.js righe 40-42): NON e' nel vocabolario di
  // missions.applicaRewardToken (e non deve entrarci: e' un token nostro, non generale del motore
  // reward). Il commento in lavoro.js chiede esplicitamente di risolverlo pescando da
  // content.data.poolInventore "riusando quella lista invece di scriverne una seconda qui, che
  // divergerebbe". PETQ.talenti.applicaInvenzione fa GIA' esattamente questo (stesso pool, stessa
  // estrazione PETQ.rng.pick, stessa mappa nome-oggetto->effetto del talento Inventore): lo
  // riusiamo com'e', senza ricopiare un solo pezzo di quella logica.
  function applicaTokenExtraLavoro(state, token, extraOut) {
    if (/^oggetto:poolinventore$/i.test(token)) {
      if (PETQ.talenti && typeof PETQ.talenti.applicaInvenzione === 'function') {
        var inv = PETQ.talenti.applicaInvenzione(state);
        if (inv && inv.ok && inv.oggetto) {
          extraOut.push({ tipo: 'oggettoInventore', nome: inv.oggetto.nome, dettaglio: inv.dettaglio });
        }
      }
      return;
    }
    // L'UNICO traduttore token->effetto del progetto (energia±N, stat±N, monete±N, cibo:Nome,
    // flag:, rendita:...): NON reimplementarlo qui, sarebbe una seconda copia che diverge (lezione
    // gia' scritta in lavoro.js riga 13, "due copie divergono sempre").
    if (PETQ.missions && typeof PETQ.missions._applicaRewardToken === 'function') {
      PETQ.missions._applicaRewardToken(state, token, extraOut);
    }
  }

  // Risolve il turno UNA volta per giorno di gioco (guard state.lavoroGiorno) e applica DAVVERO
  // l'esito (monete a state.coins, token extra via applicaTokenExtraLavoro). Non lancia MAI:
  // nessun pet / nessun lavoretto o carriera mai scelto / state.lavoro assente (lavoro.assicura lo
  // ripara da solo) / PETQ.lavoro o PETQ.missions assenti sono tutti no-op silenziosi, non errori
  // — un turno di lavoro che fallisce non deve poter rompere il cambio giorno.
  //
  // Lascia il riepilogo in state.lavoroEsitoGiorno per la UI: dailyLogin ritorna gia' solo il
  // bonus monete del login (nessuno spazio per un secondo valore di ritorno), stesso schema di
  // state.companionEffettiGiorno/state.loginFelicitaCasa/state.montaggioEvento/state.eventoValigia
  // qui sopra e sotto. null quando non c'e' nessun lavoro ATTIVO da raccontare (mai scelto un
  // lavoretto/carriera: non e' un turno "saltato", e' semplicemente non ancora iniziato — niente
  // avviso ogni mattina per chi non ha ancora la Porta 2); un oggetto quando c'e' qualcosa da
  // mostrare (turno pagato, O turno saltato con un lavoro gia' attivo).
  function risolviTurnoLavoroNotturno(state, oggi) {
    try {
      if (!state || !state.pet) return;
      if (!PETQ.lavoro || typeof PETQ.lavoro.risolviNotte !== 'function') return;
      if (state.lavoroGiorno === oggi) return; // gia' risolto oggi: mai pagare due volte lo stesso turno

      var corrente = (typeof PETQ.lavoro.lavoroCorrente === 'function') ? PETQ.lavoro.lavoroCorrente(state) : null;
      var esito = PETQ.lavoro.risolviNotte(state); // MUTA state.lavoro (nottiFatte/contatori): una volta sola, v. guard sopra
      state.lavoroGiorno = oggi; // segnato SUBITO dopo l'unica chiamata mutante, prima di qualsiasi codice che potrebbe fallire sotto

      if (!esito || !corrente) {
        state.lavoroEsitoGiorno = null; // nessun lavoretto/carriera mai scelto: niente da raccontare la mattina
        return;
      }

      var riepilogo = {
        saltato: !!esito.saltato,
        lavoro: (corrente.def && corrente.def.nome) || null, // nome grezzo IT (e' una chiave, come i nomi cibo/arredo): traduci() a schermo
        monete: 0,
        extra: [],
        motivoChiave: null,
        messaggio: null
      };

      if (esito.saltato) {
        riepilogo.motivoChiave = classificaMotivoSalto(esito.motivo);
        var fraseMotivo = (riepilogo.motivoChiave && MOTIVO_SALTO_FRASE[riepilogo.motivoChiave]) || 'il turno e\' saltato';
        riepilogo.messaggio = traduci('Turno di lavoro saltato: ') + traduci(fraseMotivo) + '.';
      } else {
        var monete = (typeof esito.monete === 'number') ? esito.monete : 0;
        state.coins = (state.coins || 0) + monete;
        riepilogo.monete = monete;
        riepilogo.messaggio = traduci('Turno finito: +') + monete + traduci(' monete.');

        var listaExtra = Array.isArray(esito.extra) ? esito.extra : [];
        for (var i = 0; i < listaExtra.length; i++) {
          var voce = listaExtra[i];
          var tok = voce && voce.token;
          if (tok) applicaTokenExtraLavoro(state, tok, riepilogo.extra);
        }
      }

      state.lavoroEsitoGiorno = riepilogo;
    } catch (e) {
      console.warn('PETQ.care: turno di lavoro notturno fallito, ignorato', e);
      state.lavoroEsitoGiorno = null;
    }
  }

  function dailyLogin(state) {
    if (!state) return 0;
    // "Nuovo giorno" sul GIORNO DI GIOCO (intero), non sulla data reale del PC: scatta quando
    // l'orologio di gioco attraversa mezzanotte (state.giornoGioco avanzato da clock.avanzaOrologio),
    // sia al boot che a meta' sessione (main.js lo chiama ad ogni tick, auto-guardato qui sotto).
    var oggi = PETQ.clock.giornoCorrente(state);
    // Salvataggi vecchi avevano lastLoginDay = stringa data: se non e' un numero lo trattiamo come
    // oggi-1 cosi' NON scatta un login spurio a raffica al primo boot post-update (le migrazioni lo
    // portano gia' a un intero, questa e' una cintura di sicurezza in piu').
    var precedente = (typeof state.lastLoginDay === 'number') ? state.lastLoginDay : (oggi - 1);
    if (oggi <= precedente) return 0;
    var delta = oggi - precedente; // >=1: quanti giorni di gioco sono passati in un colpo

    var bil = bilanciamento();
    var bonus = (bil.economia && typeof bil.economia.login === 'number') ? bil.economia.login : 10;

    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo B, "login=monete+10", Cuore Magnetico): extra
    // fisso sul login giornaliero, sommato al bonus base PRIMA di scrivere state.coins cosi'
    // risulta in un unico incremento (nessun bisogno di tracciarlo separato per la UI, che
    // legge solo il totale ritornato da questa funzione).
    var extraLogin = (PETQ.talenti && PETQ.talenti.loginBonusMonete) ? PETQ.talenti.loginBonusMonete(state) : 0;
    bonus += extraLogin;

    state.coins = (state.coins || 0) + bonus;
    state.lastLoginDay = oggi;

    // Streak: qui si contabilizza il giorno PASSATO. Se ieri non c'e' stata nessuna cura, si
    // spende una batteria o si retrocede al traguardo precedente (mai azzeramento secco).
    // Sta dentro dailyLogin perche' e' gia' auto-guardato (scatta una volta per giorno di gioco)
    // e perche' passa di qui anche il bottone debug "Nuovo giorno".
    if (window.PETQ.streak && PETQ.streak.aggiornaAlNuovoGiorno) {
      PETQ.streak.aggiornaAlNuovoGiorno(state);
    }

    // nuovo giorno: pasti di oggi diventano pasti di ieri, si azzera il contatore giornaliero
    if (state.pet) {
      state.pet.pastiIeri = state.pet.pastiOggi || [];
      state.pet.pastiOggi = [];

      // Evoluzione baby->teen (PROTOTIPO-2.md punto 1): giorniVita avanza qui, ad ogni "nuovo
      // giorno" di gioco (sia il login reale che il debug "Nuovo giorno" passano da qui, v.
      // ui.js). Il cambio di stadio effettivo lo decide pet.controllaEvoluzione (chiamata dal
      // tick/boot in ui.js, stesso pattern di controllaSveglia/controllaCrolloAutomatico) cosi'
      // la UI puo' intercettarlo e mostrare la schermata dedicata invece di farlo scattare
      // silenziosamente qui dentro dailyLogin.
      if (typeof state.pet.giorniVita !== 'number') state.pet.giorniVita = 0;
      // Avanza del DELTA (non +1): se l'orologio salta piu' giorni in un colpo (gap offline
      // lungo / debug ×600) il pet invecchia del numero giusto di giorni. Gli ALTRI effetti
      // del nuovo giorno (bonus monete, guarigione, reset contatori, valigia) restano UNA
      // volta sola per chiamata (non moltiplicati per delta): e' un "nuovo giorno" solo.
      state.pet.giorniVita += delta;

      // Ciccione REVERSIBILE (fix bug): sovralimentazioniRecenti veniva solo incrementato (feed) e
      // MAI fatto calare -> una volta ciccione per sovralimentazione il pet restava ciccione PER
      // SEMPRE, nonostante il nome "recenti". Ora cala di 1 per ogni giorno di gioco passato (clamp
      // a 0): qualche giorno di alimentazione corretta riporta il pet in forma. Coerente col
      // decadimento giornaliero degli altri contatori (pasti/dolci) e col design "deterrente
      // reversibile" del ciccione (GDD/bilanciamento). Ritmo −1/giorno deciso col fondatore.
      if (typeof state.pet.sovralimentazioniRecenti === 'number') {
        state.pet.sovralimentazioniRecenti = Math.max(0, state.pet.sovralimentazioniRecenti - delta);
      }
    }

    // nuovo giorno: azzera i contatori giornalieri del pacing cibo/cure, guarigione naturale ferite
    state.categoriePastiOggi = [];
    state.pastiStatOggi = 0; // contatore dei 3 pasti-con-stat/giorno (v. feed; ciclo 14gg, 10 lug)
    state.cureOggi = 0;
    // Coccole (segnalazione fondatore, test 7 lug 2026: "il limite sembra non resettarsi a
    // mezzanotte"): il reset lazy per confronto in care.coccola (coccoleDay !== oggi) e'
    // verificato funzionante, ma lo azzeriamo ANCHE qui esplicitamente col nuovo giorno,
    // come gli altri contatori giornalieri — nessun percorso puo' piu' lasciarlo appeso.
    state.coccoleDay = null;
    state.coccoleCount = 0;

    // Giocattoli (fase 2 del batch giocattoli): azzera gli usi giornalieri del menu "Usa un
    // giocattolo" (la barra nascosta del Cubbolo NON si azzera: e' progressione, non un limite
    // giornaliero). Il modulo ha anche un reset pigro per confronto giorno, come le coccole:
    // questo e' il reset esplicito del nuovo giorno.
    if (PETQ.giocattoli && PETQ.giocattoli.resetGiorno) {
      PETQ.giocattoli.resetGiorno(state);
    }

    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo D, "furto=1/giorno", Cleptomane/Boss di Quartiere):
    // il furto giornaliero e' gia' gestito per confronto (state.furtoDay !== oggi in ui.js), ma
    // azzeriamo qui per pulizia (coerente con gli altri contatori giornalieri). L'invenzione
    // settimanale usa invece pet.giorniVita (avanzato sopra), niente reset qui: la finestra di
    // 7 giorni scorre da sola via invenzioneDisponibile.
    state.furtoDay = null;

    // Diario (PROTOTIPO-2.md punto 6): l'esito missione di ieri non conta piu' per la pagina
    // diario di oggi (v. missions.risolvi, che lo riscrive quando si risolve una missione oggi).
    state.esitoMissioneGiorno = null;

    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "notte=ferite=0", Anima Candida): ogni notte
    // azzera del tutto le Ferite, AL POSTO della guarigione naturale -5 (non in aggiunta: il
    // talento e' strettamente migliore, non ha senso sottrarre prima e poi azzerare). Se il
    // talento non e' attivo, comportamento invariato (guarisciGiorno, -5 Ferite).
    var azzeraNotte = (PETQ.talenti && PETQ.talenti.azzeraFeriteNotte) ? PETQ.talenti.azzeraFeriteNotte(state) : false;
    if (azzeraNotte) {
      state.ferite = 0;
    } else if (PETQ.pet && typeof PETQ.pet.guarisciGiorno === 'function') {
      PETQ.pet.guarisciGiorno(state);
    }

    // nuovo giorno: scadono gli arredi temporanei (es. "il topo come allenatore per 7 giorni",
    // M7 Intimidazione) il cui scadenzaMs e' superato
    if (PETQ.arredi && typeof PETQ.arredi.scadiTemporanei === 'function') {
      PETQ.arredi.scadiTemporanei(state);
    }

    // CASA ACCOGLIENTE (fase giocattoli): la "+N Felicita passiva" scritta su 29 arredi era un
    // bonus FANTASMA (nessun modulo la leggeva). Ora al nuovo giorno il pet incassa in un colpo
    // la somma della Felicita passiva degli arredi PIAZZATI, con tetto 10 (v. arredi.felicitaPassivaCasa).
    // DOPO scadiTemporanei, cosi' un arredo scaduto stanotte non paga piu'. dailyLogin ritorna gia'
    // le monete e non c'e' spazio per un secondo valore di ritorno: la quantita' finisce in
    // state.loginFelicitaCasa, che la UI legge e consuma per scriverla nel messaggio del login
    // (stesso pattern di state.montaggioEvento/state.eventoValigia qui sotto).
    state.loginFelicitaCasa = 0;
    if (state.pet && state.pet.stats && PETQ.arredi && typeof PETQ.arredi.felicitaPassivaCasa === 'function') {
      var felCasa = PETQ.arredi.felicitaPassivaCasa(state);
      if (felCasa > 0) {
        state.pet.stats.felicita = clamp((state.pet.stats.felicita || 0) + felCasa, 0, 100);
        state.loginFelicitaCasa = felCasa;
      }
    }

    // Companion del Supporter Pack (v. applicaEffettiCompanion sopra): raccolti in
    // state.companionEffettiGiorno perche' dailyLogin ritorna gia' solo il bonus monete del login
    // e non c'e' spazio per un secondo valore di ritorno — stesso schema di
    // state.loginFelicitaCasa/state.montaggioEvento qui sopra/sotto: la UI li legge e consuma UNA
    // VOLTA (v. ui.js controllaCompanionEffettiLogin). null (non []) quando non scatta niente,
    // stesso stile di state.eventoValigia.
    var effettiCompanionOggi = applicaEffettiCompanion(state);
    state.companionEffettiGiorno = (effettiCompanionOggi.length > 0) ? effettiCompanionOggi : null;

    // Turno di lavoro notturno (v. risolviTurnoLavoroNotturno sopra, DESIGN-DILEMMI-LAVORI.md §7):
    // si risolve QUI, al cambio giorno, cosi' il giocatore lo trova gia' pagato al risveglio.
    risolviTurnoLavoroNotturno(state, oggi);

    // Talenti (P3 BATCH 4, "montaggio=1/settimana (tutte+2)", Montaggio alla Rocky): 1 volta a
    // settimana, automatico al login/nuovo giorno, +2 a TUTTE le stat RPG in un colpo. Trigger:
    // giorniVita (gia' avanzato sopra) multiplo di 7 e diverso da 0 (il giorno 0 e' la nascita,
    // non un "settimo giorno"), non gia' fatto QUEL giorno (state.montaggioGiorno, stesso
    // pattern di state.crolloGiorno/state.trainDay: confronto per valore, non booleano secco,
    // cosi' "Nuovo giorno" ripetuto non lo rifà ne' lo salta per sbaglio). Se dailyLogin avanza
    // di piu' giorni in un colpo (gap offline / debug ×600), scatta al piu' UNA volta per
    // chiamata, coerente col resto degli effetti "una volta sola per nuovo giorno" qui sopra.
    if (state.pet && PETQ.talenti && PETQ.talenti.haMontaggioRocky && PETQ.talenti.haMontaggioRocky(state)) {
      var giorniVitaMontaggio = (typeof state.pet.giorniVita === 'number') ? state.pet.giorniVita : 0;
      if (giorniVitaMontaggio > 0 && giorniVitaMontaggio % 7 === 0 && state.montaggioGiorno !== giorniVitaMontaggio) {
        state.montaggioGiorno = giorniVitaMontaggio;
        if (state.pet.rpg) {
          // Tetto per stadio: passa dal cancello unico PETQ.pet.aggiungiStat, come tutti gli
          // altri punti che alzano pet.rpg — ognuna delle 4 stat e' una chiamata a se',
          // ognuna eventualmente al tetto da' la sua consolazione Felicita' (v. pet.js).
          PETQ.pet.aggiungiStat(state.pet, 'forza', 2);
          PETQ.pet.aggiungiStat(state.pet, 'intelligenza', 2);
          PETQ.pet.aggiungiStat(state.pet, 'velocita', 2);
          PETQ.pet.aggiungiStat(state.pet, 'carisma', 2);
        }
        // Segnalato alla UI tramite state.montaggioEvento (letto e consumato da ui.js, stesso
        // pattern di state.eventoValigia sotto): dailyLogin ritorna gia' solo il bonus monete,
        // non c'e' spazio per un secondo valore di ritorno senza rompere i chiamanti esistenti.
        state.montaggioEvento = true;
      }
    }

    // nuovo giorno: la Pianta Esotica (arredo 'stat_random_giornaliera') ri-estrae la stat RPG
    // boostata (forzaReroll=true). Se non e' piazzata, aggiornaPiantaEsotica azzera la stat.
    if (PETQ.arredi && typeof PETQ.arredi.aggiornaPiantaEsotica === 'function') {
      PETQ.arredi.aggiornaPiantaEsotica(state, true);
    }

    // Valigia / partenza (PROTOTIPO 2, Blocco 2): al NUOVO GIORNO valuta i trigger (2 giorni
    // critici consecutivi da teen -> fase valigia), la finestra di rimedio (rimedio -> rientro,
    // ancora critico -> partenza). Valutata QUI, dopo che giorniVita e' avanzato e le stat/ferite
    // del nuovo giorno sono aggiornate (guarigione naturale sopra). L'evento risultante e' messo
    // in state.eventoValigia perche' dailyLogin ritorna gia' le monete (bonus): la UI legge
    // state.eventoValigia dopo il login per mostrare valigetta/rientro/addio (v. ui.js
    // controllaEventoValigia, stesso pattern di esitoMissioneGiorno). null = nessun evento.
    // Nota: NON lo si valuta se il pet e' gia' partito (state.petPartito valorizzato / state.pet
    // assente) — in quel caso dailyLogin ritorna prima (sopra, sui rami state.pet).
    if (PETQ.pet && typeof PETQ.pet.valutaValigiaNuovoGiorno === 'function' && state.pet) {
      state.eventoValigia = PETQ.pet.valutaValigiaNuovoGiorno(state);
    }

    return bonus;
  }

  // Infermeria (bagno): costo 15 monete, -30 Ferite, max 2 cure/giorno. Questi 3 numeri non
  // sono ancora mappati in parseBilanciamento (content.js) percio' per ora sono hardcoded qui
  // con default espliciti; se si vuole renderli configurabili va esteso parseBilanciamento con
  // lo stesso pattern delle altre righe (es. numeroDaEtichetta('infermeria', ...)).
  var CURA_COSTO = 15;
  var CURA_FERITE_RIDOTTE = 30;
  var CURA_MAX_DIE = 2;

  // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "infermeria_costo=-5"/"infermeria_cura=+10",
  // Infermiere Provetto): costo/cura effettivi = base + delta dai talenti (delta gia' col segno
  // giusto, es. -5 sul costo -> 15-5=10; +10 sulla cura -> 30+10=40). Clampati per sicurezza
  // (costo mai negativo, cura mai negativa) anche se nessun talento attuale ci arriva vicino.
  function costoCuraEffettivo(state) {
    var delta = (PETQ.talenti && PETQ.talenti.infermeriaModCosto) ? PETQ.talenti.infermeriaModCosto(state) : 0;
    return Math.max(0, CURA_COSTO + delta);
  }

  function feriteRidotteEffettivo(state) {
    var delta = (PETQ.talenti && PETQ.talenti.infermeriaModCura) ? PETQ.talenti.infermeriaModCura(state) : 0;
    return Math.max(0, CURA_FERITE_RIDOTTE + delta);
  }

  function cura(state) {
    if (!state || !state.pet) return { ok: false, msg: traduci('errore interno') };
    if (typeof state.ferite !== 'number') state.ferite = 0;

    var oggi = PETQ.clock.giornoCorrente(state);
    if (state.cureDay !== oggi) {
      state.cureDay = oggi;
      state.cureOggi = 0;
    }

    if (state.ferite <= 0) {
      return { ok: false, msg: traduci('Sta benone, non serve curarlo.') };
    }
    if ((state.cureOggi || 0) >= CURA_MAX_DIE) {
      return { ok: false, msg: traduci('Cure di oggi esaurite, torna domani.') };
    }
    var costo = costoCuraEffettivo(state);
    if ((state.coins || 0) < costo) {
      return { ok: false, msg: traduci('Monete insufficienti.') };
    }

    var feriteRidotte = feriteRidotteEffettivo(state);
    state.coins -= costo;
    state.ferite = clamp(state.ferite - feriteRidotte, 0, 100);
    state.cureOggi = (state.cureOggi || 0) + 1;
    PETQ.pet.recomputeSalute(state.pet, state);

    return { ok: true, msg: traduci('Cura effettuata: -') + feriteRidotte + traduci(' ferite.') };
  }

  // Streak "Giorni di carica" (Retention 2.0 / A2): un giorno vale solo con un'azione di CURA
  // VERA e RIUSCITA. Avvolgiamo le azioni QUI, in un punto solo, invece di infilare la chiamata
  // dentro feed/wash/coccola: quelle funzioni hanno molti punti di uscita (cibo bloccato dal
  // talento, cap coccole raggiunto, dispensa vuota...) e prima o poi se ne dimenticherebbe uno.
  // Cosi' conta solo cio' che e' andato a buon fine, ed e' impossibile sbagliare un ramo.
  // NB cleanPoop NON e' nell'elenco: pulire e' manutenzione della stanza, non cura del pet, e il
  // doc elenca esplicitamente pasto/lavaggio/coccola/missione avviata.
  function conStreak(fn) {
    return function (state) {
      var r = fn.apply(null, arguments);
      if (r && r.ok && window.PETQ.streak && PETQ.streak.registraAzioneCura) {
        PETQ.streak.registraAzioneCura(state);
      }
      return r;
    };
  }

  window.PETQ.care = {
    feed: conStreak(feed),
    cucinaEServi: cucinaEServi,
    haPerkCuoco: haPerkCuoco,
    cuocoUsatoOggi: cuocoUsatoOggi,
    wash: conStreak(wash),
    cleanPoop: cleanPoop,
    coccola: conStreak(coccola),
    train: train,
    completaAllenamento: completaAllenamento,
    allenamentiFattiOggi: allenamentiFattiOggi,
    studioVeloce: studioVeloce,
    teachWord: teachWord,
    paroleInsegnateOggi: paroleInsegnateOggi,
    dailyLogin: dailyLogin,
    applicaEffettiCompanion: applicaEffettiCompanion,
    _risolviTurnoLavoroNotturno: risolviTurnoLavoroNotturno,
    _classificaMotivoSalto: classificaMotivoSalto,
    cura: cura,
    capCoccoleGiorno: capCoccoleGiorno,
    _consumaDaDispensa: consumaDaDispensa,
    _sogliaSovralimentazione: sogliaSovralimentazione,
    _feriteSovralimentazione: FERITE_SOVRALIMENTAZIONE,
    _durataAllenamentoOre: DURATA_ALLENAMENTO_ORE,
    _coccolaMaxDieDefault: COCCOLA_MAX_DIE_DEFAULT,
    _curaCostoDefault: CURA_COSTO,
    _curaFeriteRidotteDefault: CURA_FERITE_RIDOTTE,
    _costoCuraEffettivo: costoCuraEffettivo,
    _feriteRidotteEffettivo: feriteRidotteEffettivo
  };

})();
