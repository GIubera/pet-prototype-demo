window.PETQ = window.PETQ || {};

(function () {
  var CAP_ORE = 12;
  // Cap SEPARATO per l'orologio/calendario (fix "lo streak non vede mai un'assenza", fondatore,
  // 3 ago 2026): CAP_ORE sopra resta la protezione "non torni a un pet morto" per il DECADIMENTO
  // delle stat, e va tenuta cosi' com'e'. Ma quello stesso numero, riusato anche per far avanzare
  // state.gameMinutes/giornoGioco (v. avanzaOrologio), tappava un'assenza reale di piu' giorni a
  // MENO di un giorno di gioco: giornoGioco non cambiava mai, quindi streak.js (che retrocede la
  // carica leggendo "e' passato piu' di un giorno da ultimoValido") non vedeva MAI un'assenza e le
  // batterie non si consumavano mai. Per il calendario basta sapere che e' passato PIU' di un
  // giorno, non quanto esattamente: per design un'assenza costa UN passo qualunque sia la sua
  // durata (streak.js chiudiGiorniSaltati). 48h (2 giorni di gioco) e' il cap piu' PICCOLO che fa
  // scattare sempre questo confronto, evitando pero' il disastro opposto: senza cap, un giocatore
  // che torna dopo mesi troverebbe pet.giorniVita balzato avanti di altrettanti giorni (avanza col
  // cambio giorno, v. care.js dailyLogin) — evoluto/invecchiato di colpo.
  var CAP_ORE_CALENDARIO = 48;
  var TICK_MS = 30000;
  var MINUTI_GIORNO = 1440;

  function isNight(date) {
    var h = date.getHours();
    return h >= 23 || h < 8;
  }

  // Somma le ore reali tra fromMs e toMs, cappate a CAP_ORE (12h: per quanto a lungo
  // resti via, non torni mai a un pet morto). FIX "il tempo non passa" (fondatore, 3a
  // segnalazione, 16 lug 2026): la vecchia esclusione delle ore notturne REALI (23:00-07:59
  // dell'orologio del telefono) congelava il gioco per chi gioca di sera — e faceva a pugni
  // con l'orologio DI GIOCO mostrato nell'HUD (che magari segna le 16:30 mentre la notte
  // reale blocca tutto: sembrava un bug, ed era impossibile da diagnosticare per il giocatore).
  // La protezione "di notte il pet non muore" resta comunque: mentre il pet dorme IN GIOCO
  // (state.sonno, crollo alle 23 di gioco / sveglia dopo 8h) applyDecay mette TUTTE le stat
  // in pausa (v. pet.js) — e' la protezione giusta, sull'orologio giusto.
  function elapsedGameHours(fromMs, toMs) {
    if (!(toMs > fromMs)) return 0;
    return Math.min((toMs - fromMs) / 3600000, CAP_ORE);
  }

  // Ore REALI trascorse fra fromMs e toMs per l'orologio/calendario (state.gameMinutes /
  // state.giornoGioco), cappate a CAP_ORE_CALENDARIO invece che a CAP_ORE — v. commento sulla
  // costante sopra per il motivo. USARE SOLO per PETQ.clock.avanzaOrologio (o per chi decide se
  // chiamarlo); il decadimento delle stat resta SEMPRE su elapsedGameHours, invariata.
  function elapsedCalendarHours(fromMs, toMs) {
    if (!(toMs > fromMs)) return 0;
    return Math.min((toMs - fromMs) / 3600000, CAP_ORE_CALENDARIO);
  }

  // RIALLINEAMENTO ALL'ORA REALE (fix "l'orario e' sempre in desync", fondatore 4 ago 2026).
  // I fix v250-v258 hanno fermato le PERDITE di tempo (casa vuota, cap doppi), ma il ritardo GIA'
  // accumulato nei salvataggi vecchi non si ripara da solo: le ore perse sotto le build precedenti
  // restano perse per sempre, e l'orologio di gioco resta indietro rispetto all'ora vera — il
  // giocatore lo vive come "il tempo si e' fermato quando ho ritirato il pet". Una partita NUOVA
  // parte dall'ora reale (v. inizializzaOrologio): questo rimette in pari anche quelle vecchie.
  // TRE REGOLE, tutte deliberate:
  //  - SOLO IN AVANTI: mai portare l'orologio indietro (un orologio che torna indietro riapre i
  //    gate giornalieri gia' consumati e confonde piu' del ritardo).
  //  - MAI ATTRAVERSARE LA MEZZANOTTE: si tocca SOLO gameMinutes, mai giornoGioco — ai giorni sono
  //    appesi TUTTI i cancelli giornalieri, e un +1 regalato qui farebbe scattare login/eta'/turni.
  //    Se per allinearsi servirebbe passare da mezzanotte (gioco 23:xx, reale 00:xx), si salta il
  //    giro: ci pensera' il flusso normale.
  //  - SOGLIA 30 MINUTI: sotto, non vale il salto (il tick recupera da solo i minuti spiccioli).
  // Nessun decadimento applicato: le ore saltate qui appartengono al PASSATO, quando l'orologio
  // era congelato — le stat di allora sono gia' state gestite dal cap 12h. Punire il pet adesso
  // per un difetto dell'orologio di ieri sarebbe il torto peggiore.
  var RIALLINEO_SOGLIA_MIN = 30;
  function riallineaOraReale(state) {
    if (!state || typeof state.gameMinutes !== 'number' || isNaN(state.gameMinutes)) return 0;
    var d = new Date();
    var reale = d.getHours() * 60 + d.getMinutes();
    var diff = reale - state.gameMinutes;
    if (diff < RIALLINEO_SOGLIA_MIN) return 0;   // indietro o quasi pari: non si tocca
    state.gameMinutes = reale;
    return diff;
  }

  function startTicking(cb) {
    return setInterval(function () {
      var moltiplicatore = window.PETQ.debugTime || 1;
      var oreBase = TICK_MS / 3600000;
      cb(oreBase * moltiplicatore);
    }, TICK_MS);
  }

  // ==================== Orologio di gioco (fix "sonno + orologio") ====================
  // Problema che questo modulo risolve: "notte"/"ora del letto"/"crollo" usavano finora
  // new Date().getHours() = ora REALE del PC. Il moltiplicatore debug (PETQ.debugTime)
  // accelera solo il decadimento delle stat (gameHours), MAI l'ora reale: a ×600 le stat
  // calano ma l'orologio reale non si sposta, quindi non si arriva mai alle 21/23 e il
  // sonno resta intestabile. state.gameMinutes (0-1439, 00:00-23:59) e' l'orologio DI GIOCO:
  // avanza con lo STESSO delta di gameHours gia' passato a applyDecay ad ogni tick/decay
  // offline, cosi' il debug ×60/×600 accelera anche l'orologio. Wrap a 1440 = nuovo giorno.
  //
  // Migrazione salvataggi: se manca, si inizializza dall'ora reale corrente (continuita'
  // per le partite gia' in corso, che altrimenti si risveglierebbero a mezzanotte in game).

  // Avanza l'orologio di gioco di deltaOreGioco (stesso numero usato per il decadimento
  // stat) e fa scattare eventuali "nuovo giorno" per ogni wrap a 1440 attraversato.
  // Ritorna il numero di giorni-di-gioco avanzati in questa chiamata (di solito 0 o 1,
  // ma con salti grossi di tempo offline o debug ×600 potrebbe essere >1).
  function avanzaOrologio(state, deltaOreGioco) {
    if (!state || !(deltaOreGioco > 0)) return 0;
    if (typeof state.gameMinutes !== 'number' || isNaN(state.gameMinutes)) {
      inizializzaOrologio(state);
    }
    var minutiTotali = state.gameMinutes + deltaOreGioco * 60;
    var giorniAvanzati = Math.floor(minutiTotali / MINUTI_GIORNO);
    state.gameMinutes = ((minutiTotali % MINUTI_GIORNO) + MINUTI_GIORNO) % MINUTI_GIORNO;
    // Contatore canonico del "giorno di gioco" (fix "nuovo giorno a mezzanotte di gioco"):
    // ogni mezzanotte DELL'OROLOGIO DI GIOCO attraversata da questo avanzamento fa +1 su
    // state.giornoGioco. E' l'UNICA fonte di verita' del "giorno di oggi" (intero) per tutti
    // i gate giornalieri (dailyLogin, allenamento, cure, parole, coccole, furto, missioni),
    // al posto della data REALE del PC (oggiStr()/new Date()). Cosi' a velocita' debug ×600
    // il nuovo giorno scatta davvero quando l'HUD passa le 00:00, non alla mezzanotte reale.
    if (giorniAvanzati > 0) {
      state.giornoGioco = (typeof state.giornoGioco === 'number' ? state.giornoGioco : 0) + giorniAvanzati;
    }
    return giorniAvanzati;
  }

  // Giorno di gioco corrente (intero, 0-based): il "giorno di oggi" canonico usato da tutti i
  // gate giornalieri. Mantenuto da avanzaOrologio ad ogni mezzanotte di gioco attraversata.
  function giornoCorrente(state) {
    return (state && typeof state.giornoGioco === 'number') ? state.giornoGioco : 0;
  }

  // Migrazione: inizializza gameMinutes dall'ora REALE corrente, per continuita' dei
  // salvataggi pre-esistenti (cosi' chi gioca oggi pomeriggio non si ritrova a mezzanotte).
  function inizializzaOrologio(state) {
    if (!state) return;
    var ora = new Date();
    state.gameMinutes = ora.getHours() * 60 + ora.getMinutes();
  }

  // {ore, minuti, hhmm:'HH:MM'} dall'orologio di gioco corrente
  function oraGioco(state) {
    var gm = (state && typeof state.gameMinutes === 'number') ? state.gameMinutes : 0;
    gm = ((gm % MINUTI_GIORNO) + MINUTI_GIORNO) % MINUTI_GIORNO;
    var ore = Math.floor(gm / 60);
    var minuti = Math.floor(gm % 60);
    var pad2 = function (n) { return (n < 10 ? '0' : '') + n; };
    return { ore: ore, minuti: minuti, hhmm: pad2(ore) + ':' + pad2(minuti) };
  }

  // notte sull'orologio DI GIOCO (GDD/bilanciamento: 21:00-07:59, non 23:00 come la notte
  // "reale" di isNight sopra - qui la soglia e' quella di "ora del letto")
  function eNotteGioco(state, oraLettoH, oraFineNotteH) {
    var oraLetto = (typeof oraLettoH === 'number') ? oraLettoH : 21;
    var oraFine = (typeof oraFineNotteH === 'number') ? oraFineNotteH : 8;
    var og = oraGioco(state);
    return og.ore >= oraLetto || og.ore < oraFine;
  }

  window.PETQ.clock = {
    isNight: isNight,
    elapsedGameHours: elapsedGameHours,
    elapsedCalendarHours: elapsedCalendarHours,
    riallineaOraReale: riallineaOraReale,
    startTicking: startTicking,
    avanzaOrologio: avanzaOrologio,
    giornoCorrente: giornoCorrente,
    inizializzaOrologio: inizializzaOrologio,
    oraGioco: oraGioco,
    eNotteGioco: eNotteGioco,
    _MINUTI_GIORNO: MINUTI_GIORNO
  };
})();
