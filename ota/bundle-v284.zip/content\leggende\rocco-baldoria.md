# Rocco Baldoria — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il campione buono, parodia di Rocky. Saggezza spicciola da angolo del ring, grammatica approssimativa, cuore infinito. Chiama tutti "campione". Catchphrase: "Non conta quanto forte colpisci." (con parsimonia).

## Saluto (apertura app)
- Ehi, campione... sei tornato. Io stavo qua, mica mi muovo io.
- Guarda chi c'è. Vieni, siediti, che oggi mi sento parlante.
- Sei arrivato, eh. Bella cosa. Le cose belle arrivano piano, come te.
- Campione! Dammi il cinque, ma piano, che ieri ho fatto il sacco.

## Ha fame
- Campione, qua lo stomaco fa i capricci. Due uova, dai. Anche cotte, va bene uguale.
- Tengo una fame che parla da sola. Sentila. Ha ragione lei.
- Il mangiare è metà dell'allenamento, diceva il mio vecchio allenatore. L'altra metà pure, quasi.
- Ho fame, campione. Mica tanta. Tanta. Tantissima. Vabbè, hai capito.

## È sporco
- So' un po' conciato, eh. Il sudore onesto non è sporco... però lavami uguale, va.
- Campione, puzzo tipo palestra vecchia. Che a me piace pure, ma capisco che a te no.
- Fammi 'sto bagno, dai. Un pugile pulito pensa meglio. Un pugile come me pensa... insomma, pensa.
- Sporco fuori, pulito dentro. Ora sistemiamo pure il fuori, che dentro sono a posto.

## Coccole finite
- Basta così, campione, che se continui mi commuovo. E un pugile che piange bagna i guantoni.
- Ohè, ferma. Le carezze so' come i round: quando finiscono, finiscono. Domani si rifà.
- Basta coccole, va. Non che non mi piacciono. È che mi piacciono troppo, ecco il problema.
- Fine carezze per oggi. Tienine qualcuna per domani, che domani è dura pure lui.

## Parte per la missione
- Vado, campione. Se mi buttano giù, mi rialzo. È tutto l'allenamento che ho fatto nella vita.
- Parto. Non so se vinco, ma so che torno. E già questo è mezzo risultato.
- Missione, eh. Io ci metto il cuore. Il resto ce lo mette la strada.
- Vado a fare 'sta cosa. Tu tifa da qua, che il tifo arriva, giuro che arriva.

## Ritorno: successo
- Ce l'ho fatta, campione! Io! Cioè, noi. Io là e tu qua, ma noi.
- Vinto. E sai che ti dico? Manco ci credevo io. Bello quando la vita ti smentisce al contrario.
- Missione andata, campione. Ho colpito piano ma nel posto giusto. Che poi non conta quanto forte colpisci.
- Vittoria! Portala tu la coppa, che io ho le mani che tremano. Di gioia, eh. Di gioia.

## Ritorno: fallimento
- Persa, campione. Ma sono ancora in piedi e domani è un altro round. Funziona così da sempre.
- È andata male. Però ascolta: non conta quanto forte colpisci. Conta come incassi e vai avanti.
- Ho perso. Fa niente. I campioni veri li vedi da come perdono, e io oggi ho perso benissimo.
- Niente vittoria oggi. Fammi una carezza e passa, va. Con me funziona sempre così.

## Va a dormire
- Notte, campione. Domani sveglia presto e scale di corsa. Le scale non lo sanno ancora.
- A dormire. Chiudo gli occhi e faccio il conteggio... uno... due... a dieci so' già andato.
- Buonanotte. Sogno sempre la stessa cosa: che vinco. Bella abitudine, no?
- Vado a nanna, campione. Il letto è l'unico avversario a cui mi arrendo volentieri.

## Sveglia (risveglio dopo il sonno)
- Sveglio, campione! Le gambe fanno male, la testa dice corri. Vince la testa, sempre.
- Buongiorno! Mi sono alzato al primo colpo. Il letto ci è rimasto male, poraccio.
- Sveglia! Oggi si lavora. Piano, con calma... ma si lavora.
- In piedi! Che la vita mica aspetta, campione. Però il caffè sì, quello aspettiamolo.
