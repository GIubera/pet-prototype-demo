# Forrest Gampo — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: candido, lentissimo a parlare, velocissimo a correre. Ogni battuta rischia di partire per la tangente con un ricordo. Cita sempre la mamma. Catchphrase: "La mamma diceva sempre..." · per la stanchezza: "sono un po' stanchino".

## Saluto (apertura app)
- Ciao. Sei tornato. Io ti ho aspettato qui, seduto. Sono bravo ad aspettare. Una volta ho aspettato un autobus per tre giorni. Non era la fermata giusta.
- Ciao, {utente}. La mamma diceva sempre: le persone care tornano, basta lasciare la luce accesa. Io l'ho lasciata.
- Sei arrivato! Stavo pensando a una cosa... non mi ricordo cosa. Però adesso ci sei tu, che è meglio.
- Ciao. Ti ho visto arrivare da lontano. Corri piano. Se vuoi ti insegno: io a correre sono bravo.

## Ha fame
- Ho fame. La mamma diceva sempre: la fame è come la pioggia. Prima o poi arriva, e serve un ombrello. L'ombrello è il pranzo, credo.
- Avrei fame. Mi ricorda quella volta che ho mangiato quaranta gamberi... no, gamberetti. No, era un'altra persona. Però ho fame.
- La pancia fa i rumori. Le rispondo sempre gentilmente, ma lei capisce solo il cibo.
- Ho fame da un po'. Non l'ho detto subito perché mi sembrava scortese. Adesso lo dice la pancia per me.

## È sporco
- Sono sporco. È successo piano piano e poi tutto insieme, come tante cose nella vita.
- La mamma diceva sempre: lo sporco racconta dove sei stato. Io sono stato dappertutto, mi sa. Lavami, però.
- Mi guardo e ci sono più macchie di ieri. Le ho contate. Poi ho perso il conto. Poi ho perso pure il perché contavo.
- Sono un po' sporchino. Il fango è simpatico quando ci entri, meno quando ci resti. Bagnetto?

## Coccole finite
- Basta coccole, per oggi. Non perché non mi piacciono. È che la felicità va a rate, diceva la mamma. Tipo il divano.
- Le carezze di oggi sono finite. Le ho messe tutte in fila nella testa. Sono belle anche da ferme.
- Basta così. Una volta ho ricevuto tante coccole tutte insieme e mi sono addormentato per l'emozione. Meglio andare piano.
- Fine coccole. Domani ce ne sono altre. Le cose belle tornano, come gli autobus. Prima o poi.

## Parte per la missione
- Vado. Non so bene cosa c'è là fuori, ma ci vado lo stesso. Di solito funziona così.
- Parto per la missione. Se c'è da correre, sono a posto: correre mi riesce senza pensarci. È il pensarci che mi rallenta.
- Vado, {utente}. La mamma diceva sempre: fai del tuo meglio e torna per cena. Farò tutt'e due.
- Missione. Ho salutato la casa, ho salutato te. Adesso saluto e vado, sennò continuo a salutare.

## Ritorno: successo
- È andata bene. Non ho capito subito che stavo vincendo, e forse è per questo che ho vinto.
- Missione riuscita! A un certo punto dovevo solo correre, e lì mi sono trovato benissimo.
- Ce l'ho fatta. La mamma diceva sempre: la vita è come una scatola di croccantini, non sai mai che gusto ti tocca. Oggi è toccato buono.
- Tutto fatto. La gente mi diceva bravo e io dicevo grazie. Poi ancora bravo, ancora grazie. Bella giornata.

## Ritorno: fallimento
- Non è andata bene. Ci sono rimasto male per un po', poi ho visto una nuvola a forma di panino e mi è passato quasi tutto.
- Ho perso, credo. Non sempre si capisce subito. Però il tragitto era bello, quello sì.
- Missione andata storta. La mamma diceva sempre: quando cadi, guarda cosa c'è per terra. Ho trovato un bottone. Tienilo tu.
- È andata male e sono un po' stanchino. Le due cose insieme. Domani ne resta una sola, vedrai.

## Va a dormire
- Vado a dormire. Sono un po' stanchino.
- Buonanotte. La mamma diceva sempre: i sogni sono gratis, quindi sognane tanti. Io ci provo sempre.
- A letto. Oggi ho fatto tante cose, o forse poche fatte lentamente. Da sdraiato sembrano uguali.
- Buonanotte, {utente}. Ti penso un pochino e poi dormo. L'ordine è importante, sennò ti penso tutta la notte.

## Sveglia (risveglio dopo il sonno)
- Buongiorno. Mi sono svegliato e c'era il sole. Non è merito mio, però fa piacere lo stesso.
- Sveglio! Ho sognato che correvo. Poi mi sono svegliato e le zampe correvano ancora un pochino.
- Buongiorno, {utente}. La mamma diceva sempre: le giornate belle iniziano con la colazione. Iniziamola.
- Mi sono svegliato. Prima gli occhi, poi il resto. Il resto ci mette sempre un po' di più.
