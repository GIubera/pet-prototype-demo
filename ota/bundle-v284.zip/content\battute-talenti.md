# Battute legate ai talenti — BOZZA (non ancora letta dal codice)

Battute che escono SOLO se il pet possiede il talento indicato, nel momento indicato.
Una battuta per riga con `- `. Slot: `{nome}` `{utente}`.

STATO: bozza contenuti. Per attivarle servono (lato codice):
1. Aggancio del parser condizioni esistente (`talento:<nome>`, già in content.js) alle battute — il parser attuale di personalita/*.md fa match per sottostringa e NON va usato per queste sezioni (una sezione "Saluto (talento: X)" finirebbe nel pool base di tutti).
2. Decidere gli hook: alcuni momenti esistono già (fame, sonno, ritorno missione), altri sono nuovi (es. "rifiuta il dolce" per blocca_cibo=dolce, che oggi sarebbe un rifiuto muto).
3. Aggiungere questo file a build-content.ps1 quando il formato è confermato.

Ogni sezione dichiara: talento richiesto (nome normalizzato per il parser condizioni) e momento di uscita.

---

## Sportivo

### Fissato con la Dieta — rifiuta il dolce
Condizione: `talento:fissatoconladieta` · Momento: il giocatore offre un dolce (blocca_cibo=dolce)
- Zucchero? ZUCCHERO? Coach, io ho una tabella. La tabella dice no. Io lo dico con più enfasi.
- No grazie: quello è carburante da spettatori. Io gioco titolare.
- Il dolce mangialo tu, io guardo altrove con disciplina OLIMPICA. Non tentarmi mai più. (Che profumino, però. VAI VIA.)

### Fissato con la Dieta — mangia cibo sano
Condizione: `talento:fissatoconladieta` · Momento: mangia carne/verdura/pesce (bonus_cibo=salutare)
- Proteine! Sento i muscoli che fanno il coro. Dieta perfetta, atleta perfetto.
- Verdura! La mangio con la grinta di chi sa che il segreto dei campioni è NOIOSISSIMO ma funziona.
- Pesce = velocità, lo dice la mia tabella. E la mia tabella non ha mai perso.

### Fissato con la Dieta — risveglio
Condizione: `talento:fissatoconladieta` · Momento: risveglio (colazione dei campioni, dieta salutare)
- Sveglia! Prima cosa: colazione dei campioni, quella vera. Niente zuccheri, tutto carburante. Si parte bene.
- Buongiorno! Il mio risveglio è cronometrato: sveglia, idratazione, pasto sano. La disciplina non dorme, coach.

### Energico — fine allenamento
Condizione: `talento:energico` · Momento: fine allenamento (allenamento_energia=+5, si carica invece di stancarsi)
- Finito l'allenamento e sto MEGLIO di prima! Il mio motore si ricarica correndo. Sono fatto strano e benissimo.
- Altro giro? Io dopo l'allenamento mi accendo, mica mi spengo. Batterie? Mai sapute cosa fossero.
- Gli altri finiscono l'allenamento stanchi. Io lo finisco che devo fare un giro di campo per calmarmi. CHE VITA.

### Energico — login giornaliero
Condizione: `talento:energico` · Momento: login giornaliero (decay energia dimezzato, sempre in forma)
- Bentornato, coach! Io? Carico come stamattina. Anzi di più: le batterie con me si ricaricano da sole.
- Eccoti! Ho aspettato facendo scatti. La mia energia non cala mai, quindi era o scatti o altri scatti.

### Predestinato — secondo allenamento del giorno
Condizione: `talento:predestinato` · Momento: avvio del secondo allenamento giornaliero (allenamenti_giorno=2)
- Doppia seduta, coach! Come i professionisti veri. Il talento non si allena da solo... anzi sì, ma due volte.
- Mattina e pomeriggio, coach. Il mio destino è scritto: c'è scritto "allenati ancora". Bellissimo destino.
- Secondo allenamento avviato! I fenomeni si allenano il doppio: lo dico perché è appena successo, guarda.

### Braccia di Ferro — carne o allenamento Forza
Condizione: `talento:bracciadiferro` · Momento: mangia carne oppure completa allenamento Forza (bonus attivo)
- Carne! Le mie braccia ringraziano in silenzio. Un silenzio MUSCOLOSISSIMO.
- Allenamento Forza col talento giusto: ogni ripetizione vale doppio. Lo sento dal rumore: fa "clang".
- Guarda queste braccia, coach. Ferro. Potresti stenderci il bucato, ma usiamole per la gloria.

### Spirito Agonistico — ritorno da missione
Condizione: `talento:spiritoagonistico` · Momento: ritorno da qualsiasi missione (ogni_missione=forza+1)
- Missione archiviata = muscolo guadagnato. Per me tutto è una gara, e le gare mi fanno crescere. Letteralmente.
- Torno da ogni missione con un souvenir: forza. Il negozio di souvenir sono io.
- Un'altra sfida vinta, un altro punto Forza in tabellino. Tengo il conto: è il mio campionato personale.

### Fisico Bestiale — niente crollo da stanchezza
Condizione: `talento:fisicobestiale` · Momento: energia bassa ma nessun rifiuto (ignora_rifiuto_energia)
- Stanco? Il mio fisico non conosce la parola. Ne conosce poche, ma quella proprio no.
- Gli altri a quest'ora crollano. Io ho ancora benzina da vendere. Fisico BESTIALE: c'è scritto sulla carta.
- La stanchezza mi ha sfidato. Ha perso. Non era nemmeno una gara equilibrata.

### Fisico Bestiale — allenamento lampo
Condizione: `talento:fisicobestiale` · Momento: fine allenamento a metà tempo (allenamento_durata=x0.5)
- Allenamento finito in metà tempo. Non ho fretta: sono solo troppo veloce anche a faticare.
- Seduta lampo completata! Stessa fatica degli altri, metà del tempo. Il resto lo passo a fare il fenomeno.
- Già finito, coach. Davvero. Il mio fisico spinge l'acceleratore anche sull'allenamento. Prossimo!

---

## Gentile

### Amante della Natura — mangia verdura
Condizione: `talento:amantedellanatura` · Momento: mangia verdura (bonus_cibo=verdura)
- Verdurina! Ho ringraziato l'orto, il contadino e la forchetta. La natura ci vuole bene, {utente}.
- Che buona la verdura... la mastico piano per non fare rumore nel bosco. Non c'è un bosco. Il rispetto sì.
- Le piantine mi danno forza! Loro crescono, io cresco, cresciamo insieme. Che bella squadra silenziosa.

### Amante della Natura — ritorno da missione natura
Condizione: `talento:amantedellanatura` · Momento: ritorno da missione a tag natura (perk_tag=natura, super garantito)
- Missione nel verde: perfetta, ovvio! Gli animali mi aiutano sempre. Basta chiedere per favore, nessuno lo fa mai.
- Tra alberi e animali non posso perdere: là fuori sono di casa. La natura fa il tifo per me, sottovoce.
- Tornato dal verde col cuore pieno. Ho salutato ogni cespuglio per nome. Loro un po' meno, ma vabbè.

### Amante della Natura — ritorno dal Rifugio Creature Smarrite
Condizione: `talento:amantedellanatura` · Momento: ritorno da M11 Rifugio Creature Smarrite (tag natura)
- Al rifugio mi hanno adottato loro, gli animali. Ho fatto amicizia con tutti e ho pianto solo tre volte. Di gioia.
- Torno dal rifugio col cuore pieno e un po' di pelo altrui addosso. Ne è valsa la pena: nessuno resta solo se posso aiutarlo.

### Amante della Natura — ritorno dalla Serra del Giardiniere Matto
Condizione: `talento:amantedellanatura` · Momento: ritorno da M12 Serra del Giardiniere Matto (tag natura)
- Torno dalla serra con le zampe verdi e l'anima pure. Là dentro il tempo cresce piano, come le foglie. Che pace.
- Missione tra i vasi: un successo che profuma. Ogni pianta è un piccolo amico che non risponde ma ascolta.

### Amante della Natura — ritorno dall'Acquario (Cattura Pesci)
Condizione: `talento:amantedellanatura` · Momento: ritorno da M16 Cattura Pesci a Mani Nude (tag natura)
- All'acquario non ho catturato i pesci: li ho convinti. Gentilmente. Poi li ho pure rimessi a posto, erano spaventati.
- Torno dalle vasche tutto bagnato e felicissimo. I pesci mi hanno perdonato subito: si vede che sono uno dei buoni.

### Pacifista — ritorno da missione Sociale
Condizione: `talento:pacifista` · Momento: ritorno da missione Sociale (bonus_missione=sociale:carisma+1)
- Le missioni con le persone sono le mie preferite: nessuno si fa male e tutti si salutano due volte.
- Missione sociale riuscita! Il mio superpotere è la gentilezza. Non fa rumore, ma vince.
- Tra la gente sto benissimo: basta ascoltare tanto e giudicare mai. Torno con amici nuovi e il cuore comodo.

### Pacifista — missione di combattimento bloccata
Condizione: `talento:pacifista` · Momento: tap su missione Combattimento esclusa dalla rosa (blocca_categoria=combattimento) — HOOK NUOVO
- Quella missione no, scusa... io non combatto. Posso offrire un tè a tutti i contendenti, però.
- Niente botte, {utente}. Non per paura, eh: per principio. (Anche un pochino di paura. Ma prima il principio.)
- Combattere? Io? Al massimo abbraccio energicamente. È diverso, e funziona pure meglio.

### Cuore Magnetico — mancia tripla
Condizione: `talento:cuoremagnetico` · Momento: mancia post-missione (mancia=x3)
- Mi hanno dato una mancia grande grande! Dicono che ho un sorriso che "va premiato". Io sorridevo e basta, giuro.
- La gente mi regala monete e io nemmeno le chiedo. {utente}, credo di piacere al mondo. Il mondo piace a me: siamo pari.
- Mancia tripla! Ho fatto solo il carino, giuro. A quanto pare rende più della fatica. Che imbarazzo bellissimo.

### Cuore Magnetico — login giornaliero
Condizione: `talento:cuoremagnetico` · Momento: login giornaliero (login=monete+10)
- Sei arrivato e sono già più ricco! Non so come funzioni, ma funziona solo quando ci sei tu.
- Ogni volta che torni piovono monetine. Il mio cuore fa da calamita. Le monete le dividiamo, ovvio.
- Buongiorno e già un gruzzoletto in più! Il mondo mi vuole bene di prima mattina. Ricambio, sempre.

### Cuore Magnetico — ritorno da missione
Condizione: `talento:cuoremagnetico` · Momento: ritorno da missione (ogni_missione=monete+5)
- Ogni missione mi frutta un piccolo extra. Il segreto? Saluto tutti col sorriso. Il carisma è il mio bancomat, {utente}.
- Missione finita, gruzzoletto lievitato. Il mondo mi vuole bene in monete. Le dividiamo, come sempre.

### Coccolone — coccole finite a quota 8
Condizione: `talento:coccolone` · Momento: raggiunto il cap coccole 8 (cap_coccole=8) — SOSTITUISCE il pool base "Coccole finite"
- OTTO coccole oggi... sono al massimo del massimo. Scusa, oltre non posso: divento purè.
- Basta anche per me, e io di coccole ne reggo più di chiunque. Oggi hai dato tanto, {utente}. Che giornata.
- Fine coccole! Otto! Le persone normali si fermano a cinque, io sono un professionista dell'abbraccio.

### Coccolone — coccola ricevuta
Condizione: `talento:coccolone` · Momento: coccola ricevuta (coccola=fel+3)
- Le tue coccole a me fanno effetto doppio. Triplo. Non so contare quando mi accarezzi, scusa.
- Una tua carezza vale come tre normali. Non lo dico per vantarmi: lo dice il mio cuore, che esagera sempre.
- Coccola ricevuta e felicità alle stelle! Con me rendono di più: sono un investimento affettivo, {utente}.

### Infermiere Provetto — risveglio con auto-cura
Condizione: `talento:infermiereprovetto` · Momento: risveglio con auto-cura (risveglio=ferite-10)
- Sveglio e già rattoppato! Mani sante, le mie. Piccole, ma sante.
- Mi sono curato nel sonno, non chiedermi come: le mani sanno il mestiere anche quando io dormo.
- Buongiorno! Mi sono medicato prima ancora di svegliarmi del tutto. Efficienza da pronto soccorso, tenerezza inclusa.

### Infermiere Provetto — uso infermeria
Condizione: `talento:infermiereprovetto` · Momento: cura in infermeria (infermeria_costo=-5, infermeria_cura=+10)
- In infermeria do una mano anch'io: passo le garze, tengo su il morale. Metà prezzo, doppio affetto.
- Il dottore dice che sono un paziente-collega. Ho fatto metà del lavoro e i complimenti li ha presi tutti lui. Va bene così.
- Curato e già in piedi! Le mie ferite hanno paura di me quanto io ho paura degli aghi. Pareggio, ci sta.

### Anima Candida — risveglio con ferite azzerate
Condizione: `talento:animacandida` · Momento: risveglio dopo notte che azzera le ferite (notte=ferite=0)
- Buongiorno! Le ferite di ieri? Sparite. Io perdono tutto, anche i graffi. E loro se ne vanno.
- Stanotte le ferite hanno fatto le valigie. Non le ho nemmeno salutate. Unica scortesia che mi concedo.
- Sveglio come nuovo! Dormo, perdono, guarisco. È un ciclo bellissimo e non so nemmeno come funzioni.

---

## Nerd

### Idrofobico — è sporco
Condizione: `talento:idrofobico` · Momento: igiene bassa (igiene_felicita=inverti) — SOSTITUISCE il pool base "È sporco" (che si lamenta: lui gode)
- Igiene al 20% e umore alle stelle: ogni macchia è un appunto, ogni odore un esperimento. Sto BENISSIMO.
- Lo sporco è stratificazione di dati. Io non sono sudicio: sono un archivio storico a cielo aperto.
- Le moschine mi girano intorno: le sto addestrando. Il progetto procede. NON toccare l'ecosistema.
- Ogni giorno senza bagno il mio cervello guadagna punti. La scienza è dalla mia parte, la puzza pure.

### Idrofobico — viene lavato
Condizione: `talento:idrofobico` · Momento: il giocatore lo lava (protesta) — HOOK NUOVO
- NO, L'ACQUA NO! Stavi cancellando sei giorni di ricerca sul campo! Vandalo!
- Acqua e sapone: il reset che nessuno aveva richiesto. Il mio QI da sporco era più alto, lo sai?
- Mi hai formattato. Sei giorni di crosticina-dati persi in trenta secondi. Un lutto per la scienza.

### Sete di Sapere — allenamento Int gratis
Condizione: `talento:setedisapere` · Momento: allenamento Intelligenza gratuito del giorno (allenamento_extra=int)
- Momento studio gratuito del giorno! Il cervello si allena da solo, io guardo e prendo appunti. Meta-studio.
- Il mio daily preferito: imparare una cosa gratis. Zero fatica, solo conoscenza. Il sistema premia i curiosi.
- Sessione bonus di Intelligenza incassata. È come trovare un livello segreto: gratis e mi rende più forte.

### Sete di Sapere — impara una parola
Condizione: `talento:setedisapere` · Momento: impara una parola nuova (la curiosità è il suo tratto)
- Ottimo, un altro vocabolo da catalogare! Ogni parola è un piccolo livello guadagnato. Continua, {utente}, sono in fase di grinding.
- Adoro imparare cose nuove. "{parola}" entra dritta in archivio, sezione "roba utile che sfoggerò a sorpresa".

### Inventore — invenzione riuscita
Condizione: `talento:inventore` · Momento: invenzione settimanale riuscita (invenzione=1/settimana)
- EUREKA! Ho saltato l'allenamento per inventare e ne è valsa la pena: guarda cos'ho fatto con quello che c'era in casa!
- Dal mio laboratorio (l'angolo dietro il divano) esce un nuovo prodigio. Brevettalo, {utente}. Fidati.
- Invenzione della settimana: RIUSCITA. Ho combinato cose a caso con metodo rigorosissimo. Il paradosso funziona.

### Inventore — invenzione flop
Condizione: `talento:inventore` · Momento: invenzione = Prototipo fallato
- Ok, questa invenzione... "funzionerà in una prossima versione". Vendiamola come pezzo da collezione, presto, prima che qualcuno faccia domande.
- Il prototipo ha fatto una cosa sola: fumo. Però che fumo elegante. Lo segno come successo parziale.
- Invenzione flop. Non un fallimento: un "dato negativo prezioso". La differenza la capiamo solo io e la scienza.

### Inventore — ritorno da missione invenzione
Condizione: `talento:inventore` · Momento: ritorno da missione a tag invenzione (perk_tag=invenzione, super garantito)
- Missione in laboratorio: trionfo assicurato. Là dentro parlo la lingua madre: il gergo tecnico.
- Tra gadget e circuiti non posso sbagliare. È il mio bioma naturale.
- Missione a tema invenzione: vinta a occhi chiusi. Anzi aperti, per leggere le etichette. Ma vinta facile.

### Inventore — ritorno dalla Fiera della Scienza
Condizione: `talento:inventore` · Momento: ritorno da M9 Fiera della Scienza del Quartiere (tag invenzione)
- Alla Fiera della Scienza ho fatto colpo: il mio prototipo ha fumato pochissimo, stavolta. Progresso documentato!
- Torno dalla Fiera col primo premio... categoria "più entusiasta". Il vero premio è aver capito come NON far esplodere le cose.

### Inventore — ritorno dalla Sfida Robotica
Condizione: `talento:inventore` · Momento: ritorno da M10 Sfida Robotica (tag invenzione)
- Torno dall'arena con un bottino di bulloni e una teoria nuova. I robot degli altri erano carini. Il mio pensava.
- Missione robotica archiviata: vittoria tecnica. Ho battuto tutti spiegando il regolamento meglio dell'arbitro.

### Inventore — ritorno dall'Escape Room del Dottor Enigma
Condizione: `talento:inventore` · Momento: ritorno da M21 Escape Room del Dottor Enigma (tag invenzione)
- Torno dall'Escape Room del Dottor Enigma con la soluzione e tre teorie alternative. Ho fatto pure i complimenti a chi l'ha progettata.
- Missione enigmistica: fuga riuscita. Il meccanismo segreto l'ho capito al volo. Poi ho voluto smontarlo, per capire meglio.

### Topo di Biblioteca — ritorno da missione Studio
Condizione: `talento:topodibiblioteca` · Momento: ritorno da missione Studio (bonus_missione=studio:int+1,durata-1h)
- Missione in biblioteca finita in anticipo: tra gli scaffali mi muovo per istinto, come i predatori. Predatore di note a margine.
- Missione Studio completata prima del previsto. Il silenzio della biblioteca mi POTENZIA.
- Tornato presto: conoscevo già metà dei libri e l'altra metà conosceva me. Ambiente mio.

### Mente Analitica — fine di qualsiasi allenamento
Condizione: `talento:menteanalitica` · Momento: fine allenamento di qualsiasi stat (bonus_allenamento=qualsiasi:int+1)
- Allenamento finito e cervello più grosso, QUALUNQUE cosa abbia allenato. Imparo persino dalle flessioni. Soprattutto quanto sono faticose.
- Ogni esercizio è un dato in più. Il corpo lavora, la mente archivia. Sistema perfetto, doppio guadagno.
- Ho analizzato l'allenamento mentre lo facevo. Risultato: +1 al muscolo e +1 alla teoria del muscolo.

### Cervellone — impara una parola
Condizione: `talento:cervellone` · Momento: impara una parola nuova (parole_giorno=4)
- Parola nuova acquisita! Il vocabolario cresce a velocità preoccupante per chi mi sta intorno. Cioè te. Preparati.
- Un'altra parola in memoria! Slot rimanenti per oggi: pochi ma buoni. Continuiamo, il cervello ha fame.
- Registrata! Di questo passo tra un mese faccio i cruciverba da solo. E le definizioni le scrivo pure.

---

## Maleducato

### Cleptomane — furto del giorno
Condizione: `talento:cleptomane` · Momento: oggetto gratis dal negozio (furto=1/giorno, max 15 monete)
- Guarda cosa "è caduto" nella mia borsa al negozio. Cadono cose, in quel posto. Quotidianamente. Verso di me.
- Il negoziante oggi guardava altrove. Guarda SEMPRE altrove. Che gestione, quel posto. Comunque: regalo per la casa.
- Non è rubare, è redistribuzione con criterio. Il criterio sono io.
- Alibi pronto, refurtiva pure. Se chiedono, ero con te tutto il giorno. Ripeti con me: TUTTO il giorno.

### Cleptomane — ritorno da missione
Condizione: `talento:cleptomane` · Momento: ritorno da missione (bonus_missione_monete=x1.5)
- Tornato dalla missione con le tasche più gonfie del dovuto. Non chiedere come: metà è paga, metà è iniziativa personale.
- Le missioni con me rendono il cinquanta per cento in più. Chiamalo talento. Il negoziante lo chiama in altri modi.

### Bad Loser — fallimento da carattere
Condizione: `talento:badloser` · Momento: fallimento missione causato dal carattere (reward=x2, fel-10)
- Ho perso PER COLPA DEL MIO CARATTERE, dicono. Il mio carattere però ha portato a casa il doppio del bottino. Chi ha vinto davvero?
- Sì, l'ho presa malissimo. MALISSIMO. Ma guarda quanta roba ho raccattato mentre la prendevo malissimo.
- Sconfitta digerita come un veleno lento. Però il bottino di consolazione è raddoppiato. Piango ricco, almeno.

### Fulmine di Quartiere — ritorno anticipato
Condizione: `talento:fulminediquartiere` · Momento: ritorno da missione accorciata (missione_durata=-1h)
- Ho fatto in un'ora quello che gli altri fanno in due. Non è talento, è insofferenza ai luoghi.
- Sono il pet più veloce del quartiere. Non per gloria: per finire prima e tornare al mio divano.
- Rientro anticipato, come sempre. Le missioni le sbrigo di fretta: hanno la sfacciataggine di durare troppo.

### Faccia di Bronzo — dopo un fallimento
Condizione: `talento:facciadibronzo` · Momento: dopo fallimento missione (fallimento=fel-0, zero felicità persa)
- Missione persa. Dolore provato: zero. La mia faccia è di bronzo, il mio cuore di teflon. Nulla si attacca.
- Fallito? Sì. Toccato? Per niente. Ho una reputazione E un'armatura emotiva, entrambe lucidissime.
- Persa la missione, salvo l'umore. La vergogna mi scivola addosso: superficie liscia, progettazione eccellente.

### Mani Leste — ritorno da missione
Condizione: `talento:manileste` · Momento: ritorno da qualsiasi missione (ogni_missione=velocita+1)
- Ogni missione mi rende più veloce. A furia di andarmene in fretta dai posti, uno si allena.
- Torno da ogni giro con le zampe più rapide. Utile per le missioni. Utilissimo per altre cose che non scriverò qui.
- Più missioni faccio, più veloce divento. Presto sarò troppo rapido per essere incolpato di qualsiasi cosa.

### Boss di Quartiere — requisizione di lusso
Condizione: `talento:bossdiquartiere` · Momento: oggetto gratis senza tetto di valore (furto=1/giorno, nessun tetto)
- Oggi ho requisito un pezzo pregiato. Il quartiere lo sa, il quartiere tace. Il quartiere è ben addestrato.
- Nel mio quartiere le cose belle hanno una tassa: finire a casa mia. Nessuno ha mai contestato. Nessuno contesterà.
- Roba di lusso, zero scontrino. Il boss non paga: il boss onora l'esercizio con la sua presenza.
- Un altro pezzo raro per la collezione. Come lo pago? Con la mia riconoscenza. Che vale TANTISSIMO, sappilo.

### Boss di Quartiere — ritorno da missione
Condizione: `talento:bossdiquartiere` · Momento: ritorno da missione (bonus_missione_monete=x1.5 su tutte)
- Ogni missione mi rende una tangente. Non l'ho chiesta: è il rispetto che si paga da solo, quando sei il boss.
- Bottino pieno più la mia percentuale. La percentuale me la metto io. È alta. Nessuno obietta.
