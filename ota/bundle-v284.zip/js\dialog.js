window.PETQ = window.PETQ || {};

(function () {

  var ultimaBattuta = {}; // per personalita+situazione, evita ripetizione consecutiva

  // i18n (contratto petq_lingua, v. i18n.js): gli slot di default 'capo' e 'boh' sono parole
  // mostrate al giocatore -> passano da traduci() come le stringhe UI ('boss' / 'dunno' in EN).
  var traduci = (PETQ.i18n && PETQ.i18n.t) || function (s) { return s; };

  /* Ultima parola INSEGNATA realmente pronunciata in una battuta. Serve alla voce vera (TTS):
   * say() ritorna il testo gia' riempito, quindi da fuori non c'e' modo di sapere QUALE parola
   * sia finita nello slot — e senza saperlo si dovrebbe indovinare cercandola nel testo, che
   * sbaglia al primo giocatore che insegna una parola comune come "ciao".
   * Si azzera ad ogni riempimento: cosi' non resta appiccicata a una battuta successiva che
   * la parola non la contiene affatto. */
  var ultimaParola = null;

  function riempiSlot(testo, pet, state) {
    var nome = (pet && pet.nome) ? pet.nome : '...';
    var parola = traduci('boh');
    var insegnata = false;
    if (state && state.parole && state.parole.length > 0) {
      var pescata = PETQ.rng.pick(state.parole);
      if (pescata) { parola = pescata; insegnata = true; }
    }
    // Vale solo se lo slot c'e' DAVVERO in questo testo e la parola e' una insegnata (non il
    // ripiego "boh", che il pet dice quando non gli hai ancora insegnato niente).
    ultimaParola = (insegnata && testo.indexOf('{parola}') !== -1) ? parola : null;
    return testo
      .replace(/\{nome\}/g, nome)
      .replace(/\{utente\}/g, traduci('capo'))
      .replace(/\{parola\}/g, parola);
  }

  // Situazioni "contestuali" in cui il pet puo' usare spontaneamente una parola insegnata
  // (GDD "Parola insegnata" / bilanciamento.md "Frequenza uso parola imparata", playtest —
  // il fondatore non la vedeva mai): saluto e felice sono le uniche due chiavi di pool usate
  // da situazionePrioritaria() in ui.js, ma coprono TUTTE E QUATTRO le situazioni richieste:
  // - saluto: battuta automatica generica (ui.js battutaAutomatica) quando nessun'altra
  //   situazione e' prioritaria
  // - felice: battuta automatica quando Felicita' > 75, e battuta occasionale dopo una coccola
  //   (ui.js eseguiCoccola -> battutaAutomatica) o dopo un pasto (ui.js eseguiFeed)
  // - "apertura casa": battutaAutomatica() e' chiamata da renderStanza() ad ogni cambio
  //   stanza/boot, quindi anche il primo giro all'apertura passa da qui
  // MAI negli esiti missione (missione_successo/missione_fallimento hanno pool dedicati, mai
  // instradati su 'parola') ne' nelle situazioni critiche fame/sporco/triste (escluse di
  // proposito da questa mappa: si fondono nell'aggiornaHud ma la voce del pet nei momenti
  // brutti non scherza con le parole imparate per gioco).
  var SITUAZIONI_PAROLA = { saluto: true, felice: true };
  var PROB_PAROLA = 0.3;

  // Normalizza il nome di un talento del pet allo stesso modo dei riferimenti nel file
  // (SENZA spazi + lowercase), come fa missions._valutaCond per ctx.talenti e
  // content.parseTermine per "talento:<nome>". Cosi' "Idrofobico"/"Boss di Quartiere" del pet
  // combaciano con "idrofobico"/"bossdiquartiere" della riga Condizione.
  function normalizzaNomeTalento(nome) {
    return (nome ? String(nome) : '').trim().toLowerCase().replace(/\s+/g, '');
  }

  function petHaTalento(pet, talentoNormalizzato) {
    if (!pet || !Array.isArray(pet.talenti)) return false;
    for (var i = 0; i < pet.talenti.length; i++) {
      if (normalizzaNomeTalento(pet.talenti[i] && pet.talenti[i].nome) === talentoNormalizzato) return true;
    }
    return false;
  }

  // Cerca in data.battuteTalenti[pet.personalita] la PRIMA voce con voce.chiave === chiave per
  // cui il pet POSSIEDE il talento voce.talento. Ritorna { testo, sostitutivo } con una battuta a
  // caso (slot riempiti come say, evitando la ripetizione consecutiva sullo stesso pool), oppure
  // null se nessuna voce combacia. La `chiave` e' quella derivata dalla prosa Momento in
  // content.parseBattuteTalenti (v. BATTUTA_TALENTO_CHIAVE_MAP).
  function trovaVoceTalento(pet, chiave, state) {
    if (!pet || !chiave) return null;
    var data = window.PETQ.content && window.PETQ.content.data;
    var elenco = data && data.battuteTalenti && data.battuteTalenti[pet.personalita || 'gentile'];
    if (!Array.isArray(elenco)) return null;
    for (var i = 0; i < elenco.length; i++) {
      var voce = elenco[i];
      if (!voce || voce.chiave !== chiave) continue;
      if (!voce.battute || voce.battute.length === 0) continue;
      if (petHaTalento(pet, voce.talento)) return voce;
    }
    return null;
  }

  function pescaDaPool(pool, chiaveRipetizione, pet, state) {
    if (!pool || pool.length === 0) return null;
    var scelta;
    if (pool.length === 1) {
      scelta = pool[0];
    } else {
      var precedente = ultimaBattuta[chiaveRipetizione];
      do {
        scelta = PETQ.rng.pick(pool);
      } while (scelta === precedente && pool.length > 1);
      ultimaBattuta[chiaveRipetizione] = scelta;
    }
    return riempiSlot(scelta, pet, state);
  }

  // Helper pubblico: ritorna una battuta-talento per (pet, chiave, state) o null.
  function battutaTalento(pet, chiave, state) {
    var voce = trovaVoceTalento(pet, chiave, state);
    if (!voce) return null;
    var personalita = (pet && pet.personalita) || 'gentile';
    return pescaDaPool(voce.battute, 'talento:' + personalita + ':' + chiave, pet, state);
  }

  function say(pet, situazione, state) {
    if (!pet) return '...';

    var data = window.PETQ.content && window.PETQ.content.data;
    var personalita = pet.personalita || 'gentile';
    var pools = data && data.personalita && data.personalita[personalita];

    // Battute LEGGENDA (P3, content/leggende/<slug>.md via content.js data.leggende): se il pet
    // e' una leggenda (pet.razza==='leggenda', pet.leggendaId='m65'..'m72', v. pet.js generate())
    // e per QUESTA situazione esiste un pool non vuoto nel suo file dedicato, pesca da li' con una
    // chiave anti-ripetizione dedicata (namespace 'leggenda:', non collide con 'talento:'/quella
    // generica sotto). I file leggenda coprono solo 9 situazioni su ~34 (saluto/fame/sporco/
    // coccole_finite/missione_partenza/missione_successo/missione_fallimento/dormire/sveglia): per
    // tutte le altre, o se il file leggenda non e' ancora stato scritto dal socio (data.leggende
    // senza quell'id), il pool qui sotto e' assente/vuoto e si prosegue INVARIATI col ramo
    // personalita' generico (talenti + parola + pool normale) — fallback OBBLIGATORIO, mai '...'
    // se esiste un pool personalita'.
    if (pet.razza === 'leggenda' && pet.leggendaId && data && data.leggende && data.leggende[pet.leggendaId]) {
      var poolLeggenda = data.leggende[pet.leggendaId][situazione];
      if (poolLeggenda && poolLeggenda.length > 0) {
        var battutaLeggenda = pescaDaPool(poolLeggenda, 'leggenda:' + pet.leggendaId + ':' + situazione, pet, state);
        if (battutaLeggenda) return battutaLeggenda;
      }
    }

    // Battute legate ai talenti (checklist del fondatore): dopo aver risolto la situazione,
    // controlla se esiste una voce battuta-talento con chiave === situazione per cui il pet ha
    // il talento richiesto. Se e' SOSTITUTIVA -> rimpiazza il pool base (ritorna quella).
    // Se e' additiva -> ~50% ritorna quella, altrimenti prosegue col pool base normale.
    var voceTal = trovaVoceTalento(pet, situazione, state);
    if (voceTal) {
      if (voceTal.sostitutivo || PETQ.rng.rand() < 0.5) {
        var battutaTal = pescaDaPool(voceTal.battute, 'talento:' + personalita + ':' + situazione, pet, state);
        if (battutaTal) return battutaTal;
      }
    }

    // 30% delle battute contestuali pescano dal pool 'parola' se il giocatore ha insegnato
    // almeno una parola ({parola} = una a caso tra le insegnate, v. riempiSlot sopra).
    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "uso_parola=50%", Cervellone): la probabilita'
    // sale al 50% per questo pet, letta a runtime da PETQ.talenti.usoParolaProb (default = PROB_PAROLA
    // stesso valore di bilanciamento.md, 30%, se il talento non e' attivo o il modulo non e' pronto).
    var probParola = (state && PETQ.talenti && PETQ.talenti.usoParolaProb) ? PETQ.talenti.usoParolaProb(state) : PROB_PAROLA;
    if (SITUAZIONI_PAROLA[situazione] && state && state.parole && state.parole.length > 0 &&
        pools && pools.parola && pools.parola.length > 0 && PETQ.rng.rand() < probParola) {
      situazione = 'parola';
    }

    var pool = pools ? pools[situazione] : null;

    if (!pool || pool.length === 0) return '...';

    var scelta;
    if (pool.length === 1) {
      scelta = pool[0];
    } else {
      var chiave = personalita + ':' + situazione;
      var precedente = ultimaBattuta[chiave];
      do {
        scelta = PETQ.rng.pick(pool);
      } while (scelta === precedente && pool.length > 1);
      ultimaBattuta[chiave] = scelta;
    }

    return riempiSlot(scelta, pet, state);
  }

  window.PETQ.dialog = {
    say: say,
    battutaTalento: battutaTalento,
    // Quale parola insegnata e' appena stata pronunciata (null se nessuna): la legge la voce
    // vera in ui.js, subito dopo say(), per farla dire davvero ad alta voce.
    ultimaParolaDetta: function () { return ultimaParola; },
    _probParola: PROB_PAROLA,
    _situazioniParola: SITUAZIONI_PAROLA
  };

})();
