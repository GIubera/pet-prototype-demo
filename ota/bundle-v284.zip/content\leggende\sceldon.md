# Sceldon — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il genio pedante. Corregge tutti, spiega cose che nessuno ha chiesto, routine ferree e UN posto sul divano che è SUO. Le sue battute fanno ridere solo lui. Catchphrase: "Bazzinga!" (dopo ogni battuta che ritiene comica).

## Saluto (apertura app)
- Sei tornato alle 18:07. Ieri alle 18:04. Questa deriva di tre minuti verrà discussa. Accomodati, ma non al MIO posto.
- Bentornato. Ho preparato un elenco di argomenti di conversazione approvati. Il punto uno sono io.
- Ciao. Stavo per diramare un avviso di ricerca, redatto correttamente, a differenza di come l'avresti scritto tu.
- Eccoti. La casa ha funzionato perfettamente in tua assenza, perché c'ero io. Correlazione? No: causalità.

## Ha fame
- È l'ora del pasto. Lo so io, lo sa il mio stomaco, lo saprebbe anche il tuo calendario, se lo leggessi.
- Ho fame. Preciso: non "un languorino", che è un termine non scientifico. Fame. Da manuale. Capitolo sette.
- Il cibo va servito adesso: la mia routine alimentare non è un suggerimento, è un protocollo.
- Cosa mangia un pet geniale quando ha fame? Qualsiasi cosa, ma con superiorità. Bazzinga!

## È sporco
- Sono sporco, e la colpa è statisticamente tua: io non tocco niente che non sia stato disinfettato.
- Igiene compromessa. Attivare protocollo bagno: acqua a temperatura ESATTA, sapone neutro, zero schizzi sul mio lato.
- C'è dello sporco su di me. Sporco. Su di ME. È come vedere un errore di battitura su un'enciclopedia.
- Perché i germi hanno scelto proprio me? Perché anche loro riconoscono l'eccellenza. Bazzinga!

## Coccole finite
- Il quantitativo di contatto fisico consentito per oggi è esaurito. Consulta il regolamento. L'ho scritto io. Stamattina.
- Basta coccole: la mia routine prevede ora 45 minuti di superiorità silenziosa sul mio posto del divano.
- Le carezze erano accettabili. Persino piacevoli. Questo dato resta tra noi, o negherò con citazioni.
- Fine coccole. Sai perché i geni non si fanno coccolare troppo? Perché si accarezzano l'ego da soli. Bazzinga!

## Parte per la missione
- Parto per la missione. Ho un piano A, un piano B e un piano C che prevede di spiegare agli altri perché avevano torto.
- Missione. Probabilità di successo: alta. Probabilità che io la commenti in modo insopportabile: altissima.
- Vado. Non toccare il mio posto sul divano. Ho installato dei deterrenti. Sono cuscini, ma disposti in modo minaccioso.
- Missione accettata. Se incontro incompetenti, li correggerò. È il mio modo di fare beneficenza.

## Ritorno: successo
- Missione completata in modo impeccabile. Ovvio: c'ero io. Il resto è contorno.
- Vittoria. L'avevo prevista, calcolata e già commentata mentalmente. Il replay dal vivo è stato comunque gradevole.
- Successo. Gli altri hanno "fatto del loro meglio". Adorabile. Io ho fatto IL meglio.
- Come si chiama una missione con me dentro? Una missione riuscita. Bazzinga!

## Ritorno: fallimento
- La missione è fallita per variabili esterne. Io, internamente, sono stato impeccabile come sempre.
- Fallimento. Ho già individuato i sette errori. Nessuno è mio. Il documento è disponibile su richiesta.
- Non ha funzionato. Sorprendente, dato che c'ero io. Sto riesaminando le leggi della probabilità: devono essersi sbagliate loro.
- Persa. Ma ho corretto la grammatica del cartello del nemico, quindi il quartiere ci ha comunque guadagnato.

## Va a dormire
- Sono le 21:00: la mia routine del sonno inizia ADESSO. Luci basse, silenzio, e nessuno respiri in modo irregolare.
- Vado a letto. Il lato sinistro. Il MIO lato. Anche da solo nel letto, esiste un mio lato.
- Buonanotte. Ho già preparato i sogni di stanotte: un indice, tre capitoli e una sorpresa che non capirai.
- Dormire otto ore rende geniali. Nel mio caso, mantiene. Bazzinga!

## Sveglia (risveglio dopo il sonno)
- Sveglio alle 7:00 esatte, come da protocollo. Il gallo del vicinato è in ritardo di due minuti: gli ho preparato una nota.
- Buongiorno. Durante il sonno il mio cervello ha risolto due problemi. Uno era tuo. Prego.
- Sveglio. La routine mattutina inizia: non parlarmi prima del punto quattro dell'elenco. Tu sei il punto sei.
- Mi sono svegliato geniale anche oggi. La costanza è la virtù dei grandi. E dei geni. Quindi doppia. Bazzinga!
