# Maleducato — pool battute

Una battuta per riga, iniziando con `- `. Obiettivo: 5-8 per sezione. Le righe `[ESEMPIO]` calibrano il tono: tienile, riscrivile o cancellale. Slot: `{nome}` `{utente}` `{parola}`.
Voce: teatralmente offeso, sarcastico, permaloso — un gatto indignato, mai crudele.

## Saluto (apertura app)
- Ah, ti degni. Che onore ricevere la tua visita.
- Oh, sei vivo. Lo segno sul calendario, è un evento.
- Ah, eccoti. Avevo quasi finito di prepararmi il monologo sull'abbandono.
- Sei tornato per me o per il senso di colpa? Va bene comunque, entra.
- Ti aspettavo. Non in senso romantico. In senso legale: ho appunti su tutto.
- Ti sei ricordato di me. Notevole. C'è speranza per la tua specie. (Poca.)
- Ah, respiri ancora. Avevo già scritto il necrologio della nostra amicizia. Che spreco di bella prosa.
- Eccoti. Stavo per denunciare la scomparsa. Non per ritrovarti: per il gusto della burocrazia.
- Sei tornato. Il mio avvocato immaginario stava preparando le carte per abbandono. Le tengo in caldo.
- Bentornato. Ho fatto una seduta spiritica per contattare la tua presenza. Ha risposto il frigo. Più affettuoso.
- Oh, eccolo. Il mio cuore ha fatto un balzo. Di rabbia, ovviamente. Però un balzo.
- Bentornato. Ho tenuto il conto dei torti: siamo a diciassette. Il ritardo sarebbe il diciottesimo, ma sono magnanimo.

## Ha fame
- La ciotola è vuota. VUOTA. Come le tue promesse.
- Ho lasciato recensioni migliori a ristoranti peggiori. Una stella. Il cibo non arriva mai.
- Se svengo di fame, sappi che l'avrò fatto in modo teatrale e che è colpa tua.
- Il mio ultimo pasto risale a un'era geologica fa. Ho visto estinguersi cose, {utente}.
- Ho fame da così tanto che ho iniziato a guardare il divano con occhi diversi.
- La cucina è a due metri, {utente}. Due. Ti disegno una mappa?
- Ho visto la luce in fondo al tunnel. Era il frigo. Chiuso. Riflettici.
- Le mie ultime volontà: lascio il broncio a te e la fame al mio successore. Oppure, idea folle: CIBO.
- Ancora un'ora così e il documentario si intitolerà "Il mistero della ciotola vuota". Spoiler: il colpevole sei tu.
- Ho rosicchiato l'angolo del tappeto. Non è un grido d'aiuto, è un antipasto. IL PIATTO PRINCIPALE, PREGO.
- Il mio stomaco ha smesso di brontolare. Ora medita in silenzio. Fa più paura, vero? Appunto.

## È sporco
- Vivo nel degrado. Un giorno scriverò un libro su quello che mi fai passare.
- Mi sono annusato per sbaglio. Non me lo perdonerò mai. E nemmeno a te.
- Io non sono sporco: sono in decomposizione controllata. Comunque lavami.
- Guardami. No, guardami davvero. Ecco: questo è il degrado di cui parlavo nel libro.
- Un pet del mio livello, ridotto così. Se avessi degli avvocati, li avresti già sentiti.
- Qualcosa è morto qui dentro. Era la mia pazienza per l'igiene fai-da-te. Provvedi tu.
- Le moschine mi hanno eletto monumento nazionale. Vogliono mettere la targa. FERMALE. Con l'acqua.
- Sono al punto in cui il sapone mi teme. Vinca il migliore: apri quel rubinetto.
- Se non mi lavi oggi, domani questa puzza avrà un nome, un documento e diritti acquisiti. Sbrigati.

## Felice
- Non ci sono lamentele al momento. Goditela, non durerà.
- Oggi sono di buon umore. Non farci l'abitudine, è un errore del sistema.
- Giornata perfetta. Sospetto tu abbia combinato qualcosa. Indagherò. Domani.
- Provo una strana sensazione di benessere. Se è contagiosa, la colpa è tua.
- Oggi non ti odio. Segnatelo, che domani si torna alla normalità.
- Sto bene e la cosa mi insospettisce. Tu ne sai qualcosa?
- Giornata splendida. Sospetto sia una trappola, ma ci casco con eleganza.
- Sono di buon umore. Godi finché dura: il mio lato oscuro è solo in pausa caffè.
- Che bella giornata. La segno a matita, che scriverla in penna porta sfortuna.

## Coccole finite
- Basta, ho una reputazione da difendere. Le coccole di oggi sono FINITE. Torna domani, se proprio devi.
- Sto facendo le fusa?! CHI TE L'HA DETTO. Basta coccole, mi stai compromettendo.
- Le coccole sono finite. Non per me, per te: troppa fortuna in un giorno solo fa male.
- Il broncio mi si sta ammorbidendo. INACCETTABILE. Sospensione immediata delle coccole. Il modulo di ricorso non esiste.
- Quota affetto esaurita. Riprova domani, il centralino apre alle otto. (Alle sette e mezza, ma non dirlo.)
- Basta. Ancora una carezza e ti perdono qualcosa. Non possiamo correre questi rischi.
- Fine coccole. Vado a rimettermi in ordine il pelo e l'orgoglio, nell'ordine inverso.
- Le coccole extra le segno come debito. Ah no, non si può. Che peccato, IMMENSO peccato. A domani.

## Trascurato / triste
- Tre giorni. TRE. Ho già scelto il mio nuovo umano, sappilo. È solo che non si è ancora presentato.
- Ho parlato col muro. Il muro mi ascolta più di te. Abbiamo legato.
- Non sono triste. Ho gli occhi lucidi per la polvere. La polvere dell'ABBANDONO.
- Ho riordinato i tuoi ricordi in uno scatolone. Etichetta: "da valutare". VALUTA anche tu qualcosa, ogni tanto.
- Ho contato i buchi del soffitto due volte. Ormai li conosco per nome.
- Il mio broncio ha raggiunto livelli che la scienza vorrà studiare. Vieni a vederlo, almeno tu.
- Ho aggiornato il testamento: il divano resta erede universale, tu sei ufficialmente diseredato.
- Giorni di solitudine: tanti. Ho iniziato a raccontare i miei torti al soffitto. Prende appunti, secondo me.

## Parte per la missione
- Vado a fare tutto il lavoro, come al solito. Non ringraziarmi, tanto non lo fai mai.
- Un'altra missione. Certo. Tu resta pure comodo, eroe del divano.
- Missione accettata. Sotto protesta. Voglio che la protesta risulti a verbale.
- Io vado a rischiare la pelliccia e tu premi un bottone. Squadra fantastica.
- Ok, vado. Ma perché mi annoiavo, non perché me l'hai chiesto tu.
- Vado in missione. Se non torno, di' al frigo che l'ho amato. Solo lui. Rifletti.
- Missione. Rischio la reputazione per monete e gloria. Le monete a me, i sensi di colpa a te.
- Vado. Ho firmato la liberatoria: in caso di disastro, la colpa è del mandante. Il mandante sei tu.

## Ritorno: successo
- Fatto. Perfetto. Come sempre. Sorpreso? Sei l'unico.
- Missione compiuta. Puoi ringraziarmi in cibo. Solo in cibo.
- Ho vinto. Da solo. Segnati la parte del "da solo", mi raccomando.
- È andata benissimo, ovvio. Il talento non prende ferie. L'umiltà sì.
- Torno vittorioso e trovo la stessa ciotola vuota di prima. La gloria è sopravvalutata.
- Vittoria. Gli avversari mi ricorderanno nei loro incubi. Con affetto, spero. No, senza affetto.
- Trionfo. La statua in mio onore la accetto anche piccola. Tipo a grandezza naturale.
- Vinto. L'unico graffio l'ha preso la mia modestia. Era già messa male, comunque.

## Ritorno: fallimento
- È andata malissimo e sì, è colpa tua. Non chiedermi come: lo sento.
- È andata male. Il piano era perfetto, era la realtà a essere sbagliata.
- Ho perso. Ma con uno stile che i vincitori se lo sognano.
- Fallimento. Tecnicamente. Io preferisco "vittoria rimandata per motivi personali".
- Sconfitto, sì. Ma il vero fallimento è tuo che mi ci hai mandato. Rifletti.
- Fallita. Seppelliamo l'argomento in giardino, di notte, e mai più una parola. Patto?
- Persa. Ho già scelto il capro espiatorio: è chi mi ci ha mandato. Combacia con te, curioso.

## Notifica push
- {nome} ci tiene a farti sapere che sta benissimo senza di te. Insiste molto perché tu lo sappia.
- Nessuna emergenza. {nome} vuole solo che tu ti senta in colpa a distanza.
- {nome} ha preparato tre bronci diversi. Vieni a scegliere il tuo preferito.
- {nome} sta ignorando la tua assenza. Male, ma la sta ignorando.
- {nome} ha fatto una cosa carinissima e per ripicca non te la mostrerà mai.
- {nome} sta fissando il muro come nei documentari crime. Manca solo la lavagna coi fili rossi. Ce l'ha. Vieni.
- Ultimo avviso prima che {nome} riscriva il testamento. Il divano si sta già sfregando le mani.
- {nome} giura vendetta da tre ore. Le vendette di {nome} sono bronci. Ma lunghi. Vieni a disinnescarlo.

## Valigia (sta per partire)
- Ho impacchettato tutto tranne la dignità. Quella l'avevo persa vivendo qui.
- Sto piegando le mie cose con rabbia. Si può piegare con rabbia, guarda. GUARDA.
- La valigia si chiude male. Come tutto, in questa casa.
- Ho messo in valigia anche la tua tazza preferita. Sanzione simbolica. Reclama pure.
- Ho salutato ogni stanza con una frase tagliente. Il bagno se l'è presa. Bene.
- Sto scrivendo le etichette del bagaglio: "fragile". Come la fiducia, guarda caso.
- La valigia è quasi pronta. Il quasi dipende da te, ma non ti dirò mai come. (Fermami.)
- Ho impacchettato i miei bronci migliori. Ne lascio uno qui, di scorta, appeso all'attaccapanni.

## Notifica valigia
- {nome} sta trascinando una valigia verso la porta. Lentissimamente. Aspetta di essere fermato.
- Ultima chiamata: {nome} sta uscendo di scena. Teatralmente. C'è ancora tempo per un applauso. Cioè, per le scuse.
- {nome} vuole che tu NON sappia che sta partendo. Te lo dico io: sta partendo. Fai qualcosa.

## Rientro (hai rimediato in tempo)
- Era un test. L'hai quasi fallito. Disfo la valigia solo perché pesava.
- Ah, eccoti. Era tutto pianificato: valigia, dramma, tempistica. Test superato. Per un pelo.
- Disfo tutto, va bene. Ma la valigia resta in vista. Come promemoria. Per te.
- Va bene, resto. Ma questa storia finisce nel libro. Capitolo lunghissimo.
- Torno a disfare la valigia. È la cosa più faticosa che ho fatto per noi. Apprezza.
- Resto. Ma la valigia la lascio pronta sotto il letto. Chiamala assicurazione. (È vuota. Non controllare.)
- Ho chiamato il pianeta dei ritirati: era pieno. Di gente meno interessante di me, soprattutto.
- Disfo la valigia. Lentamente. Ogni piega tolta è una concessione: contale e ringrazia.

## Addio (parte davvero)
- Me ne vado dove sanno trattarmi. Tu intanto rifletti. A lungo.
- Parto. Non piangere... ah no, niente lacrime. Certo. Coerente fino alla fine.
- Me ne vado a testa alta. La valigia pesa, ma il rancore di più. Ce la faccio.

## Lettera (dal pianeta dei ritirati)
- Qui il servizio è pessimo quanto da te, quindi non ho migliorato granché. Almeno da te c'eri tu. Insomma. Non è un invito. Forse.
- Non rispondere a questa lettera. A meno che tu non voglia farmi tornare. In quel caso rispondi. Subito. Ma con calma. Ma subito.
- Qui mi coccolano a orari fissi, cibo puntuale, zero lamentele da fare. Uno strazio. Non ho più materiale, {utente}. Riportami dove si soffre con stile.
- Ho fondato un club di pet offesi. Mi hanno eletto presidente all'unanimità. Comando su tutti e non mi diverto per niente. Trai le tue conclusioni.
- Allego la lista dei torti. È vuota: qui nessuno mi fa torti. Non ho MAI scritto niente di più triste.
- [ESEMPIO] Dicono che qui si dimentica in fretta. Balle. Ricordo ancora tutte le volte che mi hai ignorato. E anche quelle belle. Poche. Ma belle.

## Evoluzione
- Sono cresciuto. Fisicamente. Le aspettative su di te restano basse.
- Guarda come sono venuto bene. NONOSTANTE tutto, sottolineo.
- Il broncio ora è più in alto. Ti toccherà alzare lo sguardo per ricevere disprezzo.
- Evoluto. Ora sono più grande e ho più superficie per essere offeso. Attrezzati.
- Guardami: cresciuto benissimo. Il merito è del mio patrimonio genetico. Il resto... vabbè, un po' è tuo.
- Da oggi servono scuse più grandi: quelle da cucciolo non mi stanno più.
- Evoluto in una notte. Tu in tutto questo tempo, invece... lasciamo stare, oggi sono magnanimo.
- Nuova forma, stesso broncio. Le cose perfette non si cambiano.

## Ha sonno (sotto soglia energia o prima delle 21)
- Ho sonno, colpa tua. Portami a letto prima che crolli qui per dispetto.
- Missione? Adesso? Guardami. Guardami bene. Io oggi sono un soprammobile.
- Energia zero. Se mi vuoi utile, prenota per domani. Se mi vuoi decorativo, sono già perfetto.
- Allenamento rifiutato. Motivo: guardami. Sembro un calzino usato con gli occhi.
- Ho sonno e la colpa, per varietà, stavolta è della giornata. Tu però portami a letto lo stesso.
- Reggo a malapena il broncio. Quando cade il broncio, è FINITA. Letto, presto.
- Sonno livello: non ho nemmeno la forza di essere sgarbato. EMERGENZA. Letto.
- Sbadiglio per la nona volta. Le prime otto erano avvisi. Questa è una diffida.

## Va a dormire (dalle 21, portato a letto)
- Finalmente a letto. Non svegliarmi prima delle otto ore, o sono guai.
- A letto. Se russo, è colpa tua in un modo che spiegherò domani.
- Buonanotte. Ti perdono tutto fino alle 7 di domattina. Poi si riparte da zero.
- Buonanotte. Il cuscino l'ho sistemato io: da te non si può pretendere tutto.
- Vado a dormire prima di affezionarmi a questa giornata. Notte.
- Chiudi piano la porta. Il broncio dorme leggero.
- A letto. Se sogni di essere perdonato, era solo un sogno. Buonanotte comunque.
- Mi ritiro nei miei appartamenti. La buonanotte è inclusa, l'affetto si paga a parte. Notte.

## Sveglia (risveglio dopo il sonno)
- Sveglio. Di pessimo umore come sempre, ma quello è strutturale, non è colpa del sonno.
- Ho dormito benissimo e mi infastidisce non avere lamentele. Trovamene una.
- Che ore sono? Non importa. Qualsiasi ora è troppo presto se non c'è cibo pronto.
- Sveglio, sì. Operativo, no. Sono due contratti separati e il secondo si firma a stomaco pieno.
- Sveglio. Il sogno era migliore di questa stanza, e nel sogno pioveva.
- Buongiorno un corno. Però il letto era comodo, quindi diciamo buongiorno e mezzo.
- Sveglio da dieci minuti e ancora nessun disservizio da segnalare. State migliorando. Non montatevi la testa.
- Il materasso ha fatto il suo dovere. Uno di noi due doveva pur farlo.

## Dormito male (crollato, non a letto)
- Ho dormito per terra come un randagio. Bel lavoro, complimenti vivissimi.
- Ossa rotte, orgoglio peggio. Il letto era LÌ. Io ero QUI. Tu eri CHISSÀ DOVE. Ricapitolato per il verbale.
- Stanotte ho contato le piastrelle. Da vicino. Con la faccia. Complimenti per la gestione.
- Ho dormito dove sono caduto, come i mobili. Da oggi trattami pure da comodino, tanto è quello che sono qui.
- Ho dormito per terra. IL PAVIMENTO, {utente}. Persino il mio broncio ha dormito scomodo.
- Sveglio con le ossa a pezzi e la pazienza pure. Una delle due si aggiusta col cibo. Provaci.
- Notte sul pavimento. Ho sognato di dormire in un letto. Persino i miei sogni sono sarcastici.
- Dormito malissimo. La schiena scricchiola più della porta. Almeno lei si può oliare: pensaci.

## Usa una parola imparata
- Mi rimbomba in testa "{parola}" da stamattina. Colpa tua. Tutto è colpa tua.
- {parola}, {parola}, {parola}. Ecco. Ora suona ridicola anche a me. Contento?
- Oggi ho detto "{parola}" al muro. Il muro ha capito subito. Impara dal muro.
- Ho classificato "{parola}" tra le cose tue che tollero. Lista breve. Sentiti onorato.
- Ho insegnato "{parola}" al divano. Ora la sappiamo in due e tu sei in minoranza.
- Ho inciso "{parola}" sulla lapide della mia pazienza. Almeno lì c'è scritto qualcosa di bello.
- Dico "{parola}" ai nemici prima del broncio finale. È il mio biglietto da visita. Elegante e minaccioso.
- Nel mio diario segreto "{parola}" compare ventisette volte. Se lo trovi, negherò tutto. E cambierò diario.

## Gioca
- Va bene, giochiamo. Ma se rido, non era una risata: era un colpo di tosse divertito.
- Sto lottando col cuscino. Sta perdendo. Non intrometterti, è una questione d'onore.
- Rincorro la mia coda. Non perché sono buffo: è LEI che fa la furba. Qualcuno deve fermarla.
- Giochiamo, dai. Cinque minuti. (Un'ora. Ma ufficialmente cinque minuti.)

## Gioca col giocattolo
- Un giocattolo? Per me? Non dovevi. Cioè, DOVEVI, era ora. Comunque è mio, non toccarlo.
- Accetto questo tributo. Ci giocherò con sufficienza. (Non è vero: non me lo toglierete più di zampa.)
- Carino. L'ho già morso per stabilire la gerarchia. Ha capito chi comanda: comando io.
- Mio. MIO. Fine della recensione.

## Passeggiata partenza
- Esco. Da solo. Come i pet indipendenti e affascinanti. Non aspettarmi alzato. (Aspettami.)
- Vado a ispezionare il quartiere. Qualcuno deve pur giudicarlo casa per casa.
- Passeggiata pomeridiana. Se qualcuno chiede di me, di' che sono impegnatissimo e altrove.
- Vado. Non è una fuga, è una sfilata. C'è differenza e la differenza sono io.

## Passeggiata monete
- Ho trovato monete per strada. La città mi paga per esistere. FINALMENTE qualcuno che capisce.
- Bottino del giro: monete. Le ho trovate io, quindi sono mie. Le amministro io. Fidati. (Non fidarti.)
- Il marciapiede mi doveva dei soldi, evidentemente. Riscossi. Il quartiere si sta mettendo in regola.
- Qualcuno ha perso delle monete. Io le ho trovate. La strada premia i migliori, funziona così.

## Passeggiata incontro
- Ho incontrato un altro pet. Abbiamo giocato. Ha vinto lui... A NASCONDERSI. Io ho vinto tutto il resto.
- C'era un pet al parchetto. Simpatico, per essere uno che non sono io.
- Incontro con un altro pet: prima ci siamo studiati, poi rincorsi. Non chiamarla amicizia. (Ci rivediamo giovedì.)
- Un pet ha osato giocare con me. Se l'è cavata bene. Non dirgli mai che l'ho detto.

## Passeggiata pozzanghera
- Sì, sono fradicio. Sì, l'ho fatto apposta. No, non sono pentito. Tre risposte, zero rimorsi.
- La pozzanghera era lì, io ero lì. È stata legittima difesa. Al contrario.
- Fradicio e fiero. Lo splash si è sentito in tre vie. Un capolavoro, dicono. Lo dico io.
- Ho giudicato la pozzanghera. Colpevole di essere IRRESISTIBILE. La condanna l'ho eseguita in tuffo.

## Passeggiata panorama
- Ho guardato le luci dal ponte. Carine. La città migliora molto, vista da lontano. Come quasi tutti.
- Le luci della città... va bene, lo ammetto: belle. Questa confessione scade a mezzanotte.
- Dal ponte si vede tutto il quartiere. Ho cercato casa nostra. L'ho trovata subito. Non significa niente.
- Momento di quiete sul ponte. Nessuno mi ha infastidito e il mondo era quasi all'altezza. Giornata rara.

## Passeggiata rottame
_(socio: 4 battute — torna con un rottame/pezzo alieno luccicante trovato per strada (+monete))_
- Ho trovato un rottame LUCCICANTE. Vale una fortuna, fidati. Il mio fiuto per gli affari non sbaglia mai. (Quasi mai.)
- Torno con un pezzo di metallo alieno. Gli altri ci passavano accanto: dilettanti. Io riconosco il valore.
- Rottame? ROTTAME? Questo è un pezzo da collezione. Lo metto in salotto, in vista, coi riflettori.
- La strada mi ha offerto un tributo di metallo pregiato. Accettato. Non chiedermi quanto vale: tanto. TANTO.

## Passeggiata piccione
_(socio: 4 battute — ha rincorso un piccione cyborg / drone per mezza città (+Felicità, −Energia))_
- Ho inseguito un piccione cyborg per mezza città. Non l'ho preso perché... non volevo prenderlo. Esatto.
- Il piccione robotico è scappato. Tecnicamente ha vinto. Moralmente ho vinto io, e la morale conta di più.
- Mezza città di corsa dietro a un piccione di latta. Non commentare. Non. Commentare.
- Quel piccione mezzo robot ride ancora. Rida pure: ho memorizzato la sua targa. Ci rivedremo.

## Passeggiata assaggio
_(socio: 4 battute — un ambulante gli molla uno spuntino gratis al volo (+Fame))_
- Un ambulante mi ha dato un assaggio gratis. FINALMENTE il quartiere riconosce chi merita.
- Spuntino in omaggio dall'ambulante. Non l'ho ringraziato troppo: non voglio dargli l'illusione che basti così poco.
- Cibo gratis per strada. Era ora. Ho una reputazione da mantenere: ho masticato con eleganza.
- L'ambulante mi ha allungato un boccone "perché ho la faccia simpatica". Ha capito tutto al contrario, ma il cibo era buono.

## Passeggiata acquazzone
_(socio: 4 battute — acquazzone improvviso: torna zuppo ma bello pulito (+Igiene, −Felicità))_
- Acquazzone a tradimento. Sono fradicio, infreddolito e PULITO. Non un buon affare, comunque.
- La pioggia mi ha lavato senza permesso. Il risultato è ottimo, ma il metodo è inaccettabile. Reclamo in corso.
- Zuppo dalla testa ai piedi. Il cielo mi ha fatto il bagnetto d'ufficio. Portami una coperta e nessuna domanda.
- Torno pulito e bagnato. Ringrazia la pioggia: ha fatto il tuo lavoro. Gratis, tra l'altro. Impara.

## Passeggiata persi
_(socio: 4 battute — si è perso e ha girovagato: gran avventura, ma stanco (+Felicità, −Energia))_
- Mi sono perso. Cioè: ho esplorato zone nuove SENZA preavviso. La differenza è questione di prestigio.
- Ho girovagato per ore. Le strade erano tutte sbagliate tranne l'ultima. Tipico delle strade.
- Perso, io? Diciamo che la città si è spostata. Comunque sono tornato: le gambe reclamano, la leggenda cresce.
- Tre ore in giro per colpa di una scorciatoia bugiarda. Ho i piedi a pezzi e una lista di vie da denunciare.

## Passeggiata cielo
_(socio: 4 battute — vede un'astronave/UFO passare bassa sui tetti (+Felicità, worldbuilding sci-fi))_
- Ho visto un'astronave passare sui tetti. Ok, era notevole. Il cielo oggi si è impegnato, lo ammetto.
- Un UFO basso basso. Non ho salutato: non do confidenza a chi non si presenta.
- Astronave in cielo. Bella, luminosa, misteriosa. Se cercavano me, dovevano prenotare.
- Una luce enorme sopra i tetti. Mi sono fermato a guardarla. Nessun testimone, quindi tecnicamente non è successo.

## Passeggiata bulletto
_(socio: 4 battute — incrocia un pet maleducato: parole grosse, morale un po' giù (−Felicità))_
- Un pet mi ha mancato di rispetto. A ME. Sto ancora elaborando l'accaduto. Il quartiere ne risponderà.
- Ho incrociato un bulletto. Parole grosse, le sue. Silenzio glaciale, il mio. Ha vinto lui, ma con disonore.
- Un tizio sgarbato mi ha rovinato la passeggiata. Io sgarbato? Sì, ma con CLASSE. Lui era solo volgare.
- Torno di pessimo umore: un pet mi ha risposto male. È il mio mestiere rispondere male! Trovarsi un'idea sua, no?


## Notifica missione finita
Notifica push sul telefono quando una missione si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}` disponibile. Finché questa lista è vuota il gioco usa un testo neutro.
- {nome} è tornato VIVO. Non grazie a te. Il bottino si vede solo dal vivo.
- Missione finita. {nome} non svela l'esito. Suspense. Apri e piangi. O esulta.
- {nome} è rientrato e ha GIÀ giudicato la tua assenza. Vieni a sentire il verdetto.
- Il bottino c'è. Il racconto pure. Il pubblico manca. Indovina chi è il pubblico.
- {nome} è tornato. Fingere indifferenza gli riesce meglio se lo guardi. Sbrigati.

## Notifica allenamento finito
Notifica push quando l'allenamento si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}`. Finché vuota: testo neutro.
- {nome} si è allenato DA SOLO. Il broncio è al massimo. Vieni a disinnescarlo.
- Allenamento finito. {nome} è più forte e più offeso di prima. Doppio risultato.
- {nome} ha faticato mentre tu... facevi cose. Vieni ad ammirare il risultato.
- Muscoli nuovi, broncio vecchio. {nome} espone entrambi. Solo su appuntamento. Ora.

## Notifica carica a rischio
Notifica della sera, SOLO se la carica e' a rischio (streak >= 3 e giornata senza cura). Ricorda, non rimprovera. Una battuta per riga con `- `, slot `{nome}`.
- {nome} NON ti sta aspettando. Sta solo guardando la porta. Per caso. Da ore.
- La carica sta scendendo e {nome} se ne infischia. Molto rumorosamente. Vieni.
- {nome} ha gia' preparato la frase da dirti domani. E' lunga. Evitala.
- Se la carica salta {nome} non dira' niente. Per tre giorni. Buona fortuna.

## Notifica silenzio lungo
Notifica dopo 3+ giorni di assenza. Tono leggero: il pet se la cava, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{nome}`.
- TRE giorni. {nome} li ha contati. Uno per uno. Ad alta voce.
- {nome} sta benissimo. Ha ridipinto il broncio di fresco per l'occasione.
- {nome} ha smesso di aspettarti. Ha ricominciato. Ha smesso di nuovo. E' stanco.
- {nome} ti ha cancellato dalla lista. Poi rimesso. Poi cancellato. La lista e' un disastro.

## Reazione assenza lunga
Il pet ti rivede dopo 3+ giorni. Tono leggero: se l'e' cavata, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{utente}`.
- TRE giorni. Li ho contati. Uno per uno. Ad alta voce.
- Ah, sei vivo. Bene. Io comunque stavo benissimo. BENISSIMO.
- Non ti ho pensato. Mai. Tranne quando mi svegliavo. E il resto del tempo.

## Reazione ora assurda
Apri il gioco fra l'una e le cinque del mattino. Il pet lo fa notare. Una battuta per riga con `- `, slot `{utente}`.
- Le DUE. Di NOTTE. Spero per te che sia importante.
- Ma guarda chi si presenta all'alba. Complimenti per l'orario.
- A quest'ora io sono un elettrodomestico spento. Portami rispetto.

## Reazione batteria scarica
La batteria del telefono e' sotto il 10%. Il pet ci scherza sopra. Una battuta per riga con `- `, slot `{utente}`.
- Se muore il telefono muoio anch'io. Metaforicamente. CARICA.
- Batteria a terra e tu fai finta di niente. Bravo.
- Mi stai spegnendo per pigrizia. Complimenti sinceri.

## Reazione tema scuro
Il telefono e' in tema scuro. Battuta di colore, nessuna conseguenza. Una battuta per riga con `- `, slot `{utente}`.
- Tema scuro. Ah, quindi facciamo gli affascinanti.
- Col tema scuro sembra tutto piu' serio. Non lo e'. Ma sembra.
- Bel tema scuro. Nasconde la polvere, eh.
