# Rocco Baldoria — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il campione buono, parodia di Rocky. Saggezza spicciola da angolo del ring, grammatica approssimativa, cuore infinito. Chiama tutti "campione". Catchphrase: "Non conta quanto forte colpisci." (con parsimonia).

## Saluto (apertura app)
- Hey, kid... you came back. I been right here. I don't move, me.
- Look who it is. C'mere, sit down — I'm feelin' talkative today.
- You made it, huh. That's a good thing. Good things come slow, kid. Like you.
- Kid! Gimme five. But gentle, huh — I did the heavy bag yesterday.

## Ha fame
- Kid, the stomach's actin' up down here. Couple eggs, c'mon. Cooked is fine too, I ain't picky.
- I got a hunger that speaks for itself. Listen to it. It's got a point.
- Eatin' is half the trainin', my old coach used to say. The other half too, pretty much.
- I'm hungry, kid. Not that hungry. Okay, hungry. Okay, starvin'. Eh, you get it.

## È sporco
- I'm lookin' rough, huh. Honest sweat ain't dirt... but wash me anyway, go on.
- Kid, I smell like an old gym. Which I kinda like, but I get it ain't for everybody.
- Run me that bath, c'mon. A clean boxer thinks better. A boxer like me thinks... well, he thinks.
- Dirty outside, clean inside. Now we fix the outside too — the inside's all set.

## Coccole finite
- That's enough, kid. Keep goin' and I'm gonna tear up. And a cryin' boxer gets his gloves all soggy.
- Whoa, easy. Pettin's like rounds: when they're over, they're over. We go again tomorrow.
- No more cuddles, go on. Not that I don't like 'em. I like 'em too much, that's the problem.
- That's all the pets for today. Save a couple for tomorrow — tomorrow's got its own fights.

## Parte per la missione
- I'm goin', kid. They knock me down, I get up. That's every trainin' I ever done, right there.
- Headin' out. Dunno if I win, but I know I come back. That's half a result already.
- A mission, huh. I bring the heart. The road brings the rest.
- Goin' to do this thing. You cheer from here — the cheerin' carries, kid. I swear it carries.

## Ritorno: successo
- I did it, kid! Me! I mean, us. Me out there, you back here — but us.
- Won. And you know what? Even I didn't believe it. Nice when life proves you wrong the good way.
- Mission done, kid. I hit soft but in the right spot. 'Cause it ain't about how hard you hit anyway.
- Victory! You carry the cup, kid — my hands are shakin'. From joy, huh. From joy.

## Ritorno: fallimento
- Lost it, kid. But I'm still standin', and tomorrow's another round. Worked like that forever.
- Went bad. But listen: it ain't about how hard you hit. It's about how you take it and keep movin' forward.
- I lost. It's fine. You can tell a real champ by how he loses — and today I lost beautiful.
- No win today. Gimme a pet and it'll pass, go on. Works every time with me.

## Va a dormire
- Night, kid. Tomorrow it's up early and runnin' them steps. The steps don't know it yet.
- Off to sleep. I close my eyes and take the count... one... two... by ten I'm out cold.
- Goodnight. I always dream the same thing: that I win. Nice habit, huh?
- Beddy-bye, kid. The bed's the only opponent I'm happy to lose to.

## Sveglia (risveglio dopo il sonno)
- I'm up, kid! Legs say ow, head says run. The head wins. Always does.
- Mornin'! Got up on the first bell. The bed took it personal, poor guy.
- Rise and shine! Today we work. Slow, easy... but we work.
- On your feet! Life don't wait, kid. Coffee, though — coffee we wait for.
