window.PETQ = window.PETQ || {};

(function () {

  // i18n.js carica per primo (v. index.html): stesso binding di care.js/arredi.js/missions.js.
  // Mancava DA SEMPRE in questo file: tutti i messaggi della passeggiata, del fine-gioco e
  // dell'ammenda uscivano in italiano anche in EN (segnalazione fondatore, 15 ago 2026).
  var traduci = (PETQ.i18n && PETQ.i18n.t) || function (s) { return s; };

  // mappa personalità -> stat "firma" (bonus alla nascita); decisione di design
  // presa da content/bilanciamento.md ("Stat iniziali alla generazione").
  // maleducato -> Velocità (decisione fondatore 5 lug 2026, emersa progettando talenti/quest:
  // era Intelligenza, ora differenziato dal nerd che resta Intelligenza).
  var STAT_FIRMA = {
    gentile: 'carisma',
    maleducato: 'velocita',
    nerd: 'intelligenza',
    sportivo: 'forza'
  };

  var PERSONALITA_LIST = ['gentile', 'maleducato', 'nerd', 'sportivo'];
  var SOTTORAZZE_ALIENO = ['blob', 'insettoide', 'rettiliano'];

  // ==================== Uovo leggendario (P3 batch 6, Grandi Imprese) ====================
  // Registry id-Impresa (m65..m72) -> nome del personaggio giocabile, personalita' FISSA (sostituisce
  // il tiro casuale in generate() sotto) e stat "firma" DEL PERSONAGGIO (+3 fisso, v. generate()):
  // puo' differire dalla stat firma generica della sua personalita' (STAT_FIRMA sopra) perche' e' la
  // stat ICONICA del meme, non quella del tipo caratteriale — es. m68 Forrest Gampo e' 'gentile' (di
  // norma Carisma) ma corre, quindi la sua firma e' Velocita'. Sprite/palette dedicati in sprites.js
  // (LEGGENDE, stesso id): finche' un id non e' disegnato li' il fallback grafico e' gia' gestito
  // (mai un crash). NIENTE spoiler in UI: questa mappa non va MAI mostrata al giocatore, solo usata
  // qui alla generazione del pet.
  var LEGGENDE_INFO = {
    m65: { nome: 'Giga Ciad', personalita: 'sportivo', statFirma: 'forza' },
    m66: { nome: 'Rocco Baldoria', personalita: 'sportivo', statFirma: 'forza' },
    m67: { nome: 'Padre Maronno', personalita: 'gentile', statFirma: 'carisma' },
    m68: { nome: 'Forrest Gampo', personalita: 'gentile', statFirma: 'velocita' },
    m69: { nome: 'Fabrice The Crown', personalita: 'maleducato', statFirma: 'carisma' },
    m70: { nome: 'Veggeta', personalita: 'maleducato', statFirma: 'forza' },
    m71: { nome: 'Sceldon', personalita: 'nerd', statFirma: 'intelligenza' },
    m72: { nome: 'Tonino Stark', personalita: 'nerd', statFirma: 'intelligenza' }
  };
  // Decisione fondatore 10 lug 2026 sera (era 10%, alzata a 20%): ogni uovo ha questa probabilita'
  // di schiudersi in una leggenda, SOLO se la casa ne ha gia' sbloccata almeno una (v. generate()).
  var PROB_UOVO_LEGGENDA = 0.20;

  // Numeri da content/bilanciamento.md sezione "Energia e sonno" (v1 confermato dal
  // fondatore, 4 lug 2026): riposino (prima delle 21) e sonno notturno (dalle 21) sono due
  // modalita' della stessa azione "dormire", vedi avviaSonno/risolviRisveglio sotto.
  var DEFAULT_ENERGIA_SONNO = {
    decadimento: 2,
    costoMissionePerOra: 8,
    costoAllenamento: 10,
    sogliaRifiuto: 20,
    oraLetto: 21,
    oraCrollo: 23,
    // Crollo automatico SOLO se stanco (fix playtest 7 lug 2026: "si mette a dormire per terra
    // anche con energia alta"): sotto questa Energia alle 23 il pet crolla, sopra resta sveglio
    // (decidera' il giocatore se metterlo a letto). Override da bilanciamento.md se presente.
    crolloSogliaEnergia: 40,
    riposinoDurataMax: 2,
    riposinoDurataMin: 1,
    riposinoRecuperoOra: 15,
    sveglioAutonomoOre: 8,     // durata max sonno notturno / sveglia autonoma
    sonnoMinimoOre: 5,         // sonno notturno: minimo di gioco prima di poter svegliare
    risveglioBuono: 100,
    risveglioCattivo: 70
  };

  function bilanciamento() {
    var data = window.PETQ.content && window.PETQ.content.data;
    if (data && data.bilanciamento) return data.bilanciamento;
    console.warn('PETQ.pet: bilanciamento non disponibile, uso default locali');
    return {
      decadimento: { fame: 6, igiene: 8, felicita: 2 },
      soglie: { critica: 25, magro: 30, sporco: 30, malusSalute: 40 },
      economia: { login: 10, monetePartenza: 50 },
      allenamento: { sessioni: 1, effetto: 1, felicita: 5 },
      iniziali: { benessere: 70, budget: 3, firma: 1 },
      energia_sonno: DEFAULT_ENERGIA_SONNO
    };
  }

  // bilanciamento.energia_sonno con fallback difensivo campo-per-campo (il bilanciamento
  // caricato potrebbe avere solo alcuni campi risolti dal parser, es. se una riga manca
  // nel file .md): stesso stile difensivo delle altre sezioni di questo modulo.
  function bilEnergiaSonno() {
    var bil = bilanciamento();
    var es = (bil && bil.energia_sonno) || {};
    var out = {};
    for (var k in DEFAULT_ENERGIA_SONNO) {
      if (!Object.prototype.hasOwnProperty.call(DEFAULT_ENERGIA_SONNO, k)) continue;
      out[k] = (typeof es[k] === 'number') ? es[k] : DEFAULT_ENERGIA_SONNO[k];
    }
    return out;
  }

  // ==================== TETTO STAT per stadio (fix "le stat sfondano le soglie in anticipo") ====
  // Misurato col motore vero (pet normale, 1 allenamento + 2 pasti-stat/giorno): Forza g2=18 gia'
  // sopra la soglia super TEEN 13, quando il teen inizia solo al g4 — le stat RPG crescevano senza
  // freno per tutta la vita del pet e sfondavano le soglie SEGRETE delle missioni giorni prima
  // dello stadio a cui appartengono. Decisione fondatore: un TETTO per stadio, per singola stat.
  // Rete di sicurezza SOLO (i valori veri arrivano da content/bilanciamento.md "Tetto delle
  // statistiche per stadio", via content.js/tettoStatPerStadio sotto): se il file manca o la riga
  // non parsa, questi tengono in piedi il gioco. NON tarare qui: si tara nel .md.
  // I numeri NON sono arbitrari: ognuno sta appena SOTTO la soglia "super" dello stadio
  // SUCCESSIVO — teen super 13 > 12; adulto super 32 > 30; Grandi Imprese super 70 = tetto adulto
  // (nessuno stadio oltre l'adulto, li' tetto e soglia coincidono).
  var TETTO_STAT_DEFAULT = { baby: 12, teen: 30, adulto: 70 };

  // Quanta Felicita' regala UNA chiamata ad aggiungiStat quando il tetto ha gia' morso (decisione
  // fondatore: "ho dato da mangiare e non e' successo niente" e' una pessima sensazione, cosi'
  // l'azione non e' sprecata). Applicata UNA volta per CHIAMATA a aggiungiStat, mai per punto
  // perso (un pet con 4 stat tutte al tetto che riceve un talento che le tocca tutte e 4 in una
  // volta sola prende +2 Felicita' per ciascuna delle 4 chiamate, non +2 in tutto: sono 4 azioni).
  var CONSOLAZIONE_FELICITA_TETTO = 2;

  function tettoStatPerStadio(stadio) {
    var bil = bilanciamento();
    var tetto = (bil && bil.tettoStat) || {};
    var v = tetto[stadio];
    if (typeof v === 'number') return v;
    return TETTO_STAT_DEFAULT[stadio] || TETTO_STAT_DEFAULT.adulto;
  }

  // ==================== L'UNICA funzione autorizzata ad alzare una stat RPG =====================
  // Ogni punto del codice che tocca pet.rpg (cibo, allenamento, studio veloce, reward missione,
  // talenti, progressione arredi/giocattoli, bonus alla nascita...) DEVE passare da qui: e' il
  // cancello unico che fa rispettare il tetto per stadio sopra, cosi' nessun punto lo puo'
  // aggirare ne' dimenticare (censiti 22 punti di scrittura sparsi in pet.js/care.js/missions.js/
  // arredi.js prima di questo fix — tutti fatti passare da qui).
  //
  // pet: l'oggetto pet (serve .rpg per la stat e .stadio per il tetto; .stats.felicita per la
  //      consolazione, se presente — in generate() il pet ha gia' pet.stats quando questa viene
  //      chiamata, quindi la consolazione funziona anche alla nascita).
  // nomeStat: 'forza'|'intelligenza'|'velocita'|'carisma'.
  // delta: quanto aggiungere. NEGATIVO passa SEMPRE, invariato (i Cibi del Disonore tolgono
  //      Carisma e possono portarlo sotto zero: decisione esplicita del fondatore) — il tetto
  //      vale SOLO verso l'ALTO.
  // Ritorna quanto e' stato REALMENTE applicato alla stat (puo' essere meno di `delta`, o 0 se il
  // tetto aveva gia' morso): utile a chi deve mostrare il risultato al giocatore.
  function aggiungiStat(pet, nomeStat, delta) {
    if (!pet || !pet.rpg || typeof pet.rpg[nomeStat] !== 'number') return 0;
    if (typeof delta !== 'number' || !delta) return 0;

    if (delta < 0) {
      pet.rpg[nomeStat] += delta;
      return delta;
    }

    var tetto = tettoStatPerStadio(pet.stadio);
    var attuale = pet.rpg[nomeStat];
    var applicato;

    if (attuale >= tetto) {
      // Gia' al tetto (o sopra: salvataggio VECCHIO, mai abbassato qui) — l'aumento e' bloccato
      // per intero, la stat NON si tocca.
      applicato = 0;
    } else {
      var nuovo = Math.min(attuale + delta, tetto);
      pet.rpg[nomeStat] = nuovo;
      applicato = nuovo - attuale;
    }

    // Consolazione Felicita' (fix: prima scattava SOLO sul blocco TOTALE, cioe' quando applicato
    // era 0 — un blocco PARZIALE, es. Forza 11 su tetto 12 con un +5 richiesto, applicava 1 e
    // perdeva gli altri 4 punti SENZA nulla in cambio, peggio di chi era gia' al tetto. Ora la
    // consolazione scatta ogni volta che il tetto ha morso ALMENO un punto rispetto al delta
    // richiesto (applicato < delta), blocco totale o parziale che sia — UNA sola volta per
    // chiamata, mai per punto perso).
    if (applicato < delta) {
      if (pet.stats && typeof pet.stats.felicita === 'number') {
        pet.stats.felicita = clamp(pet.stats.felicita + CONSOLAZIONE_FELICITA_TETTO, 0, 100);
      }
    }
    return applicato;
  }

  // `state` e' un 2o parametro OPZIONALE (P3, Grandi Imprese): serve SOLO per leggere
  // state.perkCasa (i perk di ritiro sbloccati dalla casa, v. talenti.js sezione PERK CASA) e
  // sommarne il bonus "alla nascita" qui sotto. Il primissimo pet di una partita nuova non ha
  // ancora una casa (chiamato senza 2o argomento, o con state=null): l'helper e' difensivo e
  // ritorna zero, nessun bonus, esattamente come se il campo non esistesse.
  function generate(razza, state) {
    var bil = bilanciamento();
    var r = (razza === 'robot') ? 'robot' : 'alieno';
    var sottorazza = (r === 'alieno') ? PETQ.rng.pick(SOTTORAZZE_ALIENO) : null;

    // Colore: TIRO DI NASCITA pesato (GDD "Colori del pet: tiro di nascita", 24 ago 2026) —
    // il gacha visivo della schiusa. La tabella e' UNIVERSALE: possedere un colore NON cambia
    // le probabilita' (supera la regola del 29 lug "gli sbloccati entrano nel pool"); il
    // possesso governa solo il CONTROLLO nel selettore (v. ui.js coloreDisponibile). Un colore
    // speciale uscito qui e' DI NASCITA di questo pet: resta suo per sempre via coloreNascita,
    // ma NON finisce in coloriSbloccati.
    // 6 base (0-2 storici + 8-10 nuovi) uniformi nell'88%; speciali su 1000:
    // Fantasma 40, Lava 40, Oro 15, Notte Neon 15, Ghiaccio 10 -> 120 = 12%.
    var BASE_NASCITA = [0, 1, 2, 8, 9, 10];
    var tiroColore = PETQ.rng.randInt(0, 999);
    var coloreEstratto;
    if (tiroColore < 40) coloreEstratto = 3;        // Fantasma
    else if (tiroColore < 80) coloreEstratto = 6;   // Lava
    else if (tiroColore < 95) coloreEstratto = 4;   // Oro
    else if (tiroColore < 110) coloreEstratto = 5;  // Notte Neon
    else if (tiroColore < 120) coloreEstratto = 7;  // Ghiaccio
    else coloreEstratto = BASE_NASCITA[PETQ.rng.randInt(0, BASE_NASCITA.length - 1)];

    var parts = {
      antenna: PETQ.rng.randInt(0, 2),
      testa: PETQ.rng.randInt(0, 2),
      colore: coloreEstratto,
      // il colore USCITO alla nascita: si puo' sempre tornare a questo, anche dopo aver messo
      // un colore comprato (v. ui.js coloreDisponibile)
      coloreNascita: coloreEstratto
    };

    // Uovo leggendario (P3 batch 6): il tiro e' fatto UNA volta qui, dentro generate() — chiamata
    // una sola volta per tap sull'uovo (v. ui.js sceglieUovo/nuovoPetInCasa), quindi non e'
    // ripetibile con un refresh. debugForzaLeggenda (SOLO pannello debug, v. ui.js
    // montaDebugPanel/'Schiudi leggenda (test)') bypassa il tiro e forza SEMPRE la schiusa:
    // se il ciclatore del pannello ha scelto un id specifico (state.debugLeggendaId) spawna
    // QUELLA leggenda, altrimenti pesca tra le sbloccate o ripiega su Giga Ciad (m65). Serve al
    // fondatore per vedere gli sprite senza farsi una run intera. Consumato subito (flag azzerati).
    var leggendaId = null;
    if (state && state.debugForzaLeggenda === true) {
      if (state.debugLeggendaId && LEGGENDE_INFO[state.debugLeggendaId]) {
        leggendaId = state.debugLeggendaId;
      } else {
        var listaDebugLeg = (Array.isArray(state.leggendeSbloccate) && state.leggendeSbloccate.length > 0) ?
          state.leggendeSbloccate : ['m65'];
        leggendaId = PETQ.rng.pick(listaDebugLeg);
      }
      state.debugForzaLeggenda = false;
      state.debugLeggendaId = null;
    } else if (state && Array.isArray(state.leggendeSbloccate) && state.leggendeSbloccate.length > 0 &&
               PETQ.rng.rand() < PROB_UOVO_LEGGENDA) {
      leggendaId = PETQ.rng.pick(state.leggendeSbloccate);
    }
    var infoLeggenda = leggendaId && LEGGENDE_INFO[leggendaId];

    // Personalita' FISSA se leggenda (sostituisce il tiro casuale, mai casuale per queste): il
    // talento di nascita sotto (assegnaTalentoNascita) legge pet.personalita, quindi si estrae gia'
    // coerente con la personalita' vera del personaggio, nessuna modifica li' necessaria.
    var personalita = infoLeggenda ? infoLeggenda.personalita : PETQ.rng.pick(PERSONALITA_LIST);
    var statFirma = STAT_FIRMA[personalita] || 'carisma';

    // Stat iniziali (GDD "Alla nascita", playtest v2): budget FISSO di punti assegnati
    // uno alla volta a stat casuali (possono impilarsi), poi bonus alla stat firma.
    // Totale sempre budget+firma (default 3+1=4): niente tuttofare, identita' = firma + al piu' un picco.
    var budget = (bil.iniziali && typeof bil.iniziali.budget === 'number') ? bil.iniziali.budget : 3;
    var firmaBonus = (bil.iniziali && typeof bil.iniziali.firma === 'number') ? bil.iniziali.firma : 1;
    var benessere = (bil.iniziali && typeof bil.iniziali.benessere === 'number') ? bil.iniziali.benessere : 70;

    var rpg = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    var statNomi = ['forza', 'intelligenza', 'velocita', 'carisma'];
    for (var i = 0; i < budget; i++) {
      rpg[PETQ.rng.pick(statNomi)] += 1;
    }
    rpg[statFirma] += firmaBonus;

    var pet = {
      razza: infoLeggenda ? 'leggenda' : r,
      // la razza scelta con l'uovo viene IGNORATA se leggenda: l'aspetto e' fisso, niente
      // sottorazza (era solo per l'alieno).
      sottorazza: infoLeggenda ? null : sottorazza,
      // id dell'Impresa/personaggio (es. 'm65'): letto da sprites.resolvePet per lo sprite fisso.
      // null per un pet normale robot/alieno.
      leggendaId: infoLeggenda ? leggendaId : null,
      parts: parts,
      personalita: personalita,
      // Nome default = quello del personaggio leggendario; il giocatore puo' comunque rinominarlo
      // nella schermata nascita come sempre (v. ui.js mostraNascita, pre-riempie l'input ma resta
      // modificabile/obbligatorio). null per un pet normale (nome scelto SOLO dal giocatore).
      nome: infoLeggenda ? infoLeggenda.nome : null,
      stadio: 'baby',
      stats: {
        fame: benessere,
        igiene: benessere,
        salute: benessere,
        felicita: benessere,
        energia: benessere
      },
      rpg: rpg,
      pastiOggi: [],
      pastiIeri: [],
      nascita: Date.now(),
      // Evoluzione baby->teen (PROTOTIPO 2, GDD "Ciclo di vita"/PROTOTIPO-2.md punto 1):
      // giorniVita conta i giorni DI GIOCO vissuti (incrementato ad ogni "nuovo giorno", v.
      // care.dailyLogin), non i giorni di calendario reale — cosi' il debug "Nuovo giorno" lo
      // fa avanzare ed e' testabile senza aspettare la mezzanotte vera.
      giorniVita: 0,
      // M17 "Pimp My Pet" (modifica permanente all'evoluzione teen): modSprite = chiave della
      // modifica scelta (MOD_SPR in sprites.js, es. 'turbina'), disegnata sul pet da
      // drawOverlayEquip finche' e' valorizzata; null = nessuna modifica. teenIntroFatto = flag che
      // impedisce di riproporre la schermata di scelta piu' di una volta (v. mostraTeenIntro in ui.js).
      modSprite: null,
      teenIntroFatto: false,
      // Talenti (PROTOTIPO 2, Blocco 9, content/talenti.md): array cumulativo, 1 elemento alla
      // nascita + 1 alla evoluzione teen (v. controllaEvoluzione sotto). L'estrazione stessa
      // (PETQ.talenti.estrai) legge PETQ.content.data + PETQ.rng, nessuno stato di partita
      // necessario per lei; l'assegnazione avviene qui direttamente sul pet appena creato.
      talenti: []
    };

    assegnaTalentoNascita(pet);

    // Perk CASA (P3, Grandi Imprese, talenti.js sezione PERK CASA): bonus "alla nascita" di TUTTI
    // i perk di ritiro sbloccati dalla casa (es. Mascellone +2 Forza, Orgoglio del Principe +2
    // alla stat firma di QUESTO pet), sommati UNA volta qui alla creazione. Difensivo: se
    // PETQ.talenti non e' ancora pronto o `state`/perkCasa mancano, bonusNascitaPerkCasa ritorna
    // tutti zeri (nessun bonus), stesso principio di assegnaTalentoNascita sopra.
    if (window.PETQ.talenti && typeof PETQ.talenti.bonusNascitaPerkCasa === 'function') {
      var bonusCasa = PETQ.talenti.bonusNascitaPerkCasa(state, statFirma);
      // Tetto per stadio (v. aggiungiStat sopra): anche i bonus "alla nascita" passano dal
      // cancello unico, per coerenza — un pet appena creato e' gia' in stadio 'baby' (v. sotto),
      // quindi il suo tetto vale da subito.
      aggiungiStat(pet, 'forza', bonusCasa.forza || 0);
      aggiungiStat(pet, 'intelligenza', bonusCasa.intelligenza || 0);
      aggiungiStat(pet, 'velocita', bonusCasa.velocita || 0);
      aggiungiStat(pet, 'carisma', bonusCasa.carisma || 0);
    }

    // Leggenda: +3 FISSO alla stat firma DEL PERSONAGGIO (v. LEGGENDE_INFO sopra), sommato DOPO
    // la generazione base e i perk casa (decisione brief). Puo' essere una stat diversa da quella
    // gia' bonusata da statFirma/bonusCasa sopra (quella e' generica della personalita', usata
    // anche da "Orgoglio del Principe"): e' voluto, la firma del personaggio e' un'altra cosa.
    if (infoLeggenda) {
      var statFirmaLeggenda = infoLeggenda.statFirma;
      aggiungiStat(pet, statFirmaLeggenda, 3);
    }

    return pet;
  }

  // Estrae 1 talento dalla terna 'nascita' della personalita' del pet (pesi 45/45/10, v.
  // talenti.js estrai/_estraiDaTerna) e lo aggiunge a pet.talenti. Guardia difensiva se il
  // modulo PETQ.talenti non e' ancora caricato (ordine script in index.html) o il content non
  // e' pronto: non blocca la creazione del pet, semplicemente il pet nasce senza talenti (si
  // puo' rimediare con "Ri-tira talenti" in debug una volta caricato tutto).
  function assegnaTalentoNascita(pet) {
    if (!pet || !window.PETQ.talenti || typeof PETQ.talenti.estrai !== 'function') {
      console.warn('PETQ.pet: PETQ.talenti non disponibile, il pet nasce senza talento (nascita)');
      return;
    }
    var talento = PETQ.talenti.estrai(pet.personalita, 'nascita');
    if (talento) pet.talenti.push(talento);
  }

  // soglie/valori malus condizioni Salute: da bilanciamento.md sezione "Sistema Salute" ->
  // "Malus condizioni". Il parser di content.js non mappa ancora questi numeri (righe non
  // etichettate in modo univoco per numeroDaEtichetta), quindi qui usiamo i default scritti
  // nel file come fallback fisso, con nota esplicita: se si vuole renderli configurabili va
  // esteso parseBilanciamento in content.js con lo stesso pattern delle altre righe.
  // energiaBassaOre/Malus: punto 8 (aggiunta fondatore) — stesso pattern di fame/igiene basse:
  // lo sfinimento prolungato (Energia < soglia critica per 6h+ di gioco) ammala il pet, una
  // bella dormita lo risana (il risveglio riporta Energia alta -> il malus sparisce da solo).
  var MALUS_CONDIZIONI = {
    fameBassaOre: 6, fameBassaMalus: 15,
    igieneBassaOre: 6, igieneBassaMalus: 15,
    energiaBassaOre: 6, energiaBassaMalus: 15,
    poopSoglia: 2, poopMalus: 10,
    dietaSquilibrataMalus: 10,
    capTotale: 50
  };

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  // spawn dei bisogni (ritmo cura, playtest v2 — v. bilanciamento.md "decadimento/note"):
  // legati alla DIGESTIONE: 60-90 minuti di gioco dopo OGNI pasto, spawn quasi garantito
  // (p=0.9, flag digerito sul pasto), piu' un baseline casuale ridotto. Target: con 2 pasti
  // + snack ~3+ bisogni/giorno, "poco dopo mangiato". Max state.poop = 3.
  var POOP_BASE_ORA = 0.05;
  var POOP_PROB_DIGESTIONE = 0.9;
  var DIGESTIONE_ORE_MIN = 1;      // 60 minuti di gioco...
  var DIGESTIONE_ORE_EXTRA = 0.5;  // ...piu' 0-30 casuali (60-90)

  function applyDecay(pet, gameHours, state) {
    if (!pet || !(gameHours > 0)) {
      if (pet) recomputeSalute(pet, state);
      return;
    }

    // Orologio di gioco: NON avanza piu' qui dentro (fix "il tempo non passa a casa vuota",
    // fondatore, 31 lug 2026). L'orologio appartiene alla CASA, non al pet: se applyDecay va in
    // return prima di arrivare qui (pet=null, guardia sopra), l'orologio doveva comunque
    // avanzare. Ora e' main.js (applicaDecadimentoOffline/tick) a chiamare SEMPRE
    // PETQ.clock.avanzaOrologio PRIMA di invocare applyDecay, guardato solo sull'esistenza del
    // pet per la parte di decadimento vera e propria — cosi' l'orologio avanza anche a casa
    // vuota mentre il decadimento delle stat resta (giustamente) legato al pet che c'e'.
    // V. clock.js avanzaOrologio per i dettagli su wrap/migrazione.

    // Sonno (GDD "Energia e sonno"): mentre il pet dorme TUTTE le stat sono in pausa,
    // niente decadimento di sorta (stessa regola della "notte" gia' esistente in clock.js,
    // qui estesa esplicitamente al ciclo sonno del pet). Il risveglio lo gestisce
    // controllaSonno/completaSonno, chiamato separatamente dal tick (v. main.js/ui.js).
    // Le "ore dormite" si accumulano qui in ore di GIOCO (stesso delta dell'orologio sopra),
    // non ore reali: cosi' anche il sonno risente del moltiplicatore debug.
    if (state && state.sonno) {
      var esSonno = bilEnergiaSonno();
      var maxSonnoOre = (state.sonno.modalita === 'riposino') ? esSonno.riposinoDurataMax : esSonno.sveglioAutonomoOre;
      var giaDormite = state.sonno.oreDormite || 0;
      var oreAllaSveglia = maxSonnoOre - giaDormite;
      if (oreAllaSveglia >= gameHours) {
        state.sonno.oreDormite = giaDormite + gameHours;
        return;
      }
      // Fix "tenuto spento molte ore: il tempo ha smesso di scorrere" (fondatore, 17 lug
      // 2026): prima l'INTERO delta offline finiva in oreDormite — dormita senza fine, stat
      // congelate per tutta l'assenza (ogni notte il pet si "risvegliava" identico a com'era
      // andato a letto). Ora dorme SOLO le ore che mancano alla sveglia autonoma, si sveglia
      // qui con lo stesso esito di controllaSveglia (risolviRisveglio: energia, sonno=null),
      // e le ore RIMANENTI proseguono sotto col decadimento normale da sveglio.
      if (oreAllaSveglia > 0) {
        state.sonno.oreDormite = giaDormite + oreAllaSveglia;
      } else {
        oreAllaSveglia = 0;
      }
      // TERZA via di risveglio, ed e' la PIU' FREQUENTE: scatta ogni volta che il tempo avanza a
      // blocchi piu' lunghi del sonno rimasto — recupero offline al rientro nell'app, pannello
      // debug, primo tick dopo un periodo in background. Le altre due sono controllaSveglia
      // (chiamata da main.js) e controllaSonnoScaduto (ui.js, percorso manuale "Sveglia").
      // Anche qui l'esito va DEPOSITATO e non buttato: senza questa riga il fumetto del risveglio
      // e le monete notturne sparivano proprio nel caso piu' comune, mentre le altre due vie
      // erano gia' state sistemate — un fix su due punti su tre sembra funzionare finche' non
      // provi il terzo. Lo consuma ui.js controllaRisveglioPendente.
      var esitoRisveglio = risolviRisveglio(state, state.sonno.oreDormite, false);
      if (esitoRisveglio && esitoRisveglio.ok) state.risveglioEsitoGiorno = esitoRisveglio;
      gameHours = gameHours - oreAllaSveglia;
      if (!(gameHours > 0)) {
        recomputeSalute(pet, state);
        return;
      }
      // prosegue col decadimento normale: il pet e' ormai sveglio per le ore restanti
    }

    // Allenamento (bilanciamento.md "Durata allenamento", decisione fondatore: attivita' a
    // tempo, non piu' salto istantaneo): a differenza del sonno, il pet e' SVEGLIO mentre si
    // allena, quindi il decadimento normale delle stat CONTINUA sotto (niente return qui) —
    // accumuliamo solo oreFatte in ore di GIOCO, stesso pattern di state.sonno.oreDormite,
    // cosi' anche l'allenamento e' accelerato dal debug ×60/×600. Il completamento (oreFatte
    // >= oreTot) e' controllato da controllaAllenamentoScaduto, chiamato dal tick/boot come
    // controllaSveglia/controllaMissioneScaduta.
    if (state && state.allenamento) {
      state.allenamento.oreFatte = (state.allenamento.oreFatte || 0) + gameHours;
    }
    // Passeggiata serale: stesso pattern dell'allenamento (il pet e' fuori ma il tempo scorre;
    // completamento via controllaPasseggiataScaduta dal tick).
    if (state && state.passeggiata) {
      state.passeggiata.oreFatte = (state.passeggiata.oreFatte || 0) + gameHours;
    }
    // Gioco nel salone (richiesta fondatore 8 lug 2026: "il gioco coi giocattoli duri 20 min"):
    // attivita' a tempo come allenamento/passeggiata, completata da controllaGiocoScaduto.
    if (state && state.gioco) {
      state.gioco.oreFatte = (state.gioco.oreFatte || 0) + gameHours;
    }

    var bil = bilanciamento();
    var dec = bil.decadimento || { fame: 6, igiene: 8, felicita: 2 };
    var soglie = bil.soglie || { critica: 25, magro: 30, sporco: 30, malusSalute: 40 };
    var es = bilEnergiaSonno();

    pet.stats.fame = clamp(pet.stats.fame - dec.fame * gameHours, 0, 100);
    // Talenti (P3 BATCH 4, "igiene_min=50", Roombo): l'Igiene non scende mai sotto il minimo
    // garantito (0 = nessun minimo, default). Clampato sul MINIMO invece che 0 solo per questo
    // decadimento: altri punti che abbassano l'Igiene (care.wash/eventi passeggiata la ALZANO,
    // non la abbassano, quindi non serve toccarli) restano invariati.
    var igieneMin = (state && PETQ.talenti && PETQ.talenti.igieneMinima) ? PETQ.talenti.igieneMinima(state) : 0;
    var caloIgiene = dec.igiene * gameHours;
    // Vasca idromassaggio (arredo 'igiene_extra_lavaggio'): il lavaggio lascia un CREDITO di Igiene
    // (state.igieneCredito, scritto da care.wash) perche' la stat e' gia' al tetto di 100 e i punti
    // extra andrebbero persi. Il credito assorbe il calo successivo prima che tocchi la stat: e' il
    // "+5 Igiene extra a ogni lavaggio" reso davvero percepibile (circa mezz'ora di gioco pulita in
    // piu'). Nessun credito (nessuna vasca piazzata) = comportamento identico a prima.
    if (state && typeof state.igieneCredito === 'number' && state.igieneCredito > 0 && caloIgiene > 0) {
      var assorbito = Math.min(state.igieneCredito, caloIgiene);
      state.igieneCredito = state.igieneCredito - assorbito;
      caloIgiene = caloIgiene - assorbito;
    }
    pet.stats.igiene = clamp(pet.stats.igiene - caloIgiene, igieneMin, 100);

    if (typeof pet.stats.energia !== 'number') pet.stats.energia = 70;
    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo A, "energia_decay=x0.5", Energico): moltiplicatore
    // sul decadimento Energia, letto a runtime dai talenti del pet (1 se nessuno lo tocca).
    // applyDecay riceve `state` solo come parametro opzionale (v. firma sopra: alcuni chiamanti
    // storici passano solo `pet`), quindi la guardia su state e' necessaria.
    var decayMult = (state && PETQ.talenti && PETQ.talenti.energiaDecayMult) ?
      PETQ.talenti.energiaDecayMult(state) : 1;
    // Caricatore da Viaggio piazzato (premio 7 giorni di carica): rallenta il calo del 25%.
    // MOLTIPLICATIVO con quello dei talenti apposta — sommando/sottraendo, Energico (x0,5) piu'
    // caricatore avrebbe azzerato del tutto il decadimento (v. arredi.js energiaDecayMultArredi).
    if (state && PETQ.arredi && PETQ.arredi.energiaDecayMultArredi) {
      decayMult = decayMult * PETQ.arredi.energiaDecayMultArredi(state);
    }
    // Perk CASA (P3, "Reattore Arc" m72): l'Energia non scende mai sotto il minimo garantito (0 =
    // nessun minimo, default), stesso pattern di igieneMin/Roombo appena sopra ma per l'Energia.
    var energiaMin = (state && PETQ.talenti && PETQ.talenti.energiaMinima) ? PETQ.talenti.energiaMinima(state) : 0;
    pet.stats.energia = clamp(pet.stats.energia - es.decadimento * gameHours * decayMult, energiaMin, 100);

    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "igiene_felicita=inverti", Idrofobico): relazione
    // Igiene<->Felicita' invertita SOLO per questo pet. Normalmente fame<critica O igiene<critica
    // aggiungono UN malus Felicita' extra fisso (+5/h, non cumulativo se entrambe basse insieme
    // — comportamento originale preservato qui sotto per il caso non-Idrofobico). Con Idrofobico
    // separiamo i due contributi: la fame bassa continua a dare il malus normale, l'igiene bassa
    // NON da' piu' malus (niente extra da sporco) e in piu' da' un piccolo BONUS Felicita' (lo
    // sporco rende felice, v. talenti.md). Il malus SALUTE da sporco (v. malusCondizioni
    // "igieneBassaMalus" sopra, invariato) resta com'e' apposta: e' il contrappeso di design
    // (talenti.md "il malus Salute da sporco resta"), qui tocchiamo SOLO il ramo Felicita'.
    var igieneInvertita = (state && PETQ.talenti && PETQ.talenti.igieneFelicitaInvertita) ?
      PETQ.talenti.igieneFelicitaInvertita(state) : false;

    var calofelicita = dec.felicita * gameHours;
    if (!igieneInvertita) {
      // comportamento originale: malus unico (no doppio conteggio se fame E igiene sono basse insieme)
      if (pet.stats.fame < soglie.critica || pet.stats.igiene < soglie.critica) {
        calofelicita += 5 * gameHours;
      }
    } else {
      // Idrofobico: i due contributi si calcolano separatamente (la fame bassa resta un malus
      // normale, l'igiene bassa diventa un bonus) e possono sommarsi se entrambe sono basse.
      if (pet.stats.fame < soglie.critica) {
        calofelicita += 5 * gameHours;
      }
      if (pet.stats.igiene < soglie.critica) {
        calofelicita -= 5 * gameHours;
      }
    }
    // Talenti (P3 BATCH 4, "ignora_malus_energia", Il Sonno degli Ingiusti): il pet non subisce
    // il malus Felicita' da Energia bassa (bypassa SOLO questo malus, l'Energia resta comunque
    // la stat vera che decade normalmente sopra — stesso principio di ignoraRifiutoEnergia/
    // immuneMalusCondizioni: il talento dice COSA, qui si applica il COME).
    var ignoraMalusEn = (state && PETQ.talenti && PETQ.talenti.ignoraMalusEnergia) ? PETQ.talenti.ignoraMalusEnergia(state) : false;
    if (!ignoraMalusEn && pet.stats.energia < es.sogliaRifiuto) {
      calofelicita += 1 * gameHours; // GDD: sotto soglia energia, felicita' -1/h extra
    }
    pet.stats.felicita = clamp(pet.stats.felicita - calofelicita, 0, 100);

    // spawn bisogni (poop): digestione dei pasti + baseline
    if (state) {
      if (typeof state.poop !== 'number') state.poop = 0;
      var pasti = (state.pet && state.pet.pastiOggi) || [];
      for (var pi = 0; pi < pasti.length; pi++) {
        var pasto = pasti[pi];
        if (!pasto || pasto.digerito) continue;
        // difese per pasti registrati prima di questa versione (salvataggi vecchi)
        if (typeof pasto.digestioneOre !== 'number') pasto.digestioneOre = DIGESTIONE_ORE_MIN + PETQ.rng.rand() * DIGESTIONE_ORE_EXTRA;
        if (typeof pasto.oreDigerite !== 'number') pasto.oreDigerite = 0;
        pasto.oreDigerite += gameHours;
        if (pasto.oreDigerite >= pasto.digestioneOre) {
          pasto.digerito = true;
          if (state.poop < 3 && PETQ.rng.rand() < POOP_PROB_DIGESTIONE) {
            state.poop = Math.min(3, state.poop + 1);
          }
        }
      }
      var probEvento = 1 - Math.pow(1 - POOP_BASE_ORA, gameHours);
      if (state.poop < 3 && PETQ.rng.rand() < probEvento) {
        state.poop = Math.min(3, state.poop + 1);
      }

      // tracking "sotto soglia da quando": serve al malus condizioni (fame/igiene/energia < 25 per 6h+).
      // Soglia critica riusata da bilanciamento.soglie.critica (stesso valore usato altrove nel prototipo).
      // FIX playtest (8 lug 2026, "la salute sale/scende da sola a caso"): i timer erano in tempo
      // REALE (Date.now) — residuo pre-orologio unificato: a velocita' debug i malus (de)cadevano
      // scollegati da cio' che si vede. Ora sono in MINUTI DI GIOCO ASSOLUTI (v. minutiGiocoAssoluti):
      // la Salute si muove solo in sincrono con l'orologio in alto, per cause visibili.
      var sogliaMalus = (typeof soglie.critica === 'number') ? soglie.critica : 25;
      var adessoGm = minutiGiocoAssoluti(state);
      if (pet.stats.fame < sogliaMalus) {
        if (typeof state.fameBassaDaGm !== 'number') state.fameBassaDaGm = adessoGm;
      } else {
        state.fameBassaDaGm = null;
      }
      if (pet.stats.igiene < sogliaMalus) {
        if (typeof state.igieneBassaDaGm !== 'number') state.igieneBassaDaGm = adessoGm;
      } else {
        state.igieneBassaDaGm = null;
      }
      // punto 8 (aggiunta fondatore): energia bassa prolungata ammala il pet, stesso pattern.
      // Una dormita riporta l'Energia sopra soglia -> il tracking si azzera e il malus sparisce.
      if (pet.stats.energia < sogliaMalus) {
        if (typeof state.energiaBassaDaGm !== 'number') state.energiaBassaDaGm = adessoGm;
      } else {
        state.energiaBassaDaGm = null;
      }
    }

    recomputeSalute(pet, state);
  }

  // Sistema Salute v1 (bilanciamento.md): Salute = clamp(100 - Ferite - MalusCondizioni, 0, 100).
  // Le Ferite salgono SOLO da eventi espliciti (reward missione "ferite+N", vedi missions.js) e
  // scendono con la guarigione naturale (guarisciGiorno) o l'infermeria (care.cura). Rimossa la
  // vecchia media pesata dieta/pulizia/eventi: non piu' usata.
  // Minuti di gioco ASSOLUTI (non wrappano a mezzanotte): giornoGioco*1440 + gameMinutes.
  // Base dei timer "sotto soglia da quando" del malus condizioni (v. sopra/sotto).
  function minutiGiocoAssoluti(state) {
    if (!state) return 0;
    var g = (typeof state.giornoGioco === 'number') ? state.giornoGioco : 0;
    var m = (typeof state.gameMinutes === 'number') ? state.gameMinutes : 0;
    return g * 1440 + m;
  }

  function recomputeSalute(pet, state) {
    if (!pet) return;
    var ferite = (state && typeof state.ferite === 'number') ? state.ferite : 0;
    var malus = malusCondizioni(pet, state);
    pet.stats.salute = clamp(100 - ferite - malus, 0, 100);
  }

  function malusCondizioni(pet, state) {
    if (!state) return 0;
    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "immune_malus_condizioni", Anima Candida): il
    // pet non perde MAI Salute dai malus condizioni (fame/igiene/energia basse prolungate,
    // cacca accumulata, dieta squilibrata). Le stat dirette restano invariate (il pet resta
    // comunque "sporco"/"affamato" a vedersi): solo questo malus SALUTE aggiuntivo sparisce,
    // niente calcolo dei singoli malus sotto (uscita anticipata, stesso spirito di
    // energiaSottoSoglia/ignoraRifiutoEnergia: il talento dice COSA, qui si applica il COME).
    if (PETQ.talenti && PETQ.talenti.immuneMalusCondizioni && PETQ.talenti.immuneMalusCondizioni(state)) {
      return 0;
    }
    var m = 0;
    // FIX playtest 8 lug 2026: confronto in MINUTI DI GIOCO (prima Date.now = tempo reale,
    // e la Salute cambiava "a caso" rispetto all'orologio di gioco, spec. a velocita' debug).
    var adessoGm = minutiGiocoAssoluti(state);

    if (typeof state.fameBassaDaGm === 'number' &&
        (adessoGm - state.fameBassaDaGm) >= MALUS_CONDIZIONI.fameBassaOre * 60) {
      m += MALUS_CONDIZIONI.fameBassaMalus;
    }
    if (typeof state.igieneBassaDaGm === 'number' &&
        (adessoGm - state.igieneBassaDaGm) >= MALUS_CONDIZIONI.igieneBassaOre * 60) {
      m += MALUS_CONDIZIONI.igieneBassaMalus;
    }
    // Talenti (P3 BATCH 4, "ignora_malus_energia", Il Sonno degli Ingiusti): bypassa SOLO il
    // malus Salute da Energia bassa prolungata (gli altri malus condizioni restano), stesso
    // principio del bypass Felicita' in applyDecay sopra.
    var ignoraMalusEnSalute = PETQ.talenti && PETQ.talenti.ignoraMalusEnergia && PETQ.talenti.ignoraMalusEnergia(state);
    if (!ignoraMalusEnSalute && typeof state.energiaBassaDaGm === 'number' &&
        (adessoGm - state.energiaBassaDaGm) >= MALUS_CONDIZIONI.energiaBassaOre * 60) {
      m += MALUS_CONDIZIONI.energiaBassaMalus;
    }
    if (typeof state.poop === 'number' && state.poop >= MALUS_CONDIZIONI.poopSoglia) {
      m += MALUS_CONDIZIONI.poopMalus;
    }
    if (dietaSquilibrata(pet)) {
      m += MALUS_CONDIZIONI.dietaSquilibrataMalus;
    }

    return Math.min(m, MALUS_CONDIZIONI.capTotale);
  }

  // dieta squilibrata: negli ultimi 2 giorni (pastiOggi + pastiIeri) tutte le categorie mangiate
  // sono uguali, oppure sono tutte 'dolce'. Se non ci sono pasti sufficienti per giudicare, niente malus.
  function dietaSquilibrata(pet) {
    if (!pet) return false;
    var pasti = [].concat(pet.pastiOggi || [], pet.pastiIeri || []);
    if (pasti.length < 2) return false;

    var categorie = {};
    for (var i = 0; i < pasti.length; i++) {
      if (pasti[i] && pasti[i].categoria) categorie[pasti[i].categoria] = true;
    }
    var elenco = Object.keys(categorie);
    if (elenco.length === 0) return false;
    if (elenco.length === 1) return true; // monocategoria (dolce o no)

    return false;
  }

  // Guarigione naturale: -5 Ferite al primo accesso del giorno. Chiamata da PETQ.care.dailyLogin
  // (e' li' che si gestisce gia' il concetto di "nuovo giorno" nel prototipo).
  function guarisciGiorno(state) {
    if (!state) return;
    if (typeof state.ferite !== 'number') state.ferite = 0;
    state.ferite = clamp(state.ferite - 5, 0, 100);
  }

  // Soglie ciccione PER STADIO (bilanciamento.md "Soglie" -> "Variante ciccione", PROTOTIPO 2
  // punto 1: il ciccione esisteva gia' negli sprite ma non appariva mai perche' in P1 il pet
  // era sempre baby, e la regola era "mai baby"). Ora che il teen esiste diventa raggiungibile,
  // ma DEVE essere difficile da teen (decisione fondatore) e piu' facile da adulto (P3, non
  // implementato qui: struttura pronta, manca solo la voce 'adulto' quando arrivera' lo stadio).
  // baby: 'mai' (nessuna soglia rende ciccione un baby, coerente col GDD "aspetto dinamico").
  var SOGLIE_CICCIONE_PER_STADIO = {
    teen: {
      pastiGiornoSoglia: 8,           // >8 pasti/giorno (era >5 nel vecchio valore unico)
      dolciGiornoSoglia: 6,           // >6 dolci/giorno (era >3)
      sovralimentazioniSoglia: 4      // >=4 sovralimentazioni recenti cumulative (era >=2)
    },
    // adulto (P3, scheletro): soglie PIU' BASSE del teen (piu' facile diventare ciccione), stessi
    // campi/nomi del teen sopra. Valori scheletro, da tarare col fondatore quando lo stadio adulto
    // sara' giocabile davvero.
    adulto: {
      pastiGiornoSoglia: 6,            // >6 pasti/giorno
      dolciGiornoSoglia: 4,            // >4 dolci/giorno
      sovralimentazioniSoglia: 3       // >=3 sovralimentazioni recenti cumulative
    }
  };

  // regole soglie da config: media fame bassa -> magro; ciccione per-stadio (mai da baby,
  // difficile da teen, v. SOGLIE_CICCIONE_PER_STADIO sopra).
  function bodyVariant(pet) {
    if (!pet) return 'normale';
    // Leggende (P3 batch 6): aspetto FISSO, niente varianti ciccione/magro (l'icona e' l'icona,
    // v. sprites.js LEGGENDE — un solo frame per stadio, disegnato apposta per il personaggio).
    if (pet.razza === 'leggenda') return 'normale';
    var bil = bilanciamento();
    var soglieMagro = (bil.soglie && typeof bil.soglie.magro === 'number') ? bil.soglie.magro : 30;

    var pastiOggi = pet.pastiOggi || [];
    var pastiIeri = pet.pastiIeri || [];

    var dolciOggi = 0;
    for (var i = 0; i < pastiOggi.length; i++) {
      if (pastiOggi[i] && pastiOggi[i].categoria === 'dolce') dolciOggi++;
    }

    // Mai ciccione da baby (GDD "Aspetto dinamico": "NON da baby, il cucciolo non ingrassa
    // così"): la variante ciccione esiste solo dallo stadio teen in su.
    var soglieCiccione = pet.stadio && SOGLIE_CICCIONE_PER_STADIO[pet.stadio];
    if (soglieCiccione &&
        (pastiOggi.length > soglieCiccione.pastiGiornoSoglia ||
         dolciOggi > soglieCiccione.dolciGiornoSoglia ||
         (pet.sovralimentazioniRecenti || 0) >= soglieCiccione.sovralimentazioniSoglia)) {
      return 'ciccione';
    }

    var mediaFame = pet.stats ? pet.stats.fame : 100;
    if (mediaFame < soglieMagro && (pastiOggi.length + pastiIeri.length) < 2) return 'magro';
    if (mediaFame < soglieMagro) return 'magro';

    return 'normale';
  }

  // ==================== Evoluzione baby->teen (PROTOTIPO 2, punto 1) ====================
  // Trigger: baby dura 3 giorni DI GIOCO -> diventa teen. CICLO VITALE 14 GIORNI (decisione
  // fondatore 10 lug 2026, v. bilanciamento.md "Ciclo vitale"): baby 3 + teen 5 + adulto ~6.
  // La crescita stat regge perche' il giorno e' DENSO: 2 missioni + 2 allenamenti + 3 pasti-stat.
  // I "giorni di gioco" sono pet.giorniVita, incrementato in care.dailyLogin ad ogni "nuovo
  // giorno" (login giornaliero reale O debug "Nuovo giorno").
  var GIORNI_EVOLUZIONE_TEEN = 3;
  // teen->adulto: 8 giorni DI GIOCO (baby 3 + teen 5). Stesso contatore pet.giorniVita.
  var GIORNI_EVOLUZIONE_ADULTO = 8;

  // Controlla se il pet deve evolvere (baby -> teen). Ritorna true e MUTA pet.stadio se la
  // condizione e' soddisfatta, altrimenti false e non tocca nulla. Va richiamata dopo ogni
  // avanzamento di giorniVita (v. care.dailyLogin) e dal tick/boot (stesso pattern idempotente
  // di controllaSveglia/controllaCrolloAutomatico sopra), cosi' la UI puo' intercettarla e
  // mostrare la schermata dedicata (v. ui.js controllaEvoluzioneScaduta).
  //
  // TODO (da decidere col fondatore): l'evoluzione oggi NON modifica le statistiche (benessere
  // né RPG) — solo stadio + aspetto (bodyVariant ora vede 'teen') + battuta. Se in futuro si
  // vuole un bonus/malus all'evoluzione (es. +1 RPG, reset piccolo benessere, ecc.) va applicato
  // QUI, subito dopo il cambio stadio, con una sezione dedicata in bilanciamento.md.
  function controllaEvoluzione(pet) {
    if (!pet) return false;

    if (pet.stadio === 'baby') {
      var giorniTeen = (typeof pet.giorniVita === 'number') ? pet.giorniVita : 0;
      if (giorniTeen < GIORNI_EVOLUZIONE_TEEN) return false;

      pet.stadio = 'teen';
      // TODO stat evoluzione: nessuna modifica a pet.stats/pet.rpg per ora (solo stadio+aspetto
      // +battuta, v. commento sopra). Lasciato volutamente senza codice fino a decisione fondatore.

      // Talenti (PROTOTIPO 2, Blocco 9): all'evoluzione teen si estrae 1 talento dalla terna
      // 'teen' della personalita' e si AGGIUNGE (cumulativo) a pet.talenti, che gia' contiene il
      // talento-nascita: un teen ha sempre 2 talenti attivi insieme (v. talenti.md "Cumulativi").
      if (!Array.isArray(pet.talenti)) pet.talenti = [];
      if (window.PETQ.talenti && typeof PETQ.talenti.estrai === 'function') {
        var talentoTeen = PETQ.talenti.estrai(pet.personalita, 'teen');
        if (talentoTeen) pet.talenti.push(talentoTeen);
      } else {
        console.warn('PETQ.pet: PETQ.talenti non disponibile, evoluzione senza talento teen');
      }

      if (PETQ.audio) PETQ.audio.suona('evoluzione'); // evoluzione baby->teen avvenuta davvero
      return true;
    }

    // Scheletro stadio adulto (P3): stesso pattern di baby->teen sopra, soglia
    // GIORNI_EVOLUZIONE_ADULTO e terna 'adulto' invece di 'teen'.
    if (pet.stadio === 'teen') {
      var giorniAdulto = (typeof pet.giorniVita === 'number') ? pet.giorniVita : 0;
      if (giorniAdulto < GIORNI_EVOLUZIONE_ADULTO) return false;

      pet.stadio = 'adulto';
      // TODO stat evoluzione: stessa scelta di design di baby->teen, nessuna modifica a
      // pet.stats/pet.rpg per ora (solo stadio+aspetto+battuta).

      // Talenti: all'evoluzione adulto si estrae 1 talento dalla terna 'adulto' della
      // personalita' e si AGGIUNGE (cumulativo) a pet.talenti, che gia' contiene nascita+teen:
      // un adulto ha sempre 3 talenti attivi insieme.
      if (!Array.isArray(pet.talenti)) pet.talenti = [];
      if (window.PETQ.talenti && typeof PETQ.talenti.estrai === 'function') {
        var talentoAdulto = PETQ.talenti.estrai(pet.personalita, 'adulto');
        if (talentoAdulto) pet.talenti.push(talentoAdulto);
      } else {
        console.warn('PETQ.pet: PETQ.talenti non disponibile, evoluzione senza talento adulto');
      }

      if (PETQ.audio) PETQ.audio.suona('evoluzione'); // evoluzione teen->adulto avvenuta davvero
      return true;
    }

    return false;
  }

  // Debug "Evolvi ora (stadio successivo)" (P3, scheletro stadio adulto): forza l'evoluzione del
  // pet in casa allo stadio successivo (baby->teen o teen->adulto) SENZA aspettare i giorni,
  // riusando ESATTAMENTE la stessa logica/mutazioni di controllaEvoluzione (stadio + talento
  // estratto): portiamo pet.giorniVita alla soglia richiesta e richiamiamo controllaEvoluzione,
  // stesso trucco gia' usato dal bottone "Evolvi ora" esistente in ui.js per baby->teen. Se il
  // pet e' gia' adulto (nessuno stadio successivo nel prototipo) non fa nulla e ritorna false.
  function _debugEvolvi(state) {
    if (!state || !state.pet) return false;
    var pet = state.pet;
    if (pet.stadio === 'adulto') return false;
    if (pet.stadio === 'baby') {
      pet.giorniVita = GIORNI_EVOLUZIONE_TEEN;
    } else if (pet.stadio === 'teen') {
      pet.giorniVita = GIORNI_EVOLUZIONE_ADULTO;
    } else {
      return false; // stadio non riconosciuto: nessuna soglia nota, non tocchiamo nulla
    }
    return controllaEvoluzione(pet);
  }

  // Debug "Ri-tira talenti" (v. ui.js pannello ?debug): ri-estrae DA CAPO i talenti del pet
  // rispettando lo stadio attuale — 1 (nascita) se baby, 2 (nascita+teen) se teen, 3
  // (nascita+teen+adulto) se adulto — cosi' si possono provare combinazioni diverse senza dover
  // far rinascere/evolvere il pet daccapo. Sostituisce interamente pet.talenti (non aggiunge
  // alle estrazioni precedenti).
  function ritiraTalenti(pet) {
    if (!pet || !window.PETQ.talenti || typeof PETQ.talenti.estrai !== 'function') return false;
    var nuovi = [];
    var nascita = PETQ.talenti.estrai(pet.personalita, 'nascita');
    if (nascita) nuovi.push(nascita);
    if (pet.stadio === 'teen' || pet.stadio === 'adulto') {
      var teen = PETQ.talenti.estrai(pet.personalita, 'teen');
      if (teen) nuovi.push(teen);
    }
    if (pet.stadio === 'adulto') {
      var adulto = PETQ.talenti.estrai(pet.personalita, 'adulto');
      if (adulto) nuovi.push(adulto);
    }
    pet.talenti = nuovi;
    return true;
  }

  // ==================== VALIGIA / PARTENZA (PROTOTIPO 2, Blocco 2 / GDD "Ciclo di vita: uscite")
  // ===============================================================================================
  // Ciclo (design VINCOLANTE, docs/PROTOTIPO-2.md "Blocco 2 — Partenza (valigia)"):
  //   normale --(2 giorni critici consecutivi, solo teen)--> FASE VALIGIA
  //   FASE VALIGIA --(rimedio: stat sopra soglia al nuovo giorno)--> normale (battuta 'rientro')
  //   FASE VALIGIA --(ancora critico al nuovo giorno successivo)--> PARTENZA (battuta 'addio')
  //   PARTITO --("Fai ammenda", 50 monete)--> normale (Salute/Felicita' a 50, battuta 'rientro')
  //
  // Stato (migrazione: null/0 sui salvataggi vecchi, v. save.js/main.js):
  //   state.valigiaTrig = { fel, sal, doppio }  -> per ciascun trigger, da quanti NUOVI GIORNI
  //                                                consecutivi la condizione e' vera (reset a 0
  //                                                appena rientra sopra soglia).
  //   state.valigia     = null | { daGiorno: giorniVita }  -> fase valigia attiva; daGiorno = il
  //                                                giorniVita a cui e' iniziata (serve per la
  //                                                finestra di rimedio, v. sotto).
  //   state.petPartito  = null | <oggetto pet>  -> il pet che se n'e' andato (state.pet viene
  //                                                svuotato alla partenza; l'ammenda lo ripristina).
  //
  // Le TRE soglie (OR — basta UNA vera per 2 giorni): Felicita'<20, Salute<20, oppure
  // Salute<35 E Felicita'<35 insieme (il "doppio malessere" moderato). Da teen in su (teen E
  // adulto, P3 scheletro), MAI baby.
  var SOGLIA_VALIGIA_FEL = 20;      // (a) Felicita' < 20
  var SOGLIA_VALIGIA_SAL = 20;      // (b) Salute < 20
  var SOGLIA_VALIGIA_DOPPIO = 35;   // (c) Salute < 35 E Felicita' < 35 insieme
  var GIORNI_TRIGGER_VALIGIA = 2;   // 2 giorni di gioco consecutivi -> fase valigia
  // Finestra di rimedio: quanti NUOVI GIORNI di gioco il pet resta in fase valigia (ultimo
  // avvertimento) prima di partire, se non rimedia. 1 = al PRIMO nuovo giorno dopo l'ingresso
  // in fase valigia si decide (rientro se rimediato, partenza altrimenti). Proposta del brief.
  var GIORNI_FINESTRA_RIMEDIO = 1;
  // Ammenda (Blocco 2, recupero minimo — il pianeta/lettera sono un batch successivo): costo e
  // stat di rientro. Numeri dal brief; monetePartenza (50) e' anche in bilanciamento.md ma qui
  // usiamo una costante dedicata cosi' il costo dell'ammenda e' indipendente dal saldo iniziale.
  var COSTO_AMMENDA = 50;
  var STAT_RIENTRO_AMMENDA = 50;    // Salute e Felicita' riportate a 50 al ritorno

  // true se lo STATO di cura del pet e' "critico" secondo almeno una delle tre soglie valigia.
  // Usata sia per contare i giorni consecutivi (trigger) sia per decidere rimedio/partenza in
  // fase valigia (il "rimedio" e' semplicemente: NON piu' critico).
  function condizioneValigiaCritica(pet) {
    if (!pet || !pet.stats) return false;
    var fel = pet.stats.felicita;
    var sal = pet.stats.salute;
    if (fel < SOGLIA_VALIGIA_FEL) return true;                                  // (a)
    if (sal < SOGLIA_VALIGIA_SAL) return true;                                  // (b)
    if (sal < SOGLIA_VALIGIA_DOPPIO && fel < SOGLIA_VALIGIA_DOPPIO) return true; // (c)
    return false;
  }

  function inFaseValigia(state) {
    return !!(state && state.valigia);
  }

  function petPartito(state) {
    return !!(state && state.petPartito);
  }

  // Garantisce la struttura dei contatori trigger (migrazione difensiva).
  function assicuraValigiaTrig(state) {
    if (!state) return { fel: 0, sal: 0, doppio: 0 };
    if (!state.valigiaTrig || typeof state.valigiaTrig !== 'object') {
      state.valigiaTrig = { fel: 0, sal: 0, doppio: 0 };
    }
    if (typeof state.valigiaTrig.fel !== 'number') state.valigiaTrig.fel = 0;
    if (typeof state.valigiaTrig.sal !== 'number') state.valigiaTrig.sal = 0;
    if (typeof state.valigiaTrig.doppio !== 'number') state.valigiaTrig.doppio = 0;
    return state.valigiaTrig;
  }

  function entraFaseValigia(state) {
    if (!state || !state.pet) return false;
    var giorni = (typeof state.pet.giorniVita === 'number') ? state.pet.giorniVita : 0;
    state.valigia = { daGiorno: giorni };
    // azzera i contatori trigger: la fase valigia e' iniziata, il conteggio "verso la valigia"
    // non serve piu' (il prossimo check e' rimedio-vs-partenza, non piu' accumulo).
    state.valigiaTrig = { fel: 0, sal: 0, doppio: 0 };
    return true;
  }

  // Uscita dalla fase valigia per RIMEDIO (il giocatore ha risollevato le stat): torna tutto
  // normale, i contatori restano a zero. La battuta 'rientro' la mostra la UI.
  function esciFaseValigia(state) {
    if (!state) return false;
    state.valigia = null;
    state.valigiaTrig = { fel: 0, sal: 0, doppio: 0 };
    return true;
  }

  // Partenza: il pet lascia la casa. Salva l'oggetto pet in state.petPartito e SVUOTA lo stato
  // attivo (state.pet = null), cosi' la casa mostra la schermata "pet partito". Azzera anche le
  // strutture legate al pet in casa (sonno/allenamento/missione) per non lasciare stato rotto.
  // La schermata addio (battuta 'addio' + flavor per razza) la mostra la UI, che chiama questa
  // funzione DOPO aver letto pet/battuta.
  function partePet(state) {
    if (!state || !state.pet) return false;
    state.petPartito = state.pet;
    state.pet = null;
    state.valigia = null;
    state.valigiaTrig = { fel: 0, sal: 0, doppio: 0 };
    state.sonno = null;
    state.allenamento = null;
    state.missione = null;
    state.passeggiata = null;
    state.gioco = null;
    return true;
  }

  // Vero se una qualsiasi delle 5 attivita' a tempo del pet e' in corso (stesso identico
  // controllo di ui.petOccupatoPerGioco — duplicato qui invece di richiamare ui.js perche' pet.js
  // sta SOTTO nella catena di dipendenze e non deve dipendere dal livello UI). Usata SOLO per
  // rimandare la partenza in valutaValigiaNuovoGiorno, v. sotto.
  // Attivita' che meritano di RIMANDARE la partenza per valigia: quelle con un ESITO che il
  // giocatore sta aspettando (una missione da 2h, un allenamento, una passeggiata, una sessione di
  // gioco). Farle sparire senza risolverle e' la cosa che il rinvio deve evitare.
  //
  // Il SONNO e' escluso di proposito, ed e' il punto che decide se questo rinvio serve a qualcosa:
  // il crollo automatico e' alle 23 di gioco e dura ~8h, quindi ATTRAVERSA la mezzanotte — cioe'
  // esattamente l'istante in cui la partenza viene valutata. Contando il sonno, l'unico rinvio
  // concesso se lo mangerebbe quasi sempre il pet che dorme (stato normalissimo a quell'ora),
  // e la missione da proteggere resterebbe scoperta al giro dopo. Il sonno inoltre non ha un
  // premio in sospeso paragonabile: se il pet parte, non c'e' nessun esito che vada perduto.
  function attivitaInCorso(state) {
    return !!(state && (state.missione || state.allenamento ||
      state.passeggiata || state.gioco));
  }

  // Valuta il ciclo valigia AL NUOVO GIORNO (chiamata da care.dailyLogin, dopo l'avanzamento di
  // giorniVita). Ritorna un "evento" per la UI o null se non succede nulla di visibile:
  //   { tipo: 'valigia' }   -> il pet e' appena ENTRATO in fase valigia (mostra valigetta+notifica)
  //   { tipo: 'rientro' }   -> era in fase valigia e ha RIMEDIATO (mostra battuta rientro)
  //   { tipo: 'partenza' }  -> era in fase valigia e non ha rimediato -> PARTE (mostra addio)
  //   null                  -> nessun cambiamento (accumulo trigger o nulla)
  // Regole: da teen in su (teen e adulto, mai baby); se il pet e' gia' partito non fa nulla.
  function valutaValigiaNuovoGiorno(state) {
    if (!state || !state.pet) return null;
    var pet = state.pet;
    assicuraValigiaTrig(state);

    // Baby: MAI valigia (GDD). Azzeriamo comunque i contatori cosi' non "eredita" giorni critici
    // accumulati da baby quando poi diventa teen (i 2 giorni devono essere da teen). Vale da teen
    // in su (teen E adulto, P3 scheletro): solo il baby ne e' escluso.
    if (pet.stadio !== 'teen' && pet.stadio !== 'adulto') {
      state.valigiaTrig = { fel: 0, sal: 0, doppio: 0 };
      // per sicurezza: un baby non puo' essere in fase valigia (non ci entra mai), ma se un
      // salvataggio incoerente lo fosse, lo togliamo silenziosamente.
      if (state.valigia) state.valigia = null;
      return null;
    }

    var giorni = (typeof pet.giorniVita === 'number') ? pet.giorniVita : 0;

    // --- Gia' in fase valigia: finestra di rimedio ---
    if (state.valigia) {
      var daGiorno = (typeof state.valigia.daGiorno === 'number') ? state.valigia.daGiorno : giorni;
      // Non e' ancora passato abbastanza tempo in fase valigia: resta in attesa (ultimo
      // avvertimento ancora in corso). Con GIORNI_FINESTRA_RIMEDIO=1, alla PRIMA valutazione
      // del nuovo giorno dopo l'ingresso (giorni > daGiorno) si decide.
      if ((giorni - daGiorno) < GIORNI_FINESTRA_RIMEDIO) {
        return null;
      }
      if (!condizioneValigiaCritica(pet)) {
        esciFaseValigia(state);
        return { tipo: 'rientro' };
      }
      // Partenza in vista, ma un'attivita' a tempo e' in corso (missione/allenamento/passeggiata/
      // gioco — il SONNO e' escluso apposta, v. attivitaInCorso sopra per il perche'):
      // farlo partire ADESSO la cancellerebbe senza risolverla (nessun esito,
      // nessuna ricompensa, nessuna spiegazione — il difetto originale). Rimandiamo di UN
      // controllo (il prossimo nuovo giorno): l'attivita' arriva alla sua conclusione naturale
      // tramite i controlli a tick gia' esistenti (controllaMissioneScaduta e affini in ui.js/
      // main.js), poi qui si ridecide da capo su uno stato pulito. UN SOLO rinvio (state.valigia.
      // rimandata): senza questo limite un giocatore che tiene SEMPRE un'attivita' in coda
      // terrebbe il pet in fase valigia all'infinito. Con l'unico rinvio concesso, se
      // un'attivita' e' ancora in corso al controllo successivo si parte comunque (stesso
      // comportamento di oggi: l'attivita' in corso in quel momento viene persa, ma e' il caso
      // limite gia' preventivato, non piu' quello comune).
      if (attivitaInCorso(state) && !state.valigia.rimandata) {
        state.valigia.rimandata = true;
        return null;
      }
      partePet(state);
      return { tipo: 'partenza' };
    }

    // --- Non in fase valigia: accumulo dei contatori trigger ---
    var t = state.valigiaTrig;
    var fel = pet.stats.felicita;
    var sal = pet.stats.salute;

    t.fel = (fel < SOGLIA_VALIGIA_FEL) ? (t.fel + 1) : 0;
    t.sal = (sal < SOGLIA_VALIGIA_SAL) ? (t.sal + 1) : 0;
    t.doppio = (sal < SOGLIA_VALIGIA_DOPPIO && fel < SOGLIA_VALIGIA_DOPPIO) ? (t.doppio + 1) : 0;

    if (t.fel >= GIORNI_TRIGGER_VALIGIA ||
        t.sal >= GIORNI_TRIGGER_VALIGIA ||
        t.doppio >= GIORNI_TRIGGER_VALIGIA) {
      entraFaseValigia(state);
      return { tipo: 'valigia' };
    }

    return null;
  }

  // Debug "Forza valigia": entra subito in fase valigia (se teen/adulto e non gia' in
  // valigia/partito).
  function debugForzaValigia(state) {
    if (!state || !state.pet) return false;
    if (state.pet.stadio !== 'teen' && state.pet.stadio !== 'adulto') return false;
    if (state.valigia || state.petPartito) return false;
    return entraFaseValigia(state);
  }

  // Debug "Forza partenza": fa partire il pet SUBITO (bypassa la finestra), se c'e' un pet in casa.
  function debugForzaPartenza(state) {
    if (!state || !state.pet) return false;
    return partePet(state);
  }

  // "Fai ammenda" (Blocco 2, recupero minimo): riporta il pet partito in casa spendendo
  // COSTO_AMMENDA monete. Ripristina state.pet da state.petPartito, Salute e Felicita' a 50,
  // ricalcola la Salute, azzera le strutture valigia. Ritorna { ok, msg }. La battuta 'rientro'
  // la mostra la UI sul pet ripristinato.
  function faiAmmenda(state) {
    if (!state) return { ok: false, msg: traduci('errore interno') };
    if (!state.petPartito) return { ok: false, msg: traduci('Non c\'è nessun pet da far tornare.') };
    if ((state.coins || 0) < COSTO_AMMENDA) {
      return { ok: false, msg: traduci('Ti servono ') + COSTO_AMMENDA + traduci(' monete per farlo tornare.') };
    }
    var pet = state.petPartito;
    state.coins = (state.coins || 0) - COSTO_AMMENDA;
    state.pet = pet;
    state.petPartito = null;
    state.valigia = null;
    state.valigiaTrig = { fel: 0, sal: 0, doppio: 0 };

    // Felicita' e Salute riportate a 50. La Salute non e' una stat "diretta" (deriva da
    // Ferite + malus condizioni): la riportiamo a 50 azzerando le Ferite e resettando i
    // tracking dei malus condizioni prolungati, cosi' recomputeSalute non la ributta subito
    // sotto. La Felicita' invece si setta direttamente.
    pet.stats.felicita = STAT_RIENTRO_AMMENDA;
    state.ferite = 0;
    state.fameBassaDaGm = null;
    state.igieneBassaDaGm = null;
    state.energiaBassaDaGm = null;
    // se anche fame/igiene/energia sono a zero, portiamole almeno a 50 cosi' il pet non ripiomba
    // in condizione critica al primo tick e riparte davvero "con una seconda chance".
    if (pet.stats.salute < STAT_RIENTRO_AMMENDA) {
      if (pet.stats.fame < STAT_RIENTRO_AMMENDA) pet.stats.fame = STAT_RIENTRO_AMMENDA;
      if (pet.stats.igiene < STAT_RIENTRO_AMMENDA) pet.stats.igiene = STAT_RIENTRO_AMMENDA;
      if (typeof pet.stats.energia === 'number' && pet.stats.energia < STAT_RIENTRO_AMMENDA) pet.stats.energia = STAT_RIENTRO_AMMENDA;
    }
    recomputeSalute(pet, state);
    // clamp finale: se dopo il recompute la Salute risulta comunque sotto 50 (non dovrebbe, con
    // ferite=0 e malus azzerati), la forziamo a 50 come richiesto dal brief.
    if (pet.stats.salute < STAT_RIENTRO_AMMENDA) pet.stats.salute = STAT_RIENTRO_AMMENDA;

    return { ok: true, msg: (pet.nome || traduci('Il pet')) + traduci(' è tornato a casa.') };
  }

  // ==================== PENSIONE (PROTOTIPO 2, GDD "### 2. Pensione" — versione base P2) ==========
  // Il giocatore RITIRA il pet (scelta sua, PERMANENTE): il pet finisce sul "pianeta dei ritirati"
  // (state.pensionati, una galleria) e si ricomincia con un pet NUOVO nella STESSA casa (coins/
  // arredi/pensionati restano). Ogni pensionato lascia un'EREDITA' (+1 alla sua stat firma) ai pet
  // futuri (l'applicazione dell'eredita' e' in ui.js nuovoPetInCasa, alla creazione del nuovo pet).
  //
  // La pensione e' una via SEPARATA dalla valigia (petPartito): la valigia e' recuperabile (Fai
  // ammenda), la pensione ora e' recuperabile anche lei via "Riprendi" dal Pianeta (P3: lettera
  // scrivibile con AI). mandaInPensione svuota state.pet e azzera i campi PET-SPECIFICI legati al
  // vecchio pet, MA lascia intatto l'household (coins/arredi/pensionati/dispensa/orologio/
  // negozioSbloccato/tutorialFatto/ingrandimento/piantaEsoticaStat). Serve intatto perche' se poi
  // il giocatore "Riprende" il pensionato la casa dev'essere quella di prima (e' un ripensamento,
  // non una vita nuova). Dopo questa chiamata state.pet e' null: il chiamante (ui.js) DEVE portare
  // al Pianeta (mostraPianetaRitirati) dove si sceglie "Riprendi" o "Prendi un pet nuovo".
  //
  // La voce pushata contiene una DEEP COPY del pet COMPLETO (voce.pet), non solo i campi display:
  // serve per poterlo poi ripristinare identico via riprendiPensionato (ui.js). Vecchie voci v=41
  // (senza .pet, solo campi flat) vanno gestite difensivamente da chi legge (gallery/riprendi).
  function mandaInPensione(state) {
    if (!state || !state.pet) return null;
    var pet = state.pet;

    var voce = {
      pet: JSON.parse(JSON.stringify(pet)),                  // deep copy per ripristino integrale
      statFirma: STAT_FIRMA[pet.personalita] || 'carisma',
      giornoRitiro: (PETQ.clock && PETQ.clock.giornoCorrente) ? PETQ.clock.giornoCorrente(state) : 0,
      // Grande Impresa (P3): il pensionato porta con se' la Medaglia dell'Impresa (id+titolo,
      // mostrata sulla card del pianeta, v. ui.js cardPensionato) e un flag 'leggenda' se l'ha
      // vinta in SUPER (per la stellina/battuta sibillina — mai testo "sbloccato", regola
      // niente-spoiler). null/false se il pet non ha mai risolto un'Impresa.
      medagliaImpresa: pet.medagliaImpresa || null,
      leggenda: !!pet.impresaSuper,
      // Medaglie/vestiti/arma sono PER-PET ma vivono su state (fix audit): senza snapshot,
      // "Prendi un pet nuovo" li azzera (casa fresca) e il pensionato ripreso DOPO tornava
      // spoglio (contro l'intento "i pensionati tengono le loro medaglie nello snapshot").
      // riprendiPensionato (ui.js) li ripristina da qui; voci vecchie senza questo campo
      // restano com'erano (fallback difensivo).
      equipCasa: {
        perks: Array.isArray(state.perks) ? state.perks.slice() : [],
        indossabili: Array.isArray(state.indossabili) ? state.indossabili.slice() : [],
        indossato: state.indossato || null,
        armaEquip: state.armaEquip || null
      },
      // Stato di RUN (fix bug "Riprendi un pensionato rimette in gioco le missioni gia' fatte"):
      // missioniFatte/rotazioneMissioni/impresaRun/ultimaInvenzioneGiorno vivono su `state`, non su
      // `pet` — senza questo snapshot, riprendiPensionato (ui.js) li lasciava quelli dell'ULTIMO
      // occupante della casa, e una missione che QUESTO pet aveva gia' completato ricompariva sulla
      // mappa rifacibile (contro la regola "missioni uniche", decisione fondatore 5 lug 2026,
      // content/bilanciamento.md). COPIE, mai riferimenti (stesso motivo di pet sopra: gli oggetti
      // veri continuano a vivere e a cambiare sotto al prossimo pet in casa). riprendiPensionato
      // (ui.js) li rimette al loro posto; voci vecchie senza questo campo vengono azzerate li'
      // (ripiego difensivo, non ereditano quelle di un pet a caso).
      statoRun: {
        missioniFatte: JSON.parse(JSON.stringify(state.missioniFatte || {})),
        rotazioneMissioni: JSON.parse(JSON.stringify(state.rotazioneMissioni || {})),
        impresaRun: state.impresaRun || null,
        ultimaInvenzioneGiorno: (typeof state.ultimaInvenzioneGiorno === 'number') ? state.ultimaInvenzioneGiorno : null
      }
    };

    if (!Array.isArray(state.pensionati)) state.pensionati = [];
    state.pensionati.push(voce);

    // Perk di ritiro CASA + uovo leggendario (P3, Grandi Imprese): SOLO se questo pet ha vinto il
    // SUPER della sua Impresa (pet.impresaSuper, v. missions.js risolvi). PERSISTENTI ATTRAVERSO
    // LE RUN — mai azzerati qui ne' altrove (e' il punto del sistema, v. ui.js avviaPartita/
    // finalizzaNuovoPetInCasa che NON li toccano). La PARTENZA con valigia non passa MAI da questa
    // funzione (e' un ramo separato, v. rientroDaValigia/eseguiAmmenda): anti-farming voluto.
    // Niente duplicati in entrambi gli array (indexOf prima di push).
    if (pet.impresaSuper && pet.impresaSuper.id) {
      if (!Array.isArray(state.perkCasa)) state.perkCasa = [];
      if (state.perkCasa.indexOf(pet.impresaSuper.id) === -1) state.perkCasa.push(pet.impresaSuper.id);
      // Leggende sbloccate (P3): STESSO ciclo di vita persistente di perkCasa, ma NASCOSTO
      // (nessuna UI, v. brief): serve solo al futuro uovo leggendario (10% pet unico giocabile).
      if (!Array.isArray(state.leggendeSbloccate)) state.leggendeSbloccate = [];
      if (state.leggendeSbloccate.indexOf(pet.impresaSuper.id) === -1) state.leggendeSbloccate.push(pet.impresaSuper.id);
    }

    // svuota il pet in casa e azzera i campi PET-SPECIFICI legati al vecchio pet (non toccare
    // l'household: coins/arredi/pensionati/perkCasa/leggendeSbloccate/dispensa/gameMinutes/
    // giornoGioco/negozioSbloccato/tutorialFatto/ingrandimentoCasa/piantaEsoticaStat restano).
    state.pet = null;
    state.missione = null;
    state.sonno = null;
    state.allenamento = null;
    state.passeggiata = null;
    state.gioco = null;
    state.valigia = null;
    state.valigiaTrig = { fel: 0, sal: 0, doppio: 0 };
    state.petPartito = null;
    state.letteraPartito = null;
    state.eventoValigia = null;
    state.ferite = 0;

    return voce;
  }

  // ==================== Energia e sonno (GDD "Energia e sonno") ====================
  // state.sonno = null | { modalita: 'riposino'|'notturno', aLetto: bool, oreDormite: number }.
  // "Dormire" e' un unico gesto (drag sul letto) con due modalita' a seconda dell'OROLOGIO DI
  // GIOCO (state.gameMinutes, v. clock.js) al momento del drag: prima delle 21 -> riposino
  // (max 2h, +15 Energia/ora); dalle 21 -> sonno notturno (max 8h, Energia 100 al risveglio
  // pieno). Il crollo automatico (chi non va a letto entro le 23) e' sempre notturno.
  // Mentre dorme, applyDecay() sopra salta il decadimento delle stat MA accumula
  // state.sonno.oreDormite in ore di GIOCO (stesso delta del debug ×60/×600, cosi' anche il
  // sonno e' accelerabile). Le funzioni qui sotto gestiscono l'intero ciclo: avvio
  // (letto o crollo), controllo scadenza (sveglia autonoma / crollo automatico), risveglio
  // manuale o automatico.

  // true se il pet puo' rifiutare missione/allenamento per energia bassa (GDD: soglia 20)
  function energiaSottoSoglia(pet) {
    if (!pet || !pet.stats || typeof pet.stats.energia !== 'number') return false;
    var es = bilEnergiaSonno();
    return pet.stats.energia < es.sogliaRifiuto;
  }

  // Modalita' di sonno in base all'orologio DI GIOCO al momento del drag (GDD: prima delle
  // 21 -> riposino, dalle 21 -> notturno). Esposta per la UI (per decidere quale hint/testo
  // mostrare prima ancora di avviare il sonno).
  function modalitaSonnoOra(state) {
    var es = bilEnergiaSonno();
    var og = PETQ.clock ? PETQ.clock.oraGioco(state) : { ore: 0 };
    return (og.ore >= es.oraLetto) ? 'notturno' : 'riposino';
  }

  // Avvia il sonno: aLetto=true se portato a letto dal giocatore (drag), aLetto=false se
  // crollo automatico (alle 23, sul posto). La modalita' (riposino/notturno) si decide qui
  // in base all'orologio di gioco corrente: il crollo e' sempre notturno (e' un crollo
  // serale, non un pisolino). Non sovrascrive un sonno gia' in corso.
  function avviaSonno(state, aLetto) {
    if (!state || state.sonno) return false;
    var modalita = aLetto ? modalitaSonnoOra(state) : 'notturno';
    state.sonno = { modalita: modalita, aLetto: !!aLetto, oreDormite: 0 };
    // Unico punto in cui il pet si addormenta davvero (a letto O crollo automatico, v.
    // controllaCrolloAutomatico sopra che richiama questa stessa funzione): un solo aggancio copre
    // entrambe le strade.
    if (PETQ.audio) PETQ.audio.suona('dorme');
    return true;
  }

  // Crollo automatico (GDD): quando l'orologio DI GIOCO raggiunge le 23, se il pet e' sveglio
  // e non in missione, si addormenta sul posto (aLetto:false) senza intervento del giocatore.
  // Va richiamata dal tick di gioco (pattern controllaMissioneScaduta in ui.js: chiamata
  // periodica, idempotente perche' avviaSonno non fa nulla se state.sonno e' gia' impostato).
  function controllaCrolloAutomatico(state) {
    if (!state || state.sonno || state.missione || state.allenamento || state.passeggiata || state.gioco) return false;
    var es = bilEnergiaSonno();
    var og = PETQ.clock ? PETQ.clock.oraGioco(state) : { ore: 0 };
    if (og.ore < es.oraCrollo) return false;
    // Fix playtest (7 lug 2026, "dorme per terra anche con energia alta e non si sveglia"):
    // 1) il crollo scatta SOLO se il pet e' davvero stanco (energia sotto soglia) — con energia
    //    alta resta sveglio e decide il giocatore se metterlo a letto;
    // 2) UNA volta per notte (state.crolloGiorno): prima, svegliarlo dopo le 23 era inutile
    //    perche' il tick successivo lo faceva RI-crollare all'istante (loop insvegliabile).
    var energia = (state.pet && state.pet.stats && typeof state.pet.stats.energia === 'number') ? state.pet.stats.energia : 100;
    if (energia >= es.crolloSogliaEnergia) return false;
    var oggiCrollo = PETQ.clock && PETQ.clock.giornoCorrente ? PETQ.clock.giornoCorrente(state) : 0;
    if (state.crolloGiorno === oggiCrollo) return false; // gia' crollato stanotte: la sveglia tiene
    if (avviaSonno(state, false)) {
      state.crolloGiorno = oggiCrollo;
      return true;
    }
    return false;
  }

  // Applica gli effetti del risveglio (energia + pulizia stato sonno) e ritorna info per la UI
  // (battuta da mostrare: 'sveglia' se dormito bene, 'dormito_male' altrimenti).
  function risolviRisveglio(state, oreDormite, manuale) {
    var es = bilEnergiaSonno();
    var sonno = state.sonno || { modalita: 'notturno', aLetto: false };
    var energiaPre = (state.pet && typeof state.pet.stats.energia === 'number') ? state.pet.stats.energia : 0;
    var energiaFinale;
    var battuta;

    // Pescione Cantautore (giocattolo passivo 'sveglia_gratis', drop M16 super): svegliare il pet
    // PRIMA del tempo non applica piu' la penalita' di Energia. La penalita' non e' una sottrazione
    // ma il calcolo proporzionale alle ore dormite qui sotto, quindi si annulla facendo finta che
    // abbia dormito tutta la durata prevista (riposino: 2h piene; notturno: 8h piene). Vale SOLO
    // sulla sveglia MANUALE del giocatore: la sveglia autonoma dorme gia' tutto il suo tempo, e il
    // crollo sul posto resta punito (dormire per terra e' un'altra faccenda, v. ramo !aLetto).
    // oreEsito e' usato SOLO per calcolare Energia e battuta: oreDormite resta il dato VERO (lo
    // legge il talento Sonnambulo Agonista per la "notte piena" e lo ritorniamo alla UI).
    var oreEsito = oreDormite;
    if (manuale && sonno.aLetto && PETQ.giocattoli && PETQ.giocattoli.svegliaSenzaPenalita &&
        PETQ.giocattoli.svegliaSenzaPenalita(state)) {
      var durataPiena = (sonno.modalita === 'riposino') ? es.riposinoDurataMax : es.sveglioAutonomoOre;
      if (oreEsito < durataPiena) oreEsito = durataPiena;
    }

    if (!sonno.aLetto) {
      // crollato sul posto (mai andato a letto entro le 23): dormita scomoda, sempre lo
      // stesso esito indipendentemente da quanto e' durata (GDD: Energia 70).
      energiaFinale = es.risveglioCattivo;
      battuta = 'dormito_male';
    } else if (sonno.modalita === 'riposino') {
      // riposino: +15 Energia/ora dormita fino al cap di durata (2h piene = +30), qualunque
      // sia il momento della sveglia (non c'e' "soglia minima" per l'esito, solo per il
      // TASTO sveglia - v. eseguiSveglia in ui.js che blocca il tap prima di riposinoDurataMin).
      var oreEff = Math.min(oreEsito, es.riposinoDurataMax);
      energiaFinale = energiaPre + es.riposinoRecuperoOra * oreEff;
      battuta = (oreEsito >= es.riposinoDurataMax) ? 'sveglia' : 'dormito_male';
    } else if (oreEsito >= es.sonnoMinimoOre) {
      // sonno notturno, dormito almeno il minimo: energia piena (o proporzionale se
      // svegliato dopo il minimo ma prima del pieno di 8h)
      var frazioneNotte = Math.min(1, oreEsito / es.sveglioAutonomoOre);
      energiaFinale = Math.max(energiaPre, Math.round(es.risveglioBuono * frazioneNotte));
      battuta = 'sveglia';
    } else {
      // notturno svegliato prima del minimo (non dovrebbe accadere: il tasto Sveglia lo
      // blocca in ui.js, ma il debug "salta sonno" e altri automatismi possono comunque
      // arrivare qui): proporzionale alle ore dormite, mai sotto l'energia pre-sonno.
      var proporzionale = Math.round(es.risveglioBuono * (oreEsito / es.sonnoMinimoOre));
      energiaFinale = Math.max(energiaPre, proporzionale);
      battuta = 'dormito_male';
    }

    // Talenti (P3 BATCH 4, "sonno=sempre_pieno", Il Sonno degli Ingiusti): OGNI risveglio (crollo,
    // riposino o notturno, qualunque durata) porta l'Energia a 100 netto, AL POSTO del calcolo
    // sopra (non in aggiunta: il talento e' strettamente migliore, sostituisce l'esito). Applicato
    // qui prima del clamp finale, stesso principio di azzeraFeriteNotte (il talento e' un
    // override totale del ramo normale, non un bonus sommato).
    var semprePieno = (PETQ.talenti && PETQ.talenti.sonnoSemprePieno) ? PETQ.talenti.sonnoSemprePieno(state) : false;
    if (semprePieno) {
      energiaFinale = 100;
      battuta = 'sveglia';
    }

    if (state.pet) {
      state.pet.stats.energia = clamp(energiaFinale, 0, 100);
    }

    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "risveglio=ferite-10", Infermiere Provetto):
    // auto-cura automatica ad OGNI risveglio (manuale o autonomo, riposino o notturno — il
    // talento non distingue, v. talenti.md "1 auto-cura -10 Ferite a ogni risveglio"). Applicato
    // qui, prima di azzerare state.sonno, cosi' recomputeSalute sotto vede gia' le Ferite giuste.
    if (typeof state.ferite !== 'number') state.ferite = 0;
    var deltaFeriteRisveglio = (PETQ.talenti && PETQ.talenti.risveglioFeriteDelta) ?
      PETQ.talenti.risveglioFeriteDelta(state) : 0;
    if (deltaFeriteRisveglio !== 0) {
      state.ferite = clamp(state.ferite + deltaFeriteRisveglio, 0, 100);
    }

    // Talenti (P3 BATCH 4, "notte_piena=stat_casuale+1", Sonnambulo Agonista): al completamento
    // di un SONNO NOTTURNO PIENO (a letto, modalita' notturno, dormite almeno le ore piene di
    // sveglioAutonomoOre — non basta il minimo di sonnoMinimoOre: "pieno" = tutta la notte)
    // +1 a una stat RPG CASUALE. Il riposino e il crollo sul posto NON contano (non sono "notte
    // piena", v. talenti.md). Applicato PRIMA di azzerare state.sonno cosi' l'ultima lettura di
    // sonno.aLetto/modalita' e' ancora quella vera (sotto viene azzerato a null).
    var notteFuPiena = sonno.aLetto && sonno.modalita === 'notturno' && oreDormite >= es.sveglioAutonomoOre;
    var statBonusNotte = null;
    if (notteFuPiena && PETQ.talenti && PETQ.talenti.haSonnoNottePiena && PETQ.talenti.haSonnoNottePiena(state)) {
      var statNomiNotte = ['forza', 'intelligenza', 'velocita', 'carisma'];
      var statScelta = (PETQ.rng && typeof PETQ.rng.pick === 'function') ? PETQ.rng.pick(statNomiNotte) : statNomiNotte[0];
      if (state.pet && state.pet.rpg && typeof state.pet.rpg[statScelta] === 'number') {
        aggiungiStat(state.pet, statScelta, 1);
        statBonusNotte = statScelta;
      }
    }

    // Peluffo Ciarliero (giocattolo passivo 'notturno:monete+15'): monete al risveglio DEL MATTINO,
    // cioe' da un SONNO NOTTURNO (il riposino pomeridiano non e' un mattino, e il crollo sul posto
    // nemmeno: il pupazzo canta al pet che dorme nel letto). UNA volta per giorno di gioco
    // (state.moneteNotturneGiorno, stesso pattern per-valore di crolloGiorno/montaggioGiorno: cosi'
    // due risvegli notturni nello stesso giorno non pagano due volte).
    var moneteNotturne = 0;
    if (sonno.aLetto && sonno.modalita === 'notturno' && PETQ.giocattoli && PETQ.giocattoli.moneteRisveglio) {
      var oggiRisveglio = (PETQ.clock && PETQ.clock.giornoCorrente) ? PETQ.clock.giornoCorrente(state) : 0;
      if (state.moneteNotturneGiorno !== oggiRisveglio) {
        moneteNotturne = PETQ.giocattoli.moneteRisveglio(state);
        if (moneteNotturne > 0) {
          state.coins = (state.coins || 0) + moneteNotturne;
          state.moneteNotturneGiorno = oggiRisveglio;
        }
      }
    }

    state.sonno = null;
    recomputeSalute(state.pet, state);
    if (PETQ.audio) PETQ.audio.suona('sveglia');

    return { ok: true, energia: energiaFinale, oreDormite: oreDormite, battuta: battuta, manuale: !!manuale, statBonusNotte: statBonusNotte, moneteNotturne: moneteNotturne };
  }

  // Sveglia autonoma: controlla se il sonno ha raggiunto la sua durata massima (riposino:
  // riposinoDurataMax; notturno: sveglioAutonomoOre) e in tal caso completa il risveglio
  // automaticamente. Va richiamata dal tick/boot (pattern controllaMissioneScaduta).
  // Ritorna il risultato di risolviRisveglio oppure null se non e' ancora ora.
  function controllaSveglia(state) {
    if (!state || !state.sonno) return null;
    var es = bilEnergiaSonno();
    // Decisione fondatore (test 7 lug 2026): "dalle 21 e' SEMPRE sonno profondo" — un riposino
    // che scavalca le 21 (es. a letto alle 20:30) si CONVERTE in notturno invece di svegliare
    // il pet a sera fatta: stesso letto (aLetto invariato), le ore gia' dormite contano verso
    // le 8h del notturno. Controllato qui perche' questa funzione gira ad ogni tick.
    if (state.sonno.modalita === 'riposino') {
      var ogS = PETQ.clock ? PETQ.clock.oraGioco(state) : { ore: 0 };
      if (ogS.ore >= es.oraLetto) state.sonno.modalita = 'notturno';
    }
    var oreDormite = state.sonno.oreDormite || 0;
    var durataMax = (state.sonno.modalita === 'riposino') ? es.riposinoDurataMax : es.sveglioAutonomoOre;
    if (oreDormite >= durataMax) {
      return risolviRisveglio(state, oreDormite, false);
    }
    return null;
  }

  // Sveglia manuale (tap/bottone del giocatore mentre dorme): l'energia dipende da quante
  // ore ha dormito (v. risolviRisveglio). Il rispetto dei minimi (riposino 1h, notturno 5h)
  // e' responsabilita' del chiamante (ui.js puoSvegliare/eseguiSveglia): questa funzione
  // esegue sempre la sveglia se richiamata. Ritorna null se non stava dormendo.
  function svegliaManuale(state) {
    if (!state || !state.sonno) return null;
    var oreDormite = state.sonno.oreDormite || 0;
    return risolviRisveglio(state, oreDormite, true);
  }

  // Puo' il giocatore svegliare ORA il pet col tasto Sveglia? (GDD: riposino non svegliabile
  // prima di 1h di gioco dormita, notturno prima di 5h). Ritorna {puo:bool, minutiMancanti}.
  function puoSvegliare(state) {
    if (!state || !state.sonno) return { puo: false, minutiMancanti: 0 };
    // Decisione fondatore (test 7 lug 2026): "il pet deve potersi svegliare" SEMPRE, anche nel
    // sonno profondo. Niente piu' minimo bloccante (riposino 1h / notturno 5h): svegliarlo
    // presto e' permesso e la penalita' e' naturale — risolviRisveglio da' energia proporzionale
    // alle ore dormite e battuta 'dormito_male'. La firma resta uguale per i chiamanti
    // (bottone Sveglia in renderAzioniCamera + tap sul pet, entrambi via tentaSveglia).
    return { puo: true, minutiMancanti: 0 };
  }

  // Debug: "Salta sonno" completa il sonno corrente come se avesse dormito la sua durata
  // massima (riposino: 2h piene; notturno: 8h piene / sveglia autonoma), qualunque sia
  // l'orologio di gioco al momento dell'avvio. Se non sta dormendo non fa nulla.
  function debugSaltaAlMattino(state) {
    if (!state || !state.sonno) return null;
    var es = bilEnergiaSonno();
    var durataMax = (state.sonno.modalita === 'riposino') ? es.riposinoDurataMax : es.sveglioAutonomoOre;
    // Fix playtest (7 lug 2026): il salto deve spostare ANCHE l'orologio, altrimenti dopo un
    // crollo alle 23 il pet si "svegliava" ancora alle 23 e il tick lo faceva ricrollare subito
    // (sembrava insvegliabile). Notturno -> 08:00 del mattino dopo (attraversa la mezzanotte via
    // avanzaOrologio, quindi giornoGioco avanza e il nuovo giorno scatta regolare); riposino ->
    // avanti solo delle ore di pisolino rimanenti.
    if (PETQ.clock && PETQ.clock.avanzaOrologio && typeof state.gameMinutes === 'number') {
      var deltaMin;
      if (state.sonno.modalita === 'riposino') {
        deltaMin = Math.max(0, (durataMax - (state.sonno.oreDormite || 0)) * 60);
      } else {
        deltaMin = ((1440 - state.gameMinutes) + 8 * 60) % 1440; // -> 08:00 del giorno dopo
        if (deltaMin <= 0) deltaMin = 1440;
      }
      if (deltaMin > 0) PETQ.clock.avanzaOrologio(state, deltaMin / 60);
    }
    return risolviRisveglio(state, durataMax, false);
  }

  // ==================== Allenamento a tempo (bilanciamento.md "Allenamento") ====================
  // state.allenamento = null | { stat, oreFatte, oreTot }. Avviato da PETQ.care.train (che
  // NON applica piu' subito l'effetto), avanzato in ore di GIOCO da applyDecay sopra (stesso
  // pattern di state.sonno.oreDormite). Quando oreFatte >= oreTot il completamento applica
  // effetto/felicita'/energia UNA SOLA VOLTA tramite PETQ.care.completaAllenamento e azzera lo
  // stato — v. controllaAllenamentoScaduto, richiamata dal tick/boot esattamente come
  // controllaSveglia/controllaMissioneScaduta (v. ui.js).
  //
  // Nota di design (documentata qui come richiesto): il crollo automatico delle 23 NON
  // interrompe un allenamento in corso. Il pet si sta allenando da SVEGLIO (non e' a dormire),
  // quindi a differenza della missione (che e' fuori casa) lasciamo che l'allenamento finisca
  // per conto suo; controllaCrolloAutomatico sopra gia' si astiene se c'e' una missione, e qui
  // estendiamo la stessa astensione al caso allenamento cosi' il pet non "salta" a dormire a
  // meta' sessione — finita l'attivita' (anche oltre le 23, il gioco di gioco prosegue) il
  // primo tick libero lo mettera' comunque a nanna al prossimo controllo se e' ancora tardi.
  function controllaAllenamentoScaduto(state) {
    if (!state || !state.allenamento) return null;
    var a = state.allenamento;
    if ((a.oreFatte || 0) < a.oreTot) return null;
    if (!PETQ.care || typeof PETQ.care.completaAllenamento !== 'function') return null;
    return PETQ.care.completaAllenamento(state);
  }

  // ==================== Passeggiata serale (playtest 8 lug 2026, "manca un'attivita'") ====================
  // Dalle 19 (quando chiudono le missioni) alle 21 (ora del letto) si puo' mandare il pet a
  // spasso 30 minuti di GIOCO, 1 volta al giorno. NON e' una missione: niente successo/
  // fallimento, al rientro un MICRO-EVENTO casuale. state.passeggiata = null | {oreFatte, oreTot};
  // avanza in applyDecay (stesso pattern di state.allenamento), completa via
  // controllaPasseggiataScaduta dal tick (pattern controllaAllenamentoScaduto).
  // Finestra della passeggiata, spostata DI GIORNO col Batch B (Dilemmi + Lavori, numeri
  // confermati dal fondatore: 8-19). Motivo: la SERA diventa il turno di lavoro del pet, e due
  // attivita' serali si sarebbero pestate i piedi. Era 19-21.
  // Le battute del socio sono state riscritte di conseguenza (49, IT+EN): se un giorno questa
  // finestra torna serale, vanno rimesse a posto anche quelle o il pet parlera' di sole a notte.
  // CHIUSURA spostata 19 -> 21 (fondatore, 3 ago 2026). Motivo misurato: le missioni vanno 6-19 e
  // ne fai DUE da 2h; chi apre l'app alle 15 finisce esattamente alle 19, quando la passeggiata
  // chiudeva — quindi doveva SCEGLIERE fra le due cose senza che niente glielo dicesse. Ora dopo
  // le missioni restano due ore. 21 e' l'ora della nanna (bilEnergiaSonno.oraLetto), non un numero
  // a caso: la passeggiata finisce dove comincia la sera del pet.
  // NB il turno di lavoro NON confligge: si riscuote al cambio giorno, non alle 19.
  var PASSEGGIATA_ORA_INIZIO = 8;
  var PASSEGGIATA_ORA_FINE = 21;
  var PASSEGGIATA_ORE = 0.5;

  function orarioPasseggiataAperto(state) {
    var og = (PETQ.clock && PETQ.clock.oraGioco) ? PETQ.clock.oraGioco(state) : { ore: 12 };
    return og.ore >= PASSEGGIATA_ORA_INIZIO && og.ore < PASSEGGIATA_ORA_FINE;
  }

  function avviaPasseggiata(state) {
    if (!state || !state.pet) return { ok: false, msg: traduci('errore interno') };
    if (state.passeggiata) return { ok: false, msg: traduci('È già a passeggio.') };
    if (state.sonno) return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' sta dormendo.') };
    if (state.missione) return { ok: false, msg: traduci('È in missione.') };
    if (state.allenamento) return { ok: false, msg: traduci('Si sta allenando.') };
    if (state.gioco) return { ok: false, msg: traduci('Sta giocando: aspetta che finisca.') };
    if (!orarioPasseggiataAperto(state)) {
      // Gli orari NON si riscrivono a mano nel messaggio: si leggono dalle stesse costanti che
      // decidono la finestra. Prima erano cablati ("dalle 8:00 alle 19:00") e spostando la
      // chiusura a 21 il gioco avrebbe detto al giocatore un orario FALSO — lo stesso numero
      // scritto in due posti che diverge appena ne cambi uno, che e' il difetto piu' ricorrente
      // di questo progetto. Il testo tradotto tiene due segnaposto e li riempiamo qui.
      var tmpl = 'La passeggiata si fa di giorno, dalle {da} alle {a}.';
      var testo = (window.PETQ.i18n && PETQ.i18n.t) ? PETQ.i18n.t(tmpl) : tmpl;
      return { ok: false, msg: testo
        .replace('{da}', PASSEGGIATA_ORA_INIZIO + ':00')
        .replace('{a}', PASSEGGIATA_ORA_FINE + ':00') };
    }
    var oggi = (PETQ.clock && PETQ.clock.giornoCorrente) ? PETQ.clock.giornoCorrente(state) : 0;
    if (state.passeggiataGiorno === oggi) {
      return { ok: false, msg: traduci('Una passeggiata al giorno: rifatti sotto domani.') };
    }
    state.passeggiata = { oreFatte: 0, oreTot: PASSEGGIATA_ORE };
    state.passeggiataGiorno = oggi;
    return { ok: true, msg: (state.pet.nome || traduci('Il pet')) + traduci(' esce a fare due passi.') };
  }

  // Micro-eventi al rientro (pesati: le monete e l'incontro escono piu' spesso). Effetti
  // applicati qui; il msg e' pronto per il toast della UI.
  function controllaPasseggiataScaduta(state) {
    if (!state || !state.passeggiata || !state.pet) return null;
    var pw = state.passeggiata;
    if ((pw.oreFatte || 0) < pw.oreTot) return null;
    state.passeggiata = null;

    var pet = state.pet;
    var nome = pet.nome || 'Il pet';
    // ESITI NARRATIVI (richiesta fondatore 9 lug 2026: "un tot di esiti random"): 11 esiti a tema
    // città robot/alieni. Filosofia GDD: fallimenti lievi che compensano. Pesati: monete/incontro
    // piu' comuni, bulletto (negativo) raro. Ogni esito ha un pool battute del socio
    // (passeggiata_<evento>); il testo-tappo (fallback) vale finche' il socio non riempie il pool.
    var POOL_ESITI = ['monete', 'monete', 'incontro', 'incontro', 'pozzanghera', 'panorama',
      'rottame', 'piccione', 'assaggio', 'acquazzone', 'persi', 'cielo', 'bulletto'];
    var evento = PETQ.rng ? PETQ.rng.pick(POOL_ESITI) : 'incontro';
    // Perk CASA (P3, "Scatola di Cioccolatini" m68): la passeggiata serale non ha MAI esiti
    // negativi. L'unico esito negativo del pool e' 'bulletto': se esce e il perk e' attivo, lo
    // ri-estraiamo/sostituiamo con uno NON negativo (pool senza 'bulletto', stessi pesi relativi).
    if (evento === 'bulletto' && PETQ.talenti && PETQ.talenti.perkCasaPasseggiataSenzaNegativi && PETQ.talenti.perkCasaPasseggiataSenzaNegativi(state)) {
      var poolSenzaBulletto = POOL_ESITI.filter(function (e) { return e !== 'bulletto'; });
      evento = PETQ.rng ? PETQ.rng.pick(poolSenzaBulletto) : 'incontro';
    }
    var addFel = function (n) { pet.stats.felicita = clamp(pet.stats.felicita + n, 0, 100); };
    var fallback, extra = '';
    if (evento === 'monete') {
      var trovate = 3 + (PETQ.rng ? PETQ.rng.randInt(0, 5) : 2);
      state.coins = (state.coins || 0) + trovate;
      fallback = nome + traduci(' è tornato: ha trovato monete sul marciapiede!');
      extra = ' (+' + trovate + traduci(' monete') + ')';
    } else if (evento === 'incontro') {
      addFel(8);
      fallback = nome + traduci(' è tornato: ha incontrato un altro pet e hanno giocato (+8 Felicità).');
    } else if (evento === 'pozzanghera') {
      pet.stats.igiene = clamp(pet.stats.igiene - 15, 0, 100); addFel(5);
      fallback = nome + traduci(' è tornato fradicio: pozzanghera in pieno (+5 Felicità, −15 Igiene).');
    } else if (evento === 'panorama') {
      addFel(5);
      if (typeof pet.stats.energia === 'number') pet.stats.energia = clamp(pet.stats.energia + 5, 0, 100);
      fallback = nome + traduci(' è tornato rilassato: luci della città dal ponte (+5 Felicità, +5 Energia).');
    } else if (evento === 'rottame') {
      var pezzi = 2 + (PETQ.rng ? PETQ.rng.randInt(0, 3) : 2);
      state.coins = (state.coins || 0) + pezzi;
      fallback = nome + traduci(' è tornato con un rottame alieno luccicante trovato per strada.');
      extra = ' (+' + pezzi + traduci(' monete') + ')';
    } else if (evento === 'piccione') {
      addFel(6);
      if (typeof pet.stats.energia === 'number') pet.stats.energia = clamp(pet.stats.energia - 5, 0, 100);
      fallback = nome + traduci(' ha rincorso un piccione cyborg per mezza città (+6 Felicità, −5 Energia).');
    } else if (evento === 'assaggio') {
      pet.stats.fame = clamp(pet.stats.fame + 12, 0, 100);
      fallback = nome + traduci(' è tornato: un ambulante gli ha mollato uno spuntino (+12 Fame).');
    } else if (evento === 'acquazzone') {
      pet.stats.igiene = clamp(pet.stats.igiene + 12, 0, 100); addFel(-3);
      fallback = nome + traduci(' è tornato zuppo: acquazzone improvviso, ma bello pulito (+12 Igiene, −3 Felicità).');
    } else if (evento === 'persi') {
      addFel(6);
      if (typeof pet.stats.energia === 'number') pet.stats.energia = clamp(pet.stats.energia - 8, 0, 100);
      fallback = nome + traduci(' si è perso e ha girato a lungo: gran avventura, gambe a pezzi (+6 Felicità, −8 Energia).');
    } else if (evento === 'cielo') {
      addFel(8);
      fallback = nome + traduci(' è tornato con gli occhi all\'insù: un\'astronave è passata bassa sui tetti (+8 Felicità).');
    } else { // bulletto
      addFel(-4);
      fallback = nome + traduci(' ha incrociato un pet maleducato: parole grosse, morale un po\' giù (−4 Felicità).');
    }
    recomputeSalute(pet, state);
    // Battuta del socio dal pool 'passeggiata_<evento>' (agganciata 9 lug 2026); fallback al
    // testo meccanico se il pool è vuoto ('...'). Per le monete aggiungo il conteggio.
    var battuta = (PETQ.dialog && PETQ.dialog.say) ? PETQ.dialog.say(pet, 'passeggiata_' + evento, state) : null;
    var msg = '🚶 ' + ((battuta && battuta !== '...') ? (battuta + extra) : (fallback + extra));
    return { ok: true, evento: evento, msg: msg };
  }

  // Fine gioco nel salone (richiesta fondatore 8 lug 2026): quando le 20 ore-min sono passate,
  // applica il bonus Felicita' salvato all'avvio (state.gioco.bonus: 4, o 6 con un giocattolo
  // piazzato) e ritorna il messaggio per il balloon. Pattern di controllaPasseggiataScaduta.
  function controllaGiocoScaduto(state) {
    if (!state || !state.gioco || !state.pet) return null;
    var gk = state.gioco;
    if ((gk.oreFatte || 0) < gk.oreTot) return null;
    var bonus = (typeof gk.bonus === 'number') ? gk.bonus : 4;
    var giocattolo = gk.giocattolo || null;
    state.gioco = null;
    var pet = state.pet;
    pet.stats.felicita = clamp(pet.stats.felicita + bonus, 0, 100);
    recomputeSalute(pet, state);
    var nome = pet.nome || traduci('Il pet');
    // Il nome del giocattolo passa da traduci(): i nomi oggetto hanno gia' la voce a display.
    var msg = giocattolo
      ? '🧸 ' + nome + traduci(' si è divertito un mondo col ') + traduci(giocattolo) + '! (+' + bonus + ' ' + traduci('Felicità') + ')'
      : '🧸 ' + nome + traduci(' ha giocato di gusto!') + ' (+' + bonus + ' ' + traduci('Felicità') + ')';
    return { ok: true, bonus: bonus, msg: msg };
  }

  window.PETQ.pet = {
    generate: generate,
    applyDecay: applyDecay,
    // Tetto stat per stadio (fix "le stat sfondano le soglie in anticipo"): l'UNICA funzione
    // autorizzata ad alzare pet.rpg, v. commento sopra. TUTTI i punti che fanno crescere una
    // stat RPG (care.js/missions.js/arredi.js/pet.js stesso) passano da qui.
    aggiungiStat: aggiungiStat,
    _tettoStatPerStadio: tettoStatPerStadio,
    _tettoStatDefault: TETTO_STAT_DEFAULT,
    recomputeSalute: recomputeSalute,
    bodyVariant: bodyVariant,
    guarisciGiorno: guarisciGiorno,
    bilEnergiaSonno: bilEnergiaSonno,
    energiaSottoSoglia: energiaSottoSoglia,
    modalitaSonnoOra: modalitaSonnoOra,
    avviaSonno: avviaSonno,
    controllaCrolloAutomatico: controllaCrolloAutomatico,
    controllaSveglia: controllaSveglia,
    svegliaManuale: svegliaManuale,
    puoSvegliare: puoSvegliare,
    debugSaltaAlMattino: debugSaltaAlMattino,
    controllaAllenamentoScaduto: controllaAllenamentoScaduto,
    // Passeggiata serale (playtest 8 lug 2026)
    avviaPasseggiata: avviaPasseggiata,
    controllaPasseggiataScaduta: controllaPasseggiataScaduta,
    orarioPasseggiataAperto: orarioPasseggiataAperto,
    // Gioco nel salone a tempo (8 lug 2026)
    controllaGiocoScaduto: controllaGiocoScaduto,
    controllaEvoluzione: controllaEvoluzione,
    ritiraTalenti: ritiraTalenti,
    _debugEvolvi: _debugEvolvi,
    _giorniEvoluzioneAdulto: GIORNI_EVOLUZIONE_ADULTO,
    // Valigia / partenza (Blocco 2)
    valutaValigiaNuovoGiorno: valutaValigiaNuovoGiorno,
    condizioneValigiaCritica: condizioneValigiaCritica,
    inFaseValigia: inFaseValigia,
    petPartito: petPartito,
    assicuraValigiaTrig: assicuraValigiaTrig,
    faiAmmenda: faiAmmenda,
    debugForzaValigia: debugForzaValigia,
    debugForzaPartenza: debugForzaPartenza,
    // Pensione (versione base P2)
    mandaInPensione: mandaInPensione,
    _risolviRisveglio: risolviRisveglio,
    _giorniEvoluzioneTeen: GIORNI_EVOLUZIONE_TEEN,
    _soglieCiccionePerStadio: SOGLIE_CICCIONE_PER_STADIO,
    _costoAmmenda: COSTO_AMMENDA,
    _sogliaValigiaFel: SOGLIA_VALIGIA_FEL,
    _sogliaValigiaSal: SOGLIA_VALIGIA_SAL,
    _sogliaValigiaDoppio: SOGLIA_VALIGIA_DOPPIO,
    _giorniTriggerValigia: GIORNI_TRIGGER_VALIGIA,
    // Uovo leggendario (P3 batch 6): esposti per debug/test (stesso stile degli altri _prefissati)
    _leggendeInfo: LEGGENDE_INFO,
    _probUovoLeggenda: PROB_UOVO_LEGGENDA
  };

})();
