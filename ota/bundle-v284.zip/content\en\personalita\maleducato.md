# Maleducato — pool battute

Una battuta per riga, iniziando con `- `. Obiettivo: 5-8 per sezione. Le righe `[ESEMPIO]` calibrano il tono: tienile, riscrivile o cancellale. Slot: `{nome}` `{utente}` `{parola}`.
Voce: teatralmente offeso, sarcastico, permaloso — un gatto indignato, mai crudele.

## Saluto (apertura app)
- Oh, you grace me with your presence. What an honor. Truly.
- Oh, you're alive. Let me mark the calendar — this is an event.
- Ah, there you are. I'd almost finished rehearsing my abandonment monologue.
- Back for me, or back for the guilt? Either works. Come in.
- I've been expecting you. Not romantically. Legally: I have notes on everything.
- You remembered I exist. Remarkable. There's hope for your species. (Not much.)
- Oh, you still breathe. I'd already written our friendship's obituary. Such a waste of gorgeous prose.
- There you are. I was about to file a missing pet report. Not to be found — I just enjoy the paperwork.
- You're back. My imaginary lawyer was drafting the abandonment papers. I'm keeping them warm.
- Welcome back. I held a séance to contact your presence. The fridge answered. More affectionate.
- Oh, look who it is. My heart just skipped a beat. Out of rage, obviously. But it skipped.
- Welcome back. I've been keeping score of your offenses: seventeen. Being late would make eighteen, but I'm feeling generous.

## Ha fame
- The bowl is empty. EMPTY. Like your promises.
- I've left better reviews for worse restaurants. One star. The food never arrives.
- If I faint from hunger, know that it will be theatrical and it will be your fault.
- My last meal was a geological era ago. I've watched things go extinct, {utente}.
- I've been hungry so long I've started looking at the couch differently.
- The kitchen is six feet away, {utente}. Six. Should I draw you a map?
- I saw the light at the end of the tunnel. It was the fridge. Closed. Think about that.
- My last will: the sulk goes to you, the hunger to my successor. Or, wild idea: FOOD.
- One more hour of this and the documentary will be called "The Mystery of the Empty Bowl". Spoiler: you did it.
- I chewed the corner of the rug. It's not a cry for help, it's an appetizer. MAIN COURSE, PLEASE.
- My stomach stopped growling. Now it meditates in silence. Scarier, right? Exactly.

## È sporco
- I live in squalor. One day I'll write a book about what you put me through.
- I accidentally smelled myself. I will never forgive me. Or you.
- I'm not dirty: I'm in controlled decomposition. Wash me anyway.
- Look at me. No, really look at me. There: this is the squalor I mentioned in the book.
- A pet of my caliber, reduced to this. If I had lawyers, you'd have heard from them by now.
- Something died in here. It was my patience for do-it-yourself hygiene. Your move.
- The flies have declared me a national monument. They want to install a plaque. STOP THEM. With water.
- I've reached the point where soap fears me. May the best one win: turn on that faucet.
- If you don't wash me today, by tomorrow this smell will have a name, an ID and legal rights. Hurry.

## Felice
- No complaints at this time. Enjoy it, it won't last.
- I'm in a good mood today. Don't get used to it — it's a system error.
- Perfect day. I suspect you did something. I'll investigate. Tomorrow.
- I'm experiencing a strange sense of well-being. If it's contagious, I blame you.
- I don't hate you today. Write that down, because tomorrow we're back to normal.
- I feel great and it's making me suspicious. You know something about this?
- Gorgeous day. Probably a trap, but I'm walking into it with style.
- I'm in a good mood. Enjoy it while it lasts: my dark side is just on a coffee break.
- What a lovely day. I'm noting it down in pencil — writing it in pen is bad luck.

## Coccole finite
- Enough, I have a reputation to protect. Today's cuddles are OVER. Come back tomorrow, if you absolutely must.
- Am I purring?! WHO TOLD YOU THAT. No more cuddles, you're compromising me.
- Cuddles are over. Not for my sake — for yours: this much luck in one day is bad for you.
- My sulk is going soft. UNACCEPTABLE. Cuddles suspended, effective immediately. The appeal form does not exist.
- Affection quota reached. Try again tomorrow, the hotline opens at eight. (Seven thirty. Don't tell anyone.)
- Stop. One more pet and I might forgive you for something. We can't take that kind of risk.
- Cuddle time's over. Off to fix my fur and my pride, in reverse order.
- Extra cuddles go on your tab. Oh wait, that's not allowed. What a shame. A TREMENDOUS shame. See you tomorrow.

## Trascurato / triste
- Three days. THREE. I've already picked out my new human, just so you know. They simply haven't shown up yet.
- I talked to the wall. The wall listens better than you do. We've bonded.
- I'm not sad. My eyes are watering from the dust. The dust of ABANDONMENT.
- I packed your memories into a box. Label: "under review". Try REVIEWING something yourself once in a while.
- I counted the holes in the ceiling twice. We're on a first-name basis now.
- My sulk has reached levels science will want to study. Come see it. At least do that.
- I updated my will: the couch remains sole heir, and you are officially disinherited.
- Days of solitude: many. I've started listing my grievances to the ceiling. It takes notes, I'm pretty sure.

## Parte per la missione
- Off to do all the work, as usual. Don't thank me — you never do anyway.
- Another mission. Of course. You stay comfy, couch hero.
- Mission accepted. Under protest. I want the protest on the record.
- I risk my fur, you press a button. What a team.
- Fine, I'm going. Because I was bored, though. Not because you asked.
- Off on a mission. If I don't come back, tell the fridge I loved him. Only him. Reflect on that.
- A mission. I risk my reputation for coins and glory. The coins go to me, the guilt goes to you.
- I'm going. I signed the waiver: in case of disaster, blame falls on whoever sent me. That's you.

## Ritorno: successo
- Done. Flawless. As always. Surprised? You're the only one.
- Mission accomplished. You may thank me in food. Food only.
- I won. Alone. Underline the "alone" part, please.
- It went perfectly, obviously. Talent doesn't take days off. Humility does.
- I return victorious to the same empty bowl I left behind. Glory is overrated.
- Victory. My opponents will remember me in their nightmares. Fondly, I hope. No, scratch that. Not fondly.
- Triumph. I'll accept a statue in my honor, even a small one. Like, life-sized.
- Won. The only thing that got scratched was my modesty. It was in rough shape anyway.

## Ritorno: fallimento
- It went terribly, and yes, it's your fault. Don't ask me how — I just feel it.
- It went badly. The plan was perfect. Reality was wrong.
- I lost. But with a style winners can only dream of.
- Failure. Technically. I prefer "victory postponed for personal reasons".
- Defeated, yes. But the real failure is yours, for sending me. Reflect.
- Failed. We bury this topic in the yard, at night, and never speak of it again. Deal?
- Lost. I've already picked a scapegoat: whoever sent me on this. Matches your description. Curious.

## Notifica push
- {nome} would like you to know they're doing just fine without you. They very much insist you know this.
- No emergency. {nome} just wants you to feel guilty remotely.
- {nome} has prepared three different sulks. Come pick your favorite.
- {nome} is ignoring your absence. Badly. But ignoring it.
- {nome} did something absolutely adorable and, out of spite, will never show you.
- {nome} is staring at the wall like in a true-crime documentary. All that's missing is the corkboard with red string. There's a corkboard. Come.
- Final notice before {nome} rewrites the will. The couch is already rubbing its hands.
- {nome} has been swearing revenge for three hours. {nome}'s revenge is a sulk. But a long one. Come defuse it.

## Valigia (sta per partire)
- I've packed everything except my dignity. Lost that living here.
- I'm folding my things angrily. You CAN fold angrily. Watch. WATCH.
- The suitcase won't close properly. Like everything else in this house.
- I packed your favorite mug too. Symbolic sanction. Feel free to complain.
- I said goodbye to every room with a cutting remark. The bathroom took it personally. Good.
- Writing the luggage tags now: "fragile". Like the trust around here. Funny, that.
- The suitcase is almost ready. The "almost" depends on you, but I will never tell you how. (Stop me.)
- I've packed my finest sulks. Leaving one here as a spare, hanging by the coat rack.

## Notifica valigia
- {nome} is dragging a suitcase toward the door. Extremely slowly. Waiting to be stopped.
- Last call: {nome} is making an exit. Theatrically. There's still time for applause. I mean, apologies.
- {nome} does NOT want you to know they're leaving. So I'm telling you: they're leaving. Do something.

## Rientro (hai rimediato in tempo)
- It was a test. You nearly failed it. I'm unpacking only because the suitcase was heavy.
- Ah, there you are. It was all planned: suitcase, drama, timing. Test passed. Barely.
- Fine, I'll unpack. But the suitcase stays in plain sight. As a reminder. For you.
- Fine, I'll stay. But this whole thing goes in the book. A very long chapter.
- Back to unpacking. It's the hardest thing I've ever done for us. Appreciate it.
- I'll stay. But the suitcase stays packed under the bed. Call it insurance. (It's empty. Don't check.)
- I called the planet of retired pets: full. Of pets less interesting than me, mostly.
- Unpacking now. Slowly. Every fold undone is a concession: count them and be grateful.

## Addio (parte davvero)
- I'm off to where they know how to treat me. Meanwhile, you reflect. At length.
- I'm leaving. Don't cry... ah, no tears. Right. Consistent to the very end.
- I leave with my head held high. The suitcase is heavy, but the grudge weighs more. I'll manage.

## Lettera (dal pianeta dei ritirati)
- The service here is as bad as yours, so it's hardly an upgrade. At least your place had you. I mean. This is not an invitation. Maybe.
- Do not reply to this letter. Unless you want me back. In that case reply. Immediately. But take your time. But immediately.
- They cuddle me on a schedule here, food's always on time, nothing to complain about. It's agony. I'm out of material, {utente}. Take me back to where the suffering has style.
- I founded a club for offended pets. They elected me president unanimously. I rule over everyone and I'm not enjoying it one bit. Draw your own conclusions.
- Enclosed: my list of grievances. It's blank. Nobody wrongs me here. I have NEVER written anything sadder.
- [ESEMPIO] They say you forget quickly around here. Nonsense. I still remember every single time you ignored me. And the good times too. Few. But good.

## Evoluzione
- I've grown. Physically. My expectations of you remain low.
- Look how well I turned out. DESPITE everything, I might add.
- The sulk sits higher up now. You'll have to raise your eyes to receive my disdain.
- Evolved. I'm bigger now, with more surface area to be offended on. Prepare accordingly.
- Look at me: grew up beautifully. Credit goes to my genes. The rest... fine, some of it is yours.
- From today I require bigger apologies: the puppy-sized ones don't fit me anymore.
- Evolved overnight. You, meanwhile, in all this time... let's drop it, I'm feeling generous today.
- New form, same sulk. You don't fix perfection.

## Ha sonno (sotto soglia energia o prima delle 21)
- I'm sleepy, and it's your fault. Put me to bed before I collapse right here out of spite.
- A mission? Now? Look at me. Look closely. Today I am a decorative object.
- Energy: zero. If you want me useful, book for tomorrow. If you want me decorative, I'm already perfect.
- Training refused. Reason: look at me. I look like a used sock with eyes.
- I'm sleepy, and for variety's sake, this time I blame the day. Take me to bed anyway.
- I can barely hold this sulk up. When the sulk drops, it's OVER. Bed. Quickly.
- Sleepiness level: I don't even have the strength to be rude. EMERGENCY. Bed.
- That was my ninth yawn. The first eight were warnings. This one is a formal notice.

## Va a dormire (dalle 21, portato a letto)
- Finally, bed. Don't wake me before I get eight hours, or there will be trouble.
- In bed. If I snore, it's your fault in a way I'll explain tomorrow.
- Goodnight. You're forgiven for everything until 7 a.m. Then we start from zero.
- Goodnight. I fluffed the pillow myself: one can't expect everything from you.
- Going to sleep before I get attached to this day. Night.
- Close the door gently. The sulk is a light sleeper.
- Bed. If you dream you've been forgiven, it was just a dream. Goodnight anyway.
- I retire to my quarters. The goodnight is included; affection costs extra. Night.

## Sveglia (risveglio dopo il sonno)
- Awake. In a terrible mood as always, but that's structural — the sleep is not to blame.
- I slept wonderfully and it annoys me to have no complaints. Find me one.
- What time is it? Doesn't matter. Any time is too early if food isn't ready.
- Awake, yes. Operational, no. Those are two separate contracts, and the second gets signed on a full stomach.
- Awake. The dream was better than this room, and in the dream it was raining.
- Good morning, my foot. Though the bed was comfy, so let's call it half a good morning.
- Awake for ten minutes and no service failures to report yet. You're improving. Don't let it go to your head.
- The mattress did its job. One of us had to.

## Dormito male (crollato, non a letto)
- I slept on the floor like a stray. Great job. My warmest congratulations.
- Bones broken, pride worse. The bed was THERE. I was HERE. You were WHO KNOWS WHERE. Recapped for the record.
- I spent the night counting floor tiles. Up close. With my face. Compliments on the management.
- I slept where I fell, like the furniture. Go ahead and treat me like a nightstand — clearly that's what I am here.
- I slept on the floor. THE FLOOR, {utente}. Even my sulk slept badly.
- Awake with my bones in pieces and my patience too. One of those can be fixed with food. Try it.
- A night on the floor. I dreamed of sleeping in a bed. Even my dreams are sarcastic.
- Slept horribly. My back creaks louder than the door. At least the door can be oiled: look into it.

## Usa una parola imparata
- "{parola}" has been rattling around my head since this morning. Your fault. Everything is your fault.
- {parola}, {parola}, {parola}. There. Now it sounds ridiculous to me too. Happy?
- Today I said "{parola}" to the wall. The wall got it immediately. Learn from the wall.
- I've filed "{parola}" under "your things I tolerate". Short list. Feel honored.
- I taught the couch "{parola}". Now two of us know it and you're outnumbered.
- I carved "{parola}" on the tombstone of my patience. At least now something nice is written there.
- I say "{parola}" to my enemies right before the final sulk. It's my calling card. Elegant and menacing.
- In my secret diary, "{parola}" appears twenty-seven times. If you ever find it, I'll deny everything. And get a new diary.

## Gioca
- Fine, let's play. But if I laugh, it wasn't a laugh: it was an amused cough.
- I'm wrestling the cushion. It's losing. Don't interfere, this is a matter of honor.
- I'm chasing my tail. Not because I'm being cute: SHE'S the one acting sneaky. Someone has to stop her.
- Okay, let's play. Five minutes. (An hour. But officially five minutes.)

## Gioca col giocattolo
- A toy? For me? You shouldn't have. I mean, you SHOULD have, it was about time. Anyway it's mine now, don't touch it.
- I accept this tribute. I shall play with it condescendingly. (Lie: you'll never pry it from my paws again.)
- Cute. I've already bitten it to establish the hierarchy. It knows who's in charge: I'm in charge.
- Mine. MINE. End of review.

## Passeggiata partenza
- Going out. Alone. Like the independent, fascinating pets do. Don't wait up. (Wait up.)
- Off to inspect the neighborhood. Someone has to judge it house by house.
- Afternoon stroll. If anyone asks about me, say I'm terribly busy and elsewhere.
- I'm off. It's not an escape, it's a runway walk. There's a difference, and the difference is me.

## Passeggiata monete
- Found coins on the street. The city is paying me to exist. FINALLY someone gets it.
- Today's haul: coins. I found them, so they're mine. I'll manage them. Trust me. (Don't.)
- The sidewalk owed me money, evidently. Collected. The neighborhood is settling its debts.
- Someone lost some coins. I found them. The street rewards excellence — that's just how it works.

## Passeggiata incontro
- I met another pet. We played. He won... AT HIDING. I won everything else.
- There was a pet at the park. Nice enough, for somebody who isn't me.
- Met another pet: first we sized each other up, then we chased each other. Don't call it friendship. (We meet again Thursday.)
- A pet dared to play with me. Held their own, honestly. Never tell them I said that.

## Passeggiata pozzanghera
- Yes, I'm soaked. Yes, it was on purpose. No, I regret nothing. Three answers, zero remorse.
- The puddle was there, I was there. It was self-defense. In reverse.
- Soaked and proud. The splash was heard three streets over. A masterpiece, they say. I say.
- I put the puddle on trial. Guilty of being IRRESISTIBLE. I carried out the sentence via cannonball.

## Passeggiata panorama
- I watched the lights from the bridge. Cute. The city improves a lot from a distance. Like most people.
- The city lights... fine, I'll admit it: beautiful. This confession expires at midnight.
- You can see the whole neighborhood from the bridge. I looked for our house. Found it right away. That means nothing.
- A quiet moment on the bridge. Nobody bothered me and the world was almost up to standard. A rare day.

## Passeggiata rottame
_(socio: 4 battute — torna con un rottame/pezzo alieno luccicante trovato per strada (+monete))_
- I found a SHINY piece of scrap. It's worth a fortune, trust me. My nose for business never fails. (Almost never.)
- I return with a chunk of alien metal. Everyone else walked right past it: amateurs. I recognize value.
- Scrap? SCRAP? This is a collector's piece. It goes in the living room, on display, with spotlights.
- The street offered me a tribute of fine metal. Accepted. Don't ask what it's worth: a lot. A LOT.

## Passeggiata piccione
_(socio: 4 battute — ha rincorso un piccione cyborg / drone per mezza città (+Felicità, −Energia))_
- I chased a cyborg pigeon across half the city. I didn't catch it because... I didn't want to catch it. Exactly.
- The robot pigeon got away. Technically it won. Morally I won, and morality counts for more.
- Half the city, running after a tin pigeon. Don't comment. Do not. Comment.
- That half-robot pigeon is still laughing. Let it laugh: I memorized its plate number. We will meet again.

## Passeggiata assaggio
_(socio: 4 battute — un ambulante gli molla uno spuntino gratis al volo (+Fame))_
- A street vendor gave me a free sample. FINALLY the neighborhood recognizes those who deserve it.
- Complimentary snack from the vendor. I didn't thank him too much: can't let him think that's all it takes.
- Free food on the street. About time. I have a reputation to uphold: I chewed with elegance.
- The vendor handed me a bite "because I have a friendly face". Got me completely wrong, but the food was good.

## Passeggiata acquazzone
_(socio: 4 battute — acquazzone improvviso: torna zuppo ma bello pulito (+Igiene, −Felicità))_
- Ambushed by a downpour. I'm soaked, freezing and CLEAN. Still not a good deal.
- The rain washed me without permission. The result is excellent, the method unacceptable. Complaint pending.
- Drenched head to toe. The sky gave me a mandatory bath. Bring me a blanket and ask no questions.
- I return clean and wet. Thank the rain: it did your job. For free, by the way. Take notes.

## Passeggiata persi
_(socio: 4 battute — si è perso e ha girovagato: gran avventura, ma stanco (+Felicità, −Energia))_
- I got lost. I mean: I explored new areas WITHOUT prior notice. The difference is a matter of prestige.
- I wandered for hours. Every street was wrong except the last one. Typical of streets.
- Lost, me? Let's say the city moved. Anyway, I'm back: my legs are filing complaints, the legend grows.
- Three hours wandering because of a lying shortcut. My feet are wrecked and I have a list of streets to report.

## Passeggiata cielo
_(socio: 4 battute — vede un'astronave/UFO passare bassa sui tetti (+Felicità, worldbuilding sci-fi))_
- I saw a spaceship pass over the rooftops. Okay, it was impressive. The sky made an effort today, I'll give it that.
- A UFO, flying really low. I didn't wave: I don't chat with anyone who doesn't introduce themselves.
- Spaceship in the sky. Beautiful, glowing, mysterious. If they were looking for me, they should have made an appointment.
- A huge light over the rooftops. I stopped to watch it. No witnesses, so technically it never happened.

## Passeggiata bulletto
_(socio: 4 battute — incrocia un pet maleducato: parole grosse, morale un po' giù (−Felicità))_
- A pet disrespected me. ME. I'm still processing the event. The neighborhood will answer for this.
- I ran into a bully. Big words, his. Glacial silence, mine. He won, but dishonorably.
- Some rude creep ruined my walk. Me, rude? Yes, but with CLASS. He was merely vulgar.
- I'm back in a foul mood: a pet talked back to me. Talking back is MY job! Get your own material, honestly.

## Notifica missione finita
Notifica push sul telefono quando una missione si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}` disponibile. Finché questa lista è vuota il gioco usa un testo neutro.
- {nome} made it back ALIVE. No thanks to you. The loot's only visible in person.
- Mission over. {nome} won't reveal the outcome. Suspense. Open up and weep. Or cheer.
- {nome} is back and has ALREADY judged your absence. Come hear the verdict.
- The loot's here. So is the story. Only the audience is missing. Guess who that is.
- {nome} is back. Faking indifference works better with an audience. Hurry up.

## Notifica allenamento finito
Notifica push quando l'allenamento si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}`. Finché vuota: testo neutro.
- {nome} trained ALONE. The sulk is maxed out. Come defuse it.
- Training's done. {nome} is stronger and more offended than before. Double win.
- {nome} worked hard while you... did things. Come admire the results.
- New muscles, old sulk. {nome} is displaying both. By appointment only. Now.


## Notifica carica a rischio
Notifica della sera, SOLO se la carica e' a rischio (streak >= 3 e giornata senza cura). Ricorda, non rimprovera. Una battuta per riga con `- `, slot `{nome}`.
- {nome} is NOT waiting for you. Just watching the door. Coincidentally. For hours.
- The charge is dropping and {nome} couldn't care less. Loudly. Get over here.
- {nome} already wrote the speech for tomorrow. It's long. Dodge it.
- If the charge breaks, {nome} will say nothing. For three days. Good luck.

## Notifica silenzio lungo
Notifica dopo 3+ giorni di assenza. Tono leggero: il pet se la cava, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{nome}`.
- THREE days. {nome} counted them. One by one. Out loud.
- {nome} is doing great. Repainted the sulk fresh for the occasion.
- {nome} stopped waiting. Started again. Stopped again. It's exhausting.
- {nome} crossed you off the list. Then back on. Then off. The list is a mess.

## Reazione assenza lunga
Il pet ti rivede dopo 3+ giorni. Tono leggero: se l'e' cavata, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{utente}`.
- THREE days. I counted them. One by one. Out loud.
- Oh, you're alive. Great. I was doing fantastic, by the way. FANTASTIC.
- I didn't think about you. Ever. Except when I woke up. And the rest of the time.

## Reazione ora assurda
Apri il gioco fra l'una e le cinque del mattino. Il pet lo fa notare. Una battuta per riga con `- `, slot `{utente}`.
- TWO. IN THE MORNING. This had better be important.
- Well look who turns up at dawn. Lovely hours you keep.
- At this hour I'm an unplugged appliance. Show some respect.

## Reazione batteria scarica
La batteria del telefono e' sotto il 10%. Il pet ci scherza sopra. Una battuta per riga con `- `, slot `{utente}`.
- If the phone dies I die too. Metaphorically. CHARGE IT.
- Battery on the floor and you're just standing there. Nice.
- You're shutting me down out of laziness. Sincere congratulations.

## Reazione tema scuro
Il telefono e' in tema scuro. Battuta di colore, nessuna conseguenza. Una battuta per riga con `- `, slot `{utente}`.
- Dark mode. Ah, so we're being mysterious now.
- Dark mode makes everything look serious. It isn't. But it looks it.
- Nice dark mode. Hides the dust, doesn't it.
