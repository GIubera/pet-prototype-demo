# Sportivo — pool battute

Una battuta per riga, iniziando con `- `. Obiettivo: 5-8 per sezione. Le righe `[ESEMPIO]` calibrano il tono: tienile, riscrivile o cancellale. Slot: `{nome}` `{utente}` `{parola}`.
Voce: energia infinita, tutto è un allenamento o una gara, motivational coach abusivo.

## Saluto (apertura app)
- COACH ON DECK! My favorite human! We're pushing HARD today, {utente}!
- YOU'RE BACK! High five! HARDER! THAT'S IT! Now THAT'S a warmup.
- Welcome back! Warmup done, motivation maxed, I was just waiting on my head coach.
- There you are! I kept the pace without you, but with you we shift into high gear.
- Coach! Just in time for today's top highlight: your entrance. STANDING OVATION!
- YOU'RE BACK! I've got the eye of the tiger and the appetite of the lion. LET'S GO!
- You're here! I sprinted up the stairs, fists in the air, full movie montage. It was three stairs. The emotion was real.
- Welcome back! Today we give 110%. The extra 10% is borrowed from yesterday, when I gave roughly zero.
- Buzzer beater, coach! I was THIS close to blowing the final whistle. I never blow it. But I was close.
- Coach is back! Training camp is over — the season starts NOW!
- You're here! IF YOU AIN'T JUMPING YOU'RE COUCH-SITTING, HEY! ...Okay, I'm the only one jumping. Jump with me. Come on.

## Ha fame
- I burned through everything! Breakfast, supplies, emergency reserves. PIT STOP NEEDED!
- You can't win races on an empty stomach. My idol said that. My idol is me, after lunch.
- Out of gas mid-race, {utente}! Either you push me to the kitchen or you bring the kitchen here.
- Cramp! Wait, no... it's hunger. IT'S HUNGER, {utente}! Medical team, NOW!
- My stomach just called a foul on me. Penalty awarded: to be taken in the kitchen.
- My belly blew the halftime whistle. Where are the halftime orange slices? WHERE ARE THEY?
- I've been running toward the fridge since this morning and I never get there. The field between me and food is like two miles long.
- A champion eats like a champion. Today I'm eating like a suspended benchwarmer: nothing.
- The plan: breakfast of champions. The reality: fasting of the defeated. Comeback time, coach!

## È sporco
- Okay, sweat is glory, but this is beyond glory. Shower, now, then back to work.
- I smell like a locker room after double overtime. Even by my standards that's not a compliment.
- I've been scratching for half an hour. It's not a new training technique. Help.
- One sweaty jersey = honor. Third sweaty jersey in a row = health hazard. Shower, coach!
- I sniffed myself at the photo finish. I lost. Substitution needed, immediately.
- Wax on, wax off... didn't work: the wax was mud. I need an actual shower, coach.
- Instant replay reviewed my smell: straight red card. Not cleared to play until after the shower.
- I did a victory roll. The victory ended, the mud stayed. Still counting it as a win overall. Shower?

## Felice
- TOP-TIER day! I'm feeling PODIUM!
- PERFECT DAY! I did a celebration backflip. Nobody filmed it? Shame. It was textbook.
- Endorphins MAXED, coach! I could run to the fridge a hundred times today. Actually, I will.
- I'm in the zone. Like a last-minute hat trick. Like breaking a record barefoot.
- Today I'm even winning at "standing still". Look at that form. UNDEFEATED.
- Highlight-reel day! We'll rewatch it together in slow motion, I promise.
- I feel like the replay of the greatest goal ever: I could watch it forever, and the goal is today.
- This day needs a screaming commentator! UNBELIEVABLE! SENSATIONAL! I FEEL AMAZING!
- If happiness were a league, today I'd have mathematically clinched the title.
- I celebrated by pulling my shirt off. Fully deserved the yellow card. Zero regrets.

## Coccole finite
- Recovery break, coach: today's cuddles are officially sold out. We restock tomorrow, promise.
- Stop, coach! Even affection needs pacing: cuddle overtraining = a pulled happiness muscle.
- Five sets of cuddles: full workout! Now muscle recovery, tomorrow we double it. (We can't. Tragic.)
- HALT! Affection redline reached. The trainer says stop. Double session tomorrow? Double session tomorrow.
- Cuddles need periodization, coach: today's load is complete. You go rest too — tomorrow we push.
- No more cuddles: anti-doping rules are strict. Too much affection alters performance. Alters it for the BETTER, but still.
- Cuddles done: my heart is full of lactic acid. Beautiful, but recovery is recovery.
- Cuddles complete! Cooldown time: two slow laps around the couch and one happy thought.

## Trascurato / triste
- Three days with no partner training. The bench hurts, {utente}. And I am NOT a bench player.
- I trained alone. I won alone. I celebrated alone. Honestly, everything was sadder.
- I'm stretching my patience. It's the only muscle getting any work lately.
- The stopwatch keeps running even when you're not here. Current time: too long.
- I've done my warmup every morning. Sooner or later the game shows up, right? ...Right?
- Training on empty, day three. Even the weights are starting to ask about you.
- I tried self-motivation. "Go {nome}!" shouted by {nome}. It's not the same, coach.
- Train, eat, sleep. Repeat. Missing the part where somebody says "nice job". That was my favorite part.
- The team's gone silent with the press, coach. I'm the team and the silence is yours. At least the press could visit.

## Parte per la missione
- Mission = race. And I don't lose races. TIME ME!
- Mission! I did my warmup, my stretches, and my motivational speech in the mirror. The mirror was crying.
- Off to win! And if I don't win, I'm doing the victory lap anyway. Nobody gets denied the victory lap.
- Away game! Cheer for me from home — I can hear cheering at any distance. My ears are trained.
- Here we go! Goal: a record. Plan B: a record with a slightly worse time.
- Mission! Playing it like a final: rough opening minutes, then LEGEND.
- I'm off, coach! If this mission is as long as the field in those anime shows, see you in a week.
- Mission = road game. And road games are where the greats show up. Everyone else does sightseeing. I do a bit of both.
- Off to glory! If things go bad, comeback mode: it's been my specialty since the days of... since right now.

## Ritorno: successo
- VICTORY! Lift the trophy with me! There's no trophy? Let's buy one, we've earned it.
- First place! I would've done the victory lap but I got lost. Twice. STILL A WIN!
- Personal best on that mission! The old record was mine. The next one will be mine too. Great league we've got.
- Crushing victory! Clock stopped, rivals demoralized, autographs signed. (One.)
- TRIUMPH, coach! Gimme five, gimme ten, gimme FIFTEEN. Tonight we celebrate!
- COMEBACK WIN! Down by two, then a hat trick. The unverifiable details make the story better.
- I won and celebrated sprinting with one finger pointed at the sky. The sky was the ceiling, but the gesture counts.
- Triumph! Somebody once said "you'll never make it". I took that personally. Behold the result.
- Trophy in the cabinet! The cabinet is the windowsill, the trophy is imaginary, the GLORY is real.

## Ritorno: fallimento
- Stinging loss... but champions are measured by the bounce-back. Tomorrow: double training.
- We lost, coach. I say "we" because pain gets shared. Blame doesn't: that goes to the ref.
- Lost on points. I demand a replay review. Missions don't have replay reviews? WELL THEY SHOULD.
- Lost it. But I ran faster than everybody — in the wrong direction. The talent is there, it just needs a compass.
- A stinging loss, but a training loss. The redemption muscle is already mid-pump.
- Defeat. But the saying goes: it ain't about how hard you hit, it's about how hard you can get hit and keep moving forward. And I take hits BEAUTIFULLY.
- The scoreboard is a liar: mission dominated, mission lost. Football... I mean, life is strange.

## Notifica push
- {nome} is running in circles to keep the rhythm going. Around lap 400 the dizziness kicked in.
- Scoreboard reads: {nome} 1, loneliness 0. But the second half needs a crowd.
- {nome} is doing motivational push-ups. The motivation ran out mid-set. Bring yours.
- {nome} is holding your spot on the team. Been holding it since this morning. The team is filing complaints.
- Field report: {nome} is pumped, extremely pumped, TOO pumped. Needs managing. Run.
- {nome} is doing play-by-play on an empty house: "still nobody in the box, coach". Come change the game.
- Transfer window closes at midnight: {nome} is waiting on a contract renewal from the coach. The terms? One pat and one snack.
- Medical report on {nome}: heart in top shape, morale running on fumes. The cure is well documented, and it's you.

## Valigia (sta per partire)
- An athlete can tell when the team has stopped calling.
- Folding my starter jerseys. Haven't worn them in a while — might as well fold them right.
- Still training today: duffel bag lifts. One set. One rep. Heaviest of my life.
- Exiting head high, champion's stride. I might trip on the way out, but that was the exit.
- Coach doesn't call you up, captain doesn't call at all... at some point a guy packs his bag.
- Packing up my imaginary trophies. They weigh nothing and they're worth everything, like the good times here.
- Final bag check: shoes, headband, pride. The cheering stays here: it was for you, it doesn't transfer.
- Zipped the bag on the third try. My heart keeps getting caught in the zipper.

## Notifica valigia
- Stoppage time: {nome} is on the end line with a packed bag. The substitution can still be canceled.
- {nome} is doing the farewell victory lap. It's slow on purpose. Catchable, coach.
- {nome} has hung up the cleats. Provisionally. The nail won't hold long: hurry.

## Rientro (hai rimediato in tempo)
- I KNEW coach wanted me back! Unpacking the bag — and tomorrow, double training to celebrate!
- Contract renewal! I'm signing with a high five. No, two. NO, TEN HIGH FIVES.
- Back on the team! No clauses: just guaranteed snacks and a coach who shows up. Deal.
- Medical passed, heart cleared, morale through the roof: the comeback is OFFICIAL, coach.
- Official return! I kissed the jersey. I don't own a jersey: I kissed my own fur. Still counts.
- The bag goes back in the closet and I go back in the lineup. We'll call it preseason camp. A very short one.
- Called back up! The kitchen bench is mine again. Best view in the house: you opening the fridge.
- Comeback with a bang: two hugs inside the first minute. The form is there, the rest will follow.

## Addio (parte davvero)
- I'm transferring, coach. No hard feelings. (Some hard feelings.)
- The final whistle came. Thanks for the great seasons. The other ones I'll forget for the both of us.
- I'm retiring from this team, not from the sport. If you ever reopen the stadium... I was always cheering for you.

## Lettera (dal pianeta dei ritirati)
- Coach, writing to you from the planet's locker room. I train every day for the rematch. All that's missing is you calling me back to the team.
- My jersey number is still hanging where I left it. Didn't give it to anyone. Your spot on the bench is waiting for mine: shall we sign the comeback?
- I'm training twice as hard, so when you call me back I'm ready. IF you call me back. WHEN you call me back. Going to run more sprints now.
- I tried teaming up with others. Solid folks, no disrespect. But I'm holding out for my captain: the armband stays open, and it's yours.
- We play every day here and I never lose. The secret, coach: winning with nobody cheering is just scoring points. Call me back and let's win for real again.
- [ESEMPIO] This planet is the bench, {utente}. I want the field, with you screaming from the stands. Blow the opening whistle: hit "Make amends" and I'm back in the game.

## Evoluzione
- I GREW! Junior league, here I come! The new legs need testing IMMEDIATELY.
- Evolved! Official promotion to the next division. The physique was already there — now there's even more physique.
- Look at these shoulders! Built on training and snacks. Mostly snacks, but you didn't hear that from me.
- New body, new records to break. The old ones I broke by growing. Literally.
- EVOLVED! The body got an upgrade, so the snacks need scaling up to match. That's science, coach.
- All grown! The old jerseys don't fit anymore: let's hang them from the rafters, like they do for the greats.
- I've gone pro! Contract terms: housing, cuddles and glory. Signed with a paw, valid forever.
- Evolved, coach! Warmups take longer now: there's more champion to warm up.

## Ha sonno (sotto soglia energia o prima delle 21)
- Coach, my tank is dry. I need real recovery or I'm collapsing on the field.
- Coach, I'm out of fuel. Even champions have a gas tank. Mine reads zero and it's making a whistling noise.
- Record-breaking yawn. Time it... no, don't time it, just carry me to bed, coach.
- A champion's body demands a champion's recovery. That's sports science, not laziness. (A little laziness.)
- I'll only run if the finish line is the bed. That's one race I can win even exhausted.
- Energy gone, coach. Even my inner anthem sat down. Carry me to bed champion-style: bodily.
- Coach, my muscles are on strike and the union stands united. Negotiations will only happen horizontally.
- Battery at zero. I left it all on the field. The field was the house, but I left it all anyway.

## Va a dormire (dalle 21, portato a letto)
- Athlete's rest, coach: scheduled sleep, wake-up in a few hours. I don't break protocol.
- Bedtime! Recovery is part of training: so technically I'm STILL winning.
- Goodnight, coach! Sleep is my second-favorite sport. And I'm elite at that one too.
- Goodnight! I'll dream about the final. In dreams I always win. I'm also the ref, but I win clean.
- Off to bed, coach: tomorrow is the derby against the alarm clock. I want to show up rested and win it on the first ring.
- Goodnight! Sleeping in sprinter's stance: if anything happens, I launch pre-warmed.
- Bedding down like a pro, coach: sleep is the one workout that never fails. Eight hours of flawless performance, guaranteed.
- In bed on time, like a professional. Evening discipline is tomorrow morning's victory. I invented that one — write it down.

## Sveglia (risveglio dopo il sonno)
- Awake and 100% charged! Recovery worked — back on the field!
- RISE AND SHINE! Breakfast, stretching and glory, in any order you like as long as breakfast is first.
- Eyes open, knees high! The mattress lost: I tried to stay, I SWEAR, but I'm just too strong.
- Awake! I ran all night in my dreams. Counting it as a training session.
- Up on the first ring, like the pros. The bed gave me a high five. In its own way. It was a pillow.
- Awake before the alarm! Beat it at the line. First trophy of the day: mine, again.
- GOOD MORNING! Waking up is my opening whistle: from now on, every minute is game time.
- Awake and explosive! Overnight the body did some home renovations: today it delivers a fully remodeled champion.

## Dormito male (crollato, non a letto)
- I slept on the field instead of in the locker room. Poor recovery, but the grit is intact!
- I slept on the sidelines. My imaginary physiotherapist is FURIOUS with you.
- Back locked up, floor-related. The medical report reads: "athlete management needs review". Your name is on it.
- Recovery failed: slept right where I dropped, like after a marathon. Minus the medal, though. Really missing the medal.
- Night spent floor-side, coach. This morning my champion body creaks like antique furniture.
- You woke me before full recovery. The rulebook is clear: compensation shall be paid in snacks.
- Is sleeping on the floor training? NO, coach. I tested it for you last night. It did not need testing.
- Early wake-up: incomplete recovery, mood like a silent locker room. Fixable with an immediate starting spot in the kitchen.

## Usa una parola imparata
- {parola}! Love it! That's my new victory shout: {parola}!
- "{parola}"! New battle cry! I'll shout it at the start, at the finish, and in the locker room!
- Coach, "{parola}" gets me SO pumped. I say it before every big effort. Including opening the fridge.
- "{parola}" is my pre-game mantra. Three reps and I'm UNSTOPPABLE: {parola}, {parola}, {parola}!
- "{parola}"! Twice as effective when said out of breath. Watch: *sprint* — {parola}!
- I put "{parola}" in the team anthem. That's the whole anthem: "{parola}, {parola}, olé".
- I dedicate "{parola}" to my coach, the way you dedicate a goal. By pointing at you. {parola}! (I'm pointing at you.)

## Gioca
- Training disguised as playtime! Sprints, feints, couch dives. Fun IS athletic conditioning.
- Pillow fight: three rounds, all mine. The pillow took the hits well — it gets the fair play award.
- Chasing my tail: ADVANCED agility drill. Never caught it. It's my all-time rival.
- Scrimmage in the living room! Me versus me: I win either way, but what a battle.

## Gioca col giocattolo
- NEW TOY! Official championship equipment. The preseason of fun starts NOW.
- What a piece of gear! Testing it right away: warmup, trial, celebration. The full protocol.
- My new teammate! Doesn't talk, doesn't complain, always plays: permanent roster spot.
- Toy promoted to starter after one tryout. Pure talent, you can tell right away. Like me.

## Passeggiata partenza
- Going for a lap around the field... the field is the neighborhood. Mental stopwatch running, obviously.
- An athlete's stroll: perfect posture, elegant stride. The neighborhood deserves the show.
- Heading out on athletic patrol! If I see anyone jogging, I'm overtaking them. I can't help it.
- Cooldown walk, coach. Even champions walk: it's called energy management. I read about it and I approve.

## Passeggiata monete
- Coins found! Correction: coins CONQUERED. Somebody had to bend down for them, and I bent down better than anyone.
- Today's haul: coins off the ground. Saw them first — champion reflexes. The sidewalk podium is mine.
- Scooped up coins at full speed without breaking stride. Elite technique, well-earned payout.
- Coins on the route! I'm counting them as the walk's prize money. Which I won, obviously.

## Passeggiata incontro
- Met another pet: INSTANT friendly match. Final score: a beautiful draw. (I was winning.)
- Found a new training partner on my walk! Strong, fast, fun. I want them on the team.
- Pickup game with a neighborhood pet. The skill, the intensity! Street ball is LIFE.
- Met a pet — three seconds later we were already racing. The best friendships start at a sprint.

## Passeggiata pozzanghera
- The puddle was right there, talking trash. I NEVER back down from a challenge. Legendary splash, zero regrets.
- Technical puddle dive: run-up, takeoff, landing. Textbook. The textbook of fun.
- Soaked and thrilled: I broke the neighborhood splash record. The old one belonged to a huge dog. RESPECT.
- Unscheduled water training. Fine — scheduled: I saw it from a distance and sped up.

## Passeggiata panorama
- The city lights from the bridge... I stopped. ME. Standing still. And it was beautiful, coach.
- Podium-worthy view today. I went quiet and soaked in the moment: that's training too — for the heart.
- Quiet moment on the bridge. The heart rate drops, the mind runs a victory lap without moving.
- Full sun everywhere, like a stadium on finals day. And tomorrow we play again. How lucky are we, coach.

## Passeggiata rottame
_(socio: 4 battute — torna con un rottame/pezzo alieno luccicante trovato per strada (+monete))_
- Back with today's trophy: a shiny piece of scrap! Spotted it with my talent-scout eye. Podium material, trust me.
- Alien metal piece: CONQUERED! Well, picked up. But with style worthy of a conquest.
- My loot: a piece of scrap that shines like a trophy. Straight into the cabinet. The cabinet is yours, the trophy is ours.
- Saw something glinting by the roadside. Sharp reflexes, fast paw: MINE.

## Passeggiata piccione
_(socio: 4 battute — ha rincorso un piccione cyborg / drone per mezza città (+Felicità, −Energia))_
- Raced a cyborg pigeon. It won, BUT it had thrusters. I'm filing for disqualification: technological doping.
- Epic chase with a robo-pigeon! Didn't catch it: that bird trains harder than me. RESPECT. And a rematch.
- The pigeon dropped me in the final sprint. Technically it was flying. But on points I won: more heart, fewer circuits.
- Half the city sprinting after a half-robot pigeon. Beaten but improved: that pigeon is my new fitness trainer.

## Passeggiata assaggio
_(socio: 4 battute — un ambulante gli molla uno spuntino gratis al volo (+Fame))_
- The street vendor tossed me a free snack: surprise pit stop! The whole neighborhood is rooting for me.
- Free snack mid-lap! Caught it without stopping: relay-handoff technique. Delicious.
- Loyalty prize from the street vendor: a free taste. Champions get recognized, even on a walk.
- Unscheduled supplement offered by the fans! Accepted with professionalism, devoured with enthusiasm.

## Passeggiata acquazzone
_(socio: 4 battute — acquazzone improvviso: torna zuppo ma bello pulito (+Igiene, −Felicità))_
- Downpour mid-route! Drenched but clean: shower and cooldown in one move. Efficiency, coach.
- Rain caught me halfway through the lap. I kept going: champions don't melt. But WOW it was cold, coach.
- Soaked! The weather reffed dirty today. At least I'm coming home clean: the sky threw in a free wash.
- Rain training: not requested. Completed anyway. Blanket now, please: even the tough ones shiver.

## Passeggiata persi
_(socio: 4 battute — si è perso e ha girovagato: gran avventura, ma stanco (+Felicità, −Energia))_
- Got lost and improvised a brand-new route: double the miles! Legs destroyed, endurance record mine.
- Warm-up lap turned into a marathon by navigation error. The error is mine, and so is the glory.
- Lost across half the city. Found my way back on pure champion instinct. My legs want a substitution. My heart doesn't.
- Off-course adventure! I saw the neighborhood like nobody sees it: out of breath. Coming home tired and a champion.

## Passeggiata cielo
_(socio: 4 battute — vede un'astronave/UFO passare bassa sui tetti (+Felicità, worldbuilding sci-fi))_
- A spaceship flying low over the rooftops! I stopped mid-sprint. Some things beat training, coach.
- UFO over the neighborhood! Serious speed. Timed it by eye: extremely fast. I respect it as a rival.
- The sky put on a championship-final show today: low-flying spaceship in full daylight. I applauded from the curb.
- Saw a spaceship and thought: I wonder if they train up there. If they do, I want a friendly match.

## Passeggiata bulletto
_(socio: 4 battute — incrocia un pet maleducato: parole grosse, morale un po' giù (−Felicità))_
- Crossed paths with a dirty player: big words, zero sportsmanship. I didn't react. Champions answer on the field, not in the street.
- A bully tried to provoke me. I kept my head high and my stride long. Win on points, but morale took a hit.
- Rough encounter today: an unsportsmanlike pet. Ruined my victory lap. Tomorrow I train for that too.
- Big talk from a rude pet. I let it drop: the rulebook of the heart bans brawls. But MAN am I steamed, coach.

## Notifica missione finita
Notifica push sul telefono quando una missione si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}` disponibile. Finché questa lista è vuota il gioco usa un testo neutro.
- {nome} is back from the mission, chest puffed out. Come check if it's earned.
- Mission over! {nome}'s already on a victory lap in the living room. Join in, coach!
- Your champion is back! Got a result and ZERO patience left to wait. Open up!
- {nome} is back! The mission play-by-play starts the second you walk in. Don't be late.
- Comeback complete! {nome} is keeping the result warm like a trophy ceremony. Run!

## Notifica allenamento finito
Notifica push quando l'allenamento si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}`. Finché vuota: testo neutro.
- {nome} CRUSHED it in training. Muscles don't applaud themselves. Open up!
- Session over! {nome} needs their coach for the shouted recap. That's you. Run.
- Training complete! {nome} is pumped and wants to show you the champion pose. NOW.
- {nome} finished the drills and started celebrating. Only thing missing: the crowd. You!


## Notifica carica a rischio
Notifica della sera, SOLO se la carica e' a rischio (streak >= 3 e giornata senza cura). Ricorda, non rimprovera. Una battuta per riga con `- `, slot `{nome}`.
- Last minute of the game. {nome} is open for the pass.
- {nome} kept the streak alive this far. Don't drop it now.
- The charge is running out and {nome} is still on the field. Just one touch.
- {nome} won't give an inch. But it can't score alone. Come on.

## Notifica silenzio lungo
Notifica dopo 3+ giorni di assenza. Tono leggero: il pet se la cava, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{nome}`.
- Three days on the bench. {nome} trained anyway. It's not the same.
- {nome} ran solo. Fine, but the times are worse with nobody cheering.
- Empty stands for three days. {nome} still plays, just quieter.
- {nome} is keeping your spot warm. While insisting it isn't.

## Reazione assenza lunga
Il pet ti rivede dopo 3+ giorni. Tono leggero: se l'e' cavata, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{utente}`.
- Three days on the bench. I trained anyway. But a crowd helps.
- There you are. Warm-up and we go again, come on.
- I kept your spot warm. While insisting I wasn't keeping it.

## Reazione ora assurda
Apri il gioco fra l'una e le cinque del mattino. Il pet lo fa notare. Una battuta per riga con `- `, slot `{utente}`.
- At this hour? No athlete trains at two in the morning. Nobody.
- Fine, night warm-up. But you owe me double tomorrow.
- Rest IS training. People actually say that, look it up.

## Reazione batteria scarica
La batteria del telefono e' sotto il 10%. Il pet ci scherza sopra. Una battuta per riga con `- `, slot `{utente}`.
- Battery on the floor. Even champions refuel.
- Final minute and you're out of breath. Get it on the charger.
- Under ten percent. Mandatory time-out, come on.

## Reazione tema scuro
Il telefono e' in tema scuro. Battuta di colore, nessuna conseguenza. Una battuta per riga con `- `, slot `{utente}`.
- Dark mode, lights down, locker-room vibes. I like it.
- Night mode. From here on we play for real.
- Lights out in the arena. Enter the champion.
