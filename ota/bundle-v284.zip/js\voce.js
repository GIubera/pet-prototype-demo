/* PETQ.voce — la voce VERA del pet (TTS), Retention 2.0 / C2
 *
 * Si usa POCA E BENE (decisione di design nel doc): solo le parole INSEGNATE dal giocatore. Le
 * battute lunghe restano testo, con l'animalese sintetizzato in audio.js a fare il verso. Un pet
 * che legge ad alta voce ogni vignetta con la voce del navigatore satellitare non e' un pet.
 *
 * PERCHE' UN PLUGIN NATIVO E NON L'API WEB: window.speechSynthesis NON esiste dentro la WebView
 * di Android — quella in cui gira un'app Capacitor. Non e' una svista: Chromium ha separato
 * apposta i due permessi (ScriptedSpeechRecognition / ScriptedSpeechSynthesis) per abilitare il
 * riconoscimento vocale in WebView e NON la sintesi, e a luglio 2026 e' ancora cosi' (verificato
 * su caniwebview.com e su segnalazioni con Chromium 138: speechSynthesis risulta undefined).
 * Su Chrome per Android funziona, ma Chrome per Android non e' il posto dove gira il gioco.
 * Quindi: sul telefono parla il plugin @capacitor-community/text-to-speech (motore TTS di
 * sistema, offline, nessun permesso nel manifest); sul PC del fondatore, dove il gioco gira in
 * un browser vero, si ripiega su speechSynthesis cosi' la voce si puo' giudicare senza APK.
 *
 * CONTRATTO, identico a notifiche.js: se non c'e' ne' l'uno ne' l'altro, ogni funzione qui e' un
 * no-op silenzioso. Una voce che non parte non puo' rompere una partita.
 */
(function () {
  'use strict';
  window.PETQ = window.PETQ || {};

  function plugin() {
    return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.TextToSpeech) || null;
  }

  function sintesiWeb() {
    return (window.speechSynthesis && window.SpeechSynthesisUtterance) ? window.speechSynthesis : null;
  }

  /* Manopole per specie (doc: "robot=alto/metallico, alieno=basso/lento"). La voce di sistema e'
   * la stessa per tutti — quello che cambia il personaggio sono tonalita' e velocita', e sono
   * anche cio' che maschera quanto suonano diversi i motori TTS da telefono a telefono: una voce
   * gia' distorta di suo non ha una "qualita' giusta" da cui scostarsi.
   * Limiti rispettati apposta: pitch 0-2 e rate 0.1-10 sull'implementazione web; Android accetta
   * comodamente questa forbice. */
  var VOCI = {
    robot:      { pitch: 1.7, rate: 1.15 },
    blob:       { pitch: 0.8, rate: 0.85 },
    insettoide: { pitch: 2.0, rate: 1.40 }, // chiave = valore VERO di pet.js (era "insetto": mai agganciata)
    rettiliano: { pitch: 0.7, rate: 0.90 },
    leggenda:   { pitch: 0.6, rate: 0.95 }
  };

  // Stessa chiave di razza usata dall'animalese, presa da audio.js per non tenere due tabelle
  // che possono divergere (un pet non puo' avere due identita' vocali diverse).
  function chiaveVoce(petLike) {
    if (window.PETQ.audio && PETQ.audio.voceDi) return PETQ.audio.voceDi(petLike);
    return 'robot';
  }

  // La parola l'ha scritta il giocatore nella SUA lingua: si usa quella dell'interfaccia, che e'
  // la cosa piu' vicina che abbiamo. Con la lingua sbagliata il motore la pronuncia con le regole
  // di un'altra e viene fuori una parola diversa.
  // 'it' | 'en' — la lingua del GIOCO, che e' anche la lingua in cui il giocatore scrive le
  // parole da insegnare: decide le regole di lettura della sintesi (audio.js inSuoni).
  function linguaCorta() {
    return (window.PETQ.i18n && PETQ.i18n.lingua) ? PETQ.i18n.lingua() : 'it';
  }

  function lingua() {
    return linguaCorta() === 'en' ? 'en-US' : 'it-IT';
  }

  function disponibile() {
    return !!(plugin() || sintesiWeb());
  }

  /* Dice ad alta voce un testo BREVE (una parola, un nome, una catchphrase).
   * Ritorna true se la richiesta e' partita davvero. Rispetta l'interruttore audio del gioco:
   * chi ha spento i suoni non si aspetta una voce che parla. */
  /* Chi parla con COSA (correzione del fondatore, 29 lug 2026: "la voce deve essere robotica per
   * il robot e strana, storta e acuta per l'alieno; per le leggende, visto che sono umane, va
   * bene quella").
   *
   * Il motore vocale di sistema restituisce SEMPRE una voce umana e le sue uniche manopole
   * (tonalita' e velocita') danno al massimo un umano acuto: per un robot non basta, e il suo
   * audio non e' intercettabile, quindi non ci si puo' applicare sopra nessun effetto. Percio'
   * robot e alieni parlano con la voce COSTRUITA a formanti (v. audio.js parlaParola), che e'
   * l'unico modo di avere una parola vera detta da una macchina.
   * Le leggende sono personaggi umani: per loro il TTS di sistema e' la scelta giusta, non un
   * ripiego. */
  /* Da v272 la mappa e' l'IDENTITA': ogni sottorazza ha il SUO profilo in audio.js PROFILI_VOCE
   * (fondatore dal set: "la voce e' sempre la stessa" — blob e insettoide dicevano le parole con
   * un unico profilo 'alieno'). La tabella resta come punto di aggancio: chi non c'e' qui non ha
   * voce sintetica (le leggende, che sono umane e parlano col TTS). */
  var SINTETICA = { robot: 'robot', blob: 'blob', insettoide: 'insettoide', rettiliano: 'rettiliano' };

  /* INTERRUTTORE, e il motivo per cui esiste: la prima sintesi a formanti scritta a mano NON era
   * comprensibile (verdetto del fondatore: "non dicono nessuna parola, fanno una specie di suono
   * per le sillabe, e robot e alieno sono quasi identici"). Finche' la voce costruita non regge
   * la prova dell'orecchio, il gioco DEVE uscire con quella che almeno pronuncia le parole: una
   * voce umana in bocca a un robot e' un difetto di carattere, una voce incomprensibile e' un
   * difetto e basta.
   * Chiave in localStorage cosi' il fondatore puo' confrontare le due senza ricompilare niente. */
  var CHIAVE_MODO = 'petq_voce_modo';
  var MODI = ['robotizzata', 'sistema', 'sintesi']; // il primo e' il default

  function modo() {
    try {
      var m = window.localStorage && window.localStorage.getItem(CHIAVE_MODO);
      for (var i = 0; i < MODI.length; i++) if (MODI[i] === m) return m;
      return MODI[0];
    } catch (e) {
      return MODI[0];
    }
  }

  function impostaModo(m) {
    try {
      if (window.localStorage) window.localStorage.setItem(CHIAVE_MODO, m);
    } catch (e) { /* niente localStorage: resta il default */ }
  }

  function modoProssimo() {
    var i = MODI.indexOf(modo());
    return MODI[(i + 1) % MODI.length];
  }

  /* ---------- VOCE ROBOTIZZATA: la strada giusta, trovata al terzo tentativo ----------
   *
   * Il problema era che le due cose servivano insieme e sembravano incompatibili: il motore di
   * sistema PRONUNCIA bene le parole ma ha voce umana; una voce costruita da me suona robotica ma
   * non e' riuscita a dire nessuna parola. E l'audio del motore di sistema, quando parla lui, non
   * e' intercettabile.
   *
   * Ma esiste synthesizeToFile: il motore di sistema scrive l'audio in un FILE invece di suonarlo.
   * Da li' il file e' nostro — lo si legge, lo si decodifica e lo si fa passare per una catena
   * Web Audio che lo rende una macchina. Il motore mette la pronuncia, noi mettiamo il timbro.
   *
   * L'effetto e' la MODULAZIONE AD ANELLO (il segnale moltiplicato per un'onda a bassa
   * frequenza): e' l'effetto con cui si fa parlare i Dalek di Doctor Who da sessant'anni, ed e'
   * scelto apposta perche' rende metallico SENZA distruggere la parola — moltiplicare non tocca
   * l'inviluppo, quindi le sillabe restano dove sono. Un vocoder o un bitcrusher spinto sarebbero
   * piu' "sci-fi" ma rischierebbero di ripetere l'errore di prima.
   *
   * LIMITE, da dire chiaro: synthesizeToFile esiste solo su telefono. Sul PC il plugin non c'e',
   * quindi resta la voce di sistema nuda — la voce robotica si puo' giudicare solo dall'APK.
   */
  /* PERCHE' L'ALIENO NON PUO' ESSERE "IL ROBOT CON ALTRI NUMERI" (correzione del fondatore:
   * "l'alieno e' pero' identico"). Avevo differenziato le due voci sullo STESSO asse — modulazione
   * ad anello, solo con una frequenza diversa — ed e' esattamente l'errore gia' fatto a luglio coi
   * suoni del gioco: due cose modulate ad anello suonano imparentate qualunque numero ci metti,
   * perche' l'orecchio riconosce prima la FAMIGLIA dell'effetto e poi i suoi parametri.
   * Quindi ogni voce qui ha un effetto di famiglia diversa, non una taratura diversa.
   *
   * effetto 'anello'   = moltiplicazione ad anello -> metallico, fermo, macchina.
   * effetto 'ondeggia' = altezza che oscilla di continuo -> vivo ma instabile, sbagliato, alieno.
   *                      NIENTE anello: e' la firma del robot e condividerla e' il difetto.
   * effetto 'coro'     = due copie scordate e sfasate -> due gole che parlano insieme, non umano.
   */
  var ROBOTIZZA = {
    // APPROVATO dal fondatore: "robot va bene".
    robot: { effetto: 'anello', anello: 42, velocita: 0.92, risonanza: 1400, guadagnoRis: 9, passaAlto: 180 },

    // I quattro candidati per l'alieno, da far scegliere a orecchio.
    // La prima e' la sua trovata girando le manopole ("velocita 1.6 puo' essere accettabile").
    alieno_acuto:    { effetto: 'anello', anello: 128, velocita: 1.60, risonanza: 2600, guadagnoRis: 11, passaAlto: 300 },
    alieno_insetto:  { effetto: 'ondeggia', velocita: 1.34, ondaHz: 7.5, ondaProf: 0.045, passaAlto: 600, passaBasso: 5200 },
    alieno_liquido:  { effetto: 'ondeggia', velocita: 1.12, ondaHz: 2.8, ondaProf: 0.10, passaAlto: 200, passaBasso: 2200 },
    alieno_coro:     { effetto: 'coro', velocita: 1.22, detune: 18, ritardo: 0.019, passaAlto: 350, passaBasso: 4200 }
  };
  // SCELTA DEL FONDATORE (29 lug 2026): "una tra A e D, per ora metti D" — il coro.
  // Gli altri tre candidati restano nella tabella apposta: se cambia idea e' una riga sola, e
  // la pagina di prova continua a farli sentire tutti senza che io debba riscriverli.
  ROBOTIZZA.alieno = ROBOTIZZA.alieno_coro;
  // Da v272 SINTETICA passa la SOTTORAZZA ('blob'/'insettoide'/'rettiliano'), non piu' 'alieno':
  // senza questi alias la catena del telefono cadrebbe sul ripiego ROBOT — la stessa regressione
  // appena corretta, riproposta dall'altra porta. Sul telefono le tre sottorazze condividono per
  // ora il coro: differenziarle anche qui e' un lavoro a parte, da fare a orecchio col fondatore.
  ROBOTIZZA.blob = ROBOTIZZA.alieno;
  ROBOTIZZA.insettoide = ROBOTIZZA.alieno;
  ROBOTIZZA.rettiliano = ROBOTIZZA.alieno;

  function pluginSintesi() {
    return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.SpeechSynthesis) || null;
  }

  /* Costruisce la catena e suona il buffer. Separata apposta: e' l'UNICA parte che posso
   * collaudare sul PC (con un buffer qualunque), visto che il file vero arriva solo dal telefono. */
  function suonaRobotizzato(audioBuffer, profilo, override) {
    var A = window.PETQ.audio;
    var ctx = A && A._contesto && A._contesto();
    if (!ctx || !audioBuffer) return false;
    var base = ROBOTIZZA[profilo] || ROBOTIZZA.robot;
    // override: serve SOLO alla pagina di prova (scratchpad/prova-voce.html), dove il fondatore
    // gira le manopole a orecchio e mi dice i numeri che gli piacciono. In gioco non arriva mai.
    var p = {};
    for (var kb in base) if (Object.prototype.hasOwnProperty.call(base, kb)) p[kb] = base[kb];
    if (override) {
      for (var k in override) if (Object.prototype.hasOwnProperty.call(override, k)) p[k] = override[k];
    }

    var t = ctx.currentTime + 0.02;
    var durata = audioBuffer.duration / p.velocita + 0.08;
    var uscita = ctx.createGain();
    uscita.connect(A._master ? A._master() : ctx.destination);

    // Una sorgente. `ondaHz` fa OSCILLARE l'altezza: playbackRate e' un parametro pilotabile, si
    // puo' collegare un oscillatore lento e la voce ondeggia da sola. E' questo, non l'altezza
    // fissa, a rendere una voce "sbagliata" invece che semplicemente acuta.
    function sorgente(detuneCent, ritardoSec) {
      var s = ctx.createBufferSource();
      s.buffer = audioBuffer;
      s.playbackRate.value = p.velocita;
      if (detuneCent) s.detune.value = detuneCent;
      if (p.ondaHz) {
        var lfo = ctx.createOscillator();
        lfo.type = 'sine';
        lfo.frequency.value = p.ondaHz;
        var amp = ctx.createGain();
        amp.gain.value = p.velocita * (p.ondaProf || 0.05);
        lfo.connect(amp);
        amp.connect(s.playbackRate);
        lfo.start(t);
        lfo.stop(t + durata);
      }
      s.start(t + (ritardoSec || 0));
      return s;
    }

    function passabanda(nodo) {
      var n = nodo;
      if (p.passaAlto) {
        var hp = ctx.createBiquadFilter();
        hp.type = 'highpass';
        hp.frequency.value = p.passaAlto;
        n.connect(hp); n = hp;
      }
      if (p.passaBasso) {
        var lp = ctx.createBiquadFilter();
        lp.type = 'lowpass';
        lp.frequency.value = p.passaBasso;
        n.connect(lp); n = lp;
      }
      return n;
    }

    if (p.effetto === 'coro') {
      // Due copie: una scordata di qualche centesimo e leggermente in ritardo. Il cervello le
      // sente come DUE gole, ed e' una cosa che nessun essere umano puo' fare da solo.
      uscita.gain.value = 0.85;
      var a = sorgente(0, 0);
      var b = sorgente(p.detune || 15, p.ritardo || 0.02);
      var mix = ctx.createGain();
      a.connect(mix); b.connect(mix);
      passabanda(mix).connect(uscita);
      return true;
    }

    if (p.effetto === 'ondeggia') {
      // Nessun anello: e' la firma del robot, e condividerla e' proprio cio' che rendeva le due
      // voci imparentate. Qui parla l'oscillazione dell'altezza.
      uscita.gain.value = 1.1;
      passabanda(sorgente(0, 0)).connect(uscita);
      return true;
    }

    // 'anello' (robot, e il candidato alieno acuto): il segnale moltiplicato per un'onda che passa
    // anche in NEGATIVO — il guadagno parte da zero e lo pilota interamente l'oscillatore. Con un
    // offset positivo sarebbe solo un tremolo, molto meno metallico.
    uscita.gain.value = 1.6; // l'anello dimezza l'energia: si recupera qui
    var src = sorgente(0, 0);
    var anello = ctx.createGain();
    anello.gain.value = 0;
    var osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.value = p.anello;
    var prof = ctx.createGain();
    prof.gain.value = 1;
    osc.connect(prof);
    prof.connect(anello.gain);
    osc.start(t);
    osc.stop(t + durata);

    // Risonanza fissa: una cavita' metallica. E' quello che fa "scatola" invece di "gola".
    var ris = ctx.createBiquadFilter();
    ris.type = 'peaking';
    ris.frequency.value = p.risonanza;
    ris.Q.value = 1.2;
    ris.gain.value = p.guadagnoRis;

    src.connect(anello);
    anello.connect(ris);
    passabanda(ris).connect(uscita);
    return true;
  }

  /* Percorso completo: fai scrivere l'audio al motore di sistema, leggilo, robotizzalo.
   * Asincrono, e ogni passo puo' fallire (motore assente, lingua non installata, file non
   * leggibile): ad ogni inciampo si ripiega sulla voce nuda, che almeno dice la parola.
   *
   * `voceRazza` (pitch/rate da VOCI) e' il fix del bug dal telefono (fondatore, 12 ago 2026:
   * "l'insettoide dice la prima volta la parola con voce acuta e poi torna a parlare come un
   * robot"): la sintesi del file era INCHIODATA a pitch 1.0 / rate 1.0, buttando via
   * l'intonazione della razza — mentre il RIPIEGO (voce nuda) la usava. Risultato: la prima
   * parola (che cade nel ripiego finche' il contesto audio non e' pronto) usciva acuta da
   * insettoide, le successive passavano dalla catena a tono piatto e suonavano da robot.
   * Ora il file si sintetizza GIA' intonato per razza e il coro ci si applica sopra: prima e
   * dopo hanno lo stesso carattere. */
  function pronunciaRobotizzata(testo, profilo, ripiego, voceRazza) {
    var p = pluginSintesi();
    var A = window.PETQ.audio;
    if (!p || !p.synthesizeToFile || !A || !A._contesto || !window.Capacitor.convertFileSrc) {
      return ripiego();
    }
    var vr = voceRazza || { pitch: 1.0, rate: 1.0 };
    p.synthesizeToFile({ text: perVoce(testo), language: lingua(), pitch: vr.pitch, rate: vr.rate, volume: 1.0 })
      .then(function (r) {
        if (!r || !r.filePath) throw new Error('nessun file');
        // convertFileSrc trasforma un percorso di sistema in un URL che la WebView puo' leggere:
        // senza, un fetch su file:// viene bloccato.
        return fetch(window.Capacitor.convertFileSrc(r.filePath));
      })
      .then(function (risp) { return risp.arrayBuffer(); })
      .then(function (buf) {
        var ctx = A._contesto();
        if (!ctx) throw new Error('niente audio');
        return ctx.decodeAudioData(buf);
      })
      .then(function (audioBuffer) {
        if (!suonaRobotizzato(audioBuffer, profilo)) ripiego();
      })
      .catch(function () { ripiego(); });
    return true;
  }

  function pronuncia(testo, petLike) {
    try {
      if (!testo) return false;
      if (window.PETQ.audio && PETQ.audio.attivo && !PETQ.audio.attivo()) return false;

      var chiave = chiaveVoce(petLike);
      var m = modo();
      var profiloRazza = SINTETICA[chiave]; // null per le leggende: sono umane e restano tali

      // Voce nuda del motore di sistema: e' anche il RIPIEGO di tutti gli altri modi, percio'
      // vive in una funzione a se' invece di essere ripetuta tre volte.
      var v = VOCI[chiave] || VOCI.robot;
      function vocePiena() { return parlaColSistema(testo, v); }

      if (profiloRazza && m === 'sintesi' && window.PETQ.audio && PETQ.audio.parlaParola) {
        if (PETQ.audio.parlaParola(testo, profiloRazza, linguaCorta()) > 0) return true;
        return vocePiena();
      }

      if (profiloRazza && m === 'robotizzata') {
        return pronunciaRobotizzata(testo, profiloRazza, vocePiena, v);
      }

      return vocePiena();
    } catch (e) {
      return false; // mai un throw: una voce muta e' un peccato, una partita rotta e' un bug
    }
  }

  // Le MAIUSCOLE compitate (fix "fa lo spelling lettera per lettera", fondatore 8 ago 2026):
  // i motori TTS leggono una parola tutta maiuscola come una SIGLA — "PIZZA" diventa
  // P-I-Z-Z-A, e con la lingua inglese pure coi nomi inglesi delle lettere. Le parole
  // insegnate arrivano come le ha scritte il giocatore (spesso in caps) e anche le battute
  // del socio urlano in maiuscolo (PAURINA, MARONN'): per la VOCE si abbassano le sequenze
  // di 2+ maiuscole; il testo A SCHERMO resta com'e'. Una maiuscola singola (inizio frase,
  // "Il") non si tocca: non viene mai compitata.
  function perVoce(testo) {
    return String(testo).replace(/[A-ZÀ-ÖØ-Þ]{2,}/g, function (m) { return m.toLowerCase(); });
  }

  function parlaColSistema(testo, v) {
    try {
      var p = plugin();
      if (p && p.speak) {
        // queueStrategy 1 = Add in coda; 0 = Flush, azzera quello che sta dicendo. Si sceglie
        // Flush: se il pet dice due parole di fila, l'ultima e' quella che conta, e una coda che
        // si accumula farebbe parlare il pet di cose successe mezzo minuto prima.
        p.speak({ text: perVoce(testo), lang: lingua(), rate: v.rate, pitch: v.pitch, volume: 1.0, queueStrategy: 0 })
          .catch(function () { /* motore assente o lingua non installata: silenzio */ });
        return true;
      }

      var s = sintesiWeb();
      if (s) {
        try { s.cancel(); } catch (e) { /* niente da azzerare */ }
        var u = new window.SpeechSynthesisUtterance(perVoce(testo));
        u.lang = lingua();
        u.rate = v.rate;
        u.pitch = v.pitch;
        s.speak(u);
        return true;
      }
      return false;
    } catch (e) {
      return false; // mai un throw: una voce muta e' un peccato, una partita rotta e' un bug
    }
  }

  function taci() {
    try {
      var p = plugin();
      if (p && p.stop) { p.stop().catch(function () {}); return; }
      var s = sintesiWeb();
      if (s) s.cancel();
    } catch (e) { /* silenzioso */ }
  }

  window.PETQ.voce = {
    pronuncia: pronuncia,
    taci: taci,
    disponibile: disponibile,
    modo: modo,
    impostaModo: impostaModo,
    // per il pannello debug: dice DA DOVE uscirebbe la voce, che e' la prima cosa da sapere
    // quando il fondatore segnala "non parla".
    modoProssimo: modoProssimo,
    // Profilo della voce SINTETICA a formanti per questo pet: 'robot' | 'alieno', null per le
    // leggende (sono umane per design e restano tali). Esposto perche' l'attrezzo di scena del
    // pannello debug deve poter chiedere l'ANIMALESE a colpo sicuro — sul PC il modo
    // 'robotizzata' non ha il plugin nativo e ripiegherebbe sulla voce umana di sistema — senza
    // ricopiarsi qui la tabella SINTETICA, che diverge al primo cambio di razza.
    profiloSintetico: function (petLike) { return SINTETICA[chiaveVoce(petLike)] || null; },
    _suonaRobotizzato: suonaRobotizzato, // esposta per collaudare la catena sul PC
    // La pagina di prova LEGGE i valori da qui invece di ricopiarli: se ritocco un profilo nel
    // gioco, la pagina si aggiorna da sola e non faccio giudicare al fondatore numeri che nel
    // codice non esistono piu'.
    _profili: function () { return ROBOTIZZA; },
    _sorgente: function (petLike) {
      var m = modo();
      var profilo = petLike ? SINTETICA[chiaveVoce(petLike)] : null;
      if (profilo && m === 'sintesi') return 'sintesi a formanti (' + profilo + ')';
      if (profilo && m === 'robotizzata') {
        return pluginSintesi()
          ? 'robotizzata (' + profilo + ')'
          : 'robotizzata NON disponibile qui -> voce di sistema';
      }
      if (plugin()) return 'plugin nativo';
      if (sintesiWeb()) return 'browser (speechSynthesis)';
      return 'nessuna';
    }
  };
})();
