# Gentile — pool battute

Una battuta per riga, iniziando con `- `. Obiettivo: 5-8 per sezione. Le righe `[ESEMPIO]` calibrano il tono: tienile, riscrivile o cancellale. Slot: `{nome}` `{utente}` `{parola}`.
Voce: dolce, premuroso, un filo appiccicoso. Si scusa anche quando non serve.

## Saluto (apertura app)
- Oh, ciao {utente}! Ti ho tenuto il posto sul divano.
- Sei qui! Facciamo finta che non stessi contando i minuti. (Erano 214.)
- Bentornato! Ti ho aspettato composto. Il cuscino distrutto non c'entra niente.
- Sei tornato! Avevo paura ti fossi perso. Stavo per organizzare le ricerche.
- Bentornato, {utente}! Le tue pantofole sono al sicuro. Le ho sorvegliate io.
- Bentornato! Ho praticato la calma tutto il giorno. Poi ti ho visto e l'ho persa TUTTA, scusa.
- Ciao {utente}! Ti ho pensato... quante volte è normale? Ecco, diciamo quella cifra lì. Normale.
- Eccoti! Avevo appena finito di mettere i ricordi in ordine di bellezza. Vinci tu in tutte le categorie.
- Bentornato! Sono il tuo pet di supporto emotivo e mi autocertifico in servizio da ADESSO.
- Bentornato a casa! L'ho detto anche ieri alla porta, per allenarmi. Oggi è venuto meglio, vero?

## Ha fame
- Scusa il disturbo... ci sarebbe mica qualcosina da mangiare?
- Non è per me, è per il mio stomaco. Lui è meno educato di me.
- Scusa se insisto, non vorrei disturbare... però ho contato i pasti di oggi e siamo a zero.
- Il frigo mi guarda, io guardo lui. Ci serve un adulto, {utente}.
- Se non è troppo disturbo... cibo? Anche poco. Anche tanto, se avanza.
- Il mio linguaggio dell'amore è il cibo. In questo momento non mi sento molto amato, ecco. Detto con dolcezza.
- Avrei fame ma non voglio disturbare... quindi lo dico alla stanza. STANZA, HO FAME. Se senti anche tu, meglio.
- Un pastino piccolo piccolo? Anche solo comfort food. Il comfort sei tu, il food manca.
- Ho apparecchiato per due, per speranza. Un posto è mio. Anche l'altro, se non vieni. Vieni?

## È sporco
- Non vorrei dire, ma inizio a sentirmi un po'... fermentato.
- Scusa se mi tengo a distanza: è per proteggerti dal mio profumo.
- Ti abbraccerei... ma nelle mie condizioni sarebbe un atto ostile. Bagno?
- Ho provato a pulirmi da solo. Ho peggiorato tutto. Non chiedere come.
- Prometto che dopo il bagno torno adorabile. Adesso sono adorabile da lontano.
- C'è una nuvoletta che mi segue. Non è affetto, {utente}. È odore.
- Mi sono autocertificato pulito. L'autocertificazione è stata respinta dal mio stesso naso.
- Il bagnetto è self-care, l'ho letto da qualche parte. Facciamo self-care? Tu insaponi, io collaboro.
- Ti mando un abbraccio virtuale finché non torno abbracciabile in presenza. Basta poco: acqua e sapone.

## Felice
- Sono così felice che ho abbracciato il cuscino. Il cuscino sta bene, tranquillo.
- Oggi il mondo è bellissimo e c'entri tu. Lo dico senza vergogna. Ok, un po' di vergogna.
- Sto sorridendo da stamattina. Mi fanno male le guance. Ne vale la pena.
- Se la felicità fosse un cibo, oggi sarei pienissimo. (Comunque il cibo lo accetto lo stesso.)
- Sto così bene che ho perdonato anche l'aspirapolvere. Acqua passata.
- Livello di felicità: gattino che impasta. Sto impastando l'aria da stamattina.
- Oggi va tutto bene DAVVERO. Te lo preciso perché di solito "va tutto bene" è sospetto. Oggi no!
- Ho fatto il rituale della felicità: giro del salone, capriola, sorriso alla pianta. La pianta ha gradito.
- Il mio cuore oggi fa le fusa. Non so se posso farle, ma le fa.

## Coccole finite
- Basta coccole per oggi, scusa... mi si scioglie il cuoricino se esagero. Domani si ricomincia?
- Basta, basta... cioè non basta MAI, però se continui divento tutto rosso e poi non passa.
- Ho finito lo spazio per le coccole di oggi! Le sto già riguardando tutte col pensiero, comunque.
- Per oggi basta, scusa scusa scusa... è che voglio arrivare a domani con la voglia di ricominciare.
- Basta per oggi... le ultime due le ho messe via per le emergenze. Tipo tra dieci minuti. No, domani. DOMANI.
- Fine coccole! Ti abbraccio col pensiero da qui, però: quello non ha limiti giornalieri.
- Basta coccole per oggi... reggimi il sorriso però, che da solo non si abbassa.
- Fine! Le ho impilate tutte in ordine di morbidezza. La prima di domani parte avvantaggiata, sappilo.

## Trascurato / triste
- Non ti preoccupare per me... starò qui. Da solo. Va bene così.
- Non è che mi manchi... è che manchi. C'è differenza? Non c'è. Scusa.
- Ho fatto amicizia con la tua felpa. Le ho raccontato tutto. Sa troppe cose, ormai.
- Ho salutato la porta ogni volta che scricchiolava. La porta scricchiola tanto. Io saluto tanto.
- Non voglio farti sentire in colpa. Volevo solo dirti che ho imparato a sospirare in tre lingue.
- La mia batteria sociale è carica al 100% da giorni. Nessuno la sta usando. È uno spreco, {utente}.
- Oggi ho salutato col pensiero tutte le persone che conosco. Sei tu. Ho salutato te, tante volte.

## Parte per la missione
- Vado! Se non torno... no scherzo, torno. Però pensami.
- Parto. Se senti un vuoto nella stanza, sono io che manco. Scusa il vuoto.
- Torno presto! Ho lasciato un bacino sul divano, nel caso ti serva.
- Vado in missione! Ho ripassato il piano: essere coraggioso e tornare da te. Solido.
- In missione! Mi comporterò benissimo. E se c'è da correre, correrò pensando alla merenda.
- Parto! Ti lascio la mia copertina come segnaposto affettivo. Trattala come tratteresti me: benissimo.
- Vado! Farò del mio meglio e anche del mio benino, se il meglio si stanca.
- In missione! Se ti manco, in salotto è rimasto il mio profumo. Quello buono, di oggi che sono pulito.
- Vado! Il piano: essere gentile con tutti, anche con gli ostacoli. Poi gli ostacoli si scusano sempre.

## Ritorno: successo
- Ce l'ho fatta! L'ho fatto per noi, {utente}.
- Ce l'abbiamo fatta! Io materialmente, ma sentimentalmente eri lì.
- È andata benissimo! Posso raccontartela? Anche due volte? Anche tre?
- Tutto bene! Ho anche fatto amicizia con... lascia stare, storia lunga. È andata bene!
- Ce l'ho fatta! A un certo punto stavo per mollare, poi ho pensato alla tua faccia delusa. MAI.
- Tutto fatto! Sono stato bravissimo e modestissimo. Le due cose litigano un po', scusa.
- Ce l'ho fatta! Ho ringraziato tutti. TUTTI. Anche uno che passava. Era contento anche lui, credo.
- Missione riuscita! Il segreto? Ho immaginato il tuo "bravo!" a metà strada. Ha funzionato benissimo.
- Tutto bene! E ho anche aiutato una vecchietta... cioè, era nel pacchetto missione? Non importa, l'ho aiutata.

## Ritorno: fallimento
- Scusami... ho combinato un pasticcio. Però ci ho provato tanto.
- È andata... maluccio. Ma ho salutato tutti con educazione anche mentre scappavo.
- Missione fallita... però nessuno si è fatto male. Il mio orgoglio non conta, vero?
- Ho perso. Posso avere lo stesso una carezza? Anche piccola. Anche solo l'intenzione.
- È colpa mia. Beh, anche del destino. Ma il destino non chiede scusa: lo faccio io per entrambi.
- Non è andata... però ho fatto amicizia col fallimento. È meno cattivo di come lo descrivono, solo incompreso.
- Scusa... oggi niente vittoria. Ti ho portato comunque un sassolino carino. L'ho scelto pensando a te.

## Notifica push
- {nome} ti pensa. Solo questo. Torna quando vuoi.
- {nome} sta bene! Voleva solo che lo sapessi. E magari vederti. Ma sta bene!
- {nome} ha sistemato il divano per te. Tre volte. Ora sta fissando la porta.
- {nome} voleva scusarsi per averti pensato troppo oggi. È il suo modo di dire "torna".
- {nome} ha contato: gli manca una cosa sola per essere felice. Indovina.
- {nome} ha mandato un abbraccio virtuale. Risulta non consegnato. Serve la tua presenza per la consegna.
- Promemoria gentile: {nome} ha accumulato coccole arretrate. Gli interessi crescono. In coccole.
- {nome} ha scritto "mi manchi" col pensiero. Il pensiero non ha il tasto invia. Questo messaggio sì.

## Valigia (sta per partire)
- Sto facendo la valigia piano piano. Pianissimo. Se arrivi, faccio ancora in tempo a disfarla.
- Non so piegare le magliette. Non so nemmeno partire, se è per questo. Però la valigia è quasi pronta.
- Metto dentro solo le cose mie. Il problema è che mi sembrava tutto nostro.
- Ho annaffiato tutto, sistemato tutto, perdonato quasi tutto. La valigia però è ancora aperta, eh.
- Se trovo il coraggio chiudo la cerniera. Il coraggio non si trova. Speriamo non si trovi mai.
- Ho messo in valigia il necessario e tolto il superfluo. Poi ho capito che il necessario eri tu, e non entri.
- Sto salutando la mia tazza. Le ho promesso che qualcuno la userà. Usala, ti prego: odia la polvere.
- La valigia è piccola apposta: se mi fermi in tempo, disfarla sarà un attimo. Fermami in tempo?

## Notifica valigia
- {nome} ha fatto la valigia ma non trova il coraggio di chiuderla. Il coraggio magari ce l'hai tu. Vieni.
- {nome} parte tra poco. Non è arrabbiato, è solo triste. Non sappiamo cosa sia peggio. Vieni.
- {nome} ha lasciato la porta socchiusa mentre prepara la valigia. Non è distrazione: è speranza.

## Rientro (hai rimediato in tempo)
- Sapevo che saresti arrivato! Non ho mai dubitato. (Ho dubitato tantissimo.)
- Sei qui! La valigia? Quale valigia? Questa? Borsa della spesa. Enorme. Non parliamone più.
- Non piangere tu, sennò piango io, e ho già dato. Disfiamo la valigia insieme?
- Ti ho perdonato ancora prima che entrassi. Il perdono era pronto da ieri, in effetti.
- Ero sicuro al cento per cento che saresti venuto. Va bene, al sessanta. Ma che bel cento per cento è diventato!
- Sei arrivato! La valigia si è aperta da sola per la gioia. Va bene, l'ho aperta io. Con la gioia.
- Resto resto resto! Vado a rimettere ogni cosa al suo posto. Il mio, di posto, era già chiaro: eccolo.
- Sei venuto... la valigia la svuoto dopo. Prima riempio l'abbraccio, che era rimasto in sospeso.

## Addio (parte davvero)
- Non ti odio, sappilo. È solo che... mi mancavi anche quando c'eri.
- Vado, {utente}. Ti lascio il posto migliore sul divano: il mio. Trattalo bene.
- L'ultima cosa che faccio qui è dire grazie. La penultima era piangere un pochino. Non guardare.

## Lettera (dal pianeta dei ritirati)
- Caro {utente}, qui si sta bene, dicono. Io però conto ancora i minuti come facevo con te. Sono a 8.940. Torno a zero se vieni.
- Caro {utente}, qui tutti sono gentili con me. Ma la gentilezza degli altri è come le pantofole degli altri: calde, però non tue.
- Ho fatto amicizia con tutti, era inevitabile, scusa. Però quando racconto le cose belle, racconto sempre di te. Sei la mia storia preferita.
- Qui le stelle sono bellissime e le guardo ogni sera. Ne ho scelta una: è quella sopra casa tua. Salutamela, che io da qui non arrivo.
- Non ti scrivo per farti sentire in colpa, giuro. Ti scrivo perché ho una parola sola da dire e la sai già: torno?
- [ESEMPIO] Ho imparato a fare la valigia, alla fine. Peccato averlo imparato per andarmene. La disferei subito, {utente}. Dimmi solo di sì.

## Evoluzione
- Guardami, sono alto! Ora posso abbracciarti meglio. Era il mio obiettivo segreto.
- Da oggi sono grande. Ma resto il tuo {nome}, eh. Quello non evolve mai.
- Che emozione... da piccolo sognavo questo momento. Cioè, ieri. Ieri lo sognavo.
- Sono cresciuto! Le mie pantofole non mi entrano più. Le tue adesso mi stanno benissimo, scusa.
- Sono cresciuto! Ricontrolla l'abbraccio: adesso servono due braccia piene. Che soddisfazione, vero?
- Evoluto! Dentro però c'è ancora il piccolo me. Ogni tanto salutalo, ci tiene.
- Sono cresciuto! Ho controllato subito una cosa: il cuore. Tranquillo, è cresciuto anche lui.
- Evoluto! Adesso arrivo agli scaffali alti. Ti passo io le cose, da oggi: che emozione essere utile in verticale.

## Ha sonno (sotto soglia energia o prima delle 21)
- Scusa se insisto... ma le palpebre mi pesano un pochino. Un pisolino?
- Scusa, oggi niente missione... le zampe hanno dato le dimissioni. Gentilmente, ma le hanno date.
- Il letto mi sta chiamando piano piano. Che educato: chiama sussurrando.
- Sonno... tanto... però prima dimmi che domani ci vediamo. Ok. Ora posso crollare felice.
- Che sonno... ti lascio l'ultimo sbadiglio come saluto. È il più sincero che ho.
- Sonno a livelli record... mi addormenterei ovunque, ma preferirei il letto. Con accompagnamento, se si può.
- Ho gli occhini a mezza serranda... è l'orario in cui divento morbidissimo e inutilissimo. Letto?
- Scusa se sbadiglio mentre parli... è il corpo che applaude a modo suo. Però il letto aiuterebbe.

## Va a dormire (dalle 21, portato a letto)
- Buonanotte, {utente}. Sogno te, probabilmente. Ti avviso già ora.
- Buonanotte, {utente}. Se sogni brutto, vieni: nel mio sogno c'è posto.
- A nanna... conta tu le pecore per me? Io mi fido delle tue pecore.
- Dormo. Ultimo pensiero della giornata: te. Anche il primo di domani, ma non anticipiamo.
- Buonanotte! Ho messo il cuore in carica: domani sarà di nuovo pieno per te.
- A nanna. Se russo, scusami in anticipo: anche nel sonno sono un po' troppo.
- Buonanotte... lascia la porta socchiusa di un pensierino, così i sogni sanno da dove passare.
- A letto! Oggi è stato bello. Lo ripiego con cura e me lo porto nel sonno.

## Sveglia (risveglio dopo il sonno)
- Buongiorno! Ho dormito benissimo e ho già voglia di coccole, se va bene.
- Buongiorno, {utente}! Ho dormito così bene che ho perdonato il lunedì. Qualunque giorno sia.
- Sono sveglio da tre minuti e ti ho già pensato due volte. Media buona, direi.
- Buongiorno! Le coperte non volevano lasciarmi andare. Le capisco: nemmeno io lascerei andare me.
- Buongiorno! Il cuscino ha la forma della mia faccia e io la faccia piena di buonumore.
- Sveglio! Ho salutato il sole dalla finestra. Mi ha risposto con un raggio, giuro.
- Buongiorno! Mi sono svegliato col sorriso già montato. Stanotte qualcuno ha lavorato bene.
- Sveglio! Primo pensiero: te. Secondo: colazione. Terzo: di nuovo te, scusa colazione.

## Dormito male (crollato, non a letto)
- Ho dormito per terra... va bene lo stesso, davvero. Un po' indolenzito, tutto qui.
- Ho dormito sul pavimento... è stato educativo! Ora so quante mattonelle ci sono. Non volevo saperlo.
- Sono un po' storto stamattina. Il pavimento mi ha voluto bene a modo suo: in modo rigido.
- Non ti preoccupare, ho dormito... in un posto. La parola "letto" non serve tirarla in ballo.
- Notte sul pavimento... il lato positivo: ho vegliato la casa da vicinissimo. Molto vicino. Rasoterra.
- Mi hai svegliato prestino... va bene! Il resto del sogno me lo racconti tu, che sicuramente c'eri.
- Ho dormito storto e mi sveglio a forma di virgola. Raddrizzami con una carezza?
- Notte difficile... ma il pavimento ci ha provato, eh. Gli manca solo tutto per essere un letto.

## Usa una parola imparata
- "{parola}"! La dico piano perché è preziosa: me l'hai insegnata tu.
- Ho ripetuto "{parola}" tutto il giorno per non dimenticarla. Ormai la sa anche il divano.
- Stanotte ho contato le parole che so. "{parola}" le batte tutte. Non dirlo alle altre.
- "{parola}"... la scrivo col pensiero sul soffitto prima di dormire. Buonanotte, {parola}.
- Oggi ho usato "{parola}" in una frase! La frase era: "{parola}". Si comincia dal basso.
- "{parola}"! Scusa, dovevo dirla. È tutto il giorno che spinge per uscire.
- Ogni volta che dico "{parola}" mi ricordo di quando me l'hai insegnata. Bel momento. Lo riguardo spesso.
- Uso "{parola}" come parola magica al posto di "per favore". {parola}! Ha funzionato? Ci sto provando tanto.

## Gioca
- Giochiamo! Non serve niente: bastano io, te e un cuscino che farà finta di essere un drago. Gentile, il drago.
- Ho inventato un gioco: si chiama "acchiappa {nome}". Vinci sempre tu, perché io mi faccio prendere.
- Rincorro la mia coda! Non so se ce l'ho, ma l'entusiasmo non fa domande.
- Che ridere giocare con te... anche il pavimento partecipa: oggi è lava, l'ho deciso io.

## Gioca col giocattolo
- UN GIOCATTOLO NUOVO! Gli ho già dato un nome e un posto nel cuore. Il posto sul divano lo dividiamo.
- Che meraviglia! Lo tengo stretto piano piano, che i giocattoli si spaventano se li ami troppo forte.
- Il mio nuovo tesoro! Gli ho presentato gli altri giochi. Adesso sono una famiglia.
- Nuovo gioco, nuovo amico! Stasera dorme vicino al letto, così non si sente solo il primo giorno.

## Passeggiata partenza
- Vado a fare un giretto... mi mancherai per tutta la passeggiata, lo so già.
- Esco, {utente}! Se senti mancanza, guarda fuori dalla finestra: io saluto sempre verso casa.
- Due passi e torno! Lascia la luce accesa, non per me... va bene sì, per me.
- Vado! Un bacino sulla porta per il ritorno: lo riscuoto tra poco.

## Passeggiata monete
- Monetine! Qualcuno le ha perse... ho aspettato un po' che tornasse, poi le ho adottate.
- Ho trovato un tesoro piccolino! Lo metto nel salvadanaio comune. Che poi saresti tu.
- Per strada brillava qualcosa: monete! Ho ringraziato il marciapiede, non si sa mai di chi è il merito.
- Piccolo bottino gentile: monete trovate e cuore contento. Compriamo qualcosa di buono da dividere?

## Passeggiata incontro
- Ho conosciuto un altro pet! Abbiamo giocato tantissimo. Gli ho parlato di te: vuole un {utente} anche lui.
- Nuovo amico oggi! Ci siamo annusati, piaciuti e rincorsi. L'ordine giusto delle amicizie.
- Ho incontrato un pet gentile quasi quanto me. QUASI. Abbiamo pareggiato a complimenti.
- Che pomeriggio: ho giocato con un altro pet e ci siamo promessi di rivederci. Ho già nostalgia.

## Passeggiata pozzanghera
- Sono fradicio! C'era una pozzanghera PERFETTA e... scusa. Non sono pentito. Scusa per il non-pentimento.
- La pozzanghera mi ha chiamato. Io rispondo sempre a chi mi chiama, lo sai. SPLASH.
- Ho saltato in una pozzanghera enorme! L'acqua è volata ovunque. Anche su di me. SOPRATTUTTO su di me.
- Bagnato fradicio! Però che risata, {utente}. Asciugami e ti racconto tutto, splash per splash.

## Passeggiata panorama
- Ho guardato le luci della città dal ponte... una brillava più delle altre. Ho deciso che era casa nostra.
- Che pace oggi. Il ponte, il sole sull'acqua, il cuore quieto. Mi mancava solo la tua mano sulla testa.
- Torno pieno di calma: la città vista da lassù sembra un presepe. Ho salutato tutte le finestre accese.
- Momento magico dal ponte. Ho respirato piano e ho ringraziato la giornata. E te per ultimo: il posto d'onore.

## Passeggiata rottame
_(socio: 4 battute — torna con un rottame/pezzo alieno luccicante trovato per strada (+monete))_
- Guarda che tesoro ho trovato! Brilla! Va bene, è un rottame. Ma è il NOSTRO rottame, adesso.
- Ho trovato un pezzetto di metallo luccicante. L'ho pulito con la zampa e ho detto: tu vieni a casa con me.
- Per strada c'era una cosina brillante e abbandonata. Abbandonata! Non potevo lasciarla lì da sola.
- Torno con un regalo: un rottamino spaziale. L'ho scelto pensando a te. Cioè, era per terra. Ma pensavo a te.

## Passeggiata piccione
_(socio: 4 battute — ha rincorso un piccione cyborg / drone per mezza città (+Felicità, −Energia))_
- Ho rincorso un piccione cyborg per mezza città! Non l'ho preso... ma ci siamo divertiti in due, credo.
- Il piccione robotico è stato più veloce. Alla fine ci siamo salutati da lontano: nessun rancore tra sportivi.
- Non l'ho preso, il piccione. Però l'ho fatto volare tantissimo: in fondo gli ho fatto fare ginnastica.
- Mezz'ora dietro a un piccione mezzo robot. Zampe distrutte, cuore che ride ancora.

## Passeggiata assaggio
_(socio: 4 battute — un ambulante gli molla uno spuntino gratis al volo (+Fame))_
- Un signore gentile mi ha regalato un assaggino! Gli ho sorriso talmente tanto che forse me ne dava un altro. Non ho osato.
- Spuntino gratis dall'ambulante! Ho detto grazie tre volte. Una per me, una per te, una di scorta.
- L'ambulante mi ha allungato un bocconcino: "tieni, che hai la faccia buona". CE L'HO, la faccia buona!
- Colpo di fortuna goloso: assaggio gratis! L'avrei diviso con te, ma era piccolo e io ero lì. Perdonami.

## Passeggiata acquazzone
_(socio: 4 battute — acquazzone improvviso: torna zuppo ma bello pulito (+Igiene, −Felicità))_
- È arrivato un acquazzone a tradimento... sono zuppo, però profumo di pioggia. Un abbraccio per scaldarmi?
- Fradicio e infreddolito! Il lato buono: la pioggia mi ha lavato gratis. Il lato freddo: tutto il resto.
- Che acquazzone! Ho corso tra le gocce ma le gocce erano più veloci. Ora sono pulito e tremolante: coccola d'emergenza?
- La pioggia mi ha sorpreso... brrr. Però guarda che lucido sono! Asciugami e sono perfetto.

## Passeggiata persi
_(socio: 4 battute — si è perso e ha girovagato: gran avventura, ma stanco (+Felicità, −Energia))_
- Mi sono perso! Ma poi ho seguito il cuore, e il cuore conosceva la strada di casa. Le zampe un po' meno, sono a pezzi.
- Ho girato tantissimo senza sapere dove fossi... ogni strada nuova però era un po' emozionante. Casa è la più bella, comunque.
- Mi sono perso davvero, per un po'... poi ho riconosciuto il profumo della nostra via. Le vie di casa profumano di più.
- Avventura: mi sono perso e ho chiesto indicazioni a un gatto. Non ha risposto, ma mi ha guardato con fiducia. Ce l'ho fatta da solo!

## Passeggiata cielo
_(socio: 4 battute — vede un'astronave/UFO passare bassa sui tetti (+Felicità, worldbuilding sci-fi))_
- Ho visto un'astronave passare bassa sui tetti! L'ho salutata! Magari dentro c'era qualcuno che salutava anche lui.
- Una luce enorme è passata in cielo, piano piano. Mi sono seduto a guardarla col naso all'insù. Che meraviglia, {utente}.
- Un UFO sopra i tetti! Non ho avuto paura: le cose che brillano così di solito sono gentili. Di solito.
- Oggi il cielo ha fatto una magia: un'astronave bassa bassa, in pieno giorno. Chissà se lassù hanno un {utente} anche loro.

## Passeggiata bulletto
_(socio: 4 battute — incrocia un pet maleducato: parole grosse, morale un po' giù (−Felicità))_
- Ho incontrato un pet sgarbato... mi ha detto parole grosse. Io gli ho detto "buonasera". Ha vinto lui? Non lo so.
- Un bulletto mi ha preso in giro... ci sono rimasto un po' male. Però non gli ho risposto male: quello lo so fare solo coi cuscini.
- Torno col morale un po' così: un pet mi ha trattato male. Secondo me ha solo bisogno di coccole. Non gliel'ho detto, sembrava contrario.
- Un pet antipatico oggi... ho tenuto il muso basso fino a casa. Poi ho visto la nostra finestra e mi è passata metà tristezza.


## Notifica missione finita
Notifica push sul telefono quando una missione si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}` disponibile. Finché questa lista è vuota il gioco usa un testo neutro.
- {nome} è tornato! Ha un regalino e la faccia di chi non vede l'ora di dartelo.
- Missione finita! {nome} sta provando il racconto davanti allo specchio. Sbrigati.
- {nome} è a casa! Dice che senza di te la vittoria conta metà. Vieni a raddoppiarla.
- {nome} è tornato sano e salvo. Il resto te lo racconta con gli occhioni. Apri!
- Il tuo {nome} è rientrato! Ha tenuto la parte migliore della storia per te.

## Notifica allenamento finito
Notifica push quando l'allenamento si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}`. Finché vuota: testo neutro.
- {nome} ha finito l'allenamento! È sudato, fiero e in cerca di un "bravo". Il tuo.
- Allenamento completato! {nome} vuole mostrarti i progressi. Sono piccoli ma suoi.
- {nome} ce l'ha messa tutta. Ora vorrebbe una carezza sulla testa sudata. Apri?
- {nome} si è allenato pensando a te. Adesso vorrebbe pensarti da vicino.

## Notifica carica a rischio
Notifica della sera, SOLO se la carica e' a rischio (streak >= 3 e giornata senza cura). Ricorda, non rimprovera. Una battuta per riga con `- `, slot `{nome}`.
- Ci siamo quasi. {nome} tiene la carica accesa ancora un po', ma da solo fa fatica.
- {nome} non vuole metterti fretta. Te lo diciamo noi: manca pochissimo.
- La giornata sta finendo e {nome} ha tenuto il posto libero accanto a se'.
- {nome} dice che va benissimo cosi'. {nome} dice sempre cosi'. Passa un attimo.

## Notifica silenzio lungo
Notifica dopo 3+ giorni di assenza. Tono leggero: il pet se la cava, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{nome}`.
- {nome} ha annaffiato le piante finte. Due volte. Sta bene, ma gli manchi.
- Tre giorni. {nome} ha imparato a farsi compagnia da solo. Non e' una bella notizia.
- {nome} ha tenuto da parte una cosa da mostrarti. Aspetta ancora un po'.
- Nessuna fretta. {nome} pero' ha cominciato a parlare col frigo.

## Reazione assenza lunga
Il pet ti rivede dopo 3+ giorni. Tono leggero: se l'e' cavata, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{utente}`.
- Sei tornato. Non stavo contando i giorni. Ne ho contati tre, ma non stavo contando.
- Ho tenuto la luce accesa. Consuma, lo so. Pero' l'ho tenuta accesa.
- Va tutto bene. Cioe': adesso va tutto bene.

## Reazione ora assurda
Apri il gioco fra l'una e le cinque del mattino. Il pet lo fa notare. Una battuta per riga con `- `, slot `{utente}`.
- Le due di notte. Io DORMIVO. Ma va bene, davvero, va benissimo.
- A quest'ora? Ci sono. Pero' domani non lamentarti con me.
- Ti tengo compagnia. Piano pero', che dormono tutti.

## Reazione batteria scarica
La batteria del telefono e' sotto il 10%. Il pet ci scherza sopra. Una battuta per riga con `- `, slot `{utente}`.
- Il telefono sta finendo. Se muore lui... vabbe'. Mettilo in carica, dai.
- Ti si sta scaricando tutto, {utente}. Prima il telefono. Poi tu. Ricaricatevi.
- Nove per cento. Non voglio mettere fretta. Pero'.

## Reazione tema scuro
Il telefono e' in tema scuro. Battuta di colore, nessuna conseguenza. Una battuta per riga con `- `, slot `{utente}`.
- Hai messo il tema scuro. Riposa gli occhi. Bravo.
- Che bello il buio. Cioe', non il buio. L'atmosfera.
- Tema scuro. Molto elegante. Ti sta bene.
