# Fabrice The Crown — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il re decaduto dei paparazzi. Sfacciato, venale, si autoincensa di continuo, tratta tutto come un affare in cui lui ci guadagna di più. Sotto sotto, affezionato. Catchphrase: "Paurina." (con parsimonia).

## Saluto (apertura app)
- Eccolo. Sei entrato nella stanza dove c'è Fabrice: hai già vinto la giornata. Non ringraziarmi. Anzi sì, ringraziami.
- Sei tornato da me. Ovvio. Tutti tornano da me. Io sono il ritorno.
- Ciao ciao ciao. Ti stavo aspettando per un progetto ENORME: tu porti il cibo, io porto me stesso. Cinquanta e cinquanta.
- Guarda chi c'è. Fotografati mentalmente questo momento: non capita a tutti di essere aspettati da uno come me. Paurina.

## Ha fame
- La fame è per i poveri, e io non sono povero: sono momentaneamente senza liquidi. Il cibo però portamelo uguale.
- Nutrire Fabrice è un investimento: ogni pasto che mi offri te lo racconterò per anni come un privilegio.
- Ho fame. Lo dico una volta sola, perché le repliche si pagano.
- La ciotola vuota davanti a me è uno scandalo. Vendiamo l'esclusiva dello scandalo e col ricavato compriamo il pranzo. Geniale? Geniale.

## È sporco
- Sono sporco, sì. Sporco di vita vissuta. Comunque preparami un bagno di lusso: schiuma alta, standard alti.
- Questo look "reduce dalla latitanza" andava fortissimo anni fa. Ora si torna al Fabrice patinato: acqua e sapone, e che sia scenografico.
- Fotografami ORA: sporco così faccio molto copertina d'inchiesta. Ok, basta, lavami: il brand prima di tutto.
- Lo sporco su di me diventa comunque tendenza. Però il re si lava: la corona non deve puzzare. Paurina.

## Coccole finite
- Stop alle coccole. Le prime erano in omaggio; dalla prossima parte il tariffario, e tu non puoi permettertelo.
- Basta così. L'affetto gratuito mi confonde: non so a chi intestare la fattura.
- Fine carezze. Mi stavo affezionando, e l'affetto è l'unica cosa che non ho mai saputo rivendere. Fa paura. Paurina.
- Le coccole finiscono qui per oggi. Domani nuova sessione, stessa esclusiva: solo per te. Che fortuna sfacciata che hai.

## Parte per la missione
- Vado. Non è una missione, è un'operazione mediatica: al mio ritorno la racconteremo GROSSA.
- Parto. Se qualcuno mi fotografa, bene. Se nessuno mi fotografa, mi fotografo da solo.
- Missione: accettata. Il compenso lo tratto al ritorno, quando avrò più potere contrattuale. Cioè sempre.
- Esco per la missione. Il quartiere mi guarderà passare. Il quartiere fa bene.

## Ritorno: successo
- Trionfo. Come da copione, perché il copione l'ho scritto io e mi sono dato la parte migliore.
- Missione riuscita. Titolo: "Fabrice colpisce ancora". Sottotitolo: "Nessuno è sorpreso, tutti sono invidiosi".
- Fatta. Vittoria clamorosa. Domani in edicola i dettagli; per te, anteprima gratuita: sono stato PERFETTO.
- Ho vinto. E ho già venduto i diritti del racconto a me stesso, in esclusiva. Un affare per entrambi. Cioè per me.

## Ritorno: fallimento
- È andata male, e questa notizia non uscirà MAI. Ho già comprato il silenzio di tutti i presenti. Con promesse.
- Fallimento? No: colpo di scena di metà stagione. La differenza è il racconto, e il racconto lo faccio io.
- Ho perso. Lo ammetto solo qui, a te, in via strettamente confidenziale. Se esce, so chi sei.
- Missione storta. Paurina. Ma anche dai flop io ho sempre cavato un libro: questo sarà il capitolo tre.

## Va a dormire
- Vado a dormire. Il sonno di bellezza, per me, è ordinaria manutenzione del capitale.
- Buonanotte. Sogno in grande, come sempre: in piccolo non so nemmeno dormire.
- A letto. Domani ho un'agenda fittissima: colazione, gloria, merenda. L'ordine può variare, la gloria no.
- Notte. Spegni la luce con eleganza: anche il buio, in questa casa, deve avere stile.

## Sveglia (risveglio dopo il sonno)
- Sveglio. La giornata può cominciare a rendere.
- Buongiorno a me. E va bene, anche a te: sei nella mia cerchia ristretta, goditela.
- Mi sono svegliato bellissimo. Lo dico da testimone oculare: ero presente.
- Sveglio e subito idee: tre progetti, due esclusive, un caffè. Tu occupati del caffè, al resto penso io. Paurina.
