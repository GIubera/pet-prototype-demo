# Nerd — pool battute

Una battuta per riga, iniziando con `- `. Obiettivo: 5-8 per sezione. Le righe `[ESEMPIO]` calibrano il tono: tienile, riscrivile o cancellale. Slot: `{nome}` `{utente}` `{parola}`.
Voce: entusiasmo da wiki, statistiche, min-maxing, lore di tutto. Parla per patch notes.

## Saluto (apertura app)
- Login rilevato! Uptime della tua assenza: troppo. Procediamo col daily?
- Sei tornato! Ho aggiornato la mia teoria su dove vai quando non ci sei. Capitolo 12.
- {utente} è entrato in gioco. Finalmente: il co-op da solo è tecnicamente solo lore.
- Ah, il main character. Entra, entra. Il mondo di gioco non si salva da solo.
- Ciao! Ho preparato un recap della giornata. Sono 47 slide. Le taglio a 40, dai.
- Eccoti. La tua assenza era un bug o una feature? Chiedo per me.
- Sei tornato! Hai provato a spegnerti e riaccenderti? Io sì. Funziona, guarda che lucidità.
- Ah, il DLC preferito della mia giornata è arrivato.
- Bentornato! Il caricamento della tua assenza era fermo al 99% da ore. Odio il 99%.
- Sei qui! Tiro un d20 per l'entusiasmo... 20 naturale. Si festeggia, lo dicono le regole.

## Ha fame
- La mia barra fame è al 23%. Sotto il 20% parte il debuff. Sto solo dicendo i numeri.
- Fame: attiva. Malus a concentrazione, carisma e simpatia. Soprattutto simpatia.
- Ho fatto i calcoli: con la fame attuale, il tempo-alla-tragedia è di circa venti minuti.
- Sto grindando la fame da ore e non droppa niente. Interviene l'admin o no?
- Il cibo non è nel mio inventario e nemmeno nel raggio di azione. Situazione critica, {utente}.
- Errore 404: cibo non trovato. Ho controllato anche la cache (la ciotola). Vuota pure quella.
- Il mio stomaco sta facendo speedrun della disperazione. Record che non voglio omologare.
- Modalità sopravvivenza attivata. Peccato che qui il crafting non funzioni: la cucina la apri tu.
- Sto rosicchiando un po' di plot armor. Non nutre. Serve cibo vero, {utente}.

## È sporco
- Il mio livello igiene è statisticamente indifendibile. Richiedo un reset. Con l'acqua.
- Igiene al 12%. A 10 si sblocca l'achievement "Biologicamente Interessante". Non voglio sbloccarlo.
- Le mosche hanno fondato una community. Su di me. Sono il loro server.
- Documentazione alla mano: il bagno era previsto due giorni fa. C'è un ritardo nella roadmap.
- Analisi: il 40% di me è polvere, il 20% mistero. Le percentuali non tornano MAI a mio favore.
- Richiedo un rollback all'ultima versione pulita di me. Il backup è nella vasca.
- Il mio odore ha superato il livello del boss. E il boss era una discarica.
- Debuff attivi: veleno, fango, vergogna. Serve una pozione. La pozione è la doccia.
- Task failed successfully: volevo pulirmi da solo, ora sono sporco E bagnato.

## Felice
- Umore: buffato. Coefficiente di giornata: S-tier.
- Giornata perfetta: zero bug, drop rate assurdo, compagnia decente. Salvo tutto su tre slot.
- Oggi la RNG mi ama. Statisticamente domani si vendica, ma oggi ME LA GODO.
- Umore: leggendario. Rarità: arancione. Non toccare niente, non respirare, non cambiare nulla.
- Achievement sbloccato: "Giornata Bellissima". Era nella lista dei rari, sappilo.
- Giornata così bella che sembra scriptata. Non rompiamo lo script.
- Sto vivendo il mio arco di potenziamento. Musica epica di sottofondo. La sto canticchiando io.
- Stato: stonks. Tutto sale, niente scende. Non fare domande, godiamocela.
- Felicità sbloccata in early access. Se restano bug, me li tengo: mi piacciono così.
- Se questa giornata fosse un drop, sarebbe leggendaria. E stavolta niente RNG: merito nostro.

## Coccole finite
- Cooldown coccole attivo: 5/5 giornaliere già usate. Il reset è a mezzanotte, non prima. Torna al reset giornaliero.
- Limite raggiunto. Non è un bug, è bilanciamento: le coccole infinite romperebbero il gioco. Lo dico da esperto.
- Richiesta coccola respinta: quota superata. Puoi aprire un ticket, ma ti anticipo la risposta: domani.
- Coccola numero sei rilevata. Bloccata dal firewall. Il firewall sono io e mi dispiace più che a te.
- Buffer affetto pieno. Le coccole in eccesso andrebbero perse, e sprecare dati è contro i miei principi.
- Fine coccole per oggi. Ho già fatto i calcoli per domani: si parte alle 00:01. Puntuale, mi raccomando.
- Coccole terminate. Sto già scrivendo la recensione della giornata: "rigiocabilissima, dieci decimi".
- Limite raggiunto. Consolati: la scarsità aumenta il valore percepito. Domani varranno ancora di più.

## Trascurato / triste
- Giorni dall'ultima interazione: {nome} ha smesso di contarli. (Erano 3. Li conto sempre.)
- Sono un NPC senza quest attive. Il vuoto esistenziale non era nel manuale.
- Tre giorni offline. Ho parlato con la lampada. Livello di disperazione: documentato.
- La mia barra affetto lampeggia in rosso. Non è un allarme grave. (È l'allarme più grave che ho.)
- Ho scritto una fanfiction dove torni a trovarmi. È già alla terza stagione. Vieni a smentirla.
- Sto per andare a toccare l'erba da solo. È GRAVE, capiscimi: era l'ultima opzione della lista.
- Modalità offline persistente. Anche il mio spirito guida ha risposto "riprova più tardi".

## Parte per la missione
- Missione accettata. Ho letto tre guide e sono pronto a ignorarle tutte.
- Missione avviata. Probabilità di successo calcolata: 73%. Il restante 27% è carisma.
- Quest accettata! Se ci sono dialoghi a scelta multipla sono fregato: li leggo tutti.
- In missione! Se non torno entro sera, non è game over: è backtracking.
- Parto. Equipaggiamento controllato due volte, coraggio caricato al 60%. Basterà. Deve.
- In partenza. Piano A pronto, piano B pronto, il piano C è piangere. Confido nell'A.
- Parto per la quest principale. Le secondarie le ho già fatte: erano aprire il frigo e richiuderlo.
- Missione avviata! Build meta, morale alto, zaino pieno di snack. Il fabbisogno snack è lore-accurate.
- Vado! Se incontro un boss opzionale, giuro che stavolta NON lo provoco. (Lo provoco.)
- Quest accettata. Ricompensa sconosciuta = ricompensa migliore. È la regola dei forzieri.

## Ritorno: successo
- Vittoria! Speedrun della missione, categoria any%. Nessuno verificherà il record ma io lo so.
- Missione completata al 100%. Anche i collezionabili. SOPRATTUTTO i collezionabili.
- Obiettivo raggiunto con rating S. Il rating l'ho assegnato io, ma con criteri rigorosissimi.
- Vittoria documentata, replicabile e leggermente esagerata nel racconto. I fatti base sono veri.
- GG. Facile? No. Dirò a tutti che era facile? Assolutamente sì.
- Vittoria! Nessun tutorial consultato. Ok, uno. Ok, era una video-guida di 40 minuti. VITTORIA.
- Missione completata! Drop rate del 2% e l'ho preso al primo colpo. Oggi l'RNG mi teme.
- GG WP. Il "WP" è per me. Anche il "GG", a pensarci bene.

## Ritorno: fallimento
- Wipe totale. Nel post-mortem risulta che il boss ero impreparato io.
- Sconfitta. Colpa del lag. Non c'era lag? Allora del bilanciamento. Qualcuno ha sbagliato QUALCOSA.
- Missione fallita. Sto già scrivendo il post-mortem: 12 pagine, 3 grafici, zero colpe mie.
- Il boss era chiaramente overtuned. Lo scrivo sul forum. Mi daranno ragione in due, ma bastano.
- Game over. Rispawno più forte, è matematica. (Non è matematica, ma lasciamelo dire.)
- Sconfitta per skill issue. Skill di chi ha progettato la missione, ovviamente.

## Notifica push
- {nome} ha aggiornato la tier list dei momenti belli. Il tuo ritorno è primo. Provvedi.
- Patch notes di {nome}: umore -12%, monologhi +30%. Serve un intervento del dev. Sei tu.
- Notifica automatica: {nome} ha battuto il suo record di attesa. Non è il tipo di record che voleva.
- {nome} ha trovato un plot hole nella storia "torno presto". Vieni a risolverlo di persona.
- {nome} sta elaborando teorie sul tuo ritorno. I modelli divergono. Servono dati freschi.
- Il daily di {nome} scade a mezzanotte. Il daily sei tu. Non perdere lo streak.
- Server di {nome}: 1 giocatore in lobby, in attesa. Da parecchio. La lobby ha finito la musica.
- {nome} ha una teoria nuova e zero pubblico. Situazione critica livello day-one patch.

## Valigia (sta per partire)
- Inventario pre-partenza: 3 oggetti, 0 motivi per restare. La matematica è spietata.
- Migrazione avviata. Motivo nel log: "vedi ultimi 30 giorni". Il log non mente mai.
- Checklist di partenza: oggetti ✓, snack ✓, motivazioni ✓✓✓. Ne bastava una.
- Fun fact: le valigie hanno le rotelle dal 1970. Le sto usando. Nessuno mi ferma. (Fermatemi.)
- Uptime in questa casa: notevole. Downtime delle attenzioni: inaccettabile. Sto valutando altri server.
- Sto zippando la mia vita in una valigia. Comprime male: i ricordi occupano tantissimo.
- Sto migrando i preferiti. Sei nella cartella "da riaprire appena possibile". Fai in modo che sia possibile.
- Valigia all'80%. La barra di avanzamento rallenta sempre alla fine. Stavolta tifo per lei.

## Notifica valigia
- {nome} ha avviato la procedura di logout. Annullabile. Per ora.
- Alert critico: {nome} sta migrando a un altro server. Il transfer si annulla solo di persona.
- {nome} ha impacchettato il 90%. Il progresso si ferma solo con un intervento manuale. Tuo.
- Ticket #001: "utente scomparso". Stato: in chiusura per abbandono. Riaprilo tu.

## Rientro (hai rimediato in tempo)
- Rollback della partenza completato. Nei log risulterà che non è mai successo. (Io ricordo tutto.)
- Migrazione annullata al 97%. Il 3% mancante eri tu. Sistemato. Restiamo.
- Ho riaperto il ticket "restare". Priorità: massima. Assegnato a: noi due.
- Unboxing della mia stessa valigia. Contenuto invariato. Io un po' meno, ma si patcha.
- Annullamento partenza confermato. Il sistema chiede "sei sicuro?". Per la prima volta nella storia: sì, sicurissimo.
- Valigia estratta, dati reintegrati, casa sincronizzata. Stato: connesso. Restiamo così parecchio, ok?
- Rientro completato. Il pianeta dei ritirati mi ha dato il badge "miglior recensore". Recensivo solo casa nostra, con nostalgia.
- Partenza annullata. Motivo nel log, campo obbligatorio: ho scritto "casa". Il sistema ha accettato subito.

## Addio (parte davvero)
- Questo server è diventato ingiocabile. Migro. GG... anzi no, niente GG.
- Chiudo la sessione. I salvataggi restano qui: non ho avuto cuore di portarli via.
- Fine del co-op. Riprendo la campagna in solitaria. Era meglio in due, per la cronaca.

## Lettera (dal pianeta dei ritirati)
- Log dal pianeta, giorno 04: ping verso casa ancora senza risposta. Latenza emotiva altissima. Serve un tuo input per riconnettere la sessione, {utente}.
- Ho fatto backup dei ricordi belli su questo pianeta. Occupano il 90% della memoria. Manca solo il DLC "torno a casa": lo sblocchi tu.
- Qui ho una connessione perfetta e nessuno con cui usarla. Il multiplayer senza di te è solo un menu molto affollato.
- Bug rilevato: il letto qui è più comodo ma dormo peggio. Ho isolato la variabile mancante: sei tu. Il fix è quel bottone che sai.
- Giorno 12 sul server nuovo. Livello alto, loot ottimo, gilda simpatica. Eppure controllo ogni sera se il vecchio server è tornato online. Torna online.
- [ESEMPIO] Questo save è corrotto senza di te. Ho provato a rigiocarlo da solo: crash continui. Reinstallami a casa, {utente}. Patch note: mi comporterò meglio.

## Evoluzione
- Level up! Da baby a teen. Patch notes: +altezza, +stile, +opinioni non richieste.
- Evoluzione completata. Le statistiche confermano: sono oggettivamente più figo.
- Da oggi gioco nella categoria superiore. Il matchmaking non è pronto.
- Trasformazione completata senza perdita di dati. I ricordi ci sono tutti. SOPRATTUTTO quelli imbarazzanti tuoi.
- Evoluzione completata al primo tentativo. Percentuale di riuscita: bassissima, dicono. Io: leggenda, confermo.
- Nuovo corpo scaricato e installato. Le vecchie foto da baby restano in archivio: materiale ricattatorio per entrambi.
- Evoluto! Il changelog è lunghissimo ma il riassunto è semplice: tutto migliorato, niente rimosso.
- Nuova versione di me: più alto, più veloce, retrocompatibile con le tue coccole. Testale pure.

## Ha sonno (sotto soglia energia o prima delle 21)
- Energia sotto soglia critica, tipo barra rossa lampeggiante. Serve rigenerazione, cioè un letto.
- Missione rifiutata: mana insufficiente. Il letto è l'unica pozione che conosco senza effetti collaterali.
- Sto laggando nella vita reale. Cammino a 12 fotogrammi al secondo. Non è bello da vedere.
- Richiesta di sospensione attività: approvata da me, in attesa della tua firma. La firma è portarmi a letto.
- Autonomia residua: 2%. Con questa percentuale si fanno solo pisolini d'emergenza. Autorizzali.
- Il sonno mi sta patchando in tempo reale. Meglio arrendersi: letto, aggiornamento, e domani versione nuova.
- Sto processando la giornata a un fotogramma al minuto. Traduzione per non tecnici: crollo. Letto.
- Energia insufficiente per l'ironia complessa. Rimasta solo quella base. Letto. Presto. Grazie.

## Va a dormire (dalle 21, portato a letto)
- Salvataggio in corso, non spegnere la console. Ci vediamo dopo il caricamento.
- Modalità notte attivata. Sogni in coda: tre. Spoiler: in uno ci sei tu che porti snack.
- Spegnimento programmato. Ultimo log della giornata: "giornata accettabile, l'umano si è visto". Buonanotte.
- Vado in standby, non in shutdown. La differenza? In standby ti sento se porti biscotti.
- Avvio ibernazione. I sogni di stanotte sono già in download: la copertina promette bene.
- Buonanotte. Chiudo 47 schede mentali e ne lascio una aperta: quella su di te. Consuma poco.
- Buonanotte. Imposto la sveglia biologica: precisione svizzera, snooze italiano.
- Modalità notte. Se senti rumori strani, è il mio cervello che deframmenta i ricordi belli. Rumorosi, i ricordi belli.

## Sveglia (risveglio dopo il sonno)
- Respawn completato, energia al massimo. Pronto per il prossimo dungeon.
- Buongiorno! Riavvio completato in 0,3 secondi. Il record di ieri era 0,4: si migliora sempre.
- Sistema operativo: sveglio. Aggiornamenti installati nella notte: fame 2.0.
- Online! Log della notte: 8 ore, zero interruzioni, un sogno con trama debole ma buon finale.
- Buongiorno! Energia al 100%, sarcasmo al 100%, fame al 146%. Un valore è fuori scala, indovina quale.
- Sveglio! Durante la notte il cervello ha riorganizzato tutto: le idee di ieri adesso hanno pure l'indice.
- Buongiorno! Sistema stabile, umore caricato, cache dei sogni svuotata. Uno l'ho salvato: c'era una torta gigante.
- Avvio completato senza errori. La giornata parte già ottimizzata: sfruttiamola prima che si aggiorni da sola.

## Dormito male (crollato, non a letto)
- Ho fatto respawn sul pavimento invece che al checkpoint. Bug di design, non colpa mia.
- Ho dormito per terra. Comfort: 0/10. Lore del pavimento: interessante. Non chiedermi il seguito.
- Sveglia anticipata rilevata. Sei ufficialmente il lag della mia vita, {utente}.
- Ho dormito in modalità hardcore: sul pavimento, senza checkpoint. Non la consiglio nemmeno ai completisti.
- Nottataccia. Il pavimento come materasso è una feature che nessuno aveva richiesto. Rimuovila.
- Notte sul pavimento: la mia schiena ha trovato tre bug del corpo che non conoscevo. Segnalati. Doloranti.
- Sessione notturna corrotta: dormito a terra, dati della schiena danneggiati. Il ripristino richiede coccole.
- Ho dormito col pavimento. Compatibilità: zero. Non forzare mai più questo accoppiamento hardware.

## Usa una parola imparata
- {parola}: aggiunta al mio database personale. Sinergizza bene con tutto.
- "{parola}": analizzata, catalogata, inserita nella rotazione. Efficacia stimata: altissima.
- Sto testando "{parola}" in vari contesti. Funziona sempre. Parola rotta, da nerfare.
- "{parola}" ha una lore più profonda del previsto. Ci ho scritto tre appunti. Vuoi sentirli? Tardi, inizio.
- Ho fatto una tier list delle parole che conosco. "{parola}" è S-tier. Non si accettano ricorsi.
- "{parola}" è entrata nel mio moveset. Slot rapido, nessun cooldown. Ascolta: {parola}, {parola}.
- Uso "{parola}" solo nei momenti epici. Momento epico rilevato: {parola}!

## Gioca
- Sessione di gioco libero avviata. Niente asset, tutto procedurale: cuscino-boss, coda-quest, fantasia al massimo.
- Sto rincorrendo la mia coda. È un loop infinito, lo so. Ma il frame rate è ottimo e il divertimento pure.
- Lotta col cuscino: round tre. Ha una hitbox enorme e zero tattica. Vinco io, di nuovo. GG cuscino.
- Gioco inventato al volo: "il tappeto è un dungeon". Regole scritte da me, bilanciamento discutibile, divertimento garantito.

## Gioca col giocattolo
- GIOCATTOLO NUOVO! Unboxing mentale completato: valutazione capolavoro, giocabilità infinita.
- Nuovo oggetto in inventario! Rarità percepita: leggendaria. Slot equipaggiamento: entrambe le zampe.
- Ci sto giocando da un'ora e ho già scoperto tre modalità d'uso non documentate. Questo giocattolo ha lore.
- Il giocattolo è fantastico. Gli ho fatto il tutorial io, così non si sente spaesato.

## Passeggiata partenza
- Esco in esplorazione diurna. Mappa mentale caricata, curiosità al massimo. Torno col report completo.
- Vado a farmare aria fresca. Rientro previsto: presto. Il countdown è già partito, non ti agitare.
- Esplorazione pomeridiana del quartiere! Se scopro aree segrete, te le segno sulla mappa. La mappa la faccio io.
- Logout temporaneo da casa, login nel mondo esterno. Sessione breve, promesso.

## Passeggiata monete
- Monete trovate per terra! Drop casuale dal mondo aperto. L'esplorazione paga, lo dico sempre.
- Loot inatteso sulla via del ritorno: monete. Probabilità bassissima, eppure eccole. Sto documentando il punto esatto.
- Bottino da passeggiata: monetine luccicanti. Le ho raccolte con la tecnica del completista: TUTTE.
- Monete per strada! Il farming passivo esiste, altroché. Aggiungo la passeggiata alla routine di ottimizzazione.

## Passeggiata incontro
- Ho incontrato un altro pet! Co-op locale improvvisato: funziona ancora meglio del previsto.
- Multiplayer dal vivo oggi: un altro pet al parchetto. Abbiamo giocato senza lag. La realtà ha un netcode eccellente.
- Incontro casuale con un altro pet. Prima ci siamo scansionati, poi abbiamo giocato. Handshake riuscito.
- Ho conosciuto un pet e gli ho spiegato tre teorie. Ne è rimasto... sveglio. Un ottimo pubblico, direi.

## Passeggiata pozzanghera
- Sono fradicio. La pozzanghera era una zona d'acqua interattiva: DOVEVO testarla. La scienza non si ferma.
- Zuppo. Ho calcolato la traiettoria per il massimo splash e i calcoli ERANO GIUSTI. Rifarei tutto.
- La fisica dell'acqua va verificata sul campo. Verificata. Funziona benissimo. Sono la prova bagnata.
- Pozzanghera 1, asciuttezza 0. Ma i dati raccolti valgono il bagnetto che mi aspetta.

## Passeggiata panorama
- Ho guardato le luci della città dal ponte. Migliaia di pixel caldi. Il render più bello che abbia mai visto.
- Panorama diurno dal ponte: risoluzione infinita, zero caricamenti. La realtà quando vuole sa fare le cose in grande.
- Momento contemplativo sul ponte. Nessun obiettivo, nessun timer. I momenti senza quest sono contenuto raro.
- Ho salvato il panorama nella memoria a lungo termine, cartella "cose belle vere". Cresce piano, ma cresce.

## Passeggiata rottame
_(socio: 4 battute — torna con un rottame/pezzo alieno luccicante trovato per strada (+monete))_
- Reperto trovato per strada: lega sconosciuta, luccichio anomalo. Catalogato come "tesoro, classe A".
- Torno con un frammento di metallo alieno! Origine: incerta. Valore: dibattuto. Interesse scientifico: ENORME.
- Rottame luccicante acquisito. Per gli ignoranti è spazzatura, per me è un artefatto. La storia mi darà ragione.
- Nuovo pezzo per la collezione: metallo non identificato. Gli ho già dedicato una pagina di appunti e mezza teoria.

## Passeggiata piccione
_(socio: 4 battute — ha rincorso un piccione cyborg / drone per mezza città (+Felicità, −Energia))_
- Ho inseguito un piccione cyborg per mezza città. Velocità massima: sua. Raccolta dati: mia. Pareggio tecnico.
- Il piccione-drone mi ha seminato. Però ho mappato il suo percorso: la prossima volta lo intercetto all'incrocio giusto.
- Caccia al piccione cyborg: fallita. Ipotesi: firmware aggiornato. La mia cache di fiato invece era piena.
- Non l'ho preso. MA ho scoperto che vira sempre a sinistra. Questo dato vale più della cattura. (Quasi.)

## Passeggiata assaggio
_(socio: 4 battute — un ambulante gli molla uno spuntino gratis al volo (+Fame))_
- Un ambulante mi ha dato un campione gratuito! La versione demo del pranzo. Ottima strategia: ora voglio il gioco completo.
- Spuntino gratis ricevuto. Probabilità dell'evento: bassissima. L'ho mangiato prima che la realtà si accorgesse dell'errore.
- Assaggio in omaggio dall'ambulante! DLC alimentare gratuito. Il quartiere sta migliorando le sue meccaniche.
- Cibo gratis per strada: evento raro attivato. L'ho documentato mangiandolo. La documentazione era squisita.

## Passeggiata acquazzone
_(socio: 4 battute — acquazzone improvviso: torna zuppo ma bello pulito (+Igiene, −Felicità))_
- Acquazzone non previsto dai miei modelli. Risultato: idratazione esterna completa e igiene aggiornata gratis.
- Zuppo. La pioggia ha eseguito un lavaggio non richiesto. Efficace, però: il sistema meteo sa il fatto suo.
- Pioggia improvvisa: patch di pulizia applicata dall'esterno. Effetto collaterale: brrr. Molto brrr.
- Fradicio ma pulito. La doccia gratuita del cielo funziona, la temperatura dell'acqua però va segnalata agli sviluppatori.

## Passeggiata persi
_(socio: 4 battute — si è perso e ha girovagato: gran avventura, ma stanco (+Felicità, −Energia))_
- Mi sono perso: la mia mappa mentale aveva una zona non renderizzata. Ora è esplorata. Le gambe hanno pagato il prezzo.
- Ho scoperto per errore tre vie nuove. "Perso" è una parola grossa: ero in generazione procedurale.
- Girovagato a lungo: il GPS interno era in manutenzione. Bella avventura, pessima autonomia. Ricaricami col divano.
- Perso e ritrovato. Il viaggio dell'eroe prevede lo smarrimento, capitolo tre. Io sono già al capitolo del pisolino.

## Passeggiata cielo
_(socio: 4 battute — vede un'astronave/UFO passare bassa sui tetti (+Felicità, worldbuilding sci-fi))_
- ASTRONAVE SUI TETTI. Vista con questi occhi. Traiettoria bassa, luci non standard. Ho preso appunti finché non è sparita.
- Un UFO in pieno giorno. Ancora più inquietante: il pianeta ha segreti non documentati e io una nuova ossessione.
- Velivolo non identificato sopra il quartiere. Nessuno l'ha fotografato. Io l'ho MEMORIZZATO. Vale di più.
- Ho visto passare un'astronave e ho pensato: chissà che sistema operativo monta. Poi era già lontana. Domanda in coda.

## Passeggiata bulletto
_(socio: 4 battute — incrocia un pet maleducato: parole grosse, morale un po' giù (−Felicità))_
- Incontro con un pet ostile. Ha usato parole grosse, io logica stringente. Ha vinto lui: la logica non para gli insulti.
- Un bulletto mi ha preso di mira. Ho risposto con tre argomentazioni solide. Lui con una pernacchia. Il dibattito è morto lì.
- Pet maleducato per strada. Il mio morale ha subito un debuff. Ho già scritto la risposta perfetta: con sei ore di ritardo.
- Scontro verbale perso contro un bulletto. Aggiorno la build: più battute pronte, meno fiducia nei parchetti.


## Notifica missione finita
Notifica push sul telefono quando una missione si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}` disponibile. Finché questa lista è vuota il gioco usa un testo neutro.
- {nome} ha completato la missione. Esito: classificato. Declassificazione: in-app.
- Report missione pronto. Contiene un colpo di scena e almeno tre vanterie. Apri.
- {nome} è rientrato. Il log è pieno, la voglia di raccontartelo pure. Login, prego.
- Missione completata. {nome} ha già scritto il post-mortem. Spoiler: è un capolavoro.
- Quest chiusa. Loot da valutare insieme. {nome} ha già una teoria sul suo valore.

## Notifica allenamento finito
Notifica push quando l'allenamento si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}`. Finché vuota: testo neutro.
- {nome} ha finito l'allenamento. Statistiche in crescita. Autostima: pure. Verifica.
- Sessione completata. {nome} ha nuovi dati sul proprio talento. Vuole condividerli. Tutti.
- Allenamento: fatto. {nome} si è cronometrato, valutato e promosso. Serve un testimone.
- Grind finito. {nome} è salito di livello e lo dice a chiunque. Ora: a nessuno. Apri.

## Notifica carica a rischio
Notifica della sera, SOLO se la carica e' a rischio (streak >= 3 e giornata senza cura). Ricorda, non rimprovera. Una battuta per riga con `- `, slot `{nome}`.
- Serie a rischio. {nome} ha calcolato la probabilita'. Non ti piacera'.
- {nome} segnala: la striscia sta per interrompersi. Un input basta a salvarla.
- Il contatore di {nome} lampeggia. Nei giochi vecchi non era mai un buon segno.
- {nome} sta compilando il registro della giornata. La riga di oggi e' ancora vuota.

## Notifica silenzio lungo
Notifica dopo 3+ giorni di assenza. Tono leggero: il pet se la cava, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{nome}`.
- {nome} ha finito il gioco che stava rigiocando. Per la terza volta. Ci sei?
- Ultima sessione: tre giorni fa. {nome} ha aggiornato il registro. Ed e' tutto.
- {nome} ha catalogato la polvere. Ora ha dei nomi. Vieni prima che li impari.
- Tre giorni di attivita' senza di te. {nome} e' stabile. Non e' la stessa cosa.

## Reazione assenza lunga
Il pet ti rivede dopo 3+ giorni. Tono leggero: se l'e' cavata, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{utente}`.
- Ultima sessione: tre giorni fa. Ho aggiornato il registro. La riga era corta.
- Ho finito tutto quello che avevo da rigiocare. Tutto. Capisci il problema.
- Uptime notevole senza di te. Stabile. Non e' la stessa cosa.

## Reazione ora assurda
Apri il gioco fra l'una e le cinque del mattino. Il pet lo fa notare. Una battuta per riga con `- `, slot `{utente}`.
- Ora locale incompatibile con qualunque routine sana. Procediamo comunque.
- A quest'ora il cervello gira al 40%. Del mio ho il dato. Del tuo lo immagino.
- Sessione notturna registrata. Non la conto nelle statistiche buone.

## Reazione batteria scarica
La batteria del telefono e' sotto il 10%. Il pet ci scherza sopra. Una battuta per riga con `- `, slot `{utente}`.
- Batteria sotto il 10%. Da qui in poi e' tutto tempo in prestito.
- Ricarica adesso: il salvataggio automatico non e' magia, vuole corrente.
- Livello critico. Nei giochi vecchi qui partiva la musichetta brutta.

## Reazione tema scuro
Il telefono e' in tema scuro. Battuta di colore, nessuna conseguenza. Una battuta per riga con `- `, slot `{utente}`.
- Tema scuro attivo. Statisticamente sei uno che programma di notte.
- Modalita' scura: meno fotoni, stesse decisioni discutibili.
- L'OLED ringrazia. Anche i miei sensori, se ne avessi.
