window.PETQ = window.PETQ || {};

(function () {

  // i18n bilingue "gettext-style" (contratto localStorage 'petq_lingua', v. app/js/i18n.js):
  // la stringa italiana nel codice E' la chiave del dizionario. traduci() e' un no-op sicuro se
  // i18n.js non fosse ancora caricato (fallback identita'), cosi' il gioco resta bit-identico
  // in italiano anche senza il modulo. NOME NON "t": il file usa gia' variabili locali "t" per
  // altri scopi in piu' funzioni (elemento toast, tab, titolo scheda, indice di loop...) — un
  // alias corto le avrebbe silenziosamente shadowate (bug difficile da notare a schermo).
  var traduci = (PETQ.i18n && PETQ.i18n.t) || function (s) { return s; };

  var ROOM_W = (PETQ.rooms && PETQ.rooms._W) || 112;
  var ROOM_H = (PETQ.rooms && PETQ.rooms._H) || 64;

  // Altezza CORRENTE della stanza (GDD "Slot arredo, tetto passivo e Ingrandimento casa"): 64
  // normale, 80 con Ingrandimento casa comprato. La LARGHEZZA (ROOM_W) non cambia mai, quindi le
  // X restano intatte; solo l'altezza e' dinamica. Usare questo helper (NON la costante ROOM_H
  // catturata a 64) in ogni punto che tocca il CANVAS DELLA STANZA, le HOTZONE e la POSIZIONE DEL
  // PET, cosi' il pet sta sul pavimento (piu' in basso quando ingrandito) e le hotzone restano
  // allineate al disegno. I canvas NON-stanza (sprite pet, mappa, cartoline) restano su ROOM_H.
  function altezzaStanzaCorrente() {
    return (PETQ.rooms && PETQ.rooms.altezzaStanza) ? PETQ.rooms.altezzaStanza(currentState) : ROOM_H;
  }
  var PET_SIZE = 16;
  var PET_SCALE = 2;
  var PET_PX = PET_SIZE * PET_SCALE;
  var IDLE_MS = 500;
  var BALLOON_MS = 6500;
  var rientroDettoMs = 0; // quando il pet ha raccontato l'ultimo rientro (v. quarta parete, A3)

  // hotzone vasca (coordinate logiche stanza): la vasca è nella metà sinistra del bagno
  var HOTZONE_VASCA = { x: 0, y: 20, w: 50, h: 44 };
  // posizione del pet durante il lavaggio (dentro la vasca)
  var WASH_POS = { x: 8, y: 14 };

  // hotzone letto (coordinate logiche stanza, camera — GDD "Casa": il letto e' stato spostato
  // dal salone alla camera dedicata): rettangolo esposto da PETQ.rooms._letto.camera[tema],
  // riletto qui con fallback nel caso il modulo grafica non sia ancora caricato (stesso
  // pattern difensivo di ROOM_W/ROOM_H sopra). tema: 'lab'|'ship' (v. temaRazza).
  function hotzoneLetto(tema) {
    var perTema = PETQ.rooms && PETQ.rooms._letto && PETQ.rooms._letto.camera;
    if (perTema && perTema[tema]) return perTema[tema];
    return { x: 14, y: 20, w: 40, h: 30 };
  }

  // hotzone frigo (coordinate logiche stanza, cucina — GDD "Economia" -> "Spesa e dispensa"):
  // rettangolo esposto da PETQ.rooms._frigoZona.cucina[tema], stesso pattern hotzoneLetto sopra.
  function hotzoneFrigo(tema) {
    var perTema = PETQ.rooms && PETQ.rooms._frigoZona && PETQ.rooms._frigoZona.cucina;
    if (perTema && perTema[tema]) return perTema[tema];
    return { x: 6, y: 10, w: 16, h: 34 };
  }

  // hotzone scrivania (coordinate logiche stanza, camera — PROTOTIPO-2.md punto 6 "Diario in
  // camera"): rettangolo esposto da PETQ.rooms._scrivania.camera, stessa per lab/ship (solo lo
  // stile del mobile cambia). Niente parametro tema: la scrivania non si sposta tra i due temi.
  function hotzoneScrivania() {
    var z = PETQ.rooms && PETQ.rooms._scrivania && PETQ.rooms._scrivania.camera;
    return z || { x: 56, y: 40, w: 20, h: 24 };
  }
  // posizione del pet mentre dorme A LETTO (FIX: prima era un punto fisso {22,30} che non
  // teneva conto delle dimensioni reali del letto per tema e sforava sotto il bordo del
  // letto ship - v. rooms.js LETTO_LAB_CAMERA/LETTO_SHIP_CAMERA, che hanno x/y/w/h diversi).
  // Ora centriamo lo sprite (PET_PX x PET_PX) nel rettangolo VERO del letto, con un piccolo
  // offset verso il basso perche' il "materasso/giaciglio" disegnato da rooms.js occupa la
  // meta' inferiore della capsula (la cupola/vetro sta sopra): v. labCameraLetto/
  // shipCameraLetto, il rettangolo del cuscino+coperta parte a r.y+9/+12. Clampato dentro
  // il rettangolo cosi' lo sprite non sporge mai fuori dai bordi del letto.
  function sleepBedPos(tema) {
    var r = hotzoneLetto(tema);
    var x = Math.round(r.x + (r.w - PET_PX) / 2);
    var y = Math.round(r.y + (r.h - PET_PX) / 2) + 4; // +4: verso il giaciglio, non la cupola
    // clamp dentro il rettangolo letto; se il letto e' piu' piccolo del pet su un asse
    // (min > max dopo il clamp), vince il bordo superiore/sinistro (r.x/r.y) cosi' lo sprite
    // resta ancorato al letto invece di sforare, semplicemente "riempiendolo" per intero
    x = Math.min(Math.max(x, r.x), Math.max(r.x, r.x + r.w - PET_PX));
    y = Math.min(Math.max(y, r.y), Math.max(r.y, r.y + r.h - PET_PX));
    return { x: x, y: y };
  }
  // posizione del pet mentre dorme CROLLATO (sul pavimento della camera). Spostato a destra
  // del centro (fix leggibilita' posa sdraiata): il centro stanza cade dentro il rettangolo
  // del letto (v. LETTO_LAB_CAMERA/LETTO_SHIP_CAMERA in rooms.js, entrambi x:14-~54/56), quindi
  // il crollo si sovrapponeva visivamente al letto invece di leggersi come "sul pavimento,
  // NON nel letto" (la punizione visiva voluta dal GDD "Energia e sonno"). Nello spazio libero
  // a destra del letto (~x:60-108) il crollo resta chiaramente separato dal mobile.
  function sleepFloorPos() {
    return { x: ROOM_W - PET_PX - 8, y: altezzaStanzaCorrente() - PET_PX - 4 };
  }

  // mappa allenamento: prop -> stat (da GDD "Direzione interazione")
  var PROPS_ALLENAMENTO = [
    { id: 'pesi', stat: 'forza', label: 'Forza' },
    { id: 'libro', stat: 'intelligenza', label: 'Intelligenza' },
    { id: 'corsa', stat: 'velocita', label: 'Velocità' },
    { id: 'specchio', stat: 'carisma', label: 'Carisma' }
  ];

  var STAT_LABEL = { forza: 'Forza', intelligenza: 'Intelligenza', velocita: 'Velocità', carisma: 'Carisma' };

  // Etichette degli effetti dei CIBI (Tier 2, v. content.js parseCibi): le 4 stat RPG piu' le
  // stat di benessere che un cibo puo' toccare. Chiave = nome canonico dell'effetto (dato),
  // valore = etichetta a schermo (tradotta da traduci, voci gia' presenti in i18n.js).
  var EFFETTO_CIBO_LABEL = {
    forza: 'Forza', intelligenza: 'Intelligenza', velocita: 'Velocità', carisma: 'Carisma',
    fame: 'Fame', igiene: 'Igiene', felicita: 'Felicità', energia: 'Energia', ferite: 'Ferite'
  };

  // ===== COLORI (varianti cromatiche del pet, batch cosmetici) =====
  // TABELLA DATI UNICA (nome per traduci(), indice = pet.parts.colore — NON pet.colore, v.
  // sprites.js resolvePet -> getPalette(razza, sottorazza, parts.colore) — come si ottiene,
  // prezzo): selettore in scheda e negozio la leggono ENTRAMBI da qui, cosi' la regola di
  // disponibilita' (coloreDisponibile sotto) sta in un posto solo. Indici 0..2 = i tre colori
  // base gia' esistenti (il pet ne riceve uno alla nascita, v. pet.js generate, e passa agli
  // altri due gratis); 3 e 6 (Fantasma/Lava) si comprano a monete nel negozio; 4/5/7 (Oro/Notte
  // Neon/Ghiaccio) si sbloccano SOLO col Supporter Pack (per ora acceso solo da debug, v.
  // montaDebugPanel — l'acquisto vero con soldi non esiste ancora).
  var PREZZO_COLORE_NEGOZIO = 600;
  var COLORI_PET = [
    { indice: 0, nome: 'Colore 1', tipo: 'base' },
    { indice: 1, nome: 'Colore 2', tipo: 'base' },
    { indice: 2, nome: 'Colore 3', tipo: 'base' },
    { indice: 3, nome: 'Fantasma', tipo: 'negozio', prezzo: PREZZO_COLORE_NEGOZIO },
    { indice: 4, nome: 'Oro', tipo: 'supporter' },
    { indice: 5, nome: 'Notte Neon', tipo: 'supporter' },
    { indice: 6, nome: 'Lava', tipo: 'negozio', prezzo: PREZZO_COLORE_NEGOZIO },
    { indice: 7, nome: 'Ghiaccio', tipo: 'supporter' },
    // Base NUOVI (GDD "tiro di nascita" 24 ago 2026): indici 8-10 IN CODA alle palette (mai in
    // mezzo, gli speciali 3-7 sono nei salvataggi per indice). Stesse regole dei base storici:
    // non si scelgono, resta quello uscito alla nascita.
    { indice: 8, nome: 'Colore 4', tipo: 'base' },
    { indice: 9, nome: 'Colore 5', tipo: 'base' },
    { indice: 10, nome: 'Colore 6', tipo: 'base' }
  ];
  // Etichetta breve ("come si ottiene") per il titolo dei quadratini non disponibili, testo
  // esteso per il toast quando ci si tappa sopra: DUE dizionari separati, stessa chiave 'tipo'.
  // 'base' e' il caso nuovo: un colore base che NON e' quello uscito alla nascita non si puo'
  // mettere, e il motivo non e' "compralo" ma "e' un altro pet" — il messaggio deve dirlo, o
  // sembra un negozio rotto.
  var ORIGINE_COLORE_LABEL = { negozio: 'Nel negozio', supporter: 'Supporter Pack', base: 'Colore di nascita' };
  var ORIGINE_COLORE_TESTO = {
    negozio: ' si sblocca nel negozio, sezione Guardaroba.',
    supporter: ' si sblocca con il Supporter Pack.',
    base: ' e\' il colore di un altro pet: il tuo nasce col suo, e i colori comprati entrano nel pool dei prossimi.'
  };

  // Regola di disponibilita' UNICA (selettore scheda + negozio, MAI duplicata altrove): i tre
  // base sempre; i due a monete se il loro indice e' in state.coloriSbloccati; i tre Supporter se
  // state.supporter === true. Un indice sconosciuto (fuori tabella) non e' mai disponibile.
  // Il colore ESTRATTO alla nascita. I pet nati prima che esistesse coloreNascita non ce l'hanno:
  // si ripiega sul colore attuale, che per loro e' comunque quello con cui sono nati.
  function coloreNascitaDi(pet) {
    var p = (pet && pet.parts) || {};
    return (typeof p.coloreNascita === 'number') ? p.coloreNascita : p.colore;
  }

  // Regola (decisione fondatore 29 lug 2026): il colore e' un ESITO, non una scelta libera.
  // - i tre BASE non si scelgono: resta quello uscito alla nascita, se no il tiro non conta piu';
  // - i colori COMPRATI si possono mettere e togliere quando si vuole — chi paga compra controllo,
  //   e in piu' entrano nel pool dei pet futuri (v. pet.js generate);
  // - si puo' SEMPRE tornare al proprio colore di nascita, o mettersi un colore comprato sarebbe
  //   una porta a senso unico.
  function coloreDisponibile(state, indice) {
    var voce = null;
    for (var i = 0; i < COLORI_PET.length; i++) {
      if (COLORI_PET[i].indice === indice) { voce = COLORI_PET[i]; break; }
    }
    if (!voce) return false;
    if (state && state.pet && indice === coloreNascitaDi(state.pet)) return true;
    if (voce.tipo === 'base') return false;
    if (voce.tipo === 'negozio') {
      return !!(state && Array.isArray(state.coloriSbloccati) && state.coloriSbloccati.indexOf(indice) !== -1);
    }
    if (voce.tipo === 'supporter') {
      // GDD "Monetizzazione": un acquisto IAP singolo (es. colore_oro) finisce nello STESSO pool
      // a monete (coloriSbloccati) dei cosmetici comprati con le monete — disponibile col
      // Supporter Pack OPPURE con l'indice gia' sbloccato singolarmente.
      return !!(state && (state.supporter === true || (Array.isArray(state.coloriSbloccati) && state.coloriSbloccati.indexOf(indice) !== -1)));
    }
    return false;
  }

  // Copia leggera del pet con SOLO parts.colore forzato all'indice richiesto (parts clonato: mai
  // tocca il pet vero). Serve alle anteprime (quadratini scheda + righe negozio): mostrano il
  // colore VERO disegnando il pet con PETQ.sprites.draw, MAI duplicando le palette a mano (non
  // sono esposte fuori da sprites.js, ed e' giusto cosi'). corpo/modSprite copiati per un'anteprima
  // fedele (stessa forma/mod permanente del pet vero); indossato/armaEquip volutamente OMESSI
  // (l'anteprima e' solo il colore, non l'outfit del momento).
  function petFintoConColore(pet, indice) {
    var finto = {};
    for (var k in pet) { if (Object.prototype.hasOwnProperty.call(pet, k)) finto[k] = pet[k]; }
    finto.corpo = (PETQ.pet && PETQ.pet.bodyVariant) ? PETQ.pet.bodyVariant(pet) : 'normale';
    finto.parts = {};
    if (pet.parts) {
      for (var k2 in pet.parts) { if (Object.prototype.hasOwnProperty.call(pet.parts, k2)) finto.parts[k2] = pet.parts[k2]; }
    }
    finto.parts.colore = indice;
    return finto;
  }

  // Canvas 16x16 con l'anteprima disegnata (frame 0, fermo): fattorizzato qui perche' lo usano sia
  // il selettore in scheda (clickable) sia le righe del negozio (statico) — stesso disegno, stili
  // diversi applicati dal chiamante. pet assente (nessuna partita in corso) -> canvas vuoto, mai
  // un errore.
  function creaAnteprimaColore(pet, indice) {
    var cv = document.createElement('canvas');
    // 32 nativi (scale 2), NON 16: tutti i consumatori mostrano a 36-40px CSS e 16->36 e' un
    // ingrandimento x2,25 non intero — con pixelated i pixel escono di taglie diverse e l'occhio
    // legge "sfocato" (visto nel negozio, 24 ago 2026). Da 32 lo stiro e' minimo e resta nitido.
    cv.width = 32; cv.height = 32;
    cv.style.imageRendering = 'pixelated';
    if (pet && PETQ.sprites && PETQ.sprites.draw) {
      PETQ.sprites.draw(cv, petFintoConColore(pet, indice), { frame: 0, scale: 2 });
    }
    return cv;
  }

  // ===== STANZE (skin cosmetiche della stanza, batch cosmetici — STESSO SCHEMA di COLORI_PET
  // sopra: tabella dati unica, regola di disponibilita' unica, anteprima fattorizzata) =====
  // TABELLA DATI UNICA (id = valore accettato da PETQ.rooms.draw/BUILDERS, nome per traduci(),
  // tipo, prezzo): selettore in scheda e blocco negozio la leggono ENTRAMBI da qui. 'razza' = i
  // due temi storici, sempre disponibili (nessuna scelta: e' il ripiego di temaRazza, v. sotto);
  // 'negozio' = le quattro comprabili a monete (skinSbloccate); 'supporter' = le tre del
  // Supporter Pack (stesso state.supporter dei colori, per ora acceso solo da debug).
  var SKIN_STANZE = [
    { id: 'lab', nome: 'Laboratorio', tipo: 'razza' },
    { id: 'ship', nome: 'Astronave', tipo: 'razza' },
    { id: 'nonna', nome: 'Casa della Nonna', tipo: 'negozio', prezzo: 500 },
    { id: 'dojo', nome: 'Dojo', tipo: 'negozio', prezzo: 600 },
    { id: 'baita', nome: 'Baita di Montagna', tipo: 'negozio', prezzo: 700 },
    { id: 'bunker', nome: 'Bunker', tipo: 'negozio', prezzo: 800 },
    { id: 'arcade', nome: 'Sala Giochi', tipo: 'supporter' },
    { id: 'mare', nome: 'Fondale Marino', tipo: 'supporter' },
    { id: 'castello', nome: 'Castello', tipo: 'supporter' }
  ];
  // Etichette "come si ottiene" — STESSI due dizionari/stesse chiavi testuali di
  // ORIGINE_COLORE_LABEL/TESTO (nessun campo 'base': qui non serve, i due 'razza' non hanno un
  // testo "come si ottiene", sono sempre disponibili e non compaiono mai spenti).
  var ORIGINE_SKIN_LABEL = { negozio: 'Nel negozio', supporter: 'Supporter Pack' };
  var ORIGINE_SKIN_TESTO = {
    negozio: ' si sblocca nel negozio, sezione Arredamento.',
    supporter: ' si sblocca con il Supporter Pack.'
  };

  // Regola di disponibilita' UNICA (selettore scheda + negozio, MAI duplicata altrove): i due
  // 'razza' sempre; i quattro a monete se il loro id e' in state.skinSbloccate; i tre Supporter
  // se state.supporter === true. Un id sconosciuto (fuori tabella) non e' mai disponibile.
  function skinDisponibile(state, id) {
    var voce = null;
    for (var i = 0; i < SKIN_STANZE.length; i++) {
      if (SKIN_STANZE[i].id === id) { voce = SKIN_STANZE[i]; break; }
    }
    if (!voce) return false;
    if (voce.tipo === 'razza') return true;
    if (voce.tipo === 'negozio') {
      return !!(state && Array.isArray(state.skinSbloccate) && state.skinSbloccate.indexOf(id) !== -1);
    }
    if (voce.tipo === 'supporter') {
      // GDD "Monetizzazione": un acquisto IAP singolo (es. skin_arcade) finisce nello STESSO pool
      // a monete (skinSbloccate) — disponibile col Supporter Pack OPPURE con l'id gia' sbloccato
      // singolarmente.
      return !!(state && (state.supporter === true || (Array.isArray(state.skinSbloccate) && state.skinSbloccate.indexOf(id) !== -1)));
    }
    return false;
  }

  // Canvas con la STANZA VERA in miniatura (mai un campione di colore/tinta disegnato a mano):
  // PETQ.rooms.draw sul salone, senza arredi/cacca/ingrandimento — stesso identico principio di
  // creaAnteprimaColore sopra (il disegno vero, fattorizzato una volta sola, usato sia dal
  // selettore in scheda sia dalla riga del negozio). Dimensione NATIVA 112 x altezza-base (96,
  // v. rooms.altezzaStanza con ingrandimentoCasa:false): lo stile (larghezza a schermo, bordo,
  // opacita') lo applica ciascun chiamante, stesso pattern di creaAnteprimaColore.
  function creaAnteprimaStanza(id) {
    var cv = document.createElement('canvas');
    cv.style.imageRendering = 'pixelated'; // v. commento in creaAnteprimaColore
    cv.width = ROOM_W;
    cv.height = (PETQ.rooms && PETQ.rooms.altezzaStanza) ? PETQ.rooms.altezzaStanza({ ingrandimentoCasa: false }) : ROOM_H;
    if (PETQ.rooms && PETQ.rooms.draw) {
      PETQ.rooms.draw(cv, id, 'salone', { poop: null, arredi: [], ingrandimentoCasa: false });
    }
    return cv;
  }

  // ===== CORNICI (cornici cosmetiche della cartolina esito, batch cosmetici — STESSO SCHEMA di
  // COLORI_PET/SKIN_STANZE sopra: tabella dati unica, regola di disponibilita' unica, anteprima
  // fattorizzata) =====
  // TABELLA DATI UNICA (id = valore accettato da PETQ.sprites.drawCartolina/drawCornice/_cornici,
  // nome per traduci(), tipo, prezzo): selettore in scheda e blocco negozio la leggono ENTRAMBI da
  // qui. 'negozio' = le tre comprabili a monete (corniciSbloccate); 'supporter' = le due del
  // Supporter Pack (stesso state.supporter di colori/stanze, per ora acceso solo da debug). Nessun
  // tipo 'base'/'razza' qui: a differenza di colore/stanza non esiste un ripiego "di nascita" — il
  // ripiego e' semplicemente "nessuna cornice" (corniceAttiva null), sempre disponibile a chiunque.
  var CORNICI_CARTOLINA = [
    { id: 'polaroid', nome: 'Polaroid', tipo: 'negozio', prezzo: 300 },
    { id: 'pellicola', nome: 'Pellicola', tipo: 'negozio', prezzo: 400 },
    { id: 'pergamena', nome: 'Pergamena', tipo: 'negozio', prezzo: 500 },
    { id: 'dorata', nome: 'Dorata', tipo: 'supporter' },
    { id: 'neon', nome: 'Neon', tipo: 'supporter' }
  ];
  // Etichette "come si ottiene": NESSUN dizionario nuovo qui — le cornici hanno esattamente gli
  // stessi due 'tipo' (negozio/supporter) delle skin stanza, si vendono nella STESSA sezione
  // Arredamento del negozio, quindi riusano DIRETTAMENTE ORIGINE_SKIN_LABEL/ORIGINE_SKIN_TESTO
  // definiti sopra (v. sezione STANZE) invece di duplicare una terza coppia identica.

  // Regola di disponibilita' UNICA (selettore scheda + negozio, MAI duplicata altrove): le tre
  // 'negozio' se il loro id e' in state.corniciSbloccate; le due 'supporter' se state.supporter
  // === true. Un id sconosciuto (fuori tabella) non e' mai disponibile. NB: null/assente (nessuna
  // cornice) non passa da qui, e' sempre valido a monte (v. corniceCorrente sotto).
  function corniceDisponibile(state, id) {
    var voce = null;
    for (var i = 0; i < CORNICI_CARTOLINA.length; i++) {
      if (CORNICI_CARTOLINA[i].id === id) { voce = CORNICI_CARTOLINA[i]; break; }
    }
    if (!voce) return false;
    if (voce.tipo === 'negozio') {
      return !!(state && Array.isArray(state.corniciSbloccate) && state.corniciSbloccate.indexOf(id) !== -1);
    }
    if (voce.tipo === 'supporter') {
      // GDD "Monetizzazione": l'acquisto IAP singolo (pack_cornici, le due insieme) finisce nello
      // STESSO pool a monete (corniciSbloccate) — disponibile col Supporter Pack OPPURE con l'id
      // gia' sbloccato singolarmente.
      return !!(state && (state.supporter === true || (Array.isArray(state.corniciSbloccate) && state.corniciSbloccate.indexOf(id) !== -1)));
    }
    return false;
  }

  // Cornice REALMENTE applicata alla cartolina esito — STESSO ripiego di temaStanzaCorrente per le
  // skin stanza: se il Supporter si spegne (o un salvataggio perde l'unlock a monete) con una
  // cornice non piu' disponibile ancora scritta in state.corniceAttiva, qui si ripiega
  // silenziosamente su "nessuna cornice" SENZA toccare il campo salvato — se il Supporter si
  // riaccende la cornice torna da sola, esattamente come il tema stanza.
  function corniceCorrente(state) {
    if (state && state.corniceAttiva && corniceDisponibile(state, state.corniceAttiva)) return state.corniceAttiva;
    return null;
  }

  // Canvas con la CARTOLINA VERA in miniatura (mai un campione disegnato a mano): scena fissa
  // 'std_sociale' col pet CORRENTE (petLikeDaState, la STESSA funzione che disegna la cartolina
  // vera in mostraEsito) — stesso principio di creaAnteprimaColore/creaAnteprimaStanza sopra.
  // cornice null/undefined = anteprima "Nessuna" (scena senza alcuna cornice sopra, via il guard
  // di sprites.drawCartolina). Dimensione = ROOM_W/ROOM_H, le STESSE della cartolina vera (112x64,
  // coincidono con CART_W/CART_H interni a sprites.js).
  function creaAnteprimaCornice(state, cornice) {
    var cv = document.createElement('canvas');
    cv.width = ROOM_W;
    cv.height = ROOM_H;
    if (state && state.pet && PETQ.sprites && PETQ.sprites.drawCartolina) {
      PETQ.sprites.drawCartolina(cv, 'std_sociale', petLikeDaState(state), cornice);
    }
    return cv;
  }

  // ===== COMPLETI (vestiti a due pezzi, batch cosmetico, 29 lug 2026 — STESSO SCHEMA di
  // COLORI_PET/SKIN_STANZE/CORNICI_CARTOLINA sopra: tabella dati unica, regola di disponibilita'
  // unica) =====
  // TABELLA DATI UNICA (nome = chiave in sprites.js VESTITO_SPR E in state.indossato — un completo
  // e' un vestito come un altro, nessun campo "attivo" dedicato — tipo, prezzo): Armadio della
  // scheda e blocco negozio la leggono ENTRAMBI da qui. 'negozio' = i tre comprabili a monete
  // (completiSbloccati); 'supporter' = i due del Supporter Pack (stesso state.supporter di
  // colori/stanze/cornici, per ora acceso solo da debug). Si vendono in Guardaroba (come i vestiti
  // e i colori), NON in Arredamento (dove stanno stanze/cornici): sono vestiti, non arredi. Sono
  // COSMETICI PURI: nessuna voce in content/arredi.md ne' in missions.js EFFETTI_INDOSSABILI ->
  // bonusIndossato non da' mai bonus stat per questi nomi (v. report per la verifica citata riga
  // per riga).
  var COMPLETI_VESTITO = [
    { nome: 'Completo da Pirata', tipo: 'negozio', prezzo: 700 },
    { nome: 'Muta da Sub', tipo: 'negozio', prezzo: 800 },
    { nome: 'Tuta Spaziale', tipo: 'negozio', prezzo: 900 },
    // Decisione fondatore 29 lug 2026: i vestiti NON entrano nel Supporter Pack — "sono carini
    // ma non giustificano una spesa di soldi veri". Tutti e cinque a monete, prezzo crescente
    // con quanto cambiano la silhouette.
    { nome: 'Armatura del Cavaliere', tipo: 'negozio', prezzo: 1000 },
    { nome: 'Smoking', tipo: 'negozio', prezzo: 1100 }
  ];

  // Regola di disponibilita' UNICA (Armadio + negozio, MAI duplicata altrove): i tre 'negozio' se
  // il loro nome e' in state.completiSbloccati; i due 'supporter' se state.supporter === true. Un
  // nome sconosciuto (fuori tabella) non e' mai disponibile. STESSA forma di coloreDisponibile/
  // skinDisponibile/corniceDisponibile sopra; nessun 'base' qui (a differenza dei colori nessun
  // completo e' gratis di default).
  function completoDisponibile(state, nome) {
    var voce = null;
    for (var i = 0; i < COMPLETI_VESTITO.length; i++) {
      if (COMPLETI_VESTITO[i].nome === nome) { voce = COMPLETI_VESTITO[i]; break; }
    }
    if (!voce) return false;
    if (voce.tipo === 'negozio') {
      return !!(state && Array.isArray(state.completiSbloccati) && state.completiSbloccati.indexOf(nome) !== -1);
    }
    if (voce.tipo === 'supporter') return !!(state && state.supporter === true);
    return false;
  }

  // ===== Anteprime VERE nel Negozio (GDD "Negozio visivo", decisione fondatore 24 ago 2026) =====
  // Pet di ripiego SOLO per disegnare le anteprime del negozio quando la casa e' vuota (nessuna
  // partita in corso, currentState.pet assente): mostraScheda in quel caso semplicemente non si
  // apre (v. "if (!state || !state.pet) return;" in cima alla funzione), ma il negozio deve
  // restare navigabile anche senza pet. Generato UNA volta sola (cache di modulo, mai salvato:
  // PETQ.pet.generate riceve state=null apposta, cosi' non tocca leggende/perk casa/talenti di
  // una partita vera) e riusato per tutta la sessione, cosi' i colori/vestiti non "sfarfallano"
  // diversi ad ogni ri-render della stessa apertura del negozio.
  var petRipiegoNegozioCache = null;
  function petPerNegozio() {
    if (currentState && currentState.pet) return currentState.pet;
    if (!petRipiegoNegozioCache && PETQ.pet && PETQ.pet.generate) {
      petRipiegoNegozioCache = PETQ.pet.generate('alieno', null);
    }
    return petRipiegoNegozioCache;
  }
  // STESSA idea di statoAnteprimaNegozio... ma per le funzioni (creaAnteprimaCornice) che vogliono
  // uno "state" intero (leggono anche indossato/armaEquip via petLikeDaState), non solo il pet:
  // con partita in corso e' currentState stesso; a casa vuota e' un involucro minimo col SOLO pet
  // di ripiego (nessun indossato/arma finti: la cartolina di ripiego mostra il pet nudo, corretto).
  function statoAnteprimaNegozio() {
    if (currentState && currentState.pet) return currentState;
    return { pet: petPerNegozio() };
  }

  // Copia leggera del pet con SOLO indossato forzato al nome richiesto (STESSA idea di
  // petFintoConColore sopra, per colore): mostra l'abito VERO disegnandolo con PETQ.sprites.draw,
  // mai un'icona a parte duplicata. Il vestito si passa DENTRO petLike.indossato (non come
  // argomento a parte di sprites.draw): drawOverlayEquip lo legge da li' e lo disegna sopra il
  // pet, STESSO meccanismo gia' attivo quando il giocatore indossa davvero qualcosa (v.
  // petLikeDaState). Leggende: indossato forzato a null, STESSO gate dell'Armadio/petLikeDaState
  // ("le leggende non indossano mai nulla a schermo", decisione fondatore 28 lug 2026) — cosi' la
  // riga negozio di un vestito, vista col pet corrente = una leggenda, non mostra un abito che poi
  // in game non comparirebbe mai.
  function petFintoConIndossato(pet, nomeVestito) {
    var finto = {};
    for (var k in pet) { if (Object.prototype.hasOwnProperty.call(pet, k)) finto[k] = pet[k]; }
    finto.corpo = (PETQ.pet && PETQ.pet.bodyVariant) ? PETQ.pet.bodyVariant(pet) : 'normale';
    finto.parts = {};
    if (pet.parts) {
      for (var k2 in pet.parts) { if (Object.prototype.hasOwnProperty.call(pet.parts, k2)) finto.parts[k2] = pet.parts[k2]; }
    }
    finto.indossato = (pet.razza === 'leggenda') ? null : nomeVestito;
    return finto;
  }

  // Canvas con IL PET DEL GIOCATORE (o il ripiego) vestito col completo/indossabile — dimensione
  // NATIVA PET_PX (32x32, STESSA scala 1:1 con cui il pet vero e' disegnato in stanza, v. PET_SIZE/
  // PET_SCALE in cima al file): a differenza dei quadratini colore (16x16) qui serve piu' spazio,
  // perche' gli ancoraggi degli abiti possono sporgere oltre la sagoma 16x16 del corpo (cappelli,
  // codini, stivali) — con un canvas piu' piccolo si taglierebbero ai bordi. Lo stile a schermo
  // (dimensione CSS, pixelated) lo applica il chiamante (classe .petq-shop-anteprima).
  function creaAnteprimaIndossato(pet, nomeVestito) {
    var cv = document.createElement('canvas');
    cv.width = PET_PX; cv.height = PET_PX;
    if (pet && PETQ.sprites && PETQ.sprites.draw) {
      PETQ.sprites.draw(cv, petFintoConIndossato(pet, nomeVestito), { frame: 0 });
    }
    return cv;
  }

  // posizioni placeholder degli slot arredo nelle stanze (puntino luminoso finché la
  // grafica non disegna gli arredi veri)
  var SLOT_SPOTS = [[10, 41], [55, 39], [99, 41]];

  // tinte fallback della cartolina esito per scena/categoria (guard su sprites.drawCartolina)
  var TINTE_SCENA = {
    fail: { sfondo: '#4a505a', terra: '#383e48' },
    superSc: { sfondo: '#5a4a22', terra: '#44381c' },
    videogioco: { sfondo: '#2f3a5f', terra: '#242c48' },
    sociale: { sfondo: '#5f3a52', terra: '#472b3d' },
    combattimento: { sfondo: '#5f3232', terra: '#472525' },
    studio: { sfondo: '#2f4a3a', terra: '#23382c' },
    consegne: { sfondo: '#545130', terra: '#3f3d24' },
    sport: { sfondo: '#2f4a5f', terra: '#233848' },
    generica: { sfondo: '#3a4150', terra: '#2b303c' }
  };

  var appEl = null;
  var currentState = null;
  var currentStanza = 'cucina';
  var idleTimer = null;
  var idleFrame = 0;
  var balloonTimer = null;
  var toastTimer = null;
  var avvisoTimer = null;

  // ==================== Animazioni idle di personalita' (GDD "Personalita'" -> "Animazioni
  // idle di personalita'", decisione fondatore 5 lug 2026, P1 versione leggera) ====================
  // Quando il pet e' fermo in casa (sveglio, non in missione/allenamento, stanza normale,
  // niente drag/animazione in corso) ogni tanto parte una mini-azione tipica della sua
  // personalita' (2 per personalita', v. IDLE_ACTIONS sotto): un layer SOPRA la posa idle
  // normale (respiro/blink/sporco/body variant restano intatti, v. disegnaStanzaEPet), per
  // ~3-4s, poi torna tutto normale. Qualsiasi input (tap/drag/azione) la annulla subito
  // (v. annullaIdleAction, richiamata da installaPointerCanvas e dai punti di ingresso delle
  // azioni di gioco). idleAction: null | {id, personalita, startMs, durataMs}.
  var idleAction = null;
  var idleActionProssimaMs = 0; // Date.now() della prossima idle action programmata
  var IDLE_ACTION_DURATA_MS = 3500;
  var IDLE_ACTION_INTERVALLO_MIN_MS = 12000;
  var IDLE_ACTION_INTERVALLO_MAX_MS = 20000;

  // 2 azioni per personalita' (GDD): {id, prop:null|idIconaIdle|'libro'|'pesi', overlay:null|'boccaccia',
  // muovi:null|'su_giu'|'sinistra_destra'}. "prop" riusa drawProp esistente per id noti
  // (libro/pesi), altrimenti drawIdleProp (cubo/note/monete, nuovi). "overlay" e' un effetto
  // sul volto/corpo (boccaccia) invece di un prop accanto.
  var IDLE_ACTIONS = {
    sportivo: [
      { id: 'sportivo_allena', prop: 'pesi', muovi: 'su_giu' },
      { id: 'sportivo_corre', prop: null, muovi: 'sinistra_destra' }
    ],
    nerd: [
      { id: 'nerd_legge', prop: 'libro', muovi: null },
      { id: 'nerd_cubo', prop: 'cuborubik', muovi: null }
    ],
    gentile: [
      { id: 'gentile_canta', prop: 'note', muovi: null },
      { id: 'gentile_disegna', prop: 'libro', muovi: null }
    ],
    maleducato: [
      { id: 'maleducato_conta', prop: 'monete', muovi: null },
      { id: 'maleducato_boccaccia', prop: null, overlay: 'boccaccia', muovi: null }
    ]
  };

  // effetto in corso sul canvas: null | {tipo:'crumbs'} | {tipo:'wash'} |
  // {tipo:'train', prop} | {tipo:'puff', x, y, step}
  var effetto = null;
  var animazioneInCorso = false;
  var petDragging = false;
  var lastPetRect = null; // rettangolo logico del pet nell'ultimo draw

  var ghostEl = null;
  var ghostCanvas = null;

  var canvasPointer = null; // gesto in corso sul canvas stanza
  var foodPointer = null;   // gesto in corso su una card cibo

  var collezioneAperta = false;   // pannello Collezione (salone) aperto/chiuso
  var battutaPartenza = null;     // battuta 'missione_partenza' mostrata sulla card in corso
  var missioneSelezionata = null; // id del pin selezionato sulla mappa missioni
  var mapPointer = null;          // gesto in corso sul canvas mappa
  var frigoAperto = false;        // pannello frigo (cucina) aperto/chiuso
  var cuocoAttivo = false;        // interruttore Cuoco di Casa: il prossimo cibo toccato va cucinato
  var giocattoliAperti = false;   // menu "Usa un giocattolo" (salone) aperto/chiuso
  // Guardia anti-regressione (fix "mappa m73-98 ingiocabile"): se un id missione nella rosa
  // non ha un pin in rooms.js (MAPPA_PINS), qui gia' saltiamo senza eccezioni (hitPin/
  // piazzaEtichetta controllano "rect" prima di usarlo) — questo tracker serve solo per loggare
  // UNA volta sola con console.warn invece di restare silenziosi, cosi' il problema si nota in
  // console senza spammarla ad ogni tap/redraw.
  var _pinMancantiAvvisatiUi = {};
  function avvisaPinMancanteUi(id) {
    if (_pinMancantiAvvisatiUi[id]) return;
    _pinMancantiAvvisatiUi[id] = true;
    console.warn('pin mancante: ' + id);
  }
  var negozioSelezionato = false; // pannello negozio (mappa) aperto/chiuso
  var shopSezione = 'cibo';       // sezione attiva del negozio: 'cibo' | 'arredi' | 'giocattoli' | 'guardaroba' | 'vendi' | 'sostieni'
  var vendiConferma = null;       // nome dell'arredo-perk in attesa di conferma vendita
  // IAP (GDD "Monetizzazione", modulo PETQ.iap — puo' mancare: browser/file:// o plugin non
  // caricato). iapPrezzi = mappa id->prezzo dell'ultima PETQ.iap.prodotti() risolta (null finche'
  // non arriva, v. renderShopSostieni). iapSincronizzato = true dopo la sincronizza() UNA sola
  // volta per avvio (v. render()), idempotente.
  var iapPrezzi = null;
  var iapSincronizzato = false;
  var pensioneConferma = false;   // scheda: primo tap "Manda in pensione" -> attende conferma (2 tap, e' per sempre)
  // Modalita' ciak (clip social): true = pannello debug nascosto per registrare. Variabile di
  // MODULO e non locale a montaDebugPanel, cosi' un rimontaggio del pannello a meta' ripresa non
  // lo fa ricomparire nell'inquadratura (v. applicaVisibilitaDebug dentro montaDebugPanel).
  var debugPanelNascosto = false;
  // Set silenzioso (brief regia round 4): col pannello debug attivo il pet NON parla da solo, cosi'
  // non si intromette sopra il ciak. Vale SOLO in debug — nel gioco vero non cambia niente — ed e'
  // un interruttore e non una costante perche' in QA le battute spontanee servono ancora.
  var setSilenzioso = true;
  var miracoloScelteAperte = false; // scheda: tap "✨ Miracolo" -> mostra le 4 scelte (talento Santo Subito)

  // Costo dell'upgrade "Ingrandimento casa" (GDD "Slot arredo, tetto passivo e Ingrandimento
  // casa"): 1 acquisto GLOBALE che sblocca il 4o slot in tutte le stanze e le ingrandisce in
  // altezza (state.ingrandimentoCasa). Deciso dal fondatore.
  var COSTO_INGRANDIMENTO = 200;

  // ---------- util ----------

  function bilanciamento() {
    var data = window.PETQ.content && window.PETQ.content.data;
    if (data && data.bilanciamento) return data.bilanciamento;
    console.warn('PETQ.ui: bilanciamento non disponibile, uso default locali');
    return { economia: { monetePartenza: 50 } };
  }

  function oggiStr() {
    var d = new Date();
    var mese = String(d.getMonth() + 1).padStart(2, '0');
    var giorno = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + mese + '-' + giorno;
  }

  // Debug "Nuovo giorno": retrodata di N giorni ogni voce di state.missioniFatte (mappa
  // {id: 'YYYY-MM-DD'}), cosi' il cooldown missioni (3 giorni, v. missions.js) si puo' testare
  // senza aspettare la mezzanotte reale. Formato data stringa: costruiamo la data a mezzogiorno
  // per evitare sfasamenti da fuso/ora legale, stesso pattern di missions.js diffGiorniStr.
  function retrodataCooldownMissioni(state, giorni) {
    if (!state || !state.missioniFatte || typeof state.missioniFatte !== 'object') return;
    var chiavi = Object.keys(state.missioniFatte);
    for (var i = 0; i < chiavi.length; i++) {
      var dataStr = state.missioniFatte[chiavi[i]];
      var d = new Date(dataStr + 'T12:00:00Z');
      d.setUTCDate(d.getUTCDate() - giorni);
      var mese = String(d.getUTCMonth() + 1).padStart(2, '0');
      var giorno = String(d.getUTCDate()).padStart(2, '0');
      state.missioniFatte[chiavi[i]] = d.getUTCFullYear() + '-' + mese + '-' + giorno;
    }
  }

  function el(tag, cls, txt) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (txt !== undefined && txt !== null) e.textContent = txt;
    return e;
  }

  function getApp() {
    if (!appEl) appEl = document.getElementById('app');
    return appEl;
  }

  function temaRazza(pet) {
    return (pet && pet.razza === 'robot') ? 'lab' : 'ship';
  }

  // Tema VISIVO corrente della stanza (skin cosmetiche, batch cosmetici): state.skinAttiva se
  // valorizzata E ancora disponibile (skinDisponibile, tabella SKIN_STANZE sopra), altrimenti il
  // ripiego storico temaRazza(pet) — cosi' un salvataggio senza skin scelta, o con una skin che
  // nel frattempo e' diventata indisponibile (es. Supporter Pack disattivato da debug), continua
  // a mostrare lab/ship come sempre, senza mai un tema vuoto/rotto. Unico punto che decide COSA
  // DISEGNARE per la stanza: v. report per l'elenco di dove sostituisce temaRazza e dove no.
  function temaStanzaCorrente(state) {
    if (state && state.skinAttiva && skinDisponibile(state, state.skinAttiva)) {
      return state.skinAttiva;
    }
    return temaRazza(state && state.pet);
  }

  function coordLogiche(canvas, clientX, clientY) {
    var r = canvas.getBoundingClientRect();
    if (!r.width || !r.height) return { x: -1, y: -1 };
    return {
      x: (clientX - r.left) * ROOM_W / r.width,
      // altezza corrente (64 o 80): il canvas della stanza e' alto ROOM_H o piu', quindi la
      // mappatura pixel->coord logiche deve usare l'altezza vera, non la costante 64.
      y: (clientY - r.top) * altezzaStanzaCorrente() / r.height
    };
  }

  function dentroRect(p, rect, margine) {
    var m = margine || 0;
    return p.x >= rect.x - m && p.x <= rect.x + rect.w + m &&
           p.y >= rect.y - m && p.y <= rect.y + rect.h + m;
  }

  // ---------- boot pubblico ----------

  function boot(state) {
    if (state) {
      currentState = state;
      // Pet partito (PROTOTIPO 2, Blocco 2): se non c'e' un pet in casa (state.pet null e
      // state.petPartito valorizzato) la casa mostra la schermata "pet partito" col bottone
      // "Fai ammenda", non il gioco normale. Va controllato PRIMA di tutto il resto (sonno/
      // missione/evoluzione presuppongono un pet in scena).
      if (petAssente(state)) { mostraPetPartito(state); return; }
      // Casa vuota post-RITIRO (pensione): nessun pet, non e' valigia, ma ci sono pensionati.
      // Torna al Pianeta (scelta "Riprendi"/"Prendi nuovo") invece di uno stato rotto. Va DOPO il
      // caso valigia (petPartito) e prima di tutto il resto (sonno/missione/evoluzione: nessun pet).
      if (casaVuotaPensione(state)) { mostraPianetaRitirati(state); return; }
      controllaSonnoScaduto();
      controllaAllenamentoScaduto();
      // apertura app con missione già finita: risolvi e mostra subito l'esito
      if (controllaMissioneScaduta()) return;
      // evoluzione baby->teen maturata offline (es. tanti "giorni" passati mentre l'app era
      // chiusa): prende il controllo e mostra la schermata dedicata prima della casa.
      if (controllaEvoluzioneScaduta()) return;
      // evento valigia maturato offline (login giornaliero al boot): valigetta/rientro/addio.
      if (controllaEventoValigia()) return;
      // porta pendente (Batch B: Dilemmi + Lavori) maturata offline: corso/lavoretto/svolta.
      if (controllaPortaPendente()) return;
      if (controllaCartaPendente()) return;
      // risveglio maturato offline (fix "il pet non saluta mai quando si sveglia"): la battuta +
      // monete notturne depositate da main.js, v. controllaRisveglioPendente.
      if (controllaRisveglioPendente()) return;
      mostraCasa(state);
      // Popup una-tantum Supporter Pack (v. controllaPopupSostieni): NON un "return" come le
      // guardie sopra, e' un overlay indipendente che non prende il controllo di #app — dopo
      // mostraCasa il gioco e' gia' pronto, qui si aggiunge solo la promo se le condizioni ci sono.
      controllaPopupSostieni();
    } else {
      mostraIntro();
    }
  }

  function render(state) {
    if (!state) return;
    currentState = state;
    // Pet partito: se durante un tick il pet e' partito (es. partenza maturata al nuovo giorno
    // mentre l'app e' aperta), passiamo alla schermata dedicata. controllaEventoValigia sotto
    // mostra l'addio; qui gestiamo il caso in cui siamo gia' oltre (pet assente, nessun evento).
    if (petAssente(state) && !state.eventoValigia) {
      // Non clobberare la schermata ADDIO (mostraAddio, class .petq-addio) mentre e' ancora a
      // video: dopo una partenza a META' SESSIONE (mezzanotte di gioco attraversata col tick,
      // ora che dailyLogin gira ad ogni tick) l'addio con la battuta di commiato va lasciato
      // finche' l'utente non preme "Continua" (che porta a mostraPetPartito, il quale monta l'id
      // petq-pet-partito). Senza il check su .petq-addio, il tick successivo — vedendo petAssente,
      // nessun eventoValigia pendente (gia' consumato) e nessun id petq-pet-partito — sostituirebbe
      // silenziosamente l'addio con la schermata "pet partito" entro 30s, senza input utente.
      if (!document.getElementById('petq-pet-partito') && !document.querySelector('.petq-addio')) mostraPetPartito(state);
      return;
    }
    // Casa vuota post-ritiro (pensione): se un tick capita con la casa vuota + pensionati (es.
    // ricarica pagina), porta al Pianeta. Ma NON clobberare uno schermo del flusso "prendi nuovo"
    // gia' a video (durante il quale state.pet e' ancora null): il Pianeta stesso
    // (petq-pianeta-overlay), la scelta razza (petq-intro), il naming (petq-nascita) e la
    // sequenza di schiusa (petq-schiusa, Round 5 — nuovoPetInCasa lascia state.pet null per
    // TUTTA la cerimonia, esattamente come .petq-nascita qui sotto) restano.
    if (casaVuotaPensione(state)) {
      if (!document.getElementById('petq-pianeta-overlay') &&
          !document.querySelector('.petq-intro') &&
          !document.querySelector('.petq-nascita') &&
          !document.getElementById('petq-schiusa')) {
        mostraPianetaRitirati(state);
      }
      return;
    }
    // Sincronizzazione IAP (GDD "Monetizzazione"): riapplica la verita' RevenueCat (cache
    // offline) UNA sola volta per avvio, appena currentState e' pronto — idempotente, non
    // ri-acquista nulla, sblocca solo cio' che il negozio ha gia' confermato. Guardia sempre su
    // window.PETQ.iap && disponibile(): il modulo puo' mancare (browser/file:///plugin assente).
    if (!iapSincronizzato && window.PETQ.iap && PETQ.iap.disponibile()) {
      iapSincronizzato = true;
      PETQ.iap.sincronizza(state, function (err, risultato) {
        if (err) return;
        var n = (risultato && typeof risultato.nuovi === 'number') ? risultato.nuovi : 0;
        if (n > 0) {
          PETQ.save.save(currentState);
          mostraAvviso(traduci('Acquisti ripristinati.'));
          aggiornaHud(currentState);
          disegnaStanzaEPet(currentState);
        }
      });
    }
    controllaAnimScaduta();
    controllaSonnoScaduto();
    controllaAllenamentoScaduto();
    controllaGiocoScaduto();
    if (!animazioneInCorso && controllaMissioneScaduta()) return;
    controllaPasseggiataScaduta();
    if (!animazioneInCorso && controllaEvoluzioneScaduta()) return;
    // NB storico: qui c'era un recovery automatico che rimontava M17 "Pimp My Pet" sopra la casa
    // ad ogni giro di render (controllaTeenIntroPendente), gia' rimosso in v144 per il bug
    // "quando diventa teen il tempo si ferma" (mostraTeenIntro svuota #app e il ramo sotto
    // aggiorna HUD/stanza SOLO se #petq-casa esiste). AGGIORNAMENTO 28 lug 2026: la Clinica di
    // Modding "Pimp My Pet" (M17) e' stata RIMOSSA su decisione del fondatore (crea attrito ed
    // e' rimasta fonte di bug) — non si mostra piu' MAI, ne' dopo l'evoluzione a teen
    // (mostraEvoluzione porta sempre alla casa) ne' dal pin sulla mappa (m17 non entra piu' tra
    // gli attivi, v. statoMappa). mostraTeenIntro/controllaTeenIntroPendente restano nel file
    // SENZA chiamanti: i salvataggi vecchi possono avere gia' modSprite applicato e il pet deve
    // continuare a disegnarsi cosi' (drawOverlayEquip legge ancora modSprite, invariato).
    if (!animazioneInCorso && controllaEventoValigia()) return;
    // Porta pendente (Batch B: Dilemmi + Lavori): stesso pattern idempotente, nessun rischio di
    // "tempo fermo" perche' controllaPortaPendente non tocca il DOM quando non c'e' nulla da
    // mostrare (v. commento sulla funzione) — a differenza del vecchio recovery M17 qui sopra.
    if (!animazioneInCorso && controllaPortaPendente()) return;
    if (!animazioneInCorso && controllaCartaPendente()) return;
    // Risveglio pendente (fix "il pet non saluta mai quando si sveglia"): stesso pattern
    // idempotente delle altre, v. controllaRisveglioPendente.
    if (!animazioneInCorso && controllaRisveglioPendente()) return;
    if (document.getElementById('petq-casa')) {
      aggiornaHud(state);
      disegnaStanzaEPet(state);
    }
    // Popup una-tantum Supporter Pack (v. controllaPopupSostieni): si auto-guarda su tutte le
    // schermate a tutto schermo qui sopra, quindi e' sicuro chiamarlo ad ogni giro di render senza
    // un "return" dedicato — non e' uno stato di gioco pendente, e' un overlay indipendente.
    controllaPopupSostieni();
  }

  // Pet assente = non c'e' un pet in casa (partito). Guardia usata dai punti di ingresso della
  // UI per deviare alla schermata "pet partito" (v. mostraPetPartito).
  function petAssente(state) {
    return !!(state && !state.pet && state.petPartito);
  }

  // Casa vuota per PENSIONE = nessun pet in casa, NON e' un caso valigia (petPartito), ma ci sono
  // pensionati sul pianeta. Succede dopo un ritiro (o se ricarichi la pagina con la casa vuota
  // post-ritiro): il giocatore deve ancora scegliere "Riprendi" o "Prendi un pet nuovo" dal
  // Pianeta. boot/render deviano qui (dopo il caso valigia) per non lasciare lo stato rotto.
  function casaVuotaPensione(state) {
    return !!(state && !state.pet && !state.petPartito &&
      Array.isArray(state.pensionati) && state.pensionati.length > 0);
  }

  // Se la missione in corso è finita (tempoRimasto <= 0), la risolve, salva e mostra la
  // schermata esito. Ritorna l'esito (truthy) se ha preso il controllo dello schermo.
  function controllaMissioneScaduta() {
    if (!currentState || !currentState.missione) return null;
    if (PETQ.missions.tempoRimasto(currentState) > 0) return null;
    var esito = PETQ.missions.risolvi(currentState);
    if (!esito || !esito.ok) {
      // scheda sparita o stato incoerente: risolvi ha già ripulito state.missione
      PETQ.save.save(currentState);
      return null;
    }
    PETQ.save.save(currentState);
    mostraEsito(esito);
    return esito;
  }

  // Controlla il ciclo sonno (GDD "Energia e sonno"): sveglia autonoma dopo 8h, o crollo
  // automatico alle 23 se il pet e' ancora sveglio. Chiamata da boot/render/idle (stesso
  // pattern di controllaMissioneScaduta): idempotente, non fa nulla se non e' il momento.
  // Peluffo Ciarliero (giocattolo passivo 'notturno:monete+15'): pet.risolviRisveglio accredita
  // le monete e le riporta in .moneteNotturne. Senza questo toast il giocatore si ritrovava
  // monete in piu' senza sapere da dove — il passivo sembrava rotto.
  function avvisaMoneteNotturne(risveglio) {
    if (!risveglio || !risveglio.moneteNotturne) return;
    mostraToast(traduci('💰 Nel cuscino c\'erano ') + risveglio.moneteNotturne + traduci(' monete!'));
  }

  function controllaSonnoScaduto() {
    if (!currentState || !currentState.pet || !PETQ.pet) return null;
    var risveglio = PETQ.pet.controllaSveglia(currentState);
    if (risveglio) {
      PETQ.save.save(currentState);
      disegnaStanzaEPet(currentState);
      aggiornaHud(currentState);
      renderAzioni();
      mostraBalloon(PETQ.dialog.say(currentState.pet, risveglio.battuta, currentState));
      avvisaMoneteNotturne(risveglio);
      return risveglio;
    }
    var crollato = PETQ.pet.controllaCrolloAutomatico(currentState);
    if (crollato) {
      PETQ.save.save(currentState);
      disegnaStanzaEPet(currentState);
      renderAzioni();
    }
    return null;
  }

  // Risveglio pendente (fix "il pet non saluta mai quando si sveglia", segnalazione fondatore
  // 3 ago 2026): PETQ.main.controllaCicloSonno (main.js) e' chiamata da boot/tick/recuperaTempoReale
  // SEMPRE PRIMA che questa UI ridisegni, e chiama PETQ.pet.controllaSveglia — che CONSUMA il
  // risveglio (state.sonno=null) e ritorna l'esito una volta sola. Per questo, quando arriva qui
  // sopra, controllaSonnoScaduto trova gia' state.sonno=null e il suo `if (risveglio)` non scatta
  // MAI nei percorsi reali: main.js l'ha gia' consumato un istante prima e ha depositato l'esito in
  // state.risveglioEsitoGiorno (stesso schema "deposita ora, mostra al primo render utile" di
  // state.companionEffettiGiorno/state.lavoroEsitoGiorno, v. care.js/controllaCompanionEffettiLogin/
  // controllaLavoroEsitoLogin). Questa funzione lo consuma e mostra ESATTAMENTE come il ramo sopra
  // (stesso mostraBalloon/avvisaMoneteNotturne): la battuta 'sveglia'/'dormito_male' arriva da
  // PETQ.dialog.say, gia' bilingue di suo.
  //
  // Guardie sulle QUATTRO schermate a tutto schermo (cartolina esito, annuncio evoluzione, porta,
  // carta — stesso quartetto di controllaCartaPendente): mostraBalloon vive DENTRO #petq-casa, che
  // NON esiste mentre una di queste e' a video (hanno rimpiazzato #app). Senza queste guardie il
  // balloon non comparirebbe (mostraBalloon si limita a non fare nulla se non trova #petq-balloon)
  // e avremmo GIA' azzerato state.risveglioEsitoGiorno: il risveglio sparirebbe di nuovo, stavolta
  // per un motivo diverso. Rinviando l'INTERA funzione (nessuna lettura-e-azzeramento) il deposito
  // resta intatto finche' la schermata non si libera, e compare al primo render utile — se invece
  // #petq-casa manca semplicemente perche' non e' ancora stata montata (es. primissimo boot dopo un
  // risveglio maturato offline), la montiamo qui stessa, come gia' fa controllaEventoValigia per i
  // casi 'valigia'/'rientro'.
  function controllaRisveglioPendente() {
    if (!currentState || !currentState.pet || !currentState.risveglioEsitoGiorno) return false;
    if (document.getElementById('petq-schermo-esito')) return false;
    if (document.getElementById('petq-schermo-evoluzione')) return false;
    if (document.getElementById('petq-porta')) return false;
    if (document.getElementById('petq-carta')) return false;
    // Sequenza di schiusa (Round 5): stesso principio, v. commento sopra sequenzaSchiusa.
    if (document.getElementById('petq-schiusa')) return false;

    var esito = currentState.risveglioEsitoGiorno;
    currentState.risveglioEsitoGiorno = null;
    PETQ.save.save(currentState);
    if (!document.getElementById('petq-casa')) mostraCasa(currentState);
    disegnaStanzaEPet(currentState);
    aggiornaHud(currentState);
    renderAzioni();
    mostraBalloon(PETQ.dialog.say(currentState.pet, esito.battuta, currentState));
    avvisaMoneteNotturne(esito);
    return true;
  }

  // Rientro dalla passeggiata serale (playtest 8 lug 2026): quando le ore sono fatte, il
  // micro-evento e' gia' applicato da pet.controllaPasseggiataScaduta; qui solo salvataggio,
  // ridisegno e toast. Stesso pattern idempotente degli altri controlla*.
  function controllaPasseggiataScaduta() {
    if (!currentState || !currentState.passeggiata || !PETQ.pet || !PETQ.pet.controllaPasseggiataScaduta) return null;
    var rientro = PETQ.pet.controllaPasseggiataScaduta(currentState);
    if (!rientro) return null;
    PETQ.save.save(currentState);
    disegnaStanzaEPet(currentState);
    aggiornaHud(currentState);
    renderAzioni();
    mostraAvviso(rientro.msg);
    return rientro;
  }

  // Fine del gioco nel salone (8 lug 2026): quando i 10 min sono passati, pet.controllaGiocoScaduto
  // applica il bonus Felicità; qui salvataggio, ridisegno e balloon. Idempotente come gli altri.
  // MENU GIOCATTOLI (fase 3): quando l'attivita' e' partita da un giocattolo del menu, l'effetto
  // vero (Felicita'/monete/cura/oracolo...) e' GIA' stato applicato al tocco da PETQ.giocattoli.usa
  // e quell'attivita' parte con bonus 0 — il messaggio composto da pet.js ("+0 Felicita'") non va
  // bene. Il testo di chiusura lo compone QUI, pezzo per pezzo dentro traduci() (pet.js non ha
  // i18n: prima il balloon di fine gioco restava in italiano anche in inglese), leggendo
  // state.gioco PRIMA che pet.controllaGiocoScaduto lo azzeri.
  function controllaGiocoScaduto() {
    if (!currentState || !currentState.gioco || !PETQ.pet || !PETQ.pet.controllaGiocoScaduto) return null;
    var attivita = currentState.gioco;
    var nomeGiocattolo = attivita.giocattolo || null;
    var bonusFinale = (typeof attivita.bonus === 'number') ? attivita.bonus : GIOCO_BONUS_MANI_NUDE;
    var fine = PETQ.pet.controllaGiocoScaduto(currentState);
    if (!fine) return null;
    PETQ.save.save(currentState);
    disegnaStanzaEPet(currentState);
    aggiornaHud(currentState);
    renderAzioni();
    var nomePet = (currentState.pet && currentState.pet.nome) || traduci('Il pet');
    var msgFine = nomeGiocattolo
      ? '🧸 ' + nomePet + traduci(' ha finito di giocare con ') + traduci(nomeGiocattolo) + '.'
      : '🧸 ' + nomePet + traduci(' ha giocato di gusto! (+') + bonusFinale + traduci(' Felicità)');
    mostraBalloon(msgFine);
    return fine;
  }

  // Controlla l'allenamento a tempo (bilanciamento.md "Durata allenamento"): quando
  // oreFatte >= oreTot, applica l'effetto e mostra il toast/battuta di fine — stesso pattern
  // idempotente di controllaMissioneScaduta/controllaSonnoScaduto sopra, chiamata dagli stessi
  // punti (boot/render/idle).
  function controllaAllenamentoScaduto() {
    if (!currentState || !currentState.allenamento || !PETQ.pet || !PETQ.pet.controllaAllenamentoScaduto) return null;
    var esito = PETQ.pet.controllaAllenamentoScaduto(currentState);
    if (!esito) return null;
    PETQ.save.save(currentState);
    disegnaStanzaEPet(currentState);
    aggiornaHud(currentState);
    renderAzioni();
    if (esito.ok) {
      mostraToast(esito.msg);
      mostraBalloon(PETQ.dialog.say(currentState.pet, 'felice', currentState));
    }
    return esito;
  }

  // ==================== INTRO ====================

  function mostraIntro() {
    fermaIdle();
    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-intro');
    // Nome del gioco: NOME PROPRIO, NON va tradotto (niente traduci()) — stesso valore del
    // <title> in index.html, che lo store mostra come "Hatch a Legend" (v. CLAUDE.md).
    var titolo = el('h1', 'petq-title', 'Hatch a Legend');
    wrap.appendChild(titolo);
    wrap.appendChild(el('p', 'petq-sub', traduci('Scegli il tuo uovo.')));

    var scelte = el('div', 'petq-uova');

    var robotBox = el('div', 'petq-uovo-box');
    var robotCanvas = document.createElement('canvas');
    robotCanvas.width = 64; robotCanvas.height = 64;
    robotCanvas.className = 'petq-uovo-canvas';
    disegnaUovo(robotCanvas, 'robot');
    robotBox.appendChild(robotCanvas);
    robotBox.appendChild(el('div', 'petq-uovo-label', traduci('Robot')));
    robotBox.addEventListener('click', function () { sceglieUovo('robot'); });

    var alienoBox = el('div', 'petq-uovo-box');
    var alienoCanvas = document.createElement('canvas');
    alienoCanvas.width = 64; alienoCanvas.height = 64;
    alienoCanvas.className = 'petq-uovo-canvas';
    disegnaUovo(alienoCanvas, 'alieno');
    alienoBox.appendChild(alienoCanvas);
    alienoBox.appendChild(el('div', 'petq-uovo-label', traduci('Alieno')));
    alienoBox.addEventListener('click', function () { sceglieUovo('alieno'); });

    scelte.appendChild(robotBox);
    scelte.appendChild(alienoBox);
    wrap.appendChild(scelte);

    app.appendChild(wrap);
    montaDebugPanel();
  }

  /* fase (opzionale, sequenza di schiusa Round 5): 0/assente = integro (comportamento di
   * sempre), 1 = prima crepa (lo zigzag corto dall'apice), 2 = frattura drammatica — tronco
   * largo fino in fondo, quattro rami, scheggione saltato e la LUCE che preme da dentro.
   * La luce e' IDENTICA per uova normali e leggendarie (vincolo sacro: il rito non spoilera).
   * Arte approvata dal fondatore in anteprima (14 ago 2026, "crepa 2 piu' drammatica"). */
  function disegnaUovo(canvas, razza, fase) {
    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);

    if (razza === 'robot') {
      g.fillStyle = '#8a949c';
      ovale(g, 32, 34, 22, 28);
      g.fillStyle = '#c6cfd6';
      ovale(g, 32, 32, 18, 23);
      g.fillStyle = '#5a646c';
      var rivetti = [[20, 20], [44, 20], [20, 46], [44, 46], [32, 14]];
      for (var i = 0; i < rivetti.length; i++) {
        g.beginPath();
        g.arc(rivetti[i][0], rivetti[i][1], 2, 0, Math.PI * 2);
        g.fill();
      }
    } else {
      g.fillStyle = '#2d4a38';
      ovale(g, 32, 34, 22, 28);
      g.fillStyle = '#7fd8a4';
      ovale(g, 32, 32, 18, 23);
      g.fillStyle = '#f09bb0';
      var macchie = [[24, 24], [40, 30], [28, 42], [38, 46]];
      for (var j = 0; j < macchie.length; j++) {
        g.beginPath();
        g.arc(macchie[j][0], macchie[j][1], 3, 0, Math.PI * 2);
        g.fill();
      }
    }

    if (fase >= 1) disegnaCrepaUovo(g, razza, fase);
  }

  // Le due crepe della schiusa: fulmine spezzato a tratti di 2-3px, gomiti SFALSATI (mai
  // simmetrica: e' rotta, non disegnata). Colore del guscio in ombra per razza; la luce e'
  // la stessa crema per tutti.
  function disegnaCrepaUovo(g, razza, fase) {
    var colore = (razza === 'robot') ? '#3a4048' : '#1f3a2a';
    var luce = '#fff8c8';

    g.fillStyle = colore;
    g.fillRect(31, 10, 2, 4); g.fillRect(33, 13, 2, 3); g.fillRect(30, 15, 3, 2);
    g.fillRect(29, 17, 2, 4); g.fillRect(31, 20, 2, 3);
    if (fase < 2) return;

    // tronco largo che arriva quasi in fondo
    g.fillRect(30, 22, 3, 5); g.fillRect(33, 26, 3, 5); g.fillRect(29, 30, 3, 5);
    g.fillRect(32, 34, 3, 5); g.fillRect(30, 38, 3, 5); g.fillRect(32, 42, 2, 5);
    // quattro rami
    g.fillRect(27, 18, 2, 2); g.fillRect(25, 20, 2, 2); g.fillRect(23, 22, 2, 3); g.fillRect(22, 25, 1, 3);
    g.fillRect(35, 27, 2, 2); g.fillRect(37, 29, 2, 2); g.fillRect(39, 31, 2, 3);
    g.fillRect(28, 35, 2, 2); g.fillRect(26, 37, 2, 3);
    g.fillRect(36, 40, 2, 2); g.fillRect(38, 42, 2, 2);
    // scheggione gia' saltato via
    g.fillRect(41, 24, 4, 3);
    // la luce che preme da dentro
    g.fillStyle = luce;
    g.fillRect(31, 23, 2, 4); g.fillRect(34, 28, 2, 4); g.fillRect(30, 32, 2, 3);
    g.fillRect(33, 36, 2, 4); g.fillRect(31, 40, 2, 3);
    g.fillRect(42, 25, 2, 1); g.fillRect(26, 21, 1, 2);
  }

  function ovale(g, cx, cy, rx, ry) {
    g.beginPath();
    g.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    g.fill();
  }

  // ==================== SEQUENZA DI SCHIUSA (Round 5, ~4s, non skippabile) ====================
  // Cerimonia PRIMA di mostrare il pet: wobble leggero -> crepa 1 (suono) -> wobble piu' forte ->
  // crepa 2 (suono) -> wobble breve -> STOP totale (suspense) -> FLASH bianco + suono -> poi().
  // Riceve SOLO la razza (mai il pet): il rito e' IDENTICO per uova normali e leggendarie per
  // costruzione, non deve poter spoilerare nulla. Timeline (numeri del fondatore, non miei):
  // 0-1,2s / 1,2-2,4s / 2,4-3,0s / 3,0-3,5s / flash ~120ms a 3,5s / poi() a ~3,65s.
  //
  // Costruita SOLO con animaTimed (completamento a scadenza garantita, v. sopra): ogni fase
  // incatena la successiva dentro il proprio callback, cosi' se il tab va in background a meta'
  // cerimonia la sequenza salta avanti fino al punto giusto alla ripresa invece di restare
  // bloccata a meta'. Il wobble VERO E PROPRIO (l'oscillazione continua entro ogni fase) e'
  // realizzato con animazioni CSS (@keyframes petq-wobble-*, v. style.css — stessa formula
  // "angolo = sin(progress*3*2pi)*ampiezza" campionata a 12 punti per ciclo, animaTimed non offre
  // un tick per-frame): e' pura decorazione, se il tab si congela semplicemente non si vede
  // muoversi, ma il TIMING delle fasi (arrivare al flash e chiamare poi()) resta comunque
  // garantito da animaTimed, indipendente da cosa fa la CSS animation nel frattempo.
  //
  // MARCATORE wrap.id='petq-schiusa': impedisce al ciclo di render (tick 30s) di rimontare la
  // casa/il pianeta dei ritirati sopra la cerimonia — v. le guardie aggiunte in
  // controllaEvoluzioneScaduta/controllaCartaPendente/controllaPortaPendente/
  // controllaEventoValigia/controllaRisveglioPendente e il ramo casaVuotaPensione di render().
  // Non skippabile: nessun listener di input installato su questa schermata.
  // Guardia doppio tap (bug trovato in collaudo v277): due tap ravvicinati sull'uovo generavano
  // DUE pet con DUE cerimonie in corsa — e siccome la leggenda si decide alla generazione, il
  // secondo tap poteva sovrascrivere una leggenda mai vista. I listener restano vivi anche sui
  // nodi staccati dal DOM, quindi non basta che la schermata dell'intro sia stata smontata.
  var schiusaInCorsa = false;

  function sequenzaSchiusa(razza, poi) {
    schiusaInCorsa = true;
    fermaIdle();
    puliziaEffetto();

    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-schiusa-schermo');
    wrap.id = 'petq-schiusa';

    var canvas = document.createElement('canvas');
    canvas.width = 64; canvas.height = 64;
    canvas.className = 'petq-uovo-schiusa';
    disegnaUovo(canvas, razza, 0);
    wrap.appendChild(canvas);

    app.appendChild(wrap);

    // Stesso interruttore usato dalle animazioni di stanza (avviaLavaggio/avviaScrittura...):
    // finche' e' true, render() salta il quartetto di controlla* che potrebbe rimontare una
    // schermata a tutto schermo sopra la cerimonia (v. render() sotto).
    animazioneInCorso = true;

    function suona(nome) {
      if (PETQ.audio && PETQ.audio.suona) PETQ.audio.suona(nome);
    }

    canvas.classList.add('petq-wobble-lieve');
    animaTimed(1200, function () {
      canvas.classList.remove('petq-wobble-lieve');
      disegnaUovo(canvas, razza, 1);
      suona('uovoTic');

      canvas.classList.add('petq-wobble-forte');
      animaTimed(1200, function () {
        canvas.classList.remove('petq-wobble-forte');
        disegnaUovo(canvas, razza, 2);
        suona('uovoTic');

        canvas.classList.add('petq-wobble-breve');
        animaTimed(600, function () {
          canvas.classList.remove('petq-wobble-breve');

          // 3,0 -> 3,5s: STOP TOTALE, nessun suono (la suspense prima della schiusa vera).
          animaTimed(500, function () {
            var flash = el('div', 'petq-schiusa-flash');
            app.appendChild(flash);
            suona('uovoSchiusa');

            animaTimed(130, function () {
              if (flash.parentNode) flash.parentNode.removeChild(flash);
              animazioneInCorso = false;
              schiusaInCorsa = false;
              if (typeof poi === 'function') poi();
            });
          });
        });
      });
    });
  }

  function sceglieUovo(razza) {
    if (schiusaInCorsa) return; // doppio tap: la prima cerimonia e' gia' partita
    // currentState e' quasi certamente null qui (primissimo pet della partita, nessuna casa
    // ancora): passato comunque per uniformita' con nuovoPetInCasa sotto, PETQ.pet.generate e'
    // difensivo su state mancante (v. commento li'). Il pet si genera SUBITO (PETQ.pet.generate
    // decide in segreto se e' leggenda): la cerimonia sotto vede solo la razza scelta, mai il
    // risultato, cosi' il rito non spoilera nulla — v. sequenzaSchiusa sopra.
    var pet = PETQ.pet.generate(razza, currentState);
    sequenzaSchiusa(razza, function () { mostraNascita(pet); });
  }

  // ==================== NASCITA ====================

  function mostraNascita(pet, finalizer) {
    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-nascita');
    wrap.appendChild(el('h1', 'petq-title', traduci('È nato!')));

    // Leggende (Round 5, "primo incontro"): leggendeSbloccate (v. pet.js mandaInPensione) e' il
    // POOL da cui si estrae la leggenda alla schiusa — NON e' la stessa cosa di "gia' incontrata
    // una volta": lo stesso personaggio puo' uscire di nuovo da una run futura. leggendeIncontrate
    // (nuovo campo, v. save.js/statoDiPartenza/LISTA_BIANCA_CASA) e' la memoria dedicata al primo
    // incontro, persistente come leggendeSbloccate.
    //
    // currentState puo' essere null qui SOLO al primissimo uovo della partita (v. sceglieUovo): in
    // quel caso una leggenda e' comunque impossibile per costruzione (leggendeSbloccate parte
    // sempre vuoto, nessuna Grande Impresa ancora vinta). C'E' PERO' un secondo caso, trovato
    // verificando il bottone debug "Schiudi leggenda (test)" (montaDebugPanel): a partita mai
    // iniziata quel bottone arma il tiro forzato su un currentState = {} MINIMO SOLO IN MEMORIA
    // (non un salvataggio vero: niente pet/coins/arredi, e non lo salva apposta — v. commento li').
    // Un `if (currentState)` nudo lo tratterebbe come "stato vero" e PETQ.save.save lo scriverebbe
    // per intero in localStorage, sovrascrivendo (finche' "Inizia" non chiama avviaPartita) un
    // salvataggio rotto. Il discriminante e' `version`: SOLO uno stato vero (statoDiPartenza qui
    // sotto, o un salvataggio caricato da PETQ.save.load) lo ha; il contenitore minimo del debug no.
    // In entrambi i casi limite il ramo difensivo tratta l'incontro come "primo per definizione"
    // (mostra comunque cartello+fanfara) senza poterlo registrare da nessuna parte pulita.
    var eLeggenda = !!(pet && pet.razza === 'leggenda' && pet.leggendaId);
    var statoVero = !!(currentState && typeof currentState.version === 'number');
    var primoIncontro = false;
    if (eLeggenda) {
      if (statoVero) {
        if (!Array.isArray(currentState.leggendeIncontrate)) currentState.leggendeIncontrate = [];
        primoIncontro = currentState.leggendeIncontrate.indexOf(pet.leggendaId) === -1;
        if (primoIncontro) {
          currentState.leggendeIncontrate.push(pet.leggendaId);
          if (PETQ.save && PETQ.save.save) PETQ.save.save(currentState);
        }
      } else {
        primoIncontro = true; // difensivo, v. commento sopra: casa nuova o contenitore debug minimo
      }
    }

    if (PETQ.audio && PETQ.audio.suona) {
      PETQ.audio.suona((eLeggenda && primoIncontro) ? 'leggenda' : 'nascita');
    }

    // Cartello leggenda (decisione fondatore): SOLO al primo incontro, sopra il pet. Il nome del
    // personaggio si legge da PETQ.pet._leggendeInfo (leggendaId -> nome), STESSA fonte gia'
    // usata dal ciclatore debug "Schiudi leggenda (test)" (v. montaDebugPanel) — mai un secondo
    // dizionario scritto a mano. Nome PROPRIO: niente traduci() (stessa regola dei nomi cibo/
    // arredo/pet, v. CLAUDE.md "Lingue").
    if (eLeggenda && primoIncontro) {
      var infoLeg = (PETQ.pet && PETQ.pet._leggendeInfo) || {};
      var nomeLeg = (infoLeg[pet.leggendaId] && infoLeg[pet.leggendaId].nome) || pet.nome || '';
      var cartello = el('div', 'petq-cartello-leggenda');
      cartello.appendChild(el('div', 'petq-cartello-leggenda-tag', traduci('LEGGENDA!')));
      cartello.appendChild(el('div', 'petq-cartello-leggenda-nome', nomeLeg.toUpperCase()));
      wrap.appendChild(cartello);
    }

    var canvas = document.createElement('canvas');
    canvas.width = PET_SIZE * 6; canvas.height = PET_SIZE * 6;
    canvas.className = 'petq-sprite-grande';
    PETQ.sprites.draw(canvas, pet, {});
    wrap.appendChild(canvas);

    // Saltello d'ingresso (~350ms): il canvas parte 8px piu' in basso e si assesta con un piccolo
    // rimbalzo (cubic-bezier con overshoot = il "salto"). Qui mettiamo SOLO la posizione di
    // partenza (il canvas e' ancora dentro un `wrap` non ancora attaccato al DOM vivo: `app.
    // appendChild(wrap)` arriva solo in fondo alla funzione) — il vero e proprio innesco della
    // transizione (reflow + bersaglio) va fatto DOPO l'attach reale, altrimenti il browser
    // applicherebbe gia' translateY(0) al primo paint e non ci sarebbe nessuna transizione visibile
    // (v. blocco identico in fondo alla funzione).
    canvas.classList.add('petq-nascita-salto');
    canvas.style.transform = 'translateY(8px)';

    wrap.appendChild(el('div', 'petq-personalita', traduci(capitalize(pet.personalita))));

    // Cartellino "colore raro" (GDD "tiro di nascita" 24 ago 2026): SOLO se il tiro di nascita
    // ha pescato uno speciale (indici 3-7) e SOLO sui pet normali (le leggende hanno palette
    // fissa: parts.colore li' non conta, un cartellino mentirebbe). Sobrio di proposito: la
    // cerimonia grossa resta delle leggende.
    if (!eLeggenda && pet.parts && pet.parts.colore >= 3 && pet.parts.colore <= 7) {
      var vocePR = null;
      for (var iPR = 0; iPR < COLORI_PET.length; iPR++) {
        if (COLORI_PET[iPR].indice === pet.parts.colore) { vocePR = COLORI_PET[iPR]; break; }
      }
      if (vocePR) {
        wrap.appendChild(el('div', 'petq-nascita-colore-raro',
          '✨ ' + traduci('Colore raro: ') + traduci(vocePR.nome) + '!'));
      }
    }

    // Talento di nascita (PROTOTIPO 2): icona + nome del talento del cucciolo. Come per
    // l'annuncio di evoluzione (fix P3): si mostra SEMPRE se il talento esiste — icona se
    // disegnata in badges.js, altrimenti pallino colorato per rarita' (pattern della scheda).
    var talNascita = (pet.talenti && pet.talenti.length) ? pet.talenti[0] : null;
    if (talNascita) {
      var boxNasc = el('div', 'petq-nascita-talento');
      if (PETQ.badges && PETQ.badges.haTalento && PETQ.badges.haTalento(talNascita.nome)) {
        var icoN = document.createElement('canvas');
        icoN.width = 84; icoN.height = 84; icoN.className = 'petq-talento-icona';
        PETQ.badges.disegnaTalento(icoN, talNascita.nome, talNascita.raro);
        boxNasc.appendChild(icoN);
      } else {
        boxNasc.appendChild(el('span', 'petq-talento-pallino ' + (talNascita.raro ? 'petq-talento-raro' : 'petq-talento-normale')));
      }
      boxNasc.appendChild(el('div', 'petq-nascita-talento-nome', traduci('Talento: ') + traduci(talNascita.nome)));
      wrap.appendChild(boxNasc);
    }

    var stats = el('div', 'petq-stats-grid');
    var voci = [
      [traduci('Forza'), pet.rpg.forza], [traduci('Intelligenza'), pet.rpg.intelligenza],
      [traduci('Velocità'), pet.rpg.velocita], [traduci('Carisma'), pet.rpg.carisma]
    ];
    for (var i = 0; i < voci.length; i++) {
      var riga = el('div', 'petq-stat-riga');
      riga.appendChild(el('span', 'petq-stat-nome', voci[i][0]));
      riga.appendChild(el('span', 'petq-stat-val', String(voci[i][1])));
      stats.appendChild(riga);
    }
    wrap.appendChild(stats);

    var form = el('div', 'petq-form-nome');
    form.appendChild(el('label', 'petq-label', traduci('Dagli un nome (max 12 caratteri)')));
    var input = document.createElement('input');
    input.type = 'text';
    input.maxLength = 12;
    input.className = 'petq-input';
    input.placeholder = traduci('Nome...');
    // Leggende (P3 batch 6): pet.nome arriva gia' valorizzato col nome del personaggio (v.
    // pet.js generate) — lo pre-riempiamo qui, ma resta un input NORMALE: modificabile o
    // cancellabile a piacere, obbligatorio alla conferma esattamente come per un pet normale
    // (che invece arriva con nome:null -> input vuoto, comportamento invariato).
    input.value = pet.nome || '';
    form.appendChild(input);

    var errore = el('div', 'petq-errore', '');
    form.appendChild(errore);

    var bottone = el('button', 'petq-btn petq-btn-primario', traduci('Inizia'));
    bottone.addEventListener('click', function () {
      var nome = input.value.trim();
      if (nome === '') {
        errore.textContent = traduci('Il nome è obbligatorio.');
        return;
      }
      pet.nome = nome.substring(0, 12);
      // finalizer opzionale: il pet da PENSIONE tiene la casa (v. nuovoPetInCasa/finalizzaNuovoPetInCasa);
      // default (primo pet) = nuova partita completa via avviaPartita.
      if (typeof finalizer === 'function') finalizer(pet);
      else avviaPartita(pet);
    });
    form.appendChild(bottone);

    wrap.appendChild(form);
    app.appendChild(wrap);

    // Ora il canvas e' DAVVERO nel DOM (v. commento sopra): forziamo il reflow cosi' il browser
    // registra la posizione di partenza (translateY(8px)) prima di assegnare il bersaglio, poi la
    // transizione CSS di .petq-nascita-salto fa il resto. animaTimed solo per il timing/la pulizia
    // finale (v. contratto sopra): e' pura decorazione, nessun altro passo dipende dal completamento.
    void canvas.offsetHeight;
    canvas.style.transform = 'translateY(0)';
    animaTimed(350, function () {
      canvas.classList.remove('petq-nascita-salto');
      canvas.style.transform = '';
    });
  }

  function capitalize(s) {
    if (!s) return '';
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  // Stato "nuova partita": TUTTI i campi con cui una casa mai esistita prima parte. Estratto in
  // funzione propria (usata sia da avviaPartita subito sotto sia da finalizzaNuovoPetInCasa piu'
  // in basso) cosi' esiste UNA SOLA definizione di "stato fresco": le due strade (partita mai
  // iniziata / pet nuovo dopo un ritiro) non possono piu' divergere in silenzio. `pet` di default
  // e' null: finalizzaNuovoPetInCasa lo installa a parte, dopo aver applicato la lista bianca dei
  // campi della CASA (v. li').
  function statoDiPartenza(pet) {
    pet = pet || null;
    var bil = bilanciamento();
    var monete = (bil.economia && typeof bil.economia.monetePartenza === 'number') ? bil.economia.monetePartenza : 50;

    return {
      version: 1,
      pet: pet,
      coins: monete,
      poop: 0,
      lastSeen: Date.now(),
      // Nuovo pet: giorno di gioco 0, lastLoginDay 0 -> nessun login immediato; il primo
      // mezzanotte di gioco (giornoGioco -> 1) fara' scattare il "nuovo giorno" (v. care.dailyLogin).
      giornoGioco: 0,
      lastLoginDay: 0,
      arredi: { posseduti: [], piazzati: { cucina: [], bagno: [], salone: [], camera: [] } },
      parole: [],
      missione: null,
      missioniFatte: {},
      // Rotazione random missioni per run (P3, missions.js ROTAZIONE_PER_STADIO): mappa per
      // stadio, vive e muore col pet ESATTAMENTE come missioniFatte sopra. Nuova partita: nessun
      // sottoinsieme ancora estratto (lazy init alla prima rosaDelGiorno dello stadio interessato).
      rotazioneMissioni: {},
      // Impresa della run (P3, Grandi Imprese, missions.js impresaDellaRun): id-scheda estratto
      // per QUESTO pet, vive e muore col pet ESATTAMENTE come missioniFatte/rotazioneMissioni
      // sopra. Nuova partita: nessuna estrazione ancora fatta (lazy init quando il pet diventa
      // adulto).
      impresaRun: null,
      ferite: 0,
      cureOggi: 0,
      // Inventario/frigo (GDD "Economia" -> "Spesa e dispensa"): array di {nome, qty}. NON piu'
      // vuoto (decisione fondatore, analisi "il giocatore nuovo puo' perdere il pet prima di
      // capire come si gioca"): prima del tutorial M0 il negozio e' CHIUSO (negozioSbloccato=
      // false, v. sotto) e un giocatore che chiude l'app subito dopo aver dato il nome — il
      // comportamento piu' comune al primo avvio — al rientro trova Fame/Igiene/Felicita' a ZERO
      // (decadimento offline cappato 12h, v. clock.js CAP_ORE; misurato col motore vero: 6h ->
      // fame 34/igiene 22/felicita' 28, 8h -> 22/6/14, 12h -> tutto a 0) SENZA alcun modo di
      // rimediare, perche' l'unica via d'uscita e' un tutorial che non ha ancora trovato.
      // RETE DI SICUREZZA (non un regalo: stessa quantita' del regalo del tutorial, v. sotto):
      // 3x 'Crocchette semplici' — il cibo base del negozio (5 monete, +25 Fame, NESSUN effetto
      // negativo, v. content/cibi.md). Conto su Fame partita da 0 (caso peggiore, cap 12h):
      // +25*3 = +75, ben sopra la soglia critica 25 (bilanciamento.md "Soglie"); simulato ORA PER
      // ORA col motore vero (pet.applyDecay, -6 Fame/ora): restano ~9h di margine prima che la
      // Fame torni sotto 25 e ~13h prima che torni a 0 — tempo per trovare il pin Negozio/
      // tutorial sulla mappa. Igiene NON serve un cibo apposito: care.wash() e' SEMPRE gratuito
      // (non consuma dispensa) e la riporta a 100 con un tap. Quantita' voluta uguale a
      // TUTORIAL_CROCCHETTE_QTY (missions.js): se il giocatore arriva al tutorial con
      // scorta ancora intera, i due regali si sommano ma restano nello stesso ordine di
      // grandezza (mai un doppio rifornimento sproporzionato).
      dispensa: [{ nome: 'Crocchette semplici', qty: 3 }],
      categoriePastiOggi: [],
      // Pacing stat RPG (bilanciamento.md): contatore dei 2 pasti-con-stat/giorno (v. care.feed).
      pastiStatOggi: 0,
      tutorialFatto: false,
      // Negozio unico (GDD "Economia" -> "Spesa e dispensa"): il pin Negozio (m0) sblocca il
      // menu acquisto SOLO dopo il tutorial. Finche' e' false, tap su m0 = tutorial.
      negozioSbloccato: false,
      sonno: null,
      // Valigia / partenza (PROTOTIPO 2, Blocco 2): contatori trigger, fase valigia, pet partito
      // ed evento per la UI. Partono azzerati/null (v. pet.js valutaValigiaNuovoGiorno).
      valigiaTrig: { fel: 0, sal: 0, doppio: 0 },
      valigia: null,
      petPartito: null,
      // Lettera dal pianeta (Blocco 4): assemblata una volta quando il pet e' partito e mostrata
      // stabile finche' e' via ({ personalita, righe }). Azzerata al recupero (eseguiAmmenda).
      letteraPartito: null,
      eventoValigia: null,
      // Pensione (PROTOTIPO 2, versione base P2): array degli snapshot dei pet ritirati (galleria
      // "pianeta dei ritirati" + eredita' ai pet futuri). Nuova partita: nessun pensionato.
      pensionati: [],
      // Perk CASA (P3, Grandi Imprese): id delle imprese risolte in SUPER + mandate in pensione
      // (es. 'm65'), PERSISTENTE ATTRAVERSO LE RUN — non si azzera MAI al cambio pet (v. pet.js
      // mandaInPensione/talenti.js sezione PERK CASA per gli effetti; finalizzaNuovoPetInCasa
      // sotto NON lo tocca). Nuova partita (household mai esistito prima): parte vuoto, non e' un
      // "reset" di qualcosa che c'era.
      perkCasa: [],
      // Leggende sbloccate (P3): STESSO ciclo di vita persistente di perkCasa, NASCOSTO (nessuna
      // UI): serve solo al futuro uovo leggendario (10% pet unico giocabile).
      leggendeSbloccate: [],
      // Leggende INCONTRATE (Round 5, sequenza di schiusa): id delle leggende gia' schiuse almeno
      // una volta, STESSO ciclo di vita persistente di leggendeSbloccate/perkCasa — a differenza
      // di leggendeSbloccate (il pool da cui SI PESCA, puo' ripetersi) questa e' la memoria "l'hai
      // gia' vista" che decide se mostrare il cartello + la fanfara al reveal (v. mostraNascita).
      leggendeIncontrate: [],
      // Popup una-tantum del Supporter Pack (ago 2026): mostrato UNA sola volta nella vita del
      // salvataggio, al giorno 3 (v. ui.js controllaPopupSostieni), MAI se il Supporter e' gia'
      // attivo. Nuova partita: non ancora visto. STESSO ciclo di vita persistente di
      // leggendeIncontrate — una-tantum ASSOLUTA, sopravvive anche al ribaltamento casa (v.
      // LISTA_BIANCA_CASA sotto): un pet nuovo nella stessa casa non deve rivedere una promo a cui
      // ha gia' risposto.
      popupSostieniVisto: false,
      // Perk = MEDAGLIETTE (decisione fondatore, bilanciamento.md "Perk = MEDAGLIETTE"): badge
      // permanenti ottenuti dalle missioni (reward perk:<nome>), sempre attivi. PER-PET: un pet
      // nuovo riparte senza medaglie (coerente con casa fresca; i pensionati tengono le loro nello
      // snapshot). Nuova partita: nessuna medaglia.
      perks: [],
      // Indossabili (PROTOTIPO 2): vestiti posseduti + quello indossato (slot singolo). PER-PET
      // come le medaglie: un pet nuovo riparte senza vestiti. Nuova partita: nessun vestito.
      indossabili: [],
      indossato: null,
      // Armeria (FASE SPRITE): arma impugnata (slot singolo come indossato). Le armi sono arredi
      // normali (state.arredi); l'equip e' gated dal perk Weapon Wielder nell'UI. Nuova partita: nessuna.
      armaEquip: null,
      // Pianta Esotica (arredo stat_random_giornaliera): stat RPG boostata oggi (null finche' la
      // Pianta non e' piazzata). Ri-estratta ad ogni nuovo giorno (v. care.dailyLogin).
      piantaEsoticaStat: null,
      // Ingrandimento casa (GDD "Slot arredo, tetto passivo e Ingrandimento casa"): upgrade shop
      // globale (200 monete). Nuova partita: non ancora comprato.
      ingrandimentoCasa: false,
      // Colori (varianti cromatiche, v. COLORI_PET/coloreDisponibile sopra): i due a monete non
      // ancora comprati, niente Supporter Pack. Nuova partita: solo i 3 colori base disponibili.
      coloriSbloccati: [],
      supporter: false
    };
  }

  function avviaPartita(pet) {
    var state = statoDiPartenza(pet);
    // orologio di gioco: parte dall'ora REALE corrente (stessa regola di migrazione dei
    // salvataggi esistenti, v. clock.js inizializzaOrologio), cosi' anche una partita nuova
    // iniziata di sera parte gia' vicina alla notte di gioco.
    if (PETQ.clock && PETQ.clock.inizializzaOrologio) PETQ.clock.inizializzaOrologio(state);

    PETQ.save.save(state);
    PETQ.main.avviaTicking(state);
    currentState = state;
    mostraCasa(state);
  }

  // ==================== CASA ====================

  function mostraCasa(state) {
    fermaIdle();
    puliziaEffetto();
    currentState = state;
    currentStanza = 'cucina';
    collezioneAperta = false;
    frigoAperto = false;
    negozioSelezionato = null;
    missioneSelezionata = null;
    mapPointer = null;

    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-casa');
    wrap.id = 'petq-casa';

    var hud = el('div', 'petq-hud');
    hud.id = 'petq-hud';
    wrap.appendChild(hud);

    var tabs = el('div', 'petq-tabs');
    // PROTOTIPO 2, Blocco 7 — il NEGOZIO non e' piu' una tab della casa: la compravendita di
    // arredi vive DENTRO il negozio vero (pin sulla mappa, sezioni Cibo/Arredi/Vendi in
    // pannelloShop). Le tab casa tornano Cucina/Bagno/Salone/Camera/Missioni.
    var stanze = [['cucina', 'Cucina'], ['bagno', 'Bagno'], ['salone', 'Salone'], ['camera', 'Camera'], ['missioni', 'Missioni']];
    for (var i = 0; i < stanze.length; i++) {
      (function (chiave, label) {
        var tab = el('button', 'petq-tab', traduci(label));
        tab.dataset.stanza = chiave;
        tab.addEventListener('click', function () {
          controllaAnimScaduta();
          if (animazioneInCorso) return;
          annullaIdleAction();
          currentStanza = chiave;
          // Reset della guardia "centra una volta per apertura tab" (v. centraSuMissioniDelGiorno
          // piu' sotto, tab Missioni): ogni cambio tab e' una nuova apertura, quindi il prossimo
          // ingresso in Missioni deve poter ricentrare la mappa da capo. Azzerata qui a prescindere
          // dalla tab di destinazione (costa nulla e tiene la guardia sempre coerente).
          missioniMappaCentrata = false;
          // Reset della vista mappa (v. mappaVistaCitta sopra, richiesta fondatore 28 lug 2026):
          // e' una preferenza di sessione, non di gioco — ogni cambio tab riporta la tab Missioni
          // alla vista quartiere compatta, quella utile per giocare, cosi' il giocatore non resta
          // bloccato sull'atlante intero senza essersene reso conto.
          mappaVistaCitta = false;
          aggiornaModalitaHud();
          renderStanza();
        });
        tabs.appendChild(tab);
      })(stanze[i][0], stanze[i][1]);
    }
    wrap.appendChild(tabs);

    var stanzaArea = el('div', 'petq-stanza-area');
    var canvasWrap = el('div', 'petq-canvas-wrap');
    var canvas = document.createElement('canvas');
    // altezza corrente della stanza (64 normale, 80 con Ingrandimento casa): il canvas della
    // stanza cresce in altezza; la larghezza resta ROOM_W. Le hotzone (in %) usano lo stesso
    // denominatore, cosi' restano allineate al disegno (il mobile e' disegnato a coord y fisse
    // nella stanza alta altStanza, quindi la % = coordY / altStanza).
    var altStanza = (PETQ.rooms && PETQ.rooms.altezzaStanza) ? PETQ.rooms.altezzaStanza(state) : ROOM_H;
    canvas.width = ROOM_W;
    canvas.height = altStanza;
    // Proporzioni inline sull'altezza CORRENTE: senza questa riga vale l'aspect-ratio del CSS,
    // che essendo un numero fisso schiaccia il disegno quando la stanza cambia altezza (e' successo
    // passando la stanza da 112x64 a 112x96: il riquadro restava alto uguale e la scena veniva
    // compressa). Stesso trattamento gia' usato per il canvas della mappa.
    canvas.style.aspectRatio = ROOM_W + ' / ' + altStanza;
    canvas.id = 'petq-canvas-stanza';
    canvas.className = 'petq-canvas-stanza';
    canvasWrap.appendChild(canvas);

    // hotzone vasca: evidenziata durante il drag del pet nel bagno
    var hotzone = el('div', 'petq-hotzone');
    hotzone.id = 'petq-hotzone';
    hotzone.style.left = (HOTZONE_VASCA.x / ROOM_W * 100) + '%';
    hotzone.style.top = (HOTZONE_VASCA.y / altStanza * 100) + '%';
    hotzone.style.width = (HOTZONE_VASCA.w / ROOM_W * 100) + '%';
    hotzone.style.height = (HOTZONE_VASCA.h / altStanza * 100) + '%';
    canvasWrap.appendChild(hotzone);

    // hotzone letto: evidenziata durante il drag del pet in camera (stesso pattern vasca).
    // NON e' un punto di DISEGNO stanza (resta su temaRazza apposta, v. report skin stanze):
    // rooms.js._letto/_frigoZona espongono il rettangolo letto/frigo SOLO per lab/ship (le sette
    // skin nuove non hanno una voce propria), quindi passare temaStanzaCorrente qui non
    // migliorerebbe nulla — cadrebbe sul rettangolo di ripiego generico di hotzoneLetto/Frigo,
    // che non e' piu' preciso del rettangolo lab/ship gia' corretto per la razza vera del pet.
    var hzLetto = hotzoneLetto(temaRazza(state.pet));
    var hotzoneL = el('div', 'petq-hotzone');
    hotzoneL.id = 'petq-hotzone-letto';
    hotzoneL.style.left = (hzLetto.x / ROOM_W * 100) + '%';
    hotzoneL.style.top = (hzLetto.y / altStanza * 100) + '%';
    hotzoneL.style.width = (hzLetto.w / ROOM_W * 100) + '%';
    hotzoneL.style.height = (hzLetto.h / altStanza * 100) + '%';
    canvasWrap.appendChild(hotzoneL);

    // indicatore "torna tra X" quando il pet è in missione
    var indicatore = el('div', 'petq-missione-ind');
    indicatore.id = 'petq-missione-ind';
    indicatore.style.display = 'none';
    canvasWrap.appendChild(indicatore);

    var balloon = el('div', 'petq-balloon');
    balloon.id = 'petq-balloon';
    balloon.style.display = 'none';
    canvasWrap.appendChild(balloon);

    stanzaArea.appendChild(canvasWrap);
    wrap.appendChild(stanzaArea);

    var azioni = el('div', 'petq-azioni');
    azioni.id = 'petq-azioni';
    wrap.appendChild(azioni);

    // Fascia di stato (misurazione fondatore su 412x915: sotto le azioni restava un buco vuoto
    // enorme — 34/36% dello schermo in Cucina/Camera — perche' il contenuto della casa finiva
    // a y=608 su 915 disponibili). Blocco fisso appeso DOPO le azioni, in TUTTE le stanze:
    // riempito/aggiornato da aggiornaFasciaStato (v. sotto, chiamata da aggiornaHud a ogni tick
    // e a ogni renderStanza, cosi' non serve un setInterval dedicato).
    var fascia = el('div', 'petq-stato-fascia');
    fascia.id = 'petq-stato-fascia';
    wrap.appendChild(fascia);

    app.appendChild(wrap);

    installaPointerCanvas(canvas);

    montaDebugPanel();
    renderStanza();
    avviaIdle();
  }

  function renderStanza() {
    if (!currentState) return;
    aggiornaTabsAttive();
    aggiornaHud(currentState);

    // la tab Missioni e' una schermata-menu: l'area stanza (canvas) resta nascosta
    var soloMenu = (currentStanza === 'missioni');
    var area = document.querySelector('.petq-stanza-area');
    if (area) area.style.display = soloMenu ? 'none' : '';

    if (!soloMenu) disegnaStanzaEPet(currentState);
    renderAzioni();
    // Set silenzioso (brief regia round 4): col pannello debug attivo il pet non parla DA SOLO,
    // recita solo su cue. E' questa la chiamata che si intromette sopra il ciak — parte ad ogni
    // ridisegno della stanza, quindi anche ad ogni battito dell'orologio. La battuta della
    // coccola non passa di qui: quella la chiede il giocatore, ed e' roba da filmare.
    if (!soloMenu && !currentState.missione && !(debugAttivo() && setSilenzioso)) battutaAutomatica();
  }

  function aggiornaTabsAttive() {
    var tabs = document.querySelectorAll('.petq-tab');
    for (var i = 0; i < tabs.length; i++) {
      if (tabs[i].dataset.stanza === currentStanza) {
        tabs[i].classList.add('petq-tab-attiva');
      } else {
        tabs[i].classList.remove('petq-tab-attiva');
      }
    }
  }

  function aggiornaHud(state) {
    var hud = document.getElementById('petq-hud');
    if (!hud || !state || !state.pet) return;
    hud.innerHTML = '';

    hud.appendChild(costruisciOrologioHud(state));

    var barre = [
      [traduci('Fame'), state.pet.stats.fame],
      [traduci('Igiene'), state.pet.stats.igiene],
      [traduci('Salute'), state.pet.stats.salute],
      [traduci('Felicità'), state.pet.stats.felicita],
      [traduci('Energia'), state.pet.stats.energia]
    ];

    for (var i = 0; i < barre.length; i++) {
      var val = Math.round(barre[i][1]);
      var riga = el('div', 'petq-barra-riga');
      riga.appendChild(el('span', 'petq-barra-label', barre[i][0]));
      var traccia = el('div', 'petq-barra-traccia');
      var fill = el('div', 'petq-barra-fill ' + coloreBarra(val));
      fill.style.width = val + '%';
      traccia.appendChild(fill);
      riga.appendChild(traccia);
      riga.appendChild(el('span', 'petq-barra-val', String(val)));
      hud.appendChild(riga);
    }

    // riga compatta stat RPG: icona prop + valore (+ bonus arredi in accento)
    var chips = el('div', 'petq-rpg-chips');
    for (var c = 0; c < PROPS_ALLENAMENTO.length; c++) {
      var prop = PROPS_ALLENAMENTO[c];
      var chip = el('span', 'petq-rpg-chip');
      chip.title = traduci(prop.label);

      var iconaChip = document.createElement('canvas');
      iconaChip.width = 12;
      iconaChip.height = 12;
      iconaChip.className = 'petq-chip-icon';
      disegnaProp(iconaChip, prop.id);
      chip.appendChild(iconaChip);

      var sb = statConBonus(prop.stat);
      chip.appendChild(el('span', 'petq-chip-val', String(sb.base)));
      if (sb.bonus > 0) {
        var bonusEl = el('span', 'petq-chip-bonus', '(+' + sb.bonus + ')');
        bonusEl.title = traduci('bonus dagli arredi piazzati');
        chip.appendChild(bonusEl);
      }
      chips.appendChild(chip);
    }
    hud.appendChild(chips);

    // indicatore ferite discreto (visibile solo quando ce ne sono)
    if ((state.ferite || 0) > 0) {
      var fer = el('div', 'petq-ferite');
      fer.title = traduci('Ferite: guariscono col riposo o con una cura in bagno');
      var icona = el('span', 'petq-ferite-icona', '♥');
      fer.appendChild(icona);
      fer.appendChild(el('span', 'petq-ferite-num', String(Math.round(state.ferite))));
      hud.appendChild(fer);
    }

    // Riga monete + bottone Scheda (PROTOTIPO-2.md punto 3/Blocco 9, "priorita' alta, ben
    // visibile"): stessa riga, cosi' l'accesso e' sempre a portata di tap dall'HUD in
    // qualsiasi stanza, senza aggiungere una sesta tab dedicata.
    var rigaMonete = el('div', 'petq-riga-monete');
    // Monete e carica stanno insieme a SINISTRA in un gruppo loro: la riga e' space-between e
    // aggiungendo la carica come quarto figlio sciolto i bottoni si sarebbero sparpagliati.
    var gruppoSx = el('div', 'petq-riga-monete-sx');
    gruppoSx.appendChild(el('span', 'petq-monete', traduci('Monete: ') + state.coins));
    var carica = costruisciCaricaHud(state); // null finche' la serie non e' partita
    if (carica) gruppoSx.appendChild(carica);
    rigaMonete.appendChild(gruppoSx);
    var schedaBtn = el('button', 'petq-btn petq-btn-mini petq-btn-scheda', traduci('Scheda'));
    schedaBtn.addEventListener('click', function () { mostraScheda(currentState); });
    rigaMonete.appendChild(schedaBtn);
    var tastoAudio = costruisciTastoAudio(); // null se audio.js non e' caricato (v. guardia sopra)
    if (tastoAudio) rigaMonete.appendChild(tastoAudio);
    rigaMonete.appendChild(costruisciTastoLingua());
    hud.appendChild(rigaMonete);

    aggiornaModalitaHud();
    // Fascia di stato (v. sopra in mostraCasa + funzione sotto): aggiornata QUI perche'
    // aggiornaHud e' chiamata sia dal tick da 30s (render -> aggiornaHud) sia da ogni cambio
    // stanza/tab (renderStanza -> aggiornaHud) — stesso identico aggancio del resto dell'HUD,
    // nessun setInterval dedicato: il countdown scende da solo a ogni giro.
    aggiornaFasciaStato(state);
    controllaAvvisiStreak(state);
    // Qui e non in render(): aggiornaHud gira SOLO quando la casa e' davvero a schermo (l'HUD
    // esiste), quindi il fumetto non puo' finire sopra la scelta dell'uovo o una cartolina.
    // La funzione si auto-svuota, percio' e' innocua anche se l'HUD si ridisegna in continuazione.
    controllaRientroQuartaParete(state);
  }

  // HUD compatta nella tab Missioni (fix "mappa troppo in basso su mobile 412x915": canvas
  // mappa alto 874px CSS che comincia a y=335px sotto HUD+tab+hint, su un viewport da 915px se
  // ne vede meno di due terzi). Le 5 barre di benessere (.petq-barra-riga) non servono a
  // scegliere una destinazione e occupano ~110px preziosi, quindi le nascondiamo SOLO nella tab
  // Missioni via la classe CSS 'petq-hud-compatto' (v. style.css) — restano a un tap di distanza
  // tornando in una stanza qualsiasi o apendo la Scheda. Orologio+giorno, i chip RPG
  // (forza/intelligenza/velocita/carisma, servono a valutare una missione) e la riga
  // monete/scheda/lingua NON sono in .petq-barra-riga: restano sempre visibili. classList.add/
  // remove (non il toggle a due argomenti: inaffidabile sulle vecchie WebView Android, v. altri
  // usi di classList nel file) cosi' la classe e' sempre coerente con currentStanza.
  function aggiornaModalitaHud() {
    var hud = document.getElementById('petq-hud');
    if (!hud) return;
    if (currentStanza === 'missioni') hud.classList.add('petq-hud-compatto');
    else hud.classList.remove('petq-hud-compatto');
    // Fascia di stato: si mostra SOLO dove c'e' spazio da riempire, che e' il motivo per cui
    // esiste. Sta fuori da due schermate:
    //  - MISSIONI, dove #petq-azioni ospita la mappa che si prende da sola tutta l'altezza
    //    disponibile (v. adattaAltezzaMappa): aggiungerle sotto una fascia rimetterebbe in piedi
    //    il problema "mappa troppo in basso" appena risolto;
    //  - SALONE, che e' l'unica stanza gia' PIENA: ha la card allenamento e il gioco col
    //    giocattolo, e infatti era la sola con solo 98px di vuoto quando le altre ne avevano
    //    300. Misurato a 412x915 con la stanza profonda: con la fascia il Salone sfora di 106px
    //    e obbliga a scrollare, senza rientra. Le altre tre stanze restano dentro lo schermo.
    // Il meccanismo e' lo stesso della HUD compatta sopra (classe 'petq-hud-compatto').
    var fascia = document.getElementById('petq-stato-fascia');
    if (fascia) {
      var senzaFascia = (currentStanza === 'missioni' || currentStanza === 'salone');
      if (senzaFascia) fascia.classList.add('petq-hud-compatto');
      else fascia.classList.remove('petq-hud-compatto');
    }
  }

  // ---------- fascia di stato (richiesta fondatore: sotto le azioni restava un buco vuoto) ----------
  //
  // Riempie #petq-stato-fascia (v. mostraCasa) con la situazione PIU' IMPORTANTE in corso, una
  // sola alla volta, con priorita' fissa (la prima condizione che si applica vince, le altre non
  // si guardano nemmeno): missione in corso -> passeggiata -> allenamento -> sonno -> gioco ->
  // altrimenti (nessuna attivita', il caso piu' frequente) il riepilogo della giornata. Chiamata
  // da aggiornaHud (v. sopra) a ogni tick da 30s e a ogni cambio stanza: nessun setInterval
  // dedicato, il countdown scende da solo perche' PETQ.missions.tempoRimasto/minutiXRimasti
  // leggono l'orologio/i timestamp correnti a ogni chiamata.
  //
  // Pet partito o in fase valigia: quelle schermate hanno GIA' il loro flusso dedicato
  // (mostraPetPartito a schermo intero; l'avviso giallo in testa alle azioni durante la valigia,
  // v. renderAzioni riga 'petq-valigia-avviso') — niente fascia sopra, sarebbe rumore doppio.
  function aggiornaFasciaStato(state) {
    var fascia = document.getElementById('petq-stato-fascia');
    if (!fascia) return;
    if (!state || !state.pet || state.valigia) {
      fascia.innerHTML = '';
      fascia.style.display = 'none';
      return;
    }
    fascia.style.display = '';
    fascia.innerHTML = '';

    var nome = state.pet.nome || traduci('Il pet');
    var etichetta, righe;

    if (state.missione && PETQ.missions) {
      // Titolo scheda via PETQ.missions.inCorso (gia' usata altrove per la card "in corso",
      // v. cardMissione) + PETQ.missions.tempoRimasto/formattaTempo, ENTRAMBE riusate qui senza
      // reimplementarle (v. aggiornaIndicatoreMissione sopra per lo stesso pattern).
      var schedaM = PETQ.missions.inCorso(state);
      var titoloM = (schedaM && schedaM.titolo) || traduci('Missione');
      etichetta = traduci('ORA');
      righe = [titoloM, traduci('Torna tra ') + formattaTempo(PETQ.missions.tempoRimasto(state))];
    } else if (state.passeggiata) {
      // Stessa identica frase gia' usata da aggiornaIndicatorePasseggiata (v. sopra): riusata
      // parola per parola (chiave i18n gia' presente, nessuna nuova voce di dizionario).
      etichetta = traduci('ORA');
      righe = [nome + traduci(' è a passeggio: torna tra ~') + minutiPasseggiataRimasti(state) + 'm. 🚶'];
    } else if (state.allenamento) {
      // Etichetta della stat allenata presa da PROPS_ALLENAMENTO (v. _propsAllenamento in fondo
      // al file): stesso array/stesso lookup per stat di propAllenamentoAttivo sopra, qui si
      // legge .label invece di .id. Frase e minuti riusano aggiornaIndicatoreAllenamento.
      var labelAll = state.allenamento.stat;
      for (var pa = 0; pa < PROPS_ALLENAMENTO.length; pa++) {
        if (PROPS_ALLENAMENTO[pa].stat === state.allenamento.stat) { labelAll = PROPS_ALLENAMENTO[pa].label; break; }
      }
      etichetta = traduci('ORA');
      righe = [nome + traduci(' si allena (') + traduci(labelAll) + traduci('). Pronto tra ') + minutiAllenamentoRimasti(state) + 'm.'];
    } else if (state.sonno) {
      // Ore dormite/soglia di sveglia autonoma dai CAMPI GIA' PRESENTI in state.sonno
      // (oreDormite, modalita') e dalla COSTANTE DI BILANCIAMENTO gia' letta da pet.js
      // (PETQ.pet.bilEnergiaSonno: riposinoDurataMax=2h per il riposino, sveglioAutonomoOre=8h
      // per la notte — stessa fonte usata da controllaSveglia in pet.js, nessuna soglia nuova).
      var esSonno = (PETQ.pet && PETQ.pet.bilEnergiaSonno) ? PETQ.pet.bilEnergiaSonno() : { riposinoDurataMax: 2, sveglioAutonomoOre: 8 };
      var durataMaxSonno = (state.sonno.modalita === 'riposino') ? esSonno.riposinoDurataMax : esSonno.sveglioAutonomoOre;
      var oreDormiteSonno = state.sonno.oreDormite || 0;
      var msMancantiSonno = Math.max(0, durataMaxSonno - oreDormiteSonno) * 3600000;
      // 'un riposino' / 'la nanna notturna': stesse chiavi i18n gia' usate da renderAzioniCamera.
      var modalitaLbl = (state.sonno.modalita === 'riposino') ? traduci('un riposino') : traduci('la nanna notturna');
      etichetta = traduci('ORA');
      righe = [nome + traduci(' sta facendo ') + modalitaLbl + '. 😴', traduci('Sveglia tra ~') + formattaTempo(msMancantiSonno)];
    } else if (state.gioco) {
      // Stessa identica frase di aggiornaIndicatoreGioco (v. sopra), riusata parola per parola.
      etichetta = traduci('ORA');
      righe = [nome + traduci(' sta giocando: ancora ') + minutiGiocoRimasti(state) + 'm. 🧸'];
    } else {
      // Nessuna attivita' in corso (caso piu' frequente): oltre al riepilogo della giornata gia'
      // presente, QUI diventa anche la "carta d'identita'" del pet (richiesta fondatore 28 lug
      // 2026: "metterei in quello spazio tutte le info principali che appaiono anche nella
      // scheda, quindi tratto ecc") — 4 righe compatte, in ordine: (1) identita'
      // nome/razza/stadio/giorno di vita, (2) indole personalita'/talenti, (3) quante
      // missioni/allenamenti restano oggi (tetti letti dai talenti, MAI hardcodati) affiancate in
      // UNA riga a chip invece di due righe separate (v. rigaQuoteOggi sotto: stesso calcolo di
      // prima, SOLO la presentazione cambia, per recuperare ~28px e far stare la fascia nello
      // schermo anche in Salone — misura fondatore 412x915, sforava di 26px), (4) la cosa piu'
      // urgente da fare per il pet ora (v. helper sotto). Le righe 1-2 riusano etichette/funzioni
      // della scheda personaggio (mostraScheda piu' sotto nel file) senza reinventarle — v.
      // rigaIdentitaPet/rigaIndolePet appena sotto per il dettaglio del riuso.
      etichetta = traduci('OGGI');
      righe = [rigaIdentitaPet(state), rigaIndolePet(state), rigaQuoteOggi(state), rigaUrgenzaPet(state.pet)];
    }

    fascia.appendChild(el('div', 'petq-stato-fascia-etichetta', etichetta));
    for (var i = 0; i < righe.length; i++) {
      // righe[i] e' quasi sempre testo semplice; rigaQuoteOggi (v. sotto) invece ritorna gia' un
      // nodo DOM pronto (contenitore chip con due span) — se e' un nodo lo appendiamo com'e',
      // altrimenti stesso wrapping di sempre. Gli altri rami (missione/passeggiata/allenamento/
      // sonno/gioco) passano solo stringhe: per loro il comportamento resta identico a prima.
      if (righe[i] && righe[i].nodeType) {
        fascia.appendChild(righe[i]);
      } else {
        fascia.appendChild(el('div', 'petq-stato-fascia-riga', righe[i]));
      }
    }
  }

  // Riga IDENTITA' del pet (richiesta fondatore 28 lug 2026, v. commento sopra in
  // aggiornaFasciaStato): nome, razza (+sottorazza tra parentesi), stadio e giorno di vita — le
  // stesse quattro informazioni che oggi si leggono SOLO aprendo la scheda personaggio
  // (mostraScheda, piu' sotto nel file). Etichette RIUSATE pari pari dalla scheda, NON
  // reinventate: razzaTxt e' lo STESSO identico calcolo di mostraScheda (v. RAZZA_LABEL/
  // SOTTORAZZA_LABEL/STADIO_LABEL dichiarate piu' sotto nel file — forward-reference sicura,
  // stesso pattern gia' in uso per PROPS_ALLENAMENTO qui sopra: l'intero file viene eseguito una
  // volta sola dall'alto in basso prima che aggiornaFasciaStato venga MAI chiamata da un evento
  // di gioco, quindi quelle var sono gia' valorizzate). Il giorno di vita e' pet.giorniVita —
  // l'ETA' vera del pet (avanzata da care.dailyLogin ad ogni nuovo giorno), NON il calendario di
  // gioco state.giornoGioco che l'orologio dell'HUD mostra come "Giorno N" — ma STESSA dicitura
  // (0-based -> mostrato 1-based, STESSA chiave i18n 'Giorno ' gia' usata li') per restare
  // familiare al giocatore che gia' la vede in alto. Il nome e' un nodo a parte (span
  // .petq-stato-fascia-nome, v. style.css) per risaltare come richiesto; il resto
  // (razza/stadio/giorno) resta testo semplice che eredita il colore corpo della fascia, tutto
  // dentro UNA riga che va a capo da sola se non ci sta (nessun limite di lunghezza aggiunto: il
  // nome lo sceglie il giocatore, max 12 caratteri, ma razza+stadio+giorno possono spezzarsi).
  function rigaIdentitaPet(state) {
    var pet = state.pet;
    var riga = el('div', 'petq-stato-fascia-riga');
    riga.appendChild(el('span', 'petq-stato-fascia-nome', pet.nome || traduci('Il pet')));

    var razzaTxt = traduci(RAZZA_LABEL[pet.razza]) || pet.razza || '?';
    if (pet.sottorazza) razzaTxt += ' (' + (traduci(SOTTORAZZA_LABEL[pet.sottorazza]) || pet.sottorazza) + ')';
    var stadioTxt = traduci(STADIO_LABEL[pet.stadio] || pet.stadio);
    var giorniVitaVal = (typeof pet.giorniVita === 'number') ? pet.giorniVita : 0;
    var giornoTxt = traduci('Giorno ') + (giorniVitaVal + 1);

    riga.appendChild(document.createTextNode(' · ' + razzaTxt + ' · ' + stadioTxt + ' · ' + giornoTxt));
    return riga;
  }

  // Riga INDOLE del pet: personalita' (STESSO colore verde di .petq-personalita, la schermata di
  // nascita — v. style.css .petq-stato-fascia-personalita: riusato SOLO il colore, non l'intero
  // stile, per restare compatti) + talenti posseduti (PETQ.talenti.talentiAttivi, IDENTICA
  // funzione gia' usata dalla scheda per elencarli, v. mostraScheda piu' sotto). FIX segnalazione
  // fondatore 28 lug 2026 "i tratti non sono tradotti": il nome del talento e' la CHIAVE dati
  // (v. content.js parseTermine, condizioni missione `talento:x`) — content/en/talenti.md lo
  // lascia apposta identico all'italiano, quindi va tradotto SOLO qui a schermo con traduci(),
  // esattamente come mostraScheda fa per lo stesso elenco. Piu' di un talento: elencati separati
  // da virgola, la riga va a capo da sola sui nomi lunghi (nessun troncamento aggiunto). Zero
  // talenti: si OMETTE del tutto la parte talenti (niente "Talenti: -" a vuoto — richiesta
  // esplicita del fondatore).
  function rigaIndolePet(state) {
    var pet = state.pet;
    var riga = el('div', 'petq-stato-fascia-riga');
    var personalitaTxt = traduci(PERSONALITA_LABEL[pet.personalita] || pet.personalita);
    riga.appendChild(el('span', 'petq-stato-fascia-personalita', personalitaTxt));

    var talentiPosseduti = (PETQ.talenti && PETQ.talenti.talentiAttivi) ? PETQ.talenti.talentiAttivi(state) : [];
    if (talentiPosseduti.length > 0) {
      var nomiTalenti = [];
      for (var it = 0; it < talentiPosseduti.length; it++) nomiTalenti.push(traduci(talentiPosseduti[it].nome));
      riga.appendChild(document.createTextNode(' · ' + nomiTalenti.join(', ')));
    }
    return riga;
  }

  // Missioni ancora disponibili OGGI: stesso identico calcolo di missioneEsauritaOggi (v.
  // sopra, tab mappa) — tetto letto da PETQ.talenti.missioniPerGiorno (mai un numero fisso: il
  // tetto cambia coi talenti, es. "Lavoro in Nero"), contatore da state.missioniOggiCount solo
  // se e' di OGGI (state.missioniOggiGiorno). Qui serve il RESIDUO, non solo il booleano
  // esaurito/non-esaurito, quindi calcolato per intero invece di richiamare quella funzione.
  // CALCOLO INVARIATO rispetto a prima: cambia solo il testo, ridotto a fragment corto (icona +
  // numero + parola) per il chip affiancato di rigaQuoteOggi qui sotto.
  function rigaMissioniOggi(state) {
    var maxM = (PETQ.talenti && PETQ.talenti.missioniPerGiorno) ? PETQ.talenti.missioniPerGiorno(state) : 1;
    var oggiM = PETQ.clock.giornoCorrente(state);
    var fatteM = (state.missioniOggiGiorno === oggiM) ? (state.missioniOggiCount || 0) : 0;
    var restantiM = Math.max(0, maxM - fatteM);
    if (restantiM <= 0) return '🗺️ ' + traduci('nessuna missione rimasta');
    return '🗺️ ' + restantiM + ' ' + traduci(restantiM === 1 ? 'missione' : 'missioni');
  }

  // Allenamenti ancora disponibili OGGI: stesso identico calcolo di allenamentoEsauritoOggi (v.
  // sopra, salone) — PETQ.care.allenamentiFattiOggi (azzera da solo a cambio data) confrontato
  // col tetto di PETQ.talenti.allenamentiPerGiorno (default 1, 2 con "Predestinato": mai un
  // numero fisso). Qui serve il RESIDUO come sopra. CALCOLO INVARIATO, v. nota sopra.
  function rigaAllenamentiOggi(state) {
    var fattiA = (PETQ.care && PETQ.care.allenamentiFattiOggi) ? PETQ.care.allenamentiFattiOggi(state) : 0;
    var maxA = (PETQ.talenti && PETQ.talenti.allenamentiPerGiorno) ? PETQ.talenti.allenamentiPerGiorno(state) : 1;
    var restantiA = Math.max(0, maxA - fattiA);
    if (restantiA <= 0) return '💪 ' + traduci('nessun allenamento rimasto');
    return '💪 ' + restantiA + ' ' + traduci(restantiA === 1 ? 'allenamento' : 'allenamenti');
  }

  // Riga a CHIP con le due quote di oggi affiancate (v. brief fondatore: misura 412x915, con la
  // fascia attiva il Salone sforava di 26px; unire le due righe separate di missioni/allenamenti
  // in una sola recupera lo spazio di una riga intera senza perdere numeri). Stile pillola
  // riusato da .petq-orologio-giorno (v. style.css .petq-stato-fascia-chip: stesso sfondo/raggio/
  // padding, nessun colore nuovo) dentro un contenitore flex .petq-stato-fascia-chips: due span,
  // uno per quota, gia' pronti da rigaMissioniOggi/rigaAllenamentiOggi sopra (calcolo identico a
  // prima, cambia solo che ora sono due elementi in riga invece di due righe).
  function rigaQuoteOggi(state) {
    var contQuote = el('div', 'petq-stato-fascia-chips');
    contQuote.appendChild(el('span', 'petq-stato-fascia-chip', rigaMissioniOggi(state)));
    contQuote.appendChild(el('span', 'petq-stato-fascia-chip', rigaAllenamentiOggi(state)));
    return contQuote;
  }

  // La cosa piu' urgente per il pet ADESSO: stesse identiche soglie di situazionePrioritaria (v.
  // sopra, sceglie la battuta automatica del balloon) — bilanciamento().soglie.critica (25) per
  // Fame/Igiene/Felicita' ("Stat critica (sprite triste, notifiche) | < 25", bilanciamento.md
  // "Soglie") + PETQ.pet.bilEnergiaSonno().sogliaRifiuto (20, la stessa di
  // PETQ.pet.energiaSottoSoglia) per l'Energia — NESSUNA soglia nuova inventata. Tra le stat
  // sotto la propria soglia si cita quella col distacco maggiore (la "piu' bassa" in proporzione
  // alla soglia che la riguarda); se sono tutte sopra soglia, una riga positiva.
  function rigaUrgenzaPet(pet) {
    if (!pet || !pet.stats) return traduci('sta una favola') + ' ✨';
    var soglieUrg = (bilanciamento().soglie) || {};
    var criticaUrg = (typeof soglieUrg.critica === 'number') ? soglieUrg.critica : 25;
    var esUrg = (PETQ.pet && PETQ.pet.bilEnergiaSonno) ? PETQ.pet.bilEnergiaSonno() : { sogliaRifiuto: 20 };
    var sogliaEnergiaUrg = (typeof esUrg.sogliaRifiuto === 'number') ? esUrg.sogliaRifiuto : 20;

    var vociUrg = [
      { valore: pet.stats.fame, soglia: criticaUrg, testo: traduci('ha fame') + ' 🍔' },
      { valore: pet.stats.igiene, soglia: criticaUrg, testo: traduci('avrebbe bisogno di un bagno') + ' 🛁' },
      { valore: pet.stats.energia, soglia: sogliaEnergiaUrg, testo: traduci('è a pezzi') + ' 💤' },
      { valore: pet.stats.felicita, soglia: criticaUrg, testo: traduci('si annoia') + ' 😐' }
    ];
    var peggioreUrg = null, deficitMaxUrg = 0;
    for (var vu = 0; vu < vociUrg.length; vu++) {
      var deficitUrg = vociUrg[vu].soglia - vociUrg[vu].valore;
      if (deficitUrg > 0 && deficitUrg > deficitMaxUrg) { deficitMaxUrg = deficitUrg; peggioreUrg = vociUrg[vu]; }
    }
    var nomeUrg = pet.nome || traduci('Il pet');
    return peggioreUrg ? (nomeUrg + ' ' + peggioreUrg.testo) : (nomeUrg + ' ' + traduci('sta una favola') + ' ✨');
  }

  // Toggle lingua (i18n bilineue, contratto localStorage 'petq_lingua'): unico controllo UI per
  // cambiare lingua, messo accanto al bottone "Scheda" (nessun pannello impostazioni esiste
  // ancora nel telaio, v. brief i18n). Mostra la lingua a cui si passerebbe (tap "EN" quando sei
  // in italiano, "IT" quando sei in inglese). Niente hot-swap: scrive localStorage + (se possibile)
  // lo specchio state.lingua, salva e ricarica la pagina — content.js/save.js leggono la nuova
  // lingua dal boot successivo (v. content.js linguaCorrente/save.js linguaDefault).
  function costruisciTastoLingua() {
    var linguaAttuale = (PETQ.i18n && PETQ.i18n.lingua) ? PETQ.i18n.lingua() : 'it';
    var prossima = (linguaAttuale === 'en') ? 'it' : 'en';
    var btn = el('button', 'petq-btn petq-btn-mini petq-btn-lingua', prossima === 'en' ? 'EN' : 'IT');
    btn.title = 'Lingua / Language';
    btn.addEventListener('click', function () {
      try { localStorage.setItem('petq_lingua', prossima); } catch (e) { /* localStorage non disponibile: niente persistenza, resta la lingua attuale */ }
      if (currentState) {
        currentState.lingua = prossima;
        if (PETQ.save && PETQ.save.save) PETQ.save.save(currentState);
      }
      location.reload();
    });
    return btn;
  }

  // Interruttore audio nell'HUD (richiesta fondatore, audio.js): stesso posto del tasto lingua,
  // MA senza reload — e' una preferenza pura (localStorage 'petq_audio'), non serve rileggere i
  // contenuti. Etichetta 🔊/🔇 secondo PETQ.audio.attivo(); al click accende/spegne e, SOLO se ora
  // e' acceso, fa sentire subito 'tap' (conferma uditiva che il suono e' tornato). Guardia: se
  // audio.js non e' caricato (es. contesto di test) la funzione ritorna null e il bottone non
  // viene aggiunto, stesso pattern difensivo del resto del gioco (if (PETQ.xxx) ...).
  function costruisciTastoAudio() {
    if (!PETQ.audio) return null;
    var btn = el('button', 'petq-btn petq-btn-mini petq-btn-audio', PETQ.audio.attivo() ? '🔊' : '🔇');
    btn.title = traduci('Suoni');
    btn.addEventListener('click', function () {
      var acceso = !PETQ.audio.attivo();
      PETQ.audio.imposta(acceso);
      if (acceso) PETQ.audio.suona('tap');
      btn.textContent = acceso ? '🔊' : '🔇'; // niente reload: solo l'etichetta cambia
    });
    return btn;
  }

  // Orologio di gioco nell'HUD (GDD "Casa" -> orologio in-game): HH:MM da PETQ.clock.oraGioco
  // + icona sole/luna. Notte di gioco = 21:00-07:59 (PETQ.clock.eNotteGioco, stessa soglia
  // "ora del letto" del bilanciamento sonno). Aggiornata ad ogni aggiornaHud (render/tick).
  function costruisciOrologioHud(state) {
    var wrap = el('div', 'petq-orologio');
    if (!PETQ.clock || !PETQ.clock.oraGioco) return wrap;

    var es = (PETQ.pet && PETQ.pet.bilEnergiaSonno) ? PETQ.pet.bilEnergiaSonno() : { oraLetto: 21 };
    var og = PETQ.clock.oraGioco(state);
    var notte = PETQ.clock.eNotteGioco(state, es.oraLetto, 8);

    wrap.appendChild(el('span', 'petq-orologio-icona', notte ? '🌙' : '☀️'));
    wrap.appendChild(el('span', 'petq-orologio-ora', og.hhmm));
    // Contatore giorni accanto all'ora (richiesta fondatore, playtest 7 lug 2026): rende
    // visibile QUANDO scatta il nuovo giorno (reset coccole/allenamenti/rosa a mezzanotte).
    // FIX 31 lug 2026 (decisione fondatore): qui deve comparire l'ETA' DEL PET, non il contatore
    // della CASA. Prima si leggeva PETQ.clock.giornoCorrente(state) = state.giornoGioco, che NON
    // si azzera mai al cambio pet (e regge sotto al cofano TUTTI i cancelli giornalieri del
    // gioco: missioni, carte, lavoro, talenti, streak, cuoco, canto... — NON toccato, resta
    // esattamente come prima) -> risultato assurdo: l'orologio diceva "Giorno 21" con un pet
    // appena nato che nella sua fascia identita' (v. rigaIdentitaPet sopra) leggeva "Giorno 1".
    // STESSA FONTE e STESSA DICITURA di rigaIdentitaPet: pet.giorniVita, 0-based -> mostrato
    // 1-based. Il conteggio della CASA non e' sparito: ora si legge nella scheda (mostraScheda,
    // riga "casa: N giorni" vicino a "build vXXX").
    var petOrologio = state.pet;
    var giorniVitaOrologio = (petOrologio && typeof petOrologio.giorniVita === 'number') ? petOrologio.giorniVita : 0;
    var giorno = giorniVitaOrologio + 1;
    wrap.appendChild(el('span', 'petq-orologio-giorno', traduci('Giorno ') + giorno));
    wrap.title = traduci(notte ? 'Notte di gioco' : 'Giorno di gioco') + traduci(' — i limiti giornalieri si azzerano a mezzanotte');
    return wrap;
  }

  function coloreBarra(val) {
    if (val > 50) return 'petq-barra-verde';
    if (val >= 25) return 'petq-barra-gialla';
    return 'petq-barra-rossa';
  }

  // ---------- disegno stanza + pet + effetti ----------

  // prop dell'allenamento IN CORSO (state.allenamento.stat -> id prop), per il bounce/icona
  // sul canvas per tutta la durata dell'attivita' (non solo durante i 1.2s dell'animazione
  // locale di avvio, v. avviaAllenamento/PROPS_ALLENAMENTO).
  function propAllenamentoAttivo(state) {
    if (!state || !state.allenamento) return null;
    for (var i = 0; i < PROPS_ALLENAMENTO.length; i++) {
      if (PROPS_ALLENAMENTO[i].stat === state.allenamento.stat) return PROPS_ALLENAMENTO[i].id;
    }
    return null;
  }

  // posizione del pet durante l'animazione "va a scrivere" (tap sulla scrivania, GDD "Diario
  // in camera"): appena a DESTRA del mobile (v. rooms.js SCRIVANIA_CAMERA, nell'angolo a
  // sinistra del letto), sul pavimento, rivolto verso il piano dove poggia il foglio/tavoletta.
  function scrivaniaPos() {
    var r = hotzoneScrivania();
    return { x: Math.min(ROOM_W - PET_PX, r.x + r.w - 4), y: altezzaStanzaCorrente() - PET_PX - 4 };
  }

  function posizionePet() {
    if (effetto && effetto.tipo === 'wash') {
      return { x: WASH_POS.x, y: WASH_POS.y };
    }
    if (effetto && effetto.tipo === 'scrivania') {
      return scrivaniaPos();
    }
    if (currentState && currentState.sonno) {
      if (currentState.sonno.aLetto && currentStanza === 'camera') {
        // idem hotzone letto sopra: sleepBedPos si appoggia a hotzoneLetto, che conosce solo
        // lab/ship. Lasciato su temaRazza per lo stesso motivo (nessun rettangolo lab/ship-
        // preciso da guadagnare passando la skin scelta, v. report).
        return sleepBedPos(temaRazza(currentState.pet));
      }
      return sleepFloorPos();
    }
    var y = altezzaStanzaCorrente() - PET_PX - 4 + (idleFrame === 1 ? 1 : 0);
    var inTrain = (effetto && effetto.tipo === 'train') || (currentState && currentState.allenamento);
    if (inTrain && idleFrame === 1) y -= 3; // bounce da allenamento
    // Animazione "sta giocando" (fix fondatore 17 lug 2026): saltello da gioco nel salone,
    // stesso ritmo del bounce allenamento ma piu' ampio — si vede che si sta divertendo.
    var inGioco = currentState && currentState.gioco;
    if (inGioco && idleFrame === 1) y -= 4;
    var x = Math.round((ROOM_W - PET_PX) / 2);

    // Animazioni idle di personalita' (GDD): micro-movimento SOPRA l'idle normale, sportivo
    // (a) "si allena" = su/giu' piu' marcato del semplice respiro; (b) "corre per casa" =
    // traslazione orizzontale su 2-3 posizioni (sinistra/centro/destra), il frame idleFrame
    // (0|1, alterna ogni 500ms) scandisce i passi entro la durata dell'azione (~3.5s).
    if (idleAction && idleAction.def) {
      if (idleAction.def.muovi === 'su_giu') {
        y -= (idleFrame === 1 ? 4 : 0); // squat/flessione piu' ampio del bounce allenamento
      } else if (idleAction.def.muovi === 'sinistra_destra') {
        var passo = Math.floor((Date.now() - idleAction.startMs) / (IDLE_ACTION_DURATA_MS / 4)) % 4;
        var offsets = [-16, 0, 16, 0]; // sinistra -> centro -> destra -> centro
        x += offsets[passo] || 0;
        x = Math.max(2, Math.min(ROOM_W - PET_PX - 2, x));
      }
    }
    return { x: x, y: y };
  }

  function disegnaStanzaEPet(state) {
    if (currentStanza === 'missioni') {
      aggiornaIndicatoreMissione(state);
      aggiornaIndicatorePasseggiata(state); // countdown passeggiata anche nella tab mappa
      ridisegnaMappa(); // pin pulsante: il frame segue il loop idle
      return;
    }
    var canvas = document.getElementById('petq-canvas-stanza');
    if (!canvas || !state || !state.pet) return;

    // Sincronizza l'altezza del canvas con lo stato Ingrandimento casa: mostraCasa la imposta alla
    // costruzione, ma comprare l'upgrade a casa gia' montata (o altri percorsi) non ripassa di li'.
    // Senza, rooms.draw disegnerebbe a H=80 SCHIACCIATO in un canvas alto 64. Riassegnare
    // canvas.height lo pulisce: guardia sul cambio per non pulire ad ogni frame quando e' gia' giusto.
    var altStanza = (PETQ.rooms && PETQ.rooms.altezzaStanza) ? PETQ.rooms.altezzaStanza(state) : ROOM_H;
    if (canvas.height !== altStanza) canvas.height = altStanza;

    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;

    // tema VISIVO (skin scelta se disponibile, altrimenti lab/ship per razza — v.
    // temaStanzaCorrente sopra): QUESTO e' il punto vero che disegna la stanza, quindi e' l'unico
    // punto in cui temaRazza va sostituito con la funzione che tiene conto della skin scelta.
    PETQ.rooms.draw(canvas, temaStanzaCorrente(state), currentStanza, {
      poop: state.poop,
      arredi: nomiArrediPiazzati(state, currentStanza), // nomi non scaduti: rooms li disegna se sa farlo
      // altezza parametrica: rooms.draw legge ingrandimentoCasa per scegliere H (64/80) e lo
      // scaleY; DEVE combaciare con la canvas.height impostata in mostraCasa (altStanza).
      ingrandimentoCasa: !!state.ingrandimentoCasa,
      // battito dell'inattivita' (lo STESSO che fa respirare il pet, nessun timer nuovo): rooms
      // lo usa per far muovere di 1-2px i COMPANION, che content/arredi.md chiama "arredi vivi"
      // ma che finora erano figurine immobili sulla mensola.
      idleFrame: idleFrame
    });
    disegnaSlotArredi(g, state);

    var inMissione = !!state.missione;
    // Passeggiata serale (playtest 8 lug 2026): il pet e' FUORI casa, come in missione.
    var aPasseggio = !!state.passeggiata;
    // Dorme = il pet "vive" in camera per tutta la durata del sonno (riposino, notturno o
    // crollo): nelle altre stanze non va MAI disegnato (GDD "Energia e sonno" -> bug fix 5
    // lug 2026, prima si "trasferiva" sul pavimento di ogni stanza). Qui sotto usiamo
    // dormeAltrove per saltare il disegno del pet e mostrare l'hint al suo posto.
    var dormeAltrove = !!state.sonno && currentStanza !== 'camera';
    // Gioca nel salone (fix fondatore 17 lug 2026 "si trasporta in altre stanze"): durante
    // state.gioco il pet sta FERMO nel salone col giocattolo — nelle altre stanze non va
    // disegnato (stesso principio di dormeAltrove: prima "seguiva" la stanza che guardavi).
    var giocaAltrove = !!state.gioco && currentStanza !== 'salone';

    if (inMissione || aPasseggio || dormeAltrove || giocaAltrove) {
      // il pet non è visibile in questa stanza: niente hit-test sul pet
      lastPetRect = null;
      if (dormeAltrove) disegnaHintDorme(g, state);
      if (aPasseggio) disegnaHintPasseggio(g);
    } else if (!petDragging) {
      var pos = posizionePet();

      var petCanvas = document.createElement('canvas');
      petCanvas.width = PET_PX;
      petCanvas.height = PET_PX;

      if (state.sonno) {
        // Dorme (e siamo in camera, v. dormeAltrove sopra): sprite SDRAIATO orizzontale
        // (non in piedi) + palpebre chiuse, sia sul letto sia crollato a terra (GDD "Energia
        // e sonno"). zzz:false = gli Zzz NON li disegna qui dentro (sul mini-canvas del pet
        // verrebbero clippati dal bordo, v. sprites.js drawSdraiato): li ridisegniamo subito
        // dopo su tutto il canvas stanza con disegnaZzzStanza, dove c'e' margine per contenerli.
        PETQ.sprites.drawSdraiato(petCanvas, petLikeDaState(state), { frame: idleFrame, zzz: false });
      } else {
        PETQ.sprites.draw(petCanvas, petLikeDaState(state), { frame: idleFrame });
      }

      var pctx = petCanvas.getContext('2d');
      if (effetto && effetto.tipo === 'wash') overlaySchiuma(pctx, idleFrame);
      if (effetto && effetto.tipo === 'crumbs') overlayBriciole(pctx, idleFrame);
      if (effetto && effetto.tipo === 'cura') overlayCura(pctx, idleFrame);
      // Animazione idle di personalita' (GDD): overlay sul VOLTO (es. boccaccia del
      // maleducato) — va disegnato sul mini-canvas del pet PRIMA di comporlo sulla stanza,
      // stesso pattern degli altri overlay sopra (schiuma/briciole/cura).
      if (idleAction && idleAction.def && idleAction.def.overlay === 'boccaccia' && PETQ.sprites.drawBoccaccia) {
        PETQ.sprites.drawBoccaccia(pctx, idleFrame);
      }

      g.drawImage(petCanvas, pos.x, pos.y);

      // Prop dell'allenamento: durante l'animazione locale di avvio (effetto.tipo==='train')
      // oppure per TUTTA la durata dell'attivita' (state.allenamento attivo, v.
      // propAllenamentoAttivo) cosi' il pet resta visibilmente "al lavoro" col suo attrezzo
      // finche' il countdown non arriva a zero (GDD: riusa l'animazione/prop esistente).
      var propTrain = (effetto && effetto.tipo === 'train') ? effetto.prop : propAllenamentoAttivo(state);
      if (propTrain) {
        var propCanvas = document.createElement('canvas');
        propCanvas.width = 12;
        propCanvas.height = 12;
        disegnaProp(propCanvas, propTrain);
        g.drawImage(propCanvas, Math.min(pos.x + PET_PX - 2, ROOM_W - 12), pos.y + PET_PX - 13);
      }

      // Prop "scrive" (GDD "Diario in camera"): riusa l'icona libro/penna esistente durante
      // la breve animazione di avvio della scrittura (v. avviaScrittura), stesso posizionamento
      // angolare del prop allenamento cosi' non serve nuova grafica dedicata.
      if (effetto && effetto.tipo === 'scrivania') {
        var propScrivaniaCanvas = document.createElement('canvas');
        propScrivaniaCanvas.width = 12;
        propScrivaniaCanvas.height = 12;
        disegnaProp(propScrivaniaCanvas, 'libro');
        g.drawImage(propScrivaniaCanvas, Math.min(pos.x + PET_PX - 2, ROOM_W - 12), pos.y + PET_PX - 13);
      }

      // Prop dell'animazione idle di personalita' (GDD): nerd legge/cubo, gentile canta/
      // disegna, maleducato conta i soldi — un prop accanto al pet per tutta la durata della
      // mini-azione (~3.5s). "libro"/"pesi" riusano disegnaProp esistente; cubo/note/monete
      // sono i 3 prop nuovi (v. sprites.js drawIdleProp). Nessun prop per le azioni "muovi"
      // (si allena/corre) o "overlay" (boccaccia): quelle si vedono gia' nel movimento/volto.
      if (idleAction && idleAction.def && idleAction.def.prop) {
        disegnaIdleActionProp(g, idleAction.def.prop, pos);
      }

      // Valigetta (PROTOTIPO 2, Blocco 2): quando il pet e' in fase valigia (state.valigia) sta
      // preparando la valigia -> compare una valigetta accanto a lui (a terra, sul lato). Solo
      // se il pet e' sveglio e visibile in scena (questo ramo). Non durante missione/sonno
      // (rami sopra, che non arrivano qui). La disegniamo a sinistra del pet, appoggiata al
      // suo livello dei piedi, clampata dentro il canvas.
      if (state.valigia && !state.sonno && !state.missione && PETQ.sprites && PETQ.sprites.drawValigetta) {
        var valCanvas = document.createElement('canvas');
        valCanvas.width = 12; valCanvas.height = 12;
        PETQ.sprites.drawValigetta(valCanvas);
        var vx = Math.max(1, pos.x - 12);
        var vy = pos.y + PET_PX - 12;
        g.drawImage(valCanvas, vx, vy);
      }

      lastPetRect = { x: pos.x, y: pos.y, w: PET_PX, h: PET_PX };

      // Zzz "esterni": fix del clipping noto (v. sprites.js drawSdraiato) — la "Z" piu' grande
      // sfora oltre il bordo destro/superiore del mini-canvas PET_PX x PET_PX. Ridisegnandoli
      // qui sul canvas stanza (112x64, molto piu' ampio) restano interi e leggibili.
      if (state.sonno) disegnaZzzStanza(g, pos);
    }

    if (effetto && effetto.tipo === 'puff') disegnaPuff(g, effetto);

    aggiornaIndicatoreMissione(state);
    aggiornaIndicatoreAllenamento(state);
    aggiornaIndicatorePasseggiata(state);
    aggiornaIndicatoreGioco(state);
  }

  // Overlay "e' a passeggio": stanza vuota + icona discreta (stesso stile di disegnaHintDorme).
  function disegnaHintPasseggio(g) {
    g.save();
    g.globalAlpha = 0.8;
    g.font = '8px sans-serif';
    g.textAlign = 'right';
    g.textBaseline = 'top';
    g.fillText('🚶', ROOM_W - 3, 3);
    g.restore();
  }

  // Overlay "sta dormendo altrove": la stanza corrente (non camera) resta vuota mentre il
  // pet dorme, con un avviso discreto invece del pet sul pavimento (GDD "Energia e sonno").
  function disegnaHintDorme(g, state) {
    // Indicatore DISCRETO: solo un piccolo 💤 nell'angolo in alto a destra della stanza.
    // Il messaggio completo ("sta dormendo in camera...") resta nella riga .petq-hint SOTTO
    // il canvas (v. renderAzioni*), qui niente box/testo grande che copre i mobili.
    g.save();
    g.globalAlpha = 0.8;
    g.font = '8px sans-serif';
    g.textAlign = 'right';
    g.textBaseline = 'top';
    g.fillText('💤', ROOM_W - 3, 3);
    g.restore();
  }

  // Zzz sopra la testa del pet dormiente, ridisegnati sul canvas STANZA (112x64) invece che
  // sul mini-canvas del pet (32x32): fix del bug noto di clipping (v. sprites.js drawSdraiato,
  // dove la "Z" piu' in alto/a destra usciva dal bordo del canvas del pet, che e' PET_PX x
  // PET_PX e non ha margine per y negative o x oltre i 16 "pixel logici"). Disegniamo
  // direttamente sul contesto reale della stanza (molto piu' ampio, niente clip), traslato
  // all'angolo dello sprite e con la stessa scala PET_PX/16 che userebbe il mini-canvas
  // (drawZzz accetta la scala esplicita apposta per questo, v. sprites.js).
  function disegnaZzzStanza(g, pos) {
    if (!PETQ.sprites || !PETQ.sprites.drawZzz) return;
    g.save();
    g.translate(pos.x, pos.y);
    PETQ.sprites.drawZzz(g, idleFrame, PET_PX / PET_SIZE);
    g.restore();
  }

  // placeholder arredi piazzati: puntino luminoso sugli slot occupati della stanza corrente.
  // Quando il modulo grafica espone drawArredo, gli arredi veri li disegna rooms.draw
  // (riceve i nomi in stato.arredi) e i puntini spariscono.
  function disegnaSlotArredi(g, state) {
    if (PETQ.rooms && PETQ.rooms.drawArredo) return;
    var pz = state.arredi && state.arredi.piazzati && state.arredi.piazzati[currentStanza];
    if (!pz || !pz.length) return;
    for (var i = 0; i < pz.length && i < SLOT_SPOTS.length; i++) {
      var s = SLOT_SPOTS[i];
      g.fillStyle = '#3ee6d0';
      g.fillRect(s[0], s[1], 2, 2);
      g.fillStyle = (idleFrame === 1) ? '#bff5ec' : '#7fefe0';
      g.fillRect(s[0], s[1] - 1, 2, 1);
    }
  }

  // Aggiorna il countdown testuale dell'allenamento in corso (salone) senza rifare tutto
  // renderAzioni(): stesso pattern "leggero" di aggiornaIndicatoreMissione sotto, chiamato da
  // disegnaStanzaEPet ad ogni tick idle cosi' i minuti scendono anche senza toccare nulla.
  function aggiornaIndicatoreAllenamento(state) {
    if (!state || !state.allenamento || currentStanza !== 'salone') return;
    var minuti = minutiAllenamentoRimasti(state);
    var hint = document.getElementById('petq-allenamento-hint');
    if (hint) {
      var nome = state.pet.nome || traduci('il pet');
      var statLabel = STAT_LABEL[state.allenamento.stat] ? traduci(STAT_LABEL[state.allenamento.stat]) : state.allenamento.stat;
      hint.textContent = nome + traduci(' si allena (') + statLabel + traduci('). Pronto tra ') + minuti + 'm.';
    }
    var cd = document.getElementById('petq-allenamento-countdown');
    if (cd) cd.textContent = traduci('Si allena, pronto tra ') + minuti + 'm';
  }

  // Timer passeggiata (fix playtest 8 lug 2026 "non c'è timer"): minuti di gioco che mancano
  // al rientro, mostrati nell'hint (stanze + tab Missioni) e aggiornati dal tick come gli
  // indicatori di missione/allenamento qui sotto.
  function minutiPasseggiataRimasti(state) {
    if (!state || !state.passeggiata) return 0;
    var pw = state.passeggiata;
    return Math.max(0, Math.ceil((pw.oreTot - (pw.oreFatte || 0)) * 60));
  }

  function aggiornaIndicatorePasseggiata(state) {
    if (!state || !state.passeggiata) return;
    var hint = document.getElementById('petq-passeggiata-hint');
    if (hint) {
      var nome = (state.pet && state.pet.nome) || traduci('Il pet');
      hint.textContent = nome + traduci(' è a passeggio: torna tra ~') + minutiPasseggiataRimasti(state) + 'm. 🚶';
    }
  }

  function aggiornaIndicatoreGioco(state) {
    if (!state || !state.gioco) return;
    var hint = document.getElementById('petq-gioco-hint');
    if (hint) {
      var nome = (state.pet && state.pet.nome) || traduci('Il pet');
      hint.textContent = nome + traduci(' sta giocando: ancora ') + minutiGiocoRimasti(state) + 'm. 🧸';
    }
  }

  function aggiornaIndicatoreMissione(state) {
    var testo = null;
    if (state && state.missione && PETQ.missions) {
      testo = traduci('Torna tra ') + formattaTempo(PETQ.missions.tempoRimasto(state));
    }
    var ind = document.getElementById('petq-missione-ind');
    if (ind) {
      ind.style.display = testo ? 'block' : 'none';
      if (testo) ind.textContent = testo;
    }
    var cd = document.getElementById('petq-missione-countdown');
    if (cd && testo) cd.textContent = formattaTempo(PETQ.missions.tempoRimasto(state));
  }

  // ms -> "2g 5h" | "2h 05m" | "12m 30s" | "45s"
  function formattaTempo(ms) {
    if (!(ms > 0)) return '0s';
    var s = Math.ceil(ms / 1000);
    var h = Math.floor(s / 3600);
    var m = Math.floor((s % 3600) / 60);
    var sec = s % 60;
    if (h >= 24) return Math.floor(h / 24) + traduci('g ') + (h % 24) + 'h';
    if (h > 0) return h + 'h ' + (m < 10 ? '0' : '') + m + 'm';
    if (m > 0) return m + 'm ' + (sec < 10 ? '0' : '') + sec + 's';
    return sec + 's';
  }

  // valore stat RPG del pet: base + bonus passivi degli arredi piazzati (già cappati da
  // arredi.js) + bonus passivi dei talenti attivi (PROTOTIPO 2, Blocco 9, v. talenti.js
  // bonusStat, nessun cap dedicato). state opzionale (default: quello corrente) per i test.
  function statConBonus(nomeStat, state) {
    var st = state || currentState;
    var base = (st && st.pet && st.pet.rpg &&
      typeof st.pet.rpg[nomeStat] === 'number') ? st.pet.rpg[nomeStat] : 0;
    var bonus = 0;
    if (st && PETQ.arredi && PETQ.arredi.bonusPassivi) {
      var b = PETQ.arredi.bonusPassivi(st);
      if (b && typeof b[nomeStat] === 'number') bonus += b[nomeStat];
    }
    if (st && PETQ.talenti && PETQ.talenti.bonusStat) {
      bonus += PETQ.talenti.bonusStat(st, nomeStat);
    }
    if (st && PETQ.missions && PETQ.missions.bonusIndossato) {
      var bi = PETQ.missions.bonusIndossato(st);
      if (bi && typeof bi[nomeStat] === 'number') bonus += bi[nomeStat];
    }
    if (st && PETQ.missions && PETQ.missions.bonusArmaEquip) {
      var ba = PETQ.missions.bonusArmaEquip(st);
      if (ba && typeof ba[nomeStat] === 'number') bonus += ba[nomeStat];
    }
    return { base: base, bonus: bonus, tot: base + bonus };
  }

  // testo compatto per un valore stat: "3" oppure "3 (+1)" col bonus arredi
  function testoStat(nomeStat, state) {
    var sb = statConBonus(nomeStat, state);
    return sb.bonus > 0 ? sb.base + ' (+' + sb.bonus + ')' : String(sb.base);
  }

  // nomi degli arredi piazzati nella stanza (esclusi i temporanei scaduti), per rooms.draw
  function nomiArrediPiazzati(state, stanza) {
    var lista = state && state.arredi && state.arredi.piazzati && state.arredi.piazzati[stanza];
    if (!lista || !lista.length) return [];
    var ora = Date.now();
    var nomi = [];
    for (var i = 0; i < lista.length; i++) {
      if (typeof lista[i].scadenzaMs === 'number' && ora >= lista[i].scadenzaMs) continue;
      nomi.push(lista[i].nome);
    }
    return nomi;
  }

  function petLikeDaState(state) {
    var pet = state.pet;
    var soglie = (bilanciamento().soglie) || { sporco: 30 };
    var sogliaSporco = (typeof soglie.sporco === 'number') ? soglie.sporco : 30;
    return {
      razza: pet.razza,
      // Leggende (P3 batch 6): id del personaggio, letto da sprites.resolvePet per lo sprite
      // fisso; null per un pet normale (nessun effetto li').
      leggendaId: pet.leggendaId || null,
      sottorazza: pet.sottorazza,
      parts: pet.parts,
      stadio: pet.stadio,
      corpo: PETQ.pet.bodyVariant(pet),
      sporco: pet.stats.igiene < sogliaSporco,
      // FASE SPRITE: equip visibile sul pet (drawOverlayEquip in sprites.js legge questi campi).
      // Leggende (decisione fondatore 28 lug 2026, "le leggende non dovrebbero poter indossare
      // vestiti"): aspetto iconico, mai alterato da un vestito — difensivo anche qui, non solo
      // nell'Armadio della scheda, cosi' un state.indossato "sporco" (salvataggio vecchio/
      // reward/debug) non fa comparire un vestito sopra lo sprite fisso della leggenda. Le armi
      // (armaEquip) NON sono toccate: la richiesta del fondatore riguarda solo i vestiti.
      indossato: (pet.razza === 'leggenda') ? null : (state.indossato || null),
      armaEquip: state.armaEquip || null,
      // M17 "Pimp My Pet": modifica permanente scelta all'evoluzione teen, sotto vestito/arma;
      // cosi' l'impianto/mutazione si vede sul pet in ogni schermata (drawOverlayEquip la legge).
      modSprite: (state.pet && state.pet.modSprite) || null
    };
  }

  // ---------- icone e overlay: API grafica nuove con guard + fallback ----------

  var COLORI_CATEGORIA = {
    base: '#c8a468', carne: '#e07050', verdura: '#6ec46e',
    pesce: '#6aaede', dolce: '#e88ac0'
  };

  var COLORI_PROP = {
    pesi: '#8a94a0', libro: '#6aaede', corsa: '#7fd8a4', specchio: '#d8c8e8'
  };

  function disegnaCibo(canvas, cibo) {
    if (PETQ.sprites && PETQ.sprites.drawFood) {
      PETQ.sprites.drawFood(canvas, cibo);
      return;
    }
    // fallback: quadratino colorato per categoria
    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);
    var col = COLORI_CATEGORIA[(cibo && cibo.categoria) || ''] || '#c8a468';
    g.fillStyle = '#1e242e';
    g.fillRect(1, 1, 10, 10);
    g.fillStyle = col;
    g.fillRect(2, 2, 8, 8);
    g.fillStyle = 'rgba(255,255,255,0.55)';
    g.fillRect(3, 3, 2, 1);
  }

  /* Batteria della "carica" (streak, Retention 2.0/A2), 14x12 disegnata a mano nello stesso
   * stile dei chip RPG (pixel netti, niente antialias, raddoppiata dal CSS).
   * La barra e' MONOTONA su 14 giorni (giorni/14) e non riparte da vuota ad ogni traguardo:
   * una barra che si svuota quando prendi un premio si legge come "hai perso qualcosa", ed e'
   * l'esatto contrario di quello che e' successo. Cala SOLO su una retrocessione vera.
   * Il colore segue i traguardi: ambra sotto i 3 giorni, verde da 3, e il teal del visore robot
   * (il colore-firma del gioco) a batteria piena. */
  function disegnaBatteriaCarica(canvas, giorni) {
    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);

    var frazione = Math.max(0, Math.min(1, giorni / 14));
    var col = giorni >= 14 ? '#3ee6d0' : (giorni >= 3 ? '#3ddc84' : '#f0b429');

    // Guscio CHIARO e interno scuro, non il contrario: l'HUD e' gia' scuro, e con un guscio
    // scuro la parte scarica spariva nello sfondo — una batteria al 70% si leggeva come una
    // macchia verde senza contenitore, cioe' non si capiva quanta strada mancasse.
    g.fillStyle = '#8a98a8';           // guscio
    g.fillRect(0, 2, 12, 8);
    g.fillRect(12, 4, 2, 4);           // polo positivo
    g.fillStyle = '#151a22';           // interno spento
    g.fillRect(1, 3, 10, 6);

    var pieno = Math.round(10 * frazione);
    if (pieno > 0) {
      g.fillStyle = col;
      g.fillRect(1, 3, pieno, 6);
      g.fillStyle = 'rgba(255,255,255,0.45)'; // riflesso: da' volume al vetro
      g.fillRect(1, 3, pieno, 1);
    }
    g.fillStyle = '#c4cedb';           // luce sul polo
    g.fillRect(12, 4, 2, 1);
  }

  /* Chip "carica" accanto alle monete. Ritorna null sotto il primo giorno: a un giocatore
   * appena arrivato uno zero in HUD suona come un rimprovero prima ancora di aver giocato.
   * Piccolo di proposito — il fondatore ha chiesto un contatore che NON somigli a una lista di
   * doveri: qui non c'e' nessun elenco di cose da fare, solo una batteria che si riempie. */
  function costruisciCaricaHud(state) {
    if (!PETQ.streak || !PETQ.streak.stato) return null;
    var s = PETQ.streak.stato(state);
    if (!s || s.giorni <= 0) return null;

    var wrap = el('span', 'petq-carica');
    var titolo = traduci('Carica: ') + s.giorni + traduci(s.giorni === 1 ? ' giorno' : ' giorni');
    if (s.record > s.giorni) titolo += traduci(' · record ') + s.record;
    if (s.batterie > 0) {
      titolo += traduci(' · batterie di riserva: ') + s.batterie;
    }
    wrap.title = titolo;

    var icona = document.createElement('canvas');
    icona.width = 14;
    icona.height = 12;
    icona.className = 'petq-carica-icona';
    disegnaBatteriaCarica(icona, s.giorni);
    wrap.appendChild(icona);
    wrap.appendChild(el('span', 'petq-carica-val', String(s.giorni)));

    // Riserve come pallini, non come numero: sono un paracadute, non un punteggio.
    if (s.batterie > 0) {
      var pallini = '';
      for (var b = 0; b < s.batterie; b++) pallini += '•';
      wrap.appendChild(el('span', 'petq-carica-riserve', pallini));
    }
    return wrap;
  }

  /* Messaggi dello streak (traguardi, batteria spesa, retrocessione): stesso canale dei
   * companion del Supporter Pack — mostraAvviso, banner in alto, NON mostraToast, che
   * sovrascrive e con piu' messaggi nello stesso momento ne farebbe vedere solo l'ultimo.
   * Svuotato QUI, dentro aggiornaHud, perche' e' l'unico punto che gira davvero dopo OGNI
   * azione di cura (feed/wash/coccola lo chiamano tutti) e ad ogni battito: un traguardo
   * preso con una coccola si vede subito, non al tick dopo. */
  /* Rientro "quarta parete" (Retention 2.0/A3): main.js lascia in state.quartaParetePendente il
   * riassunto di cosa e' successo mentre eri via piu' l'eventuale reazione al mondo-telefono
   * (ora assurda, batteria a terra, tema scuro, tre giorni di assenza). Qui si consuma e si
   * azzera subito, stesso schema degli effetti companion e degli avvisi streak.
   *
   * Va nel BALLOON e non nel banner in alto: e' il pet che parla, con la sua voce e la sua
   * personalita', non un avviso di sistema. Le due parti si uniscono in un discorso solo, se no
   * arriverebbero due messaggi di fila dalla stessa bocca. */
  function controllaRientroQuartaParete(state) {
    if (!state || !state.quartaParetePendente) return;
    var q = state.quartaParetePendente;
    state.quartaParetePendente = null;

    var pezzi = [];
    if (q.reazione && q.reazione.chiave && PETQ.dialog && PETQ.dialog.say) {
      var battuta = PETQ.dialog.say(state.pet, q.reazione.chiave, state);
      if (battuta && battuta !== '...') pezzi.push(battuta);
    }
    if (Array.isArray(q.recap) && q.recap.length) {
      pezzi.push(traduci('Dall\'ultima volta: ') + q.recap.join(' '));
    }
    if (!pezzi.length) return;

    PETQ.save.save(state);
    mostraBalloon(pezzi.join(' '));
    // Il boot fa parlare il pet anche da solo (battutaAutomatica -> "ho fame", "sono sporco"):
    // senza questo timbro il racconto del rientro veniva scritto e SOVRASCRITTO nello stesso
    // istante, e a schermo restava solo la lamentela sulla fame. Chi torna dopo tre giorni deve
    // sentirsi dire prima cos'e' successo; la fame la vede gia' nella barra.
    rientroDettoMs = Date.now();
  }

  function controllaAvvisiStreak(state) {
    if (!PETQ.streak || !PETQ.streak.raccogliAvvisi) return;
    var avvisi = PETQ.streak.raccogliAvvisi(state);
    if (avvisi.length > 0) mostraAvviso(avvisi.join(' '));
  }

  function disegnaProp(canvas, id) {
    if (PETQ.sprites && PETQ.sprites.drawProp) {
      PETQ.sprites.drawProp(canvas, id);
      return;
    }
    // fallback: quadratino colorato per prop
    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);
    var col = COLORI_PROP[id] || '#8a94a0';
    g.fillStyle = '#1e242e';
    g.fillRect(1, 1, 10, 10);
    g.fillStyle = col;
    g.fillRect(2, 2, 8, 8);
    g.fillStyle = 'rgba(255,255,255,0.55)';
    g.fillRect(3, 3, 2, 1);
  }

  // id: 'cuborubik' | 'note' | 'monete' (nuovi, v. sprites.js IDLE_PROP_ICONS) oppure
  // 'libro' | 'pesi' (riusati da PROP_ICONS esistenti tramite disegnaProp). Disegnato accanto
  // al pet nella stessa posizione angolare usata da propTrain sopra, cosi' i due prop non si
  // accavallano mai (le condizioni di avvio dell'idle action escludono l'allenamento).
  var IDLE_PROP_NUOVI = { cuborubik: true, note: true, monete: true };
  function disegnaIdleActionProp(g, propId, pos) {
    var propCanvas = document.createElement('canvas');
    propCanvas.width = 12;
    propCanvas.height = 12;
    if (IDLE_PROP_NUOVI[propId] && PETQ.sprites && PETQ.sprites.drawIdleProp) {
      PETQ.sprites.drawIdleProp(propCanvas, propId, idleFrame);
    } else {
      disegnaProp(propCanvas, propId);
    }
    // note musicali: sopra la testa (salgono); gli altri prop accanto/davanti come propTrain
    var px = Math.min(pos.x + PET_PX - 2, ROOM_W - 12);
    var py = (propId === 'note') ? Math.max(0, pos.y - 8) : pos.y + PET_PX - 13;
    g.drawImage(propCanvas, px, py);
  }

  function overlaySchiuma(ctx, frame) {
    if (PETQ.sprites && PETQ.sprites.drawFoam) {
      PETQ.sprites.drawFoam(ctx, frame);
      return;
    }
    // fallback: bolle bianche/celesti sulla metà bassa del pet (ctx del canvas pet, 16px logici)
    var s = ctx.canvas.width / PET_SIZE;
    var bolle = frame === 1
      ? [[3, 9], [6, 11], [9, 8], [12, 10], [5, 13], [10, 13]]
      : [[4, 10], [7, 8], [10, 11], [13, 9], [6, 12], [11, 13]];
    for (var i = 0; i < bolle.length; i++) {
      ctx.fillStyle = (i % 2 === 0) ? '#eef6fb' : '#bfe0f2';
      ctx.fillRect(bolle[i][0] * s, bolle[i][1] * s, s, s);
    }
  }

  function overlayBriciole(ctx, frame) {
    if (PETQ.sprites && PETQ.sprites.drawCrumbs) {
      PETQ.sprites.drawCrumbs(ctx, frame);
      return;
    }
    // fallback: briciole marroni ai piedi del pet
    var s = ctx.canvas.width / PET_SIZE;
    var punti = frame === 1
      ? [[3, 14], [7, 15], [12, 14], [9, 13]]
      : [[4, 15], [8, 13], [11, 15], [6, 14]];
    ctx.fillStyle = '#c08a5c';
    for (var i = 0; i < punti.length; i++) {
      ctx.fillRect(punti[i][0] * s, punti[i][1] * s, s, s);
    }
  }

  // effetto infermeria: croce rossa + cuoricini sul canvas del pet (2 frame alternati)
  function overlayCura(ctx, frame) {
    var s = ctx.canvas.width / PET_SIZE;
    var cx = frame === 1 ? 12 : 11;
    ctx.fillStyle = '#e85a5a';
    ctx.fillRect(cx * s, 1 * s, s, 3 * s);
    ctx.fillRect((cx - 1) * s, 2 * s, 3 * s, s);
    ctx.fillStyle = '#f09bb0';
    var cuori = frame === 1 ? [[2, 4], [4, 7], [13, 8]] : [[3, 3], [5, 6], [12, 9]];
    for (var i = 0; i < cuori.length; i++) {
      ctx.fillRect(cuori[i][0] * s, cuori[i][1] * s, s, s);
    }
  }

  function disegnaPuff(g, e) {
    g.fillStyle = '#c9cfd8';
    if (e.step === 0) {
      g.fillRect(e.x - 1, e.y - 2, 2, 2);
      g.fillRect(e.x + 1, e.y - 1, 2, 2);
      g.fillRect(e.x - 3, e.y, 2, 2);
    } else {
      g.fillRect(e.x - 4, e.y - 3, 1, 1);
      g.fillRect(e.x + 3, e.y - 4, 1, 1);
      g.fillRect(e.x, e.y - 5, 1, 1);
      g.fillRect(e.x - 2, e.y + 1, 1, 1);
      g.fillRect(e.x + 4, e.y, 1, 1);
    }
  }

  // ---------- effetti temporizzati ----------

  var effettoTimers = [];
  var animDeadline = 0;
  var animCompletamento = null;

  function dopoMs(ms, fn) {
    effettoTimers.push(setTimeout(fn, ms));
  }

  // animazione con completamento garantito: se il timer viene congelato
  // (tab in background, telefono bloccato), il completamento scatta comunque
  // alla prima occasione utile oltre la scadenza
  function animaTimed(ms, fn) {
    animDeadline = Date.now() + ms;
    animCompletamento = fn;
    dopoMs(ms, completaAnim);
  }

  function completaAnim() {
    if (!animCompletamento) return;
    var fn = animCompletamento;
    animCompletamento = null;
    animDeadline = 0;
    fn();
  }

  function controllaAnimScaduta() {
    if (animazioneInCorso && animCompletamento && Date.now() > animDeadline) {
      completaAnim();
    }
  }

  function puliziaEffetto() {
    for (var i = 0; i < effettoTimers.length; i++) clearTimeout(effettoTimers[i]);
    effettoTimers = [];
    effetto = null;
    animazioneInCorso = false;
    petDragging = false;
    animDeadline = 0;
    animCompletamento = null;
    nascondiGhost();
    evidenziaHotzone(false);
  }

  // ---------- idle animation ----------

  function avviaIdle() {
    fermaIdle();
    idleFrame = 0;
    programmaProssimaIdleAction();
    idleTimer = setInterval(function () {
      idleFrame = idleFrame === 0 ? 1 : 0;
      if (!currentState) return;
      // il countdown missione può azzerarsi tra un tick di gioco e l'altro (30s):
      // controlliamo anche qui così il ritorno è puntuale
      if (!animazioneInCorso && controllaMissioneScaduta()) return;
      if (!animazioneInCorso) controllaSonnoScaduto();
      if (!animazioneInCorso) controllaAllenamentoScaduto();
      aggiornaIdleAction();
      disegnaStanzaEPet(currentState);
    }, IDLE_MS);
  }

  function fermaIdle() {
    if (idleTimer) {
      clearInterval(idleTimer);
      idleTimer = null;
    }
    idleAction = null;
    idleActionProssimaMs = 0;
  }

  // ---------- idle action manager (animazioni idle di personalita') ----------

  // Prossima idle action fra 12-20s (casualità, GDD): chiamata all'ingresso in casa e ogni
  // volta che un'azione finisce/viene annullata, cosi' il ritmo resta "ogni tanto" invece che
  // a orario fisso.
  function programmaProssimaIdleAction() {
    var attesa = IDLE_ACTION_INTERVALLO_MIN_MS +
      PETQ.rng.rand() * (IDLE_ACTION_INTERVALLO_MAX_MS - IDLE_ACTION_INTERVALLO_MIN_MS);
    idleActionProssimaMs = Date.now() + attesa;
  }

  // Condizioni GDD: pet fermo, sveglio, non in attivita'/missione, stanza normale (non la
  // schermata-menu Missioni), nessun drag/animazione/gesto in corso. Stesso set di guardie
  // usato altrove per "posso interagire col pet ora" (v. eseguiCoccola/provaAndareALetto).
  function condizioniIdleActionOk() {
    return !!currentState && !!currentState.pet &&
      !currentState.sonno && !currentState.missione && !currentState.allenamento &&
      currentStanza !== 'missioni' &&
      !animazioneInCorso && !petDragging && !effetto &&
      !canvasPointer && !foodPointer;
  }

  // Chiamata ad ogni tick idle (500ms, stesso ritmo di idleFrame): avvia una nuova idle
  // action quando e' il momento ed e' possibile, oppure chiude quella in corso se scaduta o
  // se le condizioni non sono piu' valide (es. e' arrivata una missione/il sonno).
  function aggiornaIdleAction() {
    if (idleAction) {
      if (!condizioniIdleActionOk() || Date.now() - idleAction.startMs >= idleAction.durataMs) {
        idleAction = null;
        programmaProssimaIdleAction();
      }
      return;
    }
    if (!condizioniIdleActionOk()) return;
    if (Date.now() < idleActionProssimaMs) return;

    var personalita = currentState.pet.personalita;
    var pool = IDLE_ACTIONS[personalita];
    if (!pool || !pool.length) { programmaProssimaIdleAction(); return; }

    var scelta = pool[PETQ.rng.randInt(0, pool.length - 1)];
    idleAction = { id: scelta.id, def: scelta, personalita: personalita, startMs: Date.now(), durataMs: IDLE_ACTION_DURATA_MS };
  }

  // Annulla subito l'idle action in corso (GDD: "un tap/drag/azione qualsiasi la annulla"):
  // richiamata dai punti di ingresso dei gesti/azioni sul canvas e sulle card. Se non c'e'
  // nessuna azione in corso non fa nulla; in ogni caso NON riprogramma qui la prossima (lo fa
  // aggiornaIdleAction al giro successivo) per evitare di far ripartire subito una nuova
  // azione a raffica su input ripetuti (es. più tap veloci).
  function annullaIdleAction() {
    if (!idleAction) return;
    idleAction = null;
    programmaProssimaIdleAction();
    if (currentState) disegnaStanzaEPet(currentState);
  }

  // ---------- balloon battute + toast ----------

  /* Voce del pet sul fumetto (richiesta fondatore: "un effetto all'Animal Crossing ma UNA
   * TANTUM"). Due manopole, ed e' l'unico punto in cui si decide se il pet fa rumore:
   *
   * - PROBABILITA': un animalese ad OGNI battuta diventerebbe la colonna sonora del gioco e
   *   dopo dieci minuti si spegne l'audio. Una volta ogni tanto e' una sorpresa; sempre e' un
   *   ronzio. Il "una tantum" del fondatore e' esattamente questo.
   * - RAFFREDDAMENTO: due battute ravvicinate (capita: un'azione ne produce spesso due di fila)
   *   si accavallerebbero con la voce ancora in corso, e due animalese sovrapposti suonano come
   *   un guasto.
   *
   * Le battute LUNGHE non parlano: oltre la soglia il parlato dura piu' del fumetto stesso e si
   * sente la coda partire mentre la vignetta e' gia' sparita. Le battute corte sono anche quelle
   * piu' "esclamative", cioe' quelle in cui una vocina ci sta bene.
   */
  var VOCE_PROBABILITA = 0.22;
  var VOCE_RAFFREDDAMENTO_MS = 15000;
  var VOCE_MAX_CARATTERI = 90;
  var voceUltimaMs = 0;
  var voceForzata = false; // bottone debug: la prossima battuta parla di sicuro

  /* Cantante da Doccia: il pet CANTA la parola invece di dirla, e la prima volta al giorno la
   * cosa gli mette di buonumore.
   *
   * La Felicita' e' una volta al giorno e non ad ogni canto per una ragione precisa: la parola
   * insegnata esce nel 30% delle battute e le battute sono tante, quindi senza il tetto
   * giornaliero il perk sarebbe una pompa di Felicita' infinita — e la Felicita' regge mezzo
   * gioco (soglie critiche, condizioni segrete delle missioni, valigia). Il tetto lo tiene un
   * regalino, che e' quello che deve essere.
   */
  var CANTO_FELICITA = 3;

  // Lingua del gioco ('it'|'en'): decide le regole di LETTURA della voce sintetica — un
  // giocatore inglese insegna parole inglesi, e "ISSUE" letto all'italiana fa i-s-u-e.
  function linguaVoce() {
    return (PETQ.i18n && PETQ.i18n.lingua) ? PETQ.i18n.lingua() : 'it';
  }

  function cantaSeCantante(parola) {
    if (!currentState || !currentState.pet || !PETQ.audio || !PETQ.audio.canta) return false;
    if (!Array.isArray(currentState.perks) || currentState.perks.indexOf('corso_musica') === -1) return false;
    var durata = PETQ.audio.canta(parola, PETQ.audio.voceDi(currentState.pet), linguaVoce());
    if (durata <= 0) return false;

    var oggi = PETQ.clock.giornoCorrente(currentState);
    if (currentState.cantoGiorno !== oggi) {
      currentState.cantoGiorno = oggi;
      currentState.pet.stats.felicita = Math.min(100, currentState.pet.stats.felicita + CANTO_FELICITA);
      PETQ.save.save(currentState);
      aggiornaHud(currentState);
    }
    return true;
  }

  function voceDelFumetto(testo) {
    if (!PETQ.audio || !PETQ.audio.parla || !currentState || !currentState.pet) return;
    var forza = voceForzata;
    voceForzata = false;

    /* Parola INSEGNATA: si dice DAVVERO, con la voce vera (richiesta esplicita del fondatore).
     * Ha la precedenza sull'animalese e lo sostituisce: sono due voci per la stessa bocca, e
     * sovrapporle suonerebbe come un guasto. Non ha ne' probabilita' ne' raffreddamento — le
     * parole insegnate escono gia' di loro solo nel 30% delle battute, e sono IL momento per cui
     * il giocatore ha insegnato la parola: zittirlo a caso sarebbe crudele.
     * Doppio controllo: la parola dev'essere quella appena messa nello slot da dialog.js E
     * comparire davvero nel testo a schermo, perche' mostraBalloon la chiamano anche messaggi
     * di sistema che con dialog.say non c'entrano nulla. */
    if (PETQ.voce && PETQ.dialog && PETQ.dialog.ultimaParolaDetta) {
      var parola = PETQ.dialog.ultimaParolaDetta();
      if (parola && testo && testo.indexOf(parola) !== -1) {
        // Cantante da Doccia (perk corso_musica, Corso Pomeridiano): la parola non si dice, si
        // CANTA. E' il posto giusto per l'aggancio perche' e' l'unico punto che sa quale parola
        // insegnata sta uscendo — cercarla altrove vorrebbe dire indovinarla dal testo.
        if (cantaSeCantante(parola)) return;
        if (PETQ.voce.pronuncia(parola, currentState.pet)) return;
      }
    }

    if (!forza) {
      if (!testo || testo.length > VOCE_MAX_CARATTERI) return;
      if (Date.now() - voceUltimaMs < VOCE_RAFFREDDAMENTO_MS) return;
      // Math.random e NON PETQ.rng: quello e' il generatore SEMINABILE del gioco, da cui escono
      // esiti di missione, talenti e rose giornaliere. Consumarne un valore per decidere se fare
      // un rumorino significherebbe che l'audio sposta la sequenza della logica — oggi non si
      // vede (il seme e' l'orologio), ma il giorno che qualcuno vorra' una run riproducibile
      // sarebbe un bug feroce da trovare. Una scelta estetica non deve toccare il caso di gioco.
      if (Math.random() >= VOCE_PROBABILITA) return;
    }
    var durata = PETQ.audio.parla(testo, PETQ.audio.voceDi(currentState.pet));
    if (durata > 0) voceUltimaMs = Date.now();
  }

  /* opzioni (facoltative, tutte per l'attrezzo di scena del pannello debug — v. recitaParolaScena):
   *   muto     -> non chiama voceDelFumetto: la voce la sceglie chi chiama
   *   durataMs -> quanto resta a schermo, invece dei BALLOON_MS normali
   * Senza opzioni il comportamento e' identico a prima. */
  function mostraBalloon(testo, opzioni) {
    var opt = opzioni || {};
    var balloon = document.getElementById('petq-balloon');
    if (!balloon) return;
    balloon.textContent = testo;
    ancoraBalloonAlPet(balloon);
    balloon.style.display = 'block';
    if (!opt.muto) voceDelFumetto(testo);

    if (balloonTimer) clearTimeout(balloonTimer);
    balloonTimer = setTimeout(function () {
      balloon.style.display = 'none';
      balloonTimer = null;
    }, opt.durataMs || BALLOON_MS);
  }

  // Mette il fumetto SOPRA LA TESTA del pet invece che in cima alla stanza (richiesta fondatore
  // 29 lug 2026: "la vignetta deve essere piu' vicina al pet"). Il fumetto vive dentro il wrap
  // del canvas, quindi basta convertire le coordinate logiche della stanza in percentuali.
  // Il pet sta quasi sempre al centro (x=48 su 112) e si sposta di +-16px solo con l'animazione
  // "corre per casa": la forbice reale e' 36%-64%, ben dentro il taglio 25-75 qui sotto, cosi'
  // la codina punta sempre davvero al pet e il fumetto non esce mai dal riquadro.
  function ancoraBalloonAlPet(balloon) {
    try {
      var pos = posizionePet();
      var altStanza = altezzaStanzaCorrente();
      if (!pos || !altStanza) return;
      var centroX = (pos.x + PET_PX / 2) / ROOM_W * 100;
      if (centroX < 25) centroX = 25;
      if (centroX > 75) centroX = 75;
      // +3px sopra la testa: la codina ha bisogno del suo spazio senza toccare lo sprite
      var daSotto = (altStanza - pos.y + 3) / altStanza * 100;
      if (daSotto > 78) daSotto = 78; // pet altissimo (letto): il fumetto resta dentro la stanza
      balloon.style.left = centroX + '%';
      balloon.style.bottom = daSotto + '%';
    } catch (e) {
      // stanza non ancora montata o stato incompleto: restano i valori di ripiego del CSS
    }
  }

  function mostraToast(testo) {
    var t = document.getElementById('petq-toast');
    if (!t) {
      t = el('div', 'petq-toast');
      t.id = 'petq-toast';
      document.body.appendChild(t);
    }
    t.textContent = testo;
    t.classList.add('petq-toast-visibile');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      t.classList.remove('petq-toast-visibile');
    }, 2000);
  }

  // Avviso prominente (rientro passeggiata, richiesta fondatore 13 lug 2026: più visibile del
  // toast in basso e più lungo). Banner in alto-centro, stesso pattern idempotente del toast.
  function mostraAvviso(testo) {
    var a = document.getElementById('petq-avviso');
    if (!a) {
      a = el('div', 'petq-avviso');
      a.id = 'petq-avviso';
      document.body.appendChild(a);
    }
    a.textContent = testo;
    a.classList.add('petq-avviso-visibile');
    if (avvisoTimer) clearTimeout(avvisoTimer);
    avvisoTimer = setTimeout(function () {
      a.classList.remove('petq-avviso-visibile');
      avvisoTimer = null;
    }, 7000);
  }

  function situazionePrioritaria(pet) {
    // Fase valigia (PROTOTIPO 2, Blocco 2): mentre il pet prepara la valigia girano le battute
    // del pool 'valigia' (e' l'ultimo avvertimento, ha la priorita' massima). Letto da
    // currentState perche' la fase valigia e' uno stato di partita, non del solo pet.
    if (currentState && currentState.valigia) return 'valigia';
    var soglie = (bilanciamento().soglie) || { critica: 25 };
    var critica = (typeof soglie.critica === 'number') ? soglie.critica : 25;
    if (pet.stats.fame < critica) return 'fame';
    if (pet.stats.igiene < critica) return 'sporco';
    if (pet.stats.felicita < critica) return 'triste';
    if (pet.stats.felicita > 75) return 'felice';
    return 'saluto';
  }

  function battutaAutomatica() {
    if (!currentState || !currentState.pet) return;
    // Il pet NON parla mentre dorme, si allena o è FUORI casa (missione/passeggiata): è
    // occupato o assente. Bug fix 5 lug 2026 (sonno) + 8 lug 2026 (passeggiata — report
    // fondatore: al cambio stanza il pet "rispuntava" con la vignetta pur essendo a spasso).
    if (currentState.sonno || currentState.allenamento || currentState.missione || currentState.passeggiata || currentState.gioco) return;
    // Il pet ha appena raccontato il rientro (quarta parete): lascialo finire.
    if (Date.now() - rientroDettoMs < BALLOON_MS) return;
    var situazione = situazionePrioritaria(currentState.pet);
    var testo = PETQ.dialog.say(currentState.pet, situazione, currentState);
    mostraBalloon(testo);
  }

  // Battuta A COMANDO (richiesta fondatore, brief regia clip social round 2, 5 ago 2026): fa
  // "recitare" il pet ADESSO davanti a OBS, senza aspettare che ne esca una spontanea. Differenze
  // volute rispetto a battutaAutomatica: NESSUNA guardia rientroDettoMs (la regia la vuole
  // SUBITO, anche a ridosso di un'altra battuta), e se il pet e' occupato/fuori NON resta muta —
  // un bottone silenzioso si legge come un bottone rotto (stessa regola di motivoOccupatoPerGioco,
  // v173). Riusa motivoOccupatoPerGioco perche' copre esattamente gli stessi cinque stati della
  // guardia qui sopra (sonno/allenamento/missione/passeggiata/gioco).
  function battutaARichiesta() {
    if (!currentState || !currentState.pet) { mostraToast('Nessun pet in casa.'); return; }
    var motivoOccupato = motivoOccupatoPerGioco(currentState);
    if (motivoOccupato) { mostraToast(motivoOccupato); return; }
    var situazioneOra = situazionePrioritaria(currentState.pet);
    var testoOra = PETQ.dialog.say(currentState.pet, situazioneOra, currentState);
    mostraBalloon(testoOra);
  }

  /* ---------- ATTREZZO DI SCENA: "di' la parola" (brief regia clip social round 4, 5 ago 2026) ----
   *
   * Serve il TIMING COMICO: nella clip il pet risponde con la parola concordata NELL'ISTANTE
   * scelto dalla regia, non quando gli pare. Non e' una feature di gioco — vive solo col pannello
   * debug (?debug), quindi sul telefono non esiste.
   *
   * Le quattro scelte, tutte dettate da come si gira davvero:
   * - Parola a TESTO LIBERO e non "una fra quelle insegnate": la clip 2 e' MID, ma la serie
   *   continua con SKILL ISSUE, -1000 AURA, LEEROY JENKINS. Si scrive e si gira.
   * - NIENTE limiti: non passa da care.teachWord, non tocca il salvataggio e non conta come parola
   *   del giorno ne' come canto del giorno. Sul set servono dieci take di fila della stessa
   *   battuta, e un attrezzo che al secondo ciak dice "gia' fatto oggi" e' inservibile.
   * - Bolla LUNGA (10s invece di 6,5): una vignetta che sparisce mentre inquadri e' ingirabile.
   *   Ripremendo il tasto riparte da capo — e' il "finche' non ripremo" del brief — ma da sola si
   *   chiude comunque, cosi' non resta appiccicata sul take dopo.
   * - Voce ANIMALESE forzata: sul PC il modo 'robotizzata' non trova il plugin nativo e
   *   ripiegherebbe sulla voce UMANA di sistema. In clip il pet non deve sembrare un navigatore
   *   satellitare, quindi si chiama direttamente la sintesi a formanti; la voce vera resta come
   *   ripiego se non esce nulla (leggende comprese: quelle sono umane per design).
   */
  var parolaScena = 'MID';
  // Pronuncia di scena (fondatore dal set, 11 ago 2026: "SKILL ISSUE la pronuncia male, come se
  // la leggessi in italiano — dice i-ss-u-e"). La sintesi a formanti legge con l'ORTOGRAFIA
  // ITALIANA (inSuoni, ed e' giusto cosi': e' la lingua in cui si insegnano le parole), quindi
  // l'inglese scritto esce storpiato. Sul set la bolla deve mostrare la GRAFIA giusta e la voce
  // dire i SUONI giusti: due campi. Vuoto = la voce dice la parola com'e' scritta (MID regge).
  // Trascrizioni pronte per la serie nel LEGGIMI (es. SKILL ISSUE -> "schil isciu").
  var pronunciaScena = '';
  var BALLOON_SCENA_MS = 10000;

  function recitaParolaScena(cantata) {
    if (!currentState || !currentState.pet) { mostraToast('Nessun pet in casa.'); return; }
    var parola = String(parolaScena || '').trim();
    if (!parola) { mostraToast('Scrivi prima la parola di scena.'); return; }

    mostraBalloon(parola, { muto: true, durataMs: BALLOON_SCENA_MS });

    // La bolla mostra la GRAFIA (parola), la voce dice i SUONI (pronuncia, se compilata):
    // e' il campo che salva l'inglese dalla lettura all'italiana di inSuoni.
    var testoVoce = String(pronunciaScena || '').trim() || parola;

    var pet = currentState.pet;
    if (cantata) {
      // audio.canta a mano e NON cantaSeCantante: il perk Cantante da Doccia e il regalino di
      // Felicita' una volta al giorno sono roba di gioco — sul set servirebbero solo a rendere il
      // secondo take diverso dal primo.
      if (PETQ.audio && PETQ.audio.canta) PETQ.audio.canta(testoVoce, PETQ.audio.voceDi(pet), linguaVoce());
      return;
    }
    // VIA DI FUGA del set (fondatore: "non suona neanche una parola"): il bottone «Voce: cambia
    // motore» ora vale anche per il tasto P. Sul motore 'sistema' la parola la dice il TTS —
    // voce umana intonata per razza (acuta e svelta per l'insettoide, bassa e lenta per il blob),
    // ma CHIARISSIMA e con la pronuncia vera della lingua. Se la sintesi a formanti non regge il
    // take, due click sul bottone e si gira comunque.
    if (PETQ.voce && PETQ.voce.modo && PETQ.voce.modo() === 'sistema') {
      PETQ.voce.pronuncia(testoVoce, pet);
      return;
    }
    var profilo = (PETQ.voce && PETQ.voce.profiloSintetico) ? PETQ.voce.profiloSintetico(pet) : null;
    var durata = (profilo && PETQ.audio && PETQ.audio.parlaParola) ? PETQ.audio.parlaParola(testoVoce, profilo, linguaVoce()) : 0;
    if (durata <= 0 && PETQ.voce) PETQ.voce.pronuncia(testoVoce, pet);
  }

  // ---------- ghost drag ----------

  function mostraGhost(sizePx, drawFn) {
    if (!ghostEl) {
      ghostEl = el('div', 'petq-ghost');
      ghostCanvas = document.createElement('canvas');
      ghostEl.appendChild(ghostCanvas);
      document.body.appendChild(ghostEl);
    }
    ghostEl.style.width = sizePx + 'px';
    ghostEl.style.height = sizePx + 'px';
    drawFn(ghostCanvas);
    ghostEl.style.display = 'block';
  }

  function muoviGhost(clientX, clientY) {
    if (!ghostEl) return;
    var size = parseInt(ghostEl.style.width, 10) || 48;
    ghostEl.style.left = (clientX - size / 2) + 'px';
    ghostEl.style.top = (clientY - size / 2 - 12) + 'px';
  }

  function nascondiGhost() {
    if (ghostEl) ghostEl.style.display = 'none';
  }

  function evidenziaHotzone(on) {
    var hz = document.getElementById('petq-hotzone');
    if (!hz) return;
    if (on) hz.classList.add('petq-hotzone-attiva');
    else hz.classList.remove('petq-hotzone-attiva');
  }

  function evidenziaHotzoneLetto(on) {
    var hz = document.getElementById('petq-hotzone-letto');
    if (!hz) return;
    if (on) hz.classList.add('petq-hotzone-attiva');
    else hz.classList.remove('petq-hotzone-attiva');
  }

  // ---------- interazioni sul canvas stanza (tap pet/poop, drag pet) ----------

  function poopSpots() {
    // se il modulo grafica espone le coordinate, usale; altrimenti fallback
    // sulle posizioni note (rooms.js POOP_SPOTS) con tolleranza generosa
    return (PETQ.rooms && (PETQ.rooms._poopSpots || PETQ.rooms.poopSpots)) ||
      [[16, 52], [54, 55], [92, 52]];
  }

  function hitPoop(p) {
    if (!currentState || !(currentState.poop > 0)) return -1;
    var spots = poopSpots();
    var n = Math.min(3, currentState.poop);
    for (var i = 0; i < n && i < spots.length; i++) {
      var cx = spots[i][0] + 2, cy = spots[i][1] + 1;
      if (Math.abs(p.x - cx) <= 9 && Math.abs(p.y - cy) <= 8) return i;
    }
    return -1;
  }

  function installaPointerCanvas(canvas) {
    canvas.addEventListener('pointerdown', function (e) {
      controllaAnimScaduta();
      annullaIdleAction(); // GDD: qualsiasi tocco sulla scena annulla la mini-azione idle
      if (animazioneInCorso || !currentState) return;
      var p = coordLogiche(canvas, e.clientX, e.clientY);

      // ORDINE DEI BERSAGLI: la cacca si controlla PER PRIMA, prima del pet.
      // Segnalazione del fondatore dopo l'allungamento della stanza: "ogni volta che clicco per
      // pulire la cacca e' come se coccolassi il pet". Con la stanza passata a 112x96 il pet e'
      // sceso in primo piano (si posiziona rispetto al fondo) e le cacche sono scese con lui,
      // finendo dentro il suo rettangolo di tocco: il pet veniva controllato per primo e si
      // prendeva il tap, quindi il giocatore coccolava invece di pulire. Il pet e' un bersaglio
      // GRANDE (16x16 piu' 3 di tolleranza) e la cacca uno PICCOLO e preciso: in un hit-test il
      // bersaglio piu' specifico deve sempre vincere, altrimenti quello grande lo mangia. Cosi'
      // il fix regge anche quando il pet cammina (l'idle "corre per casa" lo sposta di +-16px)
      // e non dipende da dove sono messe le cacche.
      var target = null, poopIdx = -1;
      poopIdx = hitPoop(p);
      if (poopIdx !== -1) {
        target = 'poop';
      } else if (lastPetRect && dentroRect(p, lastPetRect, 3)) {
        target = 'pet';
      } else if (currentStanza === 'cucina' && !currentState.missione &&
                 // hit-test frigo: stesso motivo di hotzoneLetto sopra, lasciato su temaRazza
                 // (rooms.js._frigoZona ha solo lab/ship, v. report).
                 dentroRect(p, hotzoneFrigo(temaRazza(currentState.pet)), 0)) {
        target = 'frigo';
      } else if (currentStanza === 'camera' && dentroRect(p, hotzoneScrivania(), 0)) {
        target = 'scrivania';
      }
      if (!target) return;

      canvasPointer = {
        id: e.pointerId, target: target, poopIdx: poopIdx,
        startX: e.clientX, startY: e.clientY, dragging: false
      };
      try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    });

    canvas.addEventListener('pointermove', function (e) {
      if (!canvasPointer || e.pointerId !== canvasPointer.id) return;

      var dx = e.clientX - canvasPointer.startX;
      var dy = e.clientY - canvasPointer.startY;
      var dist = Math.sqrt(dx * dx + dy * dy);

      var puoTrascinare = canvasPointer.target === 'pet' && !currentState.sonno && !currentState.allenamento &&
        (currentStanza === 'bagno' || currentStanza === 'camera');
      if (!canvasPointer.dragging && puoTrascinare && dist > 10) {
        canvasPointer.dragging = true;
        petDragging = true;
        var rect = canvas.getBoundingClientRect();
        var ghostSize = Math.round(rect.width * PET_PX / ROOM_W);
        mostraGhost(ghostSize, function (gc) {
          gc.width = PET_PX; gc.height = PET_PX;
          PETQ.sprites.draw(gc, petLikeDaState(currentState), { frame: 0 });
        });
        if (currentStanza === 'bagno') evidenziaHotzone(true);
        else evidenziaHotzoneLetto(true);
        disegnaStanzaEPet(currentState);
      }

      if (canvasPointer.dragging) {
        muoviGhost(e.clientX, e.clientY);
      } else if (dist > 14) {
        canvasPointer.tapAnnullato = true; // troppo movimento: niente tap
      }
    });

    function fine(e, annullato) {
      if (!canvasPointer || e.pointerId !== canvasPointer.id) return;
      var cp = canvasPointer;
      canvasPointer = null;

      if (cp.dragging) {
        petDragging = false;
        nascondiGhost();
        evidenziaHotzone(false);
        evidenziaHotzoneLetto(false);
        var p = coordLogiche(canvas, e.clientX, e.clientY);
        if (!annullato && currentStanza === 'bagno' && dentroRect(p, HOTZONE_VASCA, 0)) {
          avviaLavaggio();
        } else if (!annullato && currentStanza === 'camera' &&
                   // hit-test letto: stesso motivo di sopra, lasciato su temaRazza.
                   dentroRect(p, hotzoneLetto(temaRazza(currentState.pet)), 0)) {
          provaAndareALetto();
        } else {
          disegnaStanzaEPet(currentState);
        }
        return;
      }

      if (annullato || cp.tapAnnullato) return;

      if (cp.target === 'pet') {
        if (currentState.sonno) {
          eseguiSveglia();
        } else {
          eseguiCoccola();
        }
      } else if (cp.target === 'poop') {
        eseguiPuliziaBisogni(cp.poopIdx);
      } else if (cp.target === 'frigo') {
        apriFrigo();
      } else if (cp.target === 'scrivania') {
        avviaScrittura();
      }
    }

    canvas.addEventListener('pointerup', function (e) { fine(e, false); });
    canvas.addEventListener('pointercancel', function (e) { fine(e, true); });
  }

  // ---------- azioni di gioco (flussi touch) ----------

  function eseguiCoccola() {
    if (currentState.allenamento) {
      mostraToast((currentState.pet.nome || traduci('Il pet')) + traduci(' si sta allenando.'));
      return;
    }
    var r = PETQ.care.coccola(currentState);
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    if (r.ok) {
      battutaAutomatica(); // battuta contestuale per situazione
    } else if (r.battutaPool) {
      // Cap coccole raggiunto (FIX battute personalita'): pesca dal pool dedicato invece
      // del messaggio generico r.msg. Se il pool e' vuoto per quella personalita' (socio non
      // ha ancora scritto le battute, o file non ricaricato), dialog.say ritorna '...' come
      // placeholder universale: in quel caso ripieghiamo sul messaggio fisso di care.js.
      var battuta = PETQ.dialog.say(currentState.pet, r.battutaPool, currentState);
      mostraBalloon((battuta && battuta !== '...') ? battuta : r.msg);
    } else {
      mostraBalloon(r.msg);
    }
  }

  function eseguiPuliziaBisogni(spotIdx) {
    var spots = poopSpots();
    var s = spots[spotIdx] || spots[0];
    var r = PETQ.care.cleanPoop(currentState);
    if (r.ok && PETQ.audio) PETQ.audio.suona('pulisci');
    PETQ.save.save(currentState);
    aggiornaHud(currentState);

    effetto = { tipo: 'puff', x: s[0] + 2, y: s[1] + 1, step: 0 };
    disegnaStanzaEPet(currentState);
    dopoMs(160, function () {
      if (effetto && effetto.tipo === 'puff') {
        effetto.step = 1;
        disegnaStanzaEPet(currentState);
      }
    });
    dopoMs(340, function () {
      if (effetto && effetto.tipo === 'puff') {
        effetto = null;
        disegnaStanzaEPet(currentState);
      }
    });

    mostraBalloon(r.msg);
    renderAzioni();
  }

  function avviaLavaggio() {
    animazioneInCorso = true;
    effetto = { tipo: 'wash' };
    disegnaStanzaEPet(currentState);

    animaTimed(1500, function () {
      effetto = null;
      animazioneInCorso = false;
      var r = PETQ.care.wash(currentState);
      dopoAzione(r);
      // Vasca idromassaggio (arredo con effettoSpeciale 'igiene_extra_lavaggio'): i +5 Igiene
      // extra non si vedono nella barra (il lavaggio la porta gia' a 100), diventano un CREDITO
      // che assorbe il calo successivo. Va detto, altrimenti quell'arredo da 150 monete sembra
      // non fare niente.
      if (r && r.ok && r.igieneExtra > 0) {
        mostraToast(traduci('🛁 Idromassaggio: ') + r.igieneExtra + traduci(' punti Igiene di scorta.'));
      }
      // Idrofobico protesta al lavaggio (HOOK NUOVO, checklist fondatore): se il pet ha una
      // battuta-talento 'lavato', la mostra al posto del "Pulito e profumato" di dopoAzione.
      if (currentState && currentState.pet) {
        var battutaLavato = PETQ.dialog.battutaTalento(currentState.pet, 'lavato', currentState);
        if (battutaLavato) mostraBalloon(battutaLavato);
      }
    });
  }

  // Tap sulla scrivania in camera (PROTOTIPO-2.md punto 6 "Diario in camera"): il pet "va a
  // scrivere" (~2s, stesso pattern animaTimed di avviaLavaggio/avviaAllenamento: completamento
  // garantito anche se il timer viene congelato in background), poi si apre la pagina diario
  // col riassunto della giornata corrente. Non disponibile mentre il pet e' occupato (sonno/
  // allenamento/missione): in quei casi solo un toast, niente animazione ne' pagina.
  var SCRITTURA_MS = 2000;

  function avviaScrittura() {
    if (!currentState || !currentState.pet) return;
    if (currentState.sonno || currentState.allenamento || currentState.missione) {
      mostraToast((currentState.pet.nome || traduci('Il pet')) + traduci(' ora non può: è occupato.'));
      return;
    }
    if (animazioneInCorso) return;
    annullaIdleAction();

    animazioneInCorso = true;
    effetto = { tipo: 'scrivania' };
    disegnaStanzaEPet(currentState);

    animaTimed(SCRITTURA_MS, function () {
      effetto = null;
      animazioneInCorso = false;
      mostraDiario(currentState);
    });
  }

  // Drag del pet nel letto (camera, GDD "Energia e sonno" aggiornato): "Dormire" e' un unico
  // gesto, niente piu' rifiuto prima delle 21 (fix di questa sessione: era l'ostacolo che
  // impediva di testare il sonno col debug ×600, perche' l'ora reale non avanzava mai).
  // La modalita' (riposino/notturno) la decide PETQ.pet.avviaSonno in base all'orologio DI
  // GIOCO corrente (PETQ.clock.oraGioco): il pet PUO' SEMPRE essere messo a dormire.
  function provaAndareALetto() {
    if (!currentState || !currentState.pet) return;
    // FIX "si puo' mandare a letto il pet mentre gioca" (timer congelato): la guardia copriva
    // solo sonno/missione/allenamento, mancavano passeggiata e gioco — con la guardia bucata si
    // otteneva il doppio stato sonno+gioco (il timer del gioco si congela mentre dorme, e il pet
    // sparisce dalla stanza: dormeAltrove/giocaAltrove sono mutuamente esclusivi su quale stanza
    // lo mostra). RIUSATA petOccupatoPerGioco (stessa condizione sulle cinque occupazioni, gia'
    // usata da usaGiocattolo/eseguiGiocoManiNude): una condizione duplicata a mano e' la prossima
    // che si dimentica di aggiornare quando arrivera' un'attivita' numero sei.
    if (petOccupatoPerGioco(currentState)) {
      // Stesso trattamento di usaGiocattolo/eseguiGiocoManiNude (v173, "il pet non puo' giocare"):
      // un drag rifiutato in silenzio si legge come un gesto che non ha funzionato, non come una
      // regola del gioco. motivoOccupatoPerGioco copre gia' tutti e cinque i casi.
      var motivo = motivoOccupatoPerGioco(currentState);
      if (motivo) mostraToast(motivo);
      return;
    }
    PETQ.pet.avviaSonno(currentState, true);
    PETQ.save.save(currentState);
    disegnaStanzaEPet(currentState);
    renderAzioni();
    mostraBalloon(PETQ.dialog.say(currentState.pet, 'dormire', currentState));
  }

  // Tap sul pet mentre dorme (canvas stanza): equivale al tasto Sveglia, stessa regola dei
  // minimi (v. eseguiSveglia sotto, condivisa col bottone renderizzato in renderAzioniCamera).
  function eseguiSveglia() {
    tentaSveglia();
  }

  // Tenta di svegliare il pet: rispetta il minimo di ore dormite (GDD: riposino 1h, notturno
  // 5h). Sotto il minimo niente sveglia, solo una battuta di protesta (bottone disabilitato
  // nella UI, ma questa funzione e' la stessa richiamata dal tap sul pet quindi la guardia
  // va ripetuta qui). Ritorna true se la sveglia e' avvenuta.
  function tentaSveglia() {
    if (!currentState || !currentState.sonno || !PETQ.pet) return false;
    var stato = PETQ.pet.puoSvegliare(currentState);
    if (!stato.puo) {
      mostraBalloon(PETQ.dialog.say(currentState.pet, 'sonno', currentState) ||
        ((currentState.pet.nome || traduci('Il pet')) + traduci(' sta ancora dormendo, lascialo riposare.')));
      return false;
    }
    var risultato = PETQ.pet.svegliaManuale(currentState);
    PETQ.save.save(currentState);
    disegnaStanzaEPet(currentState);
    aggiornaHud(currentState);
    renderAzioni();
    if (risultato) mostraBalloon(PETQ.dialog.say(currentState.pet, risultato.battuta, currentState));
    avvisaMoneteNotturne(risultato);
    return true;
  }

  // Dai da mangiare (GDD "Economia" -> "Spesa e dispensa"): sempre gratis, il pagamento e'
  // gia' avvenuto allo shop. PETQ.care.feed consuma direttamente 1 porzione da state.dispensa
  // per nome (v. care.js consumaDaDispensa): qui non serve piu' fare lo splice manuale ne'
  // controllare le monete, solo reagire all'esito (frigo vuoto per quel cibo = errore raro,
  // capita solo per doppio-tap velocissimo su qty=1).
  function eseguiFeed(cibo, cardEl, dispensaIdx) {
    if (currentState.missione) {
      shakeCard(cardEl);
      mostraToast((currentState.pet.nome || traduci('Il pet')) + traduci(' è in missione: la pappa può aspettare.'));
      return;
    }
    if (currentState.allenamento) {
      shakeCard(cardEl);
      mostraToast((currentState.pet.nome || traduci('Il pet')) + traduci(' si sta allenando.'));
      return;
    }
    // Interruttore Cuoco acceso: questo tap CUCINA invece di servire crudo. Si spegne sempre,
    // riuscito o no — se restasse acceso dopo un rifiuto il giocatore non capirebbe piu' in quale
    // modalita' si trova, e il turno del cuoco lo protegge care.cucinaEServi (non si consuma se
    // il pasto viene rifiutato).
    var r;
    if (cuocoAttivo && PETQ.care.cucinaEServi) {
      cuocoAttivo = false;
      r = PETQ.care.cucinaEServi(currentState, cibo);
    } else {
      r = PETQ.care.feed(currentState, cibo);
    }
    if (!r.ok) {
      shakeCard(cardEl);
      // Rifiuto per talento "Fissato con la Dieta" (blocca_cibo): se il pet ha una battuta-talento
      // 'rifiuta_dolce', mostrala nel balloon invece del msg secco (HOOK NUOVO, checklist fondatore).
      var bloccatoDaTalento = PETQ.talenti && PETQ.talenti.ciboBloccato &&
        PETQ.talenti.ciboBloccato(currentState, cibo.categoria);
      if (bloccatoDaTalento) {
        var battutaRifiuto = PETQ.dialog.battutaTalento(currentState.pet, 'rifiuta_dolce', currentState);
        if (battutaRifiuto) mostraBalloon(battutaRifiuto);
        else mostraToast(r.msg);
      } else {
        mostraToast(r.msg);
      }
      return;
    }
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    renderAzioni();

    effetto = { tipo: 'crumbs' };
    disegnaStanzaEPet(currentState);
    dopoMs(1300, function () {
      if (effetto && effetto.tipo === 'crumbs') {
        effetto = null;
        disegnaStanzaEPet(currentState);
      }
    });

    // battuta 'felice' occasionale, altrimenti conferma del pasto
    if (PETQ.rng.rand() < 0.35) {
      mostraBalloon(PETQ.dialog.say(currentState.pet, 'felice', currentState));
    } else {
      mostraBalloon(r.msg);
    }
  }

  // Allenamento a tempo (bilanciamento.md "Durata allenamento", decisione fondatore: attivita'
  // a tempo come una missione, non piu' un salto d'orologio istantaneo). Tap sulla card -> una
  // breve animazione locale di "avvio" (stesso feedback immediato di prima), poi PETQ.care.train
  // AVVIA l'attivita' (state.allenamento): da qui in poi e' renderAzioniSalone/disegnaStanzaEPet
  // (guidati da state.allenamento, non da `effetto`/animazioneInCorso locali) a mostrare lo
  // stato "in corso" con countdown finche' non arriva il completamento (v.
  // controllaAllenamentoScaduto), esattamente come le missioni mostrano "torna tra X".
  // Allenamenti esauriti oggi? (PROTOTIPO 2, Blocco 9, Gruppo A, "allenamenti_giorno=2",
  // Predestinato): confronta quanti se ne sono gia' fatti oggi (care.allenamentiFattiOggi,
  // che azzera da solo a cambio data) col massimo concesso dai talenti attivi (default 1).
  function allenamentoEsauritoOggi(state) {
    var fatti = (PETQ.care && PETQ.care.allenamentiFattiOggi) ? PETQ.care.allenamentiFattiOggi(state) : (state.trainDay === PETQ.clock.giornoCorrente(state) ? 1 : 0);
    var max = (PETQ.talenti && PETQ.talenti.allenamentiPerGiorno) ? PETQ.talenti.allenamentiPerGiorno(state) : 1;
    return fatti >= max;
  }

  function avviaAllenamento(prop, cardEl) {
    if (animazioneInCorso) return;
    annullaIdleAction();
    if (allenamentoEsauritoOggi(currentState)) {
      mostraToast(traduci('Allenamento già fatto oggi.'));
      return;
    }
    if (currentState.allenamento) {
      mostraToast((currentState.pet.nome || traduci('Il pet')) + traduci(' si sta già allenando.'));
      return;
    }
    animazioneInCorso = true;
    effetto = { tipo: 'train', prop: prop.id };
    disegnaStanzaEPet(currentState);

    animaTimed(1200, function () {
      effetto = null;
      animazioneInCorso = false;
      var r = PETQ.care.train(currentState, prop.stat);
      if (!r.ok) {
        mostraToast(r.msg);
        disegnaStanzaEPet(currentState);
        renderAzioni();
        return;
      }
      dopoAzione(r);
    });
  }

  function shakeCard(cardEl) {
    if (!cardEl) return;
    cardEl.classList.remove('petq-shake');
    // forza il reflow per far ripartire l'animazione
    void cardEl.offsetWidth;
    cardEl.classList.add('petq-shake');
    setTimeout(function () { cardEl.classList.remove('petq-shake'); }, 450);
  }

  // Dopo un'azione (train/teachWord/cura...): salva, ridisegna e controlla il ciclo sonno.
  // Il controllo e' importante soprattutto per l'allenamento (bilanciamento.md "Durata
  // allenamento"): avanzando l'orologio di gioco di 90 minuti puo' far scattare l'ora del
  // crollo automatico (23:00) o, in teoria con offset di giornata estremi, un nuovo giorno —
  // stesso meccanismo idempotente gia' usato dal tick/boot (controllaSonnoScaduto).
  function dopoAzione(risultato) {
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    disegnaStanzaEPet(currentState);
    renderAzioni();
    if (risultato && risultato.battutaPool) {
      mostraBalloon(PETQ.dialog.say(currentState.pet, risultato.battutaPool, currentState));
    } else if (risultato && risultato.msg) {
      mostraBalloon(risultato.msg);
    }
    controllaSonnoScaduto();
  }

  // ---------- azioni per stanza ----------

  function renderAzioni() {
    var azioni = document.getElementById('petq-azioni');
    if (!azioni || !currentState) return;
    azioni.innerHTML = '';

    // Fase valigia (PROTOTIPO 2, Blocco 2): avviso in testa alle azioni in OGNI stanza — e'
    // l'ultimo avvertimento, il giocatore deve rimediare (Felicità e Salute sopra soglia) prima
    // del prossimo nuovo giorno o il pet parte.
    if (currentState.valigia && currentState.pet) {
      var nomeV = currentState.pet.nome || traduci('Il pet');
      azioni.appendChild(el('p', 'petq-valigia-avviso',
        '⚠ ' + nomeV + traduci(' ha preparato la valigia! Risolleva Felicità e Salute prima del prossimo giorno, o se ne andrà.')));
    }

    // Passeggiata in corso (fix playtest 8 lug 2026 "non c'è timer"): nelle stanze di casa il
    // pet non c'è — al posto delle azioni un hint unico col countdown (id aggiornato dal tick,
    // v. aggiornaIndicatorePasseggiata). La tab Missioni passa oltre: ha mappa + hint suo.
    if (currentState.passeggiata && currentStanza !== 'missioni') {
      var hintP = el('p', 'petq-hint');
      hintP.id = 'petq-passeggiata-hint';
      hintP.textContent = (currentState.pet.nome || traduci('Il pet')) + traduci(' è a passeggio: torna tra ~') + minutiPasseggiataRimasti(currentState) + 'm. 🚶';
      azioni.appendChild(hintP);
      return;
    }

    if (currentStanza === 'cucina') renderAzioniCucina(azioni);
    else if (currentStanza === 'bagno') renderAzioniBagno(azioni);
    else if (currentStanza === 'camera') renderAzioniCamera(azioni);
    else if (currentStanza === 'missioni') renderTabMissioni(azioni);
    else renderAzioniSalone(azioni);
  }

  // --- camera: hint + tasto Sveglia (l'unica altra azione è drag sul canvas: letto) ---

  function renderAzioniCamera(container) {
    var nome = currentState.pet.nome || traduci('il pet');
    if (currentState.sonno) {
      var modalita = currentState.sonno.modalita === 'riposino' ? traduci('un riposino') : traduci('la nanna notturna');
      container.appendChild(el('p', 'petq-hint', nome + traduci(' sta facendo ') + modalita + '.'));
      container.appendChild(costruisciTastoSveglia(nome));
    } else if (currentState.missione) {
      container.appendChild(el('p', 'petq-hint', nome + traduci(' è in missione: il letto aspetta il suo ritorno.')));
    } else if (currentState.allenamento) {
      container.appendChild(el('p', 'petq-hint', nome + traduci(' si sta allenando: il letto aspetta che finisca.')));
    } else {
      container.appendChild(el('p', 'petq-hint', traduci('Trascina ') + nome + traduci(' nel letto per farlo dormire: riposino di giorno, nanna vera dalle 21:00. Tocca la scrivania per leggere il diario di oggi.')));
    }
  }

  // Tasto Sveglia (GDD "Energia e sonno"): sempre visibile mentre dorme, ma disabilitato
  // sotto il minimo di ore dormite (riposino 1h, notturno 5h) con il motivo esplicito.
  function costruisciTastoSveglia(nome) {
    var wrap = el('div', 'petq-riga-azione');
    var stato = PETQ.pet.puoSvegliare(currentState);
    var btn = el('button', 'petq-btn', traduci('Sveglia'));
    if (!stato.puo) {
      btn.disabled = true;
      var motivo = traduci('Sta ancora riposando, ancora ') + stato.minutiMancanti + 'm.';
      btn.title = motivo;
      wrap.appendChild(btn);
      wrap.appendChild(el('p', 'petq-hint', motivo));
      return wrap;
    }
    btn.addEventListener('click', function () { tentaSveglia(); });
    wrap.appendChild(btn);
    return wrap;
  }

  function trovaCibo(nome) {
    var data = window.PETQ.content && window.PETQ.content.data;
    var cibi = (data && data.cibi) || [];
    for (var i = 0; i < cibi.length; i++) {
      if (cibi[i].nome === nome) return cibi[i];
    }
    return null;
  }

  // I quattro companion del Supporter Pack NON stanno in content/arredi.md (li gestiamo noi, non
  // il socio): senza questa scheda trovaArredoInfo tornava null e la Collezione li descriveva
  // "solo collezione", cioe' "non fa niente" — su creature che lavorano ogni giorno. E li mandava
  // tutti in salone, la stanza di ripiego, invece che dove ha senso.
  // stanza = dove il gioco propone di piazzarli; bonus = cosa fanno, in una riga.
  var COMPANION_PACK_INFO = {
    'Topo Chef': { stanza: 'cucina', bonus: 'cucina un pasto al giorno' },
    'Lumaca delle Pulizie': { stanza: 'bagno', bonus: 'pulisce tutte le cacche, una volta al giorno' },
    'Piccione Postino': { stanza: 'salone', bonus: 'porta 15-25 monete al giorno' },
    'Criceto Dinamo': { stanza: 'camera', bonus: '+30 Energia al giorno' }
  };

  // Stessi 4 nomi di COMPANION_PACK_INFO sopra, in ordine fisso: usati per la vetrina del pack
  // (card hero nel negozio + popup una-tantum, compiti separati che condividono lo stesso disegno
  // — v. disegnaCompanionPackHero sotto).
  var NOMI_COMPANION_PACK = ['Topo Chef', 'Lumaca delle Pulizie', 'Piccione Postino', 'Criceto Dinamo'];

  // Disegna i quattro companion del pack in fila su un canvas gia' dimensionato dal chiamante
  // (card hero: 128x40 circa; popup: stesso canvas riusato identico). drawArredo normalizza il
  // nome da solo (v. rooms.js normalizzaArredo/ARREDI: 'Topo Chef' -> 'topochef'), quindi qui i
  // nomi si passano cosi' come sono scritti in COMPANION_PACK_INFO, nessuna normalizzazione a
  // mano. Statico (nessun parametro frame): e' una vetrina promozionale, non la stanza vera —
  // l'idle respiro dei companion (v. rooms.js scostamentoCompanion) resta un lusso della stanza
  // vera, qui basta il disegno fermo. Difensiva al 100% (try/catch attorno a tutto): se il modulo
  // grafica manca o un disegno va storto, il canvas resta vuoto ma la card/il popup reggono lo
  // stesso — MAI un throw che porti giu' con se' la sezione Sostieni o il popup.
  function disegnaCompanionPackHero(canvas) {
    try {
      if (!canvas || !PETQ.rooms || !PETQ.rooms.drawArredo) return;
      var g = canvas.getContext('2d');
      if (!g) return;
      g.imageSmoothingEnabled = false;
      var larghezzaSlot = canvas.width / NOMI_COMPANION_PACK.length;
      var offsetY = Math.round((canvas.height - 16) / 2);
      for (var i = 0; i < NOMI_COMPANION_PACK.length; i++) {
        var offsetX = Math.round(i * larghezzaSlot + (larghezzaSlot - 16) / 2);
        PETQ.rooms.drawArredo(g, NOMI_COMPANION_PACK[i], offsetX, offsetY);
      }
    } catch (e) { /* mai un throw: la card/il popup reggono senza canvas */ }
  }

  // Arredi che si ottengono SOLO tenendo viva la carica (streak): non comprabili, non droppabili.
  // Il bonus NON passa da bonusPassivi (che legge il catalogo del socio, dove questo oggetto non
  // c'e'): lo applica arredi.js energiaDecayMultArredi, x0,75 sul calo Energia e solo se PIAZZATO.
  // Qui c'e' solo il testo che il giocatore legge in Collezione, e deve dire la verita'.
  var ARREDO_RITRATTO = 'Il Tuo Ritratto';

  var ARREDI_STREAK_INFO = {
    'Caricatore da Viaggio': { stanza: 'camera', bonus: 'l\'Energia cala il 25% più lentamente' },
    // Il quadro del Ritrattista: nessun bonus, e non e' una dimenticanza. E' un oggetto
    // affettivo — l'unico arredo del gioco che parla del GIOCATORE e non del pet.
    'Il Tuo Ritratto': { stanza: 'salone', bonus: 'te l\'ha disegnato lui' }
  };

  function trovaArredoInfo(nome) {
    var data = window.PETQ.content && window.PETQ.content.data;
    var arredi = (data && data.arredi) || [];
    for (var i = 0; i < arredi.length; i++) {
      if (arredi[i].nome === nome) return arredi[i];
    }
    // ripiego: scheda dei companion del pack, cosi' Collezione e negozio li descrivono davvero
    if (COMPANION_PACK_INFO[nome]) {
      return { nome: nome, stanza: COMPANION_PACK_INFO[nome].stanza, bonus: COMPANION_PACK_INFO[nome].bonus };
    }
    // Stesso ripiego per il premio dei 7 giorni di carica (streak): non e' in content/arredi.md
    // perche' non e' roba del socio, e senza questa riga la Collezione direbbe di nuovo "solo
    // collezione" senza spiegare cos'e' (identico difetto gia' visto sui companion).
    if (ARREDI_STREAK_INFO[nome]) {
      return { nome: nome, stanza: ARREDI_STREAK_INFO[nome].stanza, bonus: ARREDI_STREAK_INFO[nome].bonus };
    }
    return null;
  }

  // cibo da dispensa non presente in cibi.md: fallback neutro (fame +20 default locale)
  function ciboFallback(nome) {
    console.warn('PETQ.ui: cibo dispensa "' + nome + '" non trovato in content.data.cibi, uso fallback');
    // effetti: [] coerente col Tier 2 (v. content.js parseCibi) — il fallback non ha effetti,
    // ne' RPG ne' benessere: sfama e basta.
    return { nome: nome, categoria: 'base', costo: 0, fame: 20, stat: 0, statNome: null, effetti: [] };
  }

  // --- cucina: tap sul FRIGO -> menu del cibo POSSEDUTO (GDD "Economia" -> "Spesa e
  // dispensa"): niente più barra cibo orizzontale, niente più costo qui (già pagato allo
  // shop). Il pannello si apre/chiude con frigoAperto; ogni voce ha tap (dà subito) o drag
  // (riusa lo stesso gesto della vecchia barra) verso il pet in scena.

  function apriFrigo() {
    if (!currentState || currentState.missione) return;
    annullaIdleAction();
    frigoAperto = !frigoAperto;
    renderAzioni();
  }

  function renderAzioniCucina(container) {
    var nome = currentState.pet.nome || traduci('il pet');
    if (currentState.sonno) {
      container.appendChild(el('p', 'petq-hint', nome + traduci(' sta dormendo in camera: la pappa aspetta il suo risveglio.')));
      return;
    }
    var hintCucina = currentState.missione
      ? nome + traduci(' è in missione: la pappa aspetta il suo ritorno.')
      : traduci('Tocca il frigo per vedere cosa avete in casa.');
    container.appendChild(el('p', 'petq-hint', hintCucina));

    if (currentState.missione) return;

    var dispensa = currentState.dispensa || [];
    if (!frigoAperto) {
      var apriBtn = el('button', 'petq-btn petq-btn-piccolo', traduci('Apri frigo (') + dispensa.length + ')');
      apriBtn.addEventListener('click', apriFrigo);
      container.appendChild(apriBtn);
      return;
    }

    var chiudiBtn = el('button', 'petq-btn petq-btn-piccolo', traduci('Chiudi frigo'));
    chiudiBtn.addEventListener('click', apriFrigo);
    container.appendChild(chiudiBtn);

    /* Cuoco di Casa (perk corso_cucina): interruttore, non un bottone che cucina da solo.
     * Il giocatore deve SCEGLIERE il piatto — cucinare d'autorita' il primo cibo della dispensa
     * gli toglierebbe l'unica decisione interessante del perk. Acceso l'interruttore, il prossimo
     * tap su un cibo lo cucina invece di servirlo crudo.
     * Il bottone c'e' solo se il perk c'e' E il turno di oggi e' libero: un bottone che rifiuta
     * sempre e' peggio di un bottone assente. */
    if (PETQ.care.haPerkCuoco && PETQ.care.haPerkCuoco(currentState) &&
        !PETQ.care.cuocoUsatoOggi(currentState)) {
      var cuocoBtn = el('button', 'petq-btn petq-btn-piccolo' + (cuocoAttivo ? ' petq-btn-primario' : ''),
        cuocoAttivo ? traduci('Annulla: servi normale') : traduci('👨‍🍳 Fatti cucinare il pranzo'));
      cuocoBtn.addEventListener('click', function () {
        cuocoAttivo = !cuocoAttivo;
        renderAzioni();
      });
      container.appendChild(cuocoBtn);
      if (cuocoAttivo) {
        container.appendChild(el('p', 'petq-hint', traduci('Scegli cosa ti cucina: sazia di più e l\'effetto è più generoso.')));
      }
    } else if (cuocoAttivo) {
      cuocoAttivo = false; // il turno e' finito mentre l'interruttore era acceso
    }

    if (dispensa.length === 0) {
      container.appendChild(el('p', 'petq-vuoto', traduci('Il frigo è vuoto: fai un salto al Negozio sulla mappa.')));
      return;
    }

    var lista = el('div', 'petq-food-bar');
    for (var i = 0; i < dispensa.length; i++) {
      (function (voce, idx) {
        var cibo = trovaCibo(voce.nome) || ciboFallback(voce.nome);
        // Talenti (PROTOTIPO 2, Blocco 9, Gruppo A, "blocca_cibo=dolce", Fissato con la
        // Dieta): la card appare disabilitata con il motivo, invece di lasciar provare e
        // rifiutare al tap/drag (care.feed comunque rifiuta lato dati, questa e' solo UX).
        var bloccato = PETQ.talenti && PETQ.talenti.ciboBloccato && PETQ.talenti.ciboBloccato(currentState, cibo.categoria);
        var card = el('div', 'petq-food-card petq-food-card-dispensa' + (bloccato ? ' petq-food-card-bloccata' : ''));

        var icona = document.createElement('canvas');
        icona.width = 12; icona.height = 12;
        icona.className = 'petq-food-icon';
        disegnaCibo(icona, cibo);
        card.appendChild(icona);

        card.appendChild(el('div', 'petq-food-nome', traduci(cibo.nome)));
        card.appendChild(el('div', 'petq-food-tag', 'x' + (voce.qty || 0)));
        var effettiEl = el('div', 'petq-food-costo');
        effettiEl.appendChild(descriviCiboNodi(cibo));
        card.appendChild(effettiEl);

        if (bloccato) {
          // NOTA: 'Fissato con la Dieta' e' il NOME del talento (content, talenti.md), CHIAVE
          // dati per le condizioni missione `talento:x` (v. content.js parseTermine) — non va
          // tradotto nel content. FIX segnalazione fondatore 28 lug 2026 "i tratti non sono
          // tradotti": ora ha una voce dedicata nel dizionario EN (i18n.js), quindi si traduce
          // a schermo con traduci() esattamente come la frase attorno, invece di restare
          // hardcodato in italiano.
          var motivoBlocco = traduci('Il talento ') + traduci('Fissato con la Dieta') + traduci(' non tocca i dolci');
          card.title = motivoBlocco;
          card.appendChild(el('div', 'petq-food-bloccata-hint', motivoBlocco));
          card.addEventListener('click', function () { mostraToast(motivoBlocco + '.'); });
          lista.appendChild(card);
          return;
        }

        card.addEventListener('click', function () {
          if (!foodPointer) eseguiFeed(cibo, card, idx);
        });
        installaDragCibo(card, cibo, idx);
        lista.appendChild(card);
      })(dispensa[i], i);
    }
    container.appendChild(lista);
  }

  // Riga effetti di un cibo (card del frigo e riga del negozio): '+35 fame, +3 Forza, -1 Velocità'.
  // NOTA: i nomi degli effetti sono CHIAVI dato (v. content.js EFFETTO_ALIAS: 'forza'/'velocita'/
  // 'felicita'... minuscolo senza accenti) — a schermo passano dalla mappa etichette, mai grezzi.
  // Il segno arriva SEMPRE da segno(): un malus deve leggersi '-2 Carisma', mai '+-2 Carisma'.
  function descriviCibo(cibo) {
    var testo = segno(cibo.fame || 0) + ' ' + traduci('fame');
    var lista = effettiDiCibo(cibo);
    for (var i = 0; i < lista.length; i++) {
      var ef = lista[i];
      // '+N stat RPG casuale' (v. content.js RE_RPG_CASUALE): non ha un nome-stat da stampare,
      // la stat la estrae il motore a ogni porzione -> si legge '+2 a una stat a caso'.
      var etichetta = (ef.tipo === 'rpg_casuale') ?
        traduci('a una stat a caso') : traduci(EFFETTO_CIBO_LABEL[ef.nome] || ef.nome);
      testo += ', ' + segno(ef.valore || 0) + ' ' + etichetta;
    }
    return testo;
  }

  // Variante DOM di descriviCibo, per i due punti che mostrano la riga effetti a schermo (card
  // dispensa e riga negozio): con l'arrivo dei cibi del Disonore (revamp cibi, v157) esistono ora
  // effetti NEGATIVI (es. "Kebabbone delle Tre" -> +45 fame, +1 Forza, -15 Igiene) ma l'intera
  // riga era UN solo elemento colorato di un unico colore (oro/grigio a seconda del chiamante):
  // il malus -15 Igiene aveva lo stesso aspetto del bonus +1 Forza e passava inosservato.
  // Ritorna un DocumentFragment con UNO <span> per pezzo (stessa sequenza/virgole/segni di
  // descriviCibo, invariata), classe '.petq-effetto-malus' (rosso, gia' usato in .petq-food-costo-no)
  // sui pezzi con valore negativo. descriviCibo resta com'era: torna una stringa piatta, usata
  // dove serve solo testo semplice (non ha altri chiamanti oggi, ma non si tocca per non rischiare
  // di rompere un uso futuro tipo toast/scheda oggetto).
  function descriviCiboNodi(cibo) {
    var frammento = document.createDocumentFragment();

    function pezzo(valore, etichetta) {
      var span = document.createElement('span');
      if ((valore || 0) < 0) span.className = 'petq-effetto-malus';
      span.textContent = segno(valore || 0) + ' ' + etichetta;
      return span;
    }

    frammento.appendChild(pezzo(cibo.fame || 0, traduci('fame')));

    var lista = effettiDiCibo(cibo);
    for (var i = 0; i < lista.length; i++) {
      var ef = lista[i];
      var etichetta = (ef.tipo === 'rpg_casuale') ?
        traduci('a una stat a caso') : traduci(EFFETTO_CIBO_LABEL[ef.nome] || ef.nome);
      frammento.appendChild(document.createTextNode(', '));
      frammento.appendChild(pezzo(ef.valore || 0, etichetta));
    }

    return frammento;
  }

  // ---------- effetti di indossabili / armi (stessa formattazione col segno dei cibi) ----------
  // FONTE UNICA = content/arredi.md. Prima queste descrizioni erano due mappe scritte a mano qui
  // dentro (INDOSSABILE_EFFETTO 7 voci, ARMA_EFFETTO 10): dei 38 indossabili del contenuto, 31
  // non dicevano NIENTE nell'Armadio. Ora si legge la colonna Effetti gia' parsata, con gli helper
  // di missions.js (_voceContenuto: indossabili/armi/arredi) — le 9 armi di M7/M20 sono ANCHE
  // arredi normali, quindi i loro effetti stanno nelle tabelle arredi, esattamente come li cerca
  // missions.bonusArmaEquip: una sola regola per il bonus e per il testo che lo racconta.
  function voceEquipContenuto(nome, categoria) {
    if (!nome || !PETQ.missions || !PETQ.missions._voceContenuto) return null;
    if (categoria === 'arma') {
      return PETQ.missions._voceContenuto('armi', nome) || PETQ.missions._voceContenuto('arredi', nome);
    }
    return PETQ.missions._voceContenuto('indossabili', nome);
  }

  // Righe di arredi.md senza stat: la colonna Effetti contiene una nota tecnica per chi programma
  // ("EFFETTO SPECIALE gestito in care.js: ..."), non una frase da mostrare al giocatore. Qui la
  // versione leggibile, per NOME. Oggi ce n'e una sola.
  var EQUIP_SPECIALE_TXT = {
    'Completo da Chef': 'primo pasto di ogni categoria del giorno → +1 stat extra'
  };

  // DocumentFragment con gli effetti di un indossabile/arma: '+2 Carisma, +1 Intelligenza mentre
  // indossato'. Il segno arriva sempre da segno() (mai '+-2') e i malus vanno in rosso con la
  // stessa classe dei cibi (.petq-effetto-malus): un vestito che TOGLIE Carisma deve saltare
  // all'occhio, puo' far fallire una missione sociale.
  function nodiEffettiEquip(nome, categoria) {
    var frammento = document.createDocumentFragment();
    var voce = voceEquipContenuto(nome, categoria);
    var effetti = (voce && voce.effetti) || [];
    var scritti = 0;
    for (var i = 0; i < effetti.length; i++) {
      var ef = effetti[i];
      if (!ef || typeof ef.valore !== 'number') continue;
      if (scritti > 0) frammento.appendChild(document.createTextNode(', '));
      var span = document.createElement('span');
      if (ef.valore < 0) span.className = 'petq-effetto-malus';
      span.textContent = segno(ef.valore) + ' ' + traduci(EFFETTO_CIBO_LABEL[ef.nome] || ef.nome);
      frammento.appendChild(span);
      scritti++;
    }
    // Le code sono letterali distinti (niente ternario DENTRO traduci): lo script di censimento
    // delle chiavi i18n del progetto cerca traduci( seguito da un LETTERALE, e una chiave calcolata
    // gli sfuggirebbe restando in italiano in inglese senza che nessuno se ne accorga.
    if (scritti > 0) {
      var coda = (categoria === 'arma') ? traduci(' mentre impugnata') : traduci(' mentre indossato');
      frammento.appendChild(document.createTextNode(coda));
      return frammento;
    }
    var speciale = EQUIP_SPECIALE_TXT[nome];
    if (speciale) {
      frammento.appendChild(document.createTextNode(traduci(speciale)));
      return frammento;
    }
    var generico = (categoria === 'arma') ? traduci('arma') : traduci('indossabile');
    frammento.appendChild(document.createTextNode(generico));
    return frammento;
  }

  // ---------- icone degli oggetti che non sono arredi (indossabili, armi, giocattoli) ----------
  // COSA SUCCEDE OGGI SENZA SPRITE (verificato): rooms.drawArredo, per un nome che non conosce,
  // ripiega su arredoFallback — la "cassa col fiocco". Niente crash, ma nel negozio TUTTI i
  // vestiti uscivano come la stessa identica cassa, e i giocattoli non avevano proprio icona.
  // Qui l'icona migliore disponibile, in tre gradini:
  //   1) l'oggetto e ANCHE un arredo (Palla/Robottino/Trenino/Astronave) -> il suo disegno vero;
  //   2) e' un indossabile/arma con lo sprite equip gia' disegnato in sprites.js (VESTITO_SPR /
  //      ARMA_SPR) -> lo si ritaglia dal suo riquadro e lo si centra nell'icona;
  //   3) altrimenti SAGOMA DI CATEGORIA (maglietta / spada / palla): dichiaratamente provvisoria,
  //      ma almeno dice di che tipo di oggetto si tratta.
  //
  // TODO ARTE — sprite da disegnare A MANO (non generare, regola del fondatore). Un nome per
  // riga apposta: sono NOMI-CHIAVE (identici a content/arredi.md, accenti compresi) e uno
  // spezzato a fine riga non si troverebbe piu' cercandolo.
  //
  // STATO VERIFICATO (28 lug 2026, script node sul contenuto vero): 13 indossabili su 38 senza
  // voce in sprites.js VESTITO_SPR e 10 giocattoli su 14 senza voce in rooms.js ARREDI — sono
  // ESATTAMENTE i nomi elencati qui sotto. Nessun crash da nessuna parte: negozio, menu del
  // salone e riga premio passano tutti da iconaOggetto(), che ripiega sulla sagoma di categoria.
  // RESTA UN BUCO SOLO, e non si chiude col codice: un vestito senza VESTITO_SPR, se indossato,
  // NON si vede addosso al pet (sprites.drawOverlayEquip salta e basta: nessun errore, ma il
  // giocatore preme "Indossa" e non cambia niente a schermo). Si chiude disegnando i 13 sprite.
  //
  //   sprites.js VESTITO_SPR — 13 indossabili MEME senza sprite SUL PET:
  //     Occhialoni Fattene Una Ragione
  //     Cappellino di Stagnola
  //     Sandaloni col Calzino
  //     Acetatona Lucida
  //     Piuminone del Paninaro
  //     Cappelluccio Rosso dell'Idraulico
  //     Collarone della Vergogna
  //     Visorone della Realtà Finta
  //     Elmo del Centurione da Selfie
  //     Pettorina Catarifrangente
  //     Maglione della Nonna Renna
  //     Cappellone di Paglietta
  //     Berrettone a Punta dell'Eroe Muto
  //
  //   rooms.js ARREDI — 10 giocattoli senza icona 16x16 (negozio + menu del salone):
  //     Squalotto Trescarpe
  //     Scatoletta Inutile
  //     Cartuccia Soffiona
  //     Paperotta Consigliera
  //     Sfera Sentenziosa
  //     Trottolone Sbatacchione
  //     Cubbolo Sei Facce
  //     Peluffo Ciarliero
  //     Ciucciolotto Piagnucolone
  //     Pescione Cantautore
  var ICONA_LATO = 16; // stessa griglia 16 degli sprite equip e degli arredi

  function iconaOggetto(nome, categoria) {
    var cv = document.createElement('canvas');
    cv.width = ICONA_LATO; cv.height = ICONA_LATO;
    cv.className = 'petq-food-icon';
    cv.title = traduci(nome);
    var g = cv.getContext('2d');
    g.imageSmoothingEnabled = false;
    // 1) disegno vero della stanza (footprint 14x14 con 1px di margine). Due strade per arrivarci:
    // l'oggetto e' un ARREDO a catalogo, oppure ha comunque un disegno proprio in rooms.js — il
    // caso dei GIOCATTOLI, che vivono in un catalogo separato (data.giocattoli) e quindi non si
    // trovano con trovaArredoContentUI: senza questa seconda strada resterebbero alla sagoma
    // generica anche avendo l'icona disegnata.
    var haDisegnoProprio = !!(PETQ.rooms && PETQ.rooms.haDisegnoArredo && PETQ.rooms.haDisegnoArredo(nome));
    if ((trovaArredoContentUI(nome) || haDisegnoProprio) && PETQ.rooms && PETQ.rooms.drawArredo) {
      PETQ.rooms.drawArredo(g, nome, 1, 1);
      return cv;
    }
    // 2) sprite equip gia' disegnato
    if (categoria !== 'giocattolo' && disegnaSpriteEquipRitagliato(g, nome, categoria, ICONA_LATO)) return cv;
    // 3) sagoma di categoria
    disegnaSagomaCategoria(g, categoria, ICONA_LATO);
    return cv;
  }

  // Ritaglia lo sprite equip di sprites.js e lo centra nell'icona. Ritorna false se quel nome non
  // ha (ancora) uno sprite: drawOverlayEquip semplicemente non disegna niente, e la tela vuota e
  // il modo piu' onesto di accorgersene senza duplicare qui l'elenco degli sprite esistenti.
  function disegnaSpriteEquipRitagliato(g, nome, categoria, lato) {
    if (!PETQ.sprites || !PETQ.sprites.drawOverlayEquip) return false;
    try {
      var S = 48; // riquadro largo: le ancore del pet possono portare il disegno fuori dal 16x16
      var off = document.createElement('canvas');
      off.width = S; off.height = S;
      var og = off.getContext('2d');
      og.imageSmoothingEnabled = false;
      var finto = { razza: 'alieno', sottorazza: 'blob', stadio: 'baby' };
      if (categoria === 'arma') finto.armaEquip = nome;
      else finto.indossato = nome;
      // convenzione di sprites.draw: scale = larghezza/SIZE (SIZE=32) e la griglia equip usa
      // s16 = scale*2 -> scale 0.5 = 1 pixel di canvas per cella della griglia 16.
      PETQ.sprites.drawOverlayEquip(og, finto, 0.5, 16, 16);
      var dati = og.getImageData(0, 0, S, S).data;
      var minx = S, miny = S, maxx = -1, maxy = -1;
      for (var y = 0; y < S; y++) {
        for (var x = 0; x < S; x++) {
          if (dati[(y * S + x) * 4 + 3] === 0) continue;
          if (x < minx) minx = x;
          if (x > maxx) maxx = x;
          if (y < miny) miny = y;
          if (y > maxy) maxy = y;
        }
      }
      if (maxx < 0) return false; // nessuno sprite per questo nome
      var w = maxx - minx + 1, h = maxy - miny + 1;
      var k = Math.max(1, Math.floor(lato / Math.max(w, h))); // ingrandimento a numeri interi
      g.imageSmoothingEnabled = false;
      g.drawImage(off, minx, miny, w, h,
        Math.round((lato - w * k) / 2), Math.round((lato - h * k) / 2), w * k, h * k);
      return true;
    } catch (e) {
      return false; // getImageData non disponibile: si ripiega sulla sagoma di categoria
    }
  }

  // Sagome segnaposto, stesse convenzioni degli sprite del gioco: griglia di stringhe ('.' =
  // trasparente), palette a lettera, contorno scuro #17171e per staccare dallo sfondo.
  var SAGOME_CATEGORIA = {
    indossabile: {
      pal: { K: '#17171e', C: '#7f8ea3', c: '#5c6a7d' },
      g: ['..KK....KK..',
          '.KCCKKKKCCK.',
          'KCCCCCCCCCCK',
          'KCCCCCCCCCCK',
          'KKCCCCCCCCKK',
          '..KCcccccCK.',
          '..KCCCCCCCK.',
          '..KCCCCCCCK.',
          '..KCcccccCK.',
          '..KKKKKKKKK.']
    },
    arma: {
      pal: { K: '#17171e', W: '#eef4fa', g: '#f0c832', h: '#8a6a3a' },
      g: ['...KK...',
          '..KWWK..',
          '..KWWK..',
          '..KWWK..',
          '..KWWK..',
          '..KWWK..',
          '..KWWK..',
          '.KggggK.',
          '..KhhK..',
          '..KhhK..',
          '..KhhK..',
          '...KK...']
    },
    giocattolo: {
      pal: { K: '#17171e', R: '#e8584c', r: '#a83a34', W: '#ffffff' },
      g: ['...KKKK...',
          '..KRRRRK..',
          '.KRWWRRRK.',
          'KRWWRRRRRK',
          'KRRRRRRRRK',
          'KRRRRRRrrK',
          'KRRRRRrrrK',
          '.KRRRrrrK.',
          '..KRrrrK..',
          '...KKKK...']
    }
  };

  function disegnaSagomaCategoria(g, categoria, lato) {
    var sag = SAGOME_CATEGORIA[categoria] || SAGOME_CATEGORIA.giocattolo;
    var righe = sag.g;
    var alt = righe.length;
    var larg = righe[0].length;
    var ox = Math.floor((lato - larg) / 2);
    var oy = Math.floor((lato - alt) / 2);
    for (var y = 0; y < alt; y++) {
      var riga = righe[y];
      for (var x = 0; x < riga.length; x++) {
        var col = sag.pal[riga.charAt(x)];
        if (!col) continue;
        g.fillStyle = col;
        g.fillRect(ox + x, oy + y, 1, 1);
      }
    }
  }

  // Effetti Tier 2 di un cibo, con fallback sulla vecchia coppia stat/statNome per gli oggetti-cibo
  // costruiti a mano (stessa conversione di care.feed): un solo formato per tutta la UI.
  // La lista VUOTA non vince sul fallback (regola identica a care.feed: `effetti.length === 0 &&
  // cibo.statNome`), altrimenti un cibo legacy con effetti:[] ma statNome valorizzato si sarebbe
  // mostrato senza effetti mentre il motore glieli applicava.
  function effettiDiCibo(cibo) {
    if (cibo && Array.isArray(cibo.effetti) && cibo.effetti.length > 0) return cibo.effetti;
    if (cibo && cibo.statNome) return [{ tipo: 'rpg', nome: cibo.statNome, valore: cibo.stat || 0 }];
    return [];
  }

  // Drag di una card cibo del frigo verso la scena (stesso gesto della vecchia barra cibo):
  // se il rilascio cade sul canvas stanza, da' da mangiare (eseguiFeed). Il tap semplice (niente
  // drag) e' gia' gestito dal listener 'click' della card in renderAzioniCucina.
  function installaDragCibo(card, cibo, dispensaIdx) {
    card.addEventListener('pointerdown', function (e) {
      if (animazioneInCorso) return;
      annullaIdleAction();
      foodPointer = {
        id: e.pointerId, cibo: cibo, card: card,
        startX: e.clientX, startY: e.clientY, dragging: false
      };
    });

    card.addEventListener('pointermove', function (e) {
      if (!foodPointer || e.pointerId !== foodPointer.id) return;

      var dx = e.clientX - foodPointer.startX;
      var dy = e.clientY - foodPointer.startY;
      var dist = Math.sqrt(dx * dx + dy * dy);

      if (!foodPointer.dragging) {
        // touch: parte il drag solo se il gesto è più verticale che orizzontale
        // (orizzontale = scroll della barra, con touch-action: pan-x);
        // mouse: basta la distanza
        var verticale = Math.abs(dy) > Math.abs(dx);
        if ((e.pointerType === 'mouse' && dist > 6) || (dist > 10 && verticale)) {
          foodPointer.dragging = true;
          try { card.setPointerCapture(e.pointerId); } catch (err) {}
          var canvas = document.getElementById('petq-canvas-stanza');
          var rect = canvas ? canvas.getBoundingClientRect() : { width: 448 };
          var ghostSize = Math.max(32, Math.round(rect.width * 12 / ROOM_W));
          mostraGhost(ghostSize, function (gc) {
            gc.width = 12; gc.height = 12;
            disegnaCibo(gc, cibo);
          });
          muoviGhost(e.clientX, e.clientY);
        }
      } else {
        muoviGhost(e.clientX, e.clientY);
      }
    });

    function fine(e, annullato) {
      if (!foodPointer || e.pointerId !== foodPointer.id) return;
      var fp = foodPointer;
      foodPointer = null;

      if (fp.dragging) {
        nascondiGhost();
        if (annullato) return;
        var canvas = document.getElementById('petq-canvas-stanza');
        if (canvas) {
          var r = canvas.getBoundingClientRect();
          var dentro = e.clientX >= r.left && e.clientX <= r.right &&
                       e.clientY >= r.top && e.clientY <= r.bottom;
          if (dentro) eseguiFeed(fp.cibo, fp.card, dispensaIdx);
        }
      }
      // tap semplice (niente drag): gestito dal listener 'click' della card, niente da fare qui.
    }

    card.addEventListener('pointerup', function (e) { fine(e, false); });
    card.addEventListener('pointercancel', function (e) { fine(e, true); });
  }

  // --- bagno: solo suggerimenti, le azioni sono drag/tap sul canvas ---

  function renderAzioniBagno(container) {
    var nome = currentState.pet.nome || traduci('il pet');
    if (currentState.sonno) {
      container.appendChild(el('p', 'petq-hint', nome + traduci(' sta dormendo in camera: niente bagnetto finché non si sveglia.')));
      return;
    }
    if (currentState.missione) {
      container.appendChild(el('p', 'petq-hint', nome + traduci(' è in missione: niente bagnetto finché non torna.')));
    } else if (currentState.allenamento) {
      container.appendChild(el('p', 'petq-hint', nome + traduci(' si sta allenando: niente bagnetto finché non finisce.')));
    } else {
      container.appendChild(el('p', 'petq-hint', traduci('Trascina ') + nome + traduci(' nella vasca per lavarlo.')));
    }
    if (currentState.poop > 0) {
      container.appendChild(el('p', 'petq-hint', traduci('Tocca i bisogni per pulirli.')));
    }

    // Infermeria (fix playtest 7c): la zona è SEMPRE visibile, con stato esplicito invece
    // di sparire — "Nessuna ferita da curare" / "Cura — N monete" / "Cure finite per oggi".
    container.appendChild(costruisciInfermeria(nome));
  }

  function costruisciInfermeria(nome) {
    var wrap = el('div', 'petq-infermeria');
    wrap.appendChild(el('div', 'petq-infermeria-titolo', traduci('Infermeria')));

    var costo = costoCura();
    var ferite = currentState.ferite || 0;

    if (ferite <= 0) {
      wrap.appendChild(el('p', 'petq-hint', traduci('Nessuna ferita da curare.')));
      return wrap;
    }

    var btn = el('button', 'petq-btn', traduci('Cura — ') + costo + traduci(' monete'));
    var motivo = null;
    if (currentState.missione) motivo = nome + traduci(' è in missione.');
    else if (cureEsauriteOggi()) motivo = traduci('Cure finite per oggi, torna domani.');
    else if ((currentState.coins || 0) < costo) motivo = traduci('Monete insufficienti.');
    if (motivo) {
      btn.disabled = true;
      btn.title = motivo;
      wrap.appendChild(el('p', 'petq-hint', motivo));
    }
    btn.addEventListener('click', avviaCura);
    wrap.appendChild(btn);
    return wrap;
  }

  // Costo cura mostrato in UI: dalla config se un giorno verrà mappata
  // (bilanciamento.infermeria.costo), altrimenti 15 come hardcoded in care.cura.
  // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "infermeria_costo=-5", Infermiere Provetto): il
  // prezzo mostrato DEVE riflettere lo sconto del talento (v. care._costoCuraEffettivo, stessa
  // funzione usata davvero da care.cura al click), altrimenti il bottone mente sul prezzo reale.
  function costoCura() {
    var base = 15;
    var bil = bilanciamento();
    if (bil.infermeria && typeof bil.infermeria.costo === 'number') base = bil.infermeria.costo;
    if (PETQ.talenti && PETQ.talenti.infermeriaModCosto) {
      base = Math.max(0, base + PETQ.talenti.infermeriaModCosto(currentState));
    }
    return base;
  }

  function cureEsauriteOggi() {
    var bil = bilanciamento();
    var maxCure = (bil.infermeria && typeof bil.infermeria.maxGiorno === 'number') ? bil.infermeria.maxGiorno : 2;
    return currentState.cureDay === PETQ.clock.giornoCorrente(currentState) && (currentState.cureOggi || 0) >= maxCure;
  }

  function avviaCura() {
    if (animazioneInCorso || !currentState || currentState.missione) return;
    annullaIdleAction();
    var r = PETQ.care.cura(currentState);
    if (!r.ok) {
      mostraToast(r.msg);
      renderAzioni();
      return;
    }
    animazioneInCorso = true;
    effetto = { tipo: 'cura' };
    disegnaStanzaEPet(currentState);
    mostraToast(r.msg);

    animaTimed(1500, function () {
      effetto = null;
      animazioneInCorso = false;
      dopoAzione(null);
      mostraBalloon(PETQ.dialog.say(currentState.pet, 'felice', currentState));
    });
  }

  // --- salone: card allenamento + insegna parola ---

  // Minuti di gioco rimanenti dell'allenamento in corso (bilanciamento.md "Durata
  // allenamento"): (oreTot - oreFatte) x 60, mai negativo. Usata dalla card "in corso" sotto
  // e potenzialmente da un tick di aggiornamento countdown (v. aggiornaIndicatoreMissione per
  // il pattern equivalente delle missioni).
  function minutiAllenamentoRimasti(state) {
    var a = state && state.allenamento;
    if (!a) return 0;
    var oreRimaste = Math.max(0, (a.oreTot || 0) - (a.oreFatte || 0));
    return Math.max(1, Math.round(oreRimaste * 60));
  }

  // "Gioca" col pet nel salone (playtest 8 lug 2026): ATTIVITA' A TEMPO da 10 minuti di gioco
  // (richiesta fondatore "il gioco coi giocattoli duri 20 min"), non piu' istantanea. state.gioco
  // avanza in PETQ.pet.applyDecay e si completa via controllaGiocoScaduto (pattern
  // allenamento/passeggiata).
  //
  // REVAMP GIOCATTOLI (fase 3, decisione fondatore in content/arredi.md): l'azione non e' piu' il
  // "Gioca" generico uguale per tutti (+4, o +6 con un arredo-giocattolo piazzato). Ora apre un
  // MENU dei giocattoli posseduti e ognuno fa una cosa sua. L'ATTIVITA' resta la stessa, cambia
  // solo chi la fa partire:
  //  - gioco a mani nude   -> bonus GIOCO_BONUS_MANI_NUDE, applicato alla FINE da pet.js;
  //  - giocattolo del menu -> bonus 0, perche' l'effetto vero l'ha gia' applicato
  //    PETQ.giocattoli.usa al momento del tocco. E quello che permette i "rifiuti simpatici"
  //    (pet di ottimo umore che snobba il peluche, pet troppo stanco per il duello) senza far
  //    buttare via 10 minuti al giocatore.
  var GIOCO_DURATA_ORE = 10 / 60; // 10 minuti di gioco
  var GIOCO_BONUS_MANI_NUDE = 4;  // Felicità del gioco senza giocattoli (era il vecchio "Gioca")

  function minutiGiocoRimasti(state) {
    if (!state || !state.gioco) return 0;
    var g = state.gioco;
    return Math.max(0, Math.ceil(((g.oreTot || 0) - (g.oreFatte || 0)) * 60));
  }

  // niente doppie attivita': il pet non puo' giocare mentre dorme/e' in missione/allena/passeggia
  // (o mentre sta gia' giocando). Stessa guardia che il motore ripete lato dati in giocattoli.usa.
  function petOccupatoPerGioco(state) {
    if (!state) return true;
    return !!(state.gioco || state.sonno || state.missione || state.allenamento || state.passeggiata);
  }

  // Perche' il pet non puo' giocare adesso, in una frase (richiesta fondatore: premere "Usa" mentre
  // il pet gioca gia' non faceva NIENTE e non diceva niente — un tap senza risposta si legge come
  // un bottone rotto). Restituisce null se e' libero. Copre tutti e cinque i casi della guardia
  // qui sopra, non solo il gioco: erano silenziosi allo stesso modo.
  function motivoOccupatoPerGioco(state) {
    if (!state || !state.pet) return null;
    var nomeP = state.pet.nome || traduci('Il pet');
    if (state.gioco) return nomeP + traduci(' sta già giocando.');
    if (state.sonno) return nomeP + traduci(' sta dormendo.');
    if (state.missione) return nomeP + traduci(' è fuori in missione.');
    if (state.allenamento) return nomeP + traduci(' si sta allenando.');
    if (state.passeggiata) return nomeP + traduci(' è fuori a passeggio.');
    return null;
  }

  // Fa partire l'attivita' a tempo. bonusFinale = Felicita' che applichera' pet.controllaGiocoScaduto
  // alla scadenza (0 quando l'effetto e' gia' stato dato dal giocattolo).
  function avviaAttivitaGioco(nomeGiocattolo, bonusFinale) {
    currentState.gioco = {
      oreFatte: 0, oreTot: GIOCO_DURATA_ORE,
      bonus: bonusFinale, giocattolo: nomeGiocattolo || null
    };
    // Punto UNICO di avvio gioco vero (chiamato sia da eseguiGiocoManiNude che da usaGiocattolo,
    // dopo tutte le guardie): un solo aggancio copre "parte davvero" per entrambi.
    if (PETQ.audio) PETQ.audio.suona('gioco');
    PETQ.save.save(currentState);
    var nomeG = currentState.pet.nome || traduci('Il pet');
    // Battuta del socio (pool 'gioca_giocattolo' se c'e un giocattolo, altrimenti 'gioca';
    // agganciate 9 lug 2026), fallback al testo fisso se il pool e vuoto.
    var battutaG = PETQ.dialog.say(currentState.pet, nomeGiocattolo ? 'gioca_giocattolo' : 'gioca', currentState);
    mostraBalloon((battutaG && battutaG !== '...') ? battutaG
      : (nomeGiocattolo ? nomeG + traduci(' inizia a giocare col ') + traduci(nomeGiocattolo) + '!'
                        : nomeG + traduci(' si mette a giocare!')));
    disegnaStanzaEPet(currentState);
    renderAzioni();
  }

  // Gioco "a mani nude": il vecchio "Gioca" del salone, +4 Felicita' in 10 minuti. Resta SEMPRE
  // in fondo al menu (richiesta fondatore "cosi' non si perde niente"): chi non ha ancora comprato
  // un giocattolo — o li ha esauriti per oggi — non rimane senza azione.
  function eseguiGiocoManiNude() {
    if (!currentState || !currentState.pet) return;
    if (petOccupatoPerGioco(currentState)) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto');
      mostraToast(motivoOccupatoPerGioco(currentState));
      return;
    }
    annullaIdleAction();
    avviaAttivitaGioco(null, GIOCO_BONUS_MANI_NUDE);
  }

  // Tap su un giocattolo del menu: l'effetto lo applica il MOTORE (PETQ.giocattoli.usa, fase 2),
  // poi parte l'attivita' a tempo con bonus 0. Su ok:false non parte niente e — nel caso dei due
  // rifiuti "simpatici" — l'uso del giorno non viene nemmeno consumato (ci pensa il motore).
  function usaGiocattolo(nome) {
    if (!currentState || !currentState.pet) return;
    if (petOccupatoPerGioco(currentState)) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto');
      mostraToast(motivoOccupatoPerGioco(currentState));
      return;
    }
    if (!PETQ.giocattoli || !PETQ.giocattoli.usa) return;
    annullaIdleAction();
    var esito = PETQ.giocattoli.usa(currentState, nome);
    PETQ.save.save(currentState);
    if (!esito || !esito.ok) {
      mostraToast((esito && esito.msg) || traduci('Non si può usare adesso.'));
      renderAzioni();
      return;
    }
    aggiornaHud(currentState);
    // prima l'attivita' (balloon = battuta del socio), poi il toast con l'effetto meccanico:
    // stessa divisione dei ruoli del resto del gioco (balloon = voce del pet, toast = numeri).
    avviaAttivitaGioco(nome, 0);
    mostraToast(esito.msg);
    if (esito.scenetta) scenettaCubo();
  }

  // Scenetta del Cubbolo Sei Facce (content/arredi.md: "quando si completa parte la scenetta del
  // pet che risolve il cubo"). Nessuna arte nuova: riusa il puff gia' esistente (lo stesso della
  // pulizia dei bisogni) sopra la testa del pet + un balloon dedicato che copre la battuta di
  // avvio gioco. TODO ARTE: una vera animazione "risolve il cubo" quando ci sara' lo sprite del
  // Cubbolo (v. TODO nel blocco delle icone piu' sotto).
  function scenettaCubo() {
    if (!currentState) return;
    var pos = posizionePet();
    effetto = { tipo: 'puff', x: Math.round(pos.x + PET_PX / 2), y: Math.round(pos.y), step: 0 };
    disegnaStanzaEPet(currentState);
    dopoMs(200, function () {
      if (effetto && effetto.tipo === 'puff') { effetto.step = 1; disegnaStanzaEPet(currentState); }
    });
    dopoMs(520, function () {
      if (effetto && effetto.tipo === 'puff') { effetto = null; disegnaStanzaEPet(currentState); }
    });
    mostraBalloon(traduci('🎲 Tutte e sei le facce a posto!'));
  }

  // I giocattoli POSSEDUTI, gia' pronti per il menu (nome, descrizione tradotta, usi rimasti).
  // La lista la costruisce il motore della fase 2: qui non si ricalcola niente.
  function elencoGiocattoli() {
    if (!currentState || !PETQ.giocattoli || !PETQ.giocattoli.elencoUsabili) return [];
    return PETQ.giocattoli.elencoUsabili(currentState) || [];
  }

  // "usi oggi: 1/2" · "usi illimitati" · "sempre attivo". NIENTE SPOILER (regola sacra): la barra
  // nascosta del Cubbolo non compare da nessuna parte.
  function etichettaUsiGiocattolo(g) {
    if (g.passivo) return traduci('sempre attivo');
    if (g.illimitato) return traduci('usi illimitati');
    return traduci('usi oggi: ') + g.usiRimasti + '/' + g.usiGiorno;
  }

  // Menu "Usa un giocattolo". Stessa aria della Collezione che vive qui accanto nel salone:
  // contenitore .petq-collezione + una .petq-arredo-riga per voce (icona · nome/descrizione ·
  // bottone). Nessuna classe nuova, nessun CSS nuovo (la fase 3 tocca solo ui.js e i18n.js).
  function costruisciMenuGiocattoli(lista) {
    var wrap = el('div', 'petq-collezione');

    if (lista.length === 0) {
      wrap.appendChild(el('p', 'petq-vuoto',
        traduci('Nessun giocattolo ancora: al Negozio, scheda "Giochi", ce n\'è per tutti i gusti.')));
    } else {
      wrap.appendChild(el('p', 'petq-hint', traduci('Con cosa lo fai giocare?')));
    }

    for (var i = 0; i < lista.length; i++) {
      (function (g) {
        var riga = el('div', 'petq-arredo-riga');
        riga.appendChild(iconaOggetto(g.nome, 'giocattolo'));

        var testi = el('div', 'petq-arredo-info');
        testi.appendChild(el('div', 'petq-arredo-nome', traduci(g.nome)));
        testi.appendChild(el('div', 'petq-arredo-dett', g.descrizione + ' · ' + etichettaUsiGiocattolo(g)));
        riga.appendChild(testi);

        // I PASSIVI si mostrano ma non si toccano: funzionano da soli (Peluffo Ciarliero,
        // Pescione Cantautore). Gli esauriti restano visibili col motivo, come le card cibo
        // bloccate del frigo: il giocatore deve capire perche' non puo', non vedere un buco.
        var btn = el('button', 'petq-btn petq-btn-mini', traduci('Usa'));
        if (g.passivo) {
          btn.disabled = true;
          btn.textContent = traduci('sempre attivo');
          btn.title = traduci('Funziona da solo, non c\'è niente da fare.');
        } else if (!g.disponibile) {
          btn.disabled = true;
          btn.textContent = traduci('Per oggi basta');
          btn.title = traduci('Torna domani.');
        } else {
          btn.addEventListener('click', function () { usaGiocattolo(g.nome); });
        }
        riga.appendChild(btn);
        wrap.appendChild(riga);
      })(lista[i]);
    }

    var rigaNude = el('div', 'petq-arredo-riga');
    var testiNude = el('div', 'petq-arredo-info');
    testiNude.appendChild(el('div', 'petq-arredo-nome', traduci('Gioca a mani nude')));
    testiNude.appendChild(el('div', 'petq-arredo-dett',
      traduci('Senza niente in mano: Felicità +') + GIOCO_BONUS_MANI_NUDE + traduci(' · 10 min')));
    rigaNude.appendChild(testiNude);
    var btnNude = el('button', 'petq-btn petq-btn-mini', traduci('Gioca'));
    btnNude.addEventListener('click', function () { eseguiGiocoManiNude(); });
    rigaNude.appendChild(btnNude);
    wrap.appendChild(rigaNude);

    return wrap;
  }

  /* ---------- RITRATTISTA: il pet ti disegna (perk corso_disegno) ----------
   *
   * Una schermata sola, con l'anteprima che si ridisegna a OGNI tap. Non una procedura a cinque
   * passi: il senso del ritratto e' vederti comparire, e una procedura te lo mostra solo alla fine.
   *
   * E ogni opzione E' IL RITRATTO VERO ridisegnato con quel tratto, non un'etichetta ne' un
   * quadratino di colore. E' la stessa scelta che ha fatto funzionare il selettore dei colori del
   * pet: "Capelli tipo 2" non significa niente, il disegno si': si sceglie guardando, non leggendo.
   *
   * I tratti disponibili li legge da sprites._tratti(): la schermata non tiene una lista sua,
   * altrimenti aggiungere un colore di capelli richiederebbe di ricordarsi di due posti.
   */
  var RIT_DOMANDE = [
    { chiave: 'pelle', etichetta: 'Pelle' },
    { chiave: 'capelliForma', etichetta: 'Capelli' },
    { chiave: 'capelliColore', etichetta: 'Colore dei capelli' },
    { chiave: 'occhiali', etichetta: 'Occhiali' },
    { chiave: 'barba', etichetta: 'Barba' },
    { chiave: 'tocco', etichetta: 'Tocco finale' }
  ];

  function ritrattoCorrente(state) {
    var r = state.ritratto;
    if (!r || typeof r !== 'object') r = {};
    RIT_DOMANDE.forEach(function (d) {
      if (typeof r[d.chiave] !== 'number') r[d.chiave] = 0;
    });
    state.ritratto = r;
    return r;
  }

  function disegnaMiniRitratto(canvas, tratti) {
    if (PETQ.sprites && PETQ.sprites.drawRitratto) PETQ.sprites.drawRitratto(canvas, tratti);
  }

  function mostraRitrattista(state) {
    if (!PETQ.sprites || !PETQ.sprites.drawRitratto) return;
    fermaIdle();
    puliziaEffetto();
    currentState = state;

    var tratti = ritrattoCorrente(state);
    var tabelle = PETQ.sprites._tratti();

    var app = getApp();
    app.innerHTML = '';
    var wrap = el('div', 'petq-screen petq-esito');
    wrap.id = 'petq-ritrattista';
    wrap.appendChild(el('h1', 'petq-title', traduci('Fatti fare il ritratto')));

    // Anteprima grande, dentro la cornice: e' la cornice a giustificare uno stile diverso dai
    // 16px del resto del gioco (un quadro puo' permetterselo, uno sprite no).
    var quadro = el('div', 'petq-ritratto-quadro');
    var grande = document.createElement('canvas');
    grande.width = PETQ.sprites.RIT_W * 5;
    grande.height = PETQ.sprites.RIT_H * 5;
    grande.className = 'petq-ritratto-grande';
    quadro.appendChild(grande);
    wrap.appendChild(quadro);
    disegnaMiniRitratto(grande, tratti);

    wrap.appendChild(el('p', 'petq-esito-testo', traduci('Il pet ti fissa con la matita in mano. Dice di stare fermo.')));

    // Ridisegna l'anteprima E i bordi di selezione. Rifare tutta la schermata ad ogni tap
    // funzionerebbe ma farebbe SALTARE lo scroll in cima ad ogni scelta: con cinque righe da
    // scorrere sarebbe insopportabile.
    var bottoniPerDomanda = {};
    function aggiorna() {
      disegnaMiniRitratto(grande, tratti);
      RIT_DOMANDE.forEach(function (d) {
        (bottoniPerDomanda[d.chiave] || []).forEach(function (b, i) {
          if (i === tratti[d.chiave]) b.classList.add('petq-ritratto-scelto');
          else b.classList.remove('petq-ritratto-scelto');
        });
      });
    }

    RIT_DOMANDE.forEach(function (d) {
      var opzioni = tabelle[d.chiave] || [];
      wrap.appendChild(el('div', 'petq-hint petq-ritratto-etichetta', traduci(d.etichetta)));
      var riga = el('div', 'petq-ritratto-riga');
      bottoniPerDomanda[d.chiave] = [];
      opzioni.forEach(function (_, idx) {
        var b = el('button', 'petq-ritratto-opz');
        var mini = document.createElement('canvas');
        mini.width = PETQ.sprites.RIT_W * 2;
        mini.height = PETQ.sprites.RIT_H * 2;
        mini.className = 'petq-ritratto-mini';
        // L'anteprima varia SOLO questo tratto e tiene gli altri come li hai scelti: cosi' vedi
        // la differenza vera sul TUO ritratto, non su un modello generico.
        var provvisorio = {};
        RIT_DOMANDE.forEach(function (dd) { provvisorio[dd.chiave] = tratti[dd.chiave]; });
        provvisorio[d.chiave] = idx;
        disegnaMiniRitratto(mini, provvisorio);
        b.appendChild(mini);
        b.addEventListener('click', function () {
          tratti[d.chiave] = idx;
          // Le miniature delle ALTRE righe vanno rifatte: mostrano il tuo ritratto, che e' cambiato.
          RIT_DOMANDE.forEach(function (dd) {
            (bottoniPerDomanda[dd.chiave] || []).forEach(function (bb, ii) {
              var p = {};
              RIT_DOMANDE.forEach(function (d3) { p[d3.chiave] = tratti[d3.chiave]; });
              p[dd.chiave] = ii;
              disegnaMiniRitratto(bb.firstChild, p);
            });
          });
          aggiorna();
        });
        riga.appendChild(b);
        bottoniPerDomanda[d.chiave].push(b);
      });
      wrap.appendChild(riga);
    });

    var fatto = el('button', 'petq-btn petq-btn-primario', traduci('È fatto!'));
    fatto.addEventListener('click', function () {
      state.ritrattoFatto = true;
      // Il quadro entra fra gli arredi POSSEDUTI, cosi' eredita gratis slot, Collezione,
      // piazzamento e disegno in stanza — stesso trucco dei companion del Supporter Pack.
      if (PETQ.arredi && PETQ.arredi.aggiungi) PETQ.arredi.aggiungi(state, ARREDO_RITRATTO);
      PETQ.save.save(state);
      mostraCasa(state);
      mostraAvviso(traduci('Il ritratto è pronto: lo trovi nella Collezione, in salone.'));
    });
    wrap.appendChild(fatto);

    app.appendChild(wrap);
    montaDebugPanel();
    aggiorna();
  }

  function renderAzioniSalone(container) {
    var oggi = PETQ.clock.giornoCorrente(currentState);
    var nome = currentState.pet.nome || traduci('il pet');
    if (currentState.sonno) {
      container.appendChild(el('p', 'petq-hint', nome + traduci(' sta dormendo in camera: niente giochi finché non si sveglia.')));
      return;
    }
    var inMissione = !!currentState.missione;
    var inAllenamento = !!currentState.allenamento;

    // --- Gioca (attività a tempo, 10 min) ---
    // Mentre gioca il salone va in modalità "occupato": countdown + collezione passiva, niente
    // allenamento/parole (come durante l'allenamento in corso). Idem, il bottone appare solo
    // quando il pet è libero.
    if (currentState.gioco) {
      var giocaHint = el('p', 'petq-hint');
      giocaHint.id = 'petq-gioco-hint';
      giocaHint.textContent = nome + traduci(' sta giocando: ancora ') + minutiGiocoRimasti(currentState) + 'm. 🧸';
      container.appendChild(giocaHint);
      var collBtnGioco = el('button', 'petq-btn', collezioneAperta ? traduci('Chiudi collezione') : traduci('Collezione'));
      collBtnGioco.addEventListener('click', function () { collezioneAperta = !collezioneAperta; renderAzioni(); });
      container.appendChild(collBtnGioco);
      if (collezioneAperta) container.appendChild(costruisciCollezione());
      return;
    }
    // "Usa un giocattolo" (revamp giocattoli): apre/chiude il menu, esattamente come il frigo in
    // cucina (stesso gesto, stesso stato booleano, stesso bottone che cambia etichetta).
    if (!inMissione && !inAllenamento && !currentState.passeggiata) {
      var listaGiocattoli = elencoGiocattoli();
      var giocaBtn = el('button', 'petq-btn', giocattoliAperti
        ? '🧸 ' + traduci('Chiudi i giocattoli')
        : '🧸 ' + traduci('Usa un giocattolo (') + listaGiocattoli.length + ')');
      giocaBtn.addEventListener('click', function () {
        giocattoliAperti = !giocattoliAperti;
        renderAzioni();
      });
      container.appendChild(giocaBtn);
      if (giocattoliAperti) container.appendChild(costruisciMenuGiocattoli(listaGiocattoli));
    }

    // Allenamento IN CORSO (bilanciamento.md "Durata allenamento", decisione fondatore:
    // attivita' a tempo come una missione): al posto delle 4 card, la card unica di stato con
    // countdown, stesso pattern della card missione-in-corso (v. costruisciCardMissioneInCorso).
    if (inAllenamento) {
      var statLabel = STAT_LABEL[currentState.allenamento.stat] ? traduci(STAT_LABEL[currentState.allenamento.stat]) : currentState.allenamento.stat;
      var hintAllenamento = el('p', 'petq-hint');
      hintAllenamento.id = 'petq-allenamento-hint';
      hintAllenamento.textContent = nome + traduci(' si allena (') + statLabel + traduci('). Pronto tra ') + minutiAllenamentoRimasti(currentState) + 'm.';
      container.appendChild(hintAllenamento);

      var cardCorso = el('div', 'petq-train-card petq-train-card-corso');
      var iconaCorso = document.createElement('canvas');
      iconaCorso.width = 12; iconaCorso.height = 12;
      iconaCorso.className = 'petq-train-icon';
      disegnaProp(iconaCorso, propAllenamentoAttivo(currentState) || 'pesi');
      cardCorso.appendChild(iconaCorso);
      var labelCorso = el('div', 'petq-train-label', traduci('Si allena, pronto tra ') + minutiAllenamentoRimasti(currentState) + 'm');
      labelCorso.id = 'petq-allenamento-countdown';
      cardCorso.appendChild(labelCorso);
      container.appendChild(cardCorso);

      var cardsDisabled = el('div', 'petq-train-cards');
      for (var d = 0; d < PROPS_ALLENAMENTO.length; d++) {
        var cardD = el('div', 'petq-train-card petq-train-card-usata');
        cardD.title = nome + traduci(' si sta allenando');
        var iconaD = document.createElement('canvas');
        iconaD.width = 12; iconaD.height = 12;
        iconaD.className = 'petq-train-icon';
        disegnaProp(iconaD, PROPS_ALLENAMENTO[d].id);
        cardD.appendChild(iconaD);
        cardD.appendChild(el('div', 'petq-train-label', traduci(PROPS_ALLENAMENTO[d].label)));
        cardsDisabled.appendChild(cardD);
      }
      container.appendChild(cardsDisabled);

      // collezione resta disponibile anche ad allenamento in corso (azione "passiva", niente
      // interazione col pet)
      var collBtnCorso = el('button', 'petq-btn', collezioneAperta ? traduci('Chiudi collezione') : traduci('Collezione'));
      collBtnCorso.addEventListener('click', function () {
        collezioneAperta = !collezioneAperta;
        renderAzioni();
      });
      container.appendChild(collBtnCorso);
      if (collezioneAperta) container.appendChild(costruisciCollezione());
      return;
    }

    // Talenti (Gruppo A, "allenamenti_giorno=2", Predestinato): il limite giornaliero non e'
    // piu' sempre 1, v. allenamentoEsauritoOggi sopra.
    var giaAllenato = allenamentoEsauritoOggi(currentState);
    var maxAllenamentiGiorno = (PETQ.talenti && PETQ.talenti.allenamentiPerGiorno) ? PETQ.talenti.allenamentiPerGiorno(currentState) : 1;
    var cardsDisabilitate = giaAllenato || inMissione;

    var hintSalone = inMissione
      ? nome + traduci(' è in missione. Intanto puoi sistemare la collezione.')
      : traduci('Tocca ') + nome + traduci(' per una coccola. Allenamento (') + maxAllenamentiGiorno + traduci(' al giorno):');
    container.appendChild(el('p', 'petq-hint', hintSalone));

    var cards = el('div', 'petq-train-cards');
    for (var i = 0; i < PROPS_ALLENAMENTO.length; i++) {
      (function (prop) {
        var card = el('div', 'petq-train-card' + (cardsDisabilitate ? ' petq-train-card-usata' : ''));
        if (giaAllenato) card.title = traduci('Allenamento già fatto oggi');
        else if (inMissione) card.title = nome + traduci(' è in missione');

        var icona = document.createElement('canvas');
        icona.width = 12; icona.height = 12;
        icona.className = 'petq-train-icon';
        disegnaProp(icona, prop.id);
        card.appendChild(icona);
        card.appendChild(el('div', 'petq-train-label', traduci(prop.label)));
        card.appendChild(el('div', 'petq-train-val', testoStat(prop.stat)));

        card.addEventListener('click', function () {
          if (allenamentoEsauritoOggi(currentState) || currentState.missione || currentState.allenamento) return;
          avviaAllenamento(prop, card);
        });
        cards.appendChild(card);
      })(PROPS_ALLENAMENTO[i]);
    }
    container.appendChild(cards);

    // insegna parola: resta bottone + input (serve la tastiera)
    var paroleWrap = el('div', 'petq-riga-azione');
    var inputParola = document.createElement('input');
    inputParola.type = 'text';
    inputParola.className = 'petq-input petq-input-piccolo';
    inputParola.placeholder = traduci('Nuova parola...');
    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "parole_giorno=4", Cervellone): il tetto
    // giornaliero di parole insegnabili non e' piu' fisso a 1 (v. care.js paroleInsegnateOggi/
    // PETQ.talenti.parolePerGiorno), stesso pattern di allenamentoEsauritoOggi.
    var maxParoleGiorno = (PETQ.talenti && PETQ.talenti.parolePerGiorno) ? PETQ.talenti.parolePerGiorno(currentState) : 1;
    var paroleFatteOggi = (PETQ.care && PETQ.care.paroleInsegnateOggi) ? PETQ.care.paroleInsegnateOggi(currentState) : (currentState.wordDay === oggi ? 1 : 0);
    var giaInsegnato = paroleFatteOggi >= maxParoleGiorno;
    if (giaInsegnato || inMissione) inputParola.disabled = true;
    paroleWrap.appendChild(inputParola);

    var paroleBtn = el('button', 'petq-btn petq-btn-piccolo', traduci('Insegna parola'));
    if (giaInsegnato || inMissione) {
      paroleBtn.disabled = true;
      paroleBtn.title = giaInsegnato ? (traduci('Parole di oggi esaurite (') + paroleFatteOggi + '/' + maxParoleGiorno + ')') : nome + traduci(' è in missione');
    } else if (maxParoleGiorno > 1) {
      paroleBtn.title = traduci('Parole insegnate oggi: ') + paroleFatteOggi + '/' + maxParoleGiorno;
    }
    paroleBtn.addEventListener('click', function () {
      var r = PETQ.care.teachWord(currentState, inputParola.value);
      if (r.ok && PETQ.audio) PETQ.audio.suona('parola');
      dopoAzione(r);
    });
    paroleWrap.appendChild(paroleBtn);
    container.appendChild(paroleWrap);

    // "Studio veloce" (PROTOTIPO 2, Blocco 9, Gruppo A, talento Nerd "Sete di Sapere"):
    // bottone visibile SOLO se il pet ha questo talento attivo, azione istantanea (niente
    // animazione a tempo, non tocca state.allenamento/trainCount), 1 al giorno.
    var statStudioVeloce = (PETQ.talenti && PETQ.talenti.allenamentoExtraStat) ? PETQ.talenti.allenamentoExtraStat(currentState) : null;
    if (statStudioVeloce) {
      var studioWrap = el('div', 'petq-riga-azione');
      var giaStudiato = currentState.studioVeloceDay === oggi;
      var studioBtn = el('button', 'petq-btn petq-btn-piccolo', traduci('Studio veloce (+1 ') + (traduci(STAT_LABEL[statStudioVeloce]) || statStudioVeloce) + ')');
      if (giaStudiato || inMissione) {
        studioBtn.disabled = true;
        studioBtn.title = giaStudiato ? traduci('Studio veloce già fatto oggi') : nome + traduci(' è in missione');
      }
      studioBtn.addEventListener('click', function () {
        var r = PETQ.care.studioVeloce(currentState);
        if (!r.ok) {
          mostraToast(r.msg);
          renderAzioni();
          return;
        }
        dopoAzione(r);
      });
      studioWrap.appendChild(studioBtn);
      container.appendChild(studioWrap);
    }

    // "Inventa qualcosa" (PROTOTIPO 2, Blocco 9, Gruppo D, talento Nerd raro "Inventore",
    // invenzione=1/settimana): bottone visibile SOLO col talento Inventore. Attivo se il timer
    // settimanale e' scaduto (PETQ.talenti.invenzioneDisponibile su pet.giorniVita); altrimenti
    // disabilitato con l'hint "manca N giorno/i". Consuma il "turno inventivo" della settimana
    // (state.ultimaInvenzioneGiorno), NON l'allenamento normale (non tocca state.allenamento/
    // trainCount). Occupato in missione -> disabilitato (come Studio veloce).
    if (petHaInventore(currentState)) {
      var invWrap = el('div', 'petq-riga-azione');
      var invDisponibile = PETQ.talenti && PETQ.talenti.invenzioneDisponibile && PETQ.talenti.invenzioneDisponibile(currentState);
      var invBtn = el('button', 'petq-btn petq-btn-piccolo', traduci('Inventa qualcosa'));
      if (!invDisponibile || inMissione) {
        invBtn.disabled = true;
        invBtn.title = inMissione ? nome + traduci(' è in missione') : traduci('Invenzione settimanale: ') + testoAttesaInvenzione(currentState);
      }
      invBtn.addEventListener('click', function () {
        eseguiInvenzione();
      });
      invWrap.appendChild(invBtn);
      container.appendChild(invWrap);
    }

    // collezione arredi
    /* Ritrattista: l'azione vive in SALONE come dice il doc (§B3, "azione in salone: fatti fare il
     * ritratto"). Resta disponibile anche dopo il primo ritratto: se hai sbagliato un tratto o
     * cambi taglio di capelli nella vita vera, poterlo rifare e' gentile e non costa nulla —
     * bloccarlo dopo un tap sarebbe una porta a senso unico su una cosa che parla di TE. */
    if (Array.isArray(currentState.perks) && currentState.perks.indexOf('corso_disegno') !== -1) {
      var ritrBtn = el('button', 'petq-btn',
        currentState.ritrattoFatto ? traduci('🖼️ Rifai il ritratto') : traduci('🖼️ Fatti fare il ritratto'));
      ritrBtn.addEventListener('click', function () { mostraRitrattista(currentState); });
      container.appendChild(ritrBtn);
    }

    var collBtn = el('button', 'petq-btn', collezioneAperta ? traduci('Chiudi collezione') : traduci('Collezione'));
    collBtn.addEventListener('click', function () {
      collezioneAperta = !collezioneAperta;
      renderAzioni();
    });
    container.appendChild(collBtn);
    if (collezioneAperta) container.appendChild(costruisciCollezione());
  }

  // ---------- invenzione (talento Nerd raro "Inventore", Gruppo D) ----------

  function petHaInventore(state) {
    return !!(PETQ.talenti && PETQ.talenti.haInventore && PETQ.talenti.haInventore(state));
  }

  // Testo hint per il bottone disabilitato: quanti giorni di gioco mancano al prossimo turno
  // inventivo (finestra di 7 giorni su pet.giorniVita, v. talenti.invenzioneDisponibile).
  function testoAttesaInvenzione(state) {
    var GIORNI = (PETQ.talenti && PETQ.talenti._giorniInvenzione) ? PETQ.talenti._giorniInvenzione : 7;
    var giorni = (state && state.pet && typeof state.pet.giorniVita === 'number') ? state.pet.giorniVita : 0;
    if (typeof state.ultimaInvenzioneGiorno !== 'number') return traduci('disponibile ora');
    var mancano = GIORNI - (giorni - state.ultimaInvenzioneGiorno);
    if (mancano <= 0) return traduci('disponibile ora');
    return traduci('tra ') + mancano + traduci(mancano === 1 ? ' giorno' : ' giorni');
  }

  // Inventa 1 oggetto casuale dal Pool Inventore: applica l'effetto (talenti.applicaInvenzione),
  // marca il timer settimanale (state.ultimaInvenzioneGiorno = giorniVita corrente) e mostra
  // cosa ha inventato in un pannellino (overlay a foglio, stesso pattern del diario), NON tocca
  // l'allenamento normale. Doppia guardia sulla disponibilita' (doppio tap veloce).
  function eseguiInvenzione() {
    if (!currentState) return;
    if (!(PETQ.talenti && PETQ.talenti.invenzioneDisponibile && PETQ.talenti.invenzioneDisponibile(currentState))) {
      mostraToast(traduci('Invenzione non disponibile ora.'));
      renderAzioni();
      return;
    }
    if (currentState.missione) {
      mostraToast((currentState.pet.nome || traduci('Il pet')) + traduci(' è in missione.'));
      return;
    }
    var r = PETQ.talenti.applicaInvenzione(currentState);
    if (!r || !r.ok) {
      mostraToast((r && r.msg) || traduci('Invenzione fallita.'));
      return;
    }
    // consuma il turno inventivo della settimana (finestra su giorniVita)
    currentState.ultimaInvenzioneGiorno = (currentState.pet && typeof currentState.pet.giorniVita === 'number') ? currentState.pet.giorniVita : 0;
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    disegnaStanzaEPet(currentState);
    renderAzioni();
    mostraPannelloInvenzione(r.oggetto, r.dettaglio);
  }

  // Pannellino "hai inventato": overlay a foglio (stesso stile del diario/scheda, "Chiudi" non
  // resetta la stanza). Mostra nome oggetto + descrizione dell'effetto applicato.
  function mostraPannelloInvenzione(oggetto, dettaglio) {
    var overlay = el('div', 'petq-scheda-overlay');
    var pagina = el('div', 'petq-scheda-pagina');
    pagina.appendChild(el('h2', 'petq-scheda-titolo', traduci('Invenzione!')));
    pagina.appendChild(el('p', 'petq-scheda-sottotitolo', (currentState.pet.nome || traduci('Il pet')) + traduci(' ha inventato qualcosa saltando l\'allenamento.')));
    pagina.appendChild(el('div', 'petq-arredo-nome', traduci(oggetto.nome)));
    pagina.appendChild(el('div', 'petq-arredo-dett', dettaglio || oggetto.effetto || ''));
    var chiudi = el('button', 'petq-btn', traduci('Chiudi'));
    chiudi.addEventListener('click', function () {
      if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
    });
    pagina.appendChild(chiudi);
    overlay.appendChild(pagina);
    document.getElementById('app').appendChild(overlay);
  }

  // ---------- collezione arredi ----------

  function costruisciCollezione() {
    var wrap = el('div', 'petq-collezione');
    var arr = currentState.arredi || {};
    var posseduti = arr.posseduti || [];
    var piazzati = arr.piazzati || { cucina: [], bagno: [], salone: [], camera: [] };
    var stanze = ['cucina', 'bagno', 'salone', 'camera'];
    var slotMax = (PETQ.arredi && PETQ.arredi.slotPerStanza) ? PETQ.arredi.slotPerStanza(currentState) : 3;

    var slotInfo = [];
    for (var s = 0; s < stanze.length; s++) {
      var occupati = (piazzati[stanze[s]] || []).length;
      slotInfo.push(traduci(capitalize(stanze[s])) + ' ' + occupati + '/' + slotMax);
    }
    wrap.appendChild(el('p', 'petq-hint', traduci('Slot: ') + slotInfo.join(' · ')));

    // conteggio copie totali per nome (per mostrare "Vendi" solo sui doppioni)
    var conteggi = {};
    function conta(voce) { conteggi[voce.nome] = (conteggi[voce.nome] || 0) + 1; }
    for (var p = 0; p < posseduti.length; p++) conta(posseduti[p]);
    for (var s2 = 0; s2 < stanze.length; s2++) {
      var lista = piazzati[stanze[s2]] || [];
      for (var j = 0; j < lista.length; j++) conta(lista[j]);
    }

    var vuota = true;
    for (var s3 = 0; s3 < stanze.length; s3++) {
      var listaP = piazzati[stanze[s3]] || [];
      for (var k = 0; k < listaP.length; k++) {
        wrap.appendChild(rigaArredo(listaP[k], stanze[s3], conteggi));
        vuota = false;
      }
    }
    for (var q = 0; q < posseduti.length; q++) {
      wrap.appendChild(rigaArredo(posseduti[q], null, conteggi));
      vuota = false;
    }

    if (vuota) {
      wrap.appendChild(el('p', 'petq-vuoto', traduci('Nessun arredo: completa le missioni per trovarne.')));
    }
    return wrap;
  }

  function rigaArredo(voce, piazzatoIn, conteggi) {
    var info = trovaArredoInfo(voce.nome);
    var STANZE_4 = ['cucina', 'bagno', 'salone', 'camera'];
    // PROTOTIPO 2, Blocco 7: la stanza destinazione e' quella dell'arredo (arredi.md colonna
    // "stanza") tra tutte e 4; fallback 'salone' se manca/ignota (es. arredi programmatici).
    // Caso speciale "ovunque" (arredi.md, es. Pianta Esotica): l'arredo e' piazzabile in QUALSIASI
    // delle 4 stanze -> sotto mostriamo 4 bottoni "Piazza in <stanza>" invece di uno solo.
    var ovunque = !!(info && info.stanza === 'ovunque');
    var stanzaDest = (info && STANZE_4.indexOf(info.stanza) !== -1) ? info.stanza : 'salone';

    var riga = el('div', 'petq-arredo-riga');
    var testi = el('div', 'petq-arredo-info');

    var titolo = traduci(voce.nome) + (piazzatoIn ? ' — in ' + traduci(capitalize(piazzatoIn)) : '');
    testi.appendChild(el('div', 'petq-arredo-nome', titolo));

    var dett = [];
    // Il testo-bonus arriva grezzo da content/arredi.md (che non ha gemello inglese): senza
    // traduci() il giocatore EN si vedeva "+1 Felicita' passiva" su tutti e 135 gli arredi.
    dett.push((info && info.bonus && info.bonus !== '—') ? traduci(info.bonus) : traduci('solo collezione'));
    // stanzaDest e' la chiave-dato ('salone', 'cucina'...): a schermo va tradotta come si fa gia'
    // per la stanza in cui l'arredo e' piazzato, poco sopra, altrimenti in EN esce "room: salone".
    if (!piazzatoIn) dett.push(traduci('stanza: ') + (ovunque ? traduci('ovunque') : traduci(capitalize(stanzaDest))));
    if (typeof voce.scadenzaMs === 'number') {
      var restante = voce.scadenzaMs - Date.now();
      dett.push(restante > 0 ? traduci('scade tra ') + formattaTempo(restante) : traduci('scaduto'));
    }
    testi.appendChild(el('div', 'petq-arredo-dett', dett.join(' · ')));
    riga.appendChild(testi);

    var btns = el('div', 'petq-arredo-btns');

    if (piazzatoIn) {
      var btnRim = el('button', 'petq-btn petq-btn-mini', traduci('Rimuovi'));
      btnRim.addEventListener('click', function () {
        var r = PETQ.arredi.rimuovi(currentState, voce.nome);
        dopoAzioneArredo(r);
      });
      btns.appendChild(btnRim);
    } else if (ovunque) {
      // arredo "ovunque": un bottone per ciascuna delle 4 stanze (la piazza() rifiuta da sola se
      // gli slot della stanza scelta sono pieni, col relativo toast).
      for (var st = 0; st < STANZE_4.length; st++) {
        (function (stanza) {
          var btn = el('button', 'petq-btn petq-btn-mini', traduci('Piazza in ') + traduci(capitalize(stanza)));
          btn.addEventListener('click', function () {
            var r = PETQ.arredi.piazza(currentState, voce.nome, stanza);
            dopoAzioneArredo(r);
          });
          btns.appendChild(btn);
        })(STANZE_4[st]);
      }
    } else {
      var btnPiazza = el('button', 'petq-btn petq-btn-mini', traduci('Piazza in ') + traduci(capitalize(stanzaDest)));
      btnPiazza.addEventListener('click', function () {
        var r = PETQ.arredi.piazza(currentState, voce.nome, stanzaDest);
        dopoAzioneArredo(r);
      });
      btns.appendChild(btnPiazza);
    }

    if ((conteggi[voce.nome] || 0) > 1) {
      var btnVendi = el('button', 'petq-btn petq-btn-mini petq-btn-danger', traduci('Vendi'));
      btnVendi.addEventListener('click', function () {
        var r = PETQ.arredi.vendi(currentState, voce.nome);
        dopoAzioneArredo(r);
      });
      btns.appendChild(btnVendi);
    }

    riga.appendChild(btns);
    return riga;
  }

  function dopoAzioneArredo(r) {
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    renderAzioni();
    if (r && r.msg) mostraToast(r.msg);
  }

  // ==================== TAB NEGOZIO (arredi) ====================
  // PROTOTIPO 2, Blocco 7 — comprare arredi decorativi/utility. Vende SOLO gli arredi con
  // "negozio N monete" nella colonna "Come si ottiene" di arredi.md (content.parseArredi li
  // espone con prezzoNegozio numerico). Gli arredi-trofeo/perk delle missioni (Coppa, Completo
  // martial artist, armi, Pattini da gara, ecc.) hanno prezzoNegozio null e NON compaiono qui:
  // restano ricompense uniche delle missioni, altrimenti si svaluta l'economia missioni.
  // Acquisto singolo: gli arredi decorativi sono unici, quindi se gia' posseduti/piazzati il
  // bottone diventa "Già in collezione" (niente doppioni dal negozio — i doppioni restano una
  // cosa dei drop missione, dove esiste gia' la rivendita al 50%).

  // vero se l'arredo (per nome) e' tra i posseduti o i piazzati in una qualsiasi stanza.
  function arredoGiaInCollezione(nome) {
    var arr = (currentState && currentState.arredi) || {};
    var posseduti = arr.posseduti || [];
    for (var i = 0; i < posseduti.length; i++) {
      if (posseduti[i].nome === nome) return true;
    }
    var piazzati = arr.piazzati || {};
    var stanze = Object.keys(piazzati);
    for (var s = 0; s < stanze.length; s++) {
      var lista = piazzati[stanze[s]] || [];
      for (var j = 0; j < lista.length; j++) {
        if (lista[j].nome === nome) return true;
      }
    }
    return false;
  }

  // riassunto breve del bonus/effetto per la riga negozio (riusa la colonna Bonus grezza).
  function descriviBonusArredo(info) {
    // v. sopra (riga arredo in collezione): colonna Bonus grezza, va tradotta a schermo perche'
    // content/arredi.md esiste solo in italiano.
    if (info && info.bonus && info.bonus !== '—' && info.bonus !== '-') return traduci(info.bonus);
    return traduci('solo decorativo');
  }

  // TODO (PROTOTIPO 2, Blocco 7 — batch separato, richiede decisione di design del fondatore):
  // la sezione "Amplia slot" (comprare slot arredo aggiuntivi per stanza) andra' aggiunta come
  // 4a sotto-scheda del negozio. Oggi sono 3 posizioni fisse disegnate per stanza (rooms.js
  // SLOT_SPOTS): l'espansione richiede nuovi supporti disegnati + progressione prezzi.

  function rigaNegozioArredo(info, stanza) {
    var riga = el('div', 'petq-shop-riga');

    // Negozio visivo (GDD 24 ago 2026): l'arredo si VEDE — stessa iconaOggetto della Collezione
    // e dei Giochi (ripiega da sola sulla sagoma di categoria se il disegno manca).
    riga.appendChild(iconaOggetto(info.nome, 'arredo'));

    var testi = el('div', 'petq-shop-info');
    testi.appendChild(el('div', 'petq-cibo-nome', traduci(info.nome)));
    testi.appendChild(el('div', 'petq-cibo-effetti',
      descriviBonusArredo(info) + traduci(' — stanza: ') + traduci(capitalize(stanza)) + ' — ' + info.prezzoNegozio + traduci(' monete')));
    riga.appendChild(testi);

    var gia = arredoGiaInCollezione(info.nome);
    if (gia) {
      var giaBtn = el('button', 'petq-btn petq-btn-mini', traduci('Già in collezione'));
      giaBtn.disabled = true;
      giaBtn.title = traduci('Arredo unico: lo possiedi già.');
      riga.appendChild(giaBtn);
      return riga;
    }

    var btn = el('button', 'petq-btn petq-btn-mini', traduci('Compra'));
    if ((currentState.coins || 0) < info.prezzoNegozio) {
      btn.disabled = true;
      btn.title = traduci('Monete insufficienti.');
    }
    btn.addEventListener('click', function () { eseguiAcquistoArredo(info, riga); });
    riga.appendChild(btn);
    return riga;
  }

  // Compra 1 arredo: rivalida prezzo e possesso (niente doppioni dal negozio, l'arredo e' unico),
  // scala le monete e chiama arredi.aggiungi (finisce nei POSSEDUTI; il giocatore lo piazza poi
  // dalla Collezione nella stanza giusta). Ridisegna il pannello negozio (sezione Arredi) per
  // aggiornare monete/stato bottone.
  function eseguiAcquistoArredo(info, rigaEl) {
    if (!currentState) return;
    if (arredoGiaInCollezione(info.nome)) {
      shakeCard(rigaEl);
      mostraToast(traduci('Ce l\'hai già in collezione.'));
      aggiornaDettaglioMappa(statoMappa());
      return;
    }
    if (typeof info.prezzoNegozio !== 'number') {
      shakeCard(rigaEl);
      mostraToast(traduci('Questo arredo non è in vendita.'));
      return;
    }
    if ((currentState.coins || 0) < info.prezzoNegozio) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto');
      shakeCard(rigaEl);
      mostraToast(traduci('Monete insufficienti.'));
      return;
    }
    var r = PETQ.arredi.aggiungi(currentState, info.nome);
    if (!r || !r.ok) {
      shakeCard(rigaEl);
      mostraToast((r && r.msg) || traduci('Acquisto non riuscito.'));
      return;
    }
    currentState.coins -= info.prezzoNegozio;
    if (PETQ.audio) PETQ.audio.suona('acquisto');
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    aggiornaDettaglioMappa(statoMappa());
    mostraToast(traduci(info.nome) + traduci(' comprato: è nella Collezione (Salone), ora piazzalo nella stanza.'));
  }

  // ==================== TAB MISSIONI ====================

  function renderTabMissioni(container) {
    if (!PETQ.missions) {
      container.appendChild(el('p', 'petq-vuoto', traduci('Modulo missioni non disponibile.')));
      return;
    }
    if (mappaDisponibile()) {
      renderTabMissioniMappa(container);
    } else {
      renderTabMissioniLista(container);
    }
  }

  // guard sulle API mappa del modulo grafica (in arrivo in parallelo):
  // finché mancano, la tab resta la lista di card
  // Mappa QUARTIERE (richiesta fondatore 28 lug 2026): la tab ora disegna SOLO il quartiere di
  // oggi (rooms.drawMappaQuartiere), non piu' l'atlante intero (rooms.drawMappa) — la guardia
  // controlla quindi le API della vista quartiere (drawMappaQuartiere/altezzaMappaQuartiere/
  // rettangoliQuartiere), non piu' drawMappa/_mappaPins/_MAPPA_H che restano disponibili per la
  // vista d'insieme (bottone "Vedi tutta la città", v. mappaVistaCitta subito sotto).
  function mappaDisponibile() {
    return !!(PETQ.rooms && PETQ.rooms.drawMappaQuartiere && PETQ.rooms.altezzaMappaQuartiere &&
              PETQ.rooms.rettangoliQuartiere && PETQ.rooms._MAPPA_W > 0);
  }

  // ===== Interruttore vista mappa: quartiere (compatto, di oggi) / città intera (atlante) =====
  // Richiesta fondatore 28 lug 2026 ("metti la possibilita' di vedere l'intera mappa per
  // praticita'"): di default la tab disegna il quartiere compatto (solo i luoghi attivi oggi, v.
  // sopra), ma la vecchia mappa d'insieme coi 99 luoghi (rooms.drawMappa/altezzaMappa/_mappaPins,
  // mai rimossa) resta a un tap di distanza per farsi un'idea della città intera. mappaVistaCitta
  // e' una PREFERENZA DI SESSIONE (mai salvata: non e' stato di gioco, solo comodita' di
  // visualizzazione) — azzerata a false ad ogni cambio tab (v. click tab in mostraCasa) e ad ogni
  // avvio missione (v. eseguiPartenza), cosi' il giocatore non resta bloccato sull'atlante mentre
  // gioca davvero: la vista utile per agire e' sempre quella di oggi.
  var mappaVistaCitta = false;

  // Rettangoli slot della vista mappa CORRENTE: fonte UNICA per ogni hit-test/etichetta/
  // conversione di coordinate, al posto di un if ripetuto in ogni punto che tocca i rettangoli
  // (quartiere: gli slot cambiano posto ogni giorno secondo la rosa, v. rooms.js
  // rettangoliQuartiere; città: posizioni FISSE dell'atlante, v. rooms.js _mappaPins).
  function rettangoliMappaCorrente() {
    if (mappaVistaCitta) return (PETQ.rooms && PETQ.rooms._mappaPins) ? PETQ.rooms._mappaPins : {};
    return (PETQ.rooms && PETQ.rooms.rettangoliQuartiere) ? PETQ.rooms.rettangoliQuartiere() : {};
  }

  // Altezza logica della vista mappa CORRENTE (sm = stato mappa, v. statoMappa sopra, stessa
  // forma per entrambe le funzioni rooms): quartiere = altezzaMappaQuartiere(sm) (76 corta/130
  // piena secondo quanti luoghi sono attivi oggi), città = altezzaMappa(sm) (456 corta/530 piena
  // secondo sm.imprese). Stesso motivo di rettangoliMappaCorrente sopra: fonte unica invece di un
  // if ripetuto ovunque.
  function altezzaMappaCorrente(sm) {
    if (mappaVistaCitta) return (PETQ.rooms && PETQ.rooms.altezzaMappa) ? PETQ.rooms.altezzaMappa(sm) : 0;
    return (PETQ.rooms && PETQ.rooms.altezzaMappaQuartiere) ? PETQ.rooms.altezzaMappaQuartiere(sm) : 0;
  }

  // --- fallback: lista di card (comportamento pre-mappa, invariato) ---

  function renderTabMissioniLista(container) {
    // giorno 1: solo il tutorial M0, flusso dedicato senza rosa
    if (!currentState.tutorialFatto) {
      var m0 = PETQ.missions.tutorialDaProporre(currentState);
      if (m0) {
        container.appendChild(cardTutorial(m0));
        return;
      }
    }

    if (currentState.missione) {
      container.appendChild(cardMissioneInCorso());
      return;
    }

    if (missioneEsauritaOggi()) {
      container.appendChild(el('p', 'petq-hint', traduci('Missione di oggi completata: torna domani per una nuova rosa.')));
      return;
    }

    if (currentState.passeggiata) {
      var hintPL = el('p', 'petq-hint', (currentState.pet.nome || traduci('Il pet')) + traduci(' è a passeggio: torna tra ~') + minutiPasseggiataRimasti(currentState) + 'm. 🚶');
      hintPL.id = 'petq-passeggiata-hint'; // countdown aggiornato dal tick
      container.appendChild(hintPL);
      return;
    }

    if (PETQ.missions.orarioMissioniAperto && !PETQ.missions.orarioMissioniAperto(currentState)) {
      container.appendChild(el('p', 'petq-hint', traduci('È tardi: le missioni si fanno dalle 6:00 alle 19:00.')));
      return;
    }

    container.appendChild(el('p', 'petq-hint', traduci('La rosa di oggi: scegli una missione e mandaci ') + (currentState.pet.nome || traduci('il pet')) + '.'));

    var rosa = PETQ.missions.rosaDelGiorno(currentState);
    if (!rosa || rosa.length === 0) {
      container.appendChild(el('p', 'petq-vuoto', traduci('Nessuna missione disponibile.')));
      return;
    }
    for (var i = 0; i < rosa.length; i++) {
      container.appendChild(cardMissione(rosa[i]));
    }
  }

  // --- mappa della città ---

  // Limite missioni/giorno (fix playtest, esteso P3 BATCH 4 "missioni_giorno=2", Lavoro in
  // Nero): missions.avvia() rifiuta comunque (fonte di verità), questo è solo per la UI (mappa
  // senza pin attivi + hint dedicato) — stesso contatore/tetto usati là, così l'hint non mente a
  // un pet con Lavoro in Nero che può ancora fare una seconda missione. Il tutorial M0 non conta
  // (non passa da missioniOggiCount, v. missions.js risolviTutorial).
  function missioneEsauritaOggi() {
    var maxMissioniGiorno = (PETQ.talenti && PETQ.talenti.missioniPerGiorno) ? PETQ.talenti.missioniPerGiorno(currentState) : 1;
    var oggi = PETQ.clock.giornoCorrente(currentState);
    var fatteOggi = (currentState.missioniOggiGiorno === oggi) ? (currentState.missioniOggiCount || 0) : 0;
    return fatteOggi >= maxMissioniGiorno;
  }

  // Stato corrente della mappa: quali pin sono attivi/tappabili, quale luogo è "in corso",
  // e le schede per costruire il pannello dettaglio.
  // Negozio unico (GDD "Economia" -> "Spesa e dispensa", fix fondatore): il pin del Negozio
  // (m0) è SEMPRE illuminato una volta sbloccato (state.negozioSbloccato), indipendentemente
  // dalla rosa/missione in corso — non fa mai parte della rotazione missioni (resta escluso da
  // rosaDelGiorno), ma resta sempre tappabile per il menu acquisto (v. hitShopPin).
  function statoMappa() {
    if (!currentState.tutorialFatto) {
      var m0 = PETQ.missions.tutorialDaProporre(currentState);
      // pre-tutorial: il pet non e' ancora adulto, quindi nessuna Grande Impresa possibile
      // (v. missions.impresaDellaRun, che per design ritorna null prima dello stadio adulto).
      if (m0) return { attivi: ['m0'], inCorso: null, tutorial: m0, rosa: [m0], imprese: false };
    }
    var negozioAttivo = !!currentState.negozioSbloccato;
    // Pin "Pimp My Pet" (Clinica di Modding, m17): RIMOSSO su decisione del fondatore (28 lug
    // 2026, "crea problemi e non serve") — non calcoliamo piu' una clinicaPendente ne' accendiamo
    // il pin. V. mostraEvoluzione (il bottone "Continua" ora porta sempre alla casa) e
    // mostraTeenIntro/controllaTeenIntroPendente (funzioni lasciate senza chiamanti, commento li').
    // Impresa della run (P3, Grandi Imprese): PIN FISSO da quando il pet e' adulto (stesso
    // pattern usato in passato dal pin permanente della Clinica sopra) — SEMPRE visibile
    // (rosa/orario/tetto giornaliero non lo nascondono), apribile come una card missione
    // normale (aggiunta anche a 'rosa' cosi' aggiornaDettaglioMappa/cardMissione la trovano):
    // l'AVVIO vero passa comunque da missions.avvia come qualsiasi missione, quindi rispetta da
    // solo orarioMissioniAperto/il tetto missioni-al-giorno (nessun bypass qui, solo pin/card
    // sempre raggiungibili). Sparisce quando e' in missioniFatte (successo/super); il fallimento
    // la lascia (ritenta=1 gia' lo garantisce, v. missions.js). Spenta SOLO mentre il pet e' IN
    // MISSIONE (branch sotto).
    var impresaScheda = (PETQ.missions.impresaDellaRun) ? PETQ.missions.impresaDellaRun(currentState) : null;
    var impresaPendente = !!(impresaScheda && !(currentState.missioniFatte && currentState.missioniFatte[impresaScheda.id] != null));
    // Campo "imprese" (GDD/fix 27 lug 2026 "zona Grandi Imprese sempre disegnata"): usato da
    // rooms.altezzaMappa per decidere se la mappa e' corta o include la fascia finale. STESSA
    // fonte di verita' di impresaPendente (quella gia' usata per accendere/aggiungere il pin
    // qui sopra e sotto): non si ricalcola nulla di nuovo, non si guarda mai lo stadio del pet
    // direttamente — se impresaDellaRun torna null (pet non ancora adulto) o l'Impresa e' gia'
    // stata completata, la mappa resta/torna corta.
    if (currentState.missione) {
      return { attivi: negozioAttivo ? ['m0'] : [], inCorso: currentState.missione.id, tutorial: null, rosa: [], imprese: impresaPendente };
    }
    if (missioneEsauritaOggi()) {
      var attiviEs = negozioAttivo ? ['m0'] : [];
      var rosaEs = [];
      if (impresaPendente) { attiviEs.push(impresaScheda.id); rosaEs.push(impresaScheda); }
      return { attivi: attiviEs, inCorso: null, tutorial: null, rosa: rosaEs, esaurita: true, imprese: impresaPendente };
    }
    // Missioni solo di giorno (decisione fondatore, playtest 7 lug 2026): fuori dalla finestra
    // 8-18 i pin missione si spengono (il Negozio resta aperto). Il tutorial e' esente (branch
    // sopra). Il gate vero e' in missions.avvia: questo e' solo lo specchio in mappa.
    if (PETQ.missions.orarioMissioniAperto && !PETQ.missions.orarioMissioniAperto(currentState)) {
      var attiviFO = negozioAttivo ? ['m0'] : [];
      var rosaFO = [];
      if (impresaPendente) { attiviFO.push(impresaScheda.id); rosaFO.push(impresaScheda); }
      return { attivi: attiviFO, inCorso: null, tutorial: null, rosa: rosaFO, fuoriOrario: true, imprese: impresaPendente };
    }
    var rosa = PETQ.missions.rosaDelGiorno(currentState) || [];
    var attivi = [];
    for (var i = 0; i < rosa.length; i++) attivi.push(rosa[i].id);
    if (negozioAttivo && attivi.indexOf('m0') === -1) attivi.push('m0');
    if (impresaPendente && attivi.indexOf(impresaScheda.id) === -1) {
      attivi.push(impresaScheda.id);
      rosa = rosa.concat([impresaScheda]);
    }
    return { attivi: attivi, inCorso: null, tutorial: null, rosa: rosa, imprese: impresaPendente };
  }

  // Bottone toggle quartiere/città (v. mappaVistaCitta sopra): piccolo, sopra la mappa, stessa
  // classe petq-btn-mini gia' usata da tutti gli altri bottoncini della mappa (Compra, Chiudi,
  // ecc.) — nessuno stile nuovo. L'etichetta descrive la vista in cui si ANDREBBE cliccando
  // (stesso pattern del bottone Collezione, che alterna "Collezione"/"Chiudi collezione").
  // renderAzioni() ricostruisce l'intera tab: nuovo canvas, nuova altezza, nuovo bottone con
  // l'etichetta aggiornata — non serve toccare nient'altro a mano.
  function bottoneVistaMappa() {
    var etichetta = mappaVistaCitta ? traduci('Torna al quartiere') : traduci('Vedi tutta la città');
    var btn = el('button', 'petq-btn petq-btn-mini', etichetta);
    btn.addEventListener('click', function () {
      mappaVistaCitta = !mappaVistaCitta;
      // Riazzera la guardia "centra una volta per apertura tab" (v. missioniMappaCentrata sotto):
      // il cambio vista e' come una nuova apertura, e passando alla città la centratura sui pin
      // della rosa del giorno (centraSuMissioniDelGiorno) torna utile — nella vista quartiere,
      // gia' compatta, il ritentativo non trova nulla da scrollare ed e' innocuo.
      missioniMappaCentrata = false;
      renderAzioni();
    });
    return btn;
  }

  function renderTabMissioniMappa(container) {
    var sm = statoMappa();
    var nome = currentState.pet.nome || traduci('il pet');

    var hint;
    if (currentState.passeggiata) hint = nome + traduci(' è a passeggio: torna tra ~') + minutiPasseggiataRimasti(currentState) + 'm. 🚶';
    else if (sm.inCorso) hint = nome + traduci(' è in giro per la città: eccolo sulla mappa. Il Negozio resta aperto.');
    else if (sm.tutorial) hint = traduci('Primo giorno: tocca il pin del negozio di giocattoli.');
    else if (sm.esaurita) hint = traduci('Missione di oggi completata: torna domani per una nuova rosa. Il Negozio resta aperto.');
    else if (sm.fuoriOrario) hint = traduci('È tardi: le missioni si fanno dalle 6:00 alle 19:00. Il Negozio resta aperto.');
    else hint = traduci('Scegli una destinazione per ') + nome + traduci(', o fai la spesa al Negozio.');
    var hintEl = el('p', 'petq-hint', hint);
    if (currentState.passeggiata) hintEl.id = 'petq-passeggiata-hint'; // countdown aggiornato dal tick
    container.appendChild(hintEl);

    // Passeggiata serale (playtest 8 lug 2026): quando le missioni chiudono (18-21), qui c'e'
    // l'attivita' della sera — 30 min di gioco, 1/die, micro-evento al rientro (v. pet.js).
    if (!currentState.passeggiata && !sm.inCorso && !currentState.sonno &&
        PETQ.pet.orarioPasseggiataAperto && PETQ.pet.orarioPasseggiataAperto(currentState) &&
        currentState.passeggiataGiorno !== PETQ.clock.giornoCorrente(currentState)) {
      var passBtn = el('button', 'petq-btn petq-btn-primario', traduci('🚶 Passeggiata (30 min)'));
      passBtn.addEventListener('click', function () {
        var r = PETQ.pet.avviaPasseggiata(currentState);
        if (!r.ok) { mostraToast(r.msg); return; }
        PETQ.save.save(currentState);
        // Battuta del socio alla partenza (pool 'passeggiata_partenza', agganciata 9 lug 2026),
        // fallback al msg di avvio se il pool è vuoto.
        var battutaP = PETQ.dialog.say(currentState.pet, 'passeggiata_partenza', currentState);
        mostraToast((battutaP && battutaP !== '...') ? battutaP : r.msg);
        disegnaStanzaEPet(currentState);
        renderAzioni(); // ri-renderizza la tab (hint "a passeggio", bottone via)
      });
      container.appendChild(passBtn);
    }

    // Bottone "Vedi tutta la città" / "Torna al quartiere" (v. mappaVistaCitta/bottoneVistaMappa
    // sopra): sopra la mappa, accanto all'hint appena appeso.
    container.appendChild(bottoneVistaMappa());

    var mappaWrap = el('div', 'petq-mappa-wrap');
    mappaWrap.id = 'petq-mappa-wrap';

    var canvas = document.createElement('canvas');
    canvas.id = 'petq-canvas-mappa';
    canvas.className = 'petq-canvas-mappa';
    // Altezza PARAMETRICA della vista mappa CORRENTE (quartiere: 76 corta con meno di 4 luoghi
    // attivi oggi, 130 piena altrimenti, v. rooms.js altezzaMappaQuartiere; città: 456 corta/530
    // piena secondo sm.imprese, v. rooms.js altezzaMappa — v. altezzaMappaCorrente sopra per la
    // scelta fra le due) — serve l'altezza CORRENTE per lo stato di adesso, altrimenti il disegno
    // finirebbe SCHIACCIATO o con fondo scala vuoto in un canvas della misura sbagliata: stesso
    // errore gia' fatto due volte in questo progetto (v. rooms.js draw()/H e la vecchia
    // altezzaMappa) se l'aspect-ratio non segue l'altezza vera.
    var altMappa = altezzaMappaCorrente(sm);
    canvas.width = PETQ.rooms._MAPPA_W;
    canvas.height = altMappa;
    canvas.style.aspectRatio = PETQ.rooms._MAPPA_W + ' / ' + altMappa;
    mappaWrap.appendChild(canvas);
    container.appendChild(mappaWrap);

    var dettaglio = el('div', 'petq-mappa-dettaglio');
    dettaglio.id = 'petq-mappa-dettaglio';
    dettaglio.style.display = 'none';
    container.appendChild(dettaglio);

    installaPointerMappa(canvas);
    ridisegnaMappa();
    aggiornaEtichetteMappa(sm);
    aggiornaDettaglioMappa(sm);
    // L'ordine conta: prima si CALCOLA l'altezza vera della mappa in base allo spazio davvero
    // disponibile (adattaAltezzaMappa), poi si decide se serve scrollare per raggiungere i pin
    // della rosa del giorno (centraSuMissioniDelGiorno) — scrollare prima di conoscere l'altezza
    // vera userebbe ancora le misure sbagliate/stantie del vecchio vincolo CSS a costante fissa.
    adattaAltezzaMappa(canvas);
    centraSuMissioniDelGiorno(canvas, sm);
  }

  // Guardia di modulo per il listener di resize di adattaAltezzaMappa sotto (stesso pattern di
  // ripresaRegistrata in main.js): il listener va attaccato a window UNA SOLA VOLTA per l'intera
  // vita della pagina, non ad ogni ingresso nella tab Missioni, altrimenti se ne accumulerebbero
  // molti tutti identici.
  var resizeMappaRegistrato = false;

  // Calcola e applica l'altezza della mappa in base allo spazio verticale REALMENTE disponibile,
  // al posto della vecchia costante indovinata in CSS (era calc(100vh - 250px) / calc(100dvh -
  // 250px): 250px doveva rappresentare lo spazio sopra la mappa, ma quello spazio cambia con la
  // dimensione del font, con la presenza del bottone passeggiata serale, con l'hint che va a capo
  // su schermi stretti e con l'HUD compatta o no in tab Missioni — nessuna costante fissa insegue
  // tutte queste variabili, e infatti sforava ancora (misurato: 412x915 -> canvas 271x665 da
  // y=295, arriva a y=960, 45px oltre lo schermo). Chiamata da renderTabMissioniMappa PRIMA di
  // centraSuMissioniDelGiorno (v. sopra): prima si dimensiona la mappa con lo spazio vero, poi si
  // decide se serve scrollare.
  function adattaAltezzaMappa(canvas) {
    if (!canvas) return;
    registraResizeMappa();

    // Differito: il canvas e' appena stato appeso al DOM (o la tab e' appena stata
    // ri-renderizzata) e il layout potrebbe non essere ancora calcolato — stesso motivo del
    // setTimeout in centraSuMissioniDelGiorno qui sotto, altrimenti getBoundingClientRect
    // darebbe misure stantie.
    setTimeout(function () {
      var r = canvas.getBoundingClientRect();
      var MARGINE_SOTTO = 12; // un filo d'aria sotto la mappa, cosi' non tocca il bordo schermo

      var disponibile = window.innerHeight - r.top - MARGINE_SOTTO;
      // Sotto questa soglia e' giusto tornare a scrollare invece di ridurre la mappa a un
      // francobollo illeggibile (finestre bassissime, es. rotazione orizzontale sul telefono).
      if (disponibile < 360) disponibile = 360;

      // Tetto: la mappa non va MAI ingrandita oltre la sua dimensione naturale a piena larghezza
      // dello spazio disponibile, altrimenti su schermi molto alti sfonderebbe di lato.
      // ATTENZIONE, errore gia' fatto una volta: la larghezza disponibile NON va letta da
      // #petq-mappa-wrap, che ora e' width:fit-content e quindi si stringe attorno al canvas
      // (v. style.css: deve combaciare col canvas perche' le etichette dei luoghi sono
      // posizionate in percentuale su di lui). Misurarlo li' e' un cane che si morde la coda:
      // il tetto risulta uguale all'altezza corrente e la mappa collassa alla sua dimensione
      // nativa 216x530, piccolissima. Va letto il GENITORE del wrap (#petq-azioni), che e'
      // l'unico a conoscere lo spazio orizzontale vero, al netto del suo padding.
      var wrap = document.getElementById('petq-mappa-wrap');
      var contenitore = wrap ? wrap.parentElement : null;
      var larghezzaContenitore = contenitore ? contenitore.clientWidth : r.width;
      // Altezza CORRENTE della vista mappa attiva (76 corta o 130 piena per il quartiere, 456 o
      // 530 per la città, v. altezzaMappaCorrente sopra): senza questo il tetto userebbe una
      // proporzione sbagliata, lasciando un vuoto sotto o schiacciando il disegno. Con la mappa
      // quartiere (molto piu' bassa dell'atlante) questo tetto e' quasi sempre PIU' STRETTO di
      // "disponibile", quindi la mappa finisce quasi sempre alla sua dimensione naturale, piccola
      // — e' l'effetto voluto: la nuova mappa ci sta tutta senza bisogno di riempire lo spazio
      // verticale. Con la vista città (molto piu' alta) il tetto torna a limitare come faceva
      // l'atlante originale.
      var altMappaCorr = altezzaMappaCorrente(statoMappa());
      var tetto = larghezzaContenitore * (altMappaCorr / PETQ.rooms._MAPPA_W);
      if (disponibile > tetto) disponibile = tetto;

      // La larghezza segue da sola: il canvas ha gia' un aspect-ratio inline impostato in
      // renderTabMissioniMappa (canvas.style.aspectRatio) — qui NON va toccato.
      canvas.style.height = disponibile + 'px';
    }, 0);
  }

  // Riadatta l'altezza della mappa quando la finestra cambia dimensione (rotazione del telefono,
  // resize della finestra su PC): SOLO se il giocatore e' davvero sulla tab Missioni con la mappa
  // ancora nel DOM, altrimenti non fa nulla. Niente ResizeObserver: deve girare anche su WebView
  // datate.
  function registraResizeMappa() {
    if (resizeMappaRegistrato) return;
    resizeMappaRegistrato = true;
    window.addEventListener('resize', function () {
      if (currentStanza !== 'missioni') return;
      var canvasMappa = document.getElementById('petq-canvas-mappa');
      if (!canvasMappa) return;
      adattaAltezzaMappa(canvasMappa);
    });
  }

  // Guardia di modulo per centraSuMissioniDelGiorno sotto: la mappa e' MOLTO piu' alta dello
  // schermo (canvas logico 216x530, misurato dal vivo 874px CSS a 412x915 con meno di due terzi
  // visibili) e i pin della rosa del giorno possono nascere sotto il fold, quindi la vista va
  // centrata sul baricentro dei pin — ma SOLO all'ingresso nella tab, mai ad ogni ridisegno
  // interno: renderTabMissioniMappa (sopra) puo' essere richiamata anche dal BATTITO da 30s in
  // modo indiretto (render() -> controllaSonnoScaduto/controllaGiocoScaduto/
  // controllaAllenamentoScaduto/controllaPasseggiataScaduta -> renderAzioni() -> renderTabMissioni
  // -> renderTabMissioniMappa, se un allenamento/gioco/sonno/passeggiata si risolve mentre il
  // giocatore e' fermo su questa tab a leggere la mappa), e in quel caso NON deve tirargli lo
  // schermo sotto le dita. missioniMappaCentrata ricorda se abbiamo gia' tentato la centratura per
  // l'apertura corrente della tab; viene azzerata al cambio tab (v. click tab, currentStanza =
  // chiave, ~riga 759) E al toggle vista quartiere/città (v. bottoneVistaMappa sopra), cosi' il
  // prossimo ingresso/cambio vista la ritenta da capo.
  var missioniMappaCentrata = false;

  // Centra lo scroll di pagina sul baricentro Y dei pin della rosa del giorno, ma solo se almeno
  // uno di quei pin e' davvero tagliato/invisibile sotto il bordo inferiore dello schermo (fix
  // "35 pin su 99 nascono sotto il bordo inferiore", caso reale rosa [m76,m7,m80] -> m76 tagliato
  // e m80 del tutto invisibile). Esclude il pin del Negozio (_shopPinId, sempre acceso, non e'
  // una missione del giorno) dal calcolo. Chiamata una sola volta per apertura tab/cambio vista
  // (v. guardia missioniMappaCentrata sopra).
  // Mappa QUARTIERE (richiesta fondatore 28 lug 2026): con la mappa nuova, alta al massimo 130
  // logici su 216 di larghezza e con TUTTI i pin sempre dentro lo slot 64x38 assegnato, il caso
  // "pin tagliato sotto il bordo" che ha motivato questa funzione non dovrebbe piu' presentarsi
  // — ma la funzione resta (richiesta esplicita, non va rimossa) e va comunque fatta puntare ai
  // rettangoli GIUSTI della vista ATTIVA (rettangoliMappaCorrente sopra: rettangoliQuartiere per il
  // quartiere, _mappaPins per la città) — usare la fonte sbagliata farebbe calcolare uno scroll a
  // caso. Nella vista quartiere "deveScrollare" sotto risultera' quasi sempre false da solo
  // (nessun pin sotto il bordo); nella vista città torna utile come ai tempi dell'atlante intero.
  function centraSuMissioniDelGiorno(canvas, sm) {
    if (missioniMappaCentrata) return;
    // segna "gia' tentato per questa apertura" subito, a prescindere dall'esito: eventuali
    // ri-render della stessa apertura (es. bottone passeggiata dentro la tab) non devono ritentare
    missioniMappaCentrata = true;
    if (!canvas || !sm) return;

    var pins = rettangoliMappaCorrente();
    var shopPinId = (PETQ.rooms && PETQ.rooms._shopPinId) || 'm0';
    var attivi = sm.attivi || [];
    var rimasti = [];
    for (var i = 0; i < attivi.length; i++) {
      if (attivi[i] === shopPinId) continue; // il Negozio non e' una missione del giorno
      var rect = pins[attivi[i]];
      if (rect) rimasti.push(rect);
    }
    if (rimasti.length === 0) return; // nessun pin missione: niente da centrare

    // Differito: il canvas e' appena stato appeso al DOM, il layout potrebbe non essere ancora
    // calcolato e getBoundingClientRect darebbe misure sbagliate (rect.height 0 o stantia).
    setTimeout(function () {
      var r = canvas.getBoundingClientRect();
      if (!r.height) return; // ancora non misurabile: rinuncia, non e' un caso critico
      // altezza CORRENTE della vista mappa attiva (v. altezzaMappaCorrente sopra): sm e' gia' un
      // parametro di questa funzione.
      var scala = r.height / altezzaMappaCorrente(sm);

      // Condizione di attivazione: procede SOLO se almeno un pin rimasto e' tagliato/invisibile
      // (bordo inferiore sotto window.innerHeight). Se sono gia' tutti visibili non tocca lo
      // scroll: spostare la vista quando non serve e' fastidioso.
      var deveScrollare = false;
      var sommaCentriY = 0;
      for (var j = 0; j < rimasti.length; j++) {
        var p = rimasti[j];
        sommaCentriY += (p.y + p.h / 2);
        var bordoInferiorePx = r.top + (p.y + p.h) * scala;
        if (bordoInferiorePx > window.innerHeight) deveScrollare = true;
      }
      if (!deveScrollare) return;

      var baricentroLogico = sommaCentriY / rimasti.length;
      var yPagina = (r.top + window.pageYOffset) + baricentroLogico * scala;
      // il baricentro finisce al 40% dell'altezza schermo: spazio sopra per il contesto, sotto
      // per il pannello dettaglio che compare al tap
      var target = yPagina - window.innerHeight * 0.40;
      var maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (target < 0) target = 0;
      if (target > maxScroll) target = maxScroll;

      // Verifica differita basata sul RISULTATO, non sull'eccezione: su alcune WebView Android
      // window.scrollTo({top,behavior:'smooth'}) non lancia NESSUN errore e semplicemente non
      // scrolla (verificato dal vivo: scrollTo({top:150,behavior:'smooth'}) lascia pageYOffset a
      // 0, mentre scrollTo(0,150) subito dopo lo porta a 150 — capita quando il compositing e'
      // sospeso, per throttling, prefers-reduced-motion o implementazioni parziali dello smooth
      // scroll). Il solo try/catch non basta: copre solo il caso, oggi raro, di un motore che
      // rifiuta l'oggetto opzioni; il caso reale osservato e' "accetta l'oggetto, non fa nulla".
      // Quindi: si tenta il morbido, e SOLO se dopo un tempo ragionevole la pagina non si e'
      // mossa affatto (mentre il bersaglio era lontano) si applica il salto secco di ripiego.
      var partenza = window.pageYOffset;
      try {
        window.scrollTo({ top: target, behavior: 'smooth' });
      } catch (e) {
        // vecchie WebView che non supportano l'oggetto options di scrollTo: ricadi sulla forma
        // posizionale secca, senza animazione
        window.scrollTo(0, target);
        return;
      }
      // 350ms: uno scroll morbido reale ha gia' iniziato a muoversi ben prima di questa soglia,
      // quindi non e' un valore scelto a caso — non allungarlo, altrimenti il salto secco di
      // ripiego diventa percepibile come uno scatto tardivo invece che una correzione silenziosa.
      setTimeout(function () {
        var mossoDiPoco = Math.abs(window.pageYOffset - partenza) < 4;
        var bersaglioLontano = Math.abs(target - partenza) >= 8;
        if (mossoDiPoco && bersaglioLontano) {
          // lo smooth non ha lanciato ma non ha nemmeno scrollato: applica il salto secco, meglio
          // tardi e senza animazione che una centratura fallita in silenzio
          window.scrollTo(0, target);
        }
      }, 350);
    }, 0);
  }

  function ridisegnaMappa() {
    if (!mappaDisponibile()) return;
    var canvas = document.getElementById('petq-canvas-mappa');
    if (!canvas || !currentState) return;
    var sm = statoMappa();
    // Sincronizza l'altezza del canvas con la vista mappa ATTIVA (quartiere: 76 corta con meno di
    // 4 luoghi attivi oggi/130 piena, v. rooms.js altezzaMappaQuartiere; città: 456 corta/530
    // piena secondo sm.imprese, v. rooms.js altezzaMappa — v. altezzaMappaCorrente sopra):
    // renderTabMissioniMappa la imposta alla costruzione, ma questa funzione gira ad OGNI battito
    // del loop idle (v. chiamante disegnaStanzaEPet) e puo' quindi disegnare con una rosa/pin
    // pendenti cambiati nel frattempo (es. missione finita, Impresa completata) mentre il canvas
    // e' rimasto quello vecchio — senza, il disegno finirebbe con l'altezza NUOVA
    // SCHIACCIATA/allungata in un canvas della misura sbagliata (stesso identico errore gia' fatto
    // due volte in questo progetto, v. disegnaStanzaEPet sopra per un precedente esatto). Guardia
    // sul cambio per non toccare il canvas ad ogni frame quando e' gia' giusto.
    var altMappa = altezzaMappaCorrente(sm);
    if (canvas.height !== altMappa) {
      canvas.height = altMappa;
      canvas.style.aspectRatio = PETQ.rooms._MAPPA_W + ' / ' + altMappa;
    }
    // Stesso oggetto stato per entrambe le funzioni di disegno rooms (stessa forma attivi/
    // inCorso/frame/imprese, v. commento su drawMappa in rooms.js): quartiere disegna SOLO i
    // luoghi attivi oggi negli slot del giorno, città disegna l'atlante intero coi 99 luoghi
    // (spenti quelli non attivi) — v. mappaVistaCitta/bottoneVistaMappa sopra per il toggle.
    var statoDisegno = { attivi: sm.attivi, inCorso: sm.inCorso, frame: idleFrame, imprese: sm.imprese };
    if (mappaVistaCitta) PETQ.rooms.drawMappa(canvas, statoDisegno);
    else PETQ.rooms.drawMappaQuartiere(canvas, statoDisegno);
  }

  // Etichette col nome sui luoghi attivi (fix playtest, GDD "Mappa leggibilità"): overlay HTML
  // posizionati in percentuale sui rettangoli pin (stessa tecnica delle hotzone stanza),
  // chip piccole semi-trasparenti con testo nitido — la pixel art da sola non basta a
  // riconoscere i luoghi. Nomi brevi indipendenti dal titolo scheda (che può cambiare).
  var NOME_BREVE_LUOGO = {
    m0: 'Negozio', m1: 'Sala Giochi', m2: 'Parco', m3: 'Dojo', m4: 'Biblioteca',
    m5: 'Industria', m6: 'Studio TV', m7: 'Fogne', m8: 'Neon Ave',
    m9: 'Fiera Scienza', m10: 'Arena Robot', m11: 'Rifugio', m12: 'Serra', m13: 'Bar Bulloni',
    m14: 'Palazzo', m15: 'Vicoli Centro', m16: 'Acquario', m17: 'Clinica Mod', m18: 'Caveau',
    m19: 'Talent Show', m20: 'Quartiere', m21: 'Escape Room', m22: 'Tribunale', m23: 'Museo',
    m24: 'Museo notte', m25: 'Sala Giochi', m26: 'Tetti', m27: 'Palasport', m28: 'Discarica',
    m29: 'Luna Park', m30: 'Studio Social', m31: 'Ricevimenti', m32: 'Karaoke',
    // P3 "stadio ADULTO": 32 missioni m33-m64 + le 8 Grandi Imprese m65-m72 (v. rooms.js
    // MAPPA_PINS/LUOGHI_CFG per il fix "mappa adulto ingiocabile"). Nomi brevi dal campo Luogo
    // della scheda content, disambiguati dove due luoghi diversi condividono lo stesso testo
    // (es. m37/m61 sono entrambi "Città intera" in missioni.md: qui usano il titolo missione).
    m33: 'Palazzetto', m34: 'Lago Vaporoso', m35: 'Palestra Monte', m36: 'Via Mercato',
    m37: 'Maratona', m38: 'Stadio', m39: 'Skatepark', m40: 'Speedrun',
    m41: 'Gettone Nero', m42: 'Rovine Metro', m43: 'Base di Lancio', m44: 'Quartiere',
    m45: 'Università', m46: 'Concilio', m47: 'Studi TV', m48: 'Municipio',
    m49: 'Palco Festival', m50: 'Ristorante', m51: 'Villa Abbandonata', m52: 'Ferrovia',
    m53: 'Palazzo Condannato', m54: 'Attico', m55: 'Stazione Orbitante', m56: 'Ultimo Indirizzo',
    m57: 'Piazza Sagra', m58: 'Teatro Opera', m59: 'Pizzeria', m60: 'Osservatorio',
    m61: 'Caccia Tesoro', m62: 'Cantina', m63: 'Centrale', m64: 'Porto Vecchio',
    m65: 'Monte Mascellone', m66: 'Arena Porto', m67: 'Grattacielo', m68: 'Strada Tramonto',
    m69: 'Hotel Splendido', m70: 'Cratere', m71: 'Appartamento 4A', m72: 'Officina Tetto',
    // Estensione "26 missioni extra" m73-m98 (fix "mappa m73-98 ingiocabile"). Nomi brevi dal
    // campo Luogo della scheda content; disambiguati dove due luoghi diversi condividono lo
    // stesso testo in missioni.md (m73/m75 = "Parco Giochi"; m74/m90 = "Casa del Vicino"; m84
    // = "Via del Mercato" gia' usato da m36): qui usano il titolo/tema della missione, come
    // gia' fatto sopra per m37/m61.
    m73: 'Tiro alla Fune', m74: 'Trasloco Vicino', m75: 'Acchiapparella', m76: 'Condominio',
    m77: 'Museo dei Piccoli', m78: 'Balcone Orto', m79: 'Teatrino Cortile', m80: 'Banchetto Limonata',
    m81: 'Taverna Porto', m82: 'Festa Terrazza', m83: 'Palestra Quartiere', m84: 'Furgone Gelati',
    m85: 'Pista Go-Kart', m86: 'Villa Torta', m87: 'Mercato Rionale', m88: 'Cava Allagata',
    m89: 'Circolo Scacchi', m90: 'Ripetizioni', m91: 'Cabinato Rotto', m92: 'Bosco Fungo',
    m93: 'Palestra Scuola', m94: 'Mercatino Usato', m95: 'Teatro Parrocchiale', m96: 'Piazza Grande',
    m97: 'Erba Alta', m98: 'Piazzetta Intervista'
  };

  function aggiornaEtichetteMappa(sm) {
    var wrap = document.getElementById('petq-mappa-wrap');
    if (!wrap) return;
    var esistenti = wrap.querySelectorAll('.petq-mappa-etichetta');
    for (var r = 0; r < esistenti.length; r++) esistenti[r].remove();

    // Vista mappa CORRENTE (v. mappaVistaCitta/rettangoliMappaCorrente sopra): quartiere legge da
    // rettangoliQuartiere (l'ultimo drawMappaQuartiere, gli slot cambiano posto ogni giorno
    // secondo la rosa), città legge da _mappaPins (posizioni FISSE dell'atlante).
    var pins = rettangoliMappaCorrente();
    var attivi = (sm && sm.attivi) || [];
    // mh = altezza CORRENTE della vista mappa attiva (v. altezzaMappaCorrente sopra): le
    // etichette sono posizionate in PERCENTUALE sul wrap, che segue l'aspect-ratio del canvas —
    // con l'altezza sbagliata finirebbero spostate.
    var mw = PETQ.rooms._MAPPA_W, mh = altezzaMappaCorrente(sm);

    function piazzaEtichetta(rect, testo) {
      if (!rect || !testo) return;
      var chip = el('div', 'petq-mappa-etichetta', testo);
      var cx = rect.x + rect.w / 2;
      var yTop = Math.max(0, rect.y - 2); // appena sopra il luogo/pin, dentro il canvas
      chip.style.left = (cx / mw * 100) + '%';
      chip.style.top = (yTop / mh * 100) + '%';
      wrap.appendChild(chip);
    }

    for (var i = 0; i < attivi.length; i++) {
      var idAttivo = attivi[i];
      // guardia anti-regressione (v. avvisaPinMancanteUi sopra): un id in rosa senza pin non
      // ha etichetta (piazzaEtichetta gia' lo ignora via "!rect"), ma qui lo segnaliamo.
      if (!pins[idAttivo]) { avvisaPinMancanteUi(idAttivo); continue; }
      piazzaEtichetta(pins[idAttivo], traduci(NOME_BREVE_LUOGO[idAttivo]));
    }
    // Negozio unico (GDD "Economia" -> "Spesa e dispensa"): m0 è già incluso in 'attivi'
    // quando sbloccato (v. statoMappa), quindi prende l'etichetta "Negozio" dal loop sopra
    // come qualunque altro luogo — nessuna etichetta "Market" separata da piazzare.
  }

  // Bottone di chiusura (X) del foglio dettaglio mappa — FIX bug fondatore ("cliccando sul
  // negozio non si puo' tornare indietro e apre solo una lista enorme di cibo non chiudibile").
  // CAUSA ORIGINALE: da quando il foglio e' diventato un overlay ancorato in basso, fixed sopra
  // la mappa (v. commento su .petq-mappa-dettaglio in style.css), il vecchio modo di chiuderlo —
  // toccare la mappa FUORI dai pin, v. installaPointerMappa piu' sotto — e' diventato
  // irraggiungibile: il tocco cade sul foglio (che ora COPRE la mappa), non sulla mappa
  // sottostante. Serve quindi un bottone esplicito, sempre presente sul foglio stesso, non
  // legato al gesto ormai morto. La sequenza di chiusura IMITA esattamente quella gia' usata
  // quando si tocca la mappa a vuoto in installaPointerMappa (v. "if (negozioSelezionato) {
  // negozioSelezionato = false; aggiornaDettaglioMappa(...); }" e il ramo gemello che deseleziona
  // missioneSelezionata con ridisegnaMappa()): qui azzeriamo ENTRAMBI gli stati incondizionatamente
  // (non sappiamo a priori quale dei due era aperto — l'altro era gia' a riposo, azzerarlo e' un
  // no-op innocuo), poi ridisegniamo la mappa (stessi highlight/pin del tick normale) e infine il
  // dettaglio stesso, ora vuoto.
  function bottoneChiudiDettaglioMappa() {
    var btn = el('button', 'petq-btn petq-btn-mini petq-mappa-dettaglio-chiudi', '×');
    btn.setAttribute('aria-label', traduci('Chiudi'));
    btn.title = traduci('Chiudi');
    btn.addEventListener('click', function () {
      negozioSelezionato = false;
      missioneSelezionata = null;
      ridisegnaMappa();
      aggiornaDettaglioMappa(statoMappa());
    });
    return btn;
  }

  function aggiornaDettaglioMappa(sm) {
    var dettaglio = document.getElementById('petq-mappa-dettaglio');
    if (!dettaglio) return;
    dettaglio.innerHTML = '';

    // X di chiusura: presente in OGNI ramo che mostra qualcosa, tranne la missione IN CORSO
    // senza negozio aperto (ramo "sm.inCorso" subito sotto) — quel countdown non e' una
    // selezione dell'utente ma lo stato del gioco (rientro in corso), quindi non e' chiudibile
    // a piacere da qui. Il negozio invece resta chiudibile ANCHE a missione in corso (e' sempre
    // tappabile, v. commento su hitShopPin in installaPointerMappa): da cui la condizione
    // "niente X SOLO nel ramo puro missione-in-corso, cioe' negozio chiuso e sm.inCorso vero".
    // Aggiunta una volta sola qui (punto comune a tutti i rami) invece che ripetuta in ciascuno.
    if (negozioSelezionato || !sm.inCorso) {
      dettaglio.appendChild(bottoneChiudiDettaglioMappa());
    }

    // shop cibo: pannello acquisto, ha priorità su tutto il resto (sempre accessibile, non è
    // una missione — v. GDD "Economia" -> "Spesa e dispensa")
    if (negozioSelezionato) {
      dettaglio.appendChild(pannelloShop());
      dettaglio.style.display = '';
      return;
    }

    // missione in corso: il dettaglio è sempre la card col countdown, niente selezione (niente
    // X in questo ramo, v. condizione qui sopra: dipende solo da negozioSelezionato/sm.inCorso,
    // MAI da missioneSelezionata)
    if (sm.inCorso) {
      dettaglio.appendChild(cardMissioneInCorso());
      dettaglio.style.display = '';
      return;
    }

    if (!missioneSelezionata) {
      dettaglio.style.display = 'none';
      return;
    }

    if (sm.tutorial && missioneSelezionata === 'm0') {
      dettaglio.appendChild(cardTutorial(sm.tutorial));
      dettaglio.style.display = '';
      return;
    }

    var scheda = null;
    for (var i = 0; i < sm.rosa.length; i++) {
      if (sm.rosa[i].id === missioneSelezionata) { scheda = sm.rosa[i]; break; }
    }
    if (!scheda) {
      missioneSelezionata = null;
      dettaglio.style.display = 'none';
      return;
    }
    dettaglio.appendChild(cardMissione(scheda));
    dettaglio.style.display = '';
  }

  // Prezzo di un cibo al Negozio: SEMPRE da qui. Lo sconto del Frigo nuovo (-10%, arrotondato per
  // difetto, minimo 1) lo calcola PETQ.arredi.prezzoCiboScontato (fase 2), che e l'unico posto
  // dove vive quella regola: qui si legge e basta. Usata per il prezzo mostrato, per quello
  // scalato e per il tetto del furto — se divergessero, il giocatore vedrebbe 19 monete e si
  // sentirebbe dire "troppo caro" su un tetto da 20.
  function prezzoCibo(cibo) {
    var base = (cibo && cibo.costo) || 0;
    if (!PETQ.arredi || !PETQ.arredi.prezzoCiboScontato) return base;
    return PETQ.arredi.prezzoCiboScontato(currentState, base);
  }

  // vero se in casa c'e qualcosa che sconta il cibo (oggi: il Frigo nuovo)
  function scontoCiboAttivo() {
    if (!PETQ.arredi || !PETQ.arredi.prezzoCiboScontato) return false;
    return PETQ.arredi.prezzoCiboScontato(currentState, 100) < 100;
  }

  // ---------- shop cibo (Negozio unico, pin m0 sulla mappa: GDD "Economia" -> "Spesa e dispensa") ----------
  // Menu ACQUISTO (non una missione): lista dei cibi da content/cibi.md con prezzo; "Compra"
  // acquista 1 porzione, ripetibile, scala le monete e incrementa la qty in dispensa (frigo).
  // Stesso edificio del tutorial m0: prima del tutorial il tap apre cardTutorial, dopo apre
  // questo pannello (v. statoMappa/aggiornaDettaglioMappa/installaPointerMappa).
  // PROTOTIPO 2, Blocco 7 — il negozio ha 3 sezioni interne (Cibo/Arredi/Vendi) selezionabili
  // in cima. Riusa .petq-tab della casa per le sotto-schede. La sezione attiva vive in
  // shopSezione (persiste finche' il negozio resta aperto; ripartito su 'cibo' all'apertura del
  // pin, v. installaPointerMappa). Il corpo cambia in base alla sezione, l'intestazione resta.
  function pannelloShop() {
    var wrap = el('div', 'petq-missione-card petq-shop-card');
    wrap.appendChild(el('div', 'petq-missione-titolo', traduci('Negozio')));

    // barra sotto-schede (playtest 8 lug 2026, "negozio scarno": aggiunte Giocattoli e
    // Guardaroba — vestiti+armi comprabili come pozzo-monete late game; rifinitura in P3)
    var tabs = el('div', 'petq-tabs petq-shop-tabs');
    var SEZIONI = [['cibo', 'Cibo'], ['arredi', 'Arredi'], ['giocattoli', 'Giochi'], ['guardaroba', 'Guardaroba'], ['vendi', 'Vendi'], ['sostieni', 'Sostieni']];
    for (var s = 0; s < SEZIONI.length; s++) {
      (function (chiave, label) {
        var t = el('button', 'petq-tab' + (shopSezione === chiave ? ' petq-tab-attiva' : ''), traduci(label));
        t.addEventListener('click', function () {
          if (shopSezione === chiave) return;
          shopSezione = chiave;
          vendiConferma = null; // cambiando sezione si annulla ogni conferma vendita pendente
          aggiornaDettaglioMappa(statoMappa());
        });
        tabs.appendChild(t);
      })(SEZIONI[s][0], SEZIONI[s][1]);
    }
    wrap.appendChild(tabs);

    if (shopSezione === 'arredi') renderShopArredi(wrap);
    else if (shopSezione === 'giocattoli') renderShopGiocattoli(wrap);
    else if (shopSezione === 'guardaroba') renderShopGuardaroba(wrap);
    else if (shopSezione === 'vendi') renderShopVendi(wrap);
    else if (shopSezione === 'sostieni') renderShopSostieni(wrap);
    else renderShopCibo(wrap);

    return wrap;
  }

  // Sezione CIBO: acquisto cibo (invariato dal P1), incluso il "Ruba" del talento furto.
  function renderShopCibo(wrap) {
    wrap.appendChild(el('div', 'petq-missione-meta', traduci('Compra cibo: finisce nel frigo in cucina, gratis da lì in poi.')));

    // Frigo nuovo (arredo con effettoSpeciale 'sconto_cibo', fase 2): -10% su tutto il cibo. Lo
    // sconto vale sul prezzo MOSTRATO, su quello SCALATO e sul tetto del furto — passano tutti da
    // prezzoCibo(). Il cartello lo dice, altrimenti il giocatore non sa perche' i numeri sono
    // cambiati (ed era l'unico modo di accorgersi che quell'arredo da 80 monete serve a qualcosa).
    if (scontoCiboAttivo()) {
      wrap.appendChild(el('div', 'petq-missione-meta', traduci('🧊 Frigo nuovo: prezzi del cibo già scontati.')));
    }

    var data = window.PETQ.content && window.PETQ.content.data;
    var cibi = (data && data.cibi) || [];
    if (cibi.length === 0) {
      wrap.appendChild(el('p', 'petq-vuoto', traduci('Nessun cibo disponibile.')));
      return;
    }

    // Talenti (PROTOTIPO 2, Blocco 9, Gruppo D, "furto=1/giorno", Cleptomane/Boss di Quartiere):
    // il pet puo' prendere GRATIS 1 oggetto al giorno dal Negozio. Il bottone "Ruba (gratis)"
    // compare su ogni cibo IDONEO (prezzo <= tetto, o qualsiasi se tetto null) SOLO se il talento
    // e' attivo E non e' gia' stato usato oggi (state.furtoDay !== oggi). Dopo un furto, le opzioni
    // "Ruba" spariscono per il resto della giornata (v. eseguiFurto + il ricalcolo qui sopra).
    var furto = (PETQ.talenti && PETQ.talenti.furtoDisponibile) ? PETQ.talenti.furtoDisponibile(currentState) : { attivo: false };
    var furtoUsatoOggi = currentState.furtoDay === PETQ.clock.giornoCorrente(currentState);
    var furtoAttivoOra = furto.attivo && !furtoUsatoOggi;
    if (furto.attivo) {
      var tettoTxt = (furto.tetto === null) ? traduci('qualsiasi oggetto') : traduci('oggetti fino a ') + furto.tetto + traduci(' monete');
      var hintFurto = furtoUsatoOggi
        ? traduci('Furto del giorno già usato: torna domani.')
        : traduci('Talento ladro: puoi rubare gratis 1 oggetto al giorno (') + tettoTxt + ').';
      wrap.appendChild(el('div', 'petq-missione-meta', hintFurto));
    }

    var lista = el('div', 'petq-shop-lista');
    for (var i = 0; i < cibi.length; i++) {
      // cibi con costo 0 non sono in vendita (es. "Snack riciclato", esce solo dal Pool
      // Inventore): non vanno mostrati al Negozio (ne' comprabili ne' rubabili).
      if ((cibi[i].costo || 0) <= 0) continue;
      (function (cibo) {
        var riga = el('div', 'petq-shop-riga');

        var icona = document.createElement('canvas');
        icona.width = 12; icona.height = 12;
        icona.className = 'petq-food-icon';
        disegnaCibo(icona, cibo);
        riga.appendChild(icona);

        var info = el('div', 'petq-shop-info');
        var nomeCiboEl = el('div', 'petq-cibo-nome', traduci(cibo.nome));
        // MULTI-PORZIONE (decisione fondatore 27 lug 2026): accanto al nome, SOLO se il cibo
        // consegna piu' di 1 porzione per acquisto, il moltiplicatore discreto "×N" — stessa
        // classe petq-food-tag gia' usata per la qty "xN" nelle card della dispensa (v.
        // renderAzioniCucina sopra), nessuno stile nuovo. Wrappato in traduci() per uniformita'
        // col resto della riga, ma non serve una voce EN in i18n.js: "×3" e' un simbolo+cifra,
        // non una parola, quindi t() lo ritorna identico in entrambe le lingue.
        if ((cibo.porzioni || 1) > 1) {
          nomeCiboEl.appendChild(el('span', 'petq-food-tag', traduci(' ×' + cibo.porzioni)));
        }
        info.appendChild(nomeCiboEl);
        var prezzoV = prezzoCibo(cibo);
        var effettiRiga = el('div', 'petq-cibo-effetti');
        effettiRiga.appendChild(descriviCiboNodi(cibo));
        effettiRiga.appendChild(document.createTextNode(' — ' + prezzoV + traduci(' monete')));
        info.appendChild(effettiRiga);
        riga.appendChild(info);

        var btn = el('button', 'petq-btn petq-btn-mini', traduci('Compra'));
        if ((currentState.coins || 0) < prezzoV) {
          btn.disabled = true;
          btn.title = traduci('Monete insufficienti.');
        }
        btn.addEventListener('click', function () { eseguiAcquisto(cibo, riga); });
        riga.appendChild(btn);

        // "Ruba (gratis)": solo se il furto e' attivo oggi e questo cibo rientra nel tetto.
        // Il confronto usa il prezzo SCONTATO, cioe' quello scritto due righe sopra: e' il numero
        // che il giocatore ha davanti agli occhi.
        var idoneoFurto = furtoAttivoOra && (furto.tetto === null || prezzoV <= furto.tetto);
        if (idoneoFurto) {
          var btnRuba = el('button', 'petq-btn petq-btn-mini petq-btn-ruba', traduci('Ruba (gratis)'));
          btnRuba.addEventListener('click', function () { eseguiFurto(cibo, riga); });
          riga.appendChild(btnRuba);
        }

        lista.appendChild(riga);
      })(cibi[i]);
    }
    wrap.appendChild(lista);
  }

  // Sezione ARREDI: compra i decorativi con prezzoNegozio, raggruppati per stanza di
  // destinazione. Spostata qui dalla vecchia tab casa "Negozio" (renderTabNegozio, rimossa):
  // stesso comportamento (gia'-in-collezione disabilitato, monete insufficienti disabilitato).
  // L'arredo comprato va nei POSSEDUTI; il giocatore lo piazza poi dalla Collezione (Salone).
  function renderShopArredi(wrap) {
    wrap.appendChild(el('div', 'petq-missione-meta',
      traduci('Compra arredi: finiscono nella Collezione (Salone), poi li piazzi nelle stanze. ') + traduci('Monete: ') + (currentState.coins || 0) + '.'));

    // Upgrade "Ingrandimento casa" IN CIMA (GDD "Slot arredo, tetto passivo e Ingrandimento
    // casa"): 1 acquisto globale (200 monete) che sblocca il 4o slot in ogni stanza e ingrandisce
    // le stanze in altezza. Gia' comprato -> "Acquistato". Monete insufficienti -> disabilitato.
    renderRigaIngrandimento(wrap);

    var data = window.PETQ.content && window.PETQ.content.data;
    var arredi = (data && data.arredi) || [];

    var STANZE_ORD = ['cucina', 'bagno', 'salone', 'camera'];
    var gruppi = { cucina: [], bagno: [], salone: [], camera: [] };
    for (var i = 0; i < arredi.length; i++) {
      var a = arredi[i];
      if (typeof a.prezzoNegozio !== 'number') continue;
      if (/giocattolo/i.test(a.nome || '')) continue; // i giocattoli hanno la loro tab (Giochi)
      var stanza = (STANZE_ORD.indexOf(a.stanza) !== -1) ? a.stanza : 'salone';
      gruppi[stanza].push(a);
    }

    var totale = 0;
    for (var g = 0; g < STANZE_ORD.length; g++) {
      var st = STANZE_ORD[g];
      var lista = gruppi[st];
      if (lista.length === 0) continue;
      totale += lista.length;
      wrap.appendChild(el('div', 'petq-shop-gruppo-titolo', traduci(capitalize(st))));
      var box = el('div', 'petq-shop-lista');
      for (var k = 0; k < lista.length; k++) {
        box.appendChild(rigaNegozioArredo(lista[k], st));
      }
      wrap.appendChild(box);
    }

    if (totale === 0) {
      wrap.appendChild(el('p', 'petq-vuoto', traduci('Nessun arredo in vendita al momento.')));
    }

    // Stanze (skin cosmetiche della stanza, batch cosmetici — tabella dati SKIN_STANZE in cima al
    // file): blocco in FONDO alla sezione Arredamento (SEMPRE, indipendente dal catalogo
    // arredi.md sopra: totale===0 non lo riguarda), stessa identica forma delle righe Colore nel
    // negozio (v. rigaSkinStanzaNegozio sotto — anteprima + nome + prezzo + bottone), ma con la
    // STANZA vera in miniatura al posto dello swatch. Le quattro 'negozio' si comprano da qui; le
    // tre 'supporter' sono mostrate ma NON acquistabili (stesso pattern dei colori Supporter).
    wrap.appendChild(el('div', 'petq-shop-gruppo-titolo', traduci('Stanze')));
    // Nota d'uso (fondatore, 24 ago: "va specificato che appariranno in profilo"): i cosmetici
    // comprati si ATTIVANO dal Profilo, il negozio li vende soltanto.
    wrap.appendChild(el('div', 'petq-hint', traduci('Una volta sbloccati, si attivano dal Profilo.')));
    var boxStanze = el('div', 'petq-shop-lista');
    for (var isk = 0; isk < SKIN_STANZE.length; isk++) {
      if (SKIN_STANZE[isk].tipo === 'razza') continue; // sempre disponibili, non in vendita
      boxStanze.appendChild(rigaSkinStanzaNegozio(SKIN_STANZE[isk]));
    }
    wrap.appendChild(boxStanze);

    // Cornici (cornici cosmetiche della cartolina esito, tabella dati CORNICI_CARTOLINA in cima
    // al file): STESSO identico blocco di Stanze appena sopra, in fondo alla sezione Arredamento.
    // Le tre 'negozio' si comprano da qui; le due 'supporter' sono mostrate ma NON acquistabili
    // (rigaCorniceNegozio gestisce da sola il terzo stato, stesso pattern di colori/stanze).
    wrap.appendChild(el('div', 'petq-shop-gruppo-titolo', traduci('Cornici')));
    var boxCornici = el('div', 'petq-shop-lista');
    for (var icz = 0; icz < CORNICI_CARTOLINA.length; icz++) {
      boxCornici.appendChild(rigaCorniceNegozio(CORNICI_CARTOLINA[icz]));
    }
    wrap.appendChild(boxCornici);
  }

  // Sezione GIOCHI: i giocattoli del menu "Usa un giocattolo" del salone. La lista NON e' piu' una
  // regex sul nome degli arredi (prendeva solo i 4 che si chiamano "... Giocattolo"): la fonte e
  // content/arredi.md sezione GIOCATTOLI -> content.data.giocattoli. Prezzo valorizzato = in
  // vendita; "—" = solo drop da missione e qui non compare.
  function renderShopGiocattoli(wrap) {
    wrap.appendChild(el('div', 'petq-missione-meta',
      traduci('Giocattoli per ') + (currentState.pet.nome || traduci('il pet')) +
      traduci(': si usano dal Salone, con "Usa un giocattolo". ') + traduci('Monete: ') + (currentState.coins || 0) + '.'));
    var data = window.PETQ.content && window.PETQ.content.data;
    var giocattoli = (data && data.giocattoli) || [];
    var box = el('div', 'petq-shop-lista');
    var n = 0;
    for (var i = 0; i < giocattoli.length; i++) {
      var g = giocattoli[i];
      if (typeof g.prezzo !== 'number') continue;
      box.appendChild(rigaNegozioGiocattolo(g));
      n++;
    }
    wrap.appendChild(box);
    if (n === 0) wrap.appendChild(el('p', 'petq-vuoto', traduci('Nessun giocattolo in vendita.')));
  }

  function rigaNegozioGiocattolo(g) {
    var riga = el('div', 'petq-shop-riga');
    riga.appendChild(iconaOggetto(g.nome, 'giocattolo'));

    var testi = el('div', 'petq-shop-info');
    testi.appendChild(el('div', 'petq-cibo-nome', traduci(g.nome)));
    // La descrizione la scrive il motore (PETQ.giocattoli.descrizione): e la STESSA frase che il
    // giocatore leggera nel menu del salone, non una seconda versione scritta qui.
    var desc = (PETQ.giocattoli && PETQ.giocattoli.descrizione) ? PETQ.giocattoli.descrizione(g) : '';
    testi.appendChild(el('div', 'petq-cibo-effetti',
      desc + traduci(' — stanza: ') + traduci(capitalize(g.stanza || 'salone')) + ' — ' + g.prezzo + traduci(' monete')));
    riga.appendChild(testi);

    if (PETQ.giocattoli && PETQ.giocattoli.possiede && PETQ.giocattoli.possiede(currentState, g.nome)) {
      var giaBtn = el('button', 'petq-btn petq-btn-mini', traduci('Posseduto ✓'));
      giaBtn.disabled = true;
      giaBtn.title = traduci('Giocattolo unico: lo possiedi già.');
      riga.appendChild(giaBtn);
      return riga;
    }

    var btn = el('button', 'petq-btn petq-btn-mini', traduci('Compra'));
    if ((currentState.coins || 0) < g.prezzo) {
      btn.disabled = true;
      btn.title = traduci('Monete insufficienti.');
    } else {
      btn.addEventListener('click', function () { eseguiAcquistoGiocattolo(g, riga); });
    }
    riga.appendChild(btn);
    return riga;
  }

  // Compra un giocattolo. I 4 che sono ANCHE arredi (Palla/Robottino/Trenino/Astronave) entrano
  // come ARREDI: cosi' restano piazzabili in casa e conservano il loro bonus passivo da arredo —
  // PETQ.giocattoli.possiede() li riconosce lo stesso, per decisione della fase 2. Gli altri
  // finiscono in state.giocattoli via PETQ.giocattoli.aggiungi.
  function eseguiAcquistoGiocattolo(g, rigaEl) {
    if (!currentState) return;
    if (PETQ.giocattoli && PETQ.giocattoli.possiede && PETQ.giocattoli.possiede(currentState, g.nome)) {
      shakeCard(rigaEl);
      mostraToast(traduci('Ce l\'hai già.'));
      aggiornaDettaglioMappa(statoMappa());
      return;
    }
    if ((currentState.coins || 0) < g.prezzo) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto');
      shakeCard(rigaEl);
      mostraToast(traduci('Monete insufficienti.'));
      return;
    }
    // consegna PRIMA, monete DOPO (stesso ordine di eseguiAcquistoArredo): se la consegna
    // fallisce il giocatore non deve restare senza monete e senza giocattolo.
    var esitoAgg = null;
    if (trovaArredoContentUI(g.nome) && PETQ.arredi && PETQ.arredi.aggiungi) {
      esitoAgg = PETQ.arredi.aggiungi(currentState, g.nome);
    } else if (PETQ.giocattoli && PETQ.giocattoli.aggiungi) {
      esitoAgg = PETQ.giocattoli.aggiungi(currentState, g.nome);
    }
    if (!esitoAgg || !esitoAgg.ok) {
      shakeCard(rigaEl);
      mostraToast((esitoAgg && esitoAgg.msg) || traduci('Acquisto non riuscito.'));
      return;
    }
    currentState.coins -= g.prezzo;
    if (PETQ.audio) PETQ.audio.suona('acquisto');
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    aggiornaDettaglioMappa(statoMappa());
    mostraToast(traduci(g.nome) + traduci(' comprato: usalo dal Salone, "Usa un giocattolo".'));
  }

  // Sezione GUARDAROBA (playtest 8 lug 2026, pozzo-monete late game): vestiti indossabili e armi
  // comprabili. I prezzi NON vivono piu' qui: erano due mappe hardcodate (PREZZI_VESTITI 7 voci,
  // PREZZI_ARMI 10) che il contenuto ha superato. La fonte ora e content/arredi.md ->
  // content.data.indossabili / content.data.armi, colonna Prezzo (numero = in vendita, "—" = solo
  // drop da missione). I vestiti finiscono in state.indossabili (Armadio della scheda); le armi
  // tra gli arredi posseduti (Armeria, equip gated dal perk Weapon Wielder).
  //
  // ATTENZIONE (cambio di CONTENUTO, non di codice): in arredi.md l'unica voce della sezione Armi
  // e la Pistola Spara-Spazzatura, e ha Prezzo "—". Le 9 armi di M7/M20 stanno nelle tabelle
  // arredi e nemmeno loro hanno un "negozio N". Risultato: il gruppo Armi del negozio e VUOTO
  // finche' il regista non mette un prezzo in arredi.md — il codice qui sotto non ha nessun elenco
  // suo da esibire, ed e' giusto cosi'.
  function rigaGuardaroba(nome, categoria, prezzo, posseduto, onCompra) {
    var riga = el('div', 'petq-shop-riga');
    // Anteprima VERA (GDD "Negozio visivo" 24 ago 2026): i VESTITI (categoria 'indossabile', gli
    // "indossabili meme" del fondatore) mostrano il pet del giocatore (o il ripiego) CON il capo
    // indosso — STESSO meccanismo di rigaCompletoNegozio sopra (creaAnteprimaIndossato). Le ARMI
    // (categoria 'arma') restano com'erano, iconaOggetto: non sono nello scopo di questo batch.
    if (categoria === 'indossabile') {
      var prevG = creaAnteprimaIndossato(petPerNegozio(), nome);
      prevG.className = 'petq-shop-anteprima';
      riga.appendChild(prevG);
    } else {
      riga.appendChild(iconaOggetto(nome, categoria));
    }
    var info = el('div', 'petq-shop-info');
    info.appendChild(el('div', 'petq-cibo-nome', traduci(nome)));
    var effettiRiga = el('div', 'petq-cibo-effetti');
    effettiRiga.appendChild(nodiEffettiEquip(nome, categoria));
    effettiRiga.appendChild(document.createTextNode(' — ' + prezzo + traduci(' monete')));
    info.appendChild(effettiRiga);
    riga.appendChild(info);
    if (posseduto) {
      var gia = el('button', 'petq-btn petq-btn-mini', traduci('Posseduto ✓'));
      gia.disabled = true;
      riga.appendChild(gia);
    } else {
      var btn = el('button', 'petq-btn petq-btn-mini', traduci('Compra'));
      if ((currentState.coins || 0) < prezzo) { btn.disabled = true; btn.title = traduci('Monete insufficienti.'); }
      else btn.addEventListener('click', onCompra);
      riga.appendChild(btn);
    }
    return riga;
  }

  // Riga negozio per un colore (tabella dati COLORI_PET in cima al file): STESSA forma delle
  // righe guardaroba sopra (anteprima + nome + prezzo + bottone), ma con lo swatch VERO al posto
  // dell'icona categoria (creaAnteprimaColore -> PETQ.sprites.draw, mai palette duplicate a
  // mano), e un terzo stato che vestiti/armi non hanno: 'Supporter Pack' (non acquistabile a
  // monete, si accende SOLO da state.supporter — per ora solo pannello debug).
  function rigaColoreNegozio(voce) {
    var riga = el('div', 'petq-shop-riga');
    // petPerNegozio(): il pet vero, o il ripiego se la casa e' vuota (v. sopra) — mai un canvas
    // spento come prima quando mancava la partita.
    var prev = creaAnteprimaColore(petPerNegozio(), voce.indice);
    prev.className = 'petq-food-icon'; // stesso stile pixelato 36x36 delle altre icone negozio
    riga.appendChild(prev);

    var info = el('div', 'petq-shop-info');
    info.appendChild(el('div', 'petq-cibo-nome', traduci(voce.nome)));

    if (voce.tipo === 'supporter') {
      // "Supporter Pack" UNA volta sola: scritto sia nella colonna del prezzo sia sul bottone
      // usciva doppio a schermo ("Oro Supporter Pack Supporter Pack"). Resta nella riga
      // descrittiva, dove sta l'informazione.
      info.appendChild(el('div', 'petq-cibo-effetti', traduci('Supporter Pack')));
      riga.appendChild(info);
      // GDD "Monetizzazione": niente più "Non in vendita" — CTA attiva verso la sezione
      // Sostieni (soldi veri), a meno che il colore non sia GIÀ disponibile (pack o acquisto
      // singolo IAP: v. coloreDisponibile, che ora controlla anche coloriSbloccati), nel qual
      // caso è "Posseduto ✓" disabilitato come le righe a monete qui sotto.
      if (coloreDisponibile(currentState, voce.indice)) {
        var giaSup = el('button', 'petq-btn petq-btn-mini', traduci('Posseduto ✓'));
        giaSup.disabled = true;
        riga.appendChild(giaSup);
      } else {
        var btnSup = el('button', 'petq-btn petq-btn-mini', traduci('Nella sezione Sostieni'));
        btnSup.addEventListener('click', function () {
          shopSezione = 'sostieni';
          vendiConferma = null;
          aggiornaDettaglioMappa(statoMappa());
        });
        riga.appendChild(btnSup);
      }
      return riga;
    }

    info.appendChild(el('div', 'petq-cibo-effetti', voce.prezzo + traduci(' monete')));
    riga.appendChild(info);

    if (coloreDisponibile(currentState, voce.indice)) {
      var gia = el('button', 'petq-btn petq-btn-mini', traduci('Già sbloccato'));
      gia.disabled = true;
      riga.appendChild(gia);
    } else {
      var btn = el('button', 'petq-btn petq-btn-mini', traduci('Compra'));
      // STESSO comportamento delle righe guardaroba sopra: monete insufficienti -> bottone
      // disabilitato + titolo 'Monete insufficienti.' (nessun toast, il tap non parte nemmeno).
      if ((currentState.coins || 0) < voce.prezzo) {
        btn.disabled = true;
        btn.title = traduci('Monete insufficienti.');
      } else {
        btn.addEventListener('click', function () {
          if ((currentState.coins || 0) < voce.prezzo) return; // ridondante col disabled, difensivo
          currentState.coins -= voce.prezzo;
          if (!Array.isArray(currentState.coloriSbloccati)) currentState.coloriSbloccati = [];
          if (currentState.coloriSbloccati.indexOf(voce.indice) === -1) currentState.coloriSbloccati.push(voce.indice);
          PETQ.save.save(currentState);
          if (PETQ.audio) PETQ.audio.suona('acquisto');
          aggiornaHud(currentState);
          mostraToast(traduci(voce.nome) + traduci(' sbloccato: cambialo dalla scheda, sezione Colore.'));
          aggiornaDettaglioMappa(statoMappa());
        });
      }
      riga.appendChild(btn);
    }
    return riga;
  }

  // Riga negozio per una skin stanza (tabella dati SKIN_STANZE in cima al file): STESSA identica
  // forma di rigaColoreNegozio sopra (anteprima + nome + prezzo + bottone, stesso terzo stato
  // 'Supporter Pack' non acquistabile), ma l'anteprima e' la STANZA vera in miniatura
  // (creaAnteprimaStanza) invece dello swatch colore — non e' quadrata (112x96), quindi niente
  // classe petq-food-icon (schiaccerebbe l'aspect ratio): stile dedicato pixelato.
  function rigaSkinStanzaNegozio(voce) {
    var riga = el('div', 'petq-shop-riga');
    var prev = creaAnteprimaStanza(voce.id);
    prev.style.width = '56px';
    prev.style.aspectRatio = prev.width + ' / ' + prev.height;
    prev.style.imageRendering = 'pixelated';
    prev.style.flexShrink = '0';
    riga.appendChild(prev);

    var info = el('div', 'petq-shop-info');
    info.appendChild(el('div', 'petq-cibo-nome', traduci(voce.nome)));

    if (voce.tipo === 'supporter') {
      info.appendChild(el('div', 'petq-cibo-effetti', traduci('Supporter Pack')));
      riga.appendChild(info);
      // GDD "Monetizzazione": niente più "Non in vendita" — CTA attiva verso la sezione
      // Sostieni (soldi veri), a meno che la skin non sia GIÀ disponibile (pack o acquisto
      // singolo IAP: v. skinDisponibile, che ora controlla anche skinSbloccate), nel qual caso è
      // "Posseduto ✓" disabilitato come le righe a monete qui sotto.
      if (skinDisponibile(currentState, voce.id)) {
        var giaSup = el('button', 'petq-btn petq-btn-mini', traduci('Posseduto ✓'));
        giaSup.disabled = true;
        riga.appendChild(giaSup);
      } else {
        var btnSup = el('button', 'petq-btn petq-btn-mini', traduci('Nella sezione Sostieni'));
        btnSup.addEventListener('click', function () {
          shopSezione = 'sostieni';
          vendiConferma = null;
          aggiornaDettaglioMappa(statoMappa());
        });
        riga.appendChild(btnSup);
      }
      return riga;
    }

    info.appendChild(el('div', 'petq-cibo-effetti', voce.prezzo + traduci(' monete')));
    riga.appendChild(info);

    if (skinDisponibile(currentState, voce.id)) {
      var gia = el('button', 'petq-btn petq-btn-mini', traduci('Già sbloccato'));
      gia.disabled = true;
      riga.appendChild(gia);
    } else {
      var btn = el('button', 'petq-btn petq-btn-mini', traduci('Compra'));
      // STESSO comportamento delle righe colore/guardaroba: monete insufficienti -> bottone
      // disabilitato + titolo (nessun toast, il tap non parte nemmeno).
      if ((currentState.coins || 0) < voce.prezzo) {
        btn.disabled = true;
        btn.title = traduci('Monete insufficienti.');
      } else {
        btn.addEventListener('click', function () {
          if ((currentState.coins || 0) < voce.prezzo) return; // ridondante col disabled, difensivo
          currentState.coins -= voce.prezzo;
          if (!Array.isArray(currentState.skinSbloccate)) currentState.skinSbloccate = [];
          if (currentState.skinSbloccate.indexOf(voce.id) === -1) currentState.skinSbloccate.push(voce.id);
          PETQ.save.save(currentState);
          if (PETQ.audio) PETQ.audio.suona('acquisto');
          aggiornaHud(currentState);
          mostraToast(traduci(voce.nome) + traduci(' sbloccata: cambiala dalla scheda, sezione Stanze.'));
          aggiornaDettaglioMappa(statoMappa());
        });
      }
      riga.appendChild(btn);
    }
    return riga;
  }

  // Riga negozio per una cornice cartolina (tabella dati CORNICI_CARTOLINA in cima al file):
  // STESSA identica forma di rigaSkinStanzaNegozio sopra (anteprima + nome + prezzo + bottone,
  // stesso terzo stato 'Supporter Pack' non acquistabile), ma l'anteprima e' la CARTOLINA vera in
  // miniatura (creaAnteprimaCornice, scena fissa 'std_sociale' col pet corrente) invece della
  // stanza — stessa dimensione 112x64 della cartolina vera, stesso stile pixelato dedicato.
  function rigaCorniceNegozio(voce) {
    var riga = el('div', 'petq-shop-riga');
    // statoAnteprimaNegozio(): currentState se c'e' una partita, altrimenti un involucro col pet
    // di ripiego (v. sopra) — mai una cartolina vuota quando manca la partita.
    var prev = creaAnteprimaCornice(statoAnteprimaNegozio(), voce.id);
    prev.style.width = '56px';
    prev.style.aspectRatio = prev.width + ' / ' + prev.height;
    prev.style.imageRendering = 'pixelated';
    prev.style.flexShrink = '0';
    riga.appendChild(prev);

    var info = el('div', 'petq-shop-info');
    info.appendChild(el('div', 'petq-cibo-nome', traduci(voce.nome)));

    if (voce.tipo === 'supporter') {
      info.appendChild(el('div', 'petq-cibo-effetti', traduci('Supporter Pack')));
      riga.appendChild(info);
      // GDD "Monetizzazione": niente più "Non in vendita" — CTA attiva verso la sezione
      // Sostieni (soldi veri), a meno che la cornice non sia GIÀ disponibile (pack o acquisto
      // singolo IAP pack_cornici: v. corniceDisponibile, che ora controlla anche
      // corniciSbloccate), nel qual caso è "Posseduto ✓" disabilitato come le righe a monete qui
      // sotto.
      if (corniceDisponibile(currentState, voce.id)) {
        var giaSup = el('button', 'petq-btn petq-btn-mini', traduci('Posseduto ✓'));
        giaSup.disabled = true;
        riga.appendChild(giaSup);
      } else {
        var btnSup = el('button', 'petq-btn petq-btn-mini', traduci('Nella sezione Sostieni'));
        btnSup.addEventListener('click', function () {
          shopSezione = 'sostieni';
          vendiConferma = null;
          aggiornaDettaglioMappa(statoMappa());
        });
        riga.appendChild(btnSup);
      }
      return riga;
    }

    info.appendChild(el('div', 'petq-cibo-effetti', voce.prezzo + traduci(' monete')));
    riga.appendChild(info);

    if (corniceDisponibile(currentState, voce.id)) {
      var gia = el('button', 'petq-btn petq-btn-mini', traduci('Già sbloccato'));
      gia.disabled = true;
      riga.appendChild(gia);
    } else {
      var btn = el('button', 'petq-btn petq-btn-mini', traduci('Compra'));
      // STESSO comportamento delle righe colore/stanza/guardaroba: monete insufficienti -> bottone
      // disabilitato + titolo (nessun toast, il tap non parte nemmeno).
      if ((currentState.coins || 0) < voce.prezzo) {
        btn.disabled = true;
        btn.title = traduci('Monete insufficienti.');
      } else {
        btn.addEventListener('click', function () {
          if ((currentState.coins || 0) < voce.prezzo) return; // ridondante col disabled, difensivo
          currentState.coins -= voce.prezzo;
          if (!Array.isArray(currentState.corniciSbloccate)) currentState.corniciSbloccate = [];
          if (currentState.corniciSbloccate.indexOf(voce.id) === -1) currentState.corniciSbloccate.push(voce.id);
          PETQ.save.save(currentState);
          if (PETQ.audio) PETQ.audio.suona('acquisto');
          aggiornaHud(currentState);
          mostraToast(traduci(voce.nome) + traduci(' sbloccata: cambiala dalla scheda, sezione Cornice.'));
          aggiornaDettaglioMappa(statoMappa());
        });
      }
      riga.appendChild(btn);
    }
    return riga;
  }

  // Riga negozio per un completo (tabella dati COMPLETI_VESTITO in cima al file): STESSA identica
  // forma di rigaColoreNegozio sopra (nome + prezzo + bottone, stesso terzo stato 'Supporter Pack'
  // non acquistabile) — ma l'anteprima e' iconaOggetto (LO STESSO ritaglio dello sprite equip gia'
  // usato da rigaGuardaroba per vestiti/armi, v. disegnaSpriteEquipRitagliato), non lo swatch/
  // stanza/cartolina delle altre tre famiglie: un completo e' un vestito come gli altri, non ha una
  // scena propria da mostrare in miniatura.
  function rigaCompletoNegozio(voce) {
    var riga = el('div', 'petq-shop-riga');
    // Anteprima VERA (GDD "Negozio visivo" 24 ago 2026): il pet del giocatore (o il ripiego)
    // CON il completo indosso, non piu' l'icona generica iconaOggetto — STESSO meccanismo
    // PETQ.sprites.draw/petLike.indossato della sezione Vestiti sotto (v. creaAnteprimaIndossato).
    var prevCompleto = creaAnteprimaIndossato(petPerNegozio(), voce.nome);
    prevCompleto.className = 'petq-shop-anteprima';
    riga.appendChild(prevCompleto);

    var info = el('div', 'petq-shop-info');
    info.appendChild(el('div', 'petq-cibo-nome', traduci(voce.nome)));

    if (voce.tipo === 'supporter') {
      info.appendChild(el('div', 'petq-cibo-effetti', traduci('Supporter Pack')));
      riga.appendChild(info);
      var btnSup = el('button', 'petq-btn petq-btn-mini', traduci('Non in vendita'));
      btnSup.disabled = true;
      riga.appendChild(btnSup);
      return riga;
    }

    info.appendChild(el('div', 'petq-cibo-effetti', voce.prezzo + traduci(' monete')));
    riga.appendChild(info);

    if (completoDisponibile(currentState, voce.nome)) {
      var gia = el('button', 'petq-btn petq-btn-mini', traduci('Già sbloccato'));
      gia.disabled = true;
      riga.appendChild(gia);
    } else {
      var btn = el('button', 'petq-btn petq-btn-mini', traduci('Compra'));
      // STESSO comportamento delle righe colore/stanza/cornice/guardaroba: monete insufficienti ->
      // bottone disabilitato + titolo (nessun toast, il tap non parte nemmeno).
      if ((currentState.coins || 0) < voce.prezzo) {
        btn.disabled = true;
        btn.title = traduci('Monete insufficienti.');
      } else {
        btn.addEventListener('click', function () {
          if ((currentState.coins || 0) < voce.prezzo) return; // ridondante col disabled, difensivo
          currentState.coins -= voce.prezzo;
          if (!Array.isArray(currentState.completiSbloccati)) currentState.completiSbloccati = [];
          if (currentState.completiSbloccati.indexOf(voce.nome) === -1) currentState.completiSbloccati.push(voce.nome);
          PETQ.save.save(currentState);
          if (PETQ.audio) PETQ.audio.suona('acquisto');
          aggiornaHud(currentState);
          // STESSO messaggio dei vestiti normali (rigaGuardaroba/renderShopGuardaroba sopra): un
          // completo sbloccato finisce nello stesso identico posto, l'Armadio della scheda.
          mostraToast(traduci(voce.nome) + traduci(' comprato: lo trovi nell\'Armadio (scheda).'));
          aggiornaDettaglioMappa(statoMappa());
        });
      }
      riga.appendChild(btn);
    }
    return riga;
  }

  // vero se l'arma (che e' un arredo a tutti gli effetti) e' gia' tra i posseduti o i piazzati
  function armaGiaPosseduta(nome) {
    var poss = (currentState.arredi && currentState.arredi.posseduti) || [];
    for (var ip = 0; ip < poss.length; ip++) { if (poss[ip] && poss[ip].nome === nome) return true; }
    var piaz = (currentState.arredi && currentState.arredi.piazzati) || {};
    for (var stz in piaz) {
      if (!Object.prototype.hasOwnProperty.call(piaz, stz)) continue;
      var ls = piaz[stz] || [];
      for (var il = 0; il < ls.length; il++) { if (ls[il] && ls[il].nome === nome) return true; }
    }
    return false;
  }

  function renderShopGuardaroba(wrap) {
    wrap.appendChild(el('div', 'petq-missione-meta',
      traduci('Vestiti (Armadio della scheda) e armi (Armeria, serve il perk Weapon Wielder per impugnarle). ') + traduci('Monete: ') + (currentState.coins || 0) + '.'));

    var data = window.PETQ.content && window.PETQ.content.data;
    var indossabili = (data && data.indossabili) || [];
    var armi = (data && data.armi) || [];

    wrap.appendChild(el('div', 'petq-shop-gruppo-titolo', traduci('Vestiti')));
    var boxV = el('div', 'petq-shop-lista');
    var nV = 0;
    for (var iv = 0; iv < indossabili.length; iv++) {
      if (typeof indossabili[iv].prezzo !== 'number') continue;
      (function (nome, prezzo) {
        var posseduto = Array.isArray(currentState.indossabili) && currentState.indossabili.indexOf(nome) !== -1;
        boxV.appendChild(rigaGuardaroba(nome, 'indossabile', prezzo, posseduto, function () {
          if ((currentState.coins || 0) < prezzo) return;
          currentState.coins -= prezzo;
          if (!Array.isArray(currentState.indossabili)) currentState.indossabili = [];
          if (currentState.indossabili.indexOf(nome) === -1) currentState.indossabili.push(nome);
          PETQ.save.save(currentState);
          aggiornaHud(currentState);
          mostraToast(traduci(nome) + traduci(' comprato: lo trovi nell\'Armadio (scheda).'));
          aggiornaDettaglioMappa(statoMappa());
        }));
        nV++;
      })(indossabili[iv].nome, indossabili[iv].prezzo);
    }
    wrap.appendChild(boxV);
    if (nV === 0) wrap.appendChild(el('p', 'petq-vuoto', traduci('Nessun vestito in vendita al momento.')));

    wrap.appendChild(el('div', 'petq-shop-gruppo-titolo', traduci('Armi')));
    var boxA = el('div', 'petq-shop-lista');
    var nA = 0;
    for (var ia = 0; ia < armi.length; ia++) {
      if (typeof armi[ia].prezzo !== 'number') continue;
      (function (nome, prezzo) {
        boxA.appendChild(rigaGuardaroba(nome, 'arma', prezzo, armaGiaPosseduta(nome), function () {
          if ((currentState.coins || 0) < prezzo) return;
          currentState.coins -= prezzo;
          if (PETQ.arredi && PETQ.arredi.aggiungi) PETQ.arredi.aggiungi(currentState, nome);
          PETQ.save.save(currentState);
          aggiornaHud(currentState);
          mostraToast(traduci(nome) + traduci(' comprata: la trovi nell\'Armeria (scheda).'));
          aggiornaDettaglioMappa(statoMappa());
        }));
        nA++;
      })(armi[ia].nome, armi[ia].prezzo);
    }
    wrap.appendChild(boxA);
    if (nA === 0) {
      wrap.appendChild(el('p', 'petq-vuoto', traduci('Nessun\'arma in vendita: le armi si trovano solo in missione.')));
    }

    // Colori (varianti cromatiche, tabella dati COLORI_PET in cima al file): i due a monete
    // (Fantasma/Lava) si comprano da qui; i tre Supporter Pack sono mostrati ma NON acquistabili.
    // I tre colori base non compaiono: sono gratis da subito, si scelgono dalla scheda (sezione
    // Colore) senza passare dal negozio.
    wrap.appendChild(el('div', 'petq-shop-gruppo-titolo', traduci('Colori')));
    wrap.appendChild(el('div', 'petq-hint', traduci('Una volta sbloccati, si attivano dal Profilo.'))); // v. nota gemella in Stanze
    var boxC = el('div', 'petq-shop-lista');
    for (var ic = 0; ic < COLORI_PET.length; ic++) {
      if (COLORI_PET[ic].tipo !== 'base') boxC.appendChild(rigaColoreNegozio(COLORI_PET[ic]));
    }
    wrap.appendChild(boxC);

    // Completi (vestiti a due pezzi, batch cosmetico — tabella dati COMPLETI_VESTITO in cima al
    // file): STESSO blocco Colori appena sopra, in fondo alla sezione Guardaroba (non Arredamento:
    // sono vestiti, si vendono dove si vendono i vestiti). Le tre 'negozio' si comprano da qui; le
    // due 'supporter' sono mostrate ma NON acquistabili (rigaCompletoNegozio gestisce da sola il
    // terzo stato, stesso pattern di colori/stanze/cornici).
    wrap.appendChild(el('div', 'petq-shop-gruppo-titolo', traduci('Completi')));
    var boxCV = el('div', 'petq-shop-lista');
    for (var icv2 = 0; icv2 < COMPLETI_VESTITO.length; icv2++) {
      boxCV.appendChild(rigaCompletoNegozio(COMPLETI_VESTITO[icv2]));
    }
    wrap.appendChild(boxCV);
  }

  // ===== SOSTIENI (GDD "Monetizzazione", decisa 12 lug 2026 attivata 7 ago 2026) =====
  // Sezione del negozio con soldi VERI, l'unica che passa da PETQ.iap (RevenueCat via plugin
  // Capacitor — può mancare: browser, file://, o plugin/chiave non caricati; in quel caso il
  // gioco resta identico e completo, v. GDD). GUARDIE sempre su window.PETQ.iap &&
  // PETQ.iap.disponibile() prima di ogni uso: il modulo lo scrive un altro batch in parallelo e
  // può non esistere ancora su disco.
  //
  // Prezzi: richiesti a PETQ.iap.prodotti() alla PRIMA apertura della sezione (cache in
  // iapPrezzi, variabile di modulo — non richiesti di nuovo ad ogni remount, es. dopo un
  // acquisto: il prezzo non cambia in sessione); finché non arrivano ogni riga mostra '—'. La
  // callback è asincrona: prima di ridisegnare controlla che la sezione sia ANCORA quella
  // attiva (l'utente potrebbe aver cambiato tab nel frattempo).
  function renderShopSostieni(wrap) {
    if (!window.PETQ.iap || !PETQ.iap.disponibile()) {
      wrap.appendChild(el('div', 'petq-missione-meta',
        traduci('Gli acquisti si fanno dall\'app sul telefono. Qui nel browser il gioco è comunque completo.')));
      return;
    }

    if (iapPrezzi === null) {
      PETQ.iap.prodotti(function (err, mappa) {
        if (err) return;
        iapPrezzi = mappa || {};
        if (shopSezione === 'sostieni') aggiornaDettaglioMappa(statoMappa());
      });
    }

    var prodottiIap = PETQ.iap.PRODOTTI || [];
    function trovaProdottoIap(id) {
      for (var ip = 0; ip < prodottiIap.length; ip++) { if (prodottiIap[ip].id === id) return prodottiIap[ip]; }
      return null;
    }
    function prezzoIapDi(id) {
      return (iapPrezzi && iapPrezzi[id]) ? iapPrezzi[id] : '—';
    }

    // Card HERO del Supporter Pack (richiesta fondatore: "deve essere più visibile, più in
    // grande" — oggi era una riga come le altre). In cima alla sezione, prima di ogni altra cosa.
    // Descrizione: STESSA frase esistente del pack qui sotto (nessun testo nuovo inventato),
    // spezzata sui due punti in 2 righe visive — 'Tutto il lato supporter:' / '3 colori pet, 3
    // skin stanza, 2 cornici, i 4 companion.'. Bottone: STESSA rigaBottoneIap di ogni altro
    // prodotto (nessuna logica d'acquisto duplicata), con l'aggiunta del prezzo dentro il testo
    // del bottone (3o parametro) e una classe extra per il font piu' grande (4o parametro).
    var pack = trovaProdottoIap('supporter_pack');
    if (pack) {
      var possedutoPack = currentState.supporter === true;
      var cardHero = el('div', 'petq-pack-hero');

      cardHero.appendChild(el('div', 'petq-pack-hero-titolo',
        traduci(pack.etichetta) + (possedutoPack ? ' ✓' : '')));

      var cvHero = document.createElement('canvas');
      cvHero.width = 128;
      cvHero.height = 40;
      cvHero.className = 'petq-pack-hero-canvas';
      disegnaCompanionPackHero(cvHero);
      cardHero.appendChild(cvHero);

      var testoPack = traduci('Tutto il lato supporter: 3 colori pet, 3 skin stanza, 2 cornici, i 4 companion.');
      var idxDuePunti = testoPack.indexOf(':');
      if (idxDuePunti !== -1) {
        cardHero.appendChild(el('div', 'petq-pack-hero-desc', testoPack.substring(0, idxDuePunti + 1)));
        cardHero.appendChild(el('div', 'petq-pack-hero-desc', testoPack.substring(idxDuePunti + 1).replace(/^\s+/, '')));
      } else {
        cardHero.appendChild(el('div', 'petq-pack-hero-desc', testoPack));
      }

      var prezzoPack = prezzoIapDi('supporter_pack');
      var azionePack = el('div', 'petq-pack-hero-azione');
      azionePack.appendChild(rigaBottoneIap('supporter_pack', possedutoPack,
        prezzoPack !== '—' ? prezzoPack : null, 'petq-pack-hero-btn'));
      cardHero.appendChild(azionePack);

      wrap.appendChild(cardHero);
    }

    wrap.appendChild(el('div', 'petq-missione-meta',
      traduci('Cosmetici puri: niente potenza in vendita, il gioco è completo gratis.')));
    wrap.appendChild(el('div', 'petq-hint', traduci('Una volta sbloccati, si attivano dal Profilo.')));

    // Righe dei 7 singoli, raggruppate per famiglia — STESSI titoli di gruppo già usati sopra per
    // Stanze/Cornici (Colori compare anche in Guardaroba per i due a monete: stesso titolo,
    // contenuto diverso). "Posseduto" legge le regole di disponibilità UNICHE di
    // coloreDisponibile/skinDisponibile/corniceDisponibile: già vero col Supporter Pack attivo.
    // tipo/valore: SOLO dati per l'anteprima (v. sotto), nessuna logica d'acquisto toccata — sono
    // gli stessi indice/id gia' usati un rigo sopra per "posseduto" (coloreDisponibile(…,4) ecc.),
    // qui ripetuti come dato cosi' il ciclo sotto sa quale creaAnteprima* chiamare e con che valore.
    // nota: rimando alle sorelle a MONETE (fondatore, 24 ago: "non mostra tutte le stanze e le
    // cartoline comprabili" — qui ci sono solo quelle a soldi veri, le altre vivono nelle
    // sezioni a monete e chi guarda solo qui non le scopriva mai).
    var GRUPPI_SOSTIENI = [
      { titolo: 'Colori', tipo: 'colore', nota: 'Altri 2 colori si comprano a monete nel Guardaroba.', voci: [
        { id: 'colore_oro', valore: 4, posseduto: coloreDisponibile(currentState, 4) },
        { id: 'colore_notte_neon', valore: 5, posseduto: coloreDisponibile(currentState, 5) },
        { id: 'colore_ghiaccio', valore: 7, posseduto: coloreDisponibile(currentState, 7) }
      ] },
      { titolo: 'Stanze', tipo: 'stanza', nota: 'Altre 4 skin stanza si comprano a monete negli Arredi.', voci: [
        { id: 'skin_arcade', valore: 'arcade', posseduto: skinDisponibile(currentState, 'arcade') },
        { id: 'skin_mare', valore: 'mare', posseduto: skinDisponibile(currentState, 'mare') },
        { id: 'skin_castello', valore: 'castello', posseduto: skinDisponibile(currentState, 'castello') }
      ] },
      { titolo: 'Cornici', tipo: 'cornice', nota: 'Altre 3 cornici si comprano a monete negli Arredi.', voci: [
        // pack_cornici sblocca dorata+neon INSIEME (un solo prodotto per le due, v. GDD): serve
        // ENTRAMBE disponibili perché il pack conti come "posseduto". Anteprima: 'dorata' come
        // rappresentante del pack (le due cornici si vedono comunque tutte nella scheda una volta
        // sbloccate — qui basta far venire voglia con una).
        { id: 'pack_cornici', valore: 'dorata', posseduto: corniceDisponibile(currentState, 'dorata') && corniceDisponibile(currentState, 'neon') }
      ] }
    ];
    for (var gi = 0; gi < GRUPPI_SOSTIENI.length; gi++) {
      var gruppoS = GRUPPI_SOSTIENI[gi];
      wrap.appendChild(el('div', 'petq-shop-gruppo-titolo', traduci(gruppoS.titolo)));
      var boxS = el('div', 'petq-shop-lista');
      for (var vi = 0; vi < gruppoS.voci.length; vi++) {
        var prodS = trovaProdottoIap(gruppoS.voci[vi].id);
        if (!prodS) continue; // catalogo PETQ.iap.PRODOTTI non ancora completo/caricato: salta, mai un errore
        var rigaS = el('div', 'petq-shop-riga');
        // Anteprima VERA (GDD "Negozio visivo" 24 ago 2026): STESSI costruttori delle righe a
        // monete qui sopra (creaAnteprimaColore/Stanza/Cornice) — anche le righe Supporter fanno
        // venire voglia, non solo quelle a monete. Bloccato = si vede PER INTERO (nessuna
        // opacita' qui, STESSO comportamento delle righe a monete).
        var prevS;
        if (gruppoS.tipo === 'colore') {
          prevS = creaAnteprimaColore(petPerNegozio(), gruppoS.voci[vi].valore);
          prevS.className = 'petq-food-icon';
        } else if (gruppoS.tipo === 'stanza') {
          prevS = creaAnteprimaStanza(gruppoS.voci[vi].valore);
          prevS.style.width = '56px';
          prevS.style.aspectRatio = prevS.width + ' / ' + prevS.height;
          prevS.style.imageRendering = 'pixelated';
          prevS.style.flexShrink = '0';
        } else {
          prevS = creaAnteprimaCornice(statoAnteprimaNegozio(), gruppoS.voci[vi].valore);
          prevS.style.width = '56px';
          prevS.style.aspectRatio = prevS.width + ' / ' + prevS.height;
          prevS.style.imageRendering = 'pixelated';
          prevS.style.flexShrink = '0';
        }
        rigaS.appendChild(prevS);
        var infoS = el('div', 'petq-shop-info');
        infoS.appendChild(el('div', 'petq-cibo-nome', traduci(prodS.etichetta)));
        infoS.appendChild(el('div', 'petq-cibo-effetti', prezzoIapDi(gruppoS.voci[vi].id)));
        rigaS.appendChild(infoS);
        rigaS.appendChild(rigaBottoneIap(gruppoS.voci[vi].id, gruppoS.voci[vi].posseduto));
        boxS.appendChild(rigaS);
      }
      wrap.appendChild(boxS);
      if (gruppoS.nota) wrap.appendChild(el('div', 'petq-hint', traduci(gruppoS.nota)));
    }

    // Ripristina acquisti: stesso schema di ogni Compra sotto (disabilita+'Attendi…', poi tre
    // esiti — successo/annullato/altro errore).
    var btnRipristina = el('button', 'petq-btn petq-btn-mini', traduci('Ripristina acquisti'));
    var testoRipristinaOriginale = btnRipristina.textContent;
    btnRipristina.addEventListener('click', function () {
      btnRipristina.disabled = true;
      btnRipristina.textContent = traduci('Attendi…');
      PETQ.iap.ripristina(currentState, function (err, risultato) {
        if (!err) {
          var n = (risultato && typeof risultato.nuovi === 'number') ? risultato.nuovi : 0;
          if (n > 0) {
            PETQ.save.save(currentState);
            mostraAvviso(traduci('Acquisti ripristinati: ') + n + '.');
            aggiornaHud(currentState);
            aggiornaDettaglioMappa(statoMappa());
          } else {
            mostraToast(traduci('Nessun acquisto da ripristinare.'));
            btnRipristina.disabled = false;
            btnRipristina.textContent = testoRipristinaOriginale;
          }
          return;
        }
        if (err.annullato) {
          btnRipristina.disabled = false;
          btnRipristina.textContent = testoRipristinaOriginale;
          return;
        }
        if (err.nonDisponibile) {
          mostraToast(traduci('Prodotto non disponibile dallo store: riprova più tardi.'));
          btnRipristina.disabled = false;
          btnRipristina.textContent = testoRipristinaOriginale;
          return;
        }
        mostraToast(traduci('Acquisto non riuscito, riprova.') +
          (PETQ.iap.descriviErrore ? PETQ.iap.descriviErrore(err) : ''));
        btnRipristina.disabled = false;
        btnRipristina.textContent = testoRipristinaOriginale;
      });
    });
    wrap.appendChild(btnRipristina);
  }

  // Bottone Compra/Posseduto per UNA riga IAP (Supporter Pack o singolo, STESSO schema per tutti
  // e 8 i prodotti — v. renderShopSostieni sopra). Compra: disabilita+'Attendi…' prima della
  // chiamata; poi quattro esiti — successo (salva, avviso, rimonta la sezione), annullato
  // (riabilita in silenzio: l'utente ha chiuso lo sportello di pagamento da solo, non è un
  // errore), prodotto non arrivato dallo store (messaggio dedicato, non è un fallimento di
  // pagamento), altro errore (toast + il codice/messaggio vero di RevenueCat se c'è, v.
  // PETQ.iap.descriviErrore — prima veniva buttato via e "Purchase failed" da solo non bastava a
  // diagnosticare un fallimento reale).
  //
  // prezzoGrande/extraClass (opzionali, card hero del pack — v. renderShopSostieni): con
  // prezzoGrande il testo del bottone diventa "Compra (2,99€)" invece del solo "Compra" (richiesta
  // fondatore: il prezzo si vede grande dentro il bottone); extraClass aggiunge una classe CSS in
  // più (font più grande) senza toccare gli altri 7 prodotti, che continuano a chiamare questa
  // funzione con 2 soli argomenti — NESSUNA duplicazione della logica d'acquisto per la card hero.
  function rigaBottoneIap(id, posseduto, prezzoGrande, extraClass) {
    var classi = 'petq-btn petq-btn-mini' + (extraClass ? ' ' + extraClass : '');
    if (posseduto) {
      var gia = el('button', classi, traduci('Posseduto ✓'));
      gia.disabled = true;
      return gia;
    }
    var testoCompra = prezzoGrande ? (traduci('Compra') + ' (' + prezzoGrande + ')') : traduci('Compra');
    var btn = el('button', classi, testoCompra);
    var testoOriginale = btn.textContent;
    btn.addEventListener('click', function () {
      btn.disabled = true;
      btn.textContent = traduci('Attendi…');
      PETQ.iap.compra(id, currentState, function (err, risultato) {
        if (!err) {
          PETQ.save.save(currentState);
          mostraAvviso(traduci('Acquisto completato. Grazie di cuore! ❤'));
          aggiornaHud(currentState);
          aggiornaDettaglioMappa(statoMappa());
          return;
        }
        if (err.annullato) {
          btn.disabled = false;
          btn.textContent = testoOriginale;
          return;
        }
        if (err.nonDisponibile) {
          mostraToast(traduci('Prodotto non disponibile dallo store: riprova più tardi.'));
          btn.disabled = false;
          btn.textContent = testoOriginale;
          return;
        }
        mostraToast(traduci('Acquisto non riuscito, riprova.') +
          (PETQ.iap.descriviErrore ? PETQ.iap.descriviErrore(err) : ''));
        btn.disabled = false;
        btn.textContent = testoOriginale;
      });
    });
    return btn;
  }

  // Blocco upgrade "Ingrandimento casa" in cima alla sezione Arredi dello shop. Riusa lo stile
  // delle righe negozio (.petq-shop-riga / .petq-shop-info). Tre stati: gia' comprato (bottone
  // disabilitato "Acquistato"), monete insufficienti (disabilitato), comprabile ("Compra (200)").
  function renderRigaIngrandimento(wrap) {
    var box = el('div', 'petq-shop-lista');
    var riga = el('div', 'petq-shop-riga');

    var testi = el('div', 'petq-shop-info');
    testi.appendChild(el('div', 'petq-cibo-nome', traduci('Ingrandimento casa — ') + COSTO_INGRANDIMENTO + traduci(' monete')));
    testi.appendChild(el('div', 'petq-cibo-effetti',
      traduci('Stanze più grandi + 1 slot arredo in ogni stanza (e tetto bonus più alto).')));
    riga.appendChild(testi);

    if (currentState.ingrandimentoCasa) {
      var giaBtn = el('button', 'petq-btn petq-btn-mini', traduci('Acquistato ✓'));
      giaBtn.disabled = true;
      giaBtn.title = traduci('Hai già ingrandito la casa.');
      riga.appendChild(giaBtn);
    } else {
      var btn = el('button', 'petq-btn petq-btn-mini', traduci('Compra (') + COSTO_INGRANDIMENTO + ')');
      if ((currentState.coins || 0) < COSTO_INGRANDIMENTO) {
        btn.disabled = true;
        btn.textContent = traduci('Monete insufficienti');
        btn.title = traduci('Servono ') + COSTO_INGRANDIMENTO + traduci(' monete.');
      } else {
        btn.addEventListener('click', function () { eseguiIngrandimento(riga); });
      }
      riga.appendChild(btn);
    }

    box.appendChild(riga);
    wrap.appendChild(box);
  }

  // Compra l'Ingrandimento casa: rivalida (non gia' comprato, monete sufficienti), scala 200
  // monete, setta il flag, salva e ridisegna il pannello negozio + HUD. Da qui in poi le stanze
  // rendono alte 80 (4o slot nel pavimento nuovo) e la Collezione mostra 4 slot per stanza.
  function eseguiIngrandimento(rigaEl) {
    if (!currentState) return;
    if (currentState.ingrandimentoCasa) {
      shakeCard(rigaEl);
      mostraToast(traduci('Casa già ingrandita.'));
      aggiornaDettaglioMappa(statoMappa());
      return;
    }
    if ((currentState.coins || 0) < COSTO_INGRANDIMENTO) {
      shakeCard(rigaEl);
      mostraToast(traduci('Monete insufficienti.'));
      return;
    }
    currentState.ingrandimentoCasa = true;
    currentState.coins -= COSTO_INGRANDIMENTO;
    PETQ.save.save(currentState);
    // Ricostruisce l'intera casa: l'upgrade cambia l'altezza delle stanze (64->80), quindi vanno
    // riadattati sia il canvas stanza sia le HOTZONE (vasca/letto, posizionate in % dell'altezza) —
    // cose impostate solo da mostraCasa alla costruzione. mostraCasa riporta alla Cucina (default,
    // riga currentStanza='cucina'): il giocatore VEDE subito la casa piu' grande, chiudendo lo shop
    // (soddisfazione visiva dell'acquisto richiesta dal fondatore).
    mostraCasa(currentState);
    mostraToast(traduci('Casa ingrandita! Stanze piu\' grandi e un 4° slot arredo in ogni stanza.'));
  }

  // arredoDaPerk: vero se l'arredo da' un PERK (di categoria: campo perk valorizzato, o la
  // colonna Bonus grezza contiene "perk"). La vendita di un perk va AVVISATA e confermata
  // (secondo tap), non impedita: v. renderRigaVendi/eseguiVendita.
  function arredoDaPerk(nome) {
    var info = trovaArredoContentUI(nome);
    if (!info) return false;
    if (info.perk) return true;
    if (info.bonus && /perk/i.test(info.bonus)) return true;
    return false;
  }

  function trovaArredoContentUI(nome) {
    var data = window.PETQ.content && window.PETQ.content.data;
    var elenco = (data && data.arredi) || [];
    for (var i = 0; i < elenco.length; i++) {
      if (elenco[i].nome === nome) return elenco[i];
    }
    return null;
  }

  // valore di rivendita mostrato sul bottone: delega a PETQ.arredi.calcolaRicavoVendita, la
  // STESSA funzione che arredi.vendi() usa per accreditare le monete — UNA sola cifra calcolata
  // in UN solo posto, cosi' l'etichetta mostrata qui e l'incasso reale di vendi() non possono
  // disallinearsi (era esattamente il difetto dei tre arredi "alto valore di rivendita" che
  // promettevano tanto e pagavano 5 monete). Ripiego difensivo se arredi.js non fosse ancora
  // caricato (non dovrebbe succedere nell'ordine reale degli script): stessa formula di sempre,
  // prezzo "negozio N" dalla fonte o fallback 10.
  function valoreRivendita(nome) {
    if (PETQ.arredi && PETQ.arredi.calcolaRicavoVendita) {
      return PETQ.arredi.calcolaRicavoVendita(nome);
    }
    var info = trovaArredoContentUI(nome);
    var valore = 10;
    if (info && info.fonte) {
      var m = info.fonte.match(/negozio\s+(\d+)/i);
      if (m) valore = parseInt(m[1], 10);
    }
    return Math.round(valore * 0.5);
  }

  // Sezione VENDI: elenca gli arredi POSSEDUTI e NON piazzati (state.arredi.posseduti),
  // vendibili al 50% via arredi.vendi. Gli arredi piazzati NON compaiono (vanno prima rimossi
  // dalla Collezione). Un arredo-perk mostra un avviso e chiede conferma (secondo tap).
  function renderShopVendi(wrap) {
    wrap.appendChild(el('div', 'petq-missione-meta',
      traduci('Vendi gli arredi che possiedi e non hai piazzato: recuperi il 50%. ') + traduci('Monete: ') + (currentState.coins || 0) + '.'));

    PETQ.arredi._assicuraArrediStruct(currentState);
    var posseduti = (currentState.arredi && currentState.arredi.posseduti) || [];

    if (posseduti.length === 0) {
      wrap.appendChild(el('p', 'petq-vuoto', traduci('Niente da vendere.')));
      return;
    }

    var box = el('div', 'petq-shop-lista');
    for (var i = 0; i < posseduti.length; i++) {
      box.appendChild(renderRigaVendi(posseduti[i]));
    }
    wrap.appendChild(box);
  }

  function renderRigaVendi(voce) {
    var nome = voce.nome;
    var riga = el('div', 'petq-shop-riga');
    var ricavo = valoreRivendita(nome);
    var perk = arredoDaPerk(nome);

    var testi = el('div', 'petq-shop-info');
    testi.appendChild(el('div', 'petq-cibo-nome', traduci(nome)));
    var sotto = el('div', 'petq-cibo-effetti', traduci('Valore di vendita: ') + ricavo + traduci(' monete'));
    testi.appendChild(sotto);
    if (perk) {
      var avviso = el('div', 'petq-shop-perk-avviso', traduci('⚠ dà un perk!'));
      testi.appendChild(avviso);
    }
    riga.appendChild(testi);

    var inConferma = perk && vendiConferma === nome;
    var etichetta = inConferma ? traduci('Confermi?') : (traduci('Vendi (+') + ricavo + ')');
    var btn = el('button', 'petq-btn petq-btn-mini' + (inConferma ? ' petq-btn-conferma' : ''), etichetta);
    btn.addEventListener('click', function () {
      // arredo-perk: il primo tap chiede conferma (senza vendere), il secondo vende.
      if (perk && vendiConferma !== nome) {
        vendiConferma = nome;
        aggiornaDettaglioMappa(statoMappa());
        return;
      }
      eseguiVendita(nome, riga);
    });
    riga.appendChild(btn);
    return riga;
  }

  // Vende un arredo posseduto: arredi.vendi accredita il 50% e lo toglie dai posseduti; poi si
  // ridisegna la lista (l'arredo sparisce). Salvataggio + HUD aggiornati.
  function eseguiVendita(nome, rigaEl) {
    if (!currentState) return;
    var r = PETQ.arredi.vendi(currentState, nome);
    if (!r || !r.ok) {
      shakeCard(rigaEl);
      mostraToast((r && r.msg) || traduci('Vendita non riuscita.'));
      return;
    }
    vendiConferma = null;
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    aggiornaDettaglioMappa(statoMappa());
    mostraToast(r.msg);
  }

  // Furto (talento Cleptomane/Boss di Quartiere): aggiunge 1 porzione del cibo alla dispensa
  // SENZA scalare monete, segna state.furtoDay = oggi (consumato per la giornata: sparisce ogni
  // "Ruba" fino al giorno dopo), toast/battuta. Rivalida qui il furto per sicurezza (doppio tap
  // veloce, cibo fuori tetto): la UI ha gia' filtrato, ma non ci fidiamo del solo render.
  function eseguiFurto(cibo, rigaEl) {
    if (!currentState) return;
    var furto = (PETQ.talenti && PETQ.talenti.furtoDisponibile) ? PETQ.talenti.furtoDisponibile(currentState) : { attivo: false };
    var oggi = PETQ.clock.giornoCorrente(currentState);
    if (!furto.attivo || currentState.furtoDay === oggi) {
      shakeCard(rigaEl);
      mostraToast(traduci('Niente furto disponibile ora.'));
      aggiornaDettaglioMappa(statoMappa());
      return;
    }
    // tetto confrontato col prezzo SCONTATO (v. prezzoCibo): e quello scritto sulla riga
    if (furto.tetto !== null && prezzoCibo(cibo) > furto.tetto) {
      shakeCard(rigaEl);
      mostraToast(traduci('Troppo caro per rubarlo (max ') + furto.tetto + traduci(' monete).'));
      return;
    }
    if (!Array.isArray(currentState.dispensa)) currentState.dispensa = [];
    var voce = null;
    for (var i = 0; i < currentState.dispensa.length; i++) {
      if (currentState.dispensa[i].nome === cibo.nome) { voce = currentState.dispensa[i]; break; }
    }
    if (voce) voce.qty = (voce.qty || 0) + 1;
    else currentState.dispensa.push({ nome: cibo.nome, qty: 1 });

    currentState.furtoDay = oggi;
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    aggiornaDettaglioMappa(statoMappa());
    mostraToast(traduci('Rubato ') + traduci(cibo.nome) + traduci(': gratis, ora è nel frigo. Niente altri furti oggi.'));
  }

  // Compra 1 unita' del cibo: scala le monete UNA volta, incrementa la qty in dispensa (o crea la
  // riga se il pet non ne aveva) di cibo.porzioni PORZIONI (MULTI-PORZIONE, decisione fondatore 27
  // lug 2026: il prezzo in negozio e' gia' tarato su N porzioni, es. Arrosto 22 monete -> ×3 fette
  // -> qty +3 in un colpo solo). Fallback a 1 se cibo.porzioni manca (oggetti-cibo costruiti a
  // mano altrove, es. ciboFallback, che non passano dal parser e non hanno il campo). Ripetibile
  // a piacere finché ci sono monete.
  function eseguiAcquisto(cibo, rigaEl) {
    if (!currentState) return;
    // stesso prezzo mostrato sulla riga, sconto Frigo nuovo incluso (v. prezzoCibo)
    var prezzo = prezzoCibo(cibo);
    if ((currentState.coins || 0) < prezzo) {
      if (PETQ.audio) PETQ.audio.suona('rifiuto');
      shakeCard(rigaEl);
      mostraToast(traduci('Monete insufficienti.'));
      return;
    }
    currentState.coins -= prezzo;
    var porzioni = cibo.porzioni || 1;
    if (!Array.isArray(currentState.dispensa)) currentState.dispensa = [];
    var voce = null;
    for (var i = 0; i < currentState.dispensa.length; i++) {
      if (currentState.dispensa[i].nome === cibo.nome) { voce = currentState.dispensa[i]; break; }
    }
    if (voce) {
      voce.qty = (voce.qty || 0) + porzioni;
    } else {
      currentState.dispensa.push({ nome: cibo.nome, qty: porzioni });
    }
    if (PETQ.audio) PETQ.audio.suona('acquisto');
    PETQ.save.save(currentState);
    aggiornaHud(currentState);
    aggiornaDettaglioMappa(statoMappa());
    mostraToast(traduci(cibo.nome) + traduci(' comprato: ora è nel frigo.'));
  }

  function coordMappa(canvas, clientX, clientY) {
    var r = canvas.getBoundingClientRect();
    if (!r.width || !r.height) return { x: -1, y: -1 };
    // altezza CORRENTE della vista mappa attiva (v. altezzaMappaCorrente sopra): senza, con la
    // mappa corta il tap convertirebbe la coordinata Y su una scala sbagliata, spostando
    // l'hit-test dei pin.
    var altMappa = altezzaMappaCorrente(statoMappa());
    return {
      x: (clientX - r.left) * PETQ.rooms._MAPPA_W / r.width,
      y: (clientY - r.top) * altMappa / r.height
    };
  }

  // hit-test sui pin dei soli luoghi attivi (margine generoso per il touch). Vista mappa
  // CORRENTE (v. mappaVistaCitta/rettangoliMappaCorrente sopra): i rettangoli vengono da
  // rettangoliQuartiere (l'ultimo drawMappaQuartiere) o da _mappaPins (posizioni FISSE
  // dell'atlante) secondo la vista attiva — usare la fonte sbagliata renderebbe TUTTI i pin
  // intappabili in una delle due viste (gli slot del quartiere cambiano posto ogni giorno
  // secondo la rosa, l'atlante no).
  function hitPin(p, attivi) {
    var pins = rettangoliMappaCorrente();
    for (var i = 0; i < (attivi || []).length; i++) {
      var id = attivi[i];
      var rect = pins[id];
      // guardia anti-regressione (v. avvisaPinMancanteUi sopra): un id in rosa senza pin viene
      // solo segnalato e saltato, mai un'eccezione — gli altri pin restano tappabili.
      if (!rect) { avvisaPinMancanteUi(id); continue; }
      if (dentroRect(p, rect, 3)) return id;
    }
    return null;
  }

  // hit-test sul pin del Negozio (m0), SOLO dopo lo sblocco (GDD "Economia" -> "Spesa e
  // dispensa": negozio unico). Prima del tutorial, il tap su m0 deve invece seguire il
  // percorso normale hitPin/tutorial (v. installaPointerMappa sotto) — questo hit-test attiva
  // il menu ACQUISTO, non va confuso col tutorial.
  // Vista mappa CORRENTE: il Negozio (m0, sempre tra gli attivi quando sbloccato, v. statoMappa)
  // occupa uno slot che cambia posto ogni giorno nel quartiere come tutti gli altri, mentre
  // nell'atlante città ha la sua posizione FISSA — va quindi letto da rettangoliMappaCorrente()
  // con l'id giusto (_shopPinId), mai dal rettangolo fisso preso a prescindere dalla vista.
  function hitShopPin(p) {
    if (!currentState || !currentState.negozioSbloccato) return false;
    var pins = rettangoliMappaCorrente();
    var shopId = (PETQ.rooms && PETQ.rooms._shopPinId) || 'm0';
    var rect = pins[shopId];
    return !!(rect && dentroRect(p, rect, 3));
  }

  function installaPointerMappa(canvas) {
    canvas.addEventListener('pointerdown', function (e) {
      mapPointer = { id: e.pointerId, x: e.clientX, y: e.clientY };
    });

    function fine(e, annullato) {
      if (!mapPointer || e.pointerId !== mapPointer.id) return;
      var dx = e.clientX - mapPointer.x;
      var dy = e.clientY - mapPointer.y;
      mapPointer = null;
      if (annullato || Math.sqrt(dx * dx + dy * dy) > 12) return; // non era un tap

      var p = coordMappa(canvas, e.clientX, e.clientY);

      // shop: sempre tappabile (anche a missione in corso o rosa esaurita), niente a che
      // vedere col motore missioni. Tap fuori dal pin mentre il negozio e' aperto lo chiude.
      if (hitShopPin(p)) {
        negozioSelezionato = true;
        shopSezione = 'cibo';   // il negozio si apre sempre sulla sezione Cibo
        vendiConferma = null;
        missioneSelezionata = null;
        aggiornaDettaglioMappa(statoMappa());
        return;
      }
      if (negozioSelezionato) {
        negozioSelezionato = false;
        aggiornaDettaglioMappa(statoMappa());
        return;
      }

      var sm = statoMappa();
      if (sm.inCorso) return; // nessun pin missione tappabile durante la missione

      var pinTap = hitPin(p, sm.attivi); // pin -> seleziona/cambia; fuori -> null = chiude

      // NB storico: qui c'era il tap dedicato al pin m17 "Clinica di Modding" (Pimp My Pet), che
      // apriva mostraTeenIntro senza passare dal motore missioni. RIMOSSO su decisione del
      // fondatore (28 lug 2026): m17 non entra piu' tra gli attivi (v. statoMappa), quindi hitPin
      // non puo' piu' restituirlo — ramo tolto perche' ormai irraggiungibile.
      missioneSelezionata = pinTap;
      ridisegnaMappa();
      aggiornaDettaglioMappa(sm);
    }

    canvas.addEventListener('pointerup', function (e) { fine(e, false); });
    canvas.addEventListener('pointercancel', function (e) { fine(e, true); });
  }

  // Titolo della Medaglia dell'Impresa nella lingua ATTIVA. Stesso difetto dei talenti (v.
  // descrizioneTalentoCorrente): missions.js congela { id, titolo } dentro il salvataggio nella
  // lingua in cui si giocava quando l'Impresa e' stata completata, quindi un giocatore che passa
  // a EN si ritroverebbe il titolo italiano appiccicato addosso per sempre. L'id invece e' una
  // chiave stabile: si rilegge la scheda dal catalogo corrente e si usa il SUO titolo.
  // Difensiva a ogni livello (catalogo non caricato, id sparito da content): fallback al titolo
  // congelato, che e' comunque meglio di niente.
  function schedaImpresaCorrente(med) {
    try {
      if (!med || !med.id) return med;
      var lista = (window.PETQ && PETQ.content && PETQ.content.data && PETQ.content.data.missioni) || null;
      if (!lista || !lista.length) return med;
      for (var i = 0; i < lista.length; i++) {
        if (lista[i] && lista[i].id === med.id && lista[i].titolo) return lista[i];
      }
    } catch (e) { /* catalogo in stato strano: si tiene la copia congelata */ }
    return med;
  }

  function titoloMissione(scheda) {
    var t = (scheda && scheda.titolo) || '';
    t = t.replace(/^Missione\s+\d+\s*[:—–-]*\s*/i, '');
    t = t.replace(/\s*\[[^\]]*\]\s*$/, '');
    return t.trim() || (scheda && scheda.id) || traduci('Missione');
  }

  function statLabels(statArr) {
    var out = [];
    for (var i = 0; i < (statArr || []).length; i++) {
      out.push(traduci(STAT_LABEL[statArr[i]]) || capitalize(statArr[i]));
    }
    return out.join(', ');
  }

  function cardMissione(scheda) {
    var card = el('div', 'petq-missione-card');
    card.appendChild(el('div', 'petq-missione-titolo', titoloMissione(scheda)));

    var meta = [];
    if (scheda.luogo) meta.push(scheda.luogo);
    if (scheda.durata) meta.push(traduci('Durata: ') + scheda.durata);
    // niente valore del pet qui: scoprire se si è all'altezza fa parte del gioco
    // (le proprie stat si leggono nell'HUD)
    if (scheda.stat && scheda.stat.length) meta.push(traduci('Stat: ') + statLabels(scheda.stat));
    if (scheda.costo > 0) meta.push(traduci('Costo: ') + scheda.costo + traduci(' monete'));
    card.appendChild(el('div', 'petq-missione-meta', meta.join(' · ')));

    // Brief narrativo (parser: scheda.brief, 1-2 frasi che raccontano l'EVENTO, gia' nella
    // lingua giusta -> NON passa da traduci()). Contenuti a ondate: se manca (null) niente
    // elemento, niente placeholder. Mai stat/condizioni qui (regola sacra: niente spoiler).
    if (scheda.brief) {
      card.appendChild(el('div', 'petq-missione-brief', scheda.brief));
    }

    // anteprima del SOLO esito standard: fallimenti e super si scoprono giocando
    var standard = null;
    for (var i = 0; i < (scheda.esiti || []).length; i++) {
      if (scheda.esiti[i].tipo === 'standard') { standard = scheda.esiti[i]; break; }
    }
    if (standard && standard.reward && standard.reward.length) {
      var tokens = [];
      for (var j = 0; j < standard.reward.length; j++) {
        tokens.push(formattaRewardToken(standard.reward[j]));
      }
      card.appendChild(el('div', 'petq-missione-reward', traduci('Ricompensa: ') + tokens.join(', ')));
    }

    // Ricompense POTENZIALI del super successo (il fondatore le vuole mostrabili: "cosa puoi
    // vincere", MAI il "come" -> niente chiave esito, niente condizioni, niente fallimenti).
    // Unione deduplicata dei token grezzi di TUTTI gli esiti 'super' della scheda, poi formattati
    // con lo stesso formatter della riga reward standard (coerenza visiva). Nessun esito super
    // sulla scheda -> nessuna riga.
    var superToken = [];
    for (var si = 0; si < (scheda.esiti || []).length; si++) {
      if (scheda.esiti[si].tipo !== 'super') continue;
      var srw = scheda.esiti[si].reward || [];
      for (var sj = 0; sj < srw.length; sj++) {
        if (superToken.indexOf(srw[sj]) === -1) superToken.push(srw[sj]);
      }
    }
    if (superToken.length) {
      var superFmt = [];
      for (var sk = 0; sk < superToken.length; sk++) {
        superFmt.push(formattaRewardToken(superToken[sk]));
      }
      card.appendChild(el('div', 'petq-missione-super', '✨ ' + traduci('Super successo: ') + superFmt.join(', ')));
    }

    var btn = el('button', 'petq-btn petq-btn-primario petq-btn-piccolo', traduci('Parti'));
    if (scheda.costo > 0 && (currentState.coins || 0) < scheda.costo) {
      btn.disabled = true;
      btn.title = traduci('Monete insufficienti.');
    }
    btn.addEventListener('click', function () { eseguiPartenza(scheda); });
    card.appendChild(btn);

    return card;
  }

  function cardMissioneInCorso() {
    var scheda = PETQ.missions.inCorso(currentState);
    var card = el('div', 'petq-missione-card petq-missione-card-corso');
    card.appendChild(el('div', 'petq-missione-titolo', scheda ? titoloMissione(scheda) : traduci('Missione in corso')));
    if (scheda && scheda.luogo) card.appendChild(el('div', 'petq-missione-meta', scheda.luogo));

    var countdown = el('div', 'petq-missione-countdown-riga');
    countdown.appendChild(el('span', null, traduci('Torna tra ')));
    var span = el('span', 'petq-missione-countdown', formattaTempo(PETQ.missions.tempoRimasto(currentState)));
    span.id = 'petq-missione-countdown';
    countdown.appendChild(span);
    card.appendChild(countdown);

    if (battutaPartenza) {
      card.appendChild(el('div', 'petq-missione-quote', '"' + battutaPartenza + '"'));
    }
    return card;
  }

  function cardTutorial(m0) {
    var card = el('div', 'petq-missione-card petq-missione-card-tutorial');
    card.appendChild(el('div', 'petq-missione-titolo', titoloMissione(m0)));
    if (m0.luogo) card.appendChild(el('div', 'petq-missione-meta', m0.luogo));
    card.appendChild(el('div', 'petq-missione-reward', traduci('Regalo di benvenuto: nessun rischio, nessuna attesa.')));

    var btn = el('button', 'petq-btn petq-btn-primario petq-btn-piccolo', traduci('Vai'));
    btn.addEventListener('click', eseguiTutorial);
    card.appendChild(btn);
    return card;
  }

  function eseguiPartenza(scheda) {
    if (currentState.missione) return;
    if (currentState.allenamento) {
      mostraToast((currentState.pet.nome || traduci('Il pet')) + traduci(' si sta allenando.'));
      return;
    }
    var r = PETQ.missions.avvia(currentState, scheda.id);
    if (!r.ok) {
      mostraToast(r.msg);
      return;
    }
    if (PETQ.audio) PETQ.audio.suona('missioneParte');
    PETQ.save.save(currentState);
    battutaPartenza = PETQ.dialog.say(currentState.pet, 'missione_partenza', currentState);
    missioneSelezionata = null;
    // Reset della vista mappa (v. mappaVistaCitta sopra, richiesta fondatore 28 lug 2026): a
    // missione avviata la mappa torna al quartiere compatto, cosi' al rientro il giocatore trova
    // di nuovo la vista utile per agire invece dell'atlante intero lasciato aperto per curiosita'.
    mappaVistaCitta = false;
    aggiornaHud(currentState);
    renderAzioni(); // ora la tab mostra la scheda in corso con countdown e battuta
  }

  function eseguiTutorial() {
    var r = PETQ.missions.risolviTutorial(currentState);
    if (!r.ok) {
      mostraToast(r.msg);
      return;
    }
    PETQ.save.save(currentState);
    mostraEsito(r);
  }

  // ==================== SCHERMATA ESITO ====================

  function mostraEsito(esito) {
    fermaIdle();
    puliziaEffetto();
    battutaPartenza = null;
    collezioneAperta = false;
    missioneSelezionata = null;

    // Suono d'esito (audio.js): il tipo che distingue super/fallimento e' esito.tipo, gli stessi
    // valori usati sopra dalla mappa `titoli` ('standard'|'super'|'fallimento'|'tutorial') — solo
    // 'super' e 'fallimento' hanno una voce dedicata, tutto il resto (standard/tutorial) usa
    // 'missioneOk' (v. brief fondatore: "altrimenti missioneOk").
    if (PETQ.audio) {
      if (esito.tipo === 'super') PETQ.audio.suona('missioneSuper');
      else if (esito.tipo === 'fallimento') PETQ.audio.suona('missioneKo');
      else PETQ.audio.suona('missioneOk');
    }

    var app = getApp();
    app.innerHTML = '';

    var titoli = {
      standard: 'Missione compiuta',
      super: 'Super successo!',
      fallimento: 'Missione fallita...',
      tutorial: 'Regalo di benvenuto'
    };

    var wrap = el('div', 'petq-screen petq-esito');
    // MARCATORE (stesso schema di mostraPorta/mostraCarta/mostraTeenIntro, id 'petq-porta'/
    // 'petq-carta'/'petq-teenintro'): e' cio' che impedisce a controllaEvoluzioneScaduta/
    // controllaEventoValigia/controllaPortaPendente/controllaCartaPendente di RIMONTARE sopra
    // questa cartolina ad ogni giro di render (30s, o subito al rientro in foreground) — e' il
    // bug v144 ("Da teen il tempo si ferma"), qui nella sua variante "la ricompensa appena letta
    // sparisce sotto le dita": missions.js risolvi() azzera state.missione PRIMA che questa
    // funzione venga chiamata, quindi al giro dopo quei quattro controlli non avevano modo di
    // sapere che la cartolina era ancora a video.
    wrap.id = 'petq-schermo-esito'; // nome NON usato altrove: 'petq-esito' e 'petq-cartolina' sono gia' CLASSI (rispettivamente di 6 schermate e del canvas qui sotto), un id omonimo si rilegge male
    wrap.appendChild(el('h1', 'petq-title', traduci(titoli[esito.tipo]) || traduci('Ritorno a casa')));

    var cart = document.createElement('canvas');
    cart.width = ROOM_W;
    cart.height = ROOM_H;
    cart.className = 'petq-cartolina';
    // Cornice (batch cosmetico): corniceCorrente ripiega su null se il Supporter si e' spento o
    // l'unlock e' andato perso, cosi' una cornice non piu' disponibile sparisce senza rompere
    // nulla (v. corniceCorrente sopra per il commento esteso).
    disegnaCartolina(cart, esito.scenaId, petLikeDaState(currentState), corniceCorrente(currentState));
    wrap.appendChild(cart);

    var testo = risolviSlotEsito(esito.testo || '', esito);
    if (testo) wrap.appendChild(el('p', 'petq-esito-testo', testo));

    if (esito.rewards && esito.rewards.length) {
      var lista = el('div', 'petq-esito-rewards');
      lista.appendChild(el('div', 'petq-hint', traduci('Ottenuto:')));
      for (var i = 0; i < esito.rewards.length; i++) {
        lista.appendChild(rigaReward(esito.rewards[i]));
      }
      wrap.appendChild(lista);
    }

    var btn = el('button', 'petq-btn petq-btn-primario', traduci('Torna a casa'));
    btn.addEventListener('click', function () {
      mostraCasa(currentState);
      var pool = esito.tipo === 'fallimento' ? 'missione_fallimento' : 'missione_successo';
      mostraBalloon(PETQ.dialog.say(currentState.pet, pool, currentState));
    });
    wrap.appendChild(btn);

    app.appendChild(wrap);
    montaDebugPanel();
  }

  // ==================== SCHERMATA M17 "PIMP MY PET" (intro teen) ====================
  // Missione 17 (content/missioni.md): "Pimp My Pet" / Clinica di Modding, RIMOSSA dal gioco su
  // decisione del fondatore (28 lug 2026): "pimp my pet rimuovilo, crea problemi e non serve ed
  // e' bug ancora fastidioso" (montava sopra la casa e faceva sparire HUD/orologio, v. NB in
  // render() sopra). La schermata sotto (mostraTeenIntro) e la sua funzione di recovery
  // (controllaTeenIntroPendente) restano nel file MA SENZA CHIAMANTI: non si aprono piu' ne' dal
  // bottone "Continua" di mostraEvoluzione ne' dal pin m17 sulla mappa (v. statoMappa,
  // installaPointerMappa). Tenute (non cancellate) perche' i salvataggi esistenti possono avere
  // gia' modSprite valorizzato da una scelta passata: quel campo (e teenIntroFatto) restano sul
  // pet e il disegno dello sprite (drawOverlayEquip in sprites.js, via petLikeDaState) continua a
  // leggere modSprite esattamente come prima — il pet di chi l'aveva scelta non cambia aspetto.
  // Descrizione storica (per chi legge il codice sotto): all'evoluzione teen il giocatore
  // sceglieva UNA modifica PERMANENTE = +2 a una stat RPG + un nuovo sprite per sempre, per 10
  // monete. 8 opzioni = 4 stat x 2 razze (robot: impianti, alieno: mutazioni). Gli sprite sono
  // gia' in sprites.js (MOD_SPR): settare state.pet.modSprite li fa disegnare da drawOverlayEquip.
  var M17_COSTO = 10;
  var M17_STAT_LABEL = { forza: 'Forza', velocita: 'Velocità', intelligenza: 'Intelligenza', carisma: 'Carisma' };
  // Chiavi stat = pet.rpg (forza/velocita/intelligenza/carisma); mod = chiave MOD_SPR in sprites.js.
  var M17_ROBOT_OPTS = [
    { stat: 'forza', mod: 'servobraccia', label: 'Servo-braccia idrauliche' },
    { stat: 'velocita', mod: 'turbina', label: 'Turbina dorsale' },
    { stat: 'intelligenza', mod: 'antenna', label: 'Antenna neurale' },
    { stat: 'carisma', mod: 'neon', label: 'Insegna al neon' }
  ];
  var M17_ALIENO_OPTS = [
    { stat: 'forza', mod: 'chele', label: 'Chele / arto extra' },
    { stat: 'velocita', mod: 'pinne', label: 'Pinne / zampe da corsa' },
    { stat: 'intelligenza', mod: 'terzocchio', label: 'Terzo occhio' },
    { stat: 'carisma', mod: 'biolum', label: 'Bioluminescenza / cresta' }
  ];

  // "Piu' tardi" di M17: rimando di SESSIONE (non persistito). true = non riproporre in questo
  // run; al prossimo avvio dell'app riparte false e il recovery la ripropone.
  var teenIntroRimandato = false;

  function mostraTeenIntro(state) {
    fermaIdle();
    puliziaEffetto();
    currentState = state;

    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-esito');
    wrap.id = 'petq-teenintro'; // marker per il recovery al tick (controllaTeenIntroPendente)
    wrap.appendChild(el('h1', 'petq-title', 'Pimp My Pet'));

    // Pet TEEN col petLike vero (mostra anche la modifica se gia' settata, ma qui e' ancora null).
    // Canvas QUADRATO come mostraNascita: sprites.draw scala sulla larghezza (canvas.width/16),
    // su un canvas 112x64 il pet verrebbe alto 112px e TAGLIATO a meta' (fix audit pre-test).
    var cart = document.createElement('canvas');
    cart.width = PET_SIZE * 6;
    cart.height = PET_SIZE * 6;
    cart.className = 'petq-sprite-grande';
    wrap.appendChild(cart);
    PETQ.sprites.draw(cart, petLikeDaState(state), { frame: 0 });

    wrap.appendChild(el('p', 'petq-esito-testo',
      traduci('Diventare teenager ha i suoi vantaggi: per dieci monete puoi uscire da qui... aggiornato. ' +
      'Scegli con calma: quello che scegli, te lo porti per sempre.')));

    var abbastanza = (state.coins >= M17_COSTO);
    wrap.appendChild(el('div', 'petq-hint',
      traduci('Costo: ') + M17_COSTO + traduci(' monete — ne hai ') + state.coins +
      (abbastanza ? '' : traduci(' (te ne servono ') + M17_COSTO + ')')));

    // Applica la scelta: scala le monete, +2 alla stat RPG, setta la modifica permanente, chiude.
    // Guard anche su teenIntroFatto: un doppio click/tap veloce farebbe scattare il listener una
    // seconda volta sul bottone ormai staccato dal DOM (mostraCasa ha gia' svuotato l'app) e
    // addebiterebbe/applicherebbe DUE volte. La scelta e' "1 volta all'evoluzione": flag e stop.
    function applicaScelta(statKey, mod) {
      if (state.coins < M17_COSTO) return;
      if (state.pet && state.pet.teenIntroFatto) return;
      state.coins -= M17_COSTO;
      // Passa dal cancello unico come ogni altra fonte di stat (v. pet.js aggiungiStat): questa
      // schermata oggi NON ha chiamanti (M17 rimossa il 28 lug), ma se un domani qualcuno la
      // riaccende deve nascere gia' dentro il tetto invece che essere il buco che se ne accorge
      // nessuno.
      if (PETQ.pet && PETQ.pet.aggiungiStat) PETQ.pet.aggiungiStat(state.pet, statKey, 2);
      state.pet.modSprite = mod;
      state.pet.teenIntroFatto = true;
      PETQ.save.save(state);
      mostraCasa(currentState);
      if (typeof mostraToast === 'function') mostraToast(traduci('Modifica applicata: te la porti per sempre!'));
    }

    var opts = (state.pet.razza === 'robot') ? M17_ROBOT_OPTS : M17_ALIENO_OPTS;
    var box = el('div', 'petq-esito-rewards');
    for (var i = 0; i < opts.length; i++) {
      (function (o) {
        var statLabel = traduci(M17_STAT_LABEL[o.stat]) || o.stat;
        var b = el('button', 'petq-btn petq-btn-primario', traduci(o.label) + ' (+2 ' + statLabel + ')');
        if (!abbastanza) {
          b.disabled = true;
        } else {
          b.addEventListener('click', function () { applicaScelta(o.stat, o.mod); });
        }
        box.appendChild(b);
      })(opts[i]);
    }
    wrap.appendChild(box);

    // "Piu' tardi" VERO (fix audit: prima settava teenIntroFatto=true, cioe' un salta-per-sempre
    // travestito): rimanda SOLO per questa sessione (flag runtime non salvato) — alla prossima
    // apertura dell'app il recovery (controllaTeenIntroPendente) la ripropone dalla casa.
    var salta = el('button', 'petq-btn petq-btn-secondario', traduci('Più tardi (la Clinica resta sulla mappa)'));
    salta.addEventListener('click', function () {
      teenIntroRimandato = true;
      mostraCasa(currentState);
    });
    wrap.appendChild(salta);

    app.appendChild(wrap);
    montaDebugPanel();
  }

  // ==================== SCHERMATA EVOLUZIONE (PROTOTIPO-2.md punto 1; P3 estesa a teen->adulto)
  // ====================
  // Baby -> teen (e ora, scheletro P3, teen -> adulto): mostra il pet nello stadio PRECEDENTE, un
  // "flash" di transizione, poi il pet nel nuovo stadio (riusa gli sprite esistenti, v.
  // sprites.js) con la battuta del pool 'evoluzione' della personalita' e un bottone "Continua"
  // che torna alla casa col pet gia' nel nuovo stadio (lo stadio e' stato cambiato PRIMA di aprire
  // questa schermata, v. controllaEvoluzioneScaduta sotto: qui disegniamo solo "prima" costruendo
  // un petLike temporaneo con stadio forzato allo stadio precedente).
  var EVOLUZIONE_FLASH_MS = 900;
  // Stadio PRECEDENTE per ciascun nuovo stadio raggiunto (usato per il petLike "prima" e per il
  // testo dell'annuncio): baby->teen e teen->adulto sono le uniche transizioni del prototipo.
  var STADIO_PRECEDENTE = { teen: 'baby', adulto: 'teen' };
  var STADIO_ANNUNCIO_LABEL = { teen: 'TEEN', adulto: 'ADULTO' };

  function mostraEvoluzione(state) {
    fermaIdle();
    puliziaEffetto();
    currentState = state;

    var nuovoStadio = (state.pet && state.pet.stadio) || 'teen';
    var stadioPrima = STADIO_PRECEDENTE[nuovoStadio] || 'baby';
    var labelAnnuncio = traduci(STADIO_ANNUNCIO_LABEL[nuovoStadio]) || nuovoStadio.toUpperCase();

    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-evoluzione');
    // MARCATORE (fix "l'annuncio puo' essere scavalcato in silenzio"): id DIVERSO dalla classe
    // 'petq-evoluzione' qui sopra (un id omonimo di una classe si rilegge male, v. 'petq-porta'/
    // 'petq-carta'/'petq-schermo-esito' per lo stesso pattern). Senza questo marcatore, se il
    // giocatore non preme "Continua" e nel frattempo matura ANCHE lo stadio successivo (es. resta
    // con l'annuncio TEEN a video cosi' a lungo che nel frattempo scatta pure la soglia ADULTO),
    // controllaEvoluzioneScaduta la sostituiva in silenzio: l'annuncio e il talento appena preso
    // non venivano mai letti. La guardia che usa questo id vive in controllaEvoluzioneScaduta.
    wrap.id = 'petq-schermo-evoluzione';
    wrap.appendChild(el('h1', 'petq-title', traduci('Evoluzione!')));

    // Canvas QUADRATO come mostraNascita (fix audit pre-test): sprites.draw scala sulla
    // larghezza, su 112x64 il pet risultava alto 112px e tagliato a meta' (solo la testa).
    var cart = document.createElement('canvas');
    cart.width = PET_SIZE * 6;
    cart.height = PET_SIZE * 6;
    cart.className = 'petq-sprite-grande';
    wrap.appendChild(cart);

    var hint = el('div', 'petq-hint', (state.pet.nome || traduci('Il tuo pet')) + traduci(' e’ diventato ') + labelAnnuncio + '.');
    wrap.appendChild(hint);

    var testoEl = el('p', 'petq-esito-testo', '');
    wrap.appendChild(testoEl);

    var btn = el('button', 'petq-btn petq-btn-primario', traduci('Continua'));
    btn.style.display = 'none';
    btn.addEventListener('click', function () {
      // M17 "Pimp My Pet": qui, all'evoluzione a teen, si apriva mostraTeenIntro (la Clinica di
      // Modding). RIMOSSO su decisione del fondatore (28 lug 2026, "crea problemi e non serve"):
      // "Continua" riporta SEMPRE alla casa, qualunque sia lo stadio appena raggiunto — ECCETTO
      // l'evoluzione a ADULTO, dove si propone SUBITO la PORTA 3 "La Carriera" (doc
      // DESIGN-DILEMMI-LAVORI.md §1: "dentro la scenetta di evoluzione", stesso posto di M17).
      // FIX "la carriera si puo' perdere per sempre": PETQ.porte.porteDaMostrare ORA include anche
      // la Carriera (v. porte.js) come rete di sicurezza — se questo "Continua" non viene mai
      // premuto (app chiusa/in background proprio in quel momento, ricarica durante il flash, un
      // salto da debug che forza lo stadio) il tick successivo la ripropone da solo via
      // controllaPortaPendente. Questo trigger diretto RESTA perche' e' immediato (niente attesa
      // del prossimo giro di render) e non duplica nulla: mostraPorta segna lo schermo con l'id
      // 'petq-porta' (controllaPortaPendente non rimonta se c'e' gia'), e l'annuncio di evoluzione
      // (id 'petq-schermo-evoluzione') e' comunque gia' sparito, sostituito proprio da questo click.
      // Se il pet non ha mai scelto un lavoretto (Porta 2) opzioniPorta ritorna zero opzioni:
      // niente schermata vuota, si torna alla casa come sempre. Lo stadio e' GIA' 'adulto' a
      // questo punto (il cambio e' avvenuto prima di aprire questa schermata, v. sopra), quindi
      // porte.scegli('carriera', ...) trovera' la guardia di stadio gia' soddisfatta.
      if (nuovoStadio === 'adulto' && PETQ.porte && PETQ.porte.opzioniPorta) {
        var giaFattaCarriera = PETQ.porte.assicura(currentState).fatte.carriera;
        var opzCarriera = giaFattaCarriera ? [] : PETQ.porte.opzioniPorta(currentState, 'carriera');
        if (opzCarriera && opzCarriera.length > 0) {
          mostraPorta(currentState, 'carriera');
          return;
        }
      }
      mostraCasa(currentState);
    });
    wrap.appendChild(btn);

    app.appendChild(wrap);
    montaDebugPanel();

    // "prima": pet ancora nello stadio precedente (petLikeDaState legge lo stadio VERO, gia'
    // quello nuovo a questo punto perche' il cambio stadio e' avvenuto prima di chiamare questa
    // funzione — v. controllaEvoluzioneScaduta — quindi forziamo qui un petLike copia con stadio
    // precedente).
    var petLikeBaby = petLikeDaState(state);
    petLikeBaby.stadio = stadioPrima;
    petLikeBaby.corpo = 'normale'; // mai varianti corpo da baby (v. pet.bodyVariant); teen "prima" idem per coerenza visiva del flash
    PETQ.sprites.draw(cart, petLikeBaby, { frame: 0 });

    // flash -> pet nel nuovo stadio (scadenza garantita: setTimeout del browser, la schermata e'
    // statica nel frattempo, nessun tick di gioco puo' "congelarla" a meta').
    setTimeout(function () {
      // flash: schermo bianco brevissimo
      var g = cart.getContext('2d');
      g.imageSmoothingEnabled = false;
      g.fillStyle = '#ffffff';
      g.fillRect(0, 0, cart.width, cart.height);

      setTimeout(function () {
        PETQ.sprites.draw(cart, petLikeDaState(currentState), { frame: 0 });
        testoEl.textContent = PETQ.dialog.say(currentState.pet, 'evoluzione', currentState);
        btn.style.display = '';
        // Icona del NUOVO talento appena ottenuto (PROTOTIPO 2, esteso P3): l'ultimo talento con
        // stadio uguale al nuovo stadio raggiunto (non piu' hardcoded 'teen').
        var tlsE = currentState.pet.talenti || [], talTeen = null;
        for (var ti = 0; ti < tlsE.length; ti++) { if (tlsE[ti] && tlsE[ti].stadio === nuovoStadio) talTeen = tlsE[ti]; }
        // Il blocco "Nuovo talento" si mostra SEMPRE se il talento esiste (fix P3: prima era
        // legato a haTalento -> i talenti adulto, senza icona ancora disegnata, sparivano in
        // silenzio dall'annuncio). Icona se disegnata in badges.js, altrimenti fallback al
        // pallino colorato per rarita' (stesso pattern della scheda personaggio).
        if (talTeen) {
          var boxTeen = el('div', 'petq-evo-talento');
          if (PETQ.badges && PETQ.badges.haTalento && PETQ.badges.haTalento(talTeen.nome)) {
            var icoT = document.createElement('canvas');
            icoT.width = 84; icoT.height = 84; icoT.className = 'petq-talento-icona';
            PETQ.badges.disegnaTalento(icoT, talTeen.nome, talTeen.raro);
            boxTeen.appendChild(icoT);
          } else {
            boxTeen.appendChild(el('span', 'petq-talento-pallino ' + (talTeen.raro ? 'petq-talento-raro' : 'petq-talento-normale')));
          }
          boxTeen.appendChild(el('div', 'petq-evo-talento-nome', traduci('Nuovo talento: ') + traduci(talTeen.nome)));
          wrap.appendChild(boxTeen);
        }
      }, 250);
    }, EVOLUZIONE_FLASH_MS);
  }

  // Controlla se il pet deve evolvere (baby->teen, GDD/PROTOTIPO-2.md punto 1; ora anche
  // teen->adulto, P3 scheletro): chiamata da boot/render come
  // controllaSonnoScaduto/controllaAllenamentoScaduto (stesso pattern idempotente). Se scatta,
  // cambia stadio E prende il controllo mostrando la schermata dedicata (ritorna true, cosi' i
  // chiamanti sanno di non proseguire col rendering normale). PETQ.pet.controllaEvoluzione
  // gestisce entrambe le transizioni internamente: qui non serve distinguerle.
  function controllaEvoluzioneScaduta() {
    if (!currentState || !currentState.pet || !PETQ.pet || !PETQ.pet.controllaEvoluzione) return false;
    // Allineata a controllaCartaPendente (mancavano passeggiata/gioco: senza questi due, l'annuncio
    // di evoluzione poteva interrompere una passeggiata o una sessione di gioco in corso — non si
    // perde nulla, il pet continua l'attivita', e' solo un'interruzione VISIVA). Sicuro rinviare:
    // PETQ.pet.controllaEvoluzione (pet.js) e' una funzione pura di pet.giorniVita/pet.stadio, che
    // NON avanzano per effetto di gioco/passeggiata (avanzano in care.dailyLogin al nuovo giorno) —
    // finche' non chiamiamo controllaEvoluzione qui sotto nessuna mutazione avviene, quindi rinviare
    // la CHIAMATA (la guardia sta prima di essa) non fa perdere l'evoluzione: al prossimo render,
    // finita l'attivita', giorniVita sara' lo stesso valore maturo e l'evoluzione scattera' identica.
    if (currentState.missione || currentState.sonno || currentState.allenamento ||
        currentState.passeggiata || currentState.gioco) return false;
    // La cartolina di esito (mostraEsito, id 'petq-esito') e' l'UNICA schermata a tutto schermo
    // che non aveva un marcatore: senza questa guardia, un'evoluzione maturata PROPRIO mentre il
    // giocatore la sta leggendo la sostituirebbe in silenzio (v. commento su wrap.id in
    // mostraEsito). Rinviare qui e' sicuro perche' PETQ.pet.controllaEvoluzione non e' ancora
    // stato chiamato: nessuna mutazione a pet.stadio e' avvenuta, quindi al prossimo giro di
    // render (quando la cartolina non c'e' piu') l'evoluzione scatta esattamente come se non
    // fosse mai stata rinviata.
    if (document.getElementById('petq-schermo-esito')) return false;
    // NUOVO: l'annuncio di evoluzione stesso (mostraEvoluzione, id 'petq-schermo-evoluzione') era
    // rimasto per anni l'UNICA schermata a tutto schermo senza un marcatore proprio — se restava a
    // video (giocatore che non preme "Continua") e nel frattempo maturava ANCHE lo stadio
    // successivo, questa funzione richiamava PETQ.pet.controllaEvoluzione una seconda volta e
    // mostraEvoluzione la sostituiva sotto le dita, perdendo l'annuncio e il talento appena letti.
    // Rinviare qui e' sicuro per lo STESSO motivo del controllo sopra: siamo PRIMA della chiamata
    // a PETQ.pet.controllaEvoluzione, quindi pet.stadio non e' stato ancora toccato — nessuna
    // mutazione avvenuta, nessuna evoluzione persa. Al prossimo giro di render, quando l'annuncio
    // precedente sara' stato chiuso (bottone "Continua"), la maturazione verra' rilevata esattamente
    // come se non fosse mai stata rinviata.
    if (document.getElementById('petq-schermo-evoluzione')) return false;
    // Sequenza di schiusa (Round 5): stesso principio, v. commento sopra sequenzaSchiusa — questo
    // ramo non e' comunque raggiungibile durante la cerimonia (currentState.pet e' null finche'
    // non finisce), ma la guardia resta per coerenza col resto del quartetto e per sicurezza
    // futura.
    if (document.getElementById('petq-schiusa')) return false;
    var evoluto = PETQ.pet.controllaEvoluzione(currentState.pet);
    if (!evoluto) return false;
    PETQ.save.save(currentState);
    mostraEvoluzione(currentState);
    return true;
  }

  // ==================== LE QUATTRO PORTE (Batch B: Dilemmi + Lavori) ====================
  // Il motore vive in PETQ.porte (porte.js): qui SOLO disegno, una schermata di scelta RIUSABILE
  // per tutte e 4 (pattern copiato da mostraTeenIntro sopra). Titolo e testo di ambientazione sono
  // stringhe NUOVE scritte qui (non esistono in porte.js, che non disegna nulla): le ETICHETTE
  // delle opzioni e il messaggio di conferma sono invece CONTENUTO che arriva da porte.js (e da
  // lavoro.js per lavoretto/carriera) — non li ricopiamo mai a mano, li leggiamo da
  // opzioniPorta()/scegli() e li passiamo da traduci() qui (scegli() ritorna il testo grezzo in
  // italiano, non ancora tradotto: opzioniPorta lo traduce gia' da sola, ma un traduci() in piu' e'
  // idempotente e non fa mai danno — v. nota nel brief).
  var PORTA_TITOLO = {
    corso: 'Il Corso Pomeridiano',
    lavoretto: 'Il Lavoretto Serale',
    carriera: 'La Carriera',
    svolta: 'La Svolta'
  };
  var PORTA_TESTO = {
    corso: 'La scuola dei cuccioli apre i corsi pomeridiani. Torna a casa col volantino e ti guarda con gli occhioni: puoi sceglierne uno solo.',
    lavoretto: 'È cresciuto: vuole i suoi soldi. Sul giornale ci sono quattro annunci. Ne sceglie uno per tutta la run.',
    carriera: 'Il capo lo convoca: "Sei cresciuto. Due strade."',
    svolta: 'Sulla porta di casa, due volantini. Il pet li guarda. Poi guarda te.'
  };

  function mostraPorta(state, idPorta) {
    // Guardia difensiva ANCHE qui (non solo nel chiamante automatico controllaPortaPendente):
    // questa schermata non ha un bottone "indietro"/"più tardi" (le porte si scelgono, non si
    // rimandano), quindi con zero opzioni sarebbe un VICOLO CIECO — es. i bottoni debug sotto
    // chiamano mostraPorta direttamente "ignorando stadio e giorno" e potrebbero beccare la
    // Carriera prima che il pet abbia mai scelto un lavoretto. Meglio tornare alla casa.
    var opzioni = (PETQ.porte && PETQ.porte.opzioniPorta) ? PETQ.porte.opzioniPorta(state, idPorta) : [];
    if (!opzioni || opzioni.length === 0) {
      console.warn('PETQ.ui: porta "' + idPorta + '" senza opzioni, nessuna schermata da mostrare');
      mostraCasa(state);
      return;
    }

    fermaIdle();
    puliziaEffetto();
    currentState = state;

    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-esito');
    // MARCATORE, e non e' un dettaglio: e' quello che impedisce al ciclo di render di rimontare
    // questa schermata ogni 30 secondi (v. controllaPortaPendente). Stesso meccanismo con cui
    // render() protegge la schermata dell'addio (.petq-addio) e quella del pet partito.
    wrap.id = 'petq-porta';
    wrap.appendChild(el('h1', 'petq-title', traduci(PORTA_TITOLO[idPorta] || 'Una porta')));

    // Pet col petLike vero, stesso canvas quadrato di mostraTeenIntro/mostraNascita (sprites.draw
    // scala sulla larghezza: su un canvas non quadrato il pet verrebbe tagliato).
    var cart = document.createElement('canvas');
    cart.width = PET_SIZE * 6;
    cart.height = PET_SIZE * 6;
    cart.className = 'petq-sprite-grande';
    wrap.appendChild(cart);
    PETQ.sprites.draw(cart, petLikeDaState(state), { frame: 0 });

    wrap.appendChild(el('p', 'petq-esito-testo', traduci(PORTA_TESTO[idPorta] || '')));

    var box = el('div', 'petq-esito-rewards');
    for (var i = 0; i < opzioni.length; i++) {
      (function (opz) {
        var b = el('button', 'petq-btn petq-btn-primario', traduci(opz.etichetta));
        b.addEventListener('click', function () {
          var r = PETQ.porte.scegli(state, idPorta, opz.id);
          PETQ.save.save(state);
          mostraCasa(state);
          if (typeof mostraToast === 'function') {
            mostraToast(r.ok ? (traduci('Hai scelto: ') + traduci(r.msg)) : traduci(r.msg));
          }
        });
        box.appendChild(b);
      })(opzioni[i]);
    }
    wrap.appendChild(box);

    app.appendChild(wrap);
    montaDebugPanel();
  }

  /* ---------- CARTA DILEMMA (Batch B §3) ----------
   * Situazione + 2-3 bottoni, poi l'esito sulla STESSA schermata invece che in un toast: la carta
   * e' una scelta, e una scelta senza conseguenza vista non e' una scelta. Il tono e' sitcom e il
   * gioco non giudica mai moralmente — quindi si mostra COSA e' successo, non se hai fatto bene.
   *
   * Stesso marcatore-e-ritorno-anticipato delle porte (#petq-carta): il ciclo di render passa di
   * qui ogni 30 secondi e senza il marcatore rimonterebbe la schermata sotto le dita del
   * giocatore, azzerando anche la scelta a metA'. E' il bug v144, gia' ricreato una volta oggi
   * sulle porte: qui la guardia c'e' dalla prima riga.
   */
  function mostraCarta(state, carta) {
    if (!carta || !PETQ.carte) return;
    var opzioni = PETQ.carte.opzioniVisibili(state, carta);
    if (!opzioni.length) {
      console.warn('PETQ.ui: carta "' + carta.id + '" senza opzioni visibili, la salto');
      mostraCasa(state);
      return;
    }

    fermaIdle();
    puliziaEffetto();
    currentState = state;

    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-esito');
    wrap.id = 'petq-carta'; // v. commento sopra: e' cio' che impedisce il rimontaggio dal render
    wrap.appendChild(el('h1', 'petq-title', traduci(PETQ.carte.titoloCarta(state, carta))));

    var cart = document.createElement('canvas');
    cart.width = PET_SIZE * 6;
    cart.height = PET_SIZE * 6;
    cart.className = 'petq-sprite-grande';
    wrap.appendChild(cart);
    PETQ.sprites.draw(cart, petLikeDaState(state), { frame: 0 });

    wrap.appendChild(el('p', 'petq-esito-testo', traduci(carta.situazione)));

    var box = el('div', 'petq-esito-rewards');
    for (var i = 0; i < opzioni.length; i++) {
      (function (opz) {
        var b = el('button', 'petq-btn petq-btn-primario', traduci(opz.testo));
        b.addEventListener('click', function () {
          // Guardia doppio-tap: dopo la scelta il bottone e' staccato dal DOM ma un secondo tap
          // veloce puo' ancora far scattare il listener, e scegli() applicherebbe i token due volte.
          if (b.disabled) return;
          b.disabled = true;
          var r = PETQ.carte.scegli(state, opz.lettera);
          if (!r.ok) { mostraToast(r.msg); mostraCasa(state); return; }
          PETQ.save.save(state);
          mostraEsitoCarta(state, carta, r);
        });
        box.appendChild(b);
      })(opzioni[i]);
    }
    wrap.appendChild(box);

    app.appendChild(wrap);
    montaDebugPanel();
  }

  // L'esito: la coda della carta (la battuta di colore) piu' cosa e' cambiato davvero, riusando
  // formattaRewardOggetto/Token che il gioco usa gia' per le missioni — cosi' un token nuovo si
  // mostra bene qui senza toccare niente.
  function mostraEsitoCarta(state, carta, esito) {
    var app = getApp();
    app.innerHTML = '';
    var wrap = el('div', 'petq-screen petq-esito');
    wrap.id = 'petq-carta'; // resta marcata: il render non deve rimontare la carta sotto l'esito
    wrap.appendChild(el('h1', 'petq-title', traduci(PETQ.carte.titoloCarta(state, carta))));

    var cart = document.createElement('canvas');
    cart.width = PET_SIZE * 6;
    cart.height = PET_SIZE * 6;
    cart.className = 'petq-sprite-grande';
    wrap.appendChild(cart);
    PETQ.sprites.draw(cart, petLikeDaState(state), { frame: 0 });

    if (esito.coda) wrap.appendChild(el('p', 'petq-esito-testo', traduci(esito.coda)));

    var righe = [];
    for (var i = 0; i < (esito.rewards || []).length; i++) {
      // I FLAG non si mostrano: sono memoria narrativa interna (il REGISTRO FLAG del design), non
      // ricompense. formattaRewardOggetto non li conosce e stampava la parola "flag" nuda, che al
      // giocatore non dice niente e si legge come un difetto. Quello che il flag produce lo si
      // vede piu' avanti, nelle carte che lo consumano: e' proprio quello il suo mestiere.
      if (esito.rewards[i] && esito.rewards[i].tipo === 'flag') continue;
      var testo = formattaRewardOggetto(esito.rewards[i]);
      if (testo) righe.push(testo);
    }
    if (righe.length) {
      wrap.appendChild(el('div', 'petq-hint', righe.join(' · ')));
    } else {
      // Un esito puo' essere "non succede niente" (il trattino lungo nel file): dirlo e' meglio di
      // una schermata muta, che si legge come un bug.
      wrap.appendChild(el('div', 'petq-hint', traduci('Non succede niente. Capita.')));
    }

    var b = el('button', 'petq-btn petq-btn-primario', traduci('Continua'));
    b.addEventListener('click', function () { mostraCasa(state); });
    wrap.appendChild(b);

    app.appendChild(wrap);
    montaDebugPanel();
  }

  function controllaCartaPendente() {
    if (!currentState || !currentState.pet || !PETQ.carte || !PETQ.carte.cartaDiOggi) return false;
    // Mai durante qualcosa in corso: una carta che interrompe una missione o il sonno sarebbe un
    // dispetto, non un dilemma.
    if (currentState.missione || currentState.sonno || currentState.allenamento ||
        currentState.passeggiata || currentState.gioco) return false;
    // Stessa guardia di controllaEvoluzioneScaduta/controllaEventoValigia/controllaPortaPendente
    // (v. commenti li' e su wrap.id in mostraEsito): non rimontare la carta sopra la cartolina di
    // esito. Sicuro perche' cartaDiOggi estrae la carta del giorno UNA volta (memorizzata in
    // PETQ.carte, v. carte.js) e da li' in poi la ririchiama identica finche' non e' risolta:
    // rinviare la chiamata qui non fa perdere l'estrazione ne' la carta, solo la mostra piu' tardi.
    if (document.getElementById('petq-schermo-esito')) return false;
    // Stessa guardia anche per l'annuncio di evoluzione (mostraEvoluzione, id
    // 'petq-schermo-evoluzione', v. controllaEvoluzioneScaduta/controllaPortaPendente): mancava qui,
    // e senza di essa la Carta del giorno poteva scavalcare l'annuncio "sei diventato TEEN/ADULTO"
    // ancora a video, sostituendolo in silenzio prima che il giocatore lo leggesse.
    if (document.getElementById('petq-schermo-evoluzione')) return false;
    // Sequenza di schiusa (Round 5): stesso principio (v. commento sopra sequenzaSchiusa).
    if (document.getElementById('petq-schiusa')) return false;
    var carta = PETQ.carte.cartaDiOggi(currentState);
    if (!carta) return false;
    if (document.getElementById('petq-carta')) return true; // gia' a schermo: NON rimontare
    mostraCarta(currentState, carta);
    return true;
  }

  /* controllaPortaPendente: stesso pattern idempotente di controllaEvoluzioneScaduta/
   * controllaEventoValigia, chiamata da boot/render/tick. NON usiamo NESSUNA variabile di modulo
   * per "gia' mostrata in questa sessione" (e' esattamente il bug "Da teen il tempo si ferma",
   * v144: una guardia di sessione non persistita si ri-innesca ad ogni riavvio e, se rimontasse la
   * schermata ad ogni giro di render, distruggerebbe #petq-casa fermando l'orologio). Qui non
   * serve: PETQ.porte.porteDaMostrare legge SOLO lo stato salvato (state.porte.fatte) e
   * porte.scegli() scrive la' la scelta appena fatta, quindi una volta scelta la porta non torna
   * MAI piu' pendente — e se non e' pendente questa funzione ritorna false e non tocca il DOM. */
  function controllaPortaPendente() {
    if (!currentState || !currentState.pet || !PETQ.porte || !PETQ.porte.porteDaMostrare) return false;
    // Allineata a controllaCartaPendente/controllaEvoluzioneScaduta (mancavano passeggiata/gioco):
    // non si perde nulla (porteDaMostrare, v. commento due righe sotto, e' un confronto puro senza
    // scrittura), e' solo un'interruzione visiva evitata su un'attivita' in corso.
    if (currentState.missione || currentState.sonno || currentState.allenamento ||
        currentState.passeggiata || currentState.gioco) return false;
    // Stessa guardia di controllaEvoluzioneScaduta/controllaEventoValigia (v. commenti li' e su
    // wrap.id in mostraEsito): non rimontare la porta sopra la cartolina di esito. Sicuro perche'
    // porteDaMostrare e' un puro confronto su state.pet.giorniVita/state.porte.fatte (nessuna
    // scrittura): rinviare non consuma nulla, la porta restera' pendente finche' il giocatore non
    // la SCEGLIE davvero (v. commento esteso piu' sotto sul perche' qui non si puo' fare altrimenti).
    if (document.getElementById('petq-schermo-esito')) return false;
    // Stessa idea per l'annuncio di evoluzione (mostraEvoluzione, id 'petq-schermo-evoluzione',
    // v. controllaEvoluzioneScaduta): PETQ.porte.porteDaMostrare ora include anche la Carriera
    // (v. porte.js), che diventa pendente NEL MOMENTO STESSO in cui pet.stadio passa ad 'adulto'
    // — cioe' PRIMA che il giocatore prema "Continua" sull'annuncio "sei diventato ADULTO". Senza
    // questa guardia il primo tick dopo l'evoluzione sostituirebbe quell'annuncio col foglio della
    // Carriera in silenzio (la doppia-proposta di cui avvisa il commento in porte.js). Rinviare
    // qui e' sicuro: la Carriera resta pendente (nessuna scrittura), e il bottone "Continua" la
    // propone gia' da solo appena l'annuncio si chiude (v. mostraEvoluzione) — o comunque questo
    // elenco la riprende al tick successivo se "Continua" non arriva mai.
    if (document.getElementById('petq-schermo-evoluzione')) return false;
    // Sequenza di schiusa (Round 5): stesso principio (v. commento sopra sequenzaSchiusa).
    if (document.getElementById('petq-schiusa')) return false;
    // Mancava la guardia sulla Carta del giorno (mostraCarta, id 'petq-carta', v.
    // controllaCartaPendente): senza di essa una Porta pendente poteva sostituire in silenzio la
    // schermata di un Dilemma che il giocatore sta leggendo, esattamente come i due casi sopra.
    // Rinviare qui e' sicuro per lo stesso motivo: PETQ.porte.porteDaMostrare non scrive nulla, la
    // porta resta pendente finche' il giocatore non la SCEGLIE davvero, e la Carta stessa richiama
    // questa lista di controlli subito dopo (v. render()/boot() sotto) cosi' la porta si propone da
    // sola al tick successivo, appena la Carta si chiude. NIENTE ciclo: controllaCartaPendente non
    // ha (e non deve avere) la guardia opposta su 'petq-porta', quindi non puo' rinviare a sua
    // volta alla Porta — se rinviassero a vicenda nessuna delle due comparirebbe mai.
    if (document.getElementById('petq-carta')) return false;
    var idPorta = PETQ.porte.porteDaMostrare(currentState);
    if (!idPorta) return false;

    /* SE LA PORTA E' GIA' A SCHERMO, NON RIMONTARLA — e ritorna true comunque, cosi' il render si
     * ferma qui e non prova ad aggiornare un HUD che in questo momento non esiste.
     *
     * Senza questo controllo si ricreava esattamente il bug di luglio ("da teen il tempo si
     * ferma", v144): porteDaMostrare continua a restituire la stessa porta finche' il giocatore
     * non SCEGLIE — la scelta e' l'unica cosa che scrive state.porte.fatte — quindi ogni battito
     * da 30 secondi rifaceva app.innerHTML='' e ridisegnava tutto. A schermo: la schermata che si
     * azzera sotto le dita ogni mezzo minuto.
     * Le altre schermate del gioco non hanno il problema perche' qualcosa cambia PRIMA di
     * mostrarle (l'evoluzione cambia lo stadio, la valigia azzera state.eventoValigia). Qui non
     * si puo': segnare la porta come "fatta" prima della scelta significherebbe che basta un tick
     * per perdere la scelta. Quindi si guarda il DOM, come fa render() con la schermata dell'addio. */
    if (document.getElementById('petq-porta')) return true;

    var opzioni = PETQ.porte.opzioniPorta(currentState, idPorta);
    if (!opzioni || opzioni.length === 0) {
      // Difensivo (es. PETQ.lavoro non caricato): niente schermata vuota. Non segna nulla come
      // fatto, quindi ritentera' al prossimo giro senza mai bloccare o congelare nulla nel frattempo.
      console.warn('PETQ.ui: porta "' + idPorta + '" pendente ma senza opzioni, salto');
      return false;
    }
    mostraPorta(currentState, idPorta);
    return true;
  }

  // ==================== POPUP UNA-TANTUM SUPPORTER PACK (ago 2026) ====================
  // Diverso da carta/porta/schiusa: NON e' uno "schermo" che sostituisce la casa (mai uno stato di
  // gioco pendente da risolvere), e' un OVERLAY promozionale su document.body, fuori da #app —
  // cosi' un giro di render() (che fa spesso app.innerHTML='' e ridisegna, v. mostraCasa) non lo
  // smonta sotto le dita mentre il giocatore lo sta leggendo. Per lo stesso motivo non ha bisogno
  // del pattern "ritorna true -> il chiamante fa return": non prende il controllo di nulla, quindi
  // il chiamante prosegue sempre.
  //
  // Trigger (fondatore, numeri suoi): giornoGioco>=3, MAI se currentState.supporter e' gia' true,
  // MAI due volte nella vita del salvataggio (currentState.popupSostieniVisto, v. statoDiPartenza/
  // save.js migraState/LISTA_BIANCA_CASA — una-tantum ASSOLUTA, sopravvive al ribaltamento casa).
  // Esce anche se e' montata QUALSIASI schermata a tutto schermo — STESSA lista di marcatori delle
  // altre guardie pendenti qui sopra (carta/porta/schiusa/esito/nascita/intro/addio/pianeta) — o se
  // il pet e' occupato in un'animazione (animazioneInCorso): un popup promozionale sopra un
  // dialogo/cerimonia/animazione sarebbe un dispetto, non un invito gentile.
  function controllaPopupSostieni() {
    if (!currentState || !currentState.pet) return;
    if (currentState.popupSostieniVisto) return;
    if (currentState.supporter === true) return;
    if ((currentState.giornoGioco || 0) < 3) return;
    if (animazioneInCorso) return;
    if (document.getElementById('petq-carta')) return;
    if (document.getElementById('petq-porta')) return;
    if (document.getElementById('petq-schiusa')) return;
    if (document.getElementById('petq-schermo-esito')) return;
    if (document.querySelector('.petq-nascita')) return;
    if (document.querySelector('.petq-intro')) return;
    if (document.querySelector('.petq-addio')) return;
    if (document.getElementById('petq-pianeta-overlay')) return;
    if (document.getElementById('petq-popup-sostieni')) return; // gia' a schermo: non rimontare
    mostraPopupSostieni();
  }

  // Segna il popup come visto + salva PRIMA di chiudere (in ENTRAMBI i bottoni, v.
  // mostraPopupSostieni sotto): una-tantum vuol dire che anche un "No, grazie" seguito da una
  // chiusura brusca dell'app non deve far ricomparire il popup al prossimo avvio.
  function chiudiPopupSostieni() {
    if (currentState) currentState.popupSostieniVisto = true;
    PETQ.save.save(currentState);
    var overlay = document.getElementById('petq-popup-sostieni');
    if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
  }

  // Overlay fisso su document.body (NON dentro #app, v. commento su controllaPopupSostieni sopra).
  // Stile "pannello centrato" come carta/porta/scheda (scrim scuro + pannello, v. style.css
  // .petq-popup-sostieni), contenuto: titolo, due frasi gentili (tono di casa, MAI pressione — il
  // gioco e' gratis e resta gratis), lo stesso canvas dei 4 companion della card hero del negozio
  // (v. disegnaCompanionPackHero), due bottoni.
  function mostraPopupSostieni() {
    var overlay = el('div', 'petq-popup-sostieni');
    overlay.id = 'petq-popup-sostieni';

    var pannello = el('div', 'petq-popup-sostieni-pannello');
    pannello.appendChild(el('div', 'petq-popup-sostieni-titolo', traduci('Ti sta piacendo?')));
    pannello.appendChild(el('p', 'petq-popup-sostieni-testo', traduci('Hatch a Legend è gratis e lo resta.')));
    pannello.appendChild(el('p', 'petq-popup-sostieni-testo',
      traduci('Se ti va di sostenerlo, il Supporter Pack porta quattro aiutanti e i cosmetici esclusivi.')));

    var cvPopup = document.createElement('canvas');
    cvPopup.width = 128;
    cvPopup.height = 40;
    cvPopup.className = 'petq-pack-hero-canvas';
    disegnaCompanionPackHero(cvPopup);
    pannello.appendChild(cvPopup);

    var btns = el('div', 'petq-popup-sostieni-btns');

    var btnVedi = el('button', 'petq-btn petq-btn-primario', traduci('Vedi il pack'));
    btnVedi.addEventListener('click', function () {
      chiudiPopupSostieni();
      apriNegozioSuSezione('sostieni');
    });
    btns.appendChild(btnVedi);

    var btnNo = el('button', 'petq-btn petq-btn-mini', traduci('No, grazie'));
    btnNo.addEventListener('click', function () { chiudiPopupSostieni(); });
    btns.appendChild(btnNo);

    pannello.appendChild(btns);
    overlay.appendChild(pannello);
    document.body.appendChild(overlay);
  }

  // Apre la casa sulla tab Missioni col Negozio gia' aperto sulla sezione indicata — STESSO
  // meccanismo dei bottoni "Nella sezione Sostieni" gia' in negozio (v. rigaColoreNegozio e
  // gemelle: shopSezione='sostieni' + re-render), esteso con lo switch di tab perche' qui si parte
  // da FUORI il negozio (il popup puo' comparire mentre il giocatore e' su Cucina/Bagno/ecc.).
  // Stessa sequenza del click su una tab (v. mostraCasa sopra): resetta le preferenze di sessione
  // della mappa (missioniMappaCentrata/mappaVistaCitta) cosi' la tab Missioni si apre pulita.
  function apriNegozioSuSezione(sezione) {
    if (!currentState) return;
    currentStanza = 'missioni';
    missioniMappaCentrata = false;
    mappaVistaCitta = false;
    negozioSelezionato = true;
    shopSezione = sezione;
    vendiConferma = null;
    missioneSelezionata = null;
    aggiornaModalitaHud();
    renderStanza();
  }

  // Chiude la scheda (se aperta) e salta al Negozio sulla sezione indicata — STESSA
  // apriNegozioSuSezione sopra, usata dai selettori cosmetici BLOCCATI in mostraScheda
  // (Colore/Stanze/Cornice, sotto) per le voci comprabili (tipo 'negozio'/'supporter'): tap su un
  // quadratino spento porta DIRETTAMENTE al negozio nella sezione giusta invece del solo toast
  // esplicativo (richiesta fondatore 24 ago 2026). La scheda va rimossa PRIMA, non dopo: renderStanza
  // (dentro apriNegozioSuSezione) ridisegna la casa sotto, e un overlay scheda lasciato aperto sopra
  // il negozio risulterebbe orfano (nessun listener lo richiude piu', la casa aperta sotto ma invisibile).
  function chiudiSchedaEApriNegozio(sezione) {
    var schedaOv = document.getElementById('petq-scheda-overlay');
    if (schedaOv) schedaOv.remove();
    apriNegozioSuSezione(sezione);
  }

  // M17 "Pimp My Pet" pendente (recovery, STORICO): se il giocatore ricaricava/chiudeva la pagina
  // SULLA schermata M17 (teenIntroFatto ancora false), al boot si tornava in casa e senza questo
  // check la scelta "1 volta all'evoluzione" andrebbe persa per sempre. Gate su petq-casa: la
  // riproponeva solo dalla casa (mai sopra evoluzione/M17 stessa/altre schermate a pieno schermo).
  // NON CHIAMATA da nessuno: gia' senza l'unico chiamante (render()) da v144, perche' il
  // rimontaggio automatico di M17 sopra la casa faceva sparire HUD e orologio. AGGIORNAMENTO 28
  // lug 2026: la feature "Pimp My Pet" e' stata RIMOSSA su decisione del fondatore (v. commento
  // sopra mostraTeenIntro) — non c'e' piu' nessun pin/recovery da riproporre; questa funzione
  // resta nel file senza chiamanti solo per coerenza con mostraTeenIntro/teenIntroRimandato.
  function controllaTeenIntroPendente() {
    if (teenIntroRimandato) return false; // "Piu' tardi" premuto: non riproporre in questa sessione
    if (!currentState || !currentState.pet) return false;
    if (currentState.missione || currentState.sonno || currentState.allenamento) return false;
    var pet = currentState.pet;
    if (pet.stadio !== 'teen' || pet.teenIntroFatto) return false;
    if (!document.getElementById('petq-casa')) return false;
    // non montare M17 SOTTO un overlay aperto (scheda/pianeta stanno sopra petq-casa nel DOM)
    if (document.getElementById('petq-scheda-overlay') || document.getElementById('petq-pianeta-overlay')) return false;
    mostraTeenIntro(currentState);
    return true;
  }

  // ==================== VALIGIA / PARTENZA (PROTOTIPO 2, Blocco 2) ====================
  // Legge state.eventoValigia (impostato da care.dailyLogin via pet.valutaValigiaNuovoGiorno) e
  // reagisce: 'partenza' -> schermata addio (prende il controllo, ritorna true); 'valigia' ->
  // notifica in-gioco + battuta (resta in casa, ritorna false cosi' il rendering prosegue e la
  // valigetta appare in scena); 'rientro' -> battuta rientro (resta in casa, false). Consuma
  // sempre l'evento (lo azzera) cosi' non si ripete. Stesso pattern idempotente di
  // controllaEvoluzioneScaduta: chiamata da boot/render/tick e dopo il "Nuovo giorno" debug.
  // Talenti (P3 BATCH 4, "montaggio=1/settimana", Montaggio alla Rocky): consuma
  // state.montaggioEvento (impostato da care.dailyLogin) mostrando il toast dedicato. Chiamata
  // PRIMA del check valigia sotto (return separato, indipendente: i due eventi non si escludono
  // a vicenda) cosi' un "Nuovo giorno" che fa scattare ENTRAMBI gli eventi nella stessa chiamata
  // non ne perde nessuno — il montaggio non prende il controllo dello schermo (a differenza
  // della partenza), quindi non ritorna mai true: il chiamante prosegue sempre al resto.
  function controllaMontaggioEvento() {
    if (!currentState || !currentState.montaggioEvento) return;
    currentState.montaggioEvento = false;
    PETQ.save.save(currentState);
    mostraToast(traduci('🎬 MONTAGGIO! +2 a tutte le stat!'));
  }

  // CASA ACCOGLIENTE (fase giocattoli): care.dailyLogin regala al pet la Felicita' passiva degli
  // arredi piazzati (cap 10) e lascia la quantita in state.loginFelicitaCasa. Qui la si mostra e
  // la si AZZERA (stesso pattern consuma-una-volta di controllaMontaggioEvento sopra). Senza
  // questo il bonus arrivava in silenzio e il giocatore non collegava mai la casa arredata al
  // morale del pet. Chiamata PRIMA del montaggio cosi', nel raro giorno in cui scattano entrambi,
  // il toast che resta a schermo e' quello piu' raro/importante.
  function controllaFelicitaCasaLogin() {
    if (!currentState || !currentState.loginFelicitaCasa) return;
    var quanta = currentState.loginFelicitaCasa;
    currentState.loginFelicitaCasa = 0;
    PETQ.save.save(currentState);
    mostraToast(traduci('🏠 Casa accogliente: Felicità +') + quanta);
  }

  // Companion del Supporter Pack (batch companion, 29 lug 2026): nomi -> etichetta italiana usata
  // nel messaggio combinato sotto (i nomi passano comunque da traduci(), qui serve solo a
  // scegliere il frammento giusto in base al tipo di record che arriva da
  // care.applicaEffettiCompanion).
  var NOME_COMPANION_TIPO = {
    topoChef: 'Topo Chef',
    lumaca: 'Lumaca delle Pulizie',
    piccione: 'Piccione Postino',
    criceto: 'Criceto Dinamo'
  };

  // care.dailyLogin applica gli effetti quotidiani dei companion PIAZZATI e li lascia in
  // state.companionEffettiGiorno (dailyLogin ritorna gia' solo il bonus monete del login, stesso
  // schema di state.loginFelicitaCasa/state.montaggioEvento qui sopra). Consumati QUI (azzerati
  // subito) e mostrati con mostraAvviso invece del toast in basso: con FINO A 4 companion nello
  // stesso giorno un solo mostraToast (che SOVRASCRIVE, non accoda — v. mostraToast) ne
  // mostrerebbe solo l'ultimo, e "il giocatore DEVE accorgersene" di tutti — stesso canale gia'
  // usato per il rientro passeggiata, introdotto per l'identica ragione di visibilita'. Richiamata
  // da controllaEventoValigia (sotto, stesso punto di aggancio di Casa Accogliente/Montaggio:
  // boot + ogni render tick + debug "Nuovo giorno") e anche dal bottone debug "Companion: effetto
  // ora", che riusa questa stessa funzione per mostrare esattamente il messaggio che vedrebbe un
  // giocatore vero.
  function controllaCompanionEffettiLogin() {
    if (!currentState || !Array.isArray(currentState.companionEffettiGiorno) || currentState.companionEffettiGiorno.length === 0) return;
    var effetti = currentState.companionEffettiGiorno;
    currentState.companionEffettiGiorno = null;
    PETQ.save.save(currentState);

    var frasi = [];
    for (var i = 0; i < effetti.length; i++) {
      var e = effetti[i];
      var nome = traduci(NOME_COMPANION_TIPO[e.tipo] || '');
      if (e.tipo === 'topoChef') {
        frasi.push(nome + traduci(' ha rifornito la dispensa: +1 ') + traduci(e.cibo) + '.');
      } else if (e.tipo === 'lumaca') {
        frasi.push(nome + traduci(' ha ripulito tutta la casa.'));
      } else if (e.tipo === 'piccione') {
        frasi.push(nome + traduci(' ha portato +') + e.monete + traduci(' monete.'));
      } else if (e.tipo === 'criceto') {
        frasi.push(nome + traduci(' ha caricato le pile: +') + e.energia + traduci(' Energia.'));
      }
    }
    if (frasi.length > 0) mostraAvviso(frasi.join(' '));
  }

  // TURNO NOTTURNO (Batch B "Lavori", agganciato il 3 ago 2026): care.risolviTurnoLavoroNotturno
  // riscuote il turno al cambio giorno e lascia l'esito gia' TRADOTTO in state.lavoroEsitoGiorno.
  // Qui lo si mostra e lo si AZZERA — stesso pattern consuma-una-volta dei companion sopra.
  // mostraAvviso e non mostraToast per lo stesso motivo dei companion: al cambio giorno possono
  // arrivare insieme login, casa accogliente, companion e turno, e il toast si sovrascrive.
  // Prima di questo aggancio il giocatore sceglieva un lavoretto e non vedeva MAI un ritorno.
  function controllaLavoroEsitoLogin() {
    if (!currentState || !currentState.lavoroEsitoGiorno) return;
    var r = currentState.lavoroEsitoGiorno;
    currentState.lavoroEsitoGiorno = null;
    PETQ.save.save(currentState);
    var testo = r.messaggio || '';
    var extra = Array.isArray(r.extra) ? r.extra : [];
    for (var i = 0; i < extra.length; i++) {
      var f = formattaRewardOggetto(extra[i]);
      if (f) testo += ' ' + f;
    }
    if (testo) mostraAvviso(testo);
  }

  function controllaEventoValigia() {
    if (!currentState) return false;
    // Stessa guardia di controllaEvoluzioneScaduta (v. commento li' e su wrap.id in mostraEsito):
    // la cartolina di esito missione non deve farsi rimontare sopra da un evento maturato mentre
    // e' a video. DEVE stare PRIMA di controllaFelicitaCasaLogin/controllaMontaggioEvento/
    // controllaCompanionEffettiLogin qui sotto e prima della lettura di state.eventoValigia: sono
    // tutti flag "consumati" (azzerati) al primo giro utile, non ri-derivati da zero — se li
    // leggessimo ora e basta rinviare la SCHERMATA senza rinviare anche il consumo, l'evento
    // sparirebbe senza mai essere mostrato. Rinviando l'intera funzione, invece, i flag restano
    // esattamente come sono (li ha scritti care.dailyLogin, non li tocca nessun altro) e vengono
    // consumati e mostrati al primo render utile dopo che la cartolina si e' chiusa.
    if (document.getElementById('petq-schermo-esito')) return false;
    // Stessa guardia anche per l'annuncio di EVOLUZIONE (marcatore aggiunto il 3 ago 2026): piu'
    // sotto questa funzione puo' chiamare mostraAddio, che svuota #app — senza il rinvio, la
    // lettera d'addio sostituirebbe in silenzio il "sei diventato TEEN/ADULTO" prima che il
    // giocatore lo legga. Vale lo stesso ragionamento sui flag consumati spiegato sopra: si rinvia
    // l'INTERA funzione, cosi' nessun flag viene letto-e-azzerato senza essere mostrato.
    if (document.getElementById('petq-schermo-evoluzione')) return false;
    // Sequenza di schiusa (Round 5): stesso principio (v. commento sopra sequenzaSchiusa).
    if (document.getElementById('petq-schiusa')) return false;
    controllaFelicitaCasaLogin();
    controllaMontaggioEvento();
    controllaCompanionEffettiLogin();
    controllaLavoroEsitoLogin();
    var ev = currentState.eventoValigia;
    if (!ev) return false;
    currentState.eventoValigia = null;
    PETQ.save.save(currentState);

    if (ev.tipo === 'partenza') {
      mostraAddio(currentState);
      return true;
    }
    if (ev.tipo === 'valigia') {
      // Entrato in fase valigia: notifica in-gioco (usa una battuta 'notifica_valigia' come
      // avviso) + battuta 'valigia' nel balloon. La valigetta in scena la disegna
      // disegnaStanzaEPet (legge state.valigia). Se la casa non e' ancora montata (evento al
      // boot), montiamo la casa prima cosi' il balloon/scena esistono.
      if (!document.getElementById('petq-casa')) mostraCasa(currentState);
      if (currentState.pet) {
        var avviso = PETQ.dialog.say(currentState.pet, 'notifica_valigia', currentState);
        mostraToast(avviso);
        disegnaStanzaEPet(currentState);
        renderAzioni();
        mostraBalloon(PETQ.dialog.say(currentState.pet, 'valigia', currentState));
      }
      return false;
    }
    if (ev.tipo === 'rientro') {
      if (!document.getElementById('petq-casa')) mostraCasa(currentState);
      if (currentState.pet) {
        disegnaStanzaEPet(currentState);
        renderAzioni();
        mostraBalloon(PETQ.dialog.say(currentState.pet, 'rientro', currentState));
      }
      return false;
    }
    return false;
  }

  // Flavor della partenza per razza (Blocco 2 / GDD "Ciclo di vita": l'alieno recuperato da una
  // navetta del suo pianeta, il robot da un drone verso il centro di manutenzione). Tinta + testo
  // (+ mini-sprite del mezzo) — niente scena elaborata, come da brief ("basta tinta + testo").
  var ADDIO_FLAVOR = {
    alieno: { titolo: traduci('È partito'), mezzo: traduci('La navetta del suo pianeta è scesa a riprenderlo.'), tinta: '#3a2f5f', mezzoTinta: '#8a6ff0' },
    robot: { titolo: traduci('È partito'), mezzo: traduci('Un drone di recupero lo ha portato al centro di manutenzione.'), tinta: '#2f3a4a', mezzoTinta: '#7fb0e0' }
  };

  // Schermata ADDIO dedicata: il pet parte davvero. Mostra la battuta 'addio' della personalita',
  // il flavor per razza (navetta/drone: tinta + testo + mini-sprite del mezzo) e un bottone che
  // porta alla schermata "pet partito" (casa senza pet, con "Fai ammenda"). Il pet e' GIA' stato
  // spostato in state.petPartito da pet.partePet (chiamata dentro valutaValigiaNuovoGiorno prima
  // di generare l'evento), quindi qui leggiamo state.petPartito per nome/razza/battuta.
  function mostraAddio(state) {
    fermaIdle();
    puliziaEffetto();
    currentState = state;
    var pet = state.petPartito || state.pet; // fallback difensivo
    if (!pet) { mostraPetPartito(state); return; }

    var flavor = ADDIO_FLAVOR[pet.razza] || ADDIO_FLAVOR.robot;

    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-addio');
    wrap.style.background = flavor.tinta;
    wrap.appendChild(el('h1', 'petq-title', flavor.titolo));

    var cart = document.createElement('canvas');
    cart.width = ROOM_W;
    cart.height = ROOM_H;
    cart.className = 'petq-cartolina';
    wrap.appendChild(cart);
    disegnaScenaAddio(cart, pet, flavor);

    wrap.appendChild(el('div', 'petq-hint', flavor.mezzo));

    var testoEl = el('p', 'petq-esito-testo', PETQ.dialog.say(pet, 'addio', state));
    wrap.appendChild(testoEl);

    var btn = el('button', 'petq-btn petq-btn-primario', traduci('Continua'));
    btn.addEventListener('click', function () { mostraPetPartito(currentState); });
    wrap.appendChild(btn);

    app.appendChild(wrap);
    montaDebugPanel();
  }

  // Scena addio: sfondo a tinta, il pet piccolo che se ne va + il "mezzo" (navetta/drone)
  // stilizzato sopra di lui. Volutamente semplice (mini-sprite = un blocchetto colorato col
  // tono del mezzo), come da brief.
  function disegnaScenaAddio(canvas, pet, flavor) {
    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.fillStyle = flavor.tinta;
    g.fillRect(0, 0, ROOM_W, ROOM_H);
    g.fillStyle = 'rgba(0,0,0,0.25)';
    g.fillRect(0, 50, ROOM_W, ROOM_H - 50);

    // pet piccolo, in basso al centro (leggendaId propagato: v. petLikeDaState per lo stesso motivo)
    var petLike = { razza: pet.razza, leggendaId: pet.leggendaId || null, sottorazza: pet.sottorazza, parts: pet.parts, stadio: pet.stadio || 'teen', corpo: 'normale', sporco: false };
    var pc = document.createElement('canvas');
    pc.width = PET_PX; pc.height = PET_PX;
    PETQ.sprites.draw(pc, petLike, { frame: 0 });
    g.drawImage(pc, Math.round((ROOM_W - PET_PX) / 2), 50 - PET_PX + 2);

    // mezzo (navetta alieno / drone robot): blocchetto stilizzato in alto, col tono del mezzo,
    // e un raggio di luce che scende verso il pet.
    g.fillStyle = flavor.mezzoTinta;
    g.fillRect(ROOM_W / 2 - 12, 6, 24, 8);
    g.fillRect(ROOM_W / 2 - 6, 4, 12, 3);
    g.fillStyle = 'rgba(255,255,255,0.18)';
    g.beginPath();
    g.moveTo(ROOM_W / 2 - 8, 14);
    g.lineTo(ROOM_W / 2 + 8, 14);
    g.lineTo(ROOM_W / 2 + 14, 46);
    g.lineTo(ROOM_W / 2 - 14, 46);
    g.closePath();
    g.fill();
  }

  // Schermata "PET PARTITO" arricchita (Blocco 4, versione semplice): il pet e' su un PIANETA/
  // STAZIONE (scena pixel PETQ.sprites.drawPianeta) e ha mandato una LETTERA (pannello "foglio"
  // stile diario, testo assemblato da componiLettera in voce di personalita'). Sotto, il bottone
  // "Fai ammenda (50 monete)" gia' esistente (riusa eseguiAmmenda). Overlay pieno (app.innerHTML)
  // come mostraAddio/mostraEvoluzione. La lettera e' assemblata UNA volta e salvata in
  // state.letteraPartito, cosi' resta stabile finche' il pet e' via (non ri-pesca ad ogni apertura).
  function mostraPetPartito(state) {
    fermaIdle();
    puliziaEffetto();
    currentState = state;
    var pet = state.petPartito;
    if (!pet) {
      // nessun pet partito e nessun pet in casa: stato incoerente, torna all'intro.
      if (state.pet) { mostraCasa(state); return; }
      mostraIntro();
      return;
    }

    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-partito');
    wrap.id = 'petq-pet-partito';
    var razza = pet.razza === 'robot' ? 'robot' : 'alieno';
    wrap.appendChild(el('h1', 'petq-title', razza === 'robot' ? traduci('Alla stazione') : traduci('Su un altro pianeta')));

    // SCENA PIANETA col pet partito
    var cart = document.createElement('canvas');
    cart.width = ROOM_W;
    cart.height = ROOM_H;
    cart.className = 'petq-cartolina';
    wrap.appendChild(cart);
    if (PETQ.sprites && PETQ.sprites.drawPianeta) {
      PETQ.sprites.drawPianeta(cart, pet, { razza: razza, corpo: pet.corpo });
    }

    wrap.appendChild(el('p', 'petq-esito-testo',
      (pet.nome || traduci('Il tuo pet')) + (razza === 'robot'
        ? traduci(' è al centro di manutenzione, in orbita. Ti ha scritto.')
        : traduci(' è tornato sul suo pianeta. Ti ha scritto.'))));

    // LETTERA: pannello "foglio" (stile diario). Testo assemblato una volta e salvato in
    // state.letteraPartito cosi' resta stabile finche' il pet e' via.
    var lettera = componiLettera(state);
    var foglio = el('div', 'petq-lettera');
    foglio.appendChild(el('h2', 'petq-lettera-titolo', traduci('Lettera da ') + (pet.nome || traduci('lui'))));
    for (var i = 0; i < lettera.length; i++) {
      foglio.appendChild(el('p', 'petq-lettera-riga', lettera[i]));
    }
    foglio.appendChild(el('p', 'petq-lettera-firma', '— ' + (pet.nome || traduci('il tuo pet'))));
    wrap.appendChild(foglio);

    var costo = (PETQ.pet && typeof PETQ.pet._costoAmmenda === 'number') ? PETQ.pet._costoAmmenda : 50;
    var haMonete = (state.coins || 0) >= costo;

    var info = el('p', 'petq-hint', traduci('Puoi fare ammenda: ') + costo + traduci(' monete per farlo tornare (Salute e Felicità a 50). Hai ') + (state.coins || 0) + traduci(' monete.'));
    wrap.appendChild(info);

    var btn = el('button', 'petq-btn petq-btn-primario', traduci('Fai ammenda (') + costo + traduci(' monete)'));
    if (!haMonete) {
      btn.disabled = true;
      btn.title = traduci('Monete insufficienti.');
    }
    btn.addEventListener('click', function () { eseguiAmmenda(); });
    wrap.appendChild(btn);

    // Uscita SEMPRE possibile (fix playtest 8 lug 2026: "senza monete si resta bloccati qui,
    // serve un tasto per iniziare un nuovo save"): ricominciare da capo cancella il salvataggio
    // e riparte dalla scelta dell'uovo. Azione PERMANENTE -> conferma a due tap (stesso pattern
    // della pensione). Il reload garantisce un boot pulito (nessuno stato residuo in memoria).
    var nuovoConferma = false;
    var nuovoBtn = el('button', 'petq-btn petq-btn-secondario', traduci('Lascialo andare — ricomincia da capo'));
    nuovoBtn.addEventListener('click', function () {
      if (!nuovoConferma) {
        nuovoConferma = true;
        nuovoBtn.textContent = traduci('Sicuro? Il salvataggio riparte da ZERO — ritocca per confermare');
        nuovoBtn.className = 'petq-btn petq-btn-conferma';
        return;
      }
      if (PETQ.save && PETQ.save.reset) PETQ.save.reset();
      window.location.reload();
    });
    wrap.appendChild(nuovoBtn);

    app.appendChild(wrap);
    montaDebugPanel();
  }

  // Assembla la LETTERA del pet partito (Blocco 4). Pesca 1-2 frammenti dal pool 'lettera' della
  // personalita' (fallback al pool 'addio' se 'lettera' e' vuoto), con gli slot riempiti come
  // ogni battuta. Assemblata UNA sola volta e memorizzata in state.letteraPartito: le aperture
  // successive (e un reload) mostrano la stessa lettera, non una nuova estrazione, finche' il pet
  // e' via. Azzerata dal recupero (faiAmmenda svuota petPartito -> eseguiAmmenda pulisce anche
  // letteraPartito). Ritorna un array di righe (>=1).
  function componiLettera(state) {
    var pet = state.petPartito;
    if (!pet) return [];
    // gia' assemblata per QUESTO pet partito: riusala stabile.
    if (state.letteraPartito && state.letteraPartito.righe && state.letteraPartito.righe.length) {
      return state.letteraPartito.righe;
    }

    var data = PETQ.content && PETQ.content.data;
    var personalita = pet.personalita || 'gentile';
    var pools = data && data.personalita && data.personalita[personalita];
    var pool = (pools && pools.lettera && pools.lettera.length) ? pools.lettera
             : (pools && pools.addio ? pools.addio : []);

    var righe = [];
    if (pool && pool.length) {
      // 1-2 frammenti distinti (2 se il pool ne ha almeno 2), riempiti degli slot.
      var quanti = pool.length >= 2 ? 2 : 1;
      var indici = [];
      var tentativi = 0;
      while (indici.length < quanti && tentativi < 20) {
        var k = Math.floor((PETQ.rng ? PETQ.rng.rand() : Math.random()) * pool.length);
        if (indici.indexOf(k) === -1) indici.push(k);
        tentativi++;
      }
      for (var j = 0; j < indici.length; j++) {
        righe.push(riempiSlotLettera(pool[indici[j]], pet, state));
      }
    }
    if (righe.length === 0) {
      // fallback estremo se non c'e' proprio nessun contenuto (contenuti non caricati)
      righe.push((pet.nome || traduci('Il tuo pet')) + traduci(' ti pensa dal pianeta. Torna a prenderlo.'));
    }

    state.letteraPartito = { personalita: personalita, righe: righe };
    if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
    return righe;
  }

  // Riempimento slot per la lettera. dialog.say gestisce gli slot internamente ma sceglie ANCHE
  // la battuta (e puo' deviare su 'parola'): qui abbiamo gia' scelto il frammento, quindi
  // riempiamo solo gli slot noti {nome}/{utente}/{parola} con lo stesso criterio di dialog.js.
  function riempiSlotLettera(testo, pet, state) {
    var nome = (pet && pet.nome) ? pet.nome : '...';
    var parola = 'boh';
    if (state && state.parole && state.parole.length > 0 && PETQ.rng) {
      parola = PETQ.rng.pick(state.parole) || 'boh';
    }
    return String(testo)
      .replace(/\{nome\}/g, nome)
      .replace(/\{utente\}/g, traduci('capo'))
      .replace(/\{parola\}/g, parola);
  }

  function eseguiAmmenda() {
    if (!currentState || !PETQ.pet || !PETQ.pet.faiAmmenda) return;
    var res = PETQ.pet.faiAmmenda(currentState);
    if (!res.ok) {
      mostraToast(res.msg);
      // aggiorna il pannello (magari le monete sono cambiate)
      mostraPetPartito(currentState);
      return;
    }
    // il pet e' tornato: la lettera dal pianeta non ha piu' senso, azzerala (cosi' una futura
    // partenza ne assembla una nuova e fresca).
    currentState.letteraPartito = null;
    PETQ.save.save(currentState);
    mostraToast(res.msg);
    // pet ripristinato: torna alla casa e mostra la battuta 'rientro'.
    mostraCasa(currentState);
    if (currentState.pet) mostraBalloon(PETQ.dialog.say(currentState.pet, 'rientro', currentState));
  }

  // ==================== PENSIONE (PROTOTIPO 2, GDD "### 2. Pensione" — versione base P2) ==========
  // Flusso: il bottone "Manda in pensione" nella scheda -> pet.mandaInPensione(state) (svuota il
  // pet in casa, lo mette in state.pensionati) -> schermata "Scegli il tuo nuovo pet" (Robot/
  // Alieno) -> nuovoPetInCasa(state, razza) crea un pet NUOVO nella STESSA casa (coins/arredi/
  // pensionati restano), applica l'EREDITA' (+1 stat firma per ogni pensionato, con cap) e torna
  // alla casa. La galleria "pianeta dei ritirati" (mostraPianetaRitirati) e' accessibile dalla
  // scheda. NON si usa avviaPartita (resetterebbe l'household).

  // EREDITA': ogni pensionato da' +1 alla SUA stat firma ai pet futuri, fino a questo CAP per stat.
  var EREDITA_CAP_PER_STAT = 2;

  // Avvia il RITIRO del pet: lo manda in pensione (svuota state.pet, casa VUOTA) e va al PIANETA
  // dei ritirati (mostraPianetaRitirati), NON piu' direttamente alla scelta razza. Dal Pianeta il
  // giocatore sceglie: "Riprendi" un pensionato (paga l'ammenda) OPPURE "Prendi un pet nuovo" (->
  // scelta razza -> casa fresca). Cosi' il ritiro non e' piu' irreversibile-e-basta.
  function avviaPensione(state) {
    if (!state || !state.pet || !PETQ.pet || !PETQ.pet.mandaInPensione) return;
    PETQ.pet.mandaInPensione(state);
    if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
    mostraPianetaRitirati(state);
  }

  // Schermata "Scegli il tuo nuovo pet" (Robot/Alieno). Non riusa mostraIntro/avviaPartita perche'
  // quelli creano uno stato FRESCO (perderemmo coins/arredi/pensionati): qui, al click, chiamiamo
  // nuovoPetInCasa(state, razza) che tiene l'household. Riusa lo stile delle uova dell'intro.
  function mostraSceltaNuovoPet(state, nomeRitirato) {
    fermaIdle();
    puliziaEffetto();
    currentState = state;

    var app = getApp();
    app.innerHTML = '';

    var wrap = el('div', 'petq-screen petq-intro');
    wrap.appendChild(el('h1', 'petq-title', traduci('Un nuovo pet')));
    var sub = (nomeRitirato ? (nomeRitirato + traduci(' è in pensione sul pianeta dei ritirati. ')) : '') +
      traduci('Scegli chi accogliere in famiglia.');
    wrap.appendChild(el('p', 'petq-sub', sub));

    var scelte = el('div', 'petq-uova');

    var robotBox = el('div', 'petq-uovo-box');
    var robotCanvas = document.createElement('canvas');
    robotCanvas.width = 64; robotCanvas.height = 64;
    robotCanvas.className = 'petq-uovo-canvas';
    disegnaUovo(robotCanvas, 'robot');
    robotBox.appendChild(robotCanvas);
    robotBox.appendChild(el('div', 'petq-uovo-label', traduci('Robot')));
    robotBox.addEventListener('click', function () { nuovoPetInCasa(state, 'robot'); });

    var alienoBox = el('div', 'petq-uovo-box');
    var alienoCanvas = document.createElement('canvas');
    alienoCanvas.width = 64; alienoCanvas.height = 64;
    alienoCanvas.className = 'petq-uovo-canvas';
    disegnaUovo(alienoCanvas, 'alieno');
    alienoBox.appendChild(alienoCanvas);
    alienoBox.appendChild(el('div', 'petq-uovo-label', traduci('Alieno')));
    alienoBox.addEventListener('click', function () { nuovoPetInCasa(state, 'alieno'); });

    scelte.appendChild(robotBox);
    scelte.appendChild(alienoBox);
    wrap.appendChild(scelte);

    app.appendChild(wrap);
    montaDebugPanel();
  }

  // Crea un pet NUOVO tenendo l'household (coins/arredi/pensionati/dispensa/negozio/tutorial/
  // ingrandimento). Applica l'EREDITA' dei pensionati, resetta i contatori PER-PET/giornalieri
  // rimasti, salva e torna alla casa col nuovo pet + un toast di benvenuto.
  function nuovoPetInCasa(state, razza) {
    if (!state || !PETQ.pet || !PETQ.pet.generate) return;
    if (schiusaInCorsa) return; // stessa guardia doppio-tap di sceglieUovo
    // Perk CASA (P3, Grandi Imprese): passa `state` cosi' generate() puo' sommare il bonus "alla
    // nascita" degli eventuali perk di ritiro gia' sbloccati da questa casa (state.perkCasa).
    var nuovo = PETQ.pet.generate(razza, state);

    // EREDITA' (B): ogni pensionato da' +1 alla sua stat firma, fino a EREDITA_CAP_PER_STAT per
    // stat. Applicata alle stat RPG del pet appena generato.
    var eredita = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    (state.pensionati || []).forEach(function (p) {
      if (p && p.statFirma && typeof eredita[p.statFirma] === 'number') eredita[p.statFirma]++;
    });
    // L'eredita' passa dal cancello unico (pet.js aggiungiStat) come ogni altra fonte di stat,
    // cosi' rispetta anche il TETTO PER STADIO. Il suo cap (EREDITA_CAP_PER_STAT) resta e viene
    // applicato PRIMA: sono due limiti diversi e voluti — questo dice "quanto puo' dare la
    // famiglia", il tetto dice "quanto puo' reggere un corpo da cucciolo".
    // Nella pratica non morde quasi mai (un neonato sta molto sotto il tetto baby), ma con casa
    // piena di perk + leggenda il totale alla nascita poteva arrivare a 13 contro un tetto di 12:
    // un buco piccolo e' comunque un buco, e il senso del cancello unico e' non averne nessuno.
    if (nuovo.rpg && PETQ.pet && PETQ.pet.aggiungiStat) {
      ['forza', 'intelligenza', 'velocita', 'carisma'].forEach(function (s) {
        if (eredita[s] > 0) PETQ.pet.aggiungiStat(nuovo, s, Math.min(eredita[s], EREDITA_CAP_PER_STAT));
      });
    }

    // Naming: il pet nuovo passa PRIMA dalla cerimonia di schiusa (sequenzaSchiusa, Round 5: la
    // razza scelta e' gia' nota, il pet 'nuovo' e' gia' generato in segreto sopra ma la sequenza
    // ne vede solo la razza) e poi dalla schermata di nascita (reveal + input nome) come il primo
    // pet; solo al click "Inizia" si finalizza tenendo la casa (finalizzaNuovoPetInCasa). Cosi'
    // l'eredita' gia' applicata a nuovo.rpg si vede nelle stat mostrate alla nascita.
    sequenzaSchiusa(razza, function () {
      mostraNascita(nuovo, function (namedPet) { finalizzaNuovoPetInCasa(state, namedPet); });
    });
  }

  // Lista bianca dei campi DELLA CASA (elenco definitivo deciso dal fondatore): l'UNICA cosa che
  // finalizzaNuovoPetInCasa (sotto) NON riporta allo stato di partita nuova. Per rendere un campo
  // futuro "della casa" lo si aggiunge QUI — non c'e' nessun'altra lista da tenere aggiornata, e
  // ogni campo non elencato (presente oggi o aggiunto domani da qualunque modulo) torna da solo
  // al valore di una partita nuova, senza bisogno di toccare questa funzione.
  var LISTA_BIANCA_CASA = {
    // Pensionati (galleria + fonte dell'EREDITA' sulle stat RPG, gia' applicata a pet.rpg da
    // nuovoPetInCasa PRIMA di arrivare qui: qui si tiene solo l'elenco che l'ha generata).
    pensionati: true,
    // Niente ri-tutorial / ri-sblocco negozio per un pet successivo nella stessa casa.
    tutorialFatto: true,
    negozioSbloccato: true,
    // Perk di ritiro (Grandi Imprese risolte in SUPER + pensione, v. talenti.js sezione "PERK
    // CASA"): traguardo PERMANENTE della casa, non del pet. miracoloCasaGiorno e' il SUO
    // contatore dedicato (gate settimanale del perk m67 "Maronna Mia", v. talenti.js
    // applicaMiracolo/miracoloCasaDisponibile): stesso ciclo di vita di perkCasa, resta con lui.
    perkCasa: true,
    miracoloCasaGiorno: true,
    // Leggende sbloccate (P3): NASCOSTO (nessuna UI oggi), serve solo al futuro uovo leggendario
    // (10% pet unico giocabile). Stesso ciclo di vita persistente di perkCasa.
    leggendeSbloccate: true,
    // Leggende INCONTRATE (Round 5): memoria "gia' vista" del cartello/fanfara alla schiusa,
    // STESSO ciclo di vita persistente di leggendeSbloccate — un pet nuovo nella stessa casa non
    // deve rivedere il cartello per una leggenda gia' incontrata in una run precedente.
    leggendeIncontrate: true,
    // Popup una-tantum del Supporter Pack (v. statoDiPartenza sopra): una-tantum ASSOLUTA, non
    // per-pet — un pet nuovo nella stessa casa non deve rivedere una promo gia' vista.
    popupSostieniVisto: true,
    // Lingua scelta dal GIOCATORE (mirror informativo, v. save.js/costruisciTastoLingua nell'hub):
    // non e' una caratteristica del pet.
    lingua: true,
    // Supporter Pack: acquisto a soldi veri, per definizione della CASA.
    supporter: true,
    // I QUATTRO pool cosmetici + le due variabili "attive" (skin stanza / cornice cartolina):
    // ESTETICA PURA, zero bonus (non entrano in bonusIndossato ne' in alcun talento), e in parte
    // comprati col Supporter Pack a soldi veri — azzerarli sarebbe togliere roba pagata. Arredi/
    // giocattoli/indossabili/armi danno bonus VERI e restano FUORI da questa lista apposta: si
    // azzerano (e' cosi' gia' oggi, deve restare cosi').
    coloriSbloccati: true,
    skinSbloccate: true,
    corniciSbloccate: true,
    completiSbloccati: true,
    skinAttiva: true,
    corniceAttiva: true,
    // "Giorni di carica" (streak.js): e' del GIOCATORE (giorni consecutivi in cui apre il gioco),
    // non del pet; la medaglia Custode resta per-pet tramite pet.streakAllaNascita.
    streak: true,
    // L'OROLOGIO della casa (clock.js): unica fonte di verita' per TUTTI i cancelli giornalieri di
    // ogni sistema (missioni/carte/lavoro/talenti/streak/ecc.). Rinumerarlo per un pet nuovo
    // romperebbe in silenzio ogni cancello che lo confronta.
    gameMinutes: true,
    giornoGioco: true,
    lastLoginDay: true,
    lastSeen: true,
    // La TUA faccia (Ritrattista): i tratti sono del GIOCATORE, non del pet, e non c'e' motivo di
    // rifarti le stesse cinque domande ad ogni pet. Resta fuori invece 'ritrattoFatto', che e' il
    // flag "questo pet ti ha gia' ritratto": il pet nuovo non l'ha ancora fatto, quindi
    // l'azione torna disponibile e la schermata si riapre GIA' coi tuoi tratti scelti — un tap di
    // conferma invece di cinque domande. (Il quadro e' un arredo e si azzera come tutti gli altri:
    // prima del ribaltamento ritrattoFatto restava true SENZA il quadro, cioe' il ritratto spariva
    // e non si poteva piu' rifare.)
    ritratto: true,
    // Memoria anti-ripetizione delle battute quarta parete (quartaparete.js): serve a non ripetere
    // al GIOCATORE la stessa uscita entro 20h. Azzerandola l'unico effetto possibile e' una
    // ripetizione precoce, che si legge come un difetto: tenerla non costa niente.
    quartaParete: true
  };

  // Finalizza l'arrivo del pet nuovo DOPO il naming (v. mostraNascita): lo installa in una CASA
  // FRESCA. Decisione fondatore: iniziando un pet NUOVO dopo un ritiro l'household NON deve
  // passare (gli arredi renderebbero il pet nuovo troppo forte); si tiene SOLO la lista bianca
  // sopra. Il "Riprendi" (riprendiPensionato) e' la via che INVECE tiene la casa.
  //
  // REGOLA (non piu' una lista di "cosa azzerare" da aggiornare a mano ad ogni campo nuovo — ed e'
  // esattamente cosi' che sono sopravvissuti in silenzio le 4 Porte, il mazzo dei Dilemmi, il
  // lavoro/carriera notturna, i flag/la rendita delle missioni e il timer settimanale
  // dell'Inventore): si parte da uno stato di partita NUOVA (statoDiPartenza, v. sopra) e si
  // conserva SOLO la lista bianca. Ogni campo che non ci sta dentro — oggi o in futuro, di
  // qualunque modulo — torna al valore di una partita nuova da solo, senza toccare questa funzione.
  function finalizzaNuovoPetInCasa(state, pet) {
    if (!state || !pet) return;

    var fresco = statoDiPartenza(); // pet resta null qui: si installa quello vero al punto 3.

    // 1) Ogni campo di una partita nuova che NON e' della casa torna al suo valore di partenza
    //    (compreso 'pet', per ora null: sistemato al punto 3).
    for (var k in fresco) {
      if (!Object.prototype.hasOwnProperty.call(fresco, k)) continue;
      if (LISTA_BIANCA_CASA[k]) continue;
      state[k] = fresco[k];
    }

    // 2) Ogni campo che oggi vive su `state` ma non fa parte di una partita nuova e non e' della
    //    casa sparisce: e' questo il punto che chiude porte/carte/lavoro/flags/renditaBonus/
    //    ultimaInvenzioneGiorno e qualunque campo futuro dimenticato, senza una lista da tenere
    //    aggiornata a mano.
    for (var k2 in state) {
      if (!Object.prototype.hasOwnProperty.call(state, k2)) continue;
      if (LISTA_BIANCA_CASA[k2]) continue;
      if (Object.prototype.hasOwnProperty.call(fresco, k2)) continue;
      delete state[k2];
    }

    // 3) Installa il pet vero (l'eredita' e' gia' applicata a pet.rpg da nuovoPetInCasa: NON
    //    ricalcolarla qui).
    state.pet = pet;

    if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
    mostraCasa(state);
    mostraToast(traduci('Benvenuto! Un nuovo pet è arrivato in famiglia.'));
  }

  // ==================== PIANETA "dei ritirati" (C) — scelta successiva + recupero ==============
  // Due modalita' a seconda di state.pet:
  //  - state.pet null (casa VUOTA, appena ritirato o al boot): e' la schermata "cosa faccio
  //    adesso". Ogni pensionato ha una card CON il bottone "Riprendi (Fai ammenda: 50 monete)"
  //    (disabilitato se coins < costo) + in fondo, SEMPRE, "🥚 Prendi un pet nuovo". NIENTE "Chiudi"
  //    (non c'e' gioco a cui tornare: DEVI scegliere).
  //  - state.pet esiste (aperto dalla SCHEDA come galleria): VIEW-ONLY. Card senza "Riprendi" (con
  //    nota "Per riprenderne uno, ritira prima il pet attuale.") + bottone "Chiudi" che torna al gioco.
  function mostraPianetaRitirati(state) {
    if (!state) return;
    var esistente = document.getElementById('petq-pianeta-overlay');
    if (esistente) esistente.remove();

    var casaVuota = !state.pet; // null/undefined -> modalita' scelta; altrimenti view-only
    var pensionati = Array.isArray(state.pensionati) ? state.pensionati : [];

    // Difensivo: casa vuota SENZA pensionati non dovrebbe accadere (senza pet e senza pensionati
    // sei all'intro). Se capita, torna all'intro invece di mostrare un Pianeta senza uscite.
    if (casaVuota && pensionati.length === 0) {
      mostraIntro();
      return;
    }

    var overlay = el('div', 'petq-scheda-overlay');
    overlay.id = 'petq-pianeta-overlay';

    var pagina = el('div', 'petq-scheda-pagina');
    pagina.appendChild(el('h2', 'petq-scheda-titolo', traduci('🪐 Pianeta dei ritirati')));

    var costo = costoAmmendaPensione();
    if (casaVuota) {
      pagina.appendChild(el('p', 'petq-scheda-nota',
        traduci('La casa è vuota. Riprendi un pet dal pianeta (costa ') + costo + traduci(' monete) oppure accogline uno nuovo.')));
    }

    if (pensionati.length === 0) {
      pagina.appendChild(el('p', 'petq-scheda-vuoto',
        traduci('Nessun pet in pensione ancora. Quando ne ritirerai uno, vivrà qui.')));
    } else {
      var lista = el('div', 'petq-pensionati-lista');
      for (var i = 0; i < pensionati.length; i++) {
        lista.appendChild(cardPensionato(pensionati[i], state, casaVuota, i, overlay, costo));
      }
      pagina.appendChild(lista);
    }

    if (casaVuota) {
      // niente "Chiudi": bisogna scegliere. Sempre disponibile: prendere un pet nuovo (casa fresca).
      var nuovoBtn = el('button', 'petq-btn petq-btn-primario', traduci('🥚 Prendi un pet nuovo'));
      nuovoBtn.addEventListener('click', function () {
        overlay.remove();
        mostraSceltaNuovoPet(state);
      });
      pagina.appendChild(nuovoBtn);
    } else {
      // view-only (aperto dalla scheda col pet in casa): si puo' solo guardare e chiudere.
      if (pensionati.length > 0) {
        pagina.appendChild(el('p', 'petq-scheda-nota',
          traduci('Per riprenderne uno, ritira prima il pet attuale.')));
      }
      var chiudiBtn = el('button', 'petq-btn petq-btn-primario', traduci('Chiudi'));
      chiudiBtn.addEventListener('click', function () { overlay.remove(); });
      pagina.appendChild(chiudiBtn);
    }

    overlay.appendChild(pagina);
    // Click sullo sfondo scuro chiude SOLO in view-only (col pet in casa): a casa vuota non c'e'
    // via d'uscita, va scelto "Riprendi" o "Prendi nuovo".
    if (!casaVuota) {
      overlay.addEventListener('click', function (e) {
        if (e.target === overlay) overlay.remove();
      });
    }
    document.body.appendChild(overlay);
  }

  // Costo per riprendere un pensionato (placeholder "Fai ammenda": la lettera scrivibile con AI e'
  // P3). Riusa la costante ammenda della valigia (50) se disponibile, fallback 50.
  function costoAmmendaPensione() {
    return (PETQ.pet && typeof PETQ.pet._costoAmmenda === 'number') ? PETQ.pet._costoAmmenda : 50;
  }

  // Legge i campi display di un pensionato da voce.pet (nuovo formato: la voce contiene una deep
  // copy del pet completo) con fallback ai campi flat della voce (vecchio formato v=41), cosi' una
  // galleria mista (salvataggio pre-rework) non crasha.
  function datiPensionato(voce) {
    if (!voce) return null;
    var p = voce.pet || voce; // voce.pet = nuovo formato; voce = vecchio (campi flat)
    return {
      nome: p.nome || traduci('Senza nome'),
      razza: p.razza,
      // Leggende (P3 batch 6): id del personaggio (per il redraw dello sprite sotto, v.
      // cardPensionato) — NON e' lo stesso campo di `leggenda` sotto (quello e' il flag booleano
      // "impresaSuper vinta", preesistente e senza relazione con l'aspetto del pet).
      leggendaId: p.leggendaId || null,
      sottorazza: p.sottorazza || null,
      parts: p.parts || null,
      stadio: p.stadio || 'baby',
      personalita: p.personalita || 'gentile',
      modSprite: p.modSprite || null, // modifica permanente M17: "per sempre" anche in galleria
      statFirma: voce.statFirma || (voce.pet ? null : voce.statFirma) || 'carisma',
      recuperabile: !!voce.pet, // solo il nuovo formato (con snapshot completo) e' ripristinabile
      // Grande Impresa (P3): titolo della Medaglia (se mai risolta) + flag leggenda (super). Voci
      // vecchie (pre-feature) non hanno questi campi: null/false, nessuna riga in piu' mostrata.
      medagliaImpresa: voce.medagliaImpresa || (p && p.medagliaImpresa) || null,
      leggenda: !!(voce.leggenda || (p && p.impresaSuper)),
      // Custode (streak 14 giorni): sta nella copia del pet, non serve un campo suo nella voce.
      medagliaCustode: !!(p && p.medagliaCustode)
    };
  }

  // Battute sibilline GENERICHE per la stellina '✦' dei pensionati leggenda (P3, Grandi Imprese
  // super): regola sacra niente-spoiler, mai un nome/identita' del companion leggendario o la
  // parola "sbloccato" — solo un indizio vago. Gli sprite/le battute DEDICATE arrivano con la
  // pipeline leggende; questo e' un placeholder generico finche' non esistono.
  var BATTUTE_STELLINA_IMPRESA = [
    'Chissà chi ha bussato alla porta, quella volta.',
    'Al pianeta raccontano ancora di quella visita.',
    'Qualcuno, da queste parti, si è fatto un nome. Letteralmente.',
    'Non tutte le pensioni sono uguali. Questa ha una storia in più.'
  ];

  // Card di un singolo pensionato: mini-canvas col pet ridisegnato + testi. Se casaVuota, aggiunge
  // il bottone "Riprendi (Fai ammenda: N monete)"; altrimenti (view-only) nessun bottone.
  function cardPensionato(voce, state, casaVuota, index, overlay, costo) {
    var card = el('div', 'petq-pensionato-card');
    var d = datiPensionato(voce);
    if (!d) return card;

    var canvas = document.createElement('canvas');
    canvas.width = PET_SIZE * 3;
    canvas.height = PET_SIZE * 3;
    canvas.className = 'petq-pensionato-sprite';
    if (PETQ.sprites && PETQ.sprites.draw) {
      PETQ.sprites.draw(canvas, {
        razza: d.razza,
        leggendaId: d.leggendaId,
        sottorazza: d.sottorazza,
        parts: d.parts,
        stadio: d.stadio,
        corpo: 'normale',
        sporco: false,
        modSprite: d.modSprite // la modifica M17 e' "per sempre": si vede anche da pensionato
      }, { frame: 0 });
    }
    card.appendChild(canvas);

    var testi = el('div', 'petq-pensionato-testi');
    testi.appendChild(el('div', 'petq-pensionato-nome', d.nome));
    var meta = traduci(PERSONALITA_LABEL[d.personalita] || d.personalita || '?') + ' · ' +
      traduci(STADIO_LABEL[d.stadio] || d.stadio || '?');
    testi.appendChild(el('div', 'petq-pensionato-meta', meta));

    // Grande Impresa (P3): titolo della Medaglia sotto il nome + stellina '✦' se leggenda:true.
    // NIENTE testo "sbloccato" (regola niente-spoiler): la stellina/battuta e' l'UNICO indizio,
    // gli sprite delle leggende arrivano con la pipeline dedicata.
    if (d.medagliaImpresa && d.medagliaImpresa.titolo) {
      // titoloMissione ripulisce il prefisso "Missione N:" (scheda.titolo e' grezzo, v.
      // missions.js risolvi): stesso helper gia' usato per le card missione normali.
      var rigaMedaglia = el('div', 'petq-pensionato-medaglia', traduci('🏅 ') + titoloMissione(schedaImpresaCorrente(d.medagliaImpresa)));
      if (d.leggenda) {
        var stellina = el('span', 'petq-pensionato-stellina', ' ✦');
        var battutaStellina = (PETQ.rng && PETQ.rng.pick) ? PETQ.rng.pick(BATTUTE_STELLINA_IMPRESA) : BATTUTE_STELLINA_IMPRESA[0];
        stellina.title = traduci(battutaStellina); // hover (desktop)
        stellina.addEventListener('click', function (e) {
          e.stopPropagation();
          mostraToast('✦ ' + traduci(battutaStellina));
        }); // tap (touch)
        rigaMedaglia.appendChild(stellina);
      }
      testi.appendChild(rigaMedaglia);
    }

    // Medaglietta "Custode" (streak 14 giorni): il doc di design chiede che la card del
    // pensionato lo SCRIVA, ed e' il punto in cui quella serie diventa un ricordo invece che
    // un contatore. Letta dallo snapshot (d.medagliaCustode, copia profonda di state.pet):
    // le voci ritirate prima di oggi semplicemente non ce l'hanno e non mostrano nulla.
    if (d.medagliaCustode) {
      testi.appendChild(el('div', 'petq-pensionato-medaglia', traduci('🏅 Cresciuto senza un giorno di assenza')));
    }

    var statLabel = traduci(STAT_LABEL_RPG[d.statFirma]) || d.statFirma || '?';
    testi.appendChild(el('div', 'petq-pensionato-eredita', traduci('Eredità: +1 ') + statLabel));

    // Bottone "Riprendi" solo a casa vuota (schermata scelta) e solo per il nuovo formato (voce
    // con .pet ripristinabile). Vecchie voci v=41 senza .pet: nota "non recuperabile".
    if (casaVuota) {
      if (!d.recuperabile) {
        testi.appendChild(el('div', 'petq-pensionato-nota', traduci('Non recuperabile (pet ritirato in una vecchia versione).')));
      } else {
        var costoOk = (typeof costo === 'number') ? costo : costoAmmendaPensione();
        var haMonete = (state.coins || 0) >= costoOk;
        var ripBtn = el('button', 'petq-btn petq-btn-mini',
          haMonete ? (traduci('Riprendi (Fai ammenda: ') + costoOk + traduci(' monete)')) : traduci('Monete insufficienti'));
        if (!haMonete) {
          ripBtn.disabled = true;
          ripBtn.title = traduci('Ti servono ') + costoOk + traduci(' monete.');
        } else {
          ripBtn.addEventListener('click', function () {
            if (overlay) overlay.remove();
            riprendiPensionato(state, index);
          });
        }
        testi.appendChild(ripBtn);
      }
    }
    card.appendChild(testi);

    return card;
  }

  // Riprendi un pensionato (recupero placeholder "Fai ammenda": la lettera scrivibile con AI e' P3):
  // paga il costo, ripristina il pet COM'ERA (deep copy dallo snapshot), rimuove la voce dai
  // pensionati e torna alla casa (household/arredi restano quelli del ritiro: e' un ripensamento).
  function riprendiPensionato(state, index) {
    if (!state) return;
    var pensionati = Array.isArray(state.pensionati) ? state.pensionati : [];
    var voce = pensionati[index];
    if (!voce) { mostraToast(traduci('Pensionato non trovato.')); return; }
    if (!voce.pet) {
      // vecchio formato (v=41): niente snapshot completo, non ripristinabile.
      mostraToast(traduci('Non recuperabile: questo pet è stato ritirato in una vecchia versione.'));
      return;
    }
    var costo = costoAmmendaPensione();
    if ((state.coins || 0) < costo) {
      mostraToast(traduci('Monete insufficienti. Ti servono ') + costo + traduci(' monete.'));
      return;
    }

    state.coins = (state.coins || 0) - costo;
    state.pet = JSON.parse(JSON.stringify(voce.pet)); // il pet torna COM'ERA

    // Medaglie/vestiti/arma del pensionato (fix audit): sono PER-PET ma vivono su state, e se
    // nel frattempo e' passato un pet nuovo (casa fresca) sono stati azzerati. Lo snapshot
    // equipCasa (pet.js mandaInPensione) li riporta com'erano. Voci vecchie senza snapshot:
    // si lascia lo state attuale (comportamento precedente, ripresa diretta funzionava gia').
    if (voce.equipCasa) {
      state.perks = Array.isArray(voce.equipCasa.perks) ? voce.equipCasa.perks.slice() : [];
      state.indossabili = Array.isArray(voce.equipCasa.indossabili) ? voce.equipCasa.indossabili.slice() : [];
      state.indossato = voce.equipCasa.indossato || null;
      // l'arma equipaggiata era un ARREDO: con la casa fresca potrebbe non esistere piu'.
      // La ripristiniamo solo se ancora posseduta (bonusArmaEquip ha comunque la guardia).
      state.armaEquip = voce.equipCasa.armaEquip || null;
    }

    // Stato di RUN (fix bug "missioni gia' fatte rigiocabili": v. pet.js mandaInPensione
    // statoRun): missioniFatte/rotazioneMissioni/impresaRun/ultimaInvenzioneGiorno sono
    // dell'ULTIMO occupante della casa finche' non li si rimette a posto qui — un pet ripreso
    // deve tornare a vedere ESATTAMENTE le SUE missioni gia' fatte, non ereditare (o rifare
    // apparire come nuove) quelle di un pet diverso passato nel frattempo. Voci vecchie (ritirate
    // prima di questo fix, senza statoRun): si AZZERA invece di ereditare — "questo pet puo'
    // rifare le SUE missioni" e' meglio di "eredita quelle di un altro pet a caso".
    if (voce.statoRun) {
      state.missioniFatte = JSON.parse(JSON.stringify(voce.statoRun.missioniFatte || {}));
      state.rotazioneMissioni = JSON.parse(JSON.stringify(voce.statoRun.rotazioneMissioni || {}));
      state.impresaRun = voce.statoRun.impresaRun || null;
      if (typeof voce.statoRun.ultimaInvenzioneGiorno === 'number') {
        state.ultimaInvenzioneGiorno = voce.statoRun.ultimaInvenzioneGiorno;
      } else {
        delete state.ultimaInvenzioneGiorno;
      }
    } else {
      state.missioniFatte = {};
      state.rotazioneMissioni = {};
      state.impresaRun = null;
      delete state.ultimaInvenzioneGiorno;
    }

    pensionati.splice(index, 1);
    state.pensionati = pensionati;

    if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
    mostraCasa(state);
    mostraToast(traduci('È tornato! ') + ((state.pet && state.pet.nome) || traduci('Il pet')) + traduci(' è di nuovo a casa.'));
  }

  // ==================== PAGINA DIARIO (PROTOTIPO-2.md punto 6 "Diario in camera") ====================
  // Overlay "a foglio" sopra la scena camera (NON un app.innerHTML pieno come mostraEsito/
  // mostraEvoluzione): "Chiudi" si limita a rimuovere il nodo, cosi' si resta esattamente sulla
  // camera senza passare da mostraCasa (che resetterebbe currentStanza a 'cucina'). Le righe
  // vengono dal contenuto assemblato da PETQ.diario.componiPagina in base agli eventi VERI
  // della giornata corrente (cibo/missione/umore/coccole, v. diario.js).
  function mostraDiario(state) {
    if (!state || !state.pet) return;
    var esistente = document.getElementById('petq-diario-overlay');
    if (esistente) esistente.remove();

    var overlay = el('div', 'petq-diario-overlay');
    overlay.id = 'petq-diario-overlay';

    var pagina = el('div', 'petq-diario-pagina');
    pagina.appendChild(el('h2', 'petq-diario-titolo', traduci('Diario di ') + (state.pet.nome || traduci('il pet')) + traduci(' — sera')));

    var righe = (PETQ.diario && PETQ.diario.componiPagina) ? PETQ.diario.componiPagina(state) : [];

    // Leggerlo PREMIA (decisione fondatore, playtest 8 lug 2026: "il diario e' inutile"):
    // la PRIMA lettura del giorno da' +3 Felicita' — al pet fa piacere che ti interessi ai
    // suoi pensieri. Gate sul giorno di gioco (comparison-based, come coccole/furto).
    var oggiDiario = PETQ.clock.giornoCorrente(state);
    var premioDiario = (state.diarioLettoGiorno !== oggiDiario);
    if (premioDiario) {
      state.diarioLettoGiorno = oggiDiario;
      state.pet.stats.felicita = Math.max(0, Math.min(100, state.pet.stats.felicita + 3));
      if (PETQ.pet && PETQ.pet.recomputeSalute) PETQ.pet.recomputeSalute(state.pet, state);
      aggiornaHud(state);
    }

    // Il diario e' bloccato a 1/giorno (v. diario.js componiPagina): componiPagina memorizza
    // la pagina in state.diarioOggi la prima volta del giorno; salviamo cosi' il lock resiste
    // anche a un reload (riaprendo la scrivania esce la stessa pagina, non una nuova estrazione).
    // Il salvataggio copre anche il premio-lettura appena applicato.
    if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
    if (righe.length === 0) {
      pagina.appendChild(el('p', 'petq-diario-vuoto', traduci('(pagina bianca: niente da raccontare oggi)')));
    } else {
      for (var i = 0; i < righe.length; i++) {
        pagina.appendChild(el('p', 'petq-diario-riga', righe[i]));
      }
    }
    if (premioDiario) {
      pagina.appendChild(el('p', 'petq-diario-premio', traduci('💛 +3 Felicità: gli fa piacere che leggi i suoi pensieri.')));
    }

    var chiudiBtn = el('button', 'petq-btn petq-btn-primario', traduci('Chiudi'));
    chiudiBtn.addEventListener('click', function () { overlay.remove(); });
    pagina.appendChild(chiudiBtn);

    overlay.appendChild(pagina);
    // click sullo sfondo scuro (fuori dal foglio) chiude come il bottone, stesso gesto atteso
    // di un modale; il click sul foglio stesso non deve propagare e chiuderlo per errore.
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) overlay.remove();
    });

    document.body.appendChild(overlay);
  }

  // ==================== SCHEDA PERSONAGGIO (PROTOTIPO-2.md punto 3 / Blocco 9) ====================
  // "Priorita' alta, ben visibile": schermata tipo scheda gdr che riassume nome, razza/stadio/
  // personalita', le 5 barre benessere, le 4 stat RPG (base + bonus arredi/talenti gia'
  // calcolato da statConBonus), i talenti presi (pallino rarita' + effetto + da quale stadio) e
  // i perk di categoria attivi dagli arredi piazzati. Overlay "a foglio" come mostraDiario: NON
  // resetta currentStanza, "Chiudi" si limita a rimuovere il nodo cosi' si resta esattamente
  // dov'era la casa (qualunque stanza/tab fosse aperta quando si e' premuto "Scheda").
  // 'leggenda' (P3 batch 6): scheda mostra "Leggenda" invece del razza grezzo, niente sottorazza
  // in coda (pet.sottorazza e' null per una leggenda, v. pet.js generate).
  var RAZZA_LABEL = { robot: 'Robot', alieno: 'Alieno', leggenda: 'Leggenda' };
  var SOTTORAZZA_LABEL = { blob: 'Blob', insettoide: 'Mantide-folk', rettiliano: 'Lizardfolk' };
  var STADIO_LABEL = { baby: 'Baby', teen: 'Teen', adulto: 'Adulto', nascita: 'Nascita' };
  var PERSONALITA_LABEL = { gentile: 'Gentile', maleducato: 'Maleducato', nerd: 'Nerd', sportivo: 'Sportivo' };
  var PERK_CATEGORIA_LABEL = { videogioco: 'Player One (Videogioco)', combattimento: 'Street Fighter (Combattimento)', sport: 'Tony Hawk (Sport)' };
  var STAT_LABEL_RPG = { forza: 'Forza', intelligenza: 'Intelligenza', velocita: 'Velocità', carisma: 'Carisma' };
  // Perk = MEDAGLIETTE (decisione fondatore, bilanciamento.md "Perk = MEDAGLIETTE"): nome leggibile
  // + effetto breve per ogni badge in state.perks. Le illustrazioni dei badge sono RIMANDATE (per
  // ora testo). weaponwielder e' salvato come badge ma senza effetto ancora (equip armi = Blocco 6).
  var PERK_LABEL = {
    videogioco: 'Player One', combattimento: 'Street Fighter', sport: 'Tony Hawk', studio: 'Doc Brown',
    sabotatore: 'Sabotatore', parkour: 'Parkour Master', influencer: 'Influencer', singer: 'Singer',
    gtb: 'Gran Theft Burger', cacciatoremostri: 'Cacciatore di Mostri', popeye: 'Popeye',
    weaponwielder: 'Weapon Wielder',
    ponyexpressgalattico: 'Pony Express Galattico', partyanimal: 'Party Animal', mrwolf: 'Mr. Wolf',
    masterchef: 'Masterchef', acchiappafantasmi: 'Acchiappafantasmi', astronauta: 'Astronauta',
    acchiappalitutti: 'Acchiappali Tutti',
    // I 3 perk dei Corsi Pomeridiani (porte.js): senza queste voci la scheda ripiegava
    // sull'id grezzo capitalize('corso_disegno') = "Corso_disegno", in ENTRAMBE le lingue
    // (segnalazione fondatore 8 ago 2026). I nomi sono le "persone" che il gioco usa gia'
    // nelle sue schermate: Ritrattista, Cantante da Doccia, Cuoco di Casa.
    corso_disegno: 'Ritrattista', corso_musica: 'Cantante da Doccia', corso_cucina: 'Cuoco di Casa'
  };
  var PERK_EFFETTO = {
    videogioco: 'super garantito: Videogioco', combattimento: 'super garantito: Combattimento',
    sport: 'super garantito: Sport', studio: 'super garantito: Studio',
    sabotatore: 'super garantito nelle Gare', parkour: 'super garantito negli Inseguimenti',
    influencer: 'super garantito nelle missioni Social', singer: 'super garantito nelle missioni Musica',
    gtb: 'super garantito nelle Rapine', cacciatoremostri: 'super garantito coi Mostri',
    popeye: 'verdure → +1 Forza', weaponwielder: 'sblocca equip armi (in arrivo)',
    ponyexpressgalattico: 'super garantito nelle Consegne', partyanimal: 'super garantito nelle missioni Sociali',
    mrwolf: 'super garantito nei Lavoretti', masterchef: 'super garantito in Cucina',
    acchiappafantasmi: 'super garantito nel Paranormale', astronauta: 'super garantito nello Spazio',
    acchiappalitutti: 'super garantito coi Companion',
    corso_disegno: 'sa farti il ritratto (salone)', corso_musica: 'canta le parole insegnate',
    corso_cucina: 'cucina un pasto al giorno (cucina)'
  };
  // Armeria (FASE SPRITE): le armi sono arredi normali (nessun marcatore nel dato). Questo set
  // riconosce quali arredi posseduti/piazzati sono armi equipaggiabili. 4 M7 + 5 Kaiju + Pistola M28.
  var ARMI_SET = {
    'Bastone da combattimento': 1, 'Sai gemelli': 1, 'Nunchaku arrugginiti': 1, 'Katane a farfalla': 1,
    'Spadone': 1, 'Martellone': 1, 'Doppie Lame': 1, 'Arco Pesante': 1, 'Alabarda': 1,
    'Pistola Spara-Spazzatura': 1
  };
  // NOTA (fase 3): le due mappe INDOSSABILE_EFFETTO (7 voci) e ARMA_EFFETTO (10) che stavano qui
  // sono state RIMOSSE. Erano l'unica fonte dei testi di Armadio/Armeria/negozio e coprivano 7
  // indossabili su 38: gli altri 31 non dicevano niente. Ora il testo lo costruisce
  // nodiEffettiEquip() leggendo content/arredi.md, la stessa fonte che missions.js usa per
  // calcolare il bonus — testo e numeri non possono piu' divergere.

  // Descrizione del talento nella LINGUA ATTIVA, non quella congelata nel salvataggio (fix
  // audit 28 lug 2026, segnalazione fondatore: "i NOMI dei talenti sono in inglese ma le
  // DESCRIZIONI restano italiane"). Causa: talenti.js estrai() copia effettoTesto dal catalogo
  // DENTRO il salvataggio alla nascita/evoluzione, nella lingua attiva IN QUEL MOMENTO — se il
  // giocatore cambia lingua dopo, quella copia non si aggiorna piu' (e' un dato di partita, non
  // testo di schermata). Il catalogo in memoria (PETQ.content.data.talenti), invece, e' sempre
  // ricaricato nella lingua corrente e quindi ha gia' la descrizione giusta: qui lo si rilegge
  // usando il NOME del talento come chiave stabile (il nome e' un dato tecnico, IDENTICO in IT
  // ed EN — v. content/en/talenti.md — quindi la ricerca funziona in entrambe le lingue).
  // DIFENSIVA per costruzione: ogni livello (catalogo non caricato, personalita' sconosciuta,
  // stadio assente, array vuoto) puo' mancare, e in tal caso si ricade sul fallback SENZA MAI
  // lanciare un'eccezione — meglio una descrizione congelata che una schermata rotta.
  function descrizioneTalentoCorrente(tal) {
    try {
      if (!tal || !tal.nome) return (tal && tal.effettoTesto) || '';
      var catalogo = window.PETQ && window.PETQ.content && window.PETQ.content.data && window.PETQ.content.data.talenti;
      if (!catalogo) return tal.effettoTesto || '';
      for (var personalita in catalogo) {
        if (!catalogo.hasOwnProperty(personalita)) continue;
        var bloccoPers = catalogo[personalita];
        if (!bloccoPers) continue;
        for (var stadio in bloccoPers) {
          if (!bloccoPers.hasOwnProperty(stadio)) continue;
          var terna = bloccoPers[stadio];
          if (!terna || !terna.length) continue;
          for (var i = 0; i < terna.length; i++) {
            if (terna[i] && terna[i].nome === tal.nome) {
              return (typeof terna[i].effettoTesto === 'string') ? terna[i].effettoTesto : (tal.effettoTesto || '');
            }
          }
        }
      }
      return tal.effettoTesto || '';
    } catch (e) {
      return (tal && tal.effettoTesto) || '';
    }
  }

  function mostraScheda(state) {
    if (!state || !state.pet) return;
    var esistente = document.getElementById('petq-scheda-overlay');
    if (esistente) {
      esistente.remove();
    } else {
      miracoloScelteAperte = false; // apertura "da fuori" (non un ri-render nostro): scelte miracolo richiuse
      // Suono SOLO sull'apertura vera (nessun overlay gia' presente): questa funzione fa anche da
      // "refresh" quando gia' aperta (miracolo/indossa/equip la richiamano per ridisegnarsi), e in
      // quei casi esistente e' valorizzato -> niente doppio 'apri' a ogni tap interno.
      if (PETQ.audio) PETQ.audio.suona('apri');
    }
    pensioneConferma = false; // ogni apertura riparte senza conferma pensione pendente

    var overlay = el('div', 'petq-scheda-overlay');
    overlay.id = 'petq-scheda-overlay';

    var pagina = el('div', 'petq-scheda-pagina');
    var pet = state.pet;

    var razzaTxt = traduci(RAZZA_LABEL[pet.razza]) || pet.razza || '?';
    if (pet.sottorazza) razzaTxt += ' (' + (traduci(SOTTORAZZA_LABEL[pet.sottorazza]) || pet.sottorazza) + ')';
    pagina.appendChild(el('h2', 'petq-scheda-titolo', pet.nome || traduci('Il tuo pet')));
    pagina.appendChild(el('p', 'petq-scheda-sottotitolo',
      razzaTxt + ' · ' + traduci(STADIO_LABEL[pet.stadio] || pet.stadio) + ' · ' + traduci(PERSONALITA_LABEL[pet.personalita] || pet.personalita)));

    // ---- Stat benessere (5 barre, stesso stile dell'HUD) ----
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Benessere')));
    var barre = [
      ['Fame', pet.stats.fame], ['Igiene', pet.stats.igiene], ['Salute', pet.stats.salute],
      ['Felicità', pet.stats.felicita], ['Energia', pet.stats.energia]
    ];
    for (var i = 0; i < barre.length; i++) {
      var val = Math.round(barre[i][1]);
      var riga = el('div', 'petq-barra-riga');
      riga.appendChild(el('span', 'petq-barra-label', traduci(barre[i][0])));
      var traccia = el('div', 'petq-barra-traccia');
      var fill = el('div', 'petq-barra-fill ' + coloreBarra(val));
      fill.style.width = val + '%';
      traccia.appendChild(fill);
      riga.appendChild(traccia);
      riga.appendChild(el('span', 'petq-barra-val', String(val)));
      pagina.appendChild(riga);
    }

    // ---- Stat RPG (base + bonus arredi/talenti, es. "Forza 3 (+2)") ----
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Statistiche')));
    var statRpg = el('div', 'petq-scheda-rpg');
    for (var s = 0; s < PROPS_ALLENAMENTO.length; s++) {
      var propS = PROPS_ALLENAMENTO[s];
      var rigaS = el('div', 'petq-scheda-rpg-riga');
      rigaS.appendChild(el('span', 'petq-scheda-rpg-label', traduci(propS.label)));
      rigaS.appendChild(el('span', 'petq-scheda-rpg-val', testoStat(propS.stat, state)));
      statRpg.appendChild(rigaS);
    }
    pagina.appendChild(statRpg);

    // ---- Pianta Esotica: stat RPG boostata oggi (se piazzata) ----
    if (state.piantaEsoticaStat && STAT_LABEL_RPG[state.piantaEsoticaStat]) {
      pagina.appendChild(el('p', 'petq-scheda-nota',
        traduci('Pianta Esotica: oggi +2 ') + traduci(STAT_LABEL_RPG[state.piantaEsoticaStat])));
    }

    // ---- Talenti presi (nome, pallino rarita', effetto breve, stadio) ----
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Talenti')));
    var talenti = (PETQ.talenti && PETQ.talenti.talentiAttivi) ? PETQ.talenti.talentiAttivi(state) : [];
    if (talenti.length === 0) {
      pagina.appendChild(el('p', 'petq-scheda-vuoto', traduci('Nessun talento ancora (in attesa della nascita/evoluzione).')));
    } else {
      for (var t = 0; t < talenti.length; t++) {
        var tal = talenti[t];
        var rigaTal = el('div', 'petq-scheda-talento');
        // Icona talento (PROTOTIPO 2): simbolo su anello argento (normale) / oro (raro).
        // Fallback al pallino colorato se il talento non ha ancora un disegno in PETQ.badges.
        var iconaTal = document.createElement('canvas');
        iconaTal.width = 84; iconaTal.height = 84;
        iconaTal.className = 'petq-talento-icona';
        iconaTal.title = traduci(tal.raro ? 'Raro' : 'Normale');
        if (PETQ.badges && PETQ.badges.disegnaTalento && PETQ.badges.disegnaTalento(iconaTal, tal.nome, tal.raro)) {
          rigaTal.appendChild(iconaTal);
        } else {
          var pallino = el('span', 'petq-talento-pallino ' + (tal.raro ? 'petq-talento-raro' : 'petq-talento-normale'));
          pallino.title = traduci(tal.raro ? 'Raro' : 'Normale');
          rigaTal.appendChild(pallino);
        }
        var testoWrap = el('div', 'petq-talento-testo');
        testoWrap.appendChild(el('div', 'petq-talento-nome', traduci(tal.nome) + ' (' + traduci(STADIO_LABEL[tal.stadio] || tal.stadio) + ')'));
        testoWrap.appendChild(el('div', 'petq-talento-effetto', descrizioneTalentoCorrente(tal)));
        rigaTal.appendChild(testoWrap);
        pagina.appendChild(rigaTal);
      }
    }

    // ---- Miracolo (P3 BATCH 4, talento Santo Subito, "miracolo=1/giorno"; P3 Grandi Imprese,
    // perk casa "Maronna Mia" m67, 1/settimana anche senza il talento) ----
    // Bottone attivabile SOLO se il pet ha il talento O la casa ha sbloccato il perk m67: mostra
    // 4 scelte (Azzera Ferite / Fame 100 / Igiene 100 / Energia 100), stesso pattern "espandi
    // scelte" che il resto della scheda non ha ancora, quindi qui uso un piccolo blocco dedicato
    // con bottoni petq-btn petq-btn-mini (stesso stile Armadio/Armeria). Se non disponibile
    // (gia' usato oggi, O settimana sbagliata per chi ha solo il perk casa), bottone disabilitato
    // con nota (stesso pattern "Allenamento gia' fatto oggi" di care.train, etichetta INVARIATA
    // anche per il perk casa — v. talenti.js miracoloDisponibile/miracoloCasaDisponibile).
    var haMiracoloTalento = PETQ.talenti && PETQ.talenti.haSantoSubito && PETQ.talenti.haSantoSubito(state);
    var haMiracoloCasa = PETQ.talenti && PETQ.talenti.perkCasaMiracoloAttivo && PETQ.talenti.perkCasaMiracoloAttivo(state);
    if (haMiracoloTalento || haMiracoloCasa) {
      pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Miracolo')));
      var miracoloDisponibileOggi = PETQ.talenti.miracoloDisponibile(state);
      if (!miracoloDisponibileOggi) {
        pagina.appendChild(el('p', 'petq-scheda-vuoto', traduci('Miracolo già fatto oggi, torna domani.')));
      } else if (!miracoloScelteAperte) {
        var miracoloBtn = el('button', 'petq-btn petq-btn-mini', traduci('✨ Miracolo'));
        miracoloBtn.addEventListener('click', function () {
          miracoloScelteAperte = true;
          mostraScheda(state);
        });
        pagina.appendChild(miracoloBtn);
      } else {
        var scelteWrap = el('div', 'petq-scheda-pensione-azioni');
        var SCELTE_MIRACOLO = [
          { chiave: 'ferite', label: 'Azzera Ferite' },
          { chiave: 'fame', label: 'Fame 100' },
          { chiave: 'igiene', label: 'Igiene 100' },
          { chiave: 'energia', label: 'Energia 100' }
        ];
        for (var sm = 0; sm < SCELTE_MIRACOLO.length; sm++) {
          (function (scelta) {
            var sceltaBtn = el('button', 'petq-btn petq-btn-mini', traduci(scelta.label));
            sceltaBtn.addEventListener('click', function () {
              var esitoMiracolo = PETQ.talenti.applicaMiracolo(state, scelta.chiave);
              miracoloScelteAperte = false;
              if (esitoMiracolo.ok) {
                if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
                aggiornaHud(state);
                mostraToast(esitoMiracolo.msg);
              } else {
                mostraToast(esitoMiracolo.msg);
              }
              mostraScheda(state);
            });
            scelteWrap.appendChild(sceltaBtn);
          })(SCELTE_MIRACOLO[sm]);
        }
        pagina.appendChild(scelteWrap);
      }
    }

    // ---- Medaglia dell'Impresa (P3, Grandi Imprese): riga semplice, zona medaglie/perk ----
    if (pet.medagliaImpresa && pet.medagliaImpresa.titolo) {
      // titoloMissione ripulisce il prefisso "Missione N:" (scheda.titolo e' grezzo).
      pagina.appendChild(el('p', 'petq-scheda-medaglia-impresa', traduci('🏅 ') + titoloMissione(schedaImpresaCorrente(pet.medagliaImpresa))));
    }

    // ---- Medaglietta "Custode" (streak 14 giorni, Retention 2.0/A2): stessa forma della riga
    // Medaglia dell'Impresa qui sopra, perche' e' la stessa cosa — un riconoscimento che il pet
    // si porta dietro, non un perk con un effetto. Vive su pet.medagliaCustode, quindi un pet
    // nuovo riparte senza e il pensionato se la porta nello snapshot. ----
    if (pet.medagliaCustode) {
      pagina.appendChild(el('p', 'petq-scheda-medaglia-impresa', traduci('🏅 Custode — 14 giorni di carica senza saltarne uno')));
    }

    // ---- Medaglie / Perk (badge da state.perks, decisione fondatore "Perk = MEDAGLIETTE") ----
    // Non piu' i perk da arredi piazzati: sono medagliette permanenti ottenute dalle missioni
    // (reward perk:<nome>). Illustrazioni dei badge RIMANDATE: per ora testo (nome + effetto).
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Medaglie')));
    var perks = Array.isArray(state.perks) ? state.perks : [];
    if (perks.length === 0) {
      pagina.appendChild(el('p', 'petq-scheda-vuoto', traduci('Nessuna medaglia ancora.')));
    } else {
      var listaPerk = el('div', 'petq-scheda-perklist');
      for (var p = 0; p < perks.length; p++) {
        var pkNome = perks[p];
        var medaglia = el('div', 'petq-scheda-perk');
        // Badge perk canvas (PROTOTIPO 2): medaglietta oro disegnata sopra nome+effetto.
        // Fallback: se il perk non e' in PETQ.badges resta l'emoji 🏅 davanti al nome.
        var badgePerk = document.createElement('canvas');
        badgePerk.width = 84; badgePerk.height = 84;
        badgePerk.className = 'petq-perk-badge';
        var perkOk = !!(PETQ.badges && PETQ.badges.disegnaPerk && PETQ.badges.disegnaPerk(badgePerk, pkNome));
        if (perkOk) medaglia.appendChild(badgePerk);
        medaglia.appendChild(el('span', 'petq-scheda-perk-nome', (perkOk ? '' : traduci('🏅 ')) + (traduci(PERK_LABEL[pkNome]) || capitalize(pkNome))));
        if (PERK_EFFETTO[pkNome]) {
          medaglia.appendChild(el('span', 'petq-scheda-perk-effetto', traduci(PERK_EFFETTO[pkNome])));
        }
        listaPerk.appendChild(medaglia);
      }
      pagina.appendChild(listaPerk);
    }

    // ---- Armadio / Indossabili (PROTOTIPO 2): vestiti posseduti, equip a slot singolo ----
    // L'effetto (bonus stat in "Statistiche" sopra, o l'extra-cibo del Chef) scatta solo mentre
    // indossato. L'illustrazione sul pet e' RIMANDATA (serve arte): per ora solo testo + bottone.
    // LEGGENDE (decisione fondatore 28 lug 2026, "le leggende non dovrebbero poter indossare
    // vestiti": hanno un aspetto iconico da non alterare): qui blocchiamo SOLO la vista/equip —
    // la lista resta visibile come collezione posseduta, ma coi bottoni disabilitati e senza
    // listener di click, e "indossato" viene forzato a false a schermo qualunque sia il valore
    // sporco in state.indossato (salvataggio vecchio/reward/debug). Il bonus stat vero e proprio
    // si legge da bonusIndossato in missions.js, che QUI NON tocchiamo (v. report per dove sta).
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Armadio')));
    var petELeggenda = !!(pet && pet.razza === 'leggenda');
    var indossabili = Array.isArray(state.indossabili) ? state.indossabili : [];
    // Completi (vestiti a due pezzi, batch cosmetico — tabella dati COMPLETI_VESTITO in cima al
    // file): STESSA sezione Armadio, STESSO bottone Indossa/Togli e STESSA guardia leggenda dei
    // vestiti normali qui sotto — NESSUN secondo meccanismo. A differenza degli indossabili normali
    // (posseduto = nome dentro state.indossabili, un drop/acquisto per pet), un completo e'
    // "posseduto" quando completoDisponibile(state, nome) e' vero (STESSA regola negozio/supporter
    // di colore/stanza/cornice): niente elenco di nomi posseduti separato da salvare, i completi
    // sbloccati (o del Supporter) compaiono qui da soli.
    var completiPosseduti = [];
    for (var icv0 = 0; icv0 < COMPLETI_VESTITO.length; icv0++) {
      if (completoDisponibile(state, COMPLETI_VESTITO[icv0].nome)) completiPosseduti.push(COMPLETI_VESTITO[icv0].nome);
    }
    if (indossabili.length === 0 && completiPosseduti.length === 0) {
      pagina.appendChild(el('p', 'petq-scheda-vuoto', traduci('Nessun vestito ancora.')));
    } else {
      if (petELeggenda) {
        pagina.appendChild(el('p', 'petq-scheda-vuoto', traduci('Le leggende vestono solo il proprio mito.')));
      }
      var listaVestiti = el('div', 'petq-scheda-armadio');
      for (var iv = 0; iv < indossabili.length; iv++) {
        (function (nomeVestito) {
          // Leggenda: mai "indossato" a schermo, anche se state.indossato punta a questo vestito.
          var indossato = !petELeggenda && (state.indossato === nomeVestito);
          var riga = el('div', 'petq-scheda-vestito' + (indossato ? ' petq-vestito-indossato' : ''));
          var testoWrap = el('div', 'petq-vestito-testo');
          testoWrap.appendChild(el('div', 'petq-vestito-nome',
            (indossato ? '👕 ' : '') + traduci(nomeVestito)));
          // Effetto letto dal contenuto (v. nodiEffettiEquip): ogni capo dice cosa fa, anche i
          // 31 che prima restavano muti perche' non erano nella vecchia mappa scritta a mano.
          var effVestito = el('div', 'petq-vestito-effetto');
          effVestito.appendChild(nodiEffettiEquip(nomeVestito, 'indossabile'));
          testoWrap.appendChild(effVestito);
          riga.appendChild(testoWrap);
          var btn = el('button', 'petq-btn petq-btn-mini', indossato ? traduci('Togli') : traduci('Indossa'));
          if (petELeggenda) {
            btn.disabled = true;
          } else {
            btn.addEventListener('click', function () {
              state.indossato = indossato ? null : nomeVestito; // slot singolo: sostituisce
              if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
              mostraScheda(state); // ridisegna la scheda (stat aggiornate + stato equip)
            });
          }
          riga.appendChild(btn);
          listaVestiti.appendChild(riga);
        })(indossabili[iv]);
      }
      // Completi: STESSA identica riga (indossato/bottone/guardia leggenda) del ciclo sopra, unica
      // differenza la provenienza del nome (completiPosseduti invece di state.indossabili) —
      // nodiEffettiEquip('indossabile') su un nome senza voce in content/arredi.md ripiega da solo
      // sul testo generico "indossabile" (v. voceEquipContenuto), che e' la verita': i completi
      // sono cosmetici puri e non danno alcun effetto.
      for (var icv1 = 0; icv1 < completiPosseduti.length; icv1++) {
        (function (nomeVestito) {
          var indossato = !petELeggenda && (state.indossato === nomeVestito);
          var riga = el('div', 'petq-scheda-vestito' + (indossato ? ' petq-vestito-indossato' : ''));
          var testoWrap = el('div', 'petq-vestito-testo');
          testoWrap.appendChild(el('div', 'petq-vestito-nome',
            (indossato ? '👕 ' : '') + traduci(nomeVestito)));
          var effVestito = el('div', 'petq-vestito-effetto');
          effVestito.appendChild(nodiEffettiEquip(nomeVestito, 'indossabile'));
          testoWrap.appendChild(effVestito);
          riga.appendChild(testoWrap);
          var btn = el('button', 'petq-btn petq-btn-mini', indossato ? traduci('Togli') : traduci('Indossa'));
          if (petELeggenda) {
            btn.disabled = true;
          } else {
            btn.addEventListener('click', function () {
              state.indossato = indossato ? null : nomeVestito; // slot singolo: sostituisce
              if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
              mostraScheda(state); // ridisegna la scheda (stat aggiornate + stato equip)
            });
          }
          riga.appendChild(btn);
          listaVestiti.appendChild(riga);
        })(completiPosseduti[icv1]);
      }
      pagina.appendChild(listaVestiti);
    }

    // ---- Colore (varianti cromatiche, batch cosmetici — tabella dati COLORI_PET in cima al
    // file): riga di quadratini, uno per indice 0..7, col colore VERO disegnato dal pet stesso
    // (creaAnteprimaColore -> PETQ.sprites.draw, mai palette duplicate a mano). Quello attivo ha
    // un contorno dorato; i non disponibili sono spenti (opacita' ridotta) col titolo che dice
    // dove si sbloccano. LEGGENDE: aspetto fisso, resolvePet ignora parts.colore per
    // razza=='leggenda' -> il colore non avrebbe ALCUN effetto visivo, quindi qui blocchiamo
    // l'intera sezione (stesso spirito di Armadio/Armeria bloccati per le leggende, ma senza
    // mostrare quadratini che sembrerebbero tutti "rotti").
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Colore')));
    if (petELeggenda) {
      pagina.appendChild(el('p', 'petq-scheda-vuoto', traduci('Le leggende hanno un colore fisso.')));
    } else {
      var rigaColori = el('div');
      rigaColori.style.display = 'flex';
      rigaColori.style.flexWrap = 'wrap';
      rigaColori.style.gap = '6px';
      var coloreAttuale = (pet.parts && typeof pet.parts.colore === 'number') ? pet.parts.colore : 0;
      for (var ic = 0; ic < COLORI_PET.length; ic++) {
        (function (voceColore) {
          var attivo = coloreAttuale === voceColore.indice;
          var disponibile = coloreDisponibile(state, voceColore.indice);
          var swatch = creaAnteprimaColore(pet, voceColore.indice);
          swatch.style.width = '40px';
          swatch.style.height = '40px';
          swatch.style.imageRendering = 'pixelated';
          swatch.style.boxSizing = 'border-box';
          swatch.style.cursor = 'pointer';
          swatch.style.border = attivo ? '3px solid #ffd54a' : '2px solid rgba(255,255,255,0.25)';
          swatch.style.opacity = disponibile ? '1' : '0.35';
          swatch.title = disponibile ? traduci(voceColore.nome)
            : (traduci(voceColore.nome) + ' — ' + traduci(ORIGINE_COLORE_LABEL[voceColore.tipo]));
          swatch.addEventListener('click', function () {
            if (!disponibile) {
              // Comprabile (negozio/supporter): salto diretto al Negozio sulla sezione giusta
              // (richiesta fondatore 24 ago 2026). 'base' resta un toast: non e' in vendita, e'
              // il colore di nascita di un altro pet (v. ORIGINE_COLORE_TESTO sopra).
              if (voceColore.tipo === 'negozio' || voceColore.tipo === 'supporter') {
                chiudiSchedaEApriNegozio(voceColore.tipo === 'supporter' ? 'sostieni' : 'guardaroba');
                return;
              }
              mostraToast(traduci(voceColore.nome) + traduci(ORIGINE_COLORE_TESTO[voceColore.tipo]));
              return;
            }
            if (!pet.parts) pet.parts = {};
            pet.parts.colore = voceColore.indice; // cambio gratuito e reversibile
            if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
            if (PETQ.audio) PETQ.audio.suona('apri');
            disegnaStanzaEPet(state); // il pet in stanza riflette subito il nuovo colore
            mostraScheda(state); // ridisegna la scheda (contorno attivo aggiornato)
          });
          rigaColori.appendChild(swatch);
        })(COLORI_PET[ic]);
      }
      pagina.appendChild(rigaColori);
    }

    // ---- Stanze (skin cosmetiche della stanza, batch cosmetici — tabella dati SKIN_STANZE in
    // cima al file, STESSO SCHEMA della sezione Colore sopra): riga di anteprime, una per tema.
    // Ogni anteprima e' la STANZA VERA in miniatura (creaAnteprimaStanza -> PETQ.rooms.draw sul
    // salone, mai una tinta disegnata a mano). Quella attiva (temaStanzaCorrente, che tiene conto
    // del ripiego su razza) ha il contorno dorato; le non disponibili sono spente col titolo che
    // dice dove si sbloccano; tap su una disponibile cambia state.skinAttiva e ridisegna subito
    // la stanza, tap su una bloccata spiega col toast senza cambiare nulla.
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Stanze')));
    var rigaStanze = el('div');
    rigaStanze.style.display = 'flex';
    rigaStanze.style.flexWrap = 'wrap';
    rigaStanze.style.gap = '6px';
    var temaAttivo = temaStanzaCorrente(state);
    for (var is2 = 0; is2 < SKIN_STANZE.length; is2++) {
      (function (voceSkin) {
        var attivoSkin = temaAttivo === voceSkin.id;
        var disponibileSkin = skinDisponibile(state, voceSkin.id);
        var anteprima = creaAnteprimaStanza(voceSkin.id);
        anteprima.style.width = '72px';
        anteprima.style.aspectRatio = anteprima.width + ' / ' + anteprima.height;
        anteprima.style.imageRendering = 'pixelated';
        anteprima.style.boxSizing = 'border-box';
        anteprima.style.cursor = 'pointer';
        anteprima.style.border = attivoSkin ? '3px solid #ffd54a' : '2px solid rgba(255,255,255,0.25)';
        anteprima.style.opacity = disponibileSkin ? '1' : '0.35';
        anteprima.title = disponibileSkin ? traduci(voceSkin.nome)
          : (traduci(voceSkin.nome) + ' — ' + traduci(ORIGINE_SKIN_LABEL[voceSkin.tipo]));
        anteprima.addEventListener('click', function () {
          if (!disponibileSkin) {
            // Comprabile (negozio/supporter): salto diretto al Negozio sulla sezione giusta
            // (richiesta fondatore 24 ago 2026). 'razza' non arriva mai qui (sempre disponibile).
            if (voceSkin.tipo === 'negozio' || voceSkin.tipo === 'supporter') {
              chiudiSchedaEApriNegozio(voceSkin.tipo === 'supporter' ? 'sostieni' : 'arredi');
              return;
            }
            mostraToast(traduci(voceSkin.nome) + traduci(ORIGINE_SKIN_TESTO[voceSkin.tipo]));
            return;
          }
          state.skinAttiva = voceSkin.id; // cambio gratuito e reversibile, come il colore
          if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
          if (PETQ.audio) PETQ.audio.suona('apri');
          disegnaStanzaEPet(state); // la stanza vera riflette subito la nuova skin
          mostraScheda(state); // ridisegna la scheda (contorno attivo aggiornato)
        });
        rigaStanze.appendChild(anteprima);
      })(SKIN_STANZE[is2]);
    }
    pagina.appendChild(rigaStanze);

    // ---- Cornice (cornici cosmetiche della cartolina esito, batch cosmetici — tabella dati
    // CORNICI_CARTOLINA in cima al file, STESSO SCHEMA delle sezioni Colore/Stanze sopra): riga di
    // anteprime, ognuna la CARTOLINA VERA in miniatura (creaAnteprimaCornice -> sprites.
    // drawCartolina sulla scena fissa 'std_sociale' col pet corrente, mai un campione disegnato a
    // mano), piu' una prima voce 'Nessuna' per tornare senza cornice. Quella attiva
    // (corniceCorrente, che tiene conto del ripiego se il Supporter si spegne) ha il contorno
    // dorato; le non disponibili sono spente col titolo che dice dove si sbloccano; tap su una
    // disponibile cambia state.corniceAttiva e ridisegna la scheda, tap su una bloccata spiega col
    // toast senza cambiare nulla. Nessun gate leggenda qui (a differenza di Colore): la cornice sta
    // sulla cartolina, non sul pet, quindi vale anche per le leggende.
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Cornice')));
    var rigaCornici = el('div');
    rigaCornici.style.display = 'flex';
    rigaCornici.style.flexWrap = 'wrap';
    rigaCornici.style.gap = '6px';
    var corniceAttuale = corniceCorrente(state);

    var tileNessuna = creaAnteprimaCornice(state, null);
    tileNessuna.style.width = '72px';
    tileNessuna.style.aspectRatio = tileNessuna.width + ' / ' + tileNessuna.height;
    tileNessuna.style.imageRendering = 'pixelated';
    tileNessuna.style.boxSizing = 'border-box';
    tileNessuna.style.cursor = 'pointer';
    tileNessuna.style.border = (!corniceAttuale) ? '3px solid #ffd54a' : '2px solid rgba(255,255,255,0.25)';
    tileNessuna.title = traduci('Nessuna');
    tileNessuna.addEventListener('click', function () {
      state.corniceAttiva = null; // cambio gratuito e reversibile, come colore/stanza
      if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
      if (PETQ.audio) PETQ.audio.suona('apri');
      mostraScheda(state); // ridisegna la scheda (contorno attivo aggiornato)
    });
    rigaCornici.appendChild(tileNessuna);

    for (var icn = 0; icn < CORNICI_CARTOLINA.length; icn++) {
      (function (voceCornice) {
        var attivaCornice = corniceAttuale === voceCornice.id;
        var disponibileCornice = corniceDisponibile(state, voceCornice.id);
        var anteprimaCornice = creaAnteprimaCornice(state, voceCornice.id);
        anteprimaCornice.style.width = '72px';
        anteprimaCornice.style.aspectRatio = anteprimaCornice.width + ' / ' + anteprimaCornice.height;
        anteprimaCornice.style.imageRendering = 'pixelated';
        anteprimaCornice.style.boxSizing = 'border-box';
        anteprimaCornice.style.cursor = 'pointer';
        anteprimaCornice.style.border = attivaCornice ? '3px solid #ffd54a' : '2px solid rgba(255,255,255,0.25)';
        anteprimaCornice.style.opacity = disponibileCornice ? '1' : '0.35';
        anteprimaCornice.title = disponibileCornice ? traduci(voceCornice.nome)
          : (traduci(voceCornice.nome) + ' — ' + traduci(ORIGINE_SKIN_LABEL[voceCornice.tipo]));
        anteprimaCornice.addEventListener('click', function () {
          if (!disponibileCornice) {
            // Comprabile (negozio/supporter, uniche due 'tipo' possibili per le cornici — nessun
            // 'base' qui): salto diretto al Negozio sulla sezione giusta (richiesta fondatore 24
            // ago 2026).
            chiudiSchedaEApriNegozio(voceCornice.tipo === 'supporter' ? 'sostieni' : 'arredi');
            return;
          }
          state.corniceAttiva = voceCornice.id; // cambio gratuito e reversibile
          if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
          if (PETQ.audio) PETQ.audio.suona('apri');
          mostraScheda(state); // ridisegna la scheda (contorno attivo aggiornato)
        });
        rigaCornici.appendChild(anteprimaCornice);
      })(CORNICI_CARTOLINA[icn]);
    }
    pagina.appendChild(rigaCornici);

    // ---- Armeria (FASE SPRITE): armi possedute, equip a slot singolo, gated dal perk Weapon Wielder ----
    // Le armi sono arredi normali (nessun campo dedicato nel save): raccogliamo i nomi dai posseduti
    // + i piazzati in ogni stanza, filtrando ARMI_SET, con dedup. L'equip (state.armaEquip) da' un
    // bonus Forza (bonusArmaEquip in missions.js) e si vede sul pet (drawOverlayEquip). Gate: senza
    // il perk weaponwielder mostriamo le armi ma senza bottoni + un messaggio bloccato.
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Armeria')));
    var armiViste = {};
    var armiPossedute = [];
    (function () {
      var srcPoss = (state.arredi && Array.isArray(state.arredi.posseduti)) ? state.arredi.posseduti : [];
      for (var ip = 0; ip < srcPoss.length; ip++) {
        var nmP = srcPoss[ip] && srcPoss[ip].nome;
        if (nmP && ARMI_SET[nmP] && !armiViste[nmP]) { armiViste[nmP] = 1; armiPossedute.push(nmP); }
      }
      var piaz = (state.arredi && state.arredi.piazzati) ? state.arredi.piazzati : {};
      var stanze = ['cucina', 'bagno', 'salone', 'camera'];
      for (var is = 0; is < stanze.length; is++) {
        var lst = piaz[stanze[is]];
        if (!Array.isArray(lst)) continue;
        for (var ii = 0; ii < lst.length; ii++) {
          var nmR = lst[ii] && lst[ii].nome;
          if (nmR && ARMI_SET[nmR] && !armiViste[nmR]) { armiViste[nmR] = 1; armiPossedute.push(nmR); }
        }
      }
    })();
    var haWeaponWielder = Array.isArray(state.perks) && state.perks.indexOf('weaponwielder') !== -1;
    if (armiPossedute.length === 0) {
      pagina.appendChild(el('p', 'petq-scheda-vuoto', traduci('Nessun\'arma ancora.')));
    } else {
      if (!haWeaponWielder) {
        pagina.appendChild(el('p', 'petq-scheda-vuoto', traduci('Serve il perk Weapon Wielder per equipaggiare le armi.')));
      }
      var listaArmi = el('div', 'petq-scheda-armadio');
      for (var ia = 0; ia < armiPossedute.length; ia++) {
        (function (nomeArma) {
          var impugnata = state.armaEquip === nomeArma;
          var riga = el('div', 'petq-scheda-vestito' + (impugnata ? ' petq-vestito-indossato' : ''));
          var testoWrap = el('div', 'petq-vestito-testo');
          testoWrap.appendChild(el('div', 'petq-vestito-nome',
            (impugnata ? '⚔️ ' : '') + traduci(nomeArma)));
          var effArma = el('div', 'petq-vestito-effetto');
          effArma.appendChild(nodiEffettiEquip(nomeArma, 'arma'));
          testoWrap.appendChild(effArma);
          riga.appendChild(testoWrap);
          if (haWeaponWielder) {
            var btn = el('button', 'petq-btn petq-btn-mini', impugnata ? traduci('Togli') : traduci('Equipaggia'));
            btn.addEventListener('click', function () {
              if (!impugnata) {
                // Regola fondatore "se impugnata deve sparire dalla casa": un'arma sta O in casa
                // O in mano. Se e' piazzata in una stanza, equipaggiarla la RIPONE (torna nei
                // posseduti, sparisce dalla stanza e il suo passivo da piazzata cessa).
                if (PETQ.arredi && PETQ.arredi.rimuovi) PETQ.arredi.rimuovi(state, nomeArma);
              }
              state.armaEquip = impugnata ? null : nomeArma; // slot singolo: sostituisce
              if (PETQ.save && PETQ.save.save) PETQ.save.save(state);
              mostraScheda(state); // ridisegna (stat aggiornate + stato equip)
            });
            riga.appendChild(btn);
          }
          listaArmi.appendChild(riga);
        })(armiPossedute[ia]);
      }
      pagina.appendChild(listaArmi);
    }

    // ---- Pensione + Pianeta dei ritirati (PROTOTIPO 2, versione base P2) ----
    pagina.appendChild(el('h3', 'petq-scheda-sezione', traduci('Pensione')));
    var azioniPensione = el('div', 'petq-scheda-pensione-azioni');

    var nPensionati = Array.isArray(state.pensionati) ? state.pensionati.length : 0;
    var galleriaBtn = el('button', 'petq-btn petq-btn-mini', traduci('🪐 Pianeta dei ritirati (') + nPensionati + ')');
    galleriaBtn.addEventListener('click', function () { mostraPianetaRitirati(state); });
    azioniPensione.appendChild(galleriaBtn);

    // "Manda in pensione" e' PERMANENTE -> conferma a due tap (riusa il pattern di vendiConferma).
    // primo tap: il bottone diventa "Sicuro? È per sempre — ritocca per confermare" con stile
    // d'allerta; secondo tap: procede (chiude la scheda e avvia il flusso ritiro -> scelta razza).
    var pensioneBtn = el('button', 'petq-btn petq-btn-mini' + (pensioneConferma ? ' petq-btn-conferma' : ''),
      pensioneConferma ? traduci('Sicuro? È per sempre — ritocca per confermare') : traduci('Manda in pensione 🪐'));
    pensioneBtn.addEventListener('click', function () {
      if (!pensioneConferma) {
        pensioneConferma = true;
        pensioneBtn.textContent = traduci('Sicuro? È per sempre — ritocca per confermare');
        pensioneBtn.classList.add('petq-btn-conferma');
        return;
      }
      pensioneConferma = false;
      overlay.remove();
      avviaPensione(state);
    });
    azioniPensione.appendChild(pensioneBtn);
    pagina.appendChild(azioniPensione);

    var chiudiBtn = el('button', 'petq-btn petq-btn-primario', traduci('Chiudi'));
    chiudiBtn.addEventListener('click', function () {
      if (PETQ.audio) PETQ.audio.suona('chiudi');
      overlay.remove();
    });
    pagina.appendChild(chiudiBtn);

    // Build stamp (richiesta fondatore): riga discreta in fondo alla scheda con la versione
    // corrente, cosi' i tester sanno subito su quale build stanno giocando senza aprire la
    // console. window.PETQ_BUILD lo definisce index.html (regista): qui solo lettura + fallback.
    pagina.appendChild(el('div', 'petq-scheda-build', 'build ' + (window.PETQ_BUILD || '?')));

    // Riga OTA (24 ago 2026, dopo il "rimane sempre 280" indiagnosticabile senza cavo USB):
    // stato del canale aggiornamenti + bottone per forzare il check, SOLO dove il plugin esiste
    // (telefono). Sul browser il canale non c'e' e la riga non compare. Cosi' la prossima volta
    // il telefono DICE cos'ha fatto l'OTA invece di lasciarci a teorizzare.
    if (PETQ.ota && PETQ.ota.stato && PETQ.ota.stato().pluginPresente) {
      var rigaOta = el('div', 'petq-scheda-build');
      function testoRigaOta() {
        var s = PETQ.ota.stato();
        var quando = s.ultimoCheck ? new Date(s.ultimoCheck) : null;
        var ora = quando
          ? (quando.getHours() < 10 ? '0' : '') + quando.getHours() + ':' + (quando.getMinutes() < 10 ? '0' : '') + quando.getMinutes()
          : traduci('mai');
        var righe = traduci('aggiornamenti: ') + ora + ' · ' + (s.ultimoEsito || traduci('nessun esito'));
        if (s.inAttesa) righe += ' · ' + traduci('in attesa: ') + 'v' + s.inAttesa;
        return righe;
      }
      rigaOta.textContent = testoRigaOta();
      pagina.appendChild(rigaOta);

      var btnOta = el('button', 'petq-btn petq-btn-mini', traduci('Controlla aggiornamenti'));
      btnOta.addEventListener('click', function () {
        btnOta.disabled = true;
        PETQ.ota.controlla(true, function (r) {
          btnOta.disabled = false;
          rigaOta.textContent = testoRigaOta();
          if (r.esito === 'scaricato') mostraToast(traduci('Aggiornamento scaricato: si applica al prossimo riavvio.'));
          else if (r.esito === 'aggiornato') mostraToast(traduci('Sei già all\'ultima versione.'));
          else mostraToast(traduci('Controllo non riuscito.') + (r.dettaglio ? ' (' + String(r.dettaglio && r.dettaglio.message ? r.dettaglio.message : r.dettaglio).slice(0, 80) + ')' : ''));
        });
      });
      pagina.appendChild(btnOta);
    }

    // Contatore giorni della CASA (fondatore, 31 lug 2026): da quando l'orologio HUD in alto e'
    // passato a mostrare l'ETA' DEL PET (v. costruisciOrologioHud), il vecchio contatore
    // state.giornoGioco - che non si azzera mai al cambio pet e regge sotto al cofano TUTTI i
    // cancelli giornalieri del gioco (missioni, carte, lavoro, talenti, streak, cuoco, canto...),
    // QUI NON TOCCATO - non aveva piu' un posto a schermo. Riga discreta qui, stessa zona/stile
    // delle info di servizio della riga build sopra (stessa classe, niente CSS nuovo).
    var giorniCasa = (PETQ.clock && PETQ.clock.giornoCorrente ? PETQ.clock.giornoCorrente(state) : 0) + 1;
    pagina.appendChild(el('div', 'petq-scheda-build', traduci('casa: ') + giorniCasa + traduci(' giorni')));

    overlay.appendChild(pagina);
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) overlay.remove();
    });

    document.body.appendChild(overlay);
  }

  // slot nei testi esito: {oggetto} = il primo arredo/arma dei reward (tutorial M0), {nome} = pet
  function risolviSlotEsito(testo, esito) {
    if (!testo) return '';
    var oggetto = traduci('un regalo');
    for (var i = 0; i < ((esito && esito.rewards) || []).length; i++) {
      var rw = esito.rewards[i];
      if (rw.tipo === 'arredo' || rw.tipo === 'arma') { oggetto = traduci(rw.nome); break; }
    }
    return testo
      .replace(/\{oggetto\}/g, oggetto)
      .replace(/\{nome\}/g, (currentState && currentState.pet && currentState.pet.nome) || '...');
  }

  function rigaReward(rw) {
    var riga = el('div', 'petq-reward-riga');

    var icona = document.createElement('canvas');
    icona.width = 12;
    icona.height = 12;
    icona.className = 'petq-reward-icona';
    if (rw.tipo === 'cibo') {
      disegnaCibo(icona, trovaCibo(rw.nome) || { nome: rw.nome, categoria: 'base' });
    } else if (rw.tipo === 'arredo' || rw.tipo === 'arma' || rw.tipo === 'tutteArmi' ||
               rw.tipo === 'allenatore' || rw.tipo === 'giocattolo') {
      // oggetti fisici che finiscono nelle "tue cose": stesso quadratino dorato degli arredi
      disegnaQuadratino(icona, '#c8a25a');
    } else if (rw.tipo === 'perk') {
      disegnaQuadratino(icona, '#3ee6d0');
    } else {
      disegnaQuadratino(icona, rw.tipo === 'ferite' ? '#e85a5a' : '#8a94a0');
    }
    riga.appendChild(icona);

    riga.appendChild(el('span', 'petq-reward-testo', formattaRewardOggetto(rw)));
    return riga;
  }

  function disegnaQuadratino(canvas, colore) {
    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    g.clearRect(0, 0, canvas.width, canvas.height);
    g.fillStyle = '#1e242e';
    g.fillRect(1, 1, 10, 10);
    g.fillStyle = colore;
    g.fillRect(2, 2, 8, 8);
    g.fillStyle = 'rgba(255,255,255,0.55)';
    g.fillRect(3, 3, 2, 1);
  }

  function segno(n) {
    return (n > 0 ? '+' : '') + n;
  }

  // token reward della scheda (anteprima rosa) -> testo leggibile
  function formattaRewardToken(token) {
    var t = (token || '').trim();
    var m = t.match(/^(forza|intelligenza|int|velocita|carisma)\s*([+-]\d+)$/i);
    if (m) {
      // alias 'int' (usato nelle Dati: es. int+2) -> stessa label di intelligenza
      var statTok = m[1].toLowerCase() === 'int' ? 'intelligenza' : m[1].toLowerCase();
      return segno(parseInt(m[2], 10)) + ' ' + traduci(STAT_LABEL[statTok]);
    }
    m = t.match(/^fel\s*([+-]\d+)$/i);
    if (m) return segno(parseInt(m[1], 10)) + ' ' + traduci('Felicità');
    m = t.match(/^monete\s*([+-]\d+)$/i);
    if (m) return segno(parseInt(m[1], 10)) + traduci(' monete');
    m = t.match(/^igiene\s*([+-]\d+)$/i);
    if (m) return segno(parseInt(m[1], 10)) + ' ' + traduci('Igiene');
    m = t.match(/^ferite\s*([+-]\d+)$/i);
    if (m) return segno(parseInt(m[1], 10)) + ' ' + traduci('Ferite');
    m = t.match(/^cibo:(.+)$/i);
    if (m) return traduci(m[1].trim()) + traduci(' (cibo)');
    m = t.match(/^arredo:(.+)$/i);
    if (m) return traduci(m[1].trim()) + traduci(' (arredo)');
    m = t.match(/^indossabile:(.+)$/i);
    if (m) return traduci(m[1].trim()) + traduci(' (indossabile)');
    m = t.match(/^giocattolo:(.+)$/i);
    if (m) return traduci(m[1].trim()) + traduci(' (giocattolo)');
    if (/^armaCasuale$/i.test(t)) return traduci("Un'arma misteriosa");
    if (/^tutteArmi$/i.test(t)) return traduci('Tutte le armi');
    m = t.match(/^allenatore:(7g|perm)$/i);
    if (m) return m[1].toLowerCase() === '7g' ? traduci('Allenatore (7 giorni)') : traduci('Allenatore personale');
    m = t.match(/^perk:(\w+)$/i);
    if (m) {
      var pkKey = m[1].toLowerCase();
      return traduci('Perk ') + (traduci(PERK_LABEL[pkKey]) || capitalize(pkKey));
    }
    if (/^rimborsoCosto$/i.test(t)) return traduci('Rimborso del costo');
    return t;
  }

  // reward applicato (oggetto da missions.risolvi) -> testo leggibile
  function formattaRewardOggetto(rw) {
    if (!rw) return '';
    switch (rw.tipo) {
      case 'stat': return segno(rw.valore) + ' ' + (traduci(STAT_LABEL[rw.stat]) || rw.stat);
      case 'felicita': return segno(rw.valore) + ' ' + traduci('Felicità');
      case 'monete': return segno(rw.valore) + traduci(' monete');
      case 'igiene': return segno(rw.valore) + ' ' + traduci('Igiene');
      case 'ferite': return segno(rw.valore) + ' ' + traduci('Ferite');
      case 'arredo': return traduci(rw.nome) + traduci(' (arredo)');
      case 'arma': return traduci(rw.nome) + traduci(' (arredo)');
      case 'indossabile': return traduci(rw.nome) + traduci(' (indossabile)');
      case 'giocattolo': return traduci(rw.nome) + traduci(' (giocattolo)');
      case 'cibo': return traduci(rw.nome) + traduci(' (in dispensa)');
      case 'tutteArmi': return traduci('Tutte le armi: ') + (rw.nomi || []).map(traduci).join(', ');
      case 'allenatore': return rw.durata === '7g' ? traduci('Il Topo allenatore (7 giorni)') : traduci('Il Topo allenatore (permanente)');
      case 'perk': return traduci('Perk ') + (traduci(PERK_LABEL[rw.perk]) || capitalize(rw.perk)) + traduci(' sbloccato');
      case 'rimborso': return traduci('Rimborso: ') + rw.valore + traduci(' monete');
      default: return traduci(rw.nome) || rw.tipo || '';
    }
  }

  // cartolina esito: API grafica con guard; fallback = tinta di categoria + pet al centro.
  // cornice (opzionale, batch cosmetico) passa dritta a sprites.drawCartolina: id sconosciuto o
  // assente = nessuna cornice, comportamento identico a prima di questo batch.
  function disegnaCartolina(canvas, scenaId, petLike, cornice) {
    if (PETQ.sprites && PETQ.sprites.drawCartolina) {
      PETQ.sprites.drawCartolina(canvas, scenaId, petLike, cornice);
      return;
    }
    var g = canvas.getContext('2d');
    g.imageSmoothingEnabled = false;
    var tinta = tintaScena(scenaId);
    g.fillStyle = tinta.sfondo;
    g.fillRect(0, 0, ROOM_W, ROOM_H);
    g.fillStyle = tinta.terra;
    g.fillRect(0, 46, ROOM_W, ROOM_H - 46);

    var pc = document.createElement('canvas');
    pc.width = PET_PX;
    pc.height = PET_PX;
    PETQ.sprites.draw(pc, petLike, { frame: 0 });
    g.drawImage(pc, Math.round((ROOM_W - PET_PX) / 2), 46 - PET_PX + 6);
  }

  function tintaScena(scenaId) {
    var id = scenaId || '';
    if (id.indexOf('fail') === 0) return TINTE_SCENA.fail;
    if (id.indexOf('super') === 0) return TINTE_SCENA.superSc;
    var m = id.match(/^std_(\w+)$/);
    if (m && TINTE_SCENA[m[1]]) return TINTE_SCENA[m[1]];
    return TINTE_SCENA.generica;
  }

  // ==================== DEBUG PANEL ====================

  function debugAttivo() {
    return location.search.indexOf('debug') !== -1;
  }

  function montaDebugPanel() {
    if (!debugAttivo()) return;

    // Marca il body quando il pannello debug e' montato: il pannello e' position:fixed in fondo
    // allo schermo e coprirebbe la fine del contenuto, quindi SOLO in debug #app tiene i 90px di
    // padding-bottom di sicurezza (v. style.css). Nel gioco vero quei 90px erano spazio morto in
    // ogni schermata: con la stanza diventata piu' profonda servivano al contenuto, non al vuoto.
    if (document.body.className.indexOf('petq-con-debug') < 0) {
      document.body.className = (document.body.className + ' petq-con-debug').trim();
    }
    var esistente = document.getElementById('petq-debug');
    if (esistente) esistente.remove();

    var panel = el('div', 'petq-debug');
    panel.id = 'petq-debug';

    // MODALITA' CIAK (richiesta fondatore per le clip social, 4 ago 2026): il pannello prende
    // mezzo schermo e rovina le registrazioni. Il bottone qui sotto (o il tasto D) lo nasconde
    // TUTTO — compreso il padding-bottom del body che esiste solo per lui — e lascia un puntino
    // semitrasparente in basso a destra per richiamarlo. Il puntino e' l'unico compromesso:
    // sparire del tutto senza via di ritorno significherebbe ricaricare la pagina e perdere la
    // scena preparata. Stato in variabile di modulo (debugPanelNascosto): se qualcosa rimonta il
    // pannello a meta' ripresa, resta nascosto.
    function applicaVisibilitaDebug() {
      var riapri = document.getElementById('petq-debug-riapri');
      panel.style.display = debugPanelNascosto ? 'none' : '';
      if (riapri) riapri.style.display = debugPanelNascosto ? 'block' : 'none';
      // il padding di sicurezza serve SOLO col pannello visibile (v. commento sopra)
      var cls = document.body.className.replace(/\s*petq-con-debug\s*/g, ' ').trim();
      document.body.className = debugPanelNascosto ? cls : (cls + ' petq-con-debug').trim();
    }
    var ciakBtn = el('button', 'petq-btn petq-btn-mini', '🎬 Nascondi per registrare (tasto D)');
    ciakBtn.addEventListener('click', function () { debugPanelNascosto = true; applicaVisibilitaDebug(); });
    panel.appendChild(ciakBtn);

    // ATTREZZO DI SCENA "di' la parola" (v. recitaParolaScena per il perche' di ogni scelta).
    // Il campo e' a TESTO LIBERO e la parola NON serve che sia stata insegnata al pet: la clip 2
    // e' MID, le prossime saranno SKILL ISSUE, -1000 AURA, LEEROY JENKINS.
    var scenaLabel = el('span', 'petq-debug-label', 'Scena:');
    panel.appendChild(scenaLabel);

    var parolaInput = document.createElement('input');
    parolaInput.type = 'text';
    parolaInput.id = 'petq-debug-parola-scena';
    parolaInput.value = parolaScena;
    parolaInput.placeholder = 'parola di scena';
    parolaInput.title = 'P = la dice · Shift+P = la canta · Invio = la dice';
    parolaInput.style.cssText = 'width:120px;font-family:inherit;font-size:12px;padding:3px 6px;' +
      'border:1px solid #4a3f66;border-radius:4px;background:#1a1626;color:#efe6d2;';
    parolaInput.addEventListener('input', function () { parolaScena = parolaInput.value; });
    // Invio = "dilla": si scrive la parola nuova e si gira subito, senza tornare col mouse sul
    // bottone. blur() prima, o il campo resta col fuoco e il tasto P finisce dentro al campo.
    parolaInput.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter') return;
      e.preventDefault();
      parolaInput.blur();
      recitaParolaScena(false);
    });
    panel.appendChild(parolaInput);

    // Pronuncia per la voce (v. pronunciaScena): la bolla mostra la parola qui sopra, la voce
    // dice questa. Serve per l'inglese: la sintesi legge all'italiana, "SKILL ISSUE" va scritto
    // "schil isciu". Vuoto = dice la parola com'e' scritta.
    var pronunciaInput = document.createElement('input');
    pronunciaInput.type = 'text';
    pronunciaInput.id = 'petq-debug-pronuncia-scena';
    pronunciaInput.value = pronunciaScena;
    pronunciaInput.placeholder = 'pronuncia (vuota = come scritta)';
    pronunciaInput.title = 'La voce dice QUESTA, la bolla mostra la parola. Per l\'inglese: SKILL ISSUE -> schil isciu';
    pronunciaInput.style.cssText = 'width:150px;font-family:inherit;font-size:12px;padding:3px 6px;' +
      'border:1px solid #4a3f66;border-radius:4px;background:#1a1626;color:#bfb4d8;';
    pronunciaInput.addEventListener('input', function () { pronunciaScena = pronunciaInput.value; });
    pronunciaInput.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter') return;
      e.preventDefault();
      pronunciaInput.blur();
      recitaParolaScena(false);
    });
    panel.appendChild(pronunciaInput);

    var diciBtn = el('button', 'petq-btn petq-btn-mini', '🗣 Dì (P)');
    diciBtn.addEventListener('click', function () { recitaParolaScena(false); });
    panel.appendChild(diciBtn);

    var cantaBtn = el('button', 'petq-btn petq-btn-mini', '🎵 Canta (Shift+P)');
    cantaBtn.addEventListener('click', function () { recitaParolaScena(true); });
    panel.appendChild(cantaBtn);

    // Interruttore del set silenzioso: OFF = il pet recita solo su cue (default sul set), ON =
    // battute spontanee come nel gioco vero, che in QA servono ancora.
    function etichettaSpontanee() { return setSilenzioso ? '🤐 Battute spontanee: OFF' : '💬 Battute spontanee: ON'; }
    var spontaneeBtn = el('button', 'petq-btn petq-btn-mini', etichettaSpontanee());
    spontaneeBtn.addEventListener('click', function () {
      setSilenzioso = !setSilenzioso;
      spontaneeBtn.textContent = etichettaSpontanee();
    });
    panel.appendChild(spontaneeBtn);

    if (!document.getElementById('petq-debug-riapri')) {
      var riapri = document.createElement('button');
      riapri.id = 'petq-debug-riapri';
      riapri.textContent = '🛠';
      riapri.title = 'Rimostra il pannello debug (tasto D)';
      riapri.style.cssText = 'position:fixed;bottom:8px;right:8px;z-index:2000;width:30px;height:30px;' +
        'border-radius:50%;border:1px solid #4a3f66;background:rgba(26,22,38,.55);color:#bfb4d8;' +
        'font-size:14px;cursor:pointer;display:none;padding:0;line-height:1;';
      riapri.addEventListener('click', function () { debugPanelNascosto = false; applicaVisibilitaDebug(); });
      document.body.appendChild(riapri);
      // il tasto D come scorciatoia da set (solo PC, solo con ?debug): ignorato mentre si scrive
      // in un campo di testo, o insegnare una parola al pet diventerebbe impossibile.
      document.addEventListener('keydown', function (e) {
        if (e.key !== 'd' && e.key !== 'D') return;
        var t = e.target && e.target.tagName;
        if (t === 'INPUT' || t === 'TEXTAREA') return;
        debugPanelNascosto = !debugPanelNascosto;
        applicaVisibilitaDebug();
      });

      // P = il pet DICE la parola di scena, Shift+P = la CANTA (brief regia round 4). Registrato
      // nello stesso blocco "una volta sola" del tasto D: montaDebugPanel viene richiamata ad ogni
      // cambio schermata, e un listener per rimontaggio significherebbe dieci voci sovrapposte al
      // primo take. Si guarda e.shiftKey e non e.key === 'P' perche' col BLOC MAIUSC attivo la
      // lettera arriva maiuscola senza che nessuno abbia premuto Shift. Ctrl/Alt/Cmd esclusi:
      // Ctrl+P e' la stampa del browser.
      document.addEventListener('keydown', function (e) {
        if (!e.key || e.key.toLowerCase() !== 'p') return;
        if (e.ctrlKey || e.altKey || e.metaKey) return;
        var tag = e.target && e.target.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA') return; // si sta scrivendo, anche nel campo qui sopra
        e.preventDefault();
        recitaParolaScena(e.shiftKey);
      });
    }

    var velLabel = el('span', 'petq-debug-label', 'Velocità:');
    panel.appendChild(velLabel);
    [[1, '×1'], [60, '×60'], [600, '×600']].forEach(function (v) {
      var btn = el('button', 'petq-btn petq-btn-mini', v[1]);
      btn.addEventListener('click', function () { window.PETQ.debugTime = v[0]; });
      panel.appendChild(btn);
    });

    // Avanza tempo a scatti (richiesta fondatore 8 lug 2026: "un click = un'ora"): invoca il
    // tick reale (PETQ.main.tick) di N ore di gioco -> decadimento, orologio, eventuale nuovo
    // giorno, ciclo sonno, render, TUTTO come il ticking normale, senza aspettare.
    var tempoLabel = el('span', 'petq-debug-label', 'Avanza:');
    panel.appendChild(tempoLabel);
    [[1, '+1 ora'], [6, '+6 ore']].forEach(function (t) {
      var btn = el('button', 'petq-btn petq-btn-mini', t[1]);
      btn.addEventListener('click', function () {
        if (!currentState || !PETQ.main || !PETQ.main.tick) return;
        PETQ.main.tick(currentState, t[0]);
      });
      panel.appendChild(btn);
    });

    if (currentState && currentState.pet) {
      var statKeys = [['fame', 'Fame'], ['igiene', 'Igiene'], ['salute', 'Salute'], ['felicita', 'Felicità']];
      statKeys.forEach(function (sk) {
        var btnPiu = el('button', 'petq-btn petq-btn-mini', sk[1] + ' +20');
        btnPiu.addEventListener('click', function () {
          currentState.pet.stats[sk[0]] = Math.max(0, Math.min(100, currentState.pet.stats[sk[0]] + 20));
          PETQ.save.save(currentState);
          aggiornaHud(currentState);
        });
        panel.appendChild(btnPiu);

        var btnMeno = el('button', 'petq-btn petq-btn-mini', sk[1] + ' -20');
        btnMeno.addEventListener('click', function () {
          currentState.pet.stats[sk[0]] = Math.max(0, Math.min(100, currentState.pet.stats[sk[0]] - 20));
          PETQ.save.save(currentState);
          aggiornaHud(currentState);
        });
        panel.appendChild(btnMeno);
      });
    }

    var moneteBtn = el('button', 'petq-btn petq-btn-mini', '+100 monete');
    moneteBtn.addEventListener('click', function () {
      if (currentState) {
        currentState.coins += 100;
        PETQ.save.save(currentState);
        aggiornaHud(currentState);
        renderAzioni();
      }
    });
    panel.appendChild(moneteBtn);

    var poopBtn = el('button', 'petq-btn petq-btn-mini', 'Spawn poop');
    poopBtn.addEventListener('click', function () {
      if (currentState) {
        currentState.poop = Math.min(3, (currentState.poop || 0) + 1);
        PETQ.save.save(currentState);
        disegnaStanzaEPet(currentState);
        if (document.getElementById('petq-casa')) renderAzioni();
      }
    });
    panel.appendChild(poopBtn);

    // Insta ciccione (richiesta fondatore 8 lug 2026): forza/toglie l'aspetto ciccione per
    // testare lo sprite. corpo è derivato da pet.bodyVariant (non memorizzato), che diventa
    // 'ciccione' quando sovralimentazioniRecenti supera la soglia (teen) -> alzo/azzero quel
    // contatore (e i pasti, che pure concorrono) e ridisegno. Il ciccione esiste solo da teen.
    if (currentState && currentState.pet) {
      var giaCiccione = PETQ.pet && PETQ.pet.bodyVariant && PETQ.pet.bodyVariant(currentState.pet) === 'ciccione';
      var ciccioneBtn = el('button', 'petq-btn petq-btn-mini', giaCiccione ? 'Togli ciccione' : 'Insta ciccione');
      ciccioneBtn.addEventListener('click', function () {
        if (!currentState || !currentState.pet) return;
        var pet = currentState.pet;
        if (giaCiccione) {
          pet.sovralimentazioniRecenti = 0;
          pet.pastiOggi = [];
          mostraToast('Corpo tornato normale.');
        } else {
          pet.sovralimentazioniRecenti = 99; // ben oltre la soglia -> bodyVariant = ciccione
          mostraToast((pet.stadio === 'teen' || pet.stadio === 'adulto') ? 'Ciccione forzato.' : 'Il ciccione si vede da teen in su.');
        }
        PETQ.save.save(currentState);
        disegnaStanzaEPet(currentState);
        aggiornaHud(currentState);
        if (document.getElementById('petq-casa')) renderAzioni();
        montaDebugPanel(); // aggiorna la label del tasto
      });
      panel.appendChild(ciccioneBtn);
    }

    var fineMissBtn = el('button', 'petq-btn petq-btn-mini', 'Fine missione subito');
    fineMissBtn.addEventListener('click', function () {
      if (currentState && currentState.missione) {
        currentState.missione.fine = Date.now() - 1;
        PETQ.save.save(currentState);
        controllaMissioneScaduta();
      } else {
        mostraToast('Nessuna missione in corso.');
      }
    });
    panel.appendChild(fineMissBtn);

    // Debug "Rimescola missioni run" (P3, rotazione random missioni per run, missions.js
    // ROTAZIONE_PER_STADIO): azzera il sottoinsieme di rotazione di TUTTI gli stadi, cosi' il
    // fondatore puo' vedere sottoinsiemi diversi senza dover rifare un'intera run. Il lazy init
    // di missions.js (assicuraRotazioneStadio) ri-estrae da solo alla prossima rosaDelGiorno
    // dello stadio interessato: qui basta svuotare e salvare, stesso pattern save+render degli
    // altri bottoni sopra (es. +100 monete). Il toast avverte che serve riaprire la mappa perche'
    // rosaDelGiorno/statoMappa non sono cacheate ma nemmeno ri-disegnate automaticamente da qui.
    var rimescolaBtn = el('button', 'petq-btn petq-btn-mini', 'Rimescola missioni run');
    rimescolaBtn.addEventListener('click', function () {
      if (!currentState) return;
      currentState.rotazioneMissioni = {};
      PETQ.save.save(currentState);
      aggiornaHud(currentState);
      if (document.getElementById('petq-casa')) renderAzioni();
      mostraToast('Rotazione run ri-estratta: riapri la mappa.');
    });
    panel.appendChild(rimescolaBtn);

    // Debug "Fine allenamento subito" (bilanciamento.md "Durata allenamento", attivita' a
    // tempo): completa IMMEDIATAMENTE l'allenamento in corso, stesso pattern di "Fine missione
    // subito" sopra (forza oreFatte al massimo e lascia che il controllo normale la risolva).
    var fineAllenBtn = el('button', 'petq-btn petq-btn-mini', 'Fine allenamento subito');
    fineAllenBtn.addEventListener('click', function () {
      if (currentState && currentState.allenamento) {
        currentState.allenamento.oreFatte = currentState.allenamento.oreTot;
        PETQ.save.save(currentState);
        controllaAllenamentoScaduto();
      } else {
        mostraToast('Nessun allenamento in corso.');
      }
    });
    panel.appendChild(fineAllenBtn);

    var fineGiocoBtn = el('button', 'petq-btn petq-btn-mini', 'Fine gioco subito');
    fineGiocoBtn.addEventListener('click', function () {
      if (currentState && currentState.gioco) {
        currentState.gioco.oreFatte = currentState.gioco.oreTot;
        PETQ.save.save(currentState);
        controllaGiocoScaduto();
      } else {
        mostraToast('Nessun gioco in corso.');
      }
    });
    panel.appendChild(fineGiocoBtn);

    // Debug giocattoli (regola fondatore: ogni feature dev'essere provabile da qui). "Sblocca
    // giocattoli" consegna TUTTO il catalogo, compresi i 2 che oggi sono solo drop e che nessuna
    // missione consegna ancora — senza questo bottone il menu del salone non e' testabile a fondo.
    // I 4 doppi arredo-giocattolo entrano come arredi, come fa il negozio.
    var sbloccaGiocattoliBtn = el('button', 'petq-btn petq-btn-mini', 'Sblocca giocattoli');
    sbloccaGiocattoliBtn.addEventListener('click', function () {
      if (!currentState || !PETQ.giocattoli) return;
      var catalogo = PETQ.giocattoli.catalogo ? PETQ.giocattoli.catalogo() : [];
      for (var i = 0; i < catalogo.length; i++) {
        var nomeG = catalogo[i] && catalogo[i].nome;
        if (!nomeG) continue;
        if (trovaArredoContentUI(nomeG) && PETQ.arredi && PETQ.arredi.aggiungi) PETQ.arredi.aggiungi(currentState, nomeG);
        else if (PETQ.giocattoli.aggiungi) PETQ.giocattoli.aggiungi(currentState, nomeG);
      }
      PETQ.save.save(currentState);
      aggiornaHud(currentState);
      if (document.getElementById('petq-casa')) renderAzioni();
      mostraToast('Giocattoli sbloccati: ' + catalogo.length + '.');
    });
    panel.appendChild(sbloccaGiocattoliBtn);

    var azzeraUsiBtn = el('button', 'petq-btn petq-btn-mini', 'Azzera usi giocattoli');
    azzeraUsiBtn.addEventListener('click', function () {
      if (!currentState || !PETQ.giocattoli || !PETQ.giocattoli.resetGiorno) return;
      PETQ.giocattoli.resetGiorno(currentState);
      PETQ.save.save(currentState);
      if (document.getElementById('petq-casa')) renderAzioni();
      mostraToast('Usi giornalieri dei giocattoli azzerati.');
    });
    panel.appendChild(azzeraUsiBtn);

    // Debug "Nuovo giorno" (fix "nuovo giorno a mezzanotte di gioco"): fa AVANZARE il giorno di
    // gioco oltre la prossima mezzanotte e chiama dailyLogin passando dallo STESSO path della
    // sessione reale, invece di azzerare i contatori a mano su una data reale. Incrementa
    // state.giornoGioco di 1 e porta l'orologio a un orario mattutino (08:00) cosi' il pet "si
    // sveglia" nel nuovo giorno; dailyLogin vede giornoGioco > lastLoginDay e scatta (monete,
    // giorniVita, reset contatori giornalieri via confronto sul nuovo giorno, guarigione, valigia).
    // I gate giornalieri (trainDay/cureDay/missioneGiorno/... interi) tornano freschi da soli
    // perche' non coincidono piu' col nuovo giornoGioco. Il cooldown missioni (3 giorni di gioco)
    // scala anch'esso, essendo missioniFatte ora in giorni di gioco interi.
    var nuovoGiornoBtn = el('button', 'petq-btn petq-btn-mini', 'Nuovo giorno');
    nuovoGiornoBtn.addEventListener('click', function () {
      if (!currentState) return;
      currentState.giornoGioco = (typeof currentState.giornoGioco === 'number' ? currentState.giornoGioco : 0) + 1;
      currentState.gameMinutes = 8 * 60; // 08:00, mattino del nuovo giorno
      if (PETQ.care && PETQ.care.dailyLogin) PETQ.care.dailyLogin(currentState);
      PETQ.save.save(currentState);
      // evoluzione baby->teen (PROTOTIPO-2.md punto 1): giorniVita e' appena avanzato dal
      // dailyLogin sopra, controlliamo subito se ha raggiunto la soglia (5x "Nuovo giorno" la
      // fa scattare senza dover aspettare altri render). Se scatta prende il controllo dello
      // schermo, quindi aggiornaHud/renderAzioni sotto diventano no-op sugli elementi rimossi.
      if (controllaEvoluzioneScaduta()) return;
      // Valigia / partenza (PROTOTIPO 2, Blocco 2): il dailyLogin sopra puo' aver generato un
      // evento valigia (ingresso in valigia / rientro / partenza). Lo consumiamo qui: se e' una
      // partenza prende il controllo dello schermo (addio -> pet partito), quindi ritorniamo.
      if (controllaEventoValigia()) return;
      // Porta pendente (Batch B: Dilemmi + Lavori): giorniVita e' appena avanzato, corso/
      // lavoretto/svolta possono essere maturati esattamente come l'evoluzione qui sopra.
      if (controllaPortaPendente()) return;
      if (controllaCartaPendente()) return;
      aggiornaHud(currentState);
      renderAzioni();
      // Popup una-tantum Supporter Pack: stesso aggancio idempotente delle guardie qui sopra (v.
      // controllaPopupSostieni), cosi' il fondatore lo vede scattare anche testando col debug
      // "Nuovo giorno" invece di dover aspettare un tick reale da 30s.
      controllaPopupSostieni();
      mostraToast('Nuovo giorno simulato.');
    });
    panel.appendChild(nuovoGiornoBtn);

    // Debug "Forza nanna" (fix playtest 7a): manda a letto il pet SUBITO, a qualsiasi ora,
    // bypassando la soglia oraLetto (utile per testare il ciclo sonno senza aspettare le 21).
    var forzaNannaBtn = el('button', 'petq-btn petq-btn-mini', 'Forza nanna');
    forzaNannaBtn.addEventListener('click', function () {
      if (!currentState || !PETQ.pet) return;
      if (currentState.sonno) {
        mostraToast((currentState.pet && currentState.pet.nome || 'Il pet') + ' sta già dormendo.');
        return;
      }
      PETQ.pet.avviaSonno(currentState, true);
      PETQ.save.save(currentState);
      disegnaStanzaEPet(currentState);
      renderAzioni();
      mostraToast('A nanna, subito.');
    });
    panel.appendChild(forzaNannaBtn);

    // Debug "Salta sonno" (fix orologio di gioco, questa sessione): completa IMMEDIATAMENTE
    // il sonno in corso come se avesse dormito la sua durata massima (riposino 2h piene /
    // notturno 8h piene), utile per testare il risveglio autonomo senza aspettare l'orologio
    // di gioco anche a velocita' ×600.
    var saltaSonnoBtn = el('button', 'petq-btn petq-btn-mini', 'Salta sonno');
    saltaSonnoBtn.addEventListener('click', function () {
      if (!currentState || !PETQ.pet) return;
      if (!currentState.sonno) {
        mostraToast('Non sta dormendo.');
        return;
      }
      var risultato = PETQ.pet.debugSaltaAlMattino(currentState);
      PETQ.save.save(currentState);
      disegnaStanzaEPet(currentState);
      aggiornaHud(currentState);
      renderAzioni();
      if (risultato) mostraBalloon(PETQ.dialog.say(currentState.pet, risultato.battuta, currentState));
      mostraToast('Sonno completato.');
    });
    panel.appendChild(saltaSonnoBtn);

    // Debug "Ferite +20" (fix playtest 7c): per testare il flusso infermeria senza aspettare
    // un fallimento missione.
    var feriteBtn = el('button', 'petq-btn petq-btn-mini', 'Ferite +20');
    feriteBtn.addEventListener('click', function () {
      if (!currentState) return;
      currentState.ferite = Math.min(100, (currentState.ferite || 0) + 20);
      if (currentState.pet && PETQ.pet) PETQ.pet.recomputeSalute(currentState.pet, currentState);
      PETQ.save.save(currentState);
      aggiornaHud(currentState);
      renderAzioni();
    });
    panel.appendChild(feriteBtn);

    // Debug "Insegna parola test" (GDD "Parola imparata", punto 4): inserisce direttamente
    // "banana" in state.parole, bypassando il limite di 1 al giorno di care.teachWord, cosi'
    // si puo' verificare subito che {parola} compaia nelle battute senza aspettare il giorno
    // dopo. Non tocca wordDay: l'insegnamento "vero" del giorno resta comunque disponibile.
    var parolaTestBtn = el('button', 'petq-btn petq-btn-mini', 'Insegna parola test');
    parolaTestBtn.addEventListener('click', function () {
      if (!currentState) return;
      if (!Array.isArray(currentState.parole)) currentState.parole = [];
      if (currentState.parole.indexOf('banana') === -1) currentState.parole.push('banana');
      PETQ.save.save(currentState);
      mostraToast('Parola di test inserita: banana.');
    });
    panel.appendChild(parolaTestBtn);

    // Debug "Evolvi ora" (PROTOTIPO-2.md punto 1; P3: generalizzato allo stadio SUCCESSIVO,
    // baby->teen O teen->adulto) via PETQ.pet._debugEvolvi (riusa esattamente la logica/mutazioni
    // di controllaEvoluzione, stadio+talento, senza aspettare i giorni). NB: _debugEvolvi ESEGUE
    // GIA' la mutazione: richiamare controllaEvoluzioneScaduta dopo non servirebbe (il pet e'
    // gia' nel nuovo stadio, il check interno non scatterebbe una seconda volta), quindi salviamo
    // e mostriamo direttamente la schermata di evoluzione. Se il pet e' gia' adulto _debugEvolvi
    // ritorna false e avvisiamo con un toast invece di rompere qualcosa.
    var evolviStadioBtn = el('button', 'petq-btn petq-btn-mini', 'Evolvi ora');
    evolviStadioBtn.addEventListener('click', function () {
      if (!currentState || !currentState.pet || !PETQ.pet || !PETQ.pet._debugEvolvi) return;
      if (currentState.missione || currentState.sonno || currentState.allenamento) {
        mostraToast('Non ora: il pet e\' impegnato.');
        return;
      }
      var ok = PETQ.pet._debugEvolvi(currentState);
      if (!ok) {
        mostraToast('Già adulto (o stadio non riconosciuto): niente da evolvere.');
        return;
      }
      PETQ.save.save(currentState);
      mostraEvoluzione(currentState);
    });
    panel.appendChild(evolviStadioBtn);

    // Debug "Forza valigia" (PROTOTIPO 2, Blocco 2; P3 estesa a teen/adulto): entra SUBITO in
    // fase valigia (solo se teen o adulto, non gia' in valigia/partito), senza aspettare i 2
    // giorni critici. Fa comparire la valigetta in scena + notifica + battuta valigia.
    var forzaValigiaBtn = el('button', 'petq-btn petq-btn-mini', 'Forza valigia');
    forzaValigiaBtn.addEventListener('click', function () {
      if (!currentState || !currentState.pet || !PETQ.pet || !PETQ.pet.debugForzaValigia) return;
      if (currentState.pet.stadio !== 'teen' && currentState.pet.stadio !== 'adulto') {
        mostraToast('Solo da teen in su: evolvi prima il pet.');
        return;
      }
      if (currentState.valigia) {
        mostraToast('È già in fase valigia.');
        return;
      }
      var ok = PETQ.pet.debugForzaValigia(currentState);
      if (!ok) { mostraToast('Impossibile forzare la valigia ora.'); return; }
      currentState.eventoValigia = { tipo: 'valigia' };
      PETQ.save.save(currentState);
      controllaEventoValigia();
    });
    panel.appendChild(forzaValigiaBtn);

    // Debug "Forza partenza" (PROTOTIPO 2, Blocco 2): fa PARTIRE il pet subito (schermata addio
    // -> casa "pet partito"), bypassando la finestra. Utile per testare l'addio e l'ammenda.
    var forzaPartenzaBtn = el('button', 'petq-btn petq-btn-mini', 'Forza partenza');
    forzaPartenzaBtn.addEventListener('click', function () {
      if (!currentState || !PETQ.pet || !PETQ.pet.debugForzaPartenza) return;
      if (!currentState.pet) {
        mostraToast('Nessun pet in casa (già partito?).');
        return;
      }
      var ok = PETQ.pet.debugForzaPartenza(currentState);
      if (!ok) { mostraToast('Impossibile forzare la partenza ora.'); return; }
      PETQ.save.save(currentState);
      mostraAddio(currentState);
    });
    panel.appendChild(forzaPartenzaBtn);

    // Debug "Manda in pensione" (PROTOTIPO 2, versione base P2): ritira il pet SUBITO (senza
    // aprire la scheda ne' la conferma a due tap) e apre la scelta del nuovo pet. Utile per
    // testare il flusso ritiro -> galleria -> eredita' rapidamente.
    var pensioneBtn = el('button', 'petq-btn petq-btn-mini', 'Manda in pensione');
    pensioneBtn.addEventListener('click', function () {
      if (!currentState || !currentState.pet || !PETQ.pet || !PETQ.pet.mandaInPensione) {
        mostraToast('Nessun pet in casa da ritirare.');
        return;
      }
      avviaPensione(currentState);
    });
    panel.appendChild(pensioneBtn);

    // Debug "Schiudi leggenda (test)" (P3 batch 6, SOLO debug): CICLATORE. Ad ogni pressione arma
    // la PROSSIMA leggenda DISEGNATA (elenco dal registry sprites) per la prossima schiusa,
    // bypassando il tiro del 20%; il toast dice QUALE (ripremi per cambiarla). Serve a vedere gli
    // sprite di tutte le leggende senza dipendere da leggendeSbloccate — che a inizio gioco e'
    // vuoto, per cui prima usciva SEMPRE Giga Ciad (m65). Richiede la casa vuota (schermata uovo,
    // post-pensione/partenza o primissimo avvio): con un pet gia' in casa non fa nulla.
    var forzaLeggendaBtn = el('button', 'petq-btn petq-btn-mini', 'Schiudi leggenda (test)');
    forzaLeggendaBtn.addEventListener('click', function () {
      if (currentState && currentState.pet) {
        mostraToast('Prima manda in pensione il pet.');
        return;
      }
      // Casa vuota o nessuna partita ancora iniziata (currentState resta null finche' non si tocca
      // un uovo, v. main.js boot()/sceglieUovo): creiamo un contenitore minimo SOLO in memoria,
      // cosi' i flag sopravvivono fino al prossimo PETQ.pet.generate; diventa un save vero con
      // avviaPartita al tap sull'uovo (che scrive un save completo per conto suo).
      var statoGiaEsistente = !!currentState;
      if (!currentState) currentState = {};
      var idsDisegnate = (PETQ.sprites._leggendeIds && PETQ.sprites._leggendeIds()) || ['m65'];
      if (!idsDisegnate.length) idsDisegnate = ['m65'];
      var idxAttuale = idsDisegnate.indexOf(currentState.debugLeggendaId); // -1 se non ancora armato
      var prossimo = idsDisegnate[(idxAttuale + 1) % idsDisegnate.length];
      currentState.debugForzaLeggenda = true;
      currentState.debugLeggendaId = prossimo;
      var info = (PETQ.pet && PETQ.pet._leggendeInfo) || {};
      var nome = (info[prossimo] && info[prossimo].nome) || prossimo;
      if (statoGiaEsistente && PETQ.save && PETQ.save.save) PETQ.save.save(currentState);
      mostraToast('DEBUG prossimo uovo: ' + nome + ' (ripremi per cambiare leggenda)');
    });
    panel.appendChild(forzaLeggendaBtn);

    // Debug "Ri-tira talenti" (PROTOTIPO-2.md Blocco 9): ri-estrae da capo i talenti del pet
    // rispettando lo stadio attuale (1 se baby, 2 se teen), per provare combinazioni diverse
    // senza dover far rinascere/evolvere il pet. Aggiorna subito la scheda se e' aperta.
    var ritiraTalentiBtn = el('button', 'petq-btn petq-btn-mini', 'Ri-tira talenti');
    ritiraTalentiBtn.addEventListener('click', function () {
      if (!currentState || !currentState.pet || !PETQ.pet || !PETQ.pet.ritiraTalenti) return;
      var ok = PETQ.pet.ritiraTalenti(currentState.pet);
      if (!ok) {
        mostraToast('Talenti non disponibili (content non ancora caricato?).');
        return;
      }
      PETQ.save.save(currentState);
      aggiornaHud(currentState);
      var nomi = currentState.pet.talenti.map(function (t) { return t.nome + (t.raro ? ' (raro)' : ''); }).join(', ');
      mostraToast('Nuovi talenti: ' + (nomi || 'nessuno'));
      if (document.getElementById('petq-scheda-overlay')) mostraScheda(currentState);
    });
    panel.appendChild(ritiraTalentiBtn);

    // Debug "Sblocca tutti i colori" / "Supporter on/off" (varianti cromatiche, tabella dati
    // COLORI_PET in cima al file): l'acquisto vero con soldi non esiste ancora, questi due
    // bottoni servono al fondatore per collaudare selettore/negozio senza dover accumulare 1200
    // monete o avere un vero Supporter Pack. "Sblocca tutti i colori" tocca SOLO gli indici a
    // monete (coloriSbloccati): i tre Supporter restano gated dal bottone accanto, cosi' si
    // possono provare i due percorsi separatamente.
    var sbloccaColoriBtn = el('button', 'petq-btn petq-btn-mini', 'Sblocca tutti i colori');
    sbloccaColoriBtn.addEventListener('click', function () {
      if (!currentState) return;
      if (!Array.isArray(currentState.coloriSbloccati)) currentState.coloriSbloccati = [];
      for (var icd = 0; icd < COLORI_PET.length; icd++) {
        if (COLORI_PET[icd].tipo === 'negozio' && currentState.coloriSbloccati.indexOf(COLORI_PET[icd].indice) === -1) {
          currentState.coloriSbloccati.push(COLORI_PET[icd].indice);
        }
      }
      PETQ.save.save(currentState);
      if (document.getElementById('petq-scheda-overlay')) mostraScheda(currentState);
      mostraToast('Colori a monete tutti sbloccati.');
    });
    panel.appendChild(sbloccaColoriBtn);

    // Debug "Sblocca tutte le skin" (skin cosmetiche della stanza, tabella dati SKIN_STANZE in
    // cima al file): STESSO identico ruolo di "Sblocca tutti i colori" sopra — mette tutti gli id
    // 'negozio' in state.skinSbloccate, cosi' si collauda selettore/negozio senza accumulare
    // 2600 monete. Le tre 'supporter' restano gated dal bottone "Supporter on/off" sotto (stesso
    // interruttore condiviso con i colori Supporter: un solo toggle copre entrambi i batch).
    var sbloccaSkinBtn = el('button', 'petq-btn petq-btn-mini', 'Sblocca tutte le skin');
    sbloccaSkinBtn.addEventListener('click', function () {
      if (!currentState) return;
      if (!Array.isArray(currentState.skinSbloccate)) currentState.skinSbloccate = [];
      for (var isd = 0; isd < SKIN_STANZE.length; isd++) {
        if (SKIN_STANZE[isd].tipo === 'negozio' && currentState.skinSbloccate.indexOf(SKIN_STANZE[isd].id) === -1) {
          currentState.skinSbloccate.push(SKIN_STANZE[isd].id);
        }
      }
      PETQ.save.save(currentState);
      if (document.getElementById('petq-scheda-overlay')) mostraScheda(currentState);
      mostraToast('Skin stanza a monete tutte sbloccate.');
    });
    panel.appendChild(sbloccaSkinBtn);

    // Debug "Sblocca tutte le cornici" (cornici cosmetiche della cartolina, tabella dati
    // CORNICI_CARTOLINA in cima al file): STESSO identico ruolo dei due bottoni sopra — mette
    // tutti gli id 'negozio' in state.corniciSbloccate, cosi' si collauda selettore/negozio senza
    // accumulare 1200 monete. Le due 'supporter' restano gated dal bottone "Supporter on/off"
    // sotto (stesso interruttore condiviso con colori e skin stanza).
    var sbloccaCorniciBtn = el('button', 'petq-btn petq-btn-mini', 'Sblocca tutte le cornici');
    sbloccaCorniciBtn.addEventListener('click', function () {
      if (!currentState) return;
      if (!Array.isArray(currentState.corniciSbloccate)) currentState.corniciSbloccate = [];
      for (var icd2 = 0; icd2 < CORNICI_CARTOLINA.length; icd2++) {
        if (CORNICI_CARTOLINA[icd2].tipo === 'negozio' && currentState.corniciSbloccate.indexOf(CORNICI_CARTOLINA[icd2].id) === -1) {
          currentState.corniciSbloccate.push(CORNICI_CARTOLINA[icd2].id);
        }
      }
      PETQ.save.save(currentState);
      if (document.getElementById('petq-scheda-overlay')) mostraScheda(currentState);
      mostraToast('Cornici a monete tutte sbloccate.');
    });
    panel.appendChild(sbloccaCorniciBtn);

    // Debug "Sblocca tutti i completi" (vestiti a due pezzi, tabella dati COMPLETI_VESTITO in cima
    // al file): STESSO identico ruolo dei tre bottoni sopra — mette tutti i nomi 'negozio' in
    // state.completiSbloccati, cosi' si collauda Armadio/negozio senza accumulare 2400 monete. I
    // due 'supporter' restano gated dal bottone "Supporter on/off" sotto (stesso interruttore
    // condiviso con colori/skin/cornici).
    var sbloccaCompletiBtn = el('button', 'petq-btn petq-btn-mini', 'Sblocca tutti i completi');
    sbloccaCompletiBtn.addEventListener('click', function () {
      if (!currentState) return;
      if (!Array.isArray(currentState.completiSbloccati)) currentState.completiSbloccati = [];
      for (var icdv = 0; icdv < COMPLETI_VESTITO.length; icdv++) {
        if (COMPLETI_VESTITO[icdv].tipo === 'negozio' && currentState.completiSbloccati.indexOf(COMPLETI_VESTITO[icdv].nome) === -1) {
          currentState.completiSbloccati.push(COMPLETI_VESTITO[icdv].nome);
        }
      }
      PETQ.save.save(currentState);
      if (document.getElementById('petq-scheda-overlay')) mostraScheda(currentState);
      mostraToast('Completi a monete tutti sbloccati.');
    });
    panel.appendChild(sbloccaCompletiBtn);

    // Interruttore di TEST (pannello ?debug, mai in produzione): in produzione la verità sugli
    // acquisti è PETQ.iap (RevenueCat), sincronizzata al boot in render() — questo bottone resta
    // solo per collaudare selettore/negozio senza un vero Supporter Pack.
    var supporterBtn = el('button', 'petq-btn petq-btn-mini', 'Supporter on/off');
    supporterBtn.addEventListener('click', function () {
      if (!currentState) return;
      currentState.supporter = !currentState.supporter;
      // Companion Supporter Pack (batch companion): la sincronizzazione "vera" gira ad ogni
      // boot dentro save.js migraState, ma questo toggle NON ricarica la pagina -> senza
      // richiamarla qui i 4 companion comparirebbero fra i posseduti solo al prossimo riavvio.
      // Idempotente (v. save.js sincronizzaCompanionSupporter): richiamabile anche spegnendo il
      // Supporter, dove e' un no-op voluto (niente rimozioni).
      if (PETQ.save && PETQ.save.sincronizzaCompanionSupporter) PETQ.save.sincronizzaCompanionSupporter(currentState);
      PETQ.save.save(currentState);
      if (document.getElementById('petq-scheda-overlay')) mostraScheda(currentState);
      mostraToast('Supporter Pack: ' + (currentState.supporter ? 'ON' : 'OFF') + '.');
    });
    panel.appendChild(supporterBtn);

    // Debug "Companion: effetto ora" (batch companion, 29 lug 2026): applica SUBITO gli effetti
    // quotidiani dei companion Supporter Pack piazzati, senza aspettare la mezzanotte di gioco
    // (regola progetto: ogni cosa a tempo dev'essere saltabile dal pannello debug). Richiama la
    // STESSA funzione motore (care.applicaEffettiCompanion) e lo STESSO canale di visualizzazione
    // (controllaCompanionEffettiLogin) usati dal vero nuovo giorno, cosi' il fondatore vede
    // esattamente il messaggio che vedrebbe un giocatore. Pannello debug resta in italiano.
    var companionEffettoOraBtn = el('button', 'petq-btn petq-btn-mini', 'Companion: effetto ora');
    companionEffettoOraBtn.addEventListener('click', function () {
      if (!currentState || !PETQ.care || !PETQ.care.applicaEffettiCompanion) return;
      var effetti = PETQ.care.applicaEffettiCompanion(currentState);
      if (effetti.length === 0) {
        mostraToast('Nessun companion piazzato (o Supporter spento): niente da applicare.');
        return;
      }
      currentState.companionEffettiGiorno = effetti;
      PETQ.save.save(currentState);
      aggiornaHud(currentState);
      controllaCompanionEffettiLogin();
    });
    panel.appendChild(companionEffettoOraBtn);

    // Debug streak (Retention 2.0/A2): la carica si misura in GIORNI, quindi senza questi tre
    // bottoni collaudarla vorrebbe dire aspettare due settimane vere. Coprono i tre soli
    // comportamenti che esistono: giorno buono, giorno saltato, azzeramento.
    // Passano tutti dalle STESSE funzioni del gioco vero (registraAzioneCura /
    // aggiornaAlNuovoGiorno) — mai scorciatoie che scrivono i numeri a mano, o si collauderebbe
    // il bottone invece del meccanismo. Pannello debug in italiano come il resto.
    var streakPiuBtn = el('button', 'petq-btn petq-btn-mini', 'Streak +1 giorno');
    streakPiuBtn.addEventListener('click', function () {
      if (!currentState || !PETQ.streak) return;
      var s = PETQ.streak.assicura(currentState);
      // Fa finta che l'ultima cura sia di IERI, poi registra la cura di oggi: e' esattamente la
      // sequenza di un giocatore che torna il giorno dopo.
      s.ultimoValido = PETQ.clock.giornoCorrente(currentState) - 1;
      PETQ.streak.registraAzioneCura(currentState);
      PETQ.save.save(currentState);
      aggiornaHud(currentState);
      mostraToast('Carica: ' + PETQ.streak.stato(currentState).giorni + ' giorni.');
    });
    panel.appendChild(streakPiuBtn);

    var streakSaltaBtn = el('button', 'petq-btn petq-btn-mini', 'Streak: salta un giorno');
    streakSaltaBtn.addEventListener('click', function () {
      if (!currentState || !PETQ.streak) return;
      var s = PETQ.streak.assicura(currentState);
      if (s.ultimoValido === null) {
        mostraToast('Nessuna serie in corso: niente da saltare.');
        return;
      }
      // Ultima cura a oggi-2 (valore ASSOLUTO, non "-= 2"): cosi' IERI risulta vuoto e ogni
      // clic simula UN giorno saltato. Con la sottrazione relativa il secondo clic ne simulava
      // tre in un colpo e sembrava che una sola assenza facesse crollare la serie di due
      // gradini — un bottone di collaudo che mente e' peggio di un bottone che manca.
      s.ultimoValido = PETQ.clock.giornoCorrente(currentState) - 2;
      PETQ.streak.aggiornaAlNuovoGiorno(currentState);
      PETQ.save.save(currentState);
      aggiornaHud(currentState);
    });
    panel.appendChild(streakSaltaBtn);

    // Debug voce: l'animalese esce solo una volta ogni tanto (22% + raffreddamento), quindi
    // senza un modo di FORZARLO il fondatore dovrebbe cliccare a vuoto per minuti per sentirlo.
    var voceBtn = el('button', 'petq-btn petq-btn-mini', 'Voce: parla ora');
    voceBtn.addEventListener('click', function () {
      if (!currentState || !currentState.pet) return;
      voceForzata = true;
      mostraBalloon(PETQ.dialog.say(currentState.pet, 'felice', currentState));
    });
    panel.appendChild(voceBtn);

    // Debug voce VERA (TTS): insegna una parola al volo e la fa dire, cosi' si sente com'e' la
    // voce di questa razza senza dover aspettare che il pool 'parola' esca da solo (30%).
    var voceParolaBtn = el('button', 'petq-btn petq-btn-mini', 'Voce: di\' una parola');
    voceParolaBtn.addEventListener('click', function () {
      if (!currentState || !currentState.pet || !PETQ.voce) return;
      var parole = currentState.parole || [];
      var p = parole.length ? parole[parole.length - 1] : 'banana';
      var partita = PETQ.voce.pronuncia(p, currentState.pet);
      mostraToast('Voce (' + PETQ.voce._sorgente(currentState.pet) + '): ' + (partita ? '"' + p + '"' : 'non disponibile'));
    });
    panel.appendChild(voceParolaBtn);

    // Provino: la STESSA parola con le tre voci di fila. Una voce si giudica solo per confronto —
    // da sola sembra sempre accettabile, accanto alle altre si sente subito quale non funziona.
    var voceProvinoBtn = el('button', 'petq-btn petq-btn-mini', 'Voce: provino 3 voci');
    voceProvinoBtn.addEventListener('click', function () {
      if (!PETQ.audio || !PETQ.voce) return;
      var parola = (currentState && currentState.parole && currentState.parole.length)
        ? currentState.parole[currentState.parole.length - 1] : 'zucchina';
      var d1 = PETQ.audio.parlaParola(parola, 'robot');
      dopoMs(Math.round(d1 * 1000) + 500, function () {
        var d2 = PETQ.audio.parlaParola(parola, 'alieno');
        dopoMs(Math.round(d2 * 1000) + 500, function () {
          PETQ.voce.pronuncia(parola, { razza: 'leggenda' });
        });
      });
      mostraToast('Provino su "' + parola + '": robot, alieno, leggenda.');
    });
    panel.appendChild(voceProvinoBtn);

    // Interruttore fra le due voci: la sintesi costruita a mano non ha ancora superato la prova
    // dell'orecchio, quindi il default e' il motore di sistema (dice le parole, anche se con voce
    // umana). Questo bottone serve a confrontarle senza toccare il codice.
    var voceModoBtn = el('button', 'petq-btn petq-btn-mini', 'Voce: cambia motore');
    voceModoBtn.addEventListener('click', function () {
      if (!PETQ.voce) return;
      var nuovo = PETQ.voce.modoProssimo(); // robotizzata -> sistema -> sintesi -> ...
      PETQ.voce.impostaModo(nuovo);
      var parola = (currentState && currentState.parole && currentState.parole.length)
        ? currentState.parole[currentState.parole.length - 1] : 'zucchina';
      PETQ.voce.pronuncia(parola, currentState && currentState.pet);
      mostraToast('Motore voce: ' + nuovo + ' — "' + parola + '"');
    });
    panel.appendChild(voceModoBtn);

    // Debug carta dilemma: l'ora della carta e' casuale nella giornata, quindi senza questo
    // bottone il fondatore dovrebbe aspettare. Forza l'ora ad ADESSO e la mostra. Se non c'e'
    // niente da mostrare lo DICE, invece di non fare nulla e sembrare rotto.
    var cartaOraBtn = el('button', 'petq-btn petq-btn-mini', 'Carta: adesso');
    cartaOraBtn.addEventListener('click', function () {
      if (!currentState || !PETQ.carte) return;
      PETQ.carte.cartaDiOggi(currentState);            // estrae se il giorno e' nuovo
      var st = PETQ.carte.assicura(currentState);
      if (!st.id) { mostraToast('Nessuna carta eleggibile per questo pet oggi.'); return; }
      if (st.risolta) { mostraToast('Carta di oggi: già giocata.'); return; }
      st.ora = 0;                                     // qualunque ora la supera
      PETQ.save.save(currentState);
      controllaCartaPendente();
    });
    panel.appendChild(cartaOraBtn);

    // Debug battuta a comando (brief regia clip social round 2, 5 ago 2026): fa "recitare" il
    // pet ADESSO davanti a OBS, invece di aspettare che ne esca una spontanea.
    var battutaOraBtn = el('button', 'petq-btn petq-btn-mini', '🎭 Battuta: adesso');
    battutaOraBtn.addEventListener('click', function () { battutaARichiesta(); });
    panel.appendChild(battutaOraBtn);

    // Debug corsi: sul telefono i tre perk si ottengono solo scegliendo alla porta del giorno 1, e
    // per riprovarne un altro servirebbe una run nuova. Questo li da' tutti e tre e azzera i
    // contatori giornalieri, cosi' cuoco e canto si possono provare subito e piu' volte.
    var corsiBtn = el('button', 'petq-btn petq-btn-mini', 'Corsi: sblocca tutti e 3');
    corsiBtn.addEventListener('click', function () {
      if (!currentState) return;
      if (!Array.isArray(currentState.perks)) currentState.perks = [];
      ['corso_disegno', 'corso_musica', 'corso_cucina'].forEach(function (p) {
        if (currentState.perks.indexOf(p) === -1) currentState.perks.push(p);
      });
      currentState.cuocoGiorno = null;
      currentState.cantoGiorno = null;
      PETQ.save.save(currentState);
      renderAzioni();
      mostraToast('Corsi sbloccati: cuoco e canto pronti (contatori azzerati).');
    });
    panel.appendChild(corsiBtn);

    var streakZeroBtn = el('button', 'petq-btn petq-btn-mini', 'Streak: azzera');
    streakZeroBtn.addEventListener('click', function () {
      if (!currentState) return;
      currentState.streak = null;
      currentState.streakAvvisi = [];
      if (PETQ.streak) PETQ.streak.assicura(currentState);
      PETQ.save.save(currentState);
      aggiornaHud(currentState);
      mostraToast('Carica azzerata.');
    });
    panel.appendChild(streakZeroBtn);

    // Debug "Porta: X" (Batch B: Dilemmi + Lavori): monta SUBITO la schermata di una porta,
    // ignorando stadio e giorno (che sono gating di PETQ.porte.porteDaMostrare, non della
    // schermata) — senza questi il fondatore dovrebbe giocare nove giorni veri per vedere la
    // Svolta. Le opzioni vengono SEMPRE da PETQ.porte.opzioniPorta: se lo stadio vero del pet non
    // e' quello giusto la SCELTA (non la visualizzazione) fallisce con un messaggio chiaro, mai un
    // throw (v. porte.scegli). Pannello debug resta in italiano come il resto.
    var portaDebugLabel = el('span', 'petq-debug-label', 'Porte:');
    panel.appendChild(portaDebugLabel);
    var PORTE_DEBUG = [
      { id: 'corso', label: 'Porta: Corso' },
      { id: 'lavoretto', label: 'Porta: Lavoretto' },
      { id: 'carriera', label: 'Porta: Carriera' },
      { id: 'svolta', label: 'Porta: Svolta' }
    ];
    for (var iPortaDebug = 0; iPortaDebug < PORTE_DEBUG.length; iPortaDebug++) {
      (function (def) {
        var btnPorta = el('button', 'petq-btn petq-btn-mini', def.label);
        btnPorta.addEventListener('click', function () {
          if (!currentState || !currentState.pet || !PETQ.porte) return;
          mostraPorta(currentState, def.id);
        });
        panel.appendChild(btnPorta);
      })(PORTE_DEBUG[iPortaDebug]);
    }

    // Debug "Suoni" (audio.js): un bottone per OGNI voce del catalogo, generati in ciclo da
    // PETQ.audio.elenco() — MAI scritti a mano, cosi' una voce nuova compare qui da sola senza
    // toccare ui.js. Serve al fondatore per ascoltarli tutti in fila e segnalare quali rifare.
    // Pannello debug resta in italiano come il resto: solo l'etichetta "Suoni:" e' testo fisso.
    if (PETQ.audio) {
      var suoniLabel = el('span', 'petq-debug-label', 'Suoni:');
      panel.appendChild(suoniLabel);
      var vociAudio = PETQ.audio.elenco();
      for (var iVoce = 0; iVoce < vociAudio.length; iVoce++) {
        (function (voce) {
          var btnVoce = el('button', 'petq-btn petq-btn-mini', voce);
          btnVoce.addEventListener('click', function () { PETQ.audio.suona(voce); });
          panel.appendChild(btnVoce);
        })(vociAudio[iVoce]);
      }
    }

    // Debug "OTA" (ota.js, aggiornamenti self-hosted via @capgo/capacitor-updater): riga di
    // stato compatta letta da PETQ.ota.stato() + bottone che forza un check ignorando il
    // throttle di 6h (controlla(true, cb)). Niente alert: l'esito riscrive la riga stessa.
    // Pannello debug resta in italiano come il resto (v. commento "Suoni" sopra).
    var otaLabel = el('span', 'petq-debug-label', 'OTA:');
    panel.appendChild(otaLabel);
    if (PETQ.ota && PETQ.ota.stato) {
      function orarioBreveOta(ms) {
        var d = new Date(ms);
        var h = d.getHours(), m = d.getMinutes();
        return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
      }
      function formattaStatoOta() {
        var s = PETQ.ota.stato();
        return 'plugin: ' + (s.pluginPresente ? 'sì' : 'no') +
          ' · build ' + s.build +
          ' · in attesa: ' + (s.inAttesa !== null ? s.inAttesa : '—') +
          ' · ultimo check: ' + (s.ultimoCheck !== null ? orarioBreveOta(s.ultimoCheck) : 'mai');
      }
      var otaStatoSpan = el('span', 'petq-debug-label', formattaStatoOta());
      panel.appendChild(otaStatoSpan);

      var otaBtn = el('button', 'petq-btn petq-btn-mini', 'Controlla ora');
      otaBtn.addEventListener('click', function () {
        PETQ.ota.controlla(true, function (r) {
          otaStatoSpan.textContent = formattaStatoOta() + ' · esito: ' + ((r && r.esito) || '?');
        });
      });
      panel.appendChild(otaBtn);
    } else {
      panel.appendChild(el('span', 'petq-debug-label', 'modulo assente'));
    }

    var resetBtn = el('button', 'petq-btn petq-btn-mini petq-btn-danger', 'Reset save');
    resetBtn.addEventListener('click', function () {
      PETQ.save.reset();
      location.reload();
    });
    panel.appendChild(resetBtn);

    document.body.appendChild(panel);
    // Applica lo stato ciak ANCHE al rimontaggio: se il pannello viene ricostruito mentre e'
    // nascosto (boot ripetuto, remount), deve restare fuori dall'inquadratura.
    applicaVisibilitaDebug();
  }

  window.PETQ.ui = {
    boot: boot,
    render: render,
    // esposti per test di logica (stesso stile di rooms._W / sprites._getRobotFrame)
    _dentroRect: dentroRect,
    _coordLogiche: coordLogiche,
    _situazionePrioritaria: situazionePrioritaria,
    _hotzoneVasca: HOTZONE_VASCA,
    _propsAllenamento: PROPS_ALLENAMENTO,
    _formattaTempo: formattaTempo,
    _formattaRewardToken: formattaRewardToken,
    _formattaRewardOggetto: formattaRewardOggetto,
    _titoloMissione: titoloMissione,
    _tintaScena: tintaScena,
    _risolviSlotEsito: risolviSlotEsito,
    _hitPin: hitPin,
    _mappaDisponibile: mappaDisponibile,
    _statConBonus: statConBonus,
    _testoStat: testoStat,
    // Batch B: Dilemmi + Lavori — le 4 porte, esposte per test/debug (v. controllaPortaPendente).
    _mostraPorta: mostraPorta,
    _controllaPortaPendente: controllaPortaPendente,
    // riga effetti dei cibi (card frigo / riga negozio), esposta per i test del parser Tier 2
    _descriviCibo: descriviCibo,
    _effettiDiCibo: effettiDiCibo,
    _nomiArrediPiazzati: nomiArrediPiazzati,
    // batch giocattoli: riga effetti di indossabili/armi dal contenuto + etichette del menu
    _nodiEffettiEquip: nodiEffettiEquip,
    _voceEquipContenuto: voceEquipContenuto,
    _etichettaUsiGiocattolo: etichettaUsiGiocattolo,
    _costruisciMenuGiocattoli: costruisciMenuGiocattoli,
    _iconaOggetto: iconaOggetto,
    // sezioni del negozio esposte per i test: leggono content.data.armi/indossabili/giocattoli e
    // il gruppo "Armi" e' gia' rimasto vuoto una volta senza che nessuno se ne accorgesse.
    // _setCurrentState serve solo a montarci sopra uno stato finto senza passare dal DOM.
    _renderShopGuardaroba: renderShopGuardaroba,
    _renderShopGiocattoli: renderShopGiocattoli,
    _setCurrentState: function (s) { currentState = s; },
    _equipSpecialeTxt: EQUIP_SPECIALE_TXT,
    _sagomeCategoria: SAGOME_CATEGORIA,
    _giocoBonusManiNude: GIOCO_BONUS_MANI_NUDE,
    _finalizzaNuovoPetInCasa: finalizzaNuovoPetInCasa,
    _riprendiPensionato: riprendiPensionato,
    _casaVuotaPensione: casaVuotaPensione,
    mostraScheda: mostraScheda
  };

})();
