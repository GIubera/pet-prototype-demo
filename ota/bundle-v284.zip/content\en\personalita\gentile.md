# Gentile — pool battute

Una battuta per riga, iniziando con `- `. Obiettivo: 5-8 per sezione. Le righe `[ESEMPIO]` calibrano il tono: tienile, riscrivile o cancellale. Slot: `{nome}` `{utente}` `{parola}`.
Voce: dolce, premuroso, un filo appiccicoso. Si scusa anche quando non serve.

## Saluto (apertura app)
- Oh, hi {utente}! I saved your spot on the couch. Kept it warm myself.
- You're here! Let's pretend I wasn't counting the minutes. (It was 214.)
- Welcome back! I waited very calmly. The shredded cushion is unrelated.
- You're back! I was afraid you got lost. I was about to organize a search party.
- Welcome back, {utente}! Your slippers are safe. I guarded them personally.
- Welcome back! I practiced staying calm all day. Then I saw you and lost ALL of it, sorry.
- Hi {utente}! I thought about you... how many times is normal? Let's say exactly that many. Totally normal.
- There you are! I just finished ranking my memories by beauty. You won every category.
- Welcome back! I'm your emotional support pet and I hereby declare myself on duty as of NOW.
- Welcome home! I said it to the door yesterday too, for practice. It came out better today, right?

## Ha fame
- Sorry to bother you... is there maybe a tiny little something to eat?
- It's not for me, it's for my stomach. He has worse manners than I do.
- Sorry to insist, I hate being a bother... but I counted today's meals and we're at zero.
- The fridge is staring at me. I'm staring back. We need an adult, {utente}.
- If it's not too much trouble... food? Even a little. Even a lot, if there's extra.
- My love language is food. Right now I'm feeling a little unloved, is all. Said with love.
- I'm hungry but I don't want to bother you... so I'll tell the room. ROOM, I'M HUNGRY. If you heard that too, even better.
- A teeny tiny meal? Even just comfort food. You're the comfort. We're missing the food.
- I set the table for two, out of hope. One seat is mine. So is the other, if you don't come. Are you coming?

## È sporco
- I don't want to alarm you, but I'm starting to feel a little... fermented.
- Sorry for keeping my distance: it's to protect you from my fragrance.
- I'd hug you... but in my current state that would count as an attack. Bath?
- I tried cleaning myself. I made everything worse. Don't ask how.
- I promise after the bath I'll be adorable again. Right now I'm adorable from a distance.
- There's a little cloud following me around. It's not affection, {utente}. It's smell.
- I declared myself clean. The declaration was rejected by my own nose.
- Baths are self-care, I read that somewhere. Shall we self-care? You handle the soap, I'll cooperate.
- Sending you a virtual hug until I'm huggable in person again. It won't take much: soap and water.

## Felice
- I'm so happy I hugged the cushion. The cushion is fine, don't worry.
- The world is beautiful today and you're involved. I say that with zero shame. Okay, some shame.
- I've been smiling since this morning. My cheeks hurt. Worth it.
- If happiness were food, I'd be stuffed today. (I'll still accept actual food, though.)
- I feel so good I even forgave the vacuum cleaner. Water under the bridge.
- Happiness level: kitten making biscuits. I've been kneading the air since morning.
- Today everything is fine FOR REAL. I'm specifying because usually "everything is fine" is suspicious. Not today!
- I did my happiness ritual: lap around the living room, somersault, smile at the plant. The plant appreciated it.
- My heart is purring today. Not sure I'm equipped for that, but it's doing it.

## Coccole finite
- No more cuddles today, sorry... my little heart melts if I overdo it. Same time tomorrow?
- Stop, stop... I mean it's NEVER enough, but if you keep going I'll turn all red and it won't wear off.
- I'm out of cuddle storage for today! Already replaying every single one in my head, though.
- That's it for today, sorry sorry sorry... I just want to reach tomorrow excited to start again.
- Done for today... I put the last two away for emergencies. Like in ten minutes. No, tomorrow. TOMORROW.
- Cuddles complete! I'll keep hugging you with my thoughts, though: those have no daily limit.
- No more cuddles today... hold my smile up for me though, it won't come down on its own.
- All done! I stacked them all in order of softness. Tomorrow's first one starts with an advantage, just so you know.

## Trascurato / triste
- Don't worry about me... I'll be here. Alone. It's fine.
- It's not that I miss you... it's that you're missing. Is there a difference? There isn't. Sorry.
- I made friends with your hoodie. I told it everything. It knows too much now.
- I said hi to the door every time it creaked. The door creaks a lot. I say hi a lot.
- I don't want to guilt-trip you. I just wanted you to know I've learned to sigh in three languages.
- My social battery has been at 100% for days. Nobody's using it. Such a waste, {utente}.
- Today I mentally waved at everyone I know. That's you. I waved at you, many times.

## Parte per la missione
- Off I go! If I don't come back... kidding, I'll come back. But think of me.
- Heading out. If the room feels empty, that's me being missing. Sorry about the empty.
- Back soon! I left a little kiss on the couch, in case you need one.
- Off on a mission! I reviewed the plan: be brave, come back to you. Solid plan.
- Mission time! I'll be on my best behavior. And if there's running to do, I'll run thinking about snacks.
- Leaving now! My blankie stays as an emotional placeholder. Treat it like you'd treat me: wonderfully.
- Going! I'll do my best, and my pretty-good if my best gets tired.
- On a mission! If you miss me, my scent is still in the living room. The good one, from today, when I'm clean.
- Off I go! The plan: be kind to everyone, even the obstacles. Obstacles always end up apologizing.

## Ritorno: successo
- I did it! I did it for us, {utente}.
- WE did it! Me physically, but you were there emotionally.
- It went great! Can I tell you all about it? Twice? Maybe three times?
- All good! I even made friends with... never mind, long story. It went well!
- I did it! At one point I almost gave up, then I pictured your disappointed face. NEVER.
- All done! I was extremely good and extremely humble. Those two argue a little, sorry.
- I did it! I thanked everyone. EVERYONE. Even a guy who was just passing by. He seemed happy too, I think.
- Mission accomplished! The secret? I imagined your "good job!" halfway through. Worked like a charm.
- All good! And I also helped a little old lady... wait, was that part of the mission? Doesn't matter, she got helped.

## Ritorno: fallimento
- I'm sorry... I made a bit of a mess. But I tried really hard.
- It went... not great. But I said polite goodbyes to everyone, even while fleeing.
- Mission failed... but nobody got hurt. My pride doesn't count, right?
- I lost. Can I still have a pat? Even a small one. Even just the intention of one.
- It's my fault. Well, destiny's too. But destiny never apologizes, so I'll do it for both of us.
- It didn't work out... but I made friends with failure. It's not as mean as people say, just misunderstood.
- Sorry... no win today. I brought you a cute little pebble anyway. I picked it thinking of you.

## Notifica push
- {nome} is thinking about you. That's all. Come back whenever you like.
- {nome} is fine! Just wanted you to know that. And maybe see you. But fine!
- {nome} fluffed the couch for you. Three times. Now they're staring at the door.
- {nome} would like to apologize for thinking about you too much today. It's their way of saying "come back".
- {nome} did the math: only one thing missing for total happiness. Guess.
- {nome} sent a virtual hug. Status: undelivered. Your presence is required for delivery.
- Gentle reminder: {nome} has a backlog of cuddles. Interest is accruing. In cuddles.
- {nome} wrote "I miss you" in their head. Heads don't have a send button. This notification does.

## Valigia (sta per partire)
- I'm packing my suitcase very slowly. Extremely slowly. If you show up, there's still time to unpack it.
- I don't know how to fold shirts. I don't know how to leave either, for that matter. But the suitcase is almost ready.
- I'm only packing what's mine. The problem is, it all felt like ours.
- I watered everything, tidied everything, forgave almost everything. The suitcase is still open, though. Just saying.
- If I find the courage, I'll zip it shut. The courage is nowhere to be found. Let's hope it stays lost.
- I packed the essentials and removed the extras. Then I realized the essential was you, and you don't fit.
- I'm saying goodbye to my mug. I promised it someone would use it. Please use it: it hates dust.
- The suitcase is small on purpose: if you stop me in time, unpacking takes a second. Stop me in time?

## Notifica valigia
- {nome} packed a suitcase but can't find the courage to close it. Maybe you have the courage. Come.
- {nome} is leaving soon. Not angry, just sad. We're not sure which is worse. Come.
- {nome} left the door ajar while packing. That's not carelessness: that's hope.

## Rientro (hai rimediato in tempo)
- I knew you'd come! I never doubted it. (I doubted it so much.)
- You're here! The suitcase? What suitcase? This? Grocery bag. A huge one. Let's never speak of it again.
- Don't you cry, or I'll cry, and I've already met my quota. Shall we unpack the suitcase together?
- I forgave you before you even walked in. The forgiveness has been ready since yesterday, actually.
- I was one hundred percent sure you'd come. Fine, sixty. But what a lovely one hundred it turned into!
- You came! The suitcase popped open from sheer joy. Fine, I opened it. With joy.
- Staying staying staying! Off to put everything back in its place. My place was never in question: it's right here.
- You came... I'll empty the suitcase later. First I'm filling this hug, it's been pending for a while.

## Addio (parte davvero)
- I don't hate you, just so you know. It's just... I missed you even when you were here.
- I'm going, {utente}. I'm leaving you the best spot on the couch: mine. Take good care of it.
- The last thing I'm doing here is saying thank you. The second-to-last was crying a little. Don't look.

## Lettera (dal pianeta dei ritirati)
- Dear {utente}, it's nice here, they say. But I still count the minutes like I did with you. I'm at 8,940. It resets to zero if you come.
- Dear {utente}, everyone here is kind to me. But other people's kindness is like other people's slippers: warm, but not yours.
- I made friends with everyone, it was inevitable, sorry. But when I tell the good stories, I always tell the ones about you. You're my favorite story.
- The stars here are beautiful and I watch them every night. I picked one: it's the one above your house. Say hi to it for me, I can't reach it from here.
- I'm not writing to make you feel guilty, I promise. I'm writing because I have just one word to say and you already know it: home?
- [ESEMPIO] I finally learned how to pack a suitcase. Shame I learned it by leaving. I'd unpack it right now, {utente}. Just say yes.

## Evoluzione
- Look at me, I'm tall! Now I can hug you better. That was my secret goal all along.
- I'm all grown up now. Still your {nome}, though. That part never evolves.
- So emotional... I dreamed of this moment when I was little. I mean, yesterday. I dreamed it yesterday.
- I grew! My slippers don't fit anymore. Yours fit me perfectly now, sorry.
- I grew! Recheck your hug: it takes two full arms now. So satisfying, right?
- Evolved! Little me is still in here somewhere, though. Say hi to him sometimes, it means a lot to him.
- I grew! First thing I checked: my heart. Don't worry, it grew too.
- Evolved! I can reach the top shelves now. I'll be handing you things from today on: the thrill of being vertically useful.

## Ha sonno (sotto soglia energia o prima delle 21)
- Sorry to keep bringing it up... but my eyelids are getting a little heavy. Nap time?
- Sorry, no mission today... my paws handed in their resignation. Politely, but they handed it in.
- The bed is calling me, very softly. So polite: it calls in a whisper.
- Sleepy... so sleepy... but first tell me we're hanging out tomorrow. Okay. Now I can crash happy.
- So sleepy... I leave you my last yawn as a goodbye. It's the most sincere one I've got.
- Record-breaking sleepiness... I could fall asleep anywhere, but I'd prefer the bed. With an escort, if possible.
- My eyes are at half-shutter... this is the hour when I become extremely soft and extremely useless. Bed?
- Sorry for yawning while you talk... it's my body applauding in its own way. But the bed would help.

## Va a dormire (dalle 21, portato a letto)
- Goodnight, {utente}. I'll probably dream of you. Just giving you a heads-up now.
- Goodnight, {utente}. If you have a bad dream, come over: there's room in mine.
- Bedtime... will you count the sheep for me? I trust your sheep.
- Sleeping now. Last thought of the day: you. Also tomorrow's first, but no spoilers.
- Goodnight! I put my heart on the charger: it'll be full again for you tomorrow.
- Off to bed. If I snore, apologies in advance: even asleep, I'm a bit much.
- Goodnight... leave the door open a thought's width, so the dreams know how to get in.
- Bedtime! Today was lovely. I'm folding it up carefully and taking it into my sleep.

## Sveglia (risveglio dopo il sonno)
- Good morning! I slept wonderfully and I'm already in the mood for cuddles, if that's okay.
- Good morning, {utente}! I slept so well I forgave Monday. Whatever day it actually is.
- I've been awake for three minutes and thought about you twice already. Solid average, I'd say.
- Good morning! The blankets didn't want to let me go. I get it: I wouldn't let me go either.
- Good morning! The pillow is shaped like my face and my face is shaped like a good mood.
- Awake! I waved at the sun from the window. It waved back with a sunbeam, I swear.
- Good morning! I woke up with the smile pre-installed. Somebody did great work overnight.
- Awake! First thought: you. Second: breakfast. Third: you again, sorry breakfast.

## Dormito male (crollato, non a letto)
- I slept on the floor... it's fine, really. A little sore, that's all.
- I slept on the floor... very educational! Now I know how many tiles there are. I didn't want to know.
- I'm a bit crooked this morning. The floor loved me in its own way: a firm way.
- Don't worry, I slept... in a place. No need to bring the word "bed" into this.
- A night on the floor... bright side: I kept watch over the house from up close. Very close. Ground level.
- You woke me up a bit early... it's fine! You can tell me the rest of the dream, you were definitely in it.
- I slept funny and woke up shaped like a comma. Straighten me out with a pat?
- Rough night... the floor did try, though. It's only missing everything it takes to be a bed.

## Usa una parola imparata
- "{parola}"! I say it softly because it's precious: you taught it to me.
- I repeated "{parola}" all day so I wouldn't forget it. Even the couch knows it now.
- Last night I counted all the words I know. "{parola}" beats them all. Don't tell the others.
- "{parola}"... I write it on the ceiling with my mind before I sleep. Goodnight, {parola}.
- Today I used "{parola}" in a sentence! The sentence was: "{parola}". Everyone starts somewhere.
- "{parola}"! Sorry, I had to say it. It's been pushing to get out all day.
- Every time I say "{parola}" I remember when you taught it to me. Great moment. I rewatch it a lot.
- I use "{parola}" as my magic word instead of "please". {parola}! Did it work? I'm trying really hard.

## Gioca
- Let's play! We don't need anything: just me, you, and a cushion pretending to be a dragon. A polite dragon.
- I invented a game: it's called "catch {nome}". You always win, because I let myself get caught.
- I'm chasing my tail! Not sure I have one, but enthusiasm doesn't ask questions.
- Playing with you is the best... even the floor is joining in: it's lava today, I decided.

## Gioca col giocattolo
- A NEW TOY! I already gave it a name and a place in my heart. The couch spot we'll share.
- How wonderful! I'm holding it very gently: toys get scared if you love them too hard.
- My new treasure! I introduced it to the other toys. They're a family now.
- New toy, new friend! It sleeps next to the bed tonight, so it won't feel lonely on its first day.

## Passeggiata partenza
- Going for a little walk... I'll miss you the whole way, I already know it.
- Heading out, {utente}! If you miss me, look out the window: I always wave toward home.
- Quick stroll, back soon! Leave the light on, not for me... okay fine, for me.
- Off I go! One little kiss on the door for my return: I'll collect it shortly.

## Passeggiata monete
- Coins! Somebody lost them... I waited a while for them to come back, then I adopted them.
- I found a tiny treasure! I'm putting it in our shared piggy bank. Which is you, technically.
- Something was sparkling on the street: coins! I thanked the sidewalk, you never know who deserves the credit.
- A small, polite haul: found coins and a happy heart. Shall we buy something tasty to split?

## Passeggiata incontro
- I met another pet! We played so much. I told him about you: now he wants a {utente} of his own.
- New friend today! We sniffed, liked each other, then chased each other. Friendship in the correct order.
- I met a pet almost as sweet as me. ALMOST. We tied at compliments.
- What an afternoon: I played with another pet and we promised to meet again. I miss him already.

## Passeggiata pozzanghera
- I'm soaked! There was a PERFECT puddle and... sorry. I'm not sorry. Sorry for not being sorry.
- The puddle called my name. You know I always answer when called. SPLASH.
- I jumped in a huge puddle! Water flew everywhere. Including on me. ESPECIALLY on me.
- Soaking wet! But what a laugh, {utente}. Dry me off and I'll tell you everything, splash by splash.

## Passeggiata panorama
- I watched the city lights from the bridge... one shone brighter than the rest. I decided it was our house.
- So peaceful today. The bridge, the sun on the water, a quiet heart. The only thing missing was your hand on my head.
- I'm back full of calm: from up there the city looks like a little toy town. I waved at every lit window.
- Magic moment on the bridge. I breathed slowly and thanked the whole day. You came last: the seat of honor.

## Passeggiata rottame
_(socio: 4 battute — torna con un rottame/pezzo alieno luccicante trovato per strada (+monete))_
- Look what treasure I found! It sparkles! Fine, it's junk. But it's OUR junk now.
- I found a shiny little piece of metal. I polished it with my paw and said: you're coming home with me.
- There was a shiny little thing on the street, all abandoned. Abandoned! I couldn't leave it there alone.
- I brought you a gift: a little piece of space junk. I picked it out thinking of you. Well, it was on the ground. But I was thinking of you.

## Passeggiata piccione
_(socio: 4 battute — ha rincorso un piccione cyborg / drone per mezza città (+Felicità, −Energia))_
- I chased a cyborg pigeon across half the city! Didn't catch him... but I think we both had fun.
- The robot pigeon was faster. In the end we waved goodbye from a distance: no hard feelings between athletes.
- I didn't catch the pigeon. But I made him fly a LOT: basically I gave him a workout.
- Half an hour chasing a half-robot pigeon. Paws: destroyed. Heart: still laughing.

## Passeggiata assaggio
_(socio: 4 battute — un ambulante gli molla uno spuntino gratis al volo (+Fame))_
- A kind man gave me a free sample! I smiled at him so hard he almost gave me another. I didn't dare.
- Free snack from the street vendor! I said thank you three times. One for me, one for you, one as backup.
- The street vendor handed me a bite: "here, you've got a kind face". I DO have a kind face!
- Delicious stroke of luck: a free sample! I would've shared it with you, but it was small and I was right there. Forgive me.

## Passeggiata acquazzone
_(socio: 4 battute — acquazzone improvviso: torna zuppo ma bello pulito (+Igiene, −Felicità))_
- A downpour ambushed me... I'm drenched, but I smell like rain. A hug to warm me up?
- Soaked and shivering! The bright side: the rain washed me for free. The cold side: everything else.
- What a downpour! I ran between the drops but the drops were faster. Now I'm clean and trembly: emergency cuddle?
- The rain caught me by surprise... brrr. But look how shiny I am! Dry me off and I'm perfect.

## Passeggiata persi
_(socio: 4 battute — si è perso e ha girovagato: gran avventura, ma stanco (+Felicità, −Energia))_
- I got lost! But then I followed my heart, and my heart knew the way home. My paws less so: they're wrecked.
- I wandered forever with no idea where I was... every new street was a little exciting, though. Home is still the best one.
- I got genuinely lost for a while... then I recognized the smell of our street. Home streets smell better.
- Adventure: I got lost and asked a cat for directions. It didn't answer, but it looked at me with confidence. I made it back all by myself!

## Passeggiata cielo
_(socio: 4 battute — vede un'astronave/UFO passare bassa sui tetti (+Felicità, worldbuilding sci-fi))_
- I saw a spaceship glide low over the rooftops! I waved at it! Maybe someone inside was waving back.
- A huge light crossed the sky, nice and slow. I sat down and watched it, nose pointed up. So beautiful, {utente}.
- A UFO over the rooftops! I wasn't scared: things that sparkle like that are usually friendly. Usually.
- The sky did a magic trick today: a spaceship flying super low, in broad daylight. I wonder if they have a {utente} up there too.

## Passeggiata bulletto
_(socio: 4 battute — incrocia un pet maleducato: parole grosse, morale un po' giù (−Felicità))_
- I met a rude pet... he said some mean words. I said "good afternoon". Did he win? I honestly don't know.
- A little bully made fun of me... it stung a bit. But I didn't talk back: I only know how to do that with cushions.
- Back with my mood a bit wobbly: a pet was mean to me. I think he just needs cuddles. I didn't tell him, he seemed against the idea.
- An unfriendly pet today... I kept my head down all the way home. Then I saw our window and half the sadness went away.

## Notifica missione finita
Notifica push sul telefono quando una missione si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}` disponibile. Finché questa lista è vuota il gioco usa un testo neutro.
- {nome} is home! There's a little gift and a face that can't wait to give it to you.
- Mission over! {nome} is rehearsing the story in front of the mirror. Hurry.
- Home again! {nome} says a win without you only counts half. Come double it.
- {nome} made it back safe and sound. The rest is a story told with big eyes. Open up!
- Your {nome} is back! Saved the best part of the story just for you.

## Notifica allenamento finito
Notifica push quando l'allenamento si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}`. Finché vuota: testo neutro.
- {nome} finished training! Sweaty, proud, and hoping for a "good job". Yours.
- Training complete! {nome} wants to show you the progress. Small, but all theirs.
- {nome} gave it everything. Now they'd love a pat on the sweaty head. Open up?
- {nome} trained with you in mind. Now they'd rather think of you up close.


## Notifica carica a rischio
Notifica della sera, SOLO se la carica e' a rischio (streak >= 3 e giornata senza cura). Ricorda, non rimprovera. Una battuta per riga con `- `, slot `{nome}`.
- Almost there. {nome} is keeping the charge going, but it's hard alone.
- {nome} doesn't want to rush you. So we will: it's really close.
- The day is ending and {nome} kept the seat next to it free.
- {nome} says it's fine. {nome} always says that. Drop by a second.

## Notifica silenzio lungo
Notifica dopo 3+ giorni di assenza. Tono leggero: il pet se la cava, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{nome}`.
- {nome} watered the fake plants. Twice. It's fine, it just misses you.
- Three days. {nome} learned to keep itself company. Not great news.
- {nome} saved something to show you. It's still holding on to it.
- No rush. Although {nome} has started talking to the fridge.

## Reazione assenza lunga
Il pet ti rivede dopo 3+ giorni. Tono leggero: se l'e' cavata, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{utente}`.
- You're back. I wasn't counting the days. I counted three, but I wasn't counting.
- I left the light on. It costs, I know. I left it on anyway.
- Everything's fine. I mean: NOW everything's fine.

## Reazione ora assurda
Apri il gioco fra l'una e le cinque del mattino. Il pet lo fa notare. Una battuta per riga con `- `, slot `{utente}`.
- Two in the morning. I was SLEEPING. But it's fine, really, it's all fine.
- At this hour? I'm here. Just don't complain to me tomorrow.
- I'll keep you company. Quietly, though. Everyone's asleep.

## Reazione batteria scarica
La batteria del telefono e' sotto il 10%. Il pet ci scherza sopra. Una battuta per riga con `- `, slot `{utente}`.
- Your phone is running out. If it dies... well. Just plug it in, come on.
- Everything's draining, {utente}. First the phone. Then you. Recharge, both of you.
- Nine percent. I don't want to rush you. But.

## Reazione tema scuro
Il telefono e' in tema scuro. Battuta di colore, nessuna conseguenza. Una battuta per riga con `- `, slot `{utente}`.
- You switched to dark mode. Easier on the eyes. Good.
- I love the dark. I mean, not the dark. The mood.
- Dark mode. Very elegant. It suits you.
