window.PETQ = window.PETQ || {};

(function () {

  // i18n bilingue (v. ui.js/i18n.js): SOLO le etichette/msg "telaio" generate qui dal codice
  // (invenzione/miracolo). MAI gli effetti/nomi che arrivano da content/talenti.md.
  var traduci = (PETQ.i18n && PETQ.i18n.t) || function (s) { return s; };

  // ==================== Talenti (PROTOTIPO 2, Blocco 9) ====================
  // Sistema NUOVO e DISTINTO dai perk di categoria (arredi.perkAttivi, Player One/Street
  // Fighter/Tony Hawk). I talenti definiscono la BUILD del pet: 1 estratto alla nascita dalla
  // terna della sua personalita', +1 estratto alla evoluzione teen (cumulativi, v.
  // content/talenti.md). Questo modulo copre: l'estrazione pesata 45/45/10 (usata da pet.js
  // generate/controllaEvoluzione), i due effetti passivi semplici del batch core (bonus stat
  // piatto, cap coccole) e il GRUPPO A (Cibo/Allenamento/Energia, v. sezione dedicata sotto).
  // Tutti gli altri token del DSL "Dati" sono PARSATI (v. content.js parseTalenti ->
  // talento.effetti) ma NON ancora agganciati: v. registry TODO in fondo al file.

  // ---------- estrazione pesata 45/45/10 (generalizzata a N normali + 1 raro) ----------
  // Terna/quaterna = [normale, normale, (normale,) raro] (ordine come scritto in talenti.md, v.
  // content.js parseSezionePersonalitaTalenti: la riga con 🟡 e' sempre l'ultima in tabella ma
  // qui NON assumiamo l'ordine — selezioniamo per il flag `raro` cosi' il codice resta corretto
  // anche se in futuro il socio riordina le righe nel file). Schema atteso: il raro vale SEMPRE
  // 10%, i normali si dividono il restante 90% in parti uguali — con 2 normali fa 45/45/10 (P2,
  // nascita/teen); con 3 normali fa 30/30/30/10 (alcune sezioni Adulto P3, v. talenti.md
  // "quaterna 30/30/30/10"). Generalizzato cosi' invece di if/else dedicati per ogni cardinalita'.
  function estraiDaTerna(terna) {
    if (!terna || terna.length === 0) return null;
    var rari = [];
    var normali = [];
    for (var i = 0; i < terna.length; i++) {
      if (terna[i].raro) rari.push(terna[i]);
      else normali.push(terna[i]);
    }
    // caso atteso: N normali (N>=1) + esattamente 1 raro. Fallback tollerante se lo schema non
    // e' rispettato (es. 0 normali, 2+ rari, file mal formattato): pesca uniforme su tutta la
    // terna invece di rompere il gioco.
    if (normali.length < 1 || rari.length !== 1) {
      console.warn('PETQ.talenti: terna non nello schema N normali + 1 raro, estrazione uniforme di fallback', terna);
      return PETQ.rng.pick(terna);
    }
    var r = PETQ.rng.rand(); // [0,1)
    if (r < 0.90) {
      var quotaNormale = 0.90 / normali.length;
      var idx = Math.min(normali.length - 1, Math.floor(r / quotaNormale));
      return normali[idx];
    }
    return rari[0];
  }

  // Estrae 1 talento dalla terna <stadio> della <personalita>, dai dati caricati in
  // PETQ.content.data.talenti. Ritorna una COPIA superficiale del talento con in piu' il campo
  // `stadio` (serve alla scheda personaggio per mostrare "da quale stadio" viene), oppure null
  // se i dati non sono disponibili (content non ancora caricato, personalita sconosciuta, ecc).
  function estrai(personalita, stadio) {
    var data = window.PETQ.content && window.PETQ.content.data && window.PETQ.content.data.talenti;
    var bloccoPers = data && data[personalita];
    var terna = bloccoPers && bloccoPers[stadio];
    if (!terna || terna.length === 0) {
      console.warn('PETQ.talenti: nessuna terna "' + stadio + '" per personalita "' + personalita + '"');
      return null;
    }
    var scelto = estraiDaTerna(terna);
    if (!scelto) return null;
    var copia = {
      nome: scelto.nome,
      raro: !!scelto.raro,
      effettoTesto: scelto.effettoTesto,
      dati: scelto.dati,
      effetti: (scelto.effetti || []).slice(),
      stadio: stadio
    };
    return copia;
  }

  // ---------- lettura talenti attivi dal pet ----------

  function talentiAttivi(state) {
    if (!state || !state.pet || !Array.isArray(state.pet.talenti)) return [];
    return state.pet.talenti;
  }

  // Cerca dentro talento.effetti un token che inizia con "<chiave>=" (es. "passivo=forza+2",
  // "cap_coccole=8"). Ritorna la stringa dopo il '=' (trim), o null se non presente. Un talento
  // puo' avere piu' token con la stessa chiave (es. "passivo=forza+2" e non ce ne sono altri in
  // questo batch, ma la firma resta pronta per i futuri).
  function trovaToken(effetti, chiave) {
    if (!effetti) return null;
    var prefisso = chiave + '=';
    for (var i = 0; i < effetti.length; i++) {
      var t = (effetti[i] || '').trim();
      if (t.indexOf(prefisso) === 0) return t.substring(prefisso.length).trim();
    }
    return null;
  }

  // ---------- effetto 1: passivo=stat+N ----------
  // Somma i bonus "passivo=<stat>+N" dei talenti attivi, PARI PARI al pattern di
  // arredi.bonusPassivi (stessa forma di ritorno {forza,intelligenza,velocita,carisma}). A
  // differenza degli arredi qui NON c'e' un cap dedicato nel design (talenti.md non lo cita):
  // nessun clamp applicato, i talenti passivi sono pochi e cumulativi per design (nascita+teen).
  var STAT_NOMI = ['forza', 'intelligenza', 'velocita', 'carisma'];

  // "forza+2" / "velocita+2" / "int+3" (talenti.md usa anche l'abbreviazione "int" nella legenda,
  // v. Cervellone "passivo=int+3"): normalizziamo l'alias qui, stesso spirito di
  // STAT_CANON_ESATTI/normalizzaStatNome in content.js (e di EFFETTO_ALIAS per i cibi).
  var STAT_ALIAS_TALENTI = { int: 'intelligenza', forza: 'forza', velocita: 'velocita', carisma: 'carisma' };

  function parsePassivo(valore) {
    // valore atteso: "<stat><+/-><numero>", es. "forza+2", "int+3"
    var m = (valore || '').match(/^([a-z]+)\s*([+-]\d+)$/i);
    if (!m) return null;
    var statAlias = m[1].toLowerCase();
    var stat = STAT_ALIAS_TALENTI[statAlias] || (STAT_NOMI.indexOf(statAlias) !== -1 ? statAlias : null);
    if (!stat) return null;
    return { stat: stat, valore: parseInt(m[2], 10) };
  }

  function bonusStatTutte(state) {
    var somma = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var valGrezzo = trovaToken(attivi[i].effetti, 'passivo');
      if (valGrezzo) {
        var parsed = parsePassivo(valGrezzo);
        if (parsed && typeof somma[parsed.stat] === 'number') {
          somma[parsed.stat] += parsed.valore;
        }
      }

      // Talenti (PROTOTIPO 2, Blocco 9, Gruppo C, "se igiene<50: passivo=int+2", Idrofobico):
      // passivo CONDIZIONALE, non un "passivo=" secco come sopra (il token e' un'unica stringa
      // libera "se igiene<50: passivo=int+2", stesso stile di "se fallimento_carattere: ..." in
      // badLoserEffetto). NB: va controllato SEMPRE per ogni talento (niente early-continue sopra
      // se manca il "passivo=" semplice: Idrofobico ha SOLO il condizionale, nessun "passivo="
      // piatto, quindi un continue anticipato lo salterebbe del tutto). Sommato qui dentro
      // bonusStatTutte (non in un helper separato) cosi' TUTTI i chiamanti esistenti (ui.js
      // statConBonus/scheda, missions.bonusStatCombinato) lo vedono gratis, dinamicamente.
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        var mCond = t.match(/^se\s+igiene\s*<\s*(\d+)\s*:\s*passivo\s*=\s*([a-z]+)\s*([+-]\d+)$/i);
        if (!mCond) continue;
        var soglia = parseInt(mCond[1], 10);
        var igieneAttuale = (state && state.pet && state.pet.stats && typeof state.pet.stats.igiene === 'number') ?
          state.pet.stats.igiene : 100; // fallback ottimistico: senza dato niente bonus condizionale
        if (igieneAttuale >= soglia) continue;
        var statAlias = STAT_ALIAS_TALENTI[mCond[2].toLowerCase()] || (STAT_NOMI.indexOf(mCond[2].toLowerCase()) !== -1 ? mCond[2].toLowerCase() : null);
        if (statAlias && typeof somma[statAlias] === 'number') somma[statAlias] += parseInt(mCond[3], 10);
      }

      // Talenti (P3 BATCH 4, "se fel<30: passivo=forza+5", Furia Cieca): stesso pattern del ramo
      // igiene sopra ma su Felicita' (bonusStat condizionale, token libero, mai un "passivo="
      // secco per questo talento). Ciclo SEPARATO dal ramo igiene (non nello stesso match/regex)
      // cosi' un domani non si intrecciano le due soglie in un'unica regex fragile.
      for (var jf = 0; jf < effetti.length; jf++) {
        var tf = (effetti[jf] || '').trim();
        var mCondFel = tf.match(/^se\s+fel\s*<\s*(\d+)\s*:\s*passivo\s*=\s*([a-z]+)\s*([+-]\d+)$/i);
        if (!mCondFel) continue;
        var sogliaFel = parseInt(mCondFel[1], 10);
        var felAttuale = (state && state.pet && state.pet.stats && typeof state.pet.stats.felicita === 'number') ?
          state.pet.stats.felicita : 100; // fallback ottimistico: senza dato niente bonus condizionale
        if (felAttuale >= sogliaFel) continue;
        var statAliasFel = STAT_ALIAS_TALENTI[mCondFel[2].toLowerCase()] || (STAT_NOMI.indexOf(mCondFel[2].toLowerCase()) !== -1 ? mCondFel[2].toLowerCase() : null);
        if (statAliasFel && typeof somma[statAliasFel] === 'number') somma[statAliasFel] += parseInt(mCondFel[3], 10);
      }
    }
    return somma;
  }

  // Bonus talenti per UNA stat sola (comodo per i chiamanti che gia' iterano per stat, es.
  // ui.js statConBonus): ritorna un numero, 0 se nessun talento tocca quella stat.
  function bonusStat(state, statNome) {
    if (!statNome) return 0;
    var somma = bonusStatTutte(state);
    return (typeof somma[statNome] === 'number') ? somma[statNome] : 0;
  }

  // ---------- effetto 2: cap_coccole=N (Coccolone) ----------
  // Default 5 (v. care.js COCCOLA_MAX_DIE / GDD "Coccole"), 8 se il pet ha il talento Coccolone
  // attivo. care.coccola deve chiamare questa funzione invece di usare la costante fissa.
  var CAP_COCCOLE_DEFAULT = 5;

  function capCoccole(state) {
    var attivi = talentiAttivi(state);
    var cap = CAP_COCCOLE_DEFAULT;
    for (var i = 0; i < attivi.length; i++) {
      var valGrezzo = trovaToken(attivi[i].effetti, 'cap_coccole');
      if (valGrezzo === null) continue;
      var n = parseInt(valGrezzo, 10);
      if (!isNaN(n) && n > cap) cap = n; // se mai ci fossero piu' talenti col token, vince il piu' alto
    }
    return cap;
  }

  // ---------- effetto 2b: coccola=fel+N (Coccolone, secondo token) ----------
  // Felicita' EXTRA per ogni coccola (si somma al COCCOLA_EFFETTO base di care.js). Token
  // presente in talenti.md fin da P2 ma MAI agganciato (lacuna trovata nel P3 batch 4): il
  // Coccolone alzava solo il cap giornaliero, non l'effetto della singola coccola. Formato "fel+N".
  function coccolaFelExtra(state) {
    var attivi = talentiAttivi(state);
    var extra = 0;
    for (var i = 0; i < attivi.length; i++) {
      var valGrezzo = trovaToken(attivi[i].effetti, 'coccola');
      if (valGrezzo === null) continue;
      var m = valGrezzo.match(/^fel\+(\d+)/i);
      if (m) extra += parseInt(m[1], 10);
    }
    return extra;
  }

  // ==================== GRUPPO A: Cibo, Allenamento, Energia (PROTOTIPO 2, Blocco 9) ====================
  // Questo batch aggancia SOLO i token elencati qui sotto. Stesso pattern degli effetti sopra:
  // talentiAttivi(state) -> trovaToken(effetti, chiave) -> parse del valore grezzo. Nessun
  // effetto viene "bakeato" sul pet: tutto si legge a runtime da state.pet.talenti, cosi'
  // "Ri-tira talenti" (debug) cambia immediatamente il comportamento in gioco.

  // Alias categorie cibo -> nomi usati nel DSL (content/talenti.md usa "salutare" come
  // categoria ombrello per carne/verdura/pesce, v. Fissato con la Dieta).
  var CATEGORIE_SALUTARI = ['carne', 'verdura', 'pesce'];

  // ---------- CIBO ----------

  // bonus_cibo=<categoria>:+1stat  (es. "carne:forza+1", "verdura:+1stat")
  // bonus_cibo=salutare:+1stat     (Fissato con la Dieta: qualsiasi cibo salutare)
  //
  // Formati osservati in talenti.md (v. legenda + tabelle):
  //   "carne:forza+1"   -> categoria "carne", stat esplicita "forza", +1
  //   "verdura:+1stat"  -> categoria "verdura", "+1 alla stat DEL CIBO" (nessuna stat fissa qui)
  //   "salutare:+1stat" -> categoria ombrello (carne/verdura/pesce), stessa regola "+1 alla stat del cibo"
  //
  // Ritorna il bonus INTERO da sommare alla stat associata al cibo mangiato, o 0 se nessun
  // talento tocca questa categoria. NOTA DI DESIGN (documentata come richiesto dal brief):
  // l'extra scatta SOLO quando scatta anche il bonus stat BASE del cibo, cioe' al primo pasto
  // della categoria nella giornata (v. care.feed, stessa guardia `primaVoltaOggi`) — l'idea e'
  // "premia la dieta varia", non "spamma il cibo giusto per doppio bonus".
  function bonusCiboExtra(state, categoria) {
    if (!categoria) return 0;
    var attivi = talentiAttivi(state);
    var extra = 0;
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        if (t.indexOf('bonus_cibo=') !== 0) continue;
        var valore = t.substring('bonus_cibo='.length).trim();
        var due = valore.indexOf(':');
        if (due === -1) continue;
        var catToken = valore.substring(0, due).trim().toLowerCase();
        var resto = valore.substring(due + 1).trim(); // "forza+1" oppure "+1stat"

        var matchCategoria = (catToken === categoria) ||
          (catToken === 'salutare' && CATEGORIE_SALUTARI.indexOf(categoria) !== -1);
        if (!matchCategoria) continue;

        // "+1stat" (o "+1 stat"): +1 generico alla stat DEL CIBO, il chiamante la assegna.
        // "forza+1" (stat esplicita nel token): qui contiamo comunque solo il NUMERO, perche'
        // bonusCiboExtra ritorna un bonus per "la stat di questo cibo" (care.feed applica
        // sempre alla stessa pet.rpg[cibo.statNome] del bonus base, mai a una stat diversa
        // nei talenti di questo batch: Braccia di Ferro e' "carne:forza+1" e la carne DA'
        // gia' stat forza, quindi il caso "stat esplicita diversa dal cibo" non si presenta).
        var mNum = resto.match(/([+-]\d+)/);
        if (mNum) extra += parseInt(mNum[1], 10);
      }
    }
    return extra;
  }

  // blocca_cibo=<categoria>  (es. "dolce" per Fissato con la Dieta)
  // Ritorna true se un talento attivo blocca questa categoria di cibo.
  function ciboBloccato(state, categoria) {
    if (!categoria) return false;
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'blocca_cibo');
      if (valore && valore.trim().toLowerCase() === categoria) return true;
    }
    return false;
  }

  // ---------- ALLENAMENTO ----------

  // bonus_allenamento=<stat>:+N       (es. "forza:+1", Braccia di Ferro)
  // bonus_allenamento=qualsiasi:<stat>+N (es. "qualsiasi:int+1", Mente Analitica)
  //
  // Ritorna { extra: {forza,intelligenza,velocita,carisma} } cioe' TUTTI i bonus extra da
  // sommare al completamento di un allenamento della stat `statAllenata`: sia quelli mirati
  // alla stessa stat allenata, sia i "qualsiasi" (che vanno SEMPRE, su qualunque stat ci si
  // alleni, e possono dare bonus a UNA STAT DIVERSA, es. Mente Analitica da' +1 Int anche
  // allenando Velocita').
  function bonusAllenamentoExtra(state, statAllenata) {
    var somma = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        if (t.indexOf('bonus_allenamento=') !== 0) continue;
        var valore = t.substring('bonus_allenamento='.length).trim();
        var due = valore.indexOf(':');
        if (due === -1) continue;
        var chiave = valore.substring(0, due).trim().toLowerCase();
        var resto = valore.substring(due + 1).trim();

        if (chiave === 'qualsiasi') {
          // "int+1": stat esplicita + valore, si applica ad OGNI allenamento qualunque sia
          // statAllenata (Mente Analitica: "impara da tutto")
          var parsedQ = parsePassivo(resto.replace(/\s+/g, ''));
          if (parsedQ) somma[parsedQ.stat] += parsedQ.valore;
          continue;
        }

        // chiave e' il nome della stat allenata richiesta (es. "forza"): si applica solo se
        // coincide con la stat che si sta allenando ORA.
        var statAlias = STAT_ALIAS_TALENTI[chiave] || (STAT_NOMI.indexOf(chiave) !== -1 ? chiave : null);
        if (!statAlias || statAlias !== statAllenata) continue;
        var mNum = resto.match(/([+-]\d+)/);
        if (mNum) somma[statAlias] += parseInt(mNum[1], 10);
      }
    }
    return somma;
  }

  // allenamento_durata=x0.5  (Fisico Bestiale: allenamento a meta' tempo)
  // Ritorna il moltiplicatore da applicare a DURATA_ALLENAMENTO_ORE (1 se nessun talento).
  function durataAllenamentoMult(state) {
    var attivi = talentiAttivi(state);
    var mult = 1;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'allenamento_durata');
      if (!valore) continue;
      var m = valore.match(/x\s*([\d.,]+)/i);
      if (m) mult *= parseFloat(m[1].replace(',', '.'));
    }
    return mult;
  }

  // allenamento_energia=+5  (Energico: l'allenamento DA' energia invece di toglierne)
  // Ritorna il delta energia da applicare al completamento allenamento AL POSTO del costo
  // normale (costoAllenamento), o null se nessun talento lo tocca (il chiamante allora usa
  // il comportamento di default, cioe' sottrarre il costo).
  function energiaAllenamentoOverride(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'allenamento_energia');
      if (!valore) continue;
      var m = valore.match(/([+-]\d+)/);
      if (m) return parseInt(m[1], 10); // es. +5: da restituire cosi' com'e' (il chiamante SOMMA)
    }
    return null;
  }

  // allenamenti_giorno=2  (Predestinato: 2 allenamenti/giorno invece di 1)
  // Ritorna il numero massimo di allenamenti "a tempo" concessi in un giorno.
  // RETENTION 2.0 (fondatore 10 lug 2026): il giorno denso era troppo carico -> UN allenamento
  // al giorno che vale +2, stessa matematica del 2x+1 con meta' dei tap. Predestinato scende
  // di conseguenza a allenamenti_giorno=2 (v. talenti.md).
  // Il numero NON e' piu' hardcodato: viene da content/bilanciamento.md ("Sessioni al giorno"),
  // come tutti gli altri numeri di bilanciamento. La costante resta solo come rete di sicurezza
  // se il contenuto non fosse ancora caricato.
  var ALLENAMENTI_GIORNO_DEFAULT = 1;

  function sessioniAllenamentoDaContenuto() {
    var bil = (window.PETQ && PETQ.content && PETQ.content.data && PETQ.content.data.bilanciamento) || null;
    var n = bil && bil.allenamento && bil.allenamento.sessioni;
    return (typeof n === 'number' && n > 0) ? n : ALLENAMENTI_GIORNO_DEFAULT;
  }

  function allenamentiPerGiorno(state) {
    var attivi = talentiAttivi(state);
    var max = sessioniAllenamentoDaContenuto();
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'allenamenti_giorno');
      if (valore === null) continue;
      var n = parseInt(valore, 10);
      if (!isNaN(n) && n > max) max = n;
    }
    // Perk CASA (P3, "Mascellone" m65, v. sezione PERK CASA sotto): +1 allenamento extra,
    // SOMMATO (non "vince il piu' alto" come i talenti sopra: e' un bonus fisso indipendente
    // dal talento del pet, si stacka con qualunque talento gia' presente).
    return max + perkCasaAllenamentoExtra(state);
  }

  // allenamento_extra=int (istantaneo, 1/giorno)  (Sete di Sapere: "Studio veloce")
  // Il token grezzo ha una parte descrittiva tra parentesi (v. talenti.md), qui ci serve solo
  // il nome della stat prima della parentesi. Ritorna il nome stat (es. "intelligenza") se il
  // pet ha questo talento, o null altrimenti.
  function allenamentoExtraStat(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'allenamento_extra');
      if (!valore) continue;
      var primaParola = valore.split(/[\s(]/)[0].trim().toLowerCase();
      var stat = STAT_ALIAS_TALENTI[primaParola] || (STAT_NOMI.indexOf(primaParola) !== -1 ? primaParola : null);
      if (stat) return stat;
    }
    return null;
  }

  // ---------- ENERGIA ----------

  // energia_decay=x0.5  (Energico: decadimento Energia dimezzato)
  // Ritorna il moltiplicatore da applicare al decadimento Energia in pet.applyDecay (1 se
  // nessun talento attivo lo tocca).
  function energiaDecayMult(state) {
    var attivi = talentiAttivi(state);
    var mult = 1;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'energia_decay');
      if (!valore) continue;
      var m = valore.match(/x\s*([\d.,]+)/i);
      if (m) mult *= parseFloat(m[1].replace(',', '.'));
    }
    return mult;
  }

  // ignora_rifiuto_energia  (Fisico Bestiale: mai rifiuto allenamento/missione per energia bassa)
  // Token booleano (nessun "="): presente/assente. Ritorna true se un talento attivo lo ha.
  function ignoraRifiutoEnergia(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        if ((effetti[j] || '').trim() === 'ignora_rifiuto_energia') return true;
      }
    }
    return false;
  }

  // ==================== GRUPPO B: Missioni & Economia (PROTOTIPO 2, Blocco 9) ====================
  // Stesso pattern del Gruppo A: talentiAttivi(state) -> trovaToken/scan di effetti[] -> parse
  // del valore grezzo, letto SEMPRE a runtime (mai bakeato). Gli hook lato missions.js/care.js
  // sono documentati nei commenti li' dove vengono chiamati.

  // Alias per i nomi di stat/risorsa usati nei token missione (in piu' rispetto a
  // STAT_ALIAS_TALENTI c'e' "monete", che non e' una stat RPG ma una risorsa: usata da
  // ogni_missione=monete+5 di Cuore Magnetico).
  var CHIAVE_ALIAS_MISSIONI = { int: 'intelligenza', forza: 'forza', velocita: 'velocita', carisma: 'carisma', monete: 'monete' };

  function chiaveMissioneValida(chiave) {
    return CHIAVE_ALIAS_MISSIONI[chiave] || (STAT_NOMI.indexOf(chiave) !== -1 ? chiave : null);
  }

  // ---------- ogni_missione=<stat|monete>+N (Spirito Agonistico, Mani Lestre, Cuore Magnetico) ----------
  // Ritorna { forza, intelligenza, velocita, carisma, monete } da sommare ad OGNI missione
  // completata (qualsiasi esito non-null: super/standard/fallimento), a prescindere dalla
  // categoria. Il chiamante (missions.risolvi) applica dopo aver scelto l'esito, sempre.
  function bonusOgniMissione(state) {
    var somma = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0, monete: 0 };
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        if (t.indexOf('ogni_missione=') !== 0) continue;
        var valore = t.substring('ogni_missione='.length).trim();
        var m = valore.match(/^([a-z]+)\s*([+-]\d+)$/i);
        if (!m) continue;
        var chiave = chiaveMissioneValida(m[1].toLowerCase());
        if (!chiave) continue;
        somma[chiave] += parseInt(m[2], 10);
      }
    }
    return somma;
  }

  // ---------- bonus_missione=<categoria>:<stat>+N[,durata-1h] (Topo di Biblioteca, Pacifista) ----------
  // Formato osservato in talenti.md:
  //   "sociale:carisma+1"          -> categoria "sociale", +1 Carisma extra all'esito
  //   "studio:int+1,durata-1h"     -> categoria "studio", +1 Int extra all'esito E -1h di durata
  //                                    all'avvio della missione
  // Ritorna { statExtra: {forza,intelligenza,velocita,carisma}, durataDeltaH } per la CATEGORIA
  // passata (0/{} se nessun talento tocca quella categoria). durataDeltaH e' un numero di ORE
  // (negativo = accorcia), da sommare a quello globale di missioneDurataDeltaH.
  function bonusMissioneCategoria(state, categoria) {
    var statExtra = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    var durataDeltaH = 0;
    if (!categoria) return { statExtra: statExtra, durataDeltaH: durataDeltaH };
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        if (t.indexOf('bonus_missione=') !== 0) continue;
        var valore = t.substring('bonus_missione='.length).trim();
        var due = valore.indexOf(':');
        if (due === -1) continue;
        var catToken = valore.substring(0, due).trim().toLowerCase();
        if (catToken !== categoria) continue;
        var resto = valore.substring(due + 1).trim(); // "int+1,durata-1h" oppure "carisma+1"

        var parti = resto.split(',');
        for (var k = 0; k < parti.length; k++) {
          var p = parti[k].trim();
          var mStat = p.match(/^([a-z]+)\s*([+-]\d+)$/i);
          if (mStat) {
            var statAlias = STAT_ALIAS_TALENTI[mStat[1].toLowerCase()] || (STAT_NOMI.indexOf(mStat[1].toLowerCase()) !== -1 ? mStat[1].toLowerCase() : null);
            if (statAlias) statExtra[statAlias] += parseInt(mStat[2], 10);
            continue;
          }
          var mDurata = p.match(/^durata\s*([+-]?\d+(?:[.,]\d+)?)\s*h$/i);
          if (mDurata) {
            durataDeltaH += parseFloat(mDurata[1].replace(',', '.'));
          }
        }
      }
    }
    return { statExtra: statExtra, durataDeltaH: durataDeltaH };
  }

  // ---------- bonus_missione_monete=x1.5 (Cleptomane, Boss di Quartiere) ----------
  // Ritorna il moltiplicatore da applicare alle monete di reward di UNA missione (1 se nessun
  // talento attivo). Talenti.md non distingue "solo missioni a monete" da "tutte le missioni"
  // nel token (e' lo stesso token per entrambi, il testo cambia solo la descrizione): applicarlo
  // al token monete di reward quando c'e' basta, perche' se la missione non da' monete non c'e'
  // nessun token su cui moltiplicare.
  function bonusMissioneMoneteMult(state) {
    var attivi = talentiAttivi(state);
    var mult = 1;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'bonus_missione_monete');
      if (!valore) continue;
      var m = valore.match(/x\s*([\d.,]+)/i);
      if (m) mult *= parseFloat(m[1].replace(',', '.'));
    }
    return mult;
  }

  // ---------- mancia=x3 (Cuore Magnetico) ----------
  // Ritorna il moltiplicatore da applicare alla mancia post-missione (v. missions.calcolaMancia,
  // GDD "Economia": "mance post-missione che scalano col carisma", bilanciamento.md "Mancia
  // post-missione: 1 moneta ogni 5 punti di Carisma"). 1 se nessun talento la tocca.
  function manciaMult(state) {
    var attivi = talentiAttivi(state);
    var mult = 1;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'mancia');
      if (!valore) continue;
      var m = valore.match(/x\s*([\d.,]+)/i);
      if (m) mult *= parseFloat(m[1].replace(',', '.'));
    }
    // Perk CASA (P3, "The Crown" m69, v. sezione PERK CASA sotto): mance x2, si moltiplica
    // insieme a un eventuale talento futuro che tocchi la mancia (nessuno oggi la tocca).
    mult *= perkCasaManciaMult(state);
    return mult;
  }

  // ---------- login=monete+10 (Cuore Magnetico) ----------
  // Ritorna il bonus monete EXTRA da sommare al login giornaliero (0 se nessun talento attivo).
  function loginBonusMonete(state) {
    var attivi = talentiAttivi(state);
    var extra = 0;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'login');
      if (!valore) continue;
      var m = valore.match(/^monete\s*([+-]\d+)$/i);
      if (m) extra += parseInt(m[1], 10);
    }
    return extra;
  }

  // ---------- missione_durata=-1h (Fulmine di Quartiere) ----------
  // Ritorna il delta ORE globale (negativo = accorcia) da applicare a TUTTE le missioni, prima
  // del clamp al minimo di 1h fatto dal chiamante (missions.avvia). Combinabile col delta di
  // categoria di bonusMissioneCategoria (es. Fulmine + un ipotetico bonus_missione di categoria
  // si sommerebbero entrambi, anche se nessun talento attuale li unisce sullo stesso pet).
  function missioneDurataDeltaH(state) {
    var attivi = talentiAttivi(state);
    var delta = 0;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'missione_durata');
      if (!valore) continue;
      var m = valore.match(/^([+-]?\d+(?:[.,]\d+)?)\s*h$/i);
      if (m) delta += parseFloat(m[1].replace(',', '.'));
    }
    return delta;
  }

  // ---------- fallimento=fel-0 (Faccia di Bronzo) ----------
  // Booleano: true se un talento attivo annulla la perdita di Felicita' dei fallimenti missione.
  // NB combo voluta col -10 Felicita' extra di Bad Loser: quando entrambi sono attivi, questo
  // annulla ANCHE quell'extra (v. missions.risolvi, applicato per ultimo su tutto il delta fel
  // accumulato dal fallimento).
  function fallimentoFelBloccato(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'fallimento');
      if (valore && /^fel\s*-?0$/i.test(valore.trim())) return true;
    }
    return false;
  }

  // ---------- se fallimento_carattere: reward=x2, fel-10 (Bad Loser) ----------
  // Il token e' un'unica stringa libera (nessun "chiave=valore" pulito, v. talenti.md): la
  // riconosciamo per il prefisso fisso "se fallimento_carattere:" e ne ricaviamo i due numeri
  // (moltiplicatore reward, malus Felicita' estra) invece di hardcodarli, cosi' se il fondatore
  // ritocca i valori in talenti.md basta cambiare il testo, non il codice.
  // Ritorna { moltReward, felExtra } o null se il pet non ha questo talento.
  function badLoserEffetto(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        if (t.toLowerCase().indexOf('se fallimento_carattere:') !== 0) continue;
        var resto = t.substring(t.indexOf(':') + 1).trim(); // "reward=x2, fel-10"
        var moltReward = 1;
        var felExtra = 0;
        var mMol = resto.match(/reward\s*=\s*x\s*([\d.,]+)/i);
        if (mMol) moltReward = parseFloat(mMol[1].replace(',', '.'));
        var mFel = resto.match(/fel\s*([+-]\d+)/i);
        if (mFel) felExtra = parseInt(mFel[1], 10);
        return { moltReward: moltReward, felExtra: felExtra };
      }
    }
    return null;
  }

  // ---------- blocca_categoria=combattimento (Pacifista) ----------
  // Ritorna true se un talento attivo esclude questa categoria dalla rosa del giorno.
  function categoriaBloccata(state, categoria) {
    if (!categoria) return false;
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'blocca_categoria');
      if (valore && valore.trim().toLowerCase() === categoria) return true;
    }
    return false;
  }

  // ---------- perk_tag=<tag> (Amante della Natura -> 'natura', Inventore -> 'invenzione') ----------
  // AGGANCIATO (batch tag missioni): le schede portano ora un array scheda.tag (v. content.js).
  // Ritorna true se un talento attivo del pet ha "perk_tag=<tag>" che coincide col tag chiesto.
  // Usato da missions.scegliEsito: super GARANTITO + NIENTE fallimento sulle missioni con quel tag.
  // Stesso pattern di categoriaBloccata (talentiAttivi -> trovaToken(effetti,'perk_tag') -> confronto).
  function perkTagAttivo(state, tag) {
    if (!tag) return false;
    var attivi = talentiAttivi(state);
    var t = String(tag).trim().toLowerCase();
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'perk_tag');
      if (valore && valore.trim().toLowerCase() === t) return true;
    }
    return false;
  }

  // ==================== GRUPPO C: Salute, Sonno, Igiene, Parole (PROTOTIPO 2, Blocco 9) ====================
  // Stesso pattern dei gruppi precedenti: talentiAttivi(state) -> trovaToken/scan di effetti[]
  // -> parse del valore grezzo, letto SEMPRE a runtime (mai bakeato). Gli hook lato
  // pet.js/care.js/dialog.js sono documentati nei commenti li' dove vengono chiamati.

  // ---------- immune_malus_condizioni (Anima Candida) ----------
  // Booleano: true se un talento attivo azzera il malus Salute da malus condizioni (fame/igiene/
  // energia basse prolungate, cacca accumulata, dieta squilibrata). Usato da pet.malusCondizioni
  // per ritornare 0 SENZA nemmeno calcolare i singoli malus (il pet resta comunque "sporco" o
  // "affamato" nelle stat dirette, solo il malus SALUTE aggiuntivo sparisce).
  function immuneMalusCondizioni(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        if ((effetti[j] || '').trim() === 'immune_malus_condizioni') return true;
      }
    }
    return false;
  }

  // ---------- notte=ferite=0 (Anima Candida) ----------
  // Booleano: true se un talento attivo azzera le Ferite ad ogni nuovo giorno (invece della
  // guarigione naturale -5, v. pet.guarisciGiorno). Il chiamante (care.dailyLogin) decide se
  // azzerare del tutto o sommare alla guarigione normale: qui ritorniamo solo "il pet ha questo
  // talento", la MECCANICA (azzerare vs sottrarre) resta nel chiamante per restare vicino al
  // pattern esistente (stesso principio di ignoraRifiutoEnergia/energiaAllenamentoOverride: il
  // modulo talenti dice COSA, il modulo di gioco decide COME applicarlo allo stato).
  function azzeraFeriteNotte(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        if (/^notte\s*=\s*ferite\s*=\s*0$/i.test(t)) return true;
      }
    }
    return false;
  }

  // ---------- infermeria_costo=-5 / infermeria_cura=+10 (Infermiere Provetto) ----------
  // infermeriaModCosto: delta da SOMMARE al costo base dell'infermeria (care.CURA_COSTO), es.
  // -5 -> 15-5=10. infermeriaModCura: delta da SOMMARE alle Ferite ridotte dalla cura
  // (care.CURA_FERITE_RIDOTTE), es. +10 -> 30+10=40. Entrambi 0 se nessun talento li tocca.
  function infermeriaModCosto(state) {
    var attivi = talentiAttivi(state);
    var delta = 0;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'infermeria_costo');
      if (!valore) continue;
      var m = valore.match(/^([+-]?\d+)$/);
      if (m) delta += parseInt(m[1], 10);
    }
    return delta;
  }

  function infermeriaModCura(state) {
    var attivi = talentiAttivi(state);
    var delta = 0;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'infermeria_cura');
      if (!valore) continue;
      var m = valore.match(/^([+-]?\d+)$/);
      if (m) delta += parseInt(m[1], 10);
    }
    return delta;
  }

  // ---------- risveglio=ferite-10 (Infermiere Provetto) ----------
  // Ritorna il delta Ferite (gia' col segno, es. -10) da applicare ad OGNI risveglio dal sonno,
  // o 0 se nessun talento attivo lo tocca. Il chiamante (pet.risolviRisveglio) somma questo
  // delta a state.ferite (clampato) dopo aver applicato l'energia del risveglio.
  function risveglioFeriteDelta(state) {
    var attivi = talentiAttivi(state);
    var delta = 0;
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        var m = t.match(/^risveglio\s*=\s*ferite\s*([+-]\d+)$/i);
        if (m) delta += parseInt(m[1], 10);
      }
    }
    return delta;
  }

  // ---------- igiene_felicita=inverti (Idrofobico) ----------
  // Booleano: true se un talento attivo inverte la relazione Igiene<->Felicita'. Usato SOLO da
  // pet.applyDecay per la parte Felicita' del decadimento: il malus Salute da sporco (v.
  // malusCondizioni "igieneBassaMalus") NON e' toccato da questo helper (resta invariato, e' il
  // contrappeso voluto dal design, v. talenti.md "nota=malus_salute_sporco_resta").
  function igieneFelicitaInvertita(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'igiene_felicita');
      if (valore && valore.trim().toLowerCase() === 'inverti') return true;
    }
    return false;
  }

  // ---------- parole_giorno=4 (Cervellone) ----------
  // Ritorna il numero massimo di parole insegnabili al giorno (default 1, 4 con Cervellone).
  var PAROLE_GIORNO_DEFAULT = 1;

  function parolePerGiorno(state) {
    var attivi = talentiAttivi(state);
    var max = PAROLE_GIORNO_DEFAULT;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'parole_giorno');
      if (valore === null) continue;
      var n = parseInt(valore, 10);
      if (!isNaN(n) && n > max) max = n;
    }
    // Perk CASA (P3, "Bazzinga!" m71, v. sezione PERK CASA sotto): +1 parola extra al giorno,
    // SOMMATA come l'allenamento extra di Mascellone (non "vince il piu' alto").
    return max + perkCasaParolaExtra(state);
  }

  // ---------- uso_parola=50% (Cervellone) ----------
  // Ritorna la probabilita' [0,1] che il pet usi una parola imparata nelle battute contestuali
  // (default = valore base di bilanciamento.md "Frequenza uso parola imparata", 30%; 50% con
  // Cervellone). dialog.js legge questo helper invece di usare la costante PROB_PAROLA fissa.
  var USO_PAROLA_BASE = 0.30;

  function usoParolaProb(state) {
    var attivi = talentiAttivi(state);
    var prob = USO_PAROLA_BASE;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'uso_parola');
      if (!valore) continue;
      var m = valore.match(/^(\d+(?:[.,]\d+)?)\s*%$/);
      if (m) {
        var p = parseFloat(m[1].replace(',', '.')) / 100;
        if (p > prob) prob = p; // vince il piu' alto, stesso principio di allenamentiPerGiorno
      }
    }
    return prob;
  }

  // ==================== GRUPPO D: Furto & Invenzione (PROTOTIPO 2, Blocco 9 — ultimo batch) ====================
  // Stesso pattern dei gruppi precedenti: talentiAttivi(state) -> scan di effetti[] -> parse del
  // valore grezzo, letto SEMPRE a runtime (mai bakeato). Gli hook lato ui.js (shop/salone) e
  // care.js (reset giornaliero) sono documentati nei commenti li' dove vengono chiamati.

  // ---------- furto=1/giorno (Cleptomane: max 15 monete / Boss di Quartiere: nessun tetto) ----------
  // Il pet puo' prendere GRATIS 1 oggetto al giorno dal Negozio. I due talenti differiscono solo
  // per il TETTO di valore dell'oggetto rubabile:
  //   Cleptomane        -> "furto=1/giorno (max 15 monete)"  -> tetto 15 (solo cibi <= 15 monete)
  //   Boss di Quartiere -> "furto=1/giorno (nessun tetto)"    -> tetto null (qualsiasi cibo)
  // Ritorna { attivo: bool, tetto: number|null }: attivo=false se il pet non ha nessuno dei due;
  // se ha ENTRAMBI (impossibile col design attuale — sono su personalita' diverse — ma teniamo la
  // regola robusta) vince il piu' PERMISSIVO (tetto null batte qualsiasi numero; tra due numeri il
  // piu' alto). Il valore numerico del tetto si legge dal token stesso (non hardcodato: se il
  // fondatore ritocca "max 15 monete" in talenti.md basta cambiare il testo).
  function furtoDisponibile(state) {
    var attivi = talentiAttivi(state);
    var attivo = false;
    var tetto = -Infinity; // -Infinity = nessun furto ancora trovato; null = nessun tetto (vince)
    var senzaTetto = false;
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        if (t.toLowerCase().indexOf('furto=') !== 0) continue;
        attivo = true;
        var valore = t.substring(t.indexOf('=') + 1).toLowerCase();
        // "nessun tetto" (Boss) -> tetto null; "max 15 monete" (Cleptomane) -> tetto = 15.
        if (valore.indexOf('nessun tetto') !== -1) {
          senzaTetto = true;
        } else {
          var m = valore.match(/max\s*(\d+)/);
          if (m) {
            var n = parseInt(m[1], 10);
            if (n > tetto) tetto = n;
          } else {
            // token furto senza "max N" ne' "nessun tetto": lo trattiamo come senza tetto per
            // non bloccare per errore un futuro talento scritto diversamente.
            senzaTetto = true;
          }
        }
      }
    }
    if (!attivo) return { attivo: false, tetto: -1 };
    if (senzaTetto) return { attivo: true, tetto: null };
    return { attivo: true, tetto: (tetto === -Infinity) ? null : tetto };
  }

  // ---------- invenzione=1/settimana (Inventore: Pool Inventore) ----------
  // 1 volta ogni 7 GIORNI DI GIOCO (pet.giorniVita, lo stesso contatore dell'evoluzione: avanza a
  // ogni "nuovo giorno" via care.dailyLogin) il pet puo' inventare 1 oggetto casuale dal Pool
  // Inventore, saltando l'allenamento. Modello scelto (documentato come richiesto dal brief):
  // FINESTRA SCORREVOLE su giorniVita — si confronta pet.giorniVita con state.ultimaInvenzioneGiorno
  // (il giorniVita dell'ultima invenzione). Disponibile se non ha mai inventato (campo assente) o
  // se sono passati >= 7 giorni di gioco dall'ultima. Perche' giorniVita e non una data reale: cosi'
  // il debug "Nuovo giorno" (che avanza giorniVita) permette di testare il ciclo settimanale senza
  // aspettare 7 giorni veri, coerente con tutto il resto del pacing di gioco.
  var GIORNI_INVENZIONE = 7;

  function haInventore(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        if ((effetti[j] || '').trim().toLowerCase().indexOf('invenzione=') === 0) return true;
      }
    }
    return false;
  }

  function invenzioneDisponibile(state) {
    if (!haInventore(state)) return false;
    var giorni = (state && state.pet && typeof state.pet.giorniVita === 'number') ? state.pet.giorniVita : 0;
    if (typeof state.ultimaInvenzioneGiorno !== 'number') return true; // mai inventato
    return (giorni - state.ultimaInvenzioneGiorno) >= GIORNI_INVENZIONE;
  }

  // Estrae 1 oggetto casuale dal Pool Inventore (PETQ.content.data.poolInventore) e INTERPRETA il
  // suo effetto testuale applicandolo allo state. Ritorna { ok, oggetto:{nome,effetto}, msg,
  // dettaglio } (dettaglio = descrizione breve di cosa e' successo, per il pannellino UI), oppure
  // { ok:false } se il pool non e' caricato. NON tocca il timer: il chiamante (ui.js) marca
  // state.ultimaInvenzioneGiorno DOPO un successo (mantiene qui la sola meccanica di applicazione,
  // stesso principio "il modulo talenti dice COSA, la UI decide QUANDO consumare il turno").
  //
  // Interpretazione effetti (v. tabella "Pool Inventore" in talenti.md):
  //   "+30 Energia subito"                         -> +30 alla stat energia (clamp 0..100)
  //   "arredo, +1 Int passivo"                     -> PETQ.arredi.aggiungi("Chip di memoria")
  //   "arredo, +1 Velocità passivo"                -> PETQ.arredi.aggiungi("Ventola overcloccata")
  //   "+20 monete"                                 -> +20 state.coins
  //   "cibo, +1 Int (verdura)"                     -> +1 porzione "Snack riciclato" in dispensa
  //   "arredo raro decorativo, +2 Felicità passiva"-> PETQ.arredi.aggiungi("Torcia laser")
  //   "nessun bonus, ma vendibile a 15 monete"     -> +1 "Prototipo fallato" in dispensa/collezione (nessun effetto immediato)
  // La mappa nome-oggetto -> azione e' per NOME (chiave stabile del pool), non per parsing
  // dell'effetto: cosi' un ritocco al testo dell'effetto non rompe l'applicazione. Il testo
  // dell'effetto resta comunque mostrato all'utente (dettaglio) preso pari pari dal pool.
  function clampLoc(v, min, max) { return Math.max(min, Math.min(max, v)); }

  function applicaInvenzione(state) {
    var data = window.PETQ.content && window.PETQ.content.data;
    var pool = (data && data.poolInventore) || [];
    if (!pool.length) return { ok: false, msg: traduci('Pool Inventore non disponibile.') };

    var oggetto = PETQ.rng.pick(pool);
    var nome = (oggetto.nome || '').toLowerCase();
    var dettaglio = oggetto.effetto || '';

    if (nome.indexOf('batteria') !== -1) {
      if (state.pet && state.pet.stats && typeof state.pet.stats.energia === 'number') {
        state.pet.stats.energia = clampLoc(state.pet.stats.energia + 30, 0, 100);
      }
    } else if (nome.indexOf('gruzzolo') !== -1) {
      state.coins = (state.coins || 0) + 20;
    } else if (nome.indexOf('chip') !== -1) {
      if (PETQ.arredi && PETQ.arredi.aggiungi) PETQ.arredi.aggiungi(state, 'Chip di memoria');
      dettaglio += traduci(' — aggiunto alla collezione (piazzalo per il bonus)');
    } else if (nome.indexOf('ventola') !== -1) {
      if (PETQ.arredi && PETQ.arredi.aggiungi) PETQ.arredi.aggiungi(state, 'Ventola overcloccata');
      dettaglio += traduci(' — aggiunto alla collezione (piazzalo per il bonus)');
    } else if (nome.indexOf('torcia') !== -1) {
      if (PETQ.arredi && PETQ.arredi.aggiungi) PETQ.arredi.aggiungi(state, 'Torcia laser');
      dettaglio += traduci(' — aggiunto alla collezione (piazzalo per il bonus)');
    } else if (nome.indexOf('snack') !== -1) {
      aggiungiCiboDispensa(state, 'Snack riciclato');
      dettaglio += traduci(' — finito nel frigo');
    } else if (nome.indexOf('prototipo') !== -1) {
      // "nessun bonus, ma vendibile a 15 monete": lo mettiamo tra i posseduti come arredo (non e'
      // in arredi.md, quindi vendi() usera' il fallback ~5 monete: il "vendibile a 15" resta sapore
      // testuale, non abbiamo un canale prezzo dedicato per gli item non-arredo). Se PETQ.arredi
      // non e' pronto, non facciamo nulla (nessun bonus comunque).
      if (PETQ.arredi && PETQ.arredi.aggiungi) PETQ.arredi.aggiungi(state, oggetto.nome);
      dettaglio += traduci(' — nella collezione, rivendibile');
    }

    return { ok: true, oggetto: oggetto, dettaglio: dettaglio, msg: traduci('Inventato: ') + oggetto.nome + '!' };
  }

  // Aggiunge 1 porzione di un cibo alla dispensa (frigo), creando la voce se assente. Usato sia dal
  // furto (ruba un cibo dal negozio) sia dall'invenzione ("Snack riciclato"). Duplicato minimale
  // della logica di ui.js eseguiAcquisto per non dipendere dalla UI da un modulo di dominio.
  function aggiungiCiboDispensa(state, nomeCibo) {
    if (!state) return;
    if (!Array.isArray(state.dispensa)) state.dispensa = [];
    for (var i = 0; i < state.dispensa.length; i++) {
      if (state.dispensa[i].nome === nomeCibo) {
        state.dispensa[i].qty = (state.dispensa[i].qty || 0) + 1;
        return;
      }
    }
    state.dispensa.push({ nome: nomeCibo, qty: 1 });
  }

  // ==================== GRUPPO E: Talenti ADULTO (P3 BATCH 4, 14 talenti) ====================
  // Stesso pattern dei gruppi precedenti: talentiAttivi(state) -> trovaToken/scan di effetti[] ->
  // parse del valore grezzo, letto SEMPRE a runtime (mai bakeato). I 14 talenti adulto (v.
  // content/talenti.md sezioni "### Adulto") sono estratti alla evoluzione teen->adulto
  // (pet.controllaEvoluzione) ma finora i loro token DSL erano INERTI: questo gruppo li aggancia
  // tutti. Gli hook lato pet.js/care.js/missions.js/ui.js sono documentati nei commenti li' dove
  // vengono chiamati. NOTA generale sui parser tolleranti: alcuni token qui sono stringhe libere
  // (non "chiave=valore" pulito, es. "se fel<30: passivo=forza+5"), stesso spirito di
  // parsePassivo/badLoserEffetto sopra: riconosciuti per regex dedicata, mai per nome-talento
  // hardcodato salvo dove esplicitamente documentato come fallback.

  // ---------- Sonnambulo Agonista: notte_piena=stat_casuale+1 ----------
  // Booleano: true se un talento attivo da' +1 a una stat RPG CASUALE al completamento di un
  // sonno NOTTURNO PIENO (v. pet.risolviRisveglio, chiamante che applica l'effetto vero e
  // proprio: qui solo la query "il pet ce l'ha?"). Stesso pattern di azzeraFeriteNotte/
  // immuneMalusCondizioni: il talento dice COSA, il chiamante decide QUANDO/COME.
  function haSonnoNottePiena(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        if ((effetti[j] || '').trim().toLowerCase().indexOf('notte_piena=') === 0) return true;
      }
    }
    return false;
  }

  // ---------- Furia Cieca: se fel<30: passivo=forza+5 ----------
  // Passivo CONDIZIONALE (stesso stile del "se igiene<50: passivo=int+2" di Idrofobico sopra, ma
  // su Felicita' invece di Igiene): se il pet ha il talento E felicita' < soglia, +N alla stat
  // indicata. Sommato DENTRO bonusStatTutte (non un helper separato) cosi' tutti i chiamanti
  // esistenti (ui.js scheda, missions.bonusStatCombinato) lo vedono gratis, dinamicamente — v.
  // l'estensione dentro bonusStatTutte sotto (stessa funzione di Idrofobico, generalizzata).

  // ---------- Veterano del Ring: ferite_missione=x0.5 ----------
  // Ritorna il moltiplicatore da applicare alle Ferite subite dalle MISSIONI (reward "ferite+N"
  // in missions.applicaRewardToken/risolvi), 1 se nessun talento attivo lo tocca. Dimezza e poi
  // arrotonda per DIFETTO (Math.floor), mai sotto 0 (il chiamante clampa comunque il totale).
  function feriteMissioneMult(state) {
    var attivi = talentiAttivi(state);
    var mult = 1;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'ferite_missione');
      if (!valore) continue;
      var m = valore.match(/x\s*([\d.,]+)/i);
      if (m) mult *= parseFloat(m[1].replace(',', '.'));
    }
    return mult;
  }

  // ---------- Montaggio alla Rocky: montaggio=1/settimana (tutte+2) ----------
  // Booleano: true se un talento attivo ha il training montage settimanale automatico. La
  // MECCANICA (ogni 7 giorni di gioco, +2 a tutte le stat) vive in care.dailyLogin (v. commento
  // li'): qui solo la query, stesso principio di haSonnoNottePiena/haInventore.
  function haMontaggioRocky(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        if ((effetti[j] || '').trim().toLowerCase().indexOf('montaggio=') === 0) return true;
      }
    }
    return false;
  }

  // ---------- La Nonna Ti Vede: perk_categoria=lavoretti ----------
  // Generalizzazione di perkTagAttivo ma su CATEGORIA scheda invece che su tag: stessa
  // precedenza (super garantito + niente fallimento), stesso pattern trovaToken. Usata da
  // missions.scegliEsito accanto a perkTagAttivo (v. li' per il dettaglio della precedenza).
  function perkCategoriaAttivo(state, categoria) {
    if (!categoria) return false;
    var attivi = talentiAttivi(state);
    var c = String(categoria).trim().toLowerCase();
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'perk_categoria');
      if (valore && valore.trim().toLowerCase() === c) return true;
    }
    return false;
  }

  // ---------- Cuore di Casa: bonus_missione=lavoretti:carisma+1 ----------
  // Il token "bonus_missione=<categoria>:<stat>+N" e' ESATTAMENTE il formato gia' gestito da
  // bonusMissioneCategoria (Gruppo B, Topo di Biblioteca/Pacifista) sopra: nessun codice nuovo
  // necessario, missions.risolvi lo applica gia' per QUALSIASI categoria scritta nel token
  // (incluso "lavoretti"), a patto che scheda.categoria combaci. Documentato qui per
  // completezza del registry (v. anche passivo=carisma+1, coperto da bonusStatTutte esistente).

  // ---------- Santo Subito: miracolo=1/giorno ----------
  // Booleano: true se un talento attivo ha il "miracolo" giornaliero attivabile dal giocatore
  // (bottone in scheda, v. ui.js mostraScheda). La meccanica (4 scelte: azzera ferite / fame 100
  // / igiene 100 / energia 100, 1 volta al giorno) e' in applicaMiracolo sotto: qui solo la
  // query "il pet puo' fare il miracolo oggi?", stesso pattern di invenzioneDisponibile.
  function haSantoSubito(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        if ((effetti[j] || '').trim().toLowerCase().indexOf('miracolo=') === 0) return true;
      }
    }
    return false;
  }

  // Disponibile se il talento Santo Subito lo concede OGGI (1/giorno, come sempre) OPPURE se il
  // perk CASA "Maronna Mia" (m67) lo concede QUESTA settimana (v. miracoloCasaDisponibile nella
  // sezione PERK CASA sotto: gate separato, 1/settimana, anche senza il talento).
  function miracoloDisponibile(state) {
    var oggi = (PETQ.clock && PETQ.clock.giornoCorrente) ? PETQ.clock.giornoCorrente(state) : 0;
    if (haSantoSubito(state) && state && state.miracoloGiorno !== oggi) return true;
    return miracoloCasaDisponibile(state);
  }

  // Applica la scelta del miracolo ('ferite' | 'fame' | 'igiene' | 'energia') e marca il giorno
  // (state.miracoloGiorno), stesso pattern di state.furtoDay/state.studioVeloceDay. Ritorna
  // { ok, msg }. Il chiamante (ui.js) e' responsabile di richiamare save()/ridisegnare.
  function applicaMiracolo(state, scelta) {
    if (!state || !state.pet) return { ok: false, msg: traduci('errore interno') };
    if (!miracoloDisponibile(state)) return { ok: false, msg: traduci('Miracolo gia\' fatto oggi, torna domani.') };
    var pet = state.pet;
    var msg;
    if (scelta === 'ferite') {
      state.ferite = 0;
      msg = traduci('Miracolo: Ferite azzerate!');
    } else if (scelta === 'fame') {
      pet.stats.fame = 100;
      msg = traduci('Miracolo: Fame a 100!');
    } else if (scelta === 'igiene') {
      pet.stats.igiene = 100;
      msg = traduci('Miracolo: Igiene a 100!');
    } else if (scelta === 'energia') {
      pet.stats.energia = 100;
      msg = traduci('Miracolo: Energia a 100!');
    } else {
      return { ok: false, msg: traduci('Scelta miracolo non valida.') };
    }
    var oggi = (PETQ.clock && PETQ.clock.giornoCorrente) ? PETQ.clock.giornoCorrente(state) : 0;
    // Marca ENTRAMBI i tracker (talento daily + perk casa settimanale), qualunque sia la fonte
    // che ha aperto il gate: un solo miracolo al giorno resta un solo miracolo al giorno, e il
    // gate settimanale del perk casa (m67) non si riapre per errore piu' volte nello stesso
    // giorno%7===0 (v. miracoloCasaDisponibile sotto).
    state.miracoloGiorno = oggi;
    if (haPerkCasa(state, 'm67')) state.miracoloCasaGiorno = oggi;
    if (PETQ.pet && PETQ.pet.recomputeSalute) PETQ.pet.recomputeSalute(pet, state);
    return { ok: true, msg: '✨ ' + msg };
  }

  // ---------- Overclock: guadagni_stat=x2 ; energia_extra=-10 ----------
  // Ritorna { mult, energiaExtra }: mult = moltiplicatore da applicare ai guadagni stat RPG da
  // ALLENAMENTO e da REWARD MISSIONE (1 se nessun talento), energiaExtra = quanta Energia perde
  // il pet OGNI VOLTA che il raddoppio scatta davvero (0 se non scatta/nessun talento). Il
  // chiamante (care.completaAllenamento, missions.applicaRewardToken) applica energiaExtra SOLO
  // se mult!=1 e il guadagno era effettivamente diverso da zero (niente overclock "a vuoto" su
  // un +0). Non tocchiamo qui i costi Energia normali dell'allenamento/missione: e' un costo
  // AGGIUNTIVO, sommato a valle dal chiamante.
  function overclockInfo(state) {
    var attivi = talentiAttivi(state);
    var mult = 1;
    var energiaExtra = 0;
    for (var i = 0; i < attivi.length; i++) {
      var vMult = trovaToken(attivi[i].effetti, 'guadagni_stat');
      if (vMult) {
        var mM = vMult.match(/x\s*([\d.,]+)/i);
        if (mM) mult *= parseFloat(mM[1].replace(',', '.'));
      }
      var vEnergia = trovaToken(attivi[i].effetti, 'energia_extra');
      if (vEnergia) {
        var mE = vEnergia.match(/(-?\d+)/);
        if (mE) energiaExtra += parseInt(mE[1], 10); // gia' negativo nel token ("-10")
      }
    }
    return { mult: mult, energiaExtra: energiaExtra };
  }

  // ---------- Roombo: igiene_min=50 ; perk_tag=cucina ----------
  // Ritorna il valore minimo garantito di Igiene (0 = nessun minimo, default), il piu' alto tra
  // eventuali talenti che lo impostano. Usato da pet.applyDecay (decay) e ovunque altro l'Igiene
  // possa scendere (v. commenti li'), come clamp sul minimo invece che 0. perk_tag=cucina non
  // serve codice nuovo (perkTagAttivo generico, v. sotto la nota su Sussurra-Mostri).
  function igieneMinima(state) {
    var attivi = talentiAttivi(state);
    var min = 0;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'igiene_min');
      if (valore === null) continue;
      var n = parseInt(valore, 10);
      if (!isNaN(n) && n > min) min = n;
    }
    return min;
  }

  // ---------- Galaxy Brain: stat_come_int ----------
  // Booleano: true se un talento attivo fa si' che, SOLO nella VALUTAZIONE delle condizioni
  // missione (mai nell'HUD/valore reale), ogni stat RPG valga almeno quanto l'Intelligenza.
  // Applicato in missions._valutaCond (v. li' per il dettaglio: max(statRichiesta, intelligenza)
  // SOLO sul ctx.stat passato al valutatore condizioni, non su pet.rpg).
  function haGalaxyBrain(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        if ((effetti[j] || '').trim().toLowerCase() === 'stat_come_int') return true;
      }
    }
    return false;
  }

  // ---------- Il Sonno degli Ingiusti: sonno=sempre_pieno ; ignora_malus_energia ; perk_tag=paranormale ----------
  // sonnoSemprePieno: booleano, true se OGNI risveglio (notturno o riposino) porta l'Energia a
  // 100 (v. pet.risolviRisveglio, hook dedicato). ignoraMalusEnergia: booleano, true se il pet
  // non subisce i malus generati da Energia bassa (v. pet.js applyDecay/malusCondizioni, hook
  // dedicato: bypassa SOLO il malus, mai il valore reale della stat). perk_tag=paranormale non
  // serve codice nuovo (perkTagAttivo generico).
  function sonnoSemprePieno(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        if ((effetti[j] || '').trim().toLowerCase().indexOf('sonno=') === 0 &&
            (effetti[j] || '').toLowerCase().indexOf('sempre_pieno') !== -1) return true;
      }
    }
    return false;
  }

  function ignoraMalusEnergia(state) {
    var attivi = talentiAttivi(state);
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        if ((effetti[j] || '').trim().toLowerCase() === 'ignora_malus_energia') return true;
      }
    }
    return false;
  }

  // ---------- Chissenefrega: fallimento=fel-0 ; perk_tag=social ----------
  // Il token "fallimento=fel-0" e' ESATTAMENTE lo stesso di Faccia di Bronzo (Gruppo B, v.
  // fallimentoFelBloccato sopra): nessun codice nuovo necessario, missions.risolvi lo applica
  // gia' a QUALSIASI talento col token, a prescindere dal nome. perk_tag=social idem
  // (perkTagAttivo generico). Documentato qui per completezza del registry, nessuna funzione
  // dedicata: riusa fallimentoFelBloccato/perkTagAttivo esistenti.

  // ---------- Lavoro in Nero: missioni_giorno=2 ----------
  // Ritorna il numero massimo di missioni completABILI in un giorno (default 1, 2 con Lavoro in
  // Nero), stesso pattern di allenamentiPerGiorno/parolePerGiorno. Usato da missions.avvia al
  // posto del confronto rigido "== giorno di oggi" (v. li' per il dettaglio: un CONTATORE
  // missioniOggi confrontato con questo max, non piu' un flag booleano singolo). NOTA fondatore
  // (dal brief): la parte "di notte" del flavor NON e' implementata ora (il sistema orari
  // notturni arriva dopo) — la 2a missione segue gli orari normali (8-18), stesso orarioMissioniAperto.
  // CICLO VITALE 14 GIORNI (fondatore 10 lug): default 2 missioni/giorno (giorno denso).
  // Lavoro in Nero passa di conseguenza a missioni_giorno=3 (v. talenti.md).
  var MISSIONI_GIORNO_DEFAULT = 2;

  function missioniPerGiorno(state) {
    var attivi = talentiAttivi(state);
    var max = MISSIONI_GIORNO_DEFAULT;
    for (var i = 0; i < attivi.length; i++) {
      var valore = trovaToken(attivi[i].effetti, 'missioni_giorno');
      if (valore === null) continue;
      var n = parseInt(valore, 10);
      if (!isNaN(n) && n > max) max = n;
    }
    return max;
  }

  // ==================== PERK CASA (P3, Grandi Imprese — perk di ritiro) ====================
  // Effetto PERMANENTE su OGNI pet futuro della STESSA casa, sbloccato risolvendo in SUPER una
  // Grande Impresa (scheda.impresa, v. missions.js risolvi) e mandando QUEL pet in PENSIONE (v.
  // pet.js mandaInPensione — MAI con la valigia, anti-farming). Vive in state.perkCasa (array di
  // id-scheda 'm65'..'m72'), PERSISTENTE ATTRAVERSO LE RUN (mai azzerato da ui.js avviaPartita/
  // finalizzaNuovoPetInCasa). Stesso principio del resto del file: query di sola lettura, mai
  // stato bakeato, agganciate dai chiamanti esistenti (allenamentiPerGiorno/parolePerGiorno/
  // manciaMult/miracoloDisponibile qui sopra, pet.js generate/applyDecay/controllaPasseggiataScaduta).
  //
  // Roster (v. content/arredi.md "Companion LEGGENDARI" + docs/DESIGN-P3-ADULTO.md):
  //   m65 Mascellone         -> +2 Forza alla nascita, +1 allenamento/giorno
  //   m66 Occhio di Tigre    -> +1 Forza +1 Velocita' alla nascita
  //   m67 Maronna Mia        -> +2 Carisma alla nascita, 1 miracolo gratis/settimana
  //   m68 Scatola Cioccolatini -> +1 Carisma +1 Velocita' alla nascita, passeggiata mai negativa
  //   m69 The Crown          -> +2 Carisma alla nascita, mance x2
  //   m70 Orgoglio Principe  -> +2 alla stat FIRMA della personalita' del nuovo pet, alla nascita
  //   m71 Bazzinga!          -> +2 Intelligenza alla nascita, +1 parola/giorno
  //   m72 Reattore Arc       -> +2 Intelligenza alla nascita, Energia mai sotto 20
  function haPerkCasa(state, id) {
    return !!(state && Array.isArray(state.perkCasa) && state.perkCasa.indexOf(id) !== -1);
  }

  // TETTO al bonus perk casa, PER STATISTICA (difetto provato dal fondatore: senza tetto, con le
  // 8 Grandi Imprese sbloccate un pet nasce con statistiche totali 5 volte quelle di una casa
  // fresca, gia' sopra le soglie di meta' missioni). Gemello di EREDITA_CAP_PER_STAT (ui.js, +1
  // per pensionato con tetto 2): STESSO principio, tetto DIVERSO e apposta piu' alto (+4 contro
  // +2) perche' le Grandi Imprese sono molto piu' dure da vincere di un semplice pensionamento —
  // NON e' un'incoerenza fra i due numeri, sono due decisioni di design distinte del fondatore.
  // Si applica SOLO al contributo del perk casa (questa somma): l'eredita' dei pensionati si
  // somma DOPO, fuori da questa funzione (v. ui.js nuovoPetInCasa), col suo tetto separato.
  var PERK_CASA_CAP_PER_STAT = 4;

  // Bonus "alla nascita" di TUTTI i perk casa sbloccati (cumulativi: e' un traguardo permanente
  // della casa, non un'esclusiva). Chiamato UNA volta da pet.js generate() alla creazione del
  // nuovo pet. `statFirma` e' la stat firma della personalita' del pet appena generato (calcolata
  // dal chiamante, v. pet.js STAT_FIRMA): serve solo a "Orgoglio del Principe" (m70).
  function bonusNascitaPerkCasa(state, statFirma) {
    var somma = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    if (!state || !Array.isArray(state.perkCasa) || state.perkCasa.length === 0) return somma;
    if (haPerkCasa(state, 'm65')) somma.forza += 2;
    if (haPerkCasa(state, 'm66')) { somma.forza += 1; somma.velocita += 1; }
    if (haPerkCasa(state, 'm67')) somma.carisma += 2;
    if (haPerkCasa(state, 'm68')) { somma.carisma += 1; somma.velocita += 1; }
    if (haPerkCasa(state, 'm69')) somma.carisma += 2;
    if (haPerkCasa(state, 'm70') && statFirma && typeof somma[statFirma] === 'number') somma[statFirma] += 2;
    if (haPerkCasa(state, 'm71')) somma.intelligenza += 2;
    if (haPerkCasa(state, 'm72')) somma.intelligenza += 2;
    somma.forza = Math.min(somma.forza, PERK_CASA_CAP_PER_STAT);
    somma.intelligenza = Math.min(somma.intelligenza, PERK_CASA_CAP_PER_STAT);
    somma.velocita = Math.min(somma.velocita, PERK_CASA_CAP_PER_STAT);
    somma.carisma = Math.min(somma.carisma, PERK_CASA_CAP_PER_STAT);
    return somma;
  }

  // m65 "Mascellone": +1 allenamento extra al giorno (0 se non sbloccato). Agganciato dentro
  // allenamentiPerGiorno sopra (sommato, non "vince il piu' alto").
  function perkCasaAllenamentoExtra(state) {
    return haPerkCasa(state, 'm65') ? 1 : 0;
  }

  // m71 "Bazzinga!": +1 parola insegnabile extra al giorno. Agganciato dentro parolePerGiorno sopra.
  function perkCasaParolaExtra(state) {
    return haPerkCasa(state, 'm71') ? 1 : 0;
  }

  // m69 "The Crown": mance x2. Agganciato dentro manciaMult sopra (si moltiplica insieme a
  // qualunque talento futuro che tocchi la mancia).
  function perkCasaManciaMult(state) {
    return haPerkCasa(state, 'm69') ? 2 : 1;
  }

  // m67 "Maronna Mia": true se la casa ha sbloccato il perk (indipendentemente dal giorno) — usato
  // da ui.js per decidere se mostrare la sezione "Miracolo" della scheda ANCHE a un pet senza il
  // talento Santo Subito (stessa sezione, stessa etichetta, v. brief "etichetta invariata").
  function perkCasaMiracoloAttivo(state) {
    return haPerkCasa(state, 'm67');
  }

  // m67 "Maronna Mia": 1 miracolo GRATIS a settimana, riusando la macchina del Miracolo di Santo
  // Subito (applicaMiracolo sopra) MA con un gate/flag SEPARATO da quello del talento
  // (state.miracoloCasaGiorno, mai state.miracoloGiorno): disponibile quando giornoGioco%7===0 e
  // non ancora usato in QUESTA occorrenza. Agganciato dentro miracoloDisponibile sopra (OR col
  // gate del talento).
  function miracoloCasaDisponibile(state) {
    if (!haPerkCasa(state, 'm67')) return false;
    var giorno = (PETQ.clock && PETQ.clock.giornoCorrente) ? PETQ.clock.giornoCorrente(state) : 0;
    if (giorno % 7 !== 0) return false;
    return state && state.miracoloCasaGiorno !== giorno;
  }

  // m68 "Scatola di Cioccolatini": true se la passeggiata serale non deve MAI avere l'esito
  // negativo 'bulletto'. Usato da pet.js controllaPasseggiataScaduta per ri-estrarre/sostituire
  // quell'esito con uno non negativo (v. li' per il dettaglio).
  function perkCasaPasseggiataSenzaNegativi(state) {
    return haPerkCasa(state, 'm68');
  }

  // m72 "Reattore Arc": valore minimo garantito di Energia (0 = nessun minimo, default), stesso
  // principio/forma di igieneMinima (Roombo) sopra ma per l'Energia — nessun talento la tocca
  // ancora, solo questo perk casa. Usato da pet.js applyDecay come clamp sul minimo.
  function energiaMinima(state) {
    return haPerkCasa(state, 'm72') ? 20 : 0;
  }

  // ==================== REGISTRY token NON ancora agganciati (TODO batch futuri) ====================
  // Elenco di TUTTI i token del DSL "Dati" (v. content/talenti.md legenda in cima) che il
  // parser gia' legge dentro talento.effetti ma che NESSUN sistema di gioco applica ancora.
  // Non e' codice eseguito: e' documentazione viva + un piccolo helper (tokenNonAgganciati) per
  // scoprire a runtime quali effetti un pet ha "silenti", utile in debug/scheda.
  //
  // AGGIORNATO nel P3 BATCH 4 (14 talenti adulto, Gruppo E sopra): TUTTI i token del DSL sono
  // ora agganciati, nascita/teen/adulto compresi. Resta UN SOLO token non agganciato, e per
  // design non per "TODO":
  //
  //   nota=...                -> annotazioni testuali non meccaniche (es. "malus_salute_sporco_resta"):
  //                              NON e' un token da agganciare, e' documentazione di design.
  //
  // Storico: Gruppo A (cibo/allenamento/energia), Gruppo B (missioni/economia), Gruppo C (salute/
  // sonno/igiene/parole), Gruppo D (furto/invenzione), il batch tag missioni (perk_tag) e il
  // Gruppo E (14 talenti adulto) hanno agganciato tutti i token meccanici. Resta solo 'nota'.

  var TOKEN_NON_AGGANCIATI = [
    'nota (solo descrittivo, mai meccanico per design)'
  ];

  // Prefissi/token esatti ormai AGGANCIATI (passivo/cap_coccole dal batch core + Gruppo A +
  // Gruppo B + Gruppo C + Gruppo D + Gruppo E): usati da tokenNonAgganciati sotto per non
  // segnalarli come "silenti" nel debug/scheda, pur essendo ancora presenti come token grezzi in
  // effetti[]. perk_tag= e' AGGANCIATO (v. perkTagAttivo + missions.scegliEsito).
  var PREFISSI_AGGANCIATI = [
    'passivo=', 'cap_coccole=', 'bonus_cibo=', 'blocca_cibo=', 'bonus_allenamento=',
    'allenamenti_giorno=', 'allenamento_extra=', 'allenamento_durata=', 'allenamento_energia=',
    'energia_decay=', 'bonus_missione=', 'ogni_missione=', 'mancia=', 'login=',
    'blocca_categoria=', 'fallimento=', 'bonus_missione_monete=', 'missione_durata=',
    'igiene_felicita=', 'infermeria_costo=', 'infermeria_cura=', 'parole_giorno=', 'uso_parola=',
    'furto=', 'invenzione=', 'perk_tag=',
    // Gruppo E (P3 BATCH 4, 14 talenti adulto)
    'notte_piena=', 'ferite_missione=', 'montaggio=', 'perk_categoria=', 'miracolo=',
    'guadagni_stat=', 'energia_extra=', 'igiene_min=', 'sonno=', 'missioni_giorno='
  ];
  var TOKEN_ESATTI_AGGANCIATI = ['ignora_rifiuto_energia', 'immune_malus_condizioni',
    'stat_come_int', 'ignora_malus_energia'];

  // Prefisso libero agganciato (non "chiave=valore" pulito, v. badLoserEffetto): riconosciuto a
  // parte perche' PREFISSI_AGGANCIATI/TOKEN_ESATTI_AGGANCIATI sopra coprono solo i due formati
  // regolari. Gruppo C aggiunge "notte=ferite=0" (chiave=valore=valore, non nel formato "chiave=
  // valore" semplice di trovaToken) e "risveglio=ferite-10" (chiave=stat-N, non chiave=+/-numero
  // come infermeria_costo/cura) e il token libero "se igiene<...: passivo=..." (Idrofobico).
  // Gruppo E aggiunge "se fel<...: passivo=..." (Furia Cieca), stesso stile.
  var PREFISSI_LIBERI_AGGANCIATI = ['se fallimento_carattere:', 'notte=ferite=0', 'risveglio=ferite', 'se igiene<', 'se fel<'];

  // Ritorna, per i talenti attivi del pet, la lista di token grezzi presenti nei loro `effetti`
  // che NON sono tra quelli agganciati sopra — utile per il debug/scheda per segnalare "questo
  // talento ha effetti non ancora attivi in gioco".
  function tokenNonAgganciati(state) {
    var attivi = talentiAttivi(state);
    var out = [];
    for (var i = 0; i < attivi.length; i++) {
      var effetti = attivi[i].effetti || [];
      for (var j = 0; j < effetti.length; j++) {
        var t = (effetti[j] || '').trim();
        if (t === '') continue;
        if (TOKEN_ESATTI_AGGANCIATI.indexOf(t) !== -1) continue;
        var liberoAgganciato = false;
        for (var p = 0; p < PREFISSI_LIBERI_AGGANCIATI.length; p++) {
          if (t.toLowerCase().indexOf(PREFISSI_LIBERI_AGGANCIATI[p]) === 0) { liberoAgganciato = true; break; }
        }
        if (liberoAgganciato) continue;
        var aggancio = false;
        for (var k = 0; k < PREFISSI_AGGANCIATI.length; k++) {
          if (t.indexOf(PREFISSI_AGGANCIATI[k]) === 0) { aggancio = true; break; }
        }
        if (aggancio) continue;
        out.push({ talento: attivi[i].nome, token: t });
      }
    }
    return out;
  }

  window.PETQ.talenti = {
    estrai: estrai,
    _estraiDaTerna: estraiDaTerna,
    talentiAttivi: talentiAttivi,
    bonusStat: bonusStat,
    bonusStatTutte: bonusStatTutte,
    capCoccole: capCoccole,
    coccolaFelExtra: coccolaFelExtra,
    tokenNonAgganciati: tokenNonAgganciati,
    // Gruppo A (Cibo/Allenamento/Energia)
    bonusCiboExtra: bonusCiboExtra,
    ciboBloccato: ciboBloccato,
    bonusAllenamentoExtra: bonusAllenamentoExtra,
    durataAllenamentoMult: durataAllenamentoMult,
    energiaAllenamentoOverride: energiaAllenamentoOverride,
    allenamentiPerGiorno: allenamentiPerGiorno,
    allenamentoExtraStat: allenamentoExtraStat,
    energiaDecayMult: energiaDecayMult,
    ignoraRifiutoEnergia: ignoraRifiutoEnergia,
    // Gruppo B (Missioni & Economia)
    bonusOgniMissione: bonusOgniMissione,
    bonusMissioneCategoria: bonusMissioneCategoria,
    bonusMissioneMoneteMult: bonusMissioneMoneteMult,
    manciaMult: manciaMult,
    loginBonusMonete: loginBonusMonete,
    missioneDurataDeltaH: missioneDurataDeltaH,
    fallimentoFelBloccato: fallimentoFelBloccato,
    badLoserEffetto: badLoserEffetto,
    categoriaBloccata: categoriaBloccata,
    perkTagAttivo: perkTagAttivo,
    // Gruppo C (Salute/Sonno/Igiene/Parole)
    immuneMalusCondizioni: immuneMalusCondizioni,
    azzeraFeriteNotte: azzeraFeriteNotte,
    infermeriaModCosto: infermeriaModCosto,
    infermeriaModCura: infermeriaModCura,
    risveglioFeriteDelta: risveglioFeriteDelta,
    igieneFelicitaInvertita: igieneFelicitaInvertita,
    parolePerGiorno: parolePerGiorno,
    usoParolaProb: usoParolaProb,
    // Gruppo D (Furto & Invenzione)
    furtoDisponibile: furtoDisponibile,
    haInventore: haInventore,
    invenzioneDisponibile: invenzioneDisponibile,
    applicaInvenzione: applicaInvenzione,
    // Gruppo E (P3 BATCH 4, 14 talenti adulto)
    haSonnoNottePiena: haSonnoNottePiena,
    feriteMissioneMult: feriteMissioneMult,
    haMontaggioRocky: haMontaggioRocky,
    perkCategoriaAttivo: perkCategoriaAttivo,
    haSantoSubito: haSantoSubito,
    miracoloDisponibile: miracoloDisponibile,
    applicaMiracolo: applicaMiracolo,
    overclockInfo: overclockInfo,
    igieneMinima: igieneMinima,
    haGalaxyBrain: haGalaxyBrain,
    sonnoSemprePieno: sonnoSemprePieno,
    ignoraMalusEnergia: ignoraMalusEnergia,
    missioniPerGiorno: missioniPerGiorno,
    // PERK CASA (P3, Grandi Imprese — perk di ritiro, v. sezione dedicata sopra)
    haPerkCasa: haPerkCasa,
    bonusNascitaPerkCasa: bonusNascitaPerkCasa,
    perkCasaAllenamentoExtra: perkCasaAllenamentoExtra,
    perkCasaParolaExtra: perkCasaParolaExtra,
    perkCasaManciaMult: perkCasaManciaMult,
    perkCasaMiracoloAttivo: perkCasaMiracoloAttivo,
    miracoloCasaDisponibile: miracoloCasaDisponibile,
    perkCasaPasseggiataSenzaNegativi: perkCasaPasseggiataSenzaNegativi,
    energiaMinima: energiaMinima,
    _missioniGiornoDefault: MISSIONI_GIORNO_DEFAULT,
    _giorniInvenzione: GIORNI_INVENZIONE,
    _capCoccoleDefault: CAP_COCCOLE_DEFAULT,
    _allenamentiGiornoDefault: ALLENAMENTI_GIORNO_DEFAULT,
    _paroleGiornoDefault: PAROLE_GIORNO_DEFAULT,
    _usoParolaBase: USO_PAROLA_BASE,
    _tokenNonAgganciatiRegistry: TOKEN_NON_AGGANCIATI,
    _trovaToken: trovaToken
  };

})();
