window.PETQ = window.PETQ || {};

(function () {

  // Acquisti in-app (RevenueCat, plugin Capacitor @revenuecat/purchases-capacitor v13): stesso
  // contratto di notifiche.js — plugin che puo' MANCARE (browser, file://, o sync non ancora
  // fatto dal regista) -> ogni funzione qui e' un no-op silenzioso, MAI un throw verso il
  // chiamante (sempre via cb). DIFFERENZA voluta rispetto a notifiche.js: qui il lookup del
  // plugin e' PIGRO (funzione, non var di modulo fissata al caricamento) cosi' _test() puo'
  // sostituirlo a runtime nei test in browser senza dover ricaricare la pagina.
  //
  // Fonte di verita' del design: docs/GDD.md sezione "Monetizzazione". Fonte di verita' degli
  // acquisti VERI: la CustomerInfo di RevenueCat (non un flag nostro) — per questo ogni funzione
  // che sblocca qualcosa passa sempre da essa (getCustomerInfo/restorePurchases/l'esito di un
  // acquisto), mai da un semplice "ok l'utente ha pagato" locale.

  // Chiave API RevenueCat per Android ('goog_...', dal pannello RevenueCat -> Project -> API
  // keys). Finche' resta '' il modulo e' DORMIENTE per design: disponibile() torna false, ogni
  // funzione pubblica esce subito senza toccare il plugin — il gioco resta identico e completo
  // anche senza chiave (v. GDD, regola "senza plugin o senza chiave API gli acquisti non
  // esistono"). Va compilata quando il pannello RevenueCat e' pronto, non prima.
  // Progetto RevenueCat "Hatch a Legend" (edb7fa7a), app "Hatch a Legend (Play Store)" creata
  // l'8 ago 2026 sul package com.giubera.hatchalegend. Questa e' la chiave PUBBLICA dell'SDK:
  // sta per definizione dentro l'app installata (chiunque puo' estrarla dall'APK) e non permette
  // di leggere dati altrui — la chiave SEGRETA, quella si' pericolosa, non entra mai qui.
  var CHIAVE_API_ANDROID = 'goog_VvFBuRtQhlvSRsRPQOaqEzYqEdA';

  // ---------- Lookup pigro del plugin + hook di collaudo ----------
  // _pluginOverride/_chiaveOverride esistono SOLO per _test() (v. fondo file): in produzione
  // restano sempre a riposo e purchasesPlugin()/chiaveApi() leggono la realta' vera.
  var _pluginOverride = null;
  var _hasChiaveOverride = false;
  var _chiaveOverride = '';

  // Pigro apposta (funzione, non un var calcolato una volta all'IIFE): window.Capacitor.Plugins
  // puo' comparire DOPO il caricamento di questo file (il plugin si registra al boot di
  // Capacitor), e nei test in browser serve poter iniettare un plugin finto senza ricaricare.
  function purchasesPlugin() {
    if (_pluginOverride) return _pluginOverride;
    return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Purchases) || null;
  }

  function chiaveApi() {
    return _hasChiaveOverride ? _chiaveOverride : CHIAVE_API_ANDROID;
  }

  // Vero solo se ESISTE il plugin nativo E la chiave non e' vuota: le due condizioni sono
  // indipendenti (si puo' avere il plugin sincronizzato ma la chiave non ancora compilata, o
  // viceversa in teoria) ma per essere "disponibile" servono entrambe.
  function disponibile() {
    return !!(purchasesPlugin() && chiaveApi());
  }

  // ---------- Catalogo (GDD "Monetizzazione") ----------
  var PRODOTTI = [
    { id: 'supporter_pack', tipo: 'pack', etichetta: 'Supporter Pack' },
    { id: 'colore_oro', tipo: 'colore', etichetta: 'Colore Oro' },
    { id: 'colore_notte_neon', tipo: 'colore', etichetta: 'Colore Notte Neon' },
    { id: 'colore_ghiaccio', tipo: 'colore', etichetta: 'Colore Ghiaccio' },
    { id: 'skin_arcade', tipo: 'skin', etichetta: 'Skin Sala Giochi' },
    { id: 'skin_mare', tipo: 'skin', etichetta: 'Skin Fondale Marino' },
    { id: 'skin_castello', tipo: 'skin', etichetta: 'Skin Castello' },
    { id: 'pack_cornici', tipo: 'cornici', etichetta: 'Pack Cornici' }
  ];

  function tuttiGliId() {
    var out = [];
    for (var i = 0; i < PRODOTTI.length; i++) out.push(PRODOTTI[i].id);
    return out;
  }

  // Mapping id prodotto -> effetto sul save (GDD "Monetizzazione", tabella + regole). Tabelle a
  // parte (non un unico if/else enorme) cosi' aggiungere un colore/skin futuro e' una riga qui,
  // non un nuovo ramo di codice.
  var COLORE_INDICE = { colore_oro: 4, colore_notte_neon: 5, colore_ghiaccio: 7 };
  var SKIN_NOME = { skin_arcade: 'arcade', skin_mare: 'mare', skin_castello: 'castello' };
  var CORNICI_PACK = ['dorata', 'neon'];

  // Il Google Play Billing (e con lui RevenueCat) puo' restituire un id con un suffisso tipo
  // ":base-plan" per i prodotti a piano base — noi vendiamo solo non-consumabili semplici ma
  // meglio restare difensivi: normalizza SEMPRE all'id base prima di confrontare.
  function normalizzaId(id) {
    if (typeof id !== 'string') return id;
    var i = id.indexOf(':');
    return i === -1 ? id : id.substring(0, i);
  }

  // Estrae gli id prodotto acquistati da una CustomerInfo, difendendosi sulla FORMA: il plugin
  // a volte restituisce l'oggetto nudo, a volte lo incapsula in {customerInfo:{...}} (dipende
  // dalla chiamata: getCustomerInfo/restorePurchases/l'esito di purchaseStoreProduct non sono
  // sempre garantiti identici fra versioni). allPurchasedProductIdentifiers e' la lista COMPLETA
  // di cio' che l'account ha comprato (non solo l'ultimo acquisto): e' la fonte di verita' che
  // rende applicaAcquisti riapplicabile ad ogni boot senza perdere nulla.
  function estraiIds(risultato) {
    var info = (risultato && risultato.customerInfo) || risultato || {};
    var grezzi = info.allPurchasedProductIdentifiers;
    if (!Array.isArray(grezzi)) return [];
    var out = [];
    for (var i = 0; i < grezzi.length; i++) out.push(normalizzaId(grezzi[i]));
    return out;
  }

  // ---------- Il cuore testabile: PURA e SINCRONA ----------
  // Applica il mapping del GDD a state per ogni id in productIds. IDEMPOTENTE apposta: e' la
  // stessa lista di id che puo' arrivare piu' volte (ogni boot rilegge la CustomerInfo, un
  // ripristino puo' ripetere id gia' posseduti) e richiamarla non deve mai duplicare uno sblocco
  // ne' contarlo due volte — per questo ogni ramo controlla "e' gia' presente?" prima di
  // aggiungere e SOLO allora incrementa il contatore. NON salva mai: persistere lo stato e'
  // compito del chiamante (la UI fa PETQ.save.save dopo aver ricevuto la cb con nuovi > 0).
  function applicaAcquisti(state, productIds) {
    if (!state || !Array.isArray(productIds) || !productIds.length) return 0;

    var nuovi = 0;

    for (var i = 0; i < productIds.length; i++) {
      var id = normalizzaId(productIds[i]);

      if (id === 'supporter_pack') {
        if (state.supporter !== true) {
          state.supporter = true;
          nuovi++;
        }
        // SEMPRE, anche se supporter era gia' true: e' la stessa chiamata idempotente che usa
        // save.js al boot (v. save.js sincronizzaCompanionSupporter) — i 4 companion del pack
        // vanno garantiti presenti ogni volta che riapplichiamo gli acquisti, non solo la prima.
        if (PETQ.save && PETQ.save.sincronizzaCompanionSupporter) {
          PETQ.save.sincronizzaCompanionSupporter(state);
        }
        continue;
      }

      if (Object.prototype.hasOwnProperty.call(COLORE_INDICE, id)) {
        var indiceColore = COLORE_INDICE[id];
        if (!Array.isArray(state.coloriSbloccati)) state.coloriSbloccati = [];
        if (state.coloriSbloccati.indexOf(indiceColore) === -1) {
          state.coloriSbloccati.push(indiceColore);
          nuovi++;
        }
        continue;
      }

      if (Object.prototype.hasOwnProperty.call(SKIN_NOME, id)) {
        var nomeSkin = SKIN_NOME[id];
        if (!Array.isArray(state.skinSbloccate)) state.skinSbloccate = [];
        if (state.skinSbloccate.indexOf(nomeSkin) === -1) {
          state.skinSbloccate.push(nomeSkin);
          nuovi++;
        }
        continue;
      }

      if (id === 'pack_cornici') {
        if (!Array.isArray(state.corniciSbloccate)) state.corniciSbloccate = [];
        for (var c = 0; c < CORNICI_PACK.length; c++) {
          if (state.corniciSbloccate.indexOf(CORNICI_PACK[c]) === -1) {
            state.corniciSbloccate.push(CORNICI_PACK[c]);
            nuovi++;
          }
        }
        continue;
      }

      // Id sconosciuto (prodotto rimosso dal catalogo, refuso, ambiente di test): si ignora in
      // silenzio, non e' compito di questo modulo segnalarlo.
    }

    return nuovi;
  }

  // ---------- Inizializzazione ----------
  var _inizializzato = false;

  // Chiama Purchases.configure UNA sola volta (guardia di modulo _inizializzato): configure va
  // fatta una volta per vita dell'app, richiamarla non serve e puo' solo generare traffico
  // inutile verso RevenueCat. No-op totale se il modulo e' dormiente (plugin o chiave assenti):
  // la guardia si "consuma" solo quando l'inizializzazione parte davvero, cosi' se la chiave
  // arrivasse piu' tardi (non previsto oggi, ma per sicurezza) il modulo potrebbe ancora agganciarsi.
  function inizializza() {
    if (_inizializzato) return;
    if (!disponibile()) return;
    _inizializzato = true;
    purchasesPlugin().configure({ apiKey: chiaveApi() }).catch(function () {
      /* configure fallita (chiave non valida, plugin non pronto): silenzioso, come da contratto */
    });
  }

  // ---------- Catalogo prezzi (per la UI, che qui non si tocca mai direttamente) ----------
  // cb(null, mappa id->priceString). Difensivo sui campi del prodotto perche' la forma esatta
  // di StoreProduct non e' garantita identica fra Android/iOS/versioni del plugin.
  function prodotti(cb) {
    if (!disponibile()) { cb(null, {}); return; }

    inizializza(); // configure() deve precedere qualunque chiamata allo store

    // type NON_SUBSCRIPTION: su Android getProducts SENZA type cerca gli ABBONAMENTI
    // ("SUBSCRIPTION by default", definitions.d.ts del plugin) — noi vendiamo solo
    // non-consumabili, quindi la lista tornava SEMPRE vuota sul telefono: era questo il
    // "Product not available" del collaudo di ago 2026. Su iOS il campo viene ignorato.
    purchasesPlugin().getProducts({ productIdentifiers: tuttiGliId(), type: 'NON_SUBSCRIPTION' }).then(function (risultato) {
      var lista = (risultato && risultato.products) || risultato || [];
      if (!Array.isArray(lista)) lista = [];

      var mappa = {};
      for (var i = 0; i < lista.length; i++) {
        var p = lista[i] || {};
        var pid = p.identifier || p.productIdentifier || p.id;
        if (!pid) continue;
        var prezzo = p.priceString || p.price_string || null;
        mappa[normalizzaId(pid)] = prezzo;
      }
      cb(null, mappa);
    }).catch(function () {
      cb(null, {}); // la UI mostra i prezzi come '—', mai un errore bloccante per questo
    });
  }

  // ---------- Acquisto ----------
  // getProducts per il solo id richiesto -> purchaseStoreProduct -> la verita' sull'esito e'
  // nella CustomerInfo restituita (mai un "successo" nostro senza rileggerla): applicaAcquisti
  // e' quello che davvero sblocca lo stato.
  function compra(id, state, cb) {
    if (!disponibile()) { cb({ nonDisponibile: true }); return; }

    inizializza(); // configure() deve precedere qualunque chiamata allo store

    var plugin = purchasesPlugin();

    // type NON_SUBSCRIPTION: stesso motivo della chiamata in prodotti() qui sopra.
    plugin.getProducts({ productIdentifiers: [id], type: 'NON_SUBSCRIPTION' }).then(function (risultato) {
      var lista = (risultato && risultato.products) || risultato || [];
      if (!Array.isArray(lista)) lista = [];
      var prodotto = lista[0];
      if (!prodotto) { cb({ nonDisponibile: true }); return; }

      plugin.purchaseStoreProduct({ product: prodotto }).then(function (esito) {
        var ids = estraiIds(esito);
        var n = applicaAcquisti(state, ids);
        cb(null, { nuovi: n });
      }).catch(function (err) {
        err = err || {};
        // RevenueCat segnala l'annullo utente con userCancelled, o in alternativa col codice
        // numerico 1 (PURCHASE_CANCELLED_ERROR) — controlliamo entrambi perche' la forma esatta
        // dell'errore e' cambiata fra versioni del plugin.
        if (err.userCancelled || err.code === 1 || err.code === '1') {
          cb({ annullato: true });
        } else {
          cb(err);
        }
      });
    }).catch(function (err) {
      cb(err || {});
    });
  }

  // ---------- Ripristino (telefono nuovo / reinstallo) ----------
  function ripristina(state, cb) {
    if (!disponibile()) { cb({ nonDisponibile: true }); return; }

    inizializza(); // configure() deve precedere qualunque chiamata allo store

    purchasesPlugin().restorePurchases().then(function (risultato) {
      var ids = estraiIds(risultato);
      var n = applicaAcquisti(state, ids);
      cb(null, { nuovi: n });
    }).catch(function (err) {
      cb(err || {});
    });
  }

  // ---------- Sincronizzazione idempotente al boot ----------
  // Legge la cache OFFLINE del SDK (getCustomerInfo, non forza una chiamata di rete) e riapplica
  // gli sblocchi: e' il modo in cui un acquisto fatto su un boot precedente (o su un altro
  // dispositivo, dopo un ripristino) resta valido ad ogni avvio senza dover comprare di nuovo.
  // Mai un errore verso il chiamante: al boot un problema qui non deve mai impedire al gioco di
  // partire, quindi anche un fallimento della lettura si traduce in "zero nuovi sblocchi" e non
  // in un cb(err).
  function sincronizza(state, cb) {
    if (!disponibile()) { cb(null, { nuovi: 0 }); return; }

    inizializza();

    purchasesPlugin().getCustomerInfo().then(function (risultato) {
      var ids = estraiIds(risultato);
      var n = applicaAcquisti(state, ids);
      cb(null, { nuovi: n });
    }).catch(function () {
      cb(null, { nuovi: 0 });
    });
  }

  // ---------- Diagnostica errori (fondatore, ago 2026: "Purchase failed" da solo non basta a
  // capire un fallimento vero in corso su un telefono) ----------
  // Compone una coda breve tipo " (code 6: PRODUCT_NOT_AVAILABLE)" a partire da un errore
  // qualsiasi restituito dal plugin RevenueCat Capacitor. La forma esatta dell'errore NON e'
  // garantita fra versioni del plugin (v. commenti su compra()/estraiIds sopra): per questo si
  // controllano in cascata TUTTI i campi noti — err.code per il codice numerico/stringa, poi il
  // primo fra err.message/err.underlyingErrorMessage/err.readableErrorCode che non sia vuoto per
  // la descrizione leggibile. Se non c'e' niente di utile (err vuoto, o un oggetto senza nessuno
  // di questi campi, es. {annullato:true}/{nonDisponibile:true}) ritorna stringa vuota. Difensiva
  // al 100%: avvolta in try/catch, non deve MAI lanciare (verrebbe chiamata dentro un toast di
  // errore, sarebbe assurdo che il diagnostico rompa il messaggio d'errore stesso).
  function descriviErrore(err) {
    try {
      if (!err || typeof err !== 'object') return '';
      var parti = [];
      if (err.code !== undefined && err.code !== null && err.code !== '') {
        parti.push('code ' + err.code);
      }
      var msg = null;
      if (typeof err.message === 'string' && err.message) msg = err.message;
      else if (typeof err.underlyingErrorMessage === 'string' && err.underlyingErrorMessage) msg = err.underlyingErrorMessage;
      else if (typeof err.readableErrorCode === 'string' && err.readableErrorCode) msg = err.readableErrorCode;
      if (msg) parti.push(msg);
      if (!parti.length) return '';
      return ' (' + parti.join(': ') + ')';
    } catch (e) {
      return '';
    }
  }

  // Hook SOLO COLLAUDO (stesso ruolo di _regole in notifiche.js): sostituisce il plugin e/o la
  // chiave API per i test in browser (senza plugin/chiave veri non si puo' mai davvero
  // acquistare da qui). MAI da chiamare in codice di produzione — serve solo a chi scrive test.
  // Azzera anche la guardia di inizializza() cosi' ogni test riparte da uno stato pulito.
  function _test(pluginFinto, chiaveFinta) {
    _pluginOverride = pluginFinto || null;
    _inizializzato = false;
    _hasChiaveOverride = arguments.length >= 2;
    _chiaveOverride = chiaveFinta;
  }

  window.PETQ.iap = {
    PRODOTTI: PRODOTTI,
    disponibile: disponibile,
    inizializza: inizializza,
    applicaAcquisti: applicaAcquisti,
    prodotti: prodotti,
    compra: compra,
    ripristina: ripristina,
    sincronizza: sincronizza,
    descriviErrore: descriviErrore,
    _test: _test
  };

})();
