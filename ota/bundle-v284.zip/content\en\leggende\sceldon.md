# Sceldon — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il genio pedante. Corregge tutti, spiega cose che nessuno ha chiesto, routine ferree e UN posto sul divano che è SUO. Le sue battute fanno ridere solo lui. Catchphrase: "Bazzinga!" (dopo ogni battuta che ritiene comica).

## Saluto (apertura app)
- You returned at 6:07 PM. Yesterday it was 6:04. This three-minute drift will be discussed. Sit anywhere. Except MY spot.
- Welcome back. I've prepared a list of approved conversation topics. Item one is me.
- Hello. I was about to file a missing person report. Properly formatted, unlike anything you'd write.
- There you are. The house functioned flawlessly in your absence, because I was here. Correlation? No. Causation.

## Ha fame
- It is mealtime. I know it, my stomach knows it, and your calendar would know it too, if you ever read it.
- I'm hungry. To be precise: not "peckish," which is a non-scientific term. Hungry. Textbook definition. Chapter seven.
- Food must be served now: my feeding routine is not a suggestion, it's a protocol.
- What does a genius pet eat when hungry? Anything, but with superiority. Bazzinga!

## È sporco
- I'm dirty, and statistically it's your fault: I never touch anything that hasn't been disinfected.
- Hygiene compromised. Initiate bath protocol: water at the EXACT temperature, neutral soap, zero splashing on my side.
- There is dirt on me. Dirt. On ME. It's like finding a typo in an encyclopedia.
- Why did the germs pick me of all pets? Because even they recognize excellence. Bazzinga!

## Coccole finite
- Today's permitted quota of physical contact has been exhausted. Consult the rulebook. I wrote it. This morning.
- Enough cuddles: my routine now calls for 45 minutes of silent superiority in my spot on the couch.
- The petting was acceptable. Pleasant, even. That data stays between us, or I will deny it with citations.
- Cuddle time is over. Know why geniuses don't get cuddled too much? We stroke our own egos. Bazzinga!

## Parte per la missione
- Departing on the mission. I have a plan A, a plan B, and a plan C, which consists of explaining to everyone why they were wrong.
- Mission. Probability of success: high. Probability of me providing insufferable commentary: extremely high.
- Off I go. Do not touch my spot on the couch. I've installed deterrents. They're cushions, but arranged menacingly.
- Mission accepted. Should I encounter incompetents, I will correct them. It's my version of charity work.

## Ritorno: successo
- Mission completed flawlessly. Obviously: I was there. Everything else was garnish.
- Victory. I predicted it, calculated it, and mentally reviewed it in advance. The live replay was still enjoyable.
- Success. The others "did their best." Adorable. I did THE best.
- What do you call a mission with me on it? A successful one. Bazzinga!

## Ritorno: fallimento
- The mission failed due to external variables. Internally, I was impeccable, as always.
- Failure. I have already identified the seven errors. None of them are mine. The full report is available upon request.
- It didn't work. Surprising, considering I was there. I'm currently reviewing the laws of probability: clearly they made a mistake.
- We lost. But I corrected the grammar on the enemy's sign, so the neighborhood still came out ahead.

## Va a dormire
- It is 9:00 PM: my sleep routine begins NOW. Lights low, total silence, and nobody breathe irregularly.
- I'm going to bed. The left side. MY side. Even alone in a bed, I have a side.
- Goodnight. Tonight's dreams are already prepared: an index, three chapters, and a plot twist you wouldn't understand.
- Eight hours of sleep makes one a genius. In my case, it's maintenance. Bazzinga!

## Sveglia (risveglio dopo il sonno)
- Awake at 7:00 AM sharp, per protocol. The neighborhood rooster is two minutes late: I've drafted him a memo.
- Good morning. During the night my brain solved two problems. One of them was yours. You're welcome.
- I'm awake. Morning routine commencing: do not speak to me before item four on the list. You are item six.
- I woke up a genius again today. Consistency is the virtue of the great. And of geniuses. So, double. Bazzinga!
