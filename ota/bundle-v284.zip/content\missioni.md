# Missioni — prototipo (32 schede + tutorial)

Chi compila: il fondatore definisce le schede (requisiti, durata, reward, condizioni); il socio scrive i testi degli esiti (qui in versione neutra, poi le varianti per personalità). Ogni scheda ha anche una riga "Scena" per chi disegnerà gli sprite di ogni esito.

**Modello di risoluzione (pet baby, prototipo)** — niente tiro di dado, niente soglia probabilistica. Il giocatore sceglie 1 missione al giorno da una rosa di 3; quasi sempre l'esito è quello **standard** (è così che il pet cresce, punto). Fallimento e super successo sono code rare, deterministiche: scattano solo se il pet soddisfa la condizione scritta sulla scheda (di solito una personalità precisa, a volte insieme a una stat molto bassa/alta). Il fallimento non è mai un "meno secco": compensa sempre con qualcosa, possibilmente in tema con la missione. Dettagli del modello e vecchia formula probabilistica (fase adulta) in bilanciamento.md.

**INDICE STADIO (per il motore — così è chiaro cosa è baby/teen/fuori-rosa):**
- **Baby rosa** (16): M1–M16. **Baby intro fuori-rosa**: M0 (tutorial, giorno 1).
- **Teen rosa** (15): M18–M32. **Teen intro fuori-rosa**: M17 (Pimp My Pet, all'evoluzione, 1 volta).
- Nelle righe Dati: `stadio=baby|teen` su ogni scheda; gli intro hanno `tutorial=1` (M0) o `teenIntro=1` (M17) e NON entrano nella rosa. (Le baby senza `stadio=` esplicito vanno lette come baby.)
- **Rosa per stadio** (decisione fondatore 5 lug): la rosa di un pet TEEN pesca SOLO missioni teen; quella di un pet BABY solo baby. Un teen non rigioca le baby.

**Categorie, tag & perk**: ogni missione ha una categoria (Videogioco, Sociale, Combattimento, Studio, Consegne, Sport, Lavoretti) e opzionalmente uno o più **tag** trasversali (invenzione, natura, gara, inseguimento, rapina, mostro, studio, social, musica) usati dai talenti e da alcuni perk. Alcuni super successi sbloccano un **perk**: un arredo che, finché è piazzato in casa, annulla il fallimento e garantisce sempre il super successo nelle missioni future della stessa categoria — o dello stesso tag, come Sabotatore sulle gare senza perk proprio.

---

## Missione 0 — Tutorial: Il negozio di giocattoli [fuori rosa, solo giorno 1, mai fallimento]
Brief: Le saracinesche si alzano apposta per lui: scaffali pieni fino al soffitto, e qualcosa lo chiama per nome.
- Luogo: 📍 Negozio di Giocattoli
- Razza: entrambe
- Costo: gratis (regalo di benvenuto)
- Dati: tutorial=1 ; costo=0
- Reward: Felicità +10 + 1 oggetto collezionabile, secondo la personalità:

| Personalità | Oggetto | Bonus passivo |
|---|---|---|
| Sportivo | Pallone da calcio | +1 Forza |
| Nerd | GameBit portatile | +1 Intelligenza |
| Gentile | Microfono giocattolo | +1 Carisma |
| Maleducato | Fumetto sarcastico | +1 Intelligenza |

- Dati: cond= sportivo ; reward= fel+10, arredo:Pallone da calcio
- Dati: cond= nerd ; reward= fel+10, arredo:GameBit portatile
- Dati: cond= gentile ; reward= fel+10, arredo:Microfono giocattolo
- Dati: cond= maleducato ; reward= fel+10, arredo:Fumetto sarcastico
- Testo (slot {oggetto}): "Le saracinesche del negozio di giocattoli si alzano proprio mentre passi di lì, quasi per invito. Dentro, scaffali pieni fino al soffitto di cose che non ti servono — ma tu vai dritto verso una sola, come se ti stesse chiamando per nome: {oggetto}. Lo stringi tutto il tragitto di ritorno, e per una volta non stai calcolando se ti serve davvero. Lo vuoi, e basta."
- Scena: pet che stringe {oggetto} tra le braccia, sorriso aperto

## Missione 1: Torneo alla Sala Giochi
Brief: Pollici sui pulsanti, luci lampeggianti: al Bit & Byte è sera di torneo lampo e la coppa in palio è vera.
- Luogo: 📍 Sala Giochi "Bit & Byte"
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Velocità
- Durata: 1h
- Costo: 3 monete
- Dati: durata=1h ; costo=3 ; categoria=videogioco ; stat=velocita

**Standard** — +1 Velocità, Felicità +5
Dati: reward= velocita+1, fel+5
Testo: "La sala è piena del solito ronzio di cabinati e luci lampeggianti. Ti piazzi al primo schermo libero, pollici già pronti — e macini punti come se il joystick rispondesse solo a te. Non il record storico della sala, ma abbastanza da guadagnarti un'occhiata di rispetto dal tizio dietro al banco."
Scena: pet di profilo davanti al cabinato, pollici sui pulsanti, aria concentrata

**Fallimento** (condizione: Maleducato + Velocità 0) — rimborso dei 3 monete del costo, Felicità invariata
Dati: cond= maleducato & velocita<=0 ; reward= rimborsoCosto
Testo: "Primo livello, primo game over — e nemmeno per colpa del gioco, diciamocelo. Il cabinato lampeggia la scritta più umiliante dell'alfabeto, tu rispondi con un pugno che fa più rumore che danno. Il gestore, imbarazzato dalla scenata davanti a tutti, ti scorta fuori con la mano sulla spalla: 'dai su, non è successo niente, ma non tornare per un po'.'"
Scena: pet col pugno chiuso contro lo schermo "GAME OVER", oppure scortato fuori

**Super successo** (condizione: Nerd O Velocità 3+, oppure perk Videogioco già posseduto) — Felicità +10, Coppa Arcade (arredo raro, +1 Velocità passivo; piazzata = perk Videogioco: niente fallimento e sempre super successo nelle prossime missioni Videogioco)
Dati: cond= nerd | velocita>=3 ; reward= fel+10, arredo:Coppa Arcade, perk:videogioco
Testo: "Qualcuno ha attaccato un cartello 'TORNEO LAMPO — VINCI LA COPPA' sopra il cabinato più bello della sala. Ti iscrivi per gioco, avanzi per un misto di riflessi e fortuna sfacciata, e in finale ti ritrovi mezza sala che tifa per l'avversario. Vinci comunque. Il gestore in persona ti mette in mano una coppa vera — pesante, lucida, imbarazzantemente esagerata per un torneo nato per sbaglio un martedì pomeriggio."
Scena: pet con le braccia alzate, coppa dorata sopra la testa, luci/folla sullo sfondo

## Missione 2: Festa di compleanno al parco
Brief: Palloncini, musica troppo allegra, una torta che nessuno sorveglia abbastanza: al Parco delle Antenne è festa grossa.
- Luogo: 📍 Parco delle Antenne
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma

**Standard** — +1 Carisma, Felicità +5, Fetta di torta (cibo, Carisma+1)
Dati: reward= carisma+1, fel+5, cibo:Fetta di torta
Testo: "Il parco è pieno di palloncini e di quella musica troppo allegra che si sente da tre isolati. Ti butti tra gli invitati, chiacchieri, ridi alle battute giuste al momento giusto — e prima di sparire nella confusione qualcuno ti mette in mano una fetta, giusto una, 'il resto è per gli altri'. Giornata ben spesa comunque."
Scena: pet tra sagome di altri invitati, piatto con fetta di torta in mano, palloncini

**Fallimento** (condizione: Maleducato + Carisma 0) — niente Carisma, Torta intera (cibo, Carisma+3)
Dati: cond= maleducato & carisma<=0 ; reward= cibo:Torta intera
Testo: "Batti il record personale di comprare simpatia: zero. Una battuta di troppo, uno sguardo storto di troppo, e in cinque minuti l'intera festa ti guarda come un problema. Non ti fai troppi scrupoli: quando nessuno guarda, non ti accontenti di una fetta, ti porti via l'INTERA torta e te ne vai a muso duro, mollando la festa nel caos di chi si chiede dove sia finito il dolce."
Scena: pet a braccia conserte che scappa con la torta intera sotto il braccio, altri invitati contrariati

**Super successo** (condizione: Carisma 3+) — +1 Carisma, Felicità +10, Macchinina giocattolo (arredo, nessun bonus passivo, solo collezione)
Dati: cond= carisma>=3 ; reward= carisma+1, fel+10, arredo:Macchinina giocattolo
Testo: "Non stai nemmeno cercando di fare colpo, e proprio per questo funziona alla grande: battuta dopo battuta, diventi il motivo per cui questa festa verrà ricordata. Alla fine il festeggiato in persona ti ficca in mano il suo regalo preferito del giorno — una macchinina che luccica ancora dell'incarto — 'perché te lo meriti più di me'."
Scena: pet al centro di un capannello festante, macchinina in mano che luccica

## Missione 3: Lezioni di arti marziali
Brief: Il Dojo del Rottame profuma di sudore e disciplina: il sensei mette in fila gli allievi, ed è il suo primo giorno di tatami.
- Luogo: 📍 Dojo del Rottame
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=combattimento ; stat=forza

**Standard** — +1 Forza, Fascia da martial artist (arredo, +1 Forza passivo), Felicità +5
Dati: reward= forza+1, arredo:Fascia da martial artist, fel+5
Testo: "Il sensei — o quel che ne fa le veci qui dentro — ti mette in fila con gli altri allievi e parte con gli esercizi base. Suda, incassa qualche colpo, ne restituisce altrettanti: alla fine hai imparato due mosse vere e un inchino di approvazione. Piccoli passi."
Scena: pet in guardia, fila di allievi sullo sfondo

**Fallimento** (condizione: Forza 0 O Gentile) — niente Forza, −10 Salute, +1 Carisma
Dati: cond= forza<=0 | gentile ; reward= ferite+10, carisma+1
Testo: "Il primo sparring va così male che il sensei ti toglie dal tatami 'per la tua sicurezza'. Passi il resto della lezione a bordo campo, qualche livido di troppo — ma è lì che un altro allievo, silenzioso quanto te, inizia a farti due chiacchiere. Non hai imparato a combattere. Hai fatto un amico."
Scena: pet seduto a bordo tatami con un cerotto, chiacchiera con un altro allievo

**Super successo** (condizione: Maleducato O Forza 3+) — +1 Forza, Completo da martial artist (arredo, +2 Forza passivo, sostituisce la Fascia), perk Street Fighter (categoria Combattimento: niente fallimento, sempre super successo), Felicità +10
Dati: cond= maleducato | forza>=3 ; reward= forza+1, arredo:Completo da martial artist, perk:combattimento, fel+10
Testo: "Non fai nemmeno finta di seguire la lezione base: passi dritto agli allievi avanzati e li sfidi uno per uno, giusto per vedere l'effetto che fa. L'effetto è che smettono di ridere abbastanza in fretta. Il sensei, con un misto di orrore e rispetto, ti passa il completo riservato a chi 'ha capito lo spirito del dojo'."
Scena: pet in posa vittoriosa, allievi intimoriti intorno, completo nuovo indosso

## Missione 4: Pomeriggio in biblioteca
Brief: Un tavolo vicino alla finestra e un blocco di fogli bianchi lo aspettano: la Biblioteca dei Bit Perduti oggi è silenziosa come una chiesa.
- Luogo: 📍 Biblioteca dei Bit Perduti
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 1h30
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=intelligenza

**Standard** — +1 Intelligenza, Album da disegno (arredo, +1 Intelligenza passivo), Felicità +5
Dati: reward= intelligenza+1, arredo:Album da disegno, fel+5
Testo: "La bibliotecaria — o il suo equivalente meccanico/organico, difficile dirlo — ti indica un tavolo vicino alla finestra e ti lascia un blocco di fogli bianchi. Passi il pomeriggio tra schizzi e appunti, la lingua tra i denti per la concentrazione. Non è un capolavoro, ma quando richiudi l'album sei sicuro di aver imparato qualcosa."
Scena: pet seduto al tavolo, album aperto, lingua fuori per la concentrazione

**Fallimento** (condizione: Maleducato) — niente Intelligenza, +1 Forza
Dati: cond= maleducato ; reward= forza+1
Testo: "Cinque minuti di silenzio bastano e avanzano: il tavolo, i fogli bianchi, il ronzio delle luci al neon — tutto troppo noioso per restarci seduto. Molli l'album a metà pagina e sgusci fuori verso il campetto dietro l'angolo, dove almeno la palla non ti guarda con aria delusa."
Scena: pet che scappa con un pallone sottobraccio, foglio a metà abbandonato sul tavolo

**Super successo** (condizione: Intelligenza 3+) — +2 Intelligenza (invece di +1), Libro (arredo, +2 Intelligenza passivo, sostituisce l'Album), Felicità +10
Dati: cond= intelligenza>=3 ; reward= intelligenza+2, arredo:Libro, fel+10
Testo: "Il blocco di fogli bianchi resta bianco: oggi non hai voglia di disegnare, hai voglia di CAPIRE. Ti perdi tra gli scaffali e riemergi ore dopo con una pila di libri più alta di te. La bibliotecaria, colpita, ti lascia portare a casa il volume più prezioso dello scaffale."
Scena: pet che porta una pila di libri più alta di lui, un volume speciale in evidenza

## Missione 5: Consegna sotto la pioggia di scarti
Brief: Una pioggerella acida che nessuno sa spiegarsi cade sui vicoli della Zona Industriale, e un pacco lo aspetta per la consegna notturna.
- Luogo: 📍 Vicoli della Zona Industriale
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità + Forza
- Durata: 1h
- Dati: durata=1h ; costo=0 ; categoria=consegne ; stat=velocita,forza

**Standard** — +1 Velocità, +1 Forza, +8 monete, −10 Igiene, Felicità +5
Dati: reward= velocita+1, forza+1, monete+8, igiene-10, fel+5
Testo: "La zona industriale di notte è tutta vicoli stretti, vapore dai tombini e quella pioggerella acida che nessuno sa spiegarsi da dove venga. Consegni a tempo, firma ritirata, tutto in regola — peccato per lo strato di melma che ti sei portato dietro per tutto il tragitto."
Scena: pet che corre tra vicoli stretti, pacco sottobraccio, macchie sul corpo

**Fallimento** (condizione: Forza 0 E Velocità 0, oppure Nerd con Forza≤1 E Velocità≤1) — niente XP, −15 Igiene, Ombrello meccanico (arredo collezionabile: dimezza il calo Igiene — da −10 a −5 — in tutte le missioni a rischio pioggia/sporco, mentre è piazzato)
Dati: cond= forza<=0 & velocita<=0 | nerd & forza<=1 & velocita<=1 ; reward= igiene-15, arredo:Ombrello meccanico
Testo: "Tra buche, scorciatoie sbagliate e quella pioggerella che non vuole smettere, il pacco arriva tardi e tu arrivi peggio. Fradicio e senza voglia di rifarlo mai più, ti chiudi in garage e rimedi l'unica cosa sensata: costruirti un ombrello con quello che trovi in giro. Non elegante. Funziona."
Scena: pet fradicio seduto in garage, assembla un ombrello con pezzi di scarto

**Super successo** (condizione: Forza 2+ E Velocità 2+) — +2 Velocità, +2 Forza, +15 monete, −10 Igiene (come standard), Scooter giocattolo (arredo, +1 Velocità passivo), Felicità +10
Dati: cond= forza>=2 & velocita>=2 ; reward= velocita+2, forza+2, monete+15, igiene-10, arredo:Scooter giocattolo, fel+10
Testo: "Scatti tra i vicoli come se li conoscessi a memoria, saltando pozzanghere e schivando tubi che sbuffano vapore senza rallentare mai. Consegna record, mancia generosa, e il destinatario — sorpreso di vederti così presto E così pulito, relativamente — ti tira dietro anche uno scooter giocattolo 'per la prossima volta'."
Scena: pet che salta agilmente pozzanghere, scooter in mano

## Missione 6: Provino per lo spot in città
Brief: Facce nuove ogni cinque minuti, telecamere accese: al provino dello Studio di Trasmissione sta per toccare a lui.
- Luogo: 📍 Studio di Trasmissione
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma

**Standard** — +1 Carisma, +10 monete, Felicità +5
Dati: reward= carisma+1, monete+10, fel+5
Testo: "Il casting è un carosello di facce nuove che entrano ed escono ogni cinque minuti. Quando tocca a te, dici la battuta, fai la posa, e il regista annuisce con l'aria di chi ha visto di meglio ma non si lamenta. Sei dentro. Pagano anche bene."
Scena: pet davanti a luci da studio, regista che annuisce

**Fallimento A** (condizione: Maleducato + Carisma ≤1) — niente Carisma, Megafono (arredo, +1 Carisma passivo)
Dati: priorita=1 ; cond= maleducato & carisma<=1 ; reward= arredo:Megafono
Testo: "Il regista ti corregge una volta di troppo e decidi che il provino è finito, non prima di dirgli cosa pensi della sua regia. Non ti scritturano. Però nella foga te ne esci con il suo megafono sottobraccio."
Scena: pet che se ne va a grandi passi con un megafono, regista scandalizzato

**Fallimento B** (condizione: Intelligenza 0 O Carisma 0) — niente Carisma, +3 monete, Biscotto (cibo, Carisma+1)
Dati: priorita=2 ; cond= intelligenza<=0 | carisma<=0 ; reward= monete+3, cibo:Biscotto
Testo: "Le battute erano scritte su un foglio che, a un certo punto, hai smesso di guardare. Il regista ti ringrazia con quella cortesia che significa 'non richiameremo' — ma qualcuno dello staff, impietosito, ti infila in tasca due spiccioli e un biscotto dal buffet del catering. Meglio di niente."
Scena: pet con un biscotto in mano, espressione un po' delusa, tavolo del catering sullo sfondo

**Super successo** (condizione: Carisma 3+) — +1 Carisma, +20 monete, Statuetta tipo Oscar (arredo, +1 Carisma passivo), Felicità +10
Dati: cond= carisma>=3 ; reward= carisma+1, monete+20, arredo:Statuetta tipo Oscar, fel+10
Testo: "Non stai nemmeno recitando, a un certo punto — sei semplicemente TU, e la cinepresa sembra amarlo. Il regista si alza in piedi a metà provino. Ti scritturano su due piedi, pagano il triplo, e qualcuno ti rifila pure una statuetta avanzata da chissà quale premiazione."
Scena: pet sotto i riflettori, regista in piedi che applaude, statuetta dorata in mano

## Missione 7: Il Mostro nelle Fogne
Brief: Nelle Fogne sotto la città si aggira qualcosa di grosso, peloso e decisamente incazzato: stanotte tocca scendere a dargli la caccia.
- Luogo: 📍 Fogne / Laboratorio Abbandonato
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Durata: 1h30
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza

Le 4 armi (drop casuale nello standard, set completo nei super successi "da combattimento"): Bastone da combattimento, Sai gemelli, Nunchaku arrugginiti, Katane a farfalla — tutte arredo, +1 Forza passivo, stesso bonus, differenza solo estetica/collezione.

**Standard** — +1 Forza, −15 Salute, 1 arma casuale (delle 4), Felicità +5
Dati: reward= forza+1, ferite+15, armaCasuale, fel+5
Testo: "Nelle fogne sotto la città si aggira qualcosa di grosso, peloso, e decisamente più incazzato del solito topo di quartiere. Lo scontro è breve ma sporco — vinci, ma non senza pagarne il prezzo sulla pelle. Tra le macerie del covo raccogli un'arma a caso e te ne vai zoppicando ma soddisfatto."
Scena: pet in posa vittoriosa ma ammaccato, un'arma in mano, sfondo fogna

**Fallimento** (condizione: Forza 1 o meno) — niente Forza, −25 Salute, +5 monete, Pesi (arredo, +1 Forza passivo), Spiedino (cibo, Forza+1)
Dati: cond= forza<=1 ; reward= ferite+25, monete+5, arredo:Pesi, cibo:Spiedino
Testo: "Il topo mutante è grosso il doppio di te e lo dimostra nei primi trenta secondi. Ti ritiri più ammaccato che mai — ma non del tutto a mani vuote: trovi qualche moneta caduta da qualche tasca sfortunata, e la palestra di quartiere ti regala un set di pesi e uno spiedino ben cotto 'per rimetterti in forze'. Letteralmente."
Scena: pet zoppicante, pesi e spiedino in mano

**Super successo — Dominio** (condizione: Forza 3+) — +2 Forza, −10 Salute, +20 monete, tutte e 4 le armi, Felicità +10
Dati: priorita=2 ; cond= forza>=3 ; reward= forza+2, ferite+10, monete+20, tutteArmi, fel+10
Testo: "Non è nemmeno una gara: lo atterri con una facilità imbarazzante e resti a guardarlo scappare nel buio. Il covo è tutto tuo — non un'arma a caso stavolta, te le porti via TUTTE."
Scena: pet trionfante con tutte le armi addosso, topo in fuga sullo sfondo

**Super successo — Intimidazione** (condizione: Forza 2+ E Maleducato) — +2 Forza, +15 monete, tutte le armi, il topo come allenatore per 7 giorni (arredo temporaneo: +1 Forza extra ad ogni allenamento Forza a casa, poi scade), Felicità +10
Dati: priorita=3 ; cond= forza>=2 & maleducato ; reward= forza+2, monete+15, tutteArmi, allenatore:7g, fel+10
Testo: "Non serve nemmeno menare le mani: basta uno sguardo storto e il topone capisce con chi ha a che fare. Terrorizzato, molla armi e monete — e per farsi perdonare del tutto si offre pure di allenarti, per una settimana, prima di sparire di nuovo."
Scena: pet minaccioso, topo terrorizzato ai suoi piedi

**Super successo — Amicizia** (condizione: Gentile E Carisma 3+) — +1 Forza (solo XP base, niente armi/bottino), 0 Salute persa, il topo come allenatore permanente (arredo: +1 Forza extra ad ogni allenamento Forza a casa, per sempre), Felicità +10
Dati: priorita=1 ; cond= gentile & carisma>=3 ; reward= forza+1, allenatore:perm, fel+10
Testo: "Invece di menare le mani ti siedi, letteralmente, e chiacchieri. Il topone voleva solo un po' di compagnia in quelle fogne buie — prima che tu te ne accorga vi siete promessi di allenarvi insieme ogni giorno. Niente armi, niente bottino: un allenatore vero, per sempre."
Scena: pet e topo seduti fianco a fianco, atmosfera calma, nessuna arma in vista

Priorità se un pet soddisfa più condizioni di super successo insieme: Amicizia > Dominio > Intimidazione (l'amicizia è un percorso alternativo che esclude lo scontro a prescindere dalla Forza).

## Missione 8: Gara di Pattini a Neon Avenue
Brief: Folla ai lati della strada, semaforo che lampeggia il via: a Neon Avenue è sera di gara sui pattini.
- Luogo: 📍 Neon Avenue
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Durata: 1h
- Dati: durata=1h ; costo=0 ; categoria=sport ; stat=velocita

**Standard** — +1 Velocità, +8 monete, Pesce alla griglia (cibo, Velocità+1), Felicità +5
Dati: reward= velocita+1, monete+8, cibo:Pesce alla griglia, fel+5
Testo: "Il pubblico si accalca ai lati della strada mentre il semaforo lampeggia il via. Non sei il fulmine della serata, ma tieni un ritmo onesto e tagli il traguardo a testa alta, con applausi di cortesia e un premio di partecipazione che quantomeno copre i pattini a noleggio."
Scena: pet sui pattini al traguardo, pubblico ai lati

**Fallimento** (condizione: Velocità 0 O Gentile) — niente Velocità, Pattino spaiato (arredo, +1 Velocità passivo)
Dati: cond= velocita<=0 | gentile ; reward= arredo:Pattino spaiato
Testo: "Ti lanci con tutta l'educazione del mondo — il che, in una gara di pattini, equivale più o meno a stare fermo. Ti sorpassano tutti, con gentilezza reciproca da entrambe le parti. Sul ciglio della pista trovi però un pattino singolo perso da qualcun altro: abbastanza buono da tenertelo."
Scena: pet sorpassato da tutti, raccoglie un pattino sul bordo pista

**Super successo** (condizione: Velocità 3+ O Sportivo) — +2 Velocità, +20 monete, Pattini da gara (arredo, +2 Velocità passivo), perk Sport (categoria Sport: niente fallimento, sempre super successo), Felicità +10
Dati: cond= velocita>=3 | sportivo ; reward= velocita+2, monete+20, arredo:Pattini da gara, perk:sport, fel+10
Testo: "Non stai nemmeno pattinando, a un certo punto — stai volando basso. Tagli il traguardo con un margine imbarazzante, e lo sponsor della gara ti regala un paio di pattini professionali dritti dalla vetrina."
Scena: pet che taglia il traguardo con largo margine, pattini scintillanti

## Missione 9: Fiera della Scienza del Quartiere
Brief: Cartelloni traballanti ed esperimenti che fumano: alla Fiera della Scienza del Quartiere tocca a lui presentare la sua invenzione.
- Luogo: 📍 Fiera della Scienza del Quartiere
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: invenzione
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=studio ; stat=int ; tag=invenzione

**Standard** — +2 Int, +8 monete, Felicità +5
Dati: reward= int+2, monete+8, fel+5
Testo: "La Fiera della Scienza è un tripudio di cartelloni traballanti, esperimenti che fumano e ronzii sospetti. Presenti la tua invenzione a una giuria di quattro sapientoni con gli occhiali spessi: annuiscono, prendono appunti, uno ti fa pure una domanda difficile a cui rispondi al volo. Non vinci, ma esci con la testa più piena di quando sei entrato."
Scena: pet davanti a un cartellone-esperimento, giuria di profilo che prende appunti

**Fallimento** (condizione: Sportivo) — niente Int, Zuppa di verdure (cibo, Int+2)
Dati: priorita=1 ; cond= sportivo ; reward= cibo:Zuppa di verdure
Testo: "Cinque minuti tra formule e circuiti e già ti fischiano le orecchie: troppa roba da secchioni per i tuoi gusti. Ti defili verso il tavolo del rinfresco, dove almeno c'è della zuppa calda, e passi il resto della fiera a fare canestro con le palline di carta. Della scienza, oggi, non ti è entrato niente. Della zuppa sì."
Scena: pet annoiato che si allontana dai cartelloni con una scodella di zuppa in mano

**Fallimento** (condizione: Intelligenza ≤1) — +6 monete, +1 Int
Dati: priorita=2 ; cond= int<=1 ; reward= monete+6, int+1
Testo: "La tua invenzione, diciamo, aveva del potenziale. Peccato che a metà presentazione abbia iniziato a sfrigolare, poi a fumare, poi a spegnersi con un triste 'plop'. La giuria applaude per gentilezza e ti rimborsa le spese 'per l'impegno'. Qualcosa hai imparato, se non altro come NON si fa."
Scena: pet imbarazzato accanto a un aggeggio che sputa fumo

**Super successo** (condizione: Intelligenza 3+, o auto col talento Inventore via tag invenzione) — +3 Int, +15 monete, Coppa della Fiera (arredo raro, +1 Int passivo + perk Studio "Doc Brown": missioni Studio → niente fallimento e sempre super successo), Felicità +10
Dati: cond= int>=3 ; reward= int+3, monete+15, arredo:Coppa della Fiera, perk:studio, fel+10
Testo: "Non stai presentando un'invenzione — stai presentando IL FUTURO, e la giuria lo capisce entro trenta secondi. Occhiali che si abbassano, appunti frenetici, applausi che partono da soli. Ti consegnano la Coppa della Fiera davanti a tutti, e uno dei giudici ti stringe la mano un po' troppo a lungo: 'ricordati di me quando sarai famoso'."
Scena: pet che alza la Coppa della Fiera, giuria in piedi che applaude

## Missione 10: Sfida Robotica
Brief: Lamiera ammaccata, scintille nell'aria: nell'Arena della Sfida Robotica il suo robot fatto in casa sta per scendere in pista.
- Luogo: 📍 Arena della Sfida Robotica
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: invenzione, gara
- Durata: 1h
- Costo: 3 monete
- Dati: durata=1h ; costo=3 ; categoria=studio ; stat=int ; tag=invenzione,gara

**Standard** — +1 Int, Coppa Robot Wars (arredo, +1 Int passivo), Felicità +5
Dati: reward= int+1, arredo:Coppa Robot Wars, fel+5
Testo: "L'arena della Sfida Robotica è un quadrato di lamiera ammaccata dove piccoli robot fatti in casa si prendono a testate tra scintille e tifo isterico. Il tuo se la cava: qualche colpo dato, qualche ammaccatura presa, e un onorevole piazzamento a metà classifica. Ti porti a casa una coppa e un bel po' di nozioni su motori e ingranaggi."
Scena: pet a bordo arena con un piccolo robot telecomandato, scintille

**Fallimento** (condizione: Gentile) — niente Int, +1 Carisma, Insalatona (cibo, Int+1)
Dati: priorita=1 ; cond= gentile ; reward= carisma+1, cibo:Insalatona
Testo: "Arrivi in arena, guardi quei robottini che si prenderanno a mazzate... e proprio non te la senti. Sono troppo carini per finire a pezzi. Molli la gara, ti siedi coi tuoi 'avversari' a parlare di come li avete costruiti, e alla fine avete più amici che ammaccature. Non hai imparato a combattere, ma neanche volevi."
Scena: pet seduto in cerchio con altri concorrenti e i loro robottini, atmosfera amichevole

**Fallimento** (condizione: Intelligenza ≤1) — niente Int, Zuppa di verdure (cibo, Int+2)
Dati: priorita=2 ; cond= int<=1 ; reward= cibo:Zuppa di verdure
Testo: "Il tuo robot dura esattamente un round: parte storto, gira in tondo, poi si ferma di colpo come se ci avesse ripensato. Gli altri partecipanti, più che deriderti, ti guardano con pena e ti allungano una scodella di zuppa 'dai, la prossima va meglio'. Almeno mangi."
Scena: pet accanto al suo robottino fermo e fumante, un altro concorrente gli porge del cibo

**Super successo — Sabotaggio** (condizione: Maleducato + Intelligenza 2+) — +2 Int, Telecomando Pirata (arredo, +1 Velocità passivo + perk Sabotatore: nelle gare senza perk proprio → sempre super successo), Felicità +10
Dati: priorita=1 ; cond= maleducato & int>=2 ; reward= int+2, arredo:Telecomando Pirata, perk:sabotatore, fel+10
Testo: "Mentre gli altri si concentrano sui loro robot, tu ti concentri su UN telecomando 'preso in prestito'. Due ritocchi ai loro ricevitori e all'improvviso i robottini avversari impazziscono, si girano contro i loro stessi padroni, si autodistruggono in un valzer di scintille. Vinci per abbandono. Nessuno ha capito niente, e tu tieni il telecomando."
Scena: pet con un ghigno che smanetta un telecomando, robot avversari in tilt sullo sfondo

**Super successo — Mecha-Bot** (condizione: Intelligenza 3+) — +2 Int, Mecha-Bot (arredo raro, +2 Forza passivo), Felicità +10
Dati: priorita=2 ; cond= int>=3 ; reward= int+2, arredo:Mecha-Bot, fel+10
Testo: "Gli altri hanno portato robottini. Tu hai portato un MOSTRO. Il tuo Mecha-Bot spazza l'arena in tre mosse, e mentre gli avversari raccolgono i pezzi dei loro tu resti in piedi con le braccia incrociate. Te lo porti a casa — non è più un giocattolo, è un piccolo bestione da guerra che d'ora in poi ti rende più temibile."
Scena: pet trionfante accanto a un robot grosso e minaccioso, rottami intorno

Priorità super M10: Sabotaggio (Maleducato) prima di Mecha-Bot (generico Int 3+). Come per M7, il super batte sempre il fallimento: un Gentile con Int 3+ va in Mecha-Bot, non nel fallimento "fa amicizia".

## Missione 11: Rifugio Creature Smarrite
Brief: Al Rifugio Creature Smarrite ti aspettano guaiti, cinguettii metallici e cuccioli a tre occhi da conquistare, un pomeriggio intero.
- Luogo: 📍 Rifugio Creature Smarrite
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: natura
- Durata: 1h
- Costo: gratis (volontariato)
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=natura,companion

**Standard** — +1 Carisma, +8 monete, Cuccia (arredo camera, +1 Felicità passiva), Felicità +5, Ciucciolotto Piagnucolone (giocattolo)
Dati: reward= carisma+1, monete+8, arredo:Cuccia, giocattolo:Ciucciolotto Piagnucolone, fel+5
Testo: "Il rifugio è un tripudio di guaiti, cinguettii metallici e versi alieni indefinibili. Passi il pomeriggio a coccolare cuccioli robo e creaturine spaesate, a pulire gabbiette e a convincere un paio di famiglie che sì, quel batuffolo a tre occhi è adorabile. Il proprietario, commosso, ti ringrazia con due spicci e una cuccia avanzata 'per quando ne adotterai uno anche tu'."
Scena: pet accovacciato che accarezza un cucciolo robo/alieno, gabbiette sullo sfondo, altri cuccioli intorno — mood caldo e tenero

**Fallimento** (condizione: Maleducato) — niente Carisma, morso (Ferite +10), Biscotto (cibo Carisma+1), Distributore di croccantini (arredo cucina)
Dati: priorita=1 ; cond= maleducato ; reward= ferite+10, cibo:Biscotto, arredo:Distributore di croccantini
Testo: "Basta un pomeriggio per trasformare un rifugio tranquillo in una zona di guerra: rispondi male ai clienti, tratti i cuccioli come scocciature, e uno di loro — comprensibilmente — ti pianta i denti in un polpaccio. Te ne vai zoppicando, ma non a mani vuote: nella confusione arraffi una scatola di dolciumi e ti 'prendi in prestito' pure il distributore di croccantini."
Scena: pet scocciato che si allontana con un cucciolo aggrappato alla gamba e una scatola sottobraccio — mood comico-caotico

**Fallimento** (condizione: Carisma ≤1) — niente Carisma, morso (Ferite +10), +5 monete, Biscotto (cibo Carisma+1)
Dati: priorita=2 ; cond= carisma<=1 ; reward= ferite+10, monete+5, cibo:Biscotto
Testo: "Ce la metti tutta, ma con i cuccioli proprio non scatta la scintilla: ti annusano, ti girano intorno e decidono che non fai per loro. Uno, per sicurezza, ti dà pure un morsetto. Il proprietario ti liquida con due monete e una manciata di biscotti 'per il disturbo'. Sarà per la prossima."
Scena: pet mogio con un cerotto, un cucciolo che gli volta le spalle — mood dispiaciuto

**Super successo** (condizione: Carisma 3+, o auto col talento Amante della Natura via tag natura) — +2 Carisma, +18 monete, Gattino Robot (arredo camera, +1 Carisma passivo), Felicità +10
Dati: cond= carisma>=3 ; reward= carisma+2, monete+18, arredo:Gattino Robot, fel+10
Testo: "Nel giro di un'ora sei diventato il preferito del rifugio: i cuccioli ti seguono in fila, i clienti si fidano solo di te, e trovi casa a metà degli ospiti prima di sera. Il proprietario ti riempie di monete e ti mette tra le braccia il pezzo pregiato del rifugio: un gattino robot che ha scelto TE e non intende più mollarti."
Scena: [DEDICATA] pet raggiante circondato da cuccioli festanti, un gattino robot in braccio che fa le fusa (scintille/cuoricini) — mood trionfale e adorabile

## Missione 12: Serra del Giardiniere Matto
Brief: Nella Serra del Giardiniere Matto le piante aliene sibilano, si allungano e ti fissano — e il vecchio giardiniere ha regole tutte sue.
- Luogo: 📍 Serra del Giardiniere Matto
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: natura
- Durata: 1h30
- Costo: gratis (volontariato)
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; tag=natura

**Standard** — +1 Int, +8 monete, Felicità +5
Dati: reward= int+1, monete+8, fel+5
Testo: "La serra è una giungla di piante aliene che sibilano, si allungano e ti fissano con baccelli che sembrano occhi. Il vecchio giardiniere, mezzo matto e coperto di foglie, ti insegna quali annaffiare, quali NON toccare e quale canticchiare per farla fiorire. Alla fine hai le dita verdi e la testa piena di nozioni botaniche assurde ma utili."
Scena: pet con annaffiatoio tra piante aliene bizzarre e altissime, il giardiniere eccentrico che indica una pianta — mood curioso, luce verde-serra

**Fallimento** (condizione: Intelligenza ≤1) — niente Int, Manuale di Botanica (arredo camera, +1 Int passivo)
Dati: cond= int<=1 ; reward= arredo:Manuale di Botanica
Testo: "Le piante aliene hanno regole precise, e tu ne sbagli praticamente tutte: annaffi quella che odia l'acqua, poti quella che andava lasciata stare, e finisci avvolto dai tentacoli di una che 'di solito è docile'. Il giardiniere ti libera ridacchiando e ti regala un manuale: 'leggilo, la prossima volta, PRIMA di entrare'."
Scena: pet impigliato nei tentacoli di una pianta, il giardiniere che ride e porge un libro — mood comico

**Super successo** (condizione: Intelligenza 3+, o auto col talento Amante della Natura via tag natura) — +2 Int, +15 monete, Pianta Esotica (arredo mettibile in ogni stanza, +2 a una stat RPG casuale ogni giorno), Felicità +10
Dati: cond= int>=3 ; reward= int+2, monete+15, arredo:Pianta Esotica, fel+10
Testo: "Non solo impari le regole della serra — le riscrivi. Capisci al volo cosa vuole ogni pianta, ne fai fiorire una che il giardiniere non vedeva sbocciare da anni, e lui, con le lacrime agli occhi, ti affida il suo esemplare più prezioso: una pianta esotica dai poteri imprevedibili, che ogni giorno regala energie diverse a chi le sta vicino."
Scena: [DEDICATA] pet che regge con orgoglio una pianta esotica luminosa e pulsante di colori, il giardiniere commosso sullo sfondo — mood magico

## Missione 13: Braccio di Ferro al Bar dei Bulloni
Brief: Il Bar dei Bulloni è pieno di energumeni che si stringono la mano come per spezzarla: tocca a te sederti al tavolo.
- Luogo: 📍 Bar dei Bulloni
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: gara
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=gara

**Standard** — +1 Forza, +8 monete, Trofeo Braccio di Ferro (arredo, +1 Forza passivo), Felicità +5
Dati: reward= forza+1, monete+8, arredo:Trofeo Braccio di Ferro, fel+5
Testo: "Il Bar dei Bulloni è pieno di energumeni che si stringono la mano come per spezzarla. Ti siedi al tavolo, gomito piantato, e con una spinta secca metti giù il primo sfidante. Applausi, una bibita alla spina e un trofeo di latta."
Scena: pet al tavolo che atterra il braccio di un energumeno, folla di bestioni intorno

**Fallimento** (condizione: Gentile + Forza ≤1) — +1 Carisma, Spiedino (cibo Forza+1)
Dati: priorita=1 ; cond= gentile & forza<=1 ; reward= carisma+1, cibo:Spiedino
Testo: "Non hai la stazza per vincere, ma hai il sorriso giusto: invece di prenderle, finisci a ridere e scherzare coi bestioni, che ti adottano come mascotte del bancone."
Scena: pet minuto che ride tra energumeni sorridenti

**Fallimento** (condizione: Forza ≤1) — Ferite +10, Bistecca (cibo Forza+2)
Dati: priorita=2 ; cond= forza<=1 ; reward= ferite+10, cibo:Bistecca
Testo: "Il tuo gomito tocca il tavolo in mezzo secondo netto, e ti porti a casa un braccio indolenzito. Gli energumeni, tra una risata e l'altra, ti rifilano una bella bistecca: 'mangia, gambo di sedano'."
Scena: pet col braccio indolenzito, un bestione che gli porge un piatto di carne

**Super successo** (condizione: Forza 3+, o auto col perk Sabotatore via tag gara) — +2 Forza, +12 monete, Trofeo d'Oro Braccio di Ferro (arredo raro, +1 Forza passivo + perk Popeye: mangiando verdure prende anche +1 Forza), Felicità +10
Dati: cond= forza>=3 ; reward= forza+2, monete+12, arredo:Trofeo d'Oro Braccio di Ferro, perk:popeye, fel+10
Testo: "Li metti giù tutti, uno dopo l'altro, senza scomporti. Il bar intero scandisce il tuo nome, e il gestore stacca dal muro il trofeo d'oro riservato ai leggendari."
Scena: [DEDICATA] pet che alza il trofeo d'oro, energumeni sconfitti a bocca aperta

## Missione 14: Trasloco del Sesto Piano
Brief: Sei rampe, zero ascensore, un armadio che pesa quanto te: il trasloco del sesto piano non fa sconti a nessuno.
- Luogo: 📍 Palazzo senza Ascensore
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza

**Standard** — +1 Forza, +15 monete, −8 Igiene, Felicità +5
Dati: reward= forza+1, monete+15, igiene-8, fel+5
Testo: "Sei rampe, niente ascensore, e un armadio a quattro ante che pesa quanto te. Su e giù fino a sera: le braccia bruciano, ma il trasloco è finito e il portafoglio ringrazia. Peccato per la polvere ovunque."
Scena: pet che porta un armadio enorme su per le scale, sudato

**Fallimento** (condizione: Maleducato) — Arrosto (cibo multi-porzione: 3 fette, ogni fetta Forza+1)
Dati: priorita=1 ; cond= maleducato ; reward= cibo:Arrosto
Testo: "Dopo due ordini di troppo del capocantiere, molli tutto a metà scala. Ma già che sei in giro per l'edificio, ti 'prendi in prestito' un arrosto intero da una cucina lasciata aperta."
Scena: pet che se ne va spallucciando con un arrosto fumante sottobraccio

**Fallimento** (condizione: Forza ≤1) — +6 monete, Barretta proteica (cibo Forza+1)
Dati: priorita=2 ; cond= forza<=1 ; reward= monete+6, cibo:Barretta proteica
Testo: "Al terzo viaggio le gambe dicono basta. Il capo ti liquida con metà paga e una barretta proteica: 'allenati e torna'."
Scena: pet accasciato sui gradini con una scatola mollata a terra

**Super successo** (condizione: Nerd + talento Inventore) — +2 Forza, +20 monete, Targa Traslocatore dell'Anno (arredo, +1 Forza passivo), 0 energia consumata e niente −Igiene (monti un montacarichi), Felicità +10
Dati: priorita=1 ; cond= nerd & talento:inventore ; reward= forza+2, monete+20, arredo:Targa Traslocatore dell'Anno, energiaMissione=0, fel+10
Testo: "Invece di sfiancarti, in un'ora monti un montacarichi con corde e carrucole: il lavoro lo fa la fisica. Stessa targa, stessa paga, zero fatica — e mani pulite."
Scena: [DEDICATA] pet soddisfatto accanto a un montacarichi rustico che solleva i mobili

**Super successo** (condizione: Forza 3+) — +2 Forza, +20 monete, −8 Igiene, Targa Traslocatore dell'Anno (arredo, +1 Forza passivo), Felicità +10
Dati: priorita=2 ; cond= forza>=3 ; reward= forza+2, monete+20, igiene-8, arredo:Targa Traslocatore dell'Anno, fel+10
Testo: "Carichi due scatoloni per mano e voli su e giù per le scale come se fossero piatte. Finisci in metà tempo e il capo ti consegna la targa 'Traslocatore dell'Anno'."
Scena: [DEDICATA] pet trionfante con la targa, pila di scatoloni sistemati dietro

Priorità M14: la via Nerd+Inventore (montacarichi, 0 energia) batte il super generico Forza 3+.

## Missione 15: Acchiappa lo Scippatore
Brief: Uno scippatore ti sfreccia accanto col bottino di qualcuno: parte l'inseguimento tra i vicoli del centro.
- Luogo: 📍 Vicoli del Centro
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: inseguimento
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=inseguimento

**Standard** — +1 Velocità, +10 monete, Paperella a Reazione (arredo bagno, +1 Velocità passivo), Felicità +5
Dati: reward= velocita+1, monete+10, arredo:Paperella a Reazione, fel+5
Testo: "Uno scippatore ti sfreccia accanto col bottino di qualcuno. Parti in quarta, lo insegui tra i vicoli e lo placchi contro un cassonetto. Il derubato ti ricompensa, e nella borsa recuperata c'è pure una paperella a reazione."
Scena: pet in corsa che placca uno scippatore, borsa che vola

**Fallimento** (condizione: Velocità ≤1) — Sushi (cibo Velocità+2)
Dati: cond= velocita<=1 ; reward= cibo:Sushi
Testo: "Parte come un razzo e tu... no. Lo perdi al primo angolo. I vicini, che hanno visto il tentativo, ti consolano con del sushi fresco."
Scena: pet piegato in due col fiatone, lo scippatore lontano

**Super successo** (condizione: Velocità 3+, oppure Sportivo + talento Energico) — +2 Velocità, +15 monete, Scarpe da Parkour (arredo, +1 Velocità passivo + perk Parkour Master: auto-super nelle missioni tag inseguimento), Felicità +10
Dati: cond= velocita>=3 | (sportivo & talento:energico) ; reward= velocita+2, monete+15, arredo:Scarpe da Parkour, perk:parkour, fel+10
Testo: "Non solo lo prendi — lo fai rimbalzando su muri, scale e tettoie come se la città fosse una pista da parkour. Ti restano addosso un paio di scarpe leggendarie e la fama di chi in strada non lo prende nessuno."
Scena: [DEDICATA] pet a mezz'aria tra due muri in posa da parkour, scippatore braccato sotto

## Missione 16: Cattura Pesci a Mani Nude
Brief: Le vasche dell'acquario comunale si sono rotte e i pesci guizzano ovunque sul pavimento allagato: si va a mani nude.
- Luogo: 📍 Acquario Comunale (Vasche Rotte)
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: natura
- Durata: 1h30
- Costo: gratis
- Nota: missione volutamente difficile (super a Velocità 4+)
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=natura

**Standard** — +2 Velocità, +10 monete, Acquario di Casa (arredo camera, +1 Velocità +1 Felicità passivo), Felicità +5
Dati: reward= velocita+2, monete+10, arredo:Acquario di Casa, fel+5
Testo: "Le vasche dell'acquario si sono rotte e i pesci guizzano ovunque sul pavimento allagato. Li rincorri per ore, scivolando e riacchiappandoli a mani nude. Ne salvi un bel po', ti paghi il disturbo e ne tieni uno in una boccia."
Scena: pet che si tuffa per acchiappare pesci guizzanti in una sala allagata

**Fallimento** (condizione: Velocità ≤1, oppure Nerd + talento Idrofobico) — +4 monete, +1 Velocità, niente acquario
Dati: cond= velocita<=1 | (nerd & talento:idrofobico) ; reward= monete+4, velocita+1
Testo: "Sei lento, l'acqua ti fa ribrezzo, e i pesci sono più svelti di te. Ne prendi giusto un paio dopo un'eternità: poca paga, niente acquario. Almeno hai le idee più chiare su come si fa."
Scena: pet fradicio e sconsolato con due pesciolini in mano

**Super successo** (condizione: Velocità 4+, o auto col talento Amante della Natura via tag natura) — +3 Velocità, +20 monete, Acquario di Casa (arredo camera, +1 Velocità +1 Felicità passivo), Felicità +10, Pescione Cantautore (giocattolo: sveglia il pet senza penalità)
Dati: cond= velocita>=4 ; reward= velocita+3, monete+20, arredo:Acquario di Casa, giocattolo:Pescione Cantautore, fel+10
Testo: "Ti muovi tra le pozze come un fulmine (o, se sei un tipo gentile, convinci i pesci a saltarti dritti in mano). Li salvi tutti, l'acquario ti riempie il portafoglio e ti regala l'esemplare più bello."
Scena: [DEDICATA] pet che afferra al volo tre pesci in un tuffo spettacolare, spruzzi ovunque

---

## Missione 73: Tiro alla Fune dei Cuccioli
Brief: Corda tesa, fango ovunque: al Parco Giochi il torneo di tiro alla fune tra cuccioli si gioca sul serio.
- Luogo: 📍 Parco Giochi
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: gara
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=gara ; stadio=baby

**Standard** — +1 Forza, Felicità +5
Dati: reward= forza+1, fel+5
Testo: "Il torneo di tiro alla fune dei cuccioli del parco: due squadre, una corda, tanto fango. La tua squadra vince due tiri su tre e tu torni a casa sporco e soddisfatto."
Scena: due squadre di cuccioli che tirano una corda, fango che schizza

**Fallimento** (condizione: Forza ≤1) — −10 Igiene, Biscotto (cibo, Carisma+1)
Dati: cond= forza<=1 ; reward= igiene-10, cibo:Biscotto, fel-5
Testo: "Al primo strattone voli in avanti e fai da tappeto alla squadra avversaria. Ti rialzi ricoperto di fango dalla testa ai piedi, ma un biscotto di consolazione non si nega a nessuno."
Scena: pet spiaccicato nel fango con la corda sopra, avversari che esultano

**Super successo** (condizione: Forza 3+) — +2 Forza, +10 monete, Corda della Vittoria (arredo salone, +1 Forza), Felicità +10
Dati: cond= forza>=3 ; reward= forza+2, monete+10, arredo:Corda della Vittoria, fel+10
Testo: "Tiri così forte che l'intera squadra avversaria attraversa la linea in blocco, come un trenino. Ti danno la corda in premio e il titolo di 'ancora' ufficiale del parco."
Scena: [DEDICATA] pet che tira da solo contro cinque cuccioli, tutti che volano verso di lui

## Missione 74: Il Trasloco dei Giocattoli
Brief: Il cucciolo del vicino trasloca in una stanza più grande, e servono braccia piccole per gli scatoloni.
- Luogo: 📍 Casa del Vicino
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza ; stadio=baby

**Standard** — +1 Forza, +8 monete, Felicità +5
Dati: reward= forza+1, monete+8, fel+5
Testo: "Il cucciolo del vicino trasloca in una cameretta più grande e servono braccia piccole per gli scatoloni di giocattoli. Tre ore di viavai e la paghetta è guadagnata."
Scena: pet che porta uno scatolone di giocattoli più grande di lui

**Fallimento** (condizione: Forza ≤1) — Fetta di torta (cibo, Carisma+1)
Dati: cond= forza<=1 ; reward= cibo:Fetta di torta, fel-5
Testo: "Il primo scatolone ti si rovescia addosso e passi il pomeriggio sepolto sotto una montagna di peluche. Il vicino, dispiaciuto, ti ripaga con una fetta di torta."
Scena: pet che sbuca da una montagna di peluche, un orsacchiotto in testa

**Super successo** (condizione: Forza 3+) — +2 Forza, +15 monete, Dinosauro Giocattolo (arredo camera, +1 Felicità), Felicità +10
Dati: cond= forza>=3 ; reward= forza+2, monete+15, arredo:Dinosauro Giocattolo, fel+10
Testo: "Sposti tutto in metà tempo, impilando gli scatoloni con precisione da magazziniere provetto. Il cucciolo del vicino, ammirato, ti regala il suo dinosauro preferito."
Scena: [DEDICATA] torre di scatoloni perfetta, pet col dinosauro giocattolo in braccio

## Missione 75: Acchiapparella Reale
Brief: Al Parco Giochi l'acchiapparella di oggi vale una posta speciale: il trono dello scivolo.
- Luogo: 📍 Parco Giochi
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: inseguimento
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sport ; stat=velocita ; tag=inseguimento ; stadio=baby

**Standard** — +1 Velocità, Felicità +5
Dati: reward= velocita+1, fel+5
Testo: "L'acchiapparella del parco oggi è una cosa seria: c'è in palio il trono dello scivolo. Corri, scarti, ti salvi due volte per un pelo e chiudi il pomeriggio senza mai fare 'la statua'."
Scena: pet che scarta un inseguitore con una finta, altri cuccioli che corrono

**Fallimento** (condizione: Velocità ≤1) — Biscotto (cibo, Carisma+1)
Dati: cond= velocita<=1 ; reward= cibo:Biscotto, fel-5
Testo: "Sei 'sotto' dopo tre secondi. E ci resti per due ore: ogni cucciolo del parco ti sfila davanti al rallentatore. Alla fine ti danno un biscotto per lo sforzo (e per pietà)."
Scena: pet col fiatone al centro del parco, cuccioli che gli girano intorno ridendo

**Super successo** (condizione: Velocità 3+) — +2 Velocità, +10 monete, Felicità +10
Dati: cond= velocita>=3 ; reward= velocita+2, monete+10, fel+10
Testo: "Imprendibile. Nessuno ti tocca per tutto il pomeriggio, e quando tocca a te acchiappare li prendi tutti in tre minuti netti. Il trono dello scivolo è tuo, sudditi inclusi."
Scena: [DEDICATA] pet seduto in cima allo scivolo come su un trono, cuccioli inchinati sotto

## Missione 76: Il Piccolo Postino
Brief: Il postino vero è a letto malato: il Condominio ha bisogno di zampette veloci, cinque piani, zero ascensore.
- Luogo: 📍 Condominio
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=consegne ; stat=velocita ; stadio=baby

**Standard** — +1 Velocità, +8 monete, Felicità +5
Dati: reward= velocita+1, monete+8, fel+5
Testo: "Il postino vero è malato e il condominio ha bisogno di zampette rapide: cinque piani, dodici buste, zero ascensore. Consegni tutto entro sera, con la lingua di fuori."
Scena: pet che sale le scale con un mazzetto di buste tra i denti

**Fallimento** (condizione: Velocità ≤1) — Fetta di torta (cibo, Carisma+1)
Dati: cond= velocita<=1 ; reward= cibo:Fetta di torta, fel-5
Testo: "Consegni la bolletta del 4B alla signora del 2A, l'invito del 2A al tizio del 5C, e in generale crei un piccolo caos postale. La signora del 2A, però, ti trova adorabile: torta per te."
Scena: pet confuso tra le buste sul pianerottolo, vicini che se le scambiano

**Super successo** (condizione: Velocità 3+) — +2 Velocità, +15 monete, Felicità +10
Dati: cond= velocita>=3 ; reward= velocita+2, monete+15, fel+10
Testo: "Tutte le buste giuste alle porte giuste in mezz'ora, ascensore battuto sul tempo a ogni piano. Il condominio fa una colletta: 'il postino piccolo è meglio di quello vero'."
Scena: [DEDICATA] pet che sfreccia su per le scale, buste che volano nelle mani dei vicini

## Missione 77: Il Puzzle del Museo
Brief: Il museo dei piccoli mette in palio un dinosauro di 500 pezzi: tre ore per completarlo, coda compresa.
- Luogo: 📍 Museo dei Piccoli
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=studio ; stat=int ; stadio=baby

**Standard** — +1 Intelligenza, Felicità +5
Dati: reward= int+1, fel+5
Testo: "Il museo dei piccoli sfida i cuccioli con un puzzle gigante da 500 pezzi: un dinosauro a grandezza (quasi) naturale. In tre ore piazzi la tua bella fetta di pezzi, coda compresa."
Scena: pet concentrato su un puzzle enorme steso sul pavimento del museo

**Fallimento** (condizione: Intelligenza ≤1) — Merendina Gattarcobaleno (cibo, Velocità+1 Felicità+5)
Dati: cond= int<=1 ; reward= cibo:Merendina Gattarcobaleno, fel-5
Testo: "Provi a incastrare lo stesso pezzo nello stesso buco per quaranta minuti (non è il suo buco). Poi provi ad assaggiarlo (non è commestibile). La guida ti sposta gentilmente al tavolo delle merendine, dove quella col gatto arcobaleno ti risolleva il morale."
Scena: pet che morde un pezzo di puzzle, guida del museo che accorre

**Super successo** (condizione: Intelligenza 3+) — +2 Intelligenza, Puzzle Incorniciato (arredo camera, +1 Intelligenza), Felicità +10
Dati: cond= int>=3 ; reward= int+2, arredo:Puzzle Incorniciato, fel+10
Testo: "Piazzi i pezzi a colpo d'occhio, senza nemmeno guardare la scatola, e chiudi il dinosauro con due ore d'anticipo. Il museo ti regala la versione da camera, già incorniciata."
Scena: [DEDICATA] puzzle-dinosauro completo, pet che piazza l'ultimo pezzo tra gli applausi

## Missione 78: L'Orto sul Balcone
Brief: Tre vasi, semi misteriosi e le istruzioni della nonna: il balcone di casa diventa un piccolo orto da far crescere.
- Luogo: 📍 Balcone di Casa
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Intelligenza
- Tag: natura
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=int ; tag=natura ; stadio=baby

**Standard** — +1 Intelligenza, Insalatona (cibo, Intelligenza+1), Felicità +5
Dati: reward= int+1, cibo:Insalatona, fel+5
Testo: "Tre vasi, semi misteriosi e le istruzioni della nonna: nasce l'orto del balcone. Annaffi, aspetti, riannaffi, e le prime foglioline ti ripagano con un'insalata tutta tua."
Scena: pet che annaffia tre vasi con un annaffiatoio più grande di lui

**Fallimento** (condizione: Intelligenza ≤1) — Insalatona (cibo, Intelligenza+1)
Dati: cond= int<=1 ; reward= cibo:Insalatona, fel-5
Testo: "Annaffi con troppo entusiasmo: due vasi su tre diventano acquitrini e il balcone una zona umida protetta. La piantina superstite, per miracolo, ti regala comunque un'insalatina."
Scena: pet in mezzo a vasi allagati, un'unica piantina eroica che sbuca

**Super successo** (condizione: Intelligenza 3+, o auto col talento Amante della Natura via tag natura) — +2 Intelligenza, Piantina di Fragole (arredo cucina, +1 Felicità), Insalatona, Felicità +10
Dati: cond= int>=3 ; reward= int+2, arredo:Piantina di Fragole, cibo:Insalatona, fel+10
Testo: "Dosi acqua e sole come un piccolo agronomo e l'orto esplode di vita: insalata, profumo di basilico e — sorpresa — una piantina di fragole che nessuno aveva seminato. Il balcone più bello del palazzo."
Scena: [DEDICATA] balcone rigoglioso, pet che raccoglie una fragola rossa perfetta

## Missione 79: Il Teatrino dei Burattini
Brief: Il teatrino del cortile cerca una voce nuova per il drago cattivo: palco pronto, cuccioli già in prima fila.
- Luogo: 📍 Cortile del Palazzo
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; stadio=baby

**Standard** — +1 Carisma, +5 monete, Felicità +5
Dati: reward= carisma+1, monete+5, fel+5
Testo: "Lo spettacolo dei burattini del cortile cerca una voce nuova per il drago cattivo. Il tuo ruggito fa ridere più che spaventare, ma il pubblico di cuccioli applaude e lascia monetine."
Scena: pet dietro un teatrino di cartone che agita un burattino-drago

**Fallimento** (condizione: Carisma ≤1) — Merendina Gattarcobaleno (cibo, Velocità+1 Felicità+5)
Dati: cond= carisma<=1 ; reward= cibo:Merendina Gattarcobaleno, fel-5
Testo: "Ti cali così tanto nella parte che il TUO stesso burattino-drago ti fa paura: molli tutto a metà scena e ti nascondi dietro il teatrino. I cuccioli pensano faccia parte dello spettacolo. Quasi. Il burattinaio ti consola con una merendina: quella del gatto che vola lasciando la scia arcobaleno."
Scena: pet nascosto dietro il teatrino, burattino-drago abbandonato sul palco

**Super successo** (condizione: Carisma 3+) — +2 Carisma, +12 monete, Burattino Drago (arredo camera, +1 Carisma), Felicità +10
Dati: cond= carisma>=3 ; reward= carisma+2, monete+12, arredo:Burattino Drago, fel+10
Testo: "Il tuo drago ha voce, carattere e persino un tormentone che i cuccioli ripetono per giorni. A fine spettacolo il burattinaio ti regala il drago: 'ormai è più tuo che mio'."
Scena: [DEDICATA] pet che fa l'inchino col burattino-drago, cortile che applaude in piedi

## Missione 80: Il Banchetto della Limonata
Brief: Tavolino, brocca e un cartello scritto storto: il tuo primo banchetto di limonata apre sul marciapiede di casa.
- Luogo: 📍 Marciapiede di Casa
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Carisma
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=carisma ; stadio=baby

**Standard** — +1 Carisma, +10 monete, Felicità +5
Dati: reward= carisma+1, monete+10, fel+5
Testo: "Un tavolino, una brocca, un cartello scritto storto: il tuo primo banchetto della limonata. I passanti si fermano più per la tenerezza che per la sete, ma le monetine sono monetine."
Scena: pet dietro un banchetto con brocca e cartello 'LIMONATA 1 MONETA'

**Fallimento** (condizione: Carisma ≤1) — +3 monete
Dati: cond= carisma<=1 ; reward= monete+3, fel-5
Testo: "Fa caldo, la limonata è lì, e tu sei debole: te la bevi quasi tutta da solo. L'unico bicchiere venduto va a un signore che voleva soprattutto ridere. Bilancio: 3 monete e una pancia piena di limonata."
Scena: pet con la brocca vuota rovesciata sulla testa, cartello che pende storto

**Super successo** (condizione: Carisma 4+) — +2 Carisma, +20 monete, Spremiagrumi d'Oro (arredo cucina, +1 Carisma), Felicità +10
Dati: cond= carisma>=4 ; reward= carisma+2, monete+20, arredo:Spremiagrumi d'Oro, fel+10
Testo: "Sorriso, chiacchiere e un pizzico di teatro: si forma la FILA. Esaurisci la brocca tre volte e il fruttivendolo, che ha visto tutto, ti sponsorizza con uno spremiagrumi dorato: 'investo nei talenti'."
Scena: [DEDICATA] fila di clienti al banchetto, pet che versa limonata con gesto da barman

---

# TEEN — missioni sbloccate dall'evoluzione (tier più alto: soglie 10+/13+, reward più grosse, modifiche permanenti e vestiti indossabili)

## Missione 17: Pimp My Pet — Clinica di Modding [intro teen, fuori rosa, 1 volta all'evoluzione]
Brief: Diventato teen, ti aspetta la Clinica di Modding: un aggiornamento a scelta, per sempre. Decidi con calma.
- Luogo: 📍 Clinica di Modding (robot → officina del meccanico · alieno → clinica di muta; stesso edificio sulla mappa, reskin per razza)
- Razza: entrambe (opzioni diverse per razza)
- Tipo: modifica PERMANENTE, scelta del giocatore (niente fallimento/super)
- Costo: 10 monete
- Dati: teenIntro=1 ; stadio=teen ; costo=10 ; scelta=1

Il giocatore sceglie UNA modifica permanente: +2 permanente alla stat scelta + nuovo sprite (permanente, per sempre).

| Stat | Robot (impianto) | Alieno (mutazione) | Bonus |
|---|---|---|---|
| Forza | Servo-braccia idrauliche | Chele / arto extra | +2 Forza permanente |
| Velocità | Turbina dorsale | Pinne / zampe da corsa | +2 Velocità permanente |
| Intelligenza | Antenna neurale | Terzo occhio | +2 Intelligenza permanente |
| Carisma | Insegna al neon | Bioluminescenza / cresta | +2 Carisma permanente |

Dati: cond= robot & scelta:forza ; reward= forza+2, sprite:servobraccia
Dati: cond= robot & scelta:velocita ; reward= velocita+2, sprite:turbina
Dati: cond= robot & scelta:int ; reward= int+2, sprite:antenna
Dati: cond= robot & scelta:carisma ; reward= carisma+2, sprite:neon
Dati: cond= alieno & scelta:forza ; reward= forza+2, sprite:chele
Dati: cond= alieno & scelta:velocita ; reward= velocita+2, sprite:pinne
Dati: cond= alieno & scelta:int ; reward= int+2, sprite:terzocchio
Dati: cond= alieno & scelta:carisma ; reward= carisma+2, sprite:biolum
Testo: "Diventare teenager ha i suoi vantaggi: qualcuno — un meccanico dallo sguardo un po' troppo entusiasta, o un tecnico della clinica di muta — ti fa cenno di entrare. Per dieci monete puoi uscire da qui... aggiornato. Scegli con calma: quello che scegli, te lo porti per sempre."
Scena: [DEDICATA] pet sul lettino/rialzo dell'officina-clinica, il tecnico che mostra le opzioni; servono 8 varianti sprite d'esito (una per impianto/mutazione, permanente sul pet)

## Missione 18: Il Colpo del Secolo
Brief: Il Panino Più Grande del Mondo dorme nel caveau del centro, sorvegliato come un tesoro: il colpo del secolo comincia adesso.
- Luogo: 📍 Caveau del Panino (Centro Città)
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: qualsiasi (conta la più alta)
- Tag: rapina
- Durata: 1h30
- Costo: gratis
- Nota: la "boss" dell'infornata; modello a SOGLIA teen — qui si può FALLIRE davvero (serve una stat a 10+ per riuscire)
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=qualsiasi ; tag=rapina ; stadio=teen

**Standard** (riesci nel colpo, con almeno una stat a 10+) — +25 monete, Panino Più Grande del Mondo (arredo cucina, +2 Felicità passivo), Scorta di Panini (cibo multi-porzione: 5 porzioni, ogni porzione +2 a una stat RPG casuale), Felicità +5
Dati: reward= monete+25, arredo:Panino Più Grande del Mondo, cibo:Scorta di Panini, fel+5
Testo: "Il Panino Più Grande del Mondo è in mostra al caveau del centro, sorvegliato come un tesoro. Ti intrufoli, aggiri gli allarmi a modo tuo e lo porti via sotto gli occhi di tutti. Cena assicurata per un mese."
Scena: pet che sguscia via da un caveau con un panino gigantesco in spalla

**Fallimento** (condizione: nessuna stat a 10+) — −10 monete (multa), Fetta di Panino Gigante (cibo, +2 a una stat casuale, 1 porzione)
Dati: cond= statMax<10 ; reward= monete-10, cibo:Fetta di Panino Gigante
Testo: "Il piano era perfetto sulla carta. Nella pratica, scatta l'allarme al primo passo e ti ritrovi a spiegare tutto a due guardie. Paghi la multa — ma loro, più divertite che arrabbiate, ti lasciano andare con un pezzo di panino 'per la fatica'."
Scena: pet ammanettato bonariamente da due guardie, una fetta di panino in mano

**Super successo** (condizione: qualsiasi stat a 13+) — reward normali + Completo da Chef (indossabile: mentre indossato, ogni primo pasto di categoria del giorno dà +1 stat extra) + +40 monete, Felicità +10
Dati: priorita=2 ; cond= statMax>=13 ; reward= monete+40, arredo:Panino Più Grande del Mondo, cibo:Scorta di Panini, indossabile:Completo da Chef, fel+10
Testo: "Non solo porti via il panino: lo fai con uno stile tale che nel caveau trovi pure il completo da chef del proprietario, e lo intaschi. Nessuno capirà mai com'è andata."
Scena: [DEDICATA] pet che esce dal caveau col panino gigante E indossando un completo da chef, occhiolino

**Super successo** (condizione: Maleducato + talento Boss di Quartiere + qualsiasi stat a 13+) — tutto il super + perk GTB "Gran Theft Burger" (tag rapina: niente fallimento + sempre super successo nelle missioni tag rapina), Felicità +10
Dati: priorita=1 ; cond= maleducato & talento:bossdiquartiere & statMax>=13 ; reward= monete+40, arredo:Panino Più Grande del Mondo, cibo:Scorta di Panini, indossabile:Completo da Chef, perk:gtb, fel+10
Testo: "Questo non è un furto, è ARTE. Entri, esci, e ti lasci dietro solo leggenda e briciole. Il quartiere ha un nuovo re del crimine gastronomico."
Scena: [DEDICATA] pet incoronato "re del crimine" dagli altri teppisti, panino gigante come trofeo

Priorità M18: il super Maleducato+Boss di Quartiere (più specifico) prima del super generico. Il super batte sempre il fallimento. (Nota: "super" e "grande successo" sono lo stesso tier.)

## Missione 19: Talent Show Intergalattico
Brief: Sali sul palco del Talent Show Intergalattico, davanti a una giuria di alieni e robot che ha già visto di tutto.
- Luogo: 📍 Palco del Talent Show Intergalattico
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: gara
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=gara ; stadio=teen

**Standard** (buona performance) — +2 Carisma, Parrucchino di Elvis (indossabile, +2 Carisma mentre indossato), +15 monete, Felicità +5
Dati: reward= carisma+2, indossabile:Parrucchino di Elvis, monete+15, fel+5
Testo: "Sali sul palco davanti a una giuria di alieni e robot con l'aria di chi ha già visto tutto. Fai il tuo numero, strappi applausi sinceri, e ti aggiudichi un premio: un parrucchino alla Elvis che, va detto, ti dona un sacco."
Scena: pet sul palco sotto i riflettori, giuria che applaude, parrucchino in mano

**Fallimento** (condizione: Maleducato, oppure Carisma ≤7) — Torta intera (cibo, Carisma+3)
Dati: cond= maleducato | carisma<=7 ; reward= cibo:Torta intera
Testo: "Il palco non fa per te oggi: steccatura qui, gaffe là, e la giuria ti guarda come si guarda un incidente. Arrivi ultimo, ma qualcuno tra il pubblico, impietosito, ti manda dietro le quinte una torta intera."
Scena: pet mortificato sul palco, ortaggi virtuali che volano, una torta di consolazione

**Super successo** (condizione: Carisma 12+, oppure Sportivo + talento Spirito Agonistico) — reward base + +30 monete + Disco d'Oro (arredo, +2 Carisma passivo), Felicità +10
Dati: cond= carisma>=12 | (sportivo & talento:spiritoagonistico) ; reward= carisma+2, indossabile:Parrucchino di Elvis, monete+30, arredo:Disco d'Oro, fel+10
Testo: "Non è una performance, è un FENOMENO. La giuria si alza in piedi, il pubblico impazzisce, e ti consegnano un disco d'oro seduta stante. Nasce una stella."
Scena: [DEDICATA] pet trionfante col parrucchino e un disco d'oro sopra la testa, pioggia di stelle filanti

## Missione 20: Difesa dal Kaiju
Brief: Un bestione alto come un palazzo semina il panico in centro: il quartiere cerca un eroe, e oggi tocca a te.
- Luogo: 📍 Quartiere sotto Attacco
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: mostro
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=mostro ; stadio=teen

Le 5 armi epiche (nomi generici, no marchi; drop casuale nello standard, set completo nel super): Spadone, Martellone, Doppie Lame, Arco Pesante, Alabarda — arredo, +2 Forza ciascuna.

**Standard** (sconfiggi il mostro) — +3 Forza, 1 arma casuale (delle 5, +2 Forza), Felicità +5
Dati: reward= forza+3, armaCasualeKaiju, fel+5
Testo: "Un bestione alto come un palazzo semina il panico in centro. Ti ci butti, schivi zampate grosse come auto e lo respingi a suon di colpi. Tra le macerie del suo passaggio recuperi un'arma coi fiocchi."
Scena: pet minuscolo in posa di sfida davanti a un kaiju gigante, un'arma epica in pugno

**Fallimento** (condizione: Forza ≤7) — Bistecca (cibo, Forza+2)
Dati: cond= forza<=7 ; reward= cibo:Bistecca
Testo: "Una cosa è dirlo, un'altra è avere davanti DAVVERO un mostro di venti metri. Le gambe decidono per te e scappi. I cittadini, comunque grati per il tentativo, ti rifocillano con una bistecca coi controfiocchi."
Scena: pet che scappa a gambe levate dall'ombra enorme del kaiju, cittadini che gli offrono cibo

**Super successo** (condizione: Forza 13+, oppure perk Cacciatore di Mostri) — +4 Forza, tutte e 5 le armi, perk Cacciatore di Mostri (tag mostro: niente fallimento + sempre super successo nelle missioni tag mostro), Felicità +10
Dati: cond= forza>=13 ; reward= forza+4, tutteArmiKaiju, perk:cacciatoremostri, fel+10
Testo: "Lo affronti a viso aperto e lo metti al tappeto in un duello che entrerà nelle leggende del quartiere. Ti porti via l'intero arsenale e il titolo di Cacciatore di Mostri."
Scena: [DEDICATA] pet trionfante sul kaiju abbattuto, tutte e 5 le armi addosso, folla in delirio

## Missione 21: Escape Room del Dottor Enigma
Brief: Rinchiuso in una stanza di lucchetti e indizi criptici, col timer che ticchetta: il Dottor Enigma ti osserva sogghignando dallo schermo.
- Luogo: 📍 Escape Room del Dottor Enigma
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: invenzione
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; tag=invenzione ; stadio=teen

**Standard** — +2 Int, +15 monete, Camice del Dottore (indossabile, +1 Int), Felicità +5
Dati: reward= int+2, monete+15, indossabile:Camice del Dottore, fel+5
Testo: "Ti ritrovi chiuso in una stanza piena di lucchetti, indizi criptici e un timer che ticchetta minaccioso. Il Dottor Enigma ti osserva da uno schermo, sogghignando. Risolvi enigma dopo enigma e apri la porta col cronometro ancora acceso — ne esci col cervello in fiamme e il camice che il Dottore, sportivo, ti lascia come premio."
Scena: pet chino su un lucchetto a combinazione, indizi appesi, timer rosso sullo sfondo

**Fallimento** (condizione: Intelligenza ≤7) — Zuppa di verdure (cibo, Int+2)
Dati: cond= int<=7 ; reward= cibo:Zuppa di verdure
Testo: "Gli enigmi ti guardano, tu guardi loro, e non succede niente per un'ora buona. Il Dottor Enigma, quasi impietosito, apre lui la porta scuotendo la testa e ti rifila una zuppa 'per il cervello, ne hai bisogno'."
Scena: pet perplesso davanti a un muro di enigmi, il Dottore che apre la porta scuotendo la testa

**Super successo** (condizione: Intelligenza 13+, oppure Nerd + talento Mente Analitica) — +3 Int, +15 monete, Camice del Dottore (indossabile), Specchio del Dottor Enigma (arredo bagno, +1 Int), Felicità +10
Dati: cond= int>=13 | (nerd & talento:menteanalitica) ; reward= int+3, monete+15, indossabile:Camice del Dottore, arredo:Specchio del Dottor Enigma, fel+10
Testo: "Non risolvi la stanza — la SMONTI. Enigmi divorati in metà tempo, e mentre il Dottor Enigma balbetta incredulo tu sei già fuori. Ti lascia perfino il suo specchio col suo faccione, come trofeo della sua sconfitta."
Scena: [DEDICATA] pet che esce dalla porta a braccia alzate col camice, specchio-faccione sotto il braccio, Dottore sbigottito

## Missione 22: Avvocato per un Giorno
Brief: In tribunale un robot rischia la rottamazione per furto di Wi-Fi: tocca a te fargli da avvocato davanti a un giudice-robot.
- Luogo: 📍 Tribunale di Città
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Intelligenza + Carisma (doppia)
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sociale ; stat=int,carisma ; stadio=teen

**Standard** — +1 Int, +1 Carisma, Toga da Avvocato (indossabile, +2 Carisma +1 Int), Felicità +5
Dati: reward= int+1, carisma+1, indossabile:Toga da Avvocato, fel+5
Testo: "In tribunale difendi un robot accusato di aver risucchiato il Wi-Fi di tutto il condominio. Tra un cavillo e una battuta ben piazzata, strappi un mezzo verdetto e la toga d'ordinanza. Non un trionfo, ma il tuo cliente non finisce alla rottamazione."
Scena: pet in toga davanti a un giudice-robot, cliente-robottino al banco

**Fallimento** (condizione: Intelligenza ≤7 E Carisma ≤7) — Insalatona (cibo, Int+1), Biscotto (cibo, Carisma+1)
Dati: cond= int<=7 & carisma<=7 ; reward= cibo:Insalatona, cibo:Biscotto
Testo: "La tua arringa parte male e finisce peggio: ti impappini, il giudice sbadiglia, il cliente si copre gli occhi metallici. Assolto per pietà, non per merito. Il giudice ti manda comunque a mangiare qualcosa 'prima del prossimo disastro'."
Scena: pet impappinato, giudice che sbadiglia, cliente che si copre gli occhi

**Super successo** (condizione: Intelligenza 9+ E Carisma 9+, oppure Maleducato + talento Faccia di Bronzo con Carisma o Int ≥5) — +2 Int, +2 Carisma, Toga da Avvocato (indossabile), Martelletto da Giudice (arredo salone, +2 Int +1 Carisma), Felicità +10
Dati: cond= (int>=9 & carisma>=9) | (maleducato & talento:facciadibronzo & (carisma>=5 | int>=5)) ; reward= int+2, carisma+2, indossabile:Toga da Avvocato, arredo:Martelletto da Giudice, fel+10
Testo: "Un'arringa da manuale: cavilli, colpi di scena, un teste che crolla in lacrime d'olio. La giuria è in delirio, il giudice ti regala il suo martelletto, e il robot esce a testa alta con l'intero quartiere di nuovo online."
Scena: [DEDICATA] pet trionfante in toga col martelletto in mano, giuria in piedi, cliente libero

## Missione 23: Il Falsario
Brief: Il Museo Civico ti chiama per un verdetto delicato: quel quadro sotto le luci UV è vero oro o solo vernice fresca?
- Luogo: 📍 Museo Civico
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; stadio=teen

**Standard** — +2 Int, +15 monete, Dipinto Artistico (arredo salone, +1 Int +1 Felicità), Felicità +5
Dati: reward= int+2, monete+15, arredo:Dipinto Artistico, fel+5
Testo: "Il museo ti chiama per un parere: quel quadro è autentico o un patacca? Tra lenti, luci UV e tanta pazienza, dai il tuo verdetto — che si rivela giusto. Ti pagano bene e ti regalano una tela d'autore per il disturbo."
Scena: pet con lente e luce UV che esamina un quadro, cartello "MUSEO"

**Fallimento** (condizione: Intelligenza ≤7) — Zuppa di verdure (cibo, Int+2), Dipinto Falso (arredo salone, +1 Velocità +1 Felicità)
Dati: cond= int<=7 ; reward= cibo:Zuppa di verdure, arredo:Dipinto Falso
Testo: "Fissi il quadro per ore e più lo guardi meno capisci. Alla fine tiri a indovinare... e sbagli. Il museo ti ringrazia a denti stretti e ti liquida con un pasto e — ironia — proprio il falso che non hai saputo riconoscere."
Scena: pet grattacapo davanti a due quadri identici, un curatore contrariato

**Super successo** (condizione: Maleducato + talento Cleptomane) — +3 Int, +30 monete, Dipinto Artistico, Lente d'Ingrandimento (arredo salone, +2 Int), Dipinto Rubato (arredo salone, +2 Int, alto valore di rivendita), Felicità +10
Dati: priorita=1 ; cond= maleducato & talento:cleptomane ; reward= int+3, monete+30, arredo:Dipinto Artistico, arredo:Lente d'Ingrandimento, arredo:Dipinto Rubato, fel+10
Testo: "Smascheri il falso con classe... e già che sei lì, nel trambusto, un secondo quadro 'si stacca dal muro e ti segue a casa'. Nessuno se ne accorge. Doppio bottino."
Scena: [DEDICATA] pet che si allontana fischiettando con due quadri sottobraccio, sala del museo dietro

**Super successo** (condizione: Intelligenza 13+) — +3 Int, +30 monete, Dipinto Artistico, Lente d'Ingrandimento (arredo salone, +2 Int), Felicità +10
Dati: priorita=2 ; cond= int>=13 ; reward= int+3, monete+30, arredo:Dipinto Artistico, arredo:Lente d'Ingrandimento, fel+10
Testo: "Non solo smascheri il falso: ricostruisci CHI l'ha dipinto, QUANDO e PERCHÉ, davanti a un direttore a bocca aperta. Ti ricoprono di monete, ti regalano la tela vera e la tua lente d'ingrandimento porta-fortuna."
Scena: [DEDICATA] pet che indica trionfante un quadro smascherato, direttore a bocca aperta, monete che volano

## Missione 24: Corsa Clandestina nel Museo
Brief: A notte fonda il Museo Civico si svuota di guardie e si riempie di corridori clandestini pronti a sfrecciare tra le statue.
- Luogo: 📍 Museo Civico (di notte)
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara, inseguimento
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sport ; stat=velocita ; tag=gara,inseguimento ; stadio=teen

**Standard** — +2 Velocità, Scarpe da Corsa (arredo, +1 Velocità), Felicità +5
Dati: reward= velocita+2, arredo:Scarpe da Corsa, fel+5
Testo: "Quando cala la notte il museo cambia pelle: luci spente, coni segnaletici tra le colonne e un manipolo di corridori clandestini pronti al via. Parte il conto alla rovescia sussurrato e sei subito in mezzo alla mischia, a sfrecciare tra statue e quadri secolari mentre la guardia di turno russa beata nel gabbiotto. Non sei il fulmine della serata, ma tieni un ritmo pulito e chiudi a metà classifica senza rovesciare nemmeno un vaso etrusco. Sul traguardo raccogli un paio di scarpe da corsa che qualcuno ha perso nella fuga: adesso sono tue."
Scena: pet che corre tra le teche del museo al buio, altri corridori sfocati

**Fallimento** (condizione: Velocità ≤7, oppure Maleducato + talento Bad Loser) — Sushi (cibo, Velocità+2)
Dati: cond= velocita<=7 | (maleducato & talento:badloser) ; reward= cibo:Sushi
Testo: "Parti carico ma le gambe non rispondono — o forse è che sgambetti il primo che ti supera e vieni squalificato all'istante. Gli altri corridori, tra il divertito e il solidale, ti offrono un sushi."
Scena: pet col fiatone o che litiga con un corridore, gli altri che sfrecciano via

**Super successo** (condizione: Gentile + talento Cuore Magnetico) — +3 Velocità, Scarpe da Corsa, Coppa del Vincitore (arredo, +2 Velocità +1 Carisma), +30 monete, Felicità +10
Dati: priorita=1 ; cond= gentile & talento:cuoremagnetico ; reward= velocita+3, arredo:Scarpe da Corsa, arredo:Coppa del Vincitore, monete+30, fel+10
Testo: "Corri che è un piacere, ma la cosa più assurda è che la guardia notturna, invece di fermarti, resta a bocca aperta a guardarti — e a fine corsa ti allunga pure una mancia 'per lo spettacolo'."
Scena: [DEDICATA] pet che taglia il traguardo mentre la guardia ammaliata applaude e gli porge monete

**Super successo** (condizione: Velocità 13+) — +3 Velocità, Scarpe da Corsa, Coppa del Vincitore (arredo, +2 Velocità +1 Carisma), Felicità +10
Dati: priorita=2 ; cond= velocita>=13 ; reward= velocita+3, arredo:Scarpe da Corsa, arredo:Coppa del Vincitore, fel+10
Testo: "A un certo punto smetti di correre e cominci a volare basso: sfrecci tra le sale sfiorando le teche senza toccarle, anticipi ogni curva, superi gli altri come fossero fermi. Nessuno ti vede partire, nessuno ti vede arrivare — tagli il traguardo clandestino con un vantaggio imbarazzante, primo assoluto e senza un graffio alle opere d'arte. Ti infili in tasca la coppa (rigorosamente non ufficiale) del vincitore e sparisci nel buio dei corridoi prima che sorga il sole, o che qualcuno pensi di chiederti chi diavolo eri."
Scena: [DEDICATA] pet primo al traguardo con la coppa, sale del museo sfrecciate alle spalle

## Missione 25: FPS Tournament in Sala Giochi
Brief: La sala giochi 'Bit & Byte' si trasforma in arena eSport: cuffie a palla, chat vocale rovente, torneo sparatutto in corso.
- Luogo: 📍 Sala Giochi "Bit & Byte"
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Velocità
- Tag: gara
- Durata: 1h
- Costo: 3 monete
- Dati: durata=1h ; costo=3 ; categoria=videogioco ; stat=velocita ; tag=gara ; stadio=teen

**Standard** — +2 Velocità, Console (arredo camera, +2 Velocità +1 Felicità), Felicità +5, Visorone della Realtà Finta (indossabile, Int+3 Vel−2)
Dati: reward= velocita+2, arredo:Console, indossabile:Visorone della Realtà Finta, fel+5
Testo: "La sala giochi si trasforma in arena eSport: schermi giganti, cuffie sparate a volume assurdo e una chat vocale che alterna strategie serissime e insulti affettuosi. Ti butti nel torneo di sparatutto e te la giochi alla pari, tra headshot fortunati e qualche morte imbarazzante, chiudendo appena fuori dal podio. Non è la finale dei tuoi sogni, ma esci con i pollici indolenziti, l'adrenalina a mille e una console tutta tua da montare in cameretta."
Scena: pet con cuffie e joystick davanti a uno schermo FPS, altri giocatori ai lati

**Fallimento** (condizione: Maleducato + talento Bad Loser) — −5 monete (danni), Sushi (cibo, Velocità+2)
Dati: priorita=1 ; cond= maleducato & talento:badloser ; reward= monete-5, cibo:Sushi
Testo: "Perdi il primo scontro a fuoco e, invece di stringere la mano, spacchi il joystick contro il cabinato. Il gestore ti presenta il conto dei danni. Ti resta giusto un sushi per consolarti."
Scena: pet infuriato che spacca un joystick, il gestore che indica il cartello dei prezzi

**Fallimento** (condizione: Velocità ≤7) — Sushi (cibo, Velocità+2)
Dati: priorita=2 ; cond= velocita<=7 ; reward= cibo:Sushi
Testo: "I tuoi riflessi oggi sono in vacanza: eliminato al primo round, senza gloria. Un avversario gentile ti offre un sushi 'per la prossima'."
Scena: pet abbattuto davanti a uno schermo "ELIMINATO", avversario che gli passa del cibo

**Super successo** (condizione: Velocità 13+, oppure Nerd) — +3 Velocità, Console, perk Weapon Wielder (sblocca la capacità di equipaggiare armi nelle missioni), Felicità +10
Dati: cond= velocita>=13 | nerd ; reward= velocita+3, arredo:Console, perk:weaponwielder, fel+10
Testo: "A un certo punto qualcosa scatta: non stai più giocando, stai DOMINANDO. Headshot dietro headshot, mira chirurgica, riflessi disumani — il tabellone diventa l'elenco delle tue vittime e la chat vocale, di solito assordante, cala in un silenzio riverente. Alzi la console pro sopra la testa come un trofeo, e da quel giorno gira voce che tu, le armi, le sai maneggiare sul serio — anche fuori dallo schermo."
Scena: [DEDICATA] pet trionfante con la console pro sopra la testa, tabellone "VICTORY", folla in delirio

## Missione 26: Acchiappa il Piccione Cyborg
Brief: Un piccione cyborg ossessionato dal luccichio semina il quartiere di furti lampo: qualcuno deve dargli la caccia sui tetti.
- Luogo: 📍 Tetti del Quartiere
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: inseguimento
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=inseguimento,companion ; stadio=teen

**Standard** — +2 Velocità, Gabbia per Uccelli (arredo mettibile ovunque, +1 Velocità +1 Felicità), Felicità +5
Dati: reward= velocita+2, arredo:Gabbia per Uccelli, fel+5
Testo: "Un piccione cyborg con la fissa per gli oggetti lucenti terrorizza il vicinato: sparisce con chiavi, monetine e un paio di occhiali da sole prima ancora che tu dica 'ehi!'. Parti all'inseguimento tra cortili, grondaie e stendini, tra tuffi e scivolate che i vicini commentano dalle finestre come fosse una partita. Dopo mezz'ora di acrobazie lo blocchi in un angolo, e come premio ti tieni pure la gabbietta che qualcuno ha lasciato lì apposta."
Scena: pet che insegue un piccione robotico tra i panni stesi e le grondaie

**Fallimento** (condizione: Nerd + talento Topo di Biblioteca) — +1 Int, Pesce alla griglia (cibo, Velocità+1)
Dati: priorita=1 ; cond= nerd & talento:topodibiblioteca ; reward= int+1, cibo:Pesce alla griglia
Testo: "A metà inseguimento ti fermi: 'ma perché sto correndo dietro a un piccione?'. Torni a casa, apri un libro sull'ornitologia robotica e impari qualcosa. Il piccione, intanto, ringrazia."
Scena: pet seduto che legge un libro mentre il piccione gli fa la linguaccia dalla finestra

**Fallimento** (condizione: Velocità ≤7) — Sushi (cibo, Velocità+2)
Dati: priorita=2 ; cond= velocita<=7 ; reward= cibo:Sushi
Testo: "Quel bestione piumato è più svelto di quanto sembri: ti semina in tre svolte. I vicini, delusi ma comprensivi, ti offrono qualcosa da mangiare."
Scena: pet col fiatone su un tetto, il piccione ormai lontano nel cielo

**Super successo** (condizione: Velocità 13+, oppure Gentile + talento Amante della Natura) — +3 Velocità, Gabbia per Uccelli, Piccione Cyborg (arredo companion, +2 Velocità fisso), Felicità +10
Dati: cond= velocita>=13 | (gentile & talento:amantedellanatura) ; reward= velocita+3, arredo:Gabbia per Uccelli, arredo:Piccione Cyborg, fel+10
Testo: "Lo insegui saltando di tetto in tetto con un'agilità da capogiro, anticipando ogni sua virata come se gli leggessi nel processore (o, se sei un tipo gentile, ti limiti a parlargli con dolcezza finché non decide da solo di costituirsi). Alla fine quel bulletto piumato ti guarda, valuta le sue opzioni, e sceglie te: da quel momento ti svolazza accanto ovunque. Tienilo nella gabbia in bella vista — un companion che, a quanto pare, ti trasmette pure un po' della sua velocità."
Scena: [DEDICATA] pet che stringe felice il piccione cyborg, entrambi su un tetto al tramonto

## Missione 27: Wrestling Show
Brief: Sali sul ring del Palasport con una maschera e un nome d'arte urlato dallo speaker, contro bestioni imbottiti pronti a tutto.
- Luogo: 📍 Palasport del Wrestling
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza ; stadio=teen

**Standard** — +2 Forza, −8 Salute (Ferite +8), Maschera da Wrestler (indossabile, +2 Forza +1 Carisma), Felicità +5
Dati: reward= forza+2, ferite+8, indossabile:Maschera da Wrestler, fel+5
Testo: "Sali sul ring del Palasport con una maschera e un nome d'arte urlato dallo speaker. Contro bestioni imbottiti incassi e restituisci suplex a raffica: il pubblico impazzisce e vinci il tuo primo incontro (e qualche livido)."
Scena: pet mascherato che esegue una mossa da wrestling su un avversario gigante, folla sugli spalti

**Fallimento** (condizione: Gentile + talento Coccolone) — Ferite +15, Bistecca (cibo, Forza+2)
Dati: priorita=1 ; cond= gentile & talento:coccolone ; reward= ferite+15, cibo:Bistecca
Testo: "Provi a coccolare gli avversari invece di combatterli. Loro non capiscono, tu incassi il doppio, e finisci la serata più a pezzi del previsto. Ma con una bella bistecca di consolazione."
Scena: pet malconcio che tende le braccia per un abbraccio verso un wrestler perplesso

**Fallimento** (condizione: Forza ≤7) — Ferite +15, Bistecca (cibo, Forza+2)
Dati: priorita=2 ; cond= forza<=7 ; reward= ferite+15, cibo:Bistecca
Testo: "Il bestione di turno ti usa come tappetino: schienato in dieci secondi, esci dal ring più ammaccato che glorioso. A bordo ring qualcuno ti passa una bistecca — 'da mettere sull'occhio o da mangiare, decidi tu'."
Scena: pet steso al tappeto con l'arbitro che conta, avversario esultante

**Super successo** (condizione: Forza 13+, oppure Nerd + talento Cervellone) — +3 Forza, −5 Salute (Ferite +5), Maschera da Wrestler, Poster del Campione (arredo camera, +1 Forza +1 Carisma), Felicità +10
Dati: cond= forza>=13 | (nerd & talento:cervellone) ; reward= forza+3, ferite+5, indossabile:Maschera da Wrestler, arredo:Poster del Campione, fel+10
Testo: "Non è un match, è uno SHOW: mosse spettacolari, un urlo di battaglia (con la parola che ti hanno insegnato) che gela l'arena, e l'avversario al tappeto in un lampo. Campione, con maschera e poster celebrativo."
Scena: [DEDICATA] pet mascherato in posa di trionfo sul ring, cintura al fianco, folla in delirio

## Missione 28: L'Invasione degli Scarti
Brief: Un'orda di mostriciattoli fatti di lattine e cavi invade la Discarica di Città e il quartiere intorno: qualcuno deve fermarli.
- Luogo: 📍 Discarica di Città
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: mostro, studio
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=mostro,studio ; stadio=teen

**Standard** — +2 Forza, −12 Salute (Ferite +12), +15 monete, Pupazzo Mostriciattolo (arredo camera, +1 Forza +1 Int), Felicità +5
Dati: reward= forza+2, ferite+12, monete+15, arredo:Pupazzo Mostriciattolo, fel+5
Testo: "Un'orda di mostriciattoli fatti di lattine, cavi e spazzatura invade il quartiere. Li fai a pezzi mentre cerchi di capire DA DOVE arrivino: prendi qualche graffio, ma torni con un pupazzo-trofeo e la tasca piena."
Scena: pet che mena fendenti contro creaturine di spazzatura, quartiere sullo sfondo

**Fallimento** (condizione: Maleducato + talento Bad Loser) — Bistecca (cibo, Forza+2) (se ne va senza un graffio)
Dati: priorita=1 ; cond= maleducato & talento:badloser ; reward= cibo:Bistecca
Testo: "L'idea di perdere contro della SPAZZATURA ti manda in tilt: molli tutto e te ne vai sbuffando, senza un graffio ma anche senza gloria."
Scena: pet che si allontana a braccia conserte mentre i mostriciattoli lo inseguono goffi

**Fallimento** (condizione: Forza ≤7) — Ferite +12, +5 monete, Bistecca (cibo, Forza+2)
Dati: priorita=2 ; cond= forza<=7 ; reward= ferite+12, monete+5, cibo:Bistecca
Testo: "Sono troppi e tu troppo poco: ti sommergono, ti rialzi ammaccato e con pochi spiccioli. Un vicino ti rifocilla con una bistecca."
Scena: pet sepolto sotto una montagna di mostriciattoli, una mano che spunta

**Super successo** (condizione: Forza 13+; auto anche con perk Doc Brown [tag studio] o Cacciatore di Mostri [tag mostro]) — +3 Forza, −6 Salute (Ferite +6), +25 monete, Pupazzo Mostriciattolo, Pistola Spara-Spazzatura (arma equipaggiabile, +4 Forza −2 Carisma; serve il perk Weapon Wielder), Felicità +10
Dati: cond= forza>=13 ; reward= forza+3, ferite+6, monete+25, arredo:Pupazzo Mostriciattolo, arma:Pistola Spara-Spazzatura, fel+10
Testo: "Li spazzi via come briciole, poi risali la corrente fino al BOSS — un mostro-discarica gigante — e lo smonti pezzo per pezzo. Tra i rottami trovi una pistola spara-spazzatura, brutta ma devastante."
Scena: [DEDICATA] pet vittorioso sul boss-discarica smontato, pistola spara-spazzatura in pugno

## Missione 29: Prova di Forza al Luna Park
Brief: Al Luna Park il vecchio gioco del martellone aspetta la tua mazzata: pallina, colonna, campana, e tutti gli occhi puntati su di te.
- Luogo: 📍 Luna Park
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Forza
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sport ; stat=forza ; stadio=teen

**Standard** — +2 Forza, +1 Carisma, Adesivo Martello (arredo cucina, +1 Forza), Felicità +5
Dati: reward= forza+2, carisma+1, arredo:Adesivo Martello, fel+5
Testo: "Al luna park c'è il classico gioco del martellone: colpisci, la pallina sale, la campana suona. Dai una bella mazzata, arrivi a metà colonna e strappi applausi e un adesivo-ricordo per il frigo."
Scena: pet che cala un martellone su una pedana, la pallina a metà colonna, folla curiosa

**Fallimento** (condizione: Gentile + talento Amante della Natura) — +1 Carisma, Bistecca (cibo, Forza+2), Peluche Luna Park (arredo bagno, +1 Carisma)
Dati: priorita=1 ; cond= gentile & talento:amantedellanatura ; reward= carisma+1, cibo:Bistecca, arredo:Peluche Luna Park
Testo: "Alzi il martello di legno e... no, non te la senti di colpirlo, poverino. Ti rifiuti con dignità. Il gestore, intenerito, ti regala comunque un peluche e qualcosa da mangiare."
Scena: pet che accarezza il martello di legno invece di usarlo, gestore che ride

**Fallimento** (condizione: Forza ≤7) — Bistecca (cibo, Forza+2), Peluche Luna Park (arredo bagno, +1 Carisma)
Dati: priorita=2 ; cond= forza<=7 ; reward= cibo:Bistecca, arredo:Peluche Luna Park
Testo: "La pallina sale... di tre centimetri. Il gestore trattiene una risata e ti consola con del cibo e un peluche 'per non piangere'."
Scena: pet deluso davanti alla pallina fermissima in basso, gestore che porge un peluche

**Super successo** (condizione: Forza 13+, oppure Nerd + talento Inventore) — +3 Forza, +30 monete, Martello Vero (arredo salone, +3 Forza), Felicità +10
Dati: cond= forza>=13 | (nerd & talento:inventore) ; reward= forza+3, monete+30, arredo:Martello Vero, fel+10
Testo: "MAZZATA COSMICA: la pallina sfonda la campana e forse pure il cielo. (O, se sei un tipo ingegnoso, ti costruisci un martello meccanico che fa il record da solo.) Premio in monete e un martellone vero tutto tuo."
Scena: [DEDICATA] pet trionfante mentre la campana esplode in cima alla colonna, martellone in spalla

## Missione 30: Influencer per un Giorno
Brief: Un giorno da influencer: telecamere puntate, profilo pronto a esplodere, e gli hater già in agguato nei commenti.
- Luogo: 📍 Studio Social
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=teen

**Standard** — +2 Carisma, +15 monete (donazioni), Felicità +5
Dati: reward= carisma+2, monete+15, fel+5
Testo: "Il tuo profilo social esplode dall'oggi al domani. Tra un post riuscito e qualche hater da ignorare, cavalchi l'onda con discreta classe e incassi le prime donazioni dei follower."
Scena: pet che si fa un selfie con lo sfondo di cuori e like che salgono

**Fallimento** (condizione: Sportivo + talento Predestinato) — Torta intera (cibo, Carisma+3), +3 monete
Dati: priorita=1 ; cond= sportivo & talento:predestinato ; reward= cibo:Torta intera, monete+3
Testo: "Ti sei montato la testa: 'sono una STAR, io'. Al primo hater sbrocchi in diretta e perdi metà follower in un minuto. Resta giusto qualche donazione e un dolce di consolazione."
Scena: pet imbufalito che urla contro lo schermo del telefono, il contatore follower che crolla

**Fallimento** (condizione: Carisma ≤7) — Abbuffata in Diretta (cibo multi-porzione ×5, +2 stat casuale a morso), +3 monete
Dati: priorita=2 ; cond= carisma<=7 ; reward= cibo:Abbuffata in Diretta, monete+3
Testo: "Un post infelice, una risposta peggiore, e i commenti si trasformano in un linciaggio. Allora fai l'unica cosa che sul web funziona sempre: apri la diretta e ti metti a MANGIARE. Cinque portate, zero parole, migliaia di spettatori ipnotizzati. Non hai salvato la reputazione, ma la dispensa è piena e qualcuno ha pure donato."
Scena: pet mogio che fissa un telefono pieno di commenti arrabbiati

**Super successo** (condizione: Carisma 13+, oppure Sportivo + talento Fisico Bestiale) — +3 Carisma, +40 monete, Laptop (arredo salone, +2 Carisma), perk Influencer (tag social: niente fallimento + sempre super successo nelle missioni tag social), Felicità +10
Dati: cond= carisma>=13 | (sportivo & talento:fisicobestiale) ; reward= carisma+3, monete+40, arredo:Laptop, perk:influencer, fel+10
Testo: "Diventi virale nel modo giusto: milioni di cuori, gli haters zittiti a suon di carisma (o di bicipiti), e gli sponsor che fanno a gara. Ti regalano un laptop pro e la fama da vero influencer."
Scena: [DEDICATA] pet raggiante circondato da schermi con milioni di like, un laptop pro tra le mani

## Missione 31: Salva il Matrimonio
Brief: Sei invitato a un matrimonio che sta franando in diretta: torta traballante, sposi sul piede di guerra, nessuno che media.
- Luogo: 📍 Sala Ricevimenti
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; stadio=teen

**Standard** — +2 Carisma, Torta Nuziale (cibo, Carisma+2), Felicità +5
Dati: reward= carisma+2, cibo:Torta Nuziale, fel+5
Testo: "Sei un ospite, e il matrimonio sta andando a rotoli: la torta traballa, gli sposi bisticciano. Con qualche parola giusta rimetti insieme i cocci e la festa riparte. Ti tocca pure una bella fetta di torta nuziale."
Scena: pet che media tra due sposi imbronciati, torta nuziale traballante sullo sfondo

**Fallimento** (condizione: Sportivo + talento Fissato con la Dieta) — Spiedino (cibo, Forza+1)
Dati: priorita=1 ; cond= sportivo & talento:fissatoconladieta ; reward= cibo:Spiedino
Testo: "Il caos non ti tocca: sei troppo impegnato a NON toccare la torta ('è tutta zucchero!'). Non risolvi niente, ma ti porti via qualcosa di sano da mangiare."
Scena: pet che scansa con orrore un vassoio di torta, cercando qualcosa di più sano

**Fallimento** (condizione: Carisma ≤7) — Biscotto (cibo, Carisma+1)
Dati: priorita=2 ; cond= carisma<=7 ; reward= cibo:Biscotto
Testo: "Provi a mediare ma peggiori tutto: la torta crolla, gli sposi litigano più forte. Ti defili in imbarazzo, rimediando giusto un dolcetto dal buffet."
Scena: pet imbarazzato che si defila mentre la torta nuziale crolla dietro di lui

**Super successo** (condizione: Carisma 13+, oppure Gentile + talento Pacifista) — +3 Carisma, Torta Nuziale, Bouquet da Sposa (indossabile, +1 Carisma), Felicità +10
Dati: cond= carisma>=13 | (gentile & talento:pacifista) ; reward= carisma+3, cibo:Torta Nuziale, indossabile:Bouquet da Sposa, fel+10
Testo: "Con una dolcezza da manuale rimetti pace tra gli sposi, salvi la torta all'ultimo secondo e trasformi il disastro nel matrimonio dell'anno. Gli sposi commossi ti lanciano il bouquet."
Scena: [DEDICATA] pet che afferra al volo il bouquet mentre gli sposi si baciano felici, coriandoli

## Missione 32: Karaoke
Brief: Serata karaoke al bar del quartiere: palchetto, microfono acceso, e tutti gli occhi (e orecchie) puntati su di te.
- Luogo: 📍 Karaoke Bar
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: musica, social
- Durata: 1h
- Costo: gratis
- Dati: durata=1h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=musica,social ; stadio=teen

**Standard** — +2 Carisma, Microfono da Cantante (indossabile, +2 Carisma), Felicità +5
Dati: reward= carisma+2, indossabile:Microfono da Cantante, fel+5
Testo: "Serata karaoke coi pet del quartiere. Sali sul palchetto, prendi il microfono e canti — non benissimo, ma con un'energia che contagia tutti. Il locale ti regala il microfono 'per la prossima'."
Scena: pet che canta al microfono sul palchetto, testo della canzone su uno schermo dietro

**Fallimento** (condizione: Maleducato + talento Cleptomane) — Torta intera (cibo, Carisma+3)
Dati: priorita=1 ; cond= maleducato & talento:cleptomane ; reward= cibo:Torta intera
Testo: "Più che cantare, provi a 'prendere in prestito' qualche moneta dai tavoli. Ti beccano e ti cacciano tra i fischi. Ti resta giusto un dolce arraffato al volo."
Scena: pet trascinato fuori dai buttafuori con un dolce e qualche moneta in mano

**Fallimento** (condizione: Carisma ≤7) — Torta intera (cibo, Carisma+3)
Dati: priorita=2 ; cond= carisma<=7 ; reward= cibo:Torta intera
Testo: "Steccatura dopo steccatura, il pubblico si copre le orecchie. Scendi dal palco tra applausi di pietà. Qualcuno ti offre un dolce per farti passare la vergogna."
Scena: pet mortificato al microfono, pubblico che si copre le orecchie

**Super successo** (condizione: Carisma 13+, oppure talento Faccia di Bronzo; auto anche col perk Influencer [tag social]) — +3 Carisma, Microfono da Cantante, perk Singer (tag musica: niente fallimento + sempre super successo nelle missioni tag musica), Felicità +10
Dati: cond= carisma>=13 | talento:facciadibronzo ; reward= carisma+3, indossabile:Microfono da Cantante, perk:singer, fel+10
Testo: "Che tu canti divinamente o sia totalmente stonato ma senza vergogna, conquisti il pubblico: cori, accendini alzati, bis su bis. Diventi la leggenda del karaoke, microfono e fama di cantante inclusi."
Scena: [DEDICATA] pet star sul palco col microfono, pubblico in delirio con le luci alzate

---

## Missione 81: Braccio di Ferro del Porto
Brief: Alla taverna del porto il braccio di ferro è religione: scaricatori, marinai e un tavolo pronto a scricchiolare.
- Luogo: 📍 Taverna del Porto
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: gara
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=combattimento ; stat=forza ; tag=gara ; stadio=teen

**Standard** — +2 Forza, +20 monete, Felicità +5
Dati: reward= forza+2, monete+20, fel+5
Testo: "Alla taverna del porto il braccio di ferro è religione: scaricatori, marinai e un tavolo che ha visto più gomiti che bicchieri. Vinci qualche mano, ne perdi altre, e ti guadagni il rispetto (e la paga) della serata."
Scena: pet a un tavolo di taverna gomito a gomito con uno scaricatore enorme

**Fallimento** (condizione: Forza ≤7) — Ferite +10, Barretta proteica (cibo, Forza+1)
Dati: cond= forza<=7 ; reward= ferite+10, cibo:Barretta proteica, fel-5
Testo: "Il primo avversario ti sbatte il braccio sul tavolo con tale slancio che fai un mezzo giro sulla sedia. La taverna ride bonaria e ti passa una barretta: 'mangia, ragazzo, e torna tra un mese'."
Scena: pet a gambe all'aria accanto al tavolo, avversario che ride con simpatia

**Super successo** (condizione: Forza 13+, oppure talento Mani Leste — *il polso scatta prima che l'avversario capisca che si è iniziato*) — +3 Forza, +35 monete, Trofeo del Porto (arredo salone, +2 Forza), Felicità +10
Dati: cond= forza>=13 | talento:manileste ; reward= forza+3, monete+35, arredo:Trofeo del Porto, fel+10
Testo: "Li stendi tutti, compreso il campione in carica che non perdeva da tre anni. Il tavolo storico si crepa nel punto del tuo ultimo colpo: lo firmano e ti danno il trofeo della taverna."
Scena: [DEDICATA] pet col braccio alzato sul tavolo crepato, taverna in delirio

## Missione 82: Buttafuori per una Sera
Brief: Stasera fai il buttafuori alla festa più esclusiva della terrazza: lista in mano, sguardo serio, zero eccezioni.
- Luogo: 📍 Festa in Terrazza
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Tag: social
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza ; tag=social ; stadio=teen

**Standard** — +2 Forza, +25 monete, Felicità +5
Dati: reward= forza+2, monete+25, fel+5
Testo: "La festa in terrazza più esclusiva del quartiere ti assume come buttafuori: lista in mano, braccia conserte, sguardo serio. Qualche imbucato ci prova, nessuno passa. Professionista."
Scena: pet a braccia conserte davanti alla scala della terrazza, lista in mano

**Fallimento** (condizione: Forza ≤7) — Spiedino (cibo, Forza+1)
Dati: cond= forza<=7 ; reward= cibo:Spiedino, fel-5
Testo: "Gli imbucati ti scavalcano, ti aggirano e uno ti passa letteralmente SOTTO. A fine serata in terrazza ci sono più imbucati che invitati. Il buffet avanzato è la tua buonuscita."
Scena: pet frastornato alla scala mentre gente festante gli sfila intorno

**Super successo** (condizione: Forza 13+, oppure Gentile + talento Pacifista — *convince gli imbucati ad andarsene offrendogli da bere: nessuno capisce come, ma funziona*) — +3 Forza, +40 monete, Felicità +10
Dati: cond= forza>=13 | (gentile & talento:pacifista) ; reward= forza+3, monete+40, fel+10
Testo: "Zero imbucati, zero incidenti, e persino il vicino brontolone se ne va convinto di essersi divertito. Il padrone di casa ti prenota per TUTTE le feste della stagione, paga doppia."
Scena: [DEDICATA] pet che accompagna fuori l'ultimo imbucato con gesto elegante, festa perfetta alle spalle

## Missione 83: Istruttore Supplente
Brief: L'istruttore della palestra è a casa malato e la classe delle sei è tutta tua: dieci allievi, un'ora, la tua playlist.
- Luogo: 📍 Palestra di Quartiere
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Forza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sport ; stat=forza ; stadio=teen

**Standard** — +2 Forza, +25 monete, Felicità +5
Dati: reward= forza+2, monete+25, fel+5
Testo: "L'istruttore è influenzato e la classe delle 18 è tua: dieci allievi, un'ora di circuito e la tua playlist. Sopravvivete tutti, qualcuno persino ringrazia."
Scena: pet col fischietto davanti a una fila di allievi in affanno

**Fallimento** (condizione: Forza ≤7) — Ferite +10, Barretta proteica (cibo, Forza+1)
Dati: cond= forza<=7 ; reward= ferite+10, cibo:Barretta proteica, fel-5
Testo: "Provi a dimostrare l'esercizio più difficile e resti incastrato nella macchina per i dorsali. La classe ti libera con lavoro di squadra: tecnicamente, un ottimo esercizio di gruppo."
Scena: pet incastrato nella macchina da palestra, allievi che tirano

**Super successo** (condizione: Forza 13+, oppure Nerd + talento Mente Analitica — *schede d'allenamento calcolate al millimetro per ogni allievo*) — +3 Forza, +40 monete, Fischietto dell'Istruttore (indossabile, +1 Forza +1 Carisma), Felicità +10
Dati: cond= forza>=13 | (nerd & talento:menteanalitica) ; reward= forza+3, monete+40, indossabile:Fischietto dell'Istruttore, fel+10
Testo: "La tua lezione è così ben costruita che gli allievi chiedono di averti TUTTE le settimane. Il titolare ti consegna il fischietto ufficiale: 'il supplente è promosso'."
Scena: [DEDICATA] classe che applaude, pet col fischietto al collo appena consegnato

## Missione 84: Il Furgone del Gelataio
Brief: Il furgone dei gelati resta in panne in salita, motore fuso e trenta cuccioli disperati in coda per un cono.
- Luogo: 📍 Via del Mercato
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza ; stadio=teen

**Standard** — +2 Forza, Ghiacciolo (cibo, Carisma+1), +15 monete, Felicità +5
Dati: reward= forza+2, cibo:Ghiacciolo, monete+15, fel+5
Testo: "Il furgone dei gelati è in panne in salita, col motore fuso e trenta cuccioli in attesa disperata. Lo spingi fino alla piazza, un metro alla volta: il gelataio ti paga in monete e ghiaccioli."
Scena: pet che spinge un furgone dei gelati in salita, cuccioli che tifano dal marciapiede

**Fallimento** (condizione: Forza ≤7) — −10 Igiene, Ghiacciolo (cibo, Carisma+1)
Dati: cond= forza<=7 ; reward= igiene-10, cibo:Ghiacciolo, fel-5
Testo: "Il furgone rotola all'indietro e tu con lui, aggrappato al paraurti come un eroe inutile. Vi fermate contro un cumulo di sabbia: tu sporco, il furgone intatto, il gelataio riconoscente per l'intenzione."
Scena: pet impolverato aggrappato al paraurti, furgone nel cumulo di sabbia

**Super successo** (condizione: Forza 13+) — +3 Forza, +30 monete, Ghiacciolo (cibo, Carisma+1), Felicità +10
Dati: cond= forza>=13 ; reward= forza+3, monete+30, cibo:Ghiacciolo, fel+10
Testo: "Spingi il furgone su per la salita SENZA fermarti mai, tra due ali di folla che applaude. Il gelataio apre il portellone in piazza e annuncia: 'gelato gratis per tutti, offre il mio motore!' Sei l'eroe dell'estate."
Scena: [DEDICATA] pet che spinge il furgone in cima tra gli applausi, gelati che spuntano dal portellone

## Missione 85: Gran Premio dei Go-Kart
Brief: Dodici giri, curve strette e gomitate ufficialmente vietate: il Gran Premio dei go-kart del luna park sta per partire.
- Luogo: 📍 Pista del Luna Park
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara, inseguimento
- Durata: 1h30
- Costo: 10 monete
- Dati: durata=1.5h ; costo=10 ; categoria=sport ; stat=velocita ; tag=gara,inseguimento ; stadio=teen

**Standard** — +2 Velocità, +25 monete, Felicità +5
Dati: reward= velocita+2, monete+25, fel+5
Testo: "Il Gran Premio dei go-kart del luna park: dodici giri, curve strette e gomitate (vietate ma tollerate). Chiudi sul podio basso dopo una gara tutta sorpassi."
Scena: pet in un go-kart in piena curva, avversari incollati

**Fallimento** (condizione: Velocità ≤7) — Ferite +5, Sushi (cibo, Velocità+2)
Dati: cond= velocita<=7 ; reward= ferite+5, cibo:Sushi, fel-5
Testo: "Testacoda al secondo giro: finisci nelle balle di paglia con le ruote che girano a vuoto. Il pubblico applaude comunque, perché il tuo testacoda era oggettivamente spettacolare."
Scena: pet a testa in giù nella paglia, go-kart con le ruote che girano

**Super successo** (condizione: Velocità 13+; auto anche col perk Sabotatore [gara] o Parkour Master [inseguimento]) — +3 Velocità, +40 monete, Kart a Pedali (arredo salone, +2 Velocità), Felicità +10
Dati: cond= velocita>=13 ; reward= velocita+3, monete+40, arredo:Kart a Pedali, fel+10
Testo: "Parti ultimo per un problema al motore e rimonti TUTTI, con un sorpasso all'esterno all'ultima curva che finirà nei racconti del luna park. Il gestore ti regala il kart d'esposizione."
Scena: [DEDICATA] sorpasso all'esterno sull'ultima curva, bandiera a scacchi che sventola

## Missione 86: La Consegna dell'Ultima Torta
Brief: Una torta a tre piani deve arrivare in villa entro le sei, e il traffico della città non sembra d'accordo.
- Luogo: 📍 Dalla Pasticceria alla Villa
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=consegne ; stat=velocita ; stadio=teen

**Standard** — +2 Velocità, +25 monete, Felicità +5
Dati: reward= velocita+2, monete+25, fel+5
Testo: "La torta a tre piani per il compleanno in villa DEVE arrivare entro le sei, e il traffico è un incubo. Tra scorciatoie e frenate col fiato sospeso, la consegni con dieci minuti di margine e la glassa intatta."
Scena: pet in equilibrio con una torta a tre piani, orologio della città sullo sfondo

**Fallimento** (condizione: Velocità ≤7) — −10 Igiene, Fetta di torta (cibo, Carisma+1)
Dati: cond= velocita<=7 ; reward= igiene-10, cibo:Fetta di torta, fel-5
Testo: "L'ultimo gradino della villa è il tuo nemico: inciampi e la torta ti abbraccia in volo. Recuperi il recuperabile (una fetta, per te) e la pasticceria manda d'urgenza il piano B."
Scena: pet seduto coperto di glassa, una fetta superstite in mano

**Super successo** (condizione: Velocità 13+) — +3 Velocità, +45 monete, Felicità +10
Dati: cond= velocita>=13 ; reward= velocita+3, monete+45, fel+10
Testo: "Arrivi con mezz'ora d'anticipo e la torta perfetta, tanto che ti chiedono di restare a servirla in guanti bianchi. La padrona di casa raddoppia la mancia: 'il fattorino più elegante mai visto'."
Scena: [DEDICATA] pet in posa da maggiordomo che presenta la torta intatta, ospiti ammirati

## Missione 87: Il Borseggiatore del Mercato
Brief: Un borseggiatore ripulisce le borse della spesa da giorni: oggi lo becchi in flagrante tra i banchi del mercato rionale.
- Luogo: 📍 Mercato Rionale
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: inseguimento
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=inseguimento ; stadio=teen

**Standard** — +2 Velocità, +30 monete, Felicità +5
Dati: reward= velocita+2, monete+30, fel+5
Testo: "Un borseggiatore ripulisce le borse della spesa da una settimana. Lo becchi in flagrante e parte l'inseguimento tra i banchi: lo perdi due volte, lo riprendi alla terza. I mercanti fanno la colletta."
Scena: inseguimento tra i banchi del mercato, arance che volano

**Fallimento** (condizione: Velocità ≤7) — Pesce alla griglia (cibo, Velocità+1)
Dati: cond= velocita<=7 ; reward= cibo:Pesce alla griglia, fel-5
Testo: "Il borseggiatore ti semina in tre curve e per giunta, nella foga, travolgi il banco delle uova. Il pescivendolo ti consola con un pesce alla griglia: 'l'importante è provarci, ragazzo. Anche se magari... non tra le uova.'"
Scena: pet seduto tra le uova rotte, banco rovesciato, pescivendolo che sorride

**Super successo** (condizione: Velocità 13+, oppure Forza 10+ — *non serve corrergli dietro: lo placchi come un rugbista quando ti ripassa accanto*; auto anche col perk Parkour Master [inseguimento]) — +3 Velocità, +50 monete, perk Mr. Wolf (categoria Lavoretti: niente fallimento + sempre super successo nelle missioni Lavoretti), Felicità +10
Dati: cond= velocita>=13 | forza>=10 ; reward= velocita+3, monete+50, perk:mrwolf, fel+10
Testo: "Lo anticipi: invece di inseguirlo, tagli per il banco del pesce e te lo ritrovi in braccio alla svolta (o semplicemente lo placchi al volo, stile rugby). Restituisci ogni borsellino al legittimo proprietario. Il mercato ti incorona: sei quello che risolve i problemi."
Scena: [DEDICATA] borseggiatore consegnato al vigile, mercanti che sollevano il pet in trionfo

## Missione 88: La Traversata della Cava
Brief: La cava allagata aspetta la traversata completa: il rito di passaggio di ogni teen del quartiere, acqua gelida inclusa.
- Luogo: 📍 Cava Allagata
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: natura
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sport ; stat=velocita ; tag=natura ; stadio=teen

**Standard** — +2 Velocità, Felicità +5
Dati: reward= velocita+2, fel+5
Testo: "La vecchia cava allagata è la piscina segreta del quartiere, e la traversata completa è il rito di passaggio dei teen. La fai tutta, con una pausa a metà sull'isolotto per riprendere fiato e dignità."
Scena: pet che nuota nella cava turchese, isolotto al centro

**Fallimento** (condizione: Nerd + talento Idrofobico) — +1 Intelligenza, Felicità +5
Dati: priorita=1 ; cond= nerd & talento:idrofobico ; reward= int+1, fel+5
Testo: "L'acqua? Neanche morto. Resti sulla riva a catalogare le rane della cava (tre specie, una probabilmente nuova alla scienza). Non hai nuotato un metro, ma il taccuino è pieno."
Scena: pet all'asciutto che disegna rane sul taccuino, nuotatori sullo sfondo

**Fallimento** (condizione: Velocità ≤7) — Sushi (cibo, Velocità+2)
Dati: priorita=2 ; cond= velocita<=7 ; reward= cibo:Sushi, fel-5
Testo: "A metà traversata i crampi ti trasformano in una boa. Ti trascinano a riva i bagnanti, tra applausi ironici. Il sushi del chiosco ti restituisce un po' d'onore."
Scena: pet a pancia in su che galleggia, due bagnanti che lo rimorchiano

**Super successo** (condizione: Velocità 13+, o auto col talento Amante della Natura via tag natura) — +3 Velocità, +30 monete, Trofeo Rana d'Oro (arredo bagno, +1 Velocità), Felicità +10
Dati: cond= velocita>=13 ; reward= velocita+3, monete+30, arredo:Trofeo Rana d'Oro, fel+10
Testo: "Traversata completa andata e ritorno senza pause: nuovo record della cava, certificato dai teen anziani sulla lavagnetta del chiosco. Ti consegnano la Rana d'Oro, il trofeo più ambito dell'estate."
Scena: [DEDICATA] pet sull'isolotto con la Rana d'Oro alzata, cava che applaude dall'acqua

## Missione 89: Il Torneo di Scacchi del Circolo
Brief: Tra occhiali spessi e partite serissime, il circolo degli anziani accoglie i giovani a scacchi con scetticismo puro.
- Luogo: 📍 Circolo degli Anziani
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: gara
- Durata: 1h30
- Costo: 5 monete
- Dati: durata=1.5h ; costo=5 ; categoria=studio ; stat=int ; tag=gara ; stadio=teen

**Standard** — +2 Intelligenza, +20 monete, Felicità +5
Dati: reward= int+2, monete+20, fel+5
Testo: "Il torneo di scacchi del circolo anziani accetta 'giovani promesse' con malcelato scetticismo. Vinci tre partite su cinque e ti guadagni il rispetto del tavolo: 'il piccolo sa quello che fa'."
Scena: pet concentrato sulla scacchiera, anziani con l'occhialino che osservano

**Fallimento** (condizione: Intelligenza ≤7) — Cacio e Pepe Quantistica (cibo, Intelligenza+3)
Dati: cond= int<=7 ; reward= cibo:Cacio e Pepe Quantistica, fel-5
Testo: "Il decano del circolo ti dà matto in quattro mosse, il tutto senza mai smettere di raccontare la guerra. Ti offrono il piatto della casa — una cacio e pepe fatta con la formula esatta, zero grumi — e un consiglio: 'torna quando sai cos'è un arrocco, giovane'."
Scena: pet che fissa la scacchiera incredulo, decano che sorseggia il tè

**Super successo** (condizione: Intelligenza 13+, oppure Sportivo + talento Spirito Agonistico — *la tratta come una finale di campionato: concentrazione assoluta*; auto anche col perk Sabotatore [gara]) — +3 Intelligenza, +35 monete, Scacchiera d'Onice (arredo salone, +2 Intelligenza), Felicità +10
Dati: cond= int>=13 | (sportivo & talento:spiritoagonistico) ; reward= int+3, monete+35, arredo:Scacchiera d'Onice, fel+10
Testo: "Batti anche il decano, che non perdeva dal secolo scorso. Lunga pausa, poi il vecchio sorride: 'era ora.' Ti regala la sua scacchiera d'onice, quella che nessuno poteva nemmeno toccare."
Scena: [DEDICATA] stretta di mano sulla scacchiera d'onice, circolo in piedi

## Missione 90: Ripetizioni al Vicino
Brief: Il cucciolo del piano di sopra è in guerra con le frazioni e sua madre cerca rinforzi: oggi tocca a te salvare la situazione.
- Luogo: 📍 Casa del Vicino
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; stadio=teen

**Standard** — +2 Intelligenza, +25 monete, Felicità +5
Dati: reward= int+2, monete+25, fel+5
Testo: "Il cucciolo del piano di sopra è un disastro in matematica e sua madre paga bene. Quattro ore di frazioni spiegate con le fette di pizza: alla fine qualcosa entra, e la paga pure."
Scena: pet alla scrivania che spiega, cucciolo che finalmente annuisce

**Fallimento** (condizione: Intelligenza ≤7) — Biscotto (cibo, Carisma+1)
Dati: cond= int<=7 ; reward= cibo:Biscotto, fel-5
Testo: "Le frazioni mettono ko prima lui e poi te: la madre vi trova addormentati sul libro, guancia contro guancia sulla pagina 42. Niente paga, ma i biscotti della merenda te li dà lo stesso."
Scena: pet e cucciolo addormentati sul libro di matematica, madre sulla soglia

**Super successo** (condizione: Intelligenza 13+) — +3 Intelligenza, +50 monete, Felicità +10
Dati: cond= int>=13 ; reward= int+3, monete+50, fel+10
Testo: "Il metodo delle fette di pizza funziona così bene che il cucciolo prende il suo primo dieci. La madre, commossa, raddoppia la paga e ti prenota per tutto il quadrimestre: sei ufficialmente 'il professore'."
Scena: [DEDICATA] cucciolo che sventola la verifica col dieci, pet portato in trionfo per casa

## Missione 91: Il Cabinato Rotto
Brief: Fili scoperti, polvere e un cabinato morto da una settimana: la sala giochi ha bisogno di mani ficcanaso, non del tecnico.
- Luogo: 📍 Sala Giochi
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Intelligenza
- Tag: invenzione
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=videogioco ; stat=int ; stadio=teen

**Standard** — +2 Intelligenza, +20 monete, Felicità +5
Dati: reward= int+2, monete+20, fel+5
Testo: "Il cabinato più amato della sala giochi è morto da una settimana e il tecnico costa troppo. Lo apri, segui i fili, trovi il colpevole (una moneta incastrata dal 2019) e lo riporti in vita."
Scena: pet dentro il cabinato aperto tra i fili, torcia tra i denti

**Fallimento** (condizione: Intelligenza ≤7) — Ferite +5, Torta Menzogniera (cibo, Intelligenza+2 — la torta era una bugia, la lezione no)
Dati: cond= int<=7 ; reward= ferite+5, cibo:Torta Menzogniera, fel-5
Testo: "Tocchi il filo sbagliato: scossa, capelli dritti e il cabinato che ora parla in giapponese. Il gestore ti allontana con gentilezza promettendoti una torta di consolazione: nella scatola, però, trovi solo un bigliettino che dice che la torta era una bugia. La lezione, quella no."
Scena: pet coi capelli dritti e le scintille intorno, cabinato che lampeggia ideogrammi

**Super successo** (condizione: Intelligenza 13+, oppure Forza 10+ — *manutenzione percussiva: UNA manata assestata nel punto esatto*; auto anche col perk Player One [Videogioco]; via alt flag grinder) — +3 Intelligenza, +35 monete, Gettone d'Oro (arredo salone, +1 Intelligenza +1 Felicità), Felicità +10
Dati: cond= int>=13 | forza>=10 | flag:grinder ; reward= int+3, monete+35, arredo:Gettone d'Oro, fel+10
Testo: "Non solo lo aggiusti: lo MIGLIORI. Ora il cabinato ha una modalità segreta che sblocchi con il doppio salto, e la sala giochi non è mai stata così piena. Il gestore conia per te un gettone d'oro: partite gratis a vita."
Scena: [DEDICATA] cabinato acceso con la folla intorno, gestore che consegna il gettone dorato

## Missione 92: Il Fungo Misterioso
Brief: Nel bosco del Parco Grande spunta un fungo mai visto: gigante, a pois, vagamente luminoso. La guardia vuole un rapporto.
- Luogo: 📍 Bosco del Parco Grande
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: natura
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; tag=natura ; stadio=teen

**Standard** — +2 Intelligenza, Fungone Ingrandotto (cibo, Forza+2 Intelligenza+1), Felicità +5
Dati: reward= int+2, cibo:Fungone Ingrandotto, fel+5
Testo: "Nel bosco del parco è spuntato un fungo MAI visto: gigante, a pois, vagamente luminoso. Lo studi, lo cataloghi, lo fotografi da otto angolazioni e concludi il rapporto: 'commestibile, probabilmente'. La guardia del parco ti lascia portare a casa un esemplare: 'se cresci di colpo, non dire che te l'ho dato io'."
Scena: pet con la lente davanti a un fungo gigante a pois, taccuino aperto

**Fallimento** (condizione: Intelligenza ≤7) — Insalatona (cibo, Intelligenza+1), Felicità −5
Dati: cond= int<=7 ; reward= cibo:Insalatona, fel-5
Testo: "Lo annusi da troppo vicino: le spore ti fanno vedere i colori CHE NON ESISTONO per un'ora buona. La guardia del parco ti tiene d'occhio finché non torni normale, poi ti rimanda a casa con un'insalata: 'verdure normali, mi raccomando'."
Scena: pet con gli occhi a spirale seduto davanti al fungo, farfalle immaginarie intorno

**Super successo** (condizione: Intelligenza 13+, o auto col talento Amante della Natura via tag natura) — +3 Intelligenza, +30 monete, Felicità +10
Dati: cond= int>=13 ; reward= int+3, monete+30, fel+10
Testo: "Identifichi il fungo: è una specie rarissima che si credeva estinta, e il tuo rapporto finisce dritto al museo di storia naturale con il tuo nome come scopritore. La targhetta dice 'catalogato da un giovane naturalista del quartiere'. Sei tu."
Scena: [DEDICATA] teca del museo col fungo e la targhetta, pet in posa orgogliosa accanto

## Missione 93: DJ della Festa Scolastica
Brief: Il DJ della festa scolastica ha dato buca all'ultimo minuto: la consolle è vuota, la palestra è piena e aspetta.
- Luogo: 📍 Palestra della Scuola
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social, musica
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social,musica ; stadio=teen

**Standard** — +2 Carisma, +25 monete, Felicità +5
Dati: reward= carisma+2, monete+25, fel+5
Testo: "Il DJ della festa scolastica ha dato buca e la consolle è tua. Qualche transizione incerta, un microfono che fischia, ma la pista si riempie e ci resta fino alla fine."
Scena: pet alla consolle con le cuffie su un orecchio, palestra piena che balla

**Fallimento** (condizione: Carisma ≤7) — Fetta di torta (cibo, Carisma+1)
Dati: cond= carisma<=7 ; reward= cibo:Fetta di torta, fel-5
Testo: "Parti con la playlist sbagliata — quella del viaggio in macchina con la nonna — e la pista si svuota in novanta secondi. Ti sostituisce il bidello (che spacca, peraltro). Ti resta la torta del buffet."
Scena: pista vuota, bidello alla consolle che alza le braccia, pet in disparte con la torta

**Super successo** (condizione: Carisma 13+; auto anche col perk Singer [musica] o Influencer [social]) — +3 Carisma, +40 monete, Cuffie da DJ (indossabile, +2 Carisma), Felicità +10
Dati: cond= carisma>=13 ; reward= carisma+3, monete+40, indossabile:Cuffie da DJ, fel+10
Testo: "Leggi la pista come un libro aperto: ogni pezzo al momento giusto, il momento lento calibrato al secondo, il finale con tutti sulle spalle di tutti. La scuola ti nomina DJ ufficiale e ti consegna le cuffie d'ordinanza."
Scena: [DEDICATA] palestra in delirio con le mani alzate, pet alla consolle con le cuffie nuove

## Missione 94: Il Mercatino dell'Usato
Brief: Un banchetto al mercatino dell'usato, tra vecchi giocattoli e fumetti letti mille volte: oggi si contratta sul serio.
- Luogo: 📍 Piazzetta del Quartiere
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Carisma
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=carisma ; stadio=teen

**Standard** — +2 Carisma, +30 monete, Felicità +5
Dati: reward= carisma+2, monete+30, fel+5
Testo: "Un banchetto al mercatino dell'usato: vecchi giocattoli, fumetti letti e rilievi di soffitta. Contratti, sorridi, sconti al punto giusto — a fine giornata il banco è mezzo vuoto e il borsello mezzo pieno."
Scena: pet dietro un banchetto pieno di cianfrusaglie, cliente che contratta

**Fallimento** (condizione: Carisma ≤7) — −10 monete, Lampada Lava di Seconda Mano (arredo camera, +1 Felicità)
Dati: cond= carisma<=7 ; reward= monete-10, arredo:Lampada Lava di Seconda Mano, fel-5
Testo: "Il problema del mercatino è che è PIENO di cose bellissime: finisci per comprare più di quanto vendi. Torni a casa con dieci monete in meno e una lampada lava 'che era un affare, giuro'."
Scena: pet che torna a casa carico di acquisti, lampada lava sotto il braccio

**Super successo** (condizione: Carisma 13+, oppure Maleducato + talento Cleptomane — *da imbonitore navigato sa vendere qualsiasi cosa; meglio non chiedere da dove viene metà della merce*) — +3 Carisma, +60 monete, Felicità +10
Dati: cond= carisma>=13 | (maleducato & talento:cleptomane) ; reward= carisma+3, monete+60, fel+10
Testo: "Vendi TUTTO, compreso il tavolino del banchetto e la sedia su cui eri seduto. L'ultima cliente ti lascia il doppio 'perché con quel sorriso non si può dire di no'. Il mercatino ti implora di tornare domenica prossima."
Scena: [DEDICATA] banchetto completamente vuoto, pet in piedi (la sedia è venduta) col borsello gonfio

## Missione 95: La Recita del Quartiere
Brief: La recita del quartiere ti affida il ruolo del secondo protagonista: mantello, spada di legno e un duello sotto le luci.
- Luogo: 📍 Teatro Parrocchiale
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sociale ; stat=carisma ; stadio=teen

**Standard** — +2 Carisma, +20 monete, Felicità +5
Dati: reward= carisma+2, monete+20, fel+5
Testo: "La recita del quartiere ti affida il ruolo del secondo protagonista: trenta battute, un mantello e un duello finale con spade di legno. Te la cavi con onore e un solo vuoto di memoria, coperto da un colpo di tosse magistrale."
Scena: pet sul palco col mantello, spada di legno alzata, pubblico in penombra

**Fallimento** (condizione: Carisma ≤7) — Biscotto (cibo, Carisma+1)
Dati: cond= carisma<=7 ; reward= cibo:Biscotto, fel-5
Testo: "Al momento clou la battuta sparisce dalla tua testa: silenzio, imbarazzo, un suggeritore che sussurra troppo forte e ride mezzo teatro. Cala il sipario tecnico. Dietro le quinte, biscotti di conforto per tutti."
Scena: pet pietrificato sul palco a bocca aperta, suggeritore che gesticola dalla buca

**Super successo** (condizione: Carisma 13+, oppure Maleducato + talento Faccia di Bronzo — *improvvisa metà copione e il pubblico preferisce la SUA versione*) — +3 Carisma, +35 monete, Costume da Protagonista (indossabile, +1 Carisma +1 Intelligenza), Felicità +10
Dati: cond= carisma>=13 | (maleducato & talento:facciadibronzo) ; reward= carisma+3, monete+35, indossabile:Costume da Protagonista, fel+10
Testo: "Rubi la scena a tutti, protagonista compreso: tre applausi a scena aperta e un bis richiesto a gran voce. Il regista ti promuove sul campo e ti lascia il costume: 'l'anno prossimo la locandina ha il tuo nome'."
Scena: [DEDICATA] pet al centro del palco nell'inchino finale, fiori che volano dal pubblico

## Missione 96: La Festa di Quartiere
Brief: La festa di quartiere annuale cerca volontari per TUTTO — palco, luci, musica, torte — e oggi la piazza conta su di te.
- Luogo: 📍 Piazza Grande
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma (ma ogni build ha la sua via)
- Tag: social
- Durata: 2h
- Costo: gratis
- Nota: BOSS multi-via (stile M7: più super possibili, vince il più specifico)
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=teen

**Standard** — +2 Carisma, +30 monete, Felicità +5
Dati: reward= carisma+2, monete+30, fel+5
Testo: "La festa di quartiere annuale cerca volontari per TUTTO: palco, luci, musica, torte. Fai la tua parte tra mille commissioni e la festa riesce, come sempre, per miracolo collettivo."
Scena: piazza in festa con bancarelle e luci, pet che corre con una cassa in braccio

**Fallimento** (condizione: Carisma ≤7) — Torta intera (cibo, Carisma+3)
Dati: cond= carisma<=7 ; reward= cibo:Torta intera, fel-5
Testo: "Ti affidano il volantinaggio e inviti mezza città... per il giorno sbagliato. La piazza sabato è vuota, domenica è un caos non pianificato. Ti consoli con una torta avanzata: almeno quella non sbaglia data."
Scena: piazza deserta con le bandierine al vento, pet col pacco di volantini sbagliati

**Super successo A — l'Anima della Festa** (condizione: Carisma 13+) — +3 Carisma, +50 monete, Lanterne della Festa (arredo salone, +2 Felicità), perk Party Animal (categoria Sociale: niente fallimento + sempre super successo nelle missioni Sociale), Felicità +10
Dati: priorita=1 ; cond= carisma>=13 ; reward= carisma+3, monete+50, arredo:Lanterne della Festa, perk:partyanimal, fel+10
Testo: "Presenti, intrattieni, fai ballare i nonni e ridere i cuccioli: la festa gira intorno a te. A fine serata il comitato ti consegna le lanterne della piazza: 'appendile a casa, l'anno prossimo si replica'."
Scena: [DEDICATA] pet al centro della piazza illuminata dalle lanterne, girotondo intorno

**Super successo B — il Cervello della Festa** (condizione: Intelligenza 13+) — +3 Intelligenza, +50 monete, Lanterne della Festa (arredo salone, +2 Felicità), perk Party Animal (categoria Sociale: niente fallimento + sempre super successo nelle missioni Sociale), Felicità +10
Dati: priorita=2 ; cond= int>=13 ; reward= int+3, monete+50, arredo:Lanterne della Festa, perk:partyanimal, fel+10
Testo: "Turni, mappa dei banchi, piano B per la pioggia e persino il piano C per il vento: la tua regia logistica fila così liscia che nessuno si accorge di quanto lavoro c'era dietro. Il comitato sì, però."
Scena: [DEDICATA] pet con la planimetria della piazza spuntata voce per voce, festa perfetta sullo sfondo

**Super successo C — le Braccia della Festa** (condizione: Forza 13+) — +3 Forza, +50 monete, Lanterne della Festa (arredo salone, +2 Felicità), perk Party Animal (categoria Sociale: niente fallimento + sempre super successo nelle missioni Sociale), Felicità +10
Dati: priorita=3 ; cond= forza>=13 ; reward= forza+3, monete+50, arredo:Lanterne della Festa, perk:partyanimal, fel+10
Testo: "Monti il palco DA SOLO, scarichi tre furgoni e issi il tendone che di solito richiede sei volontari e un litigio. Quando la festa inizia, tu sei già leggenda: 'quello del tendone'."
Scena: [DEDICATA] pet che regge il tendone da solo mentre i volontari applaudono, palco montato alle spalle

## Missione 97: Il Mostriciattolo dell'Erba Alta
Brief: Qualcosa di mai catalogato si nasconde nell'erba alta del parco: piccolo, guizzante, con le guance che fanno scintille.
- Luogo: 📍 Erba Alta del Parco Grande
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: mostro, inseguimento, companion
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sport ; stat=velocita ; tag=mostro,inseguimento,companion ; stadio=teen

**Standard** — +2 Velocità, Sfera Tascabile (arredo camera, +1 Felicità), Felicità +5
Dati: reward= velocita+2, arredo:Sfera Tascabile, fel+5
Testo: "Nell'erba alta del parco si nasconde un mostriciattolo mai catalogato: piccolo, guizzante, con le guance che fanno le scintille. Lo insegui per ore, lo sfiori DUE volte, e all'alba lui ti saluta con la zampina e sparisce. Nell'erba, però, trovi la sfera rossa e bianca che si è lasciato dietro: un souvenir. E una promessa."
Scena: pet nell'erba alta che sfiora il mostriciattolo guizzante, scintille tra le spighe

**Fallimento** (condizione: Velocità ≤7) — Ferite +5, Ciambriso Gelatinoso (cibo, Velocità+2)
Dati: cond= velocita<=7 ; reward= ferite+5, cibo:Ciambriso Gelatinoso, fel-5
Testo: "Ti ci tuffi sopra con tutto l'entusiasmo del mondo e lui ti frigge con una scintilla dispettosa: capelli dritti e codino fumante. Dall'erba alta esce solo il suo risolino. Il guardiano del parco ti offre una ciambella alla gelatina — che è palesemente un onigiri, ma non contraddirlo — e ti consola: 'ci provano tutti, nessuno l'ha mai preso'."
Scena: pet coi capelli dritti e il codino fumante seduto nell'erba, risolino che sale dalle spighe

**Super successo** (condizione: Velocità 13+, oppure Gentile + talento Coccolone — *non lo catturi: lo COCCOLI finché non decide di restare lui*) — +3 Velocità, Mostriciattolo companion (arredo camera, +1 Velocità fisso), Costume dell'Allenatore (indossabile, +2 Velocità), perk Acchiappali Tutti (tag companion: niente fallimento + sempre super successo nelle missioni tag companion — i companion non ti scappano MAI più), Felicità +10
Dati: cond= velocita>=13 | (gentile & talento:coccolone) ; reward= velocita+3, arredo:Mostriciattolo, indossabile:Costume dell'Allenatore, perk:acchiappalitutti, fel+10
Testo: "Lo braccheggi spiga per spiga finché non gli tagli la strada al balzo perfetto (o ti siedi, apri le braccia, e lo lasci decidere: sceglie te). Il mostriciattolo si arrende con un verso soddisfatto e ti si piazza sulla spalla. Il guardiano del parco non ci crede e ti consegna il costume della leggenda: berretto rosso e tutto il resto. Da oggi, gotta catch 'em all — o come si dice da queste parti: ACCHIAPPALI TUTTI."
Scena: [DEDICATA] pet col berretto rosso e il mostriciattolo sulla spalla, sfera alzata al cielo nell'erba alta al tramonto

## Missione 98: Ci Hanno Rubato i Colori
Brief: Un tizio straparla davanti alle telecamere in piazzetta: 'CI HANNO RUBATO I COLORI!' Il video sta già facendo il giro della città.
- Luogo: 📍 Piazzetta dell'Intervista
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: mistero, social
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=studio ; stat=int ; tag=mistero,social ; stadio=teen

**Standard** — +2 Intelligenza, +25 monete, Felicità +5
Dati: reward= int+2, monete+25, fel+5
Testo: "La TV locale intervista un tizio di mezza età in piazzetta e lui parte per la tangente: 'CI HANNO RUBATO I COLORI! I colori! E pure le bollicine dell'acqua frizzante, sono meno frizzanti di una volta!' Il video fa il giro della città in un'ora. E il bello è che il quartiere, guardandosi intorno... un po' ci crede: i muri SEMBRANO più spenti. Indaghi mezza giornata e trovi la spiegazione: la ditta delle pulizie ha sgrassato i muri con un solvente che ha sbiadito i murales. Colletta di vernice, caso chiuso, il tizio resta convinto del complotto."
Scena: uomo di mezza età che gesticola davanti al microfono della TV, pet che esamina un muro sbiadito con la lente

**Fallimento** (condizione: Intelligenza ≤7) — Acqua Frizzantissima (cibo), Felicità −5
Dati: cond= int<=7 ; reward= cibo:Acqua Frizzantissima, fel-5
Testo: "Parti per indagare e finisci CONVERTITO: dopo un'ora di chiacchiere col tizio sei lì anche tu a fissare il bicchiere controluce — 'le bollicine... ha ragione, sono PICCOLE.' Passi il pomeriggio a confrontare acque frizzanti invece di risolvere il caso. Almeno una bottiglia di quella buona te la porti a casa."
Scena: pet e il tizio fianco a fianco che fissano due bicchieri d'acqua frizzante controluce, molto seri

**Super successo** (condizione: Intelligenza 13+, oppure Carisma 10+ — *il tizio i suoi segreti li racconta solo a chi gli va a genio*) — +3 Intelligenza, +40 monete, Barattolo dei Colori Rubati (arredo salone, +1 Intelligenza +1 Felicità), Felicità +10
Dati: cond= int>=13 | carisma>=10 ; reward= int+3, monete+40, arredo:Barattolo dei Colori Rubati, fel+10
Testo: "Segui gli indizi fino in fondo (o è il tizio in persona, conquistato, a indicarti il vicolo giusto) e scopri che un LADRO DI COLORI esiste davvero: un artista di strada che di notte 'prendeva in prestito' la vernice dei murales per il suo capolavoro segreto. Lo convinci a restituire il maltolto: all'alba il quartiere si sveglia più colorato di prima, murales nuovi compresi. Il tizio, intervistato di nuovo, si prende tutto il merito: 'VE L'AVEVO DETTO, IO!' È diventato una celebrità del quartiere."
Scena: [DEDICATA] quartiere esploso di colori all'alba, il tizio di mezza età trionfante davanti alle telecamere, pet col barattolo di vernice in mano

---

# ADULTO — missioni da adulto (P3, stadio adulto; fail ≤15, super 32+, gate 45+/65+; Felicità std +5 / super +10)

Tutte scritte insieme, ruotano random per run (~15-17 attive dalle 32). Nuovi tag: cucina, paranormale, spazio, mistero. Nuovi perk (medagliette da super): Masterchef (cucina), Acchiappafantasmi (paranormale), Pony Express Galattico (Consegne), Astronauta (spazio). Le vie di super alt seguono la regola anti-ridondanza (build diversa dalla stat della soglia). Nuovi arredi/cibi/indossabili in coda al file, da aggiungere ad arredi.md/cibi.md.

## Missione 33: Torneo Mondiale di Arti Marziali
Brief: Il Palazzetto Mondiale si riempie di campioni che non guardano in faccia nessuno: il gong sta per suonare.
- Luogo: 📍 Palazzetto Mondiale
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: gara
- Durata: 2h
- Costo: 15 monete
- Dati: durata=2h ; costo=15 ; categoria=combattimento ; stat=forza ; tag=gara ; stadio=adulto

**Standard** — +3 Forza, −15 Salute (Ferite +15), +30 monete
Dati: reward= forza+3, ferite+15, monete+30, fel+5
Testo: "Il tabellone mondiale è un muro di campioni, e tu ci arrivi ai quarti a suon di parate e ginocchiate. Non vinci il titolo, ma tutti sanno il tuo nome, e qualche costola te lo ricorderà per un po'."
Scena: pet in guardia su un ring illuminato, tabellone dei match sullo sfondo

**Fallimento** (condizione: Forza ≤15) — Ferite +25, Bistecca (cibo, Forza+2)
Dati: cond= forza<=15 ; reward= ferite+25, cibo:Bistecca, fel-5
Testo: "Il gong suona e il primo avversario ti smonta come un mobile IKEA fatto male: pezzi ovunque e nessun manuale per rimetterti insieme. Fuori al primo turno, dolorante e mesto, mentre il pubblico applaude educatamente il tuo volo. Lo staff ti raccatta a bordo tatami e ti rimpolpa con un paio di bistecche 'per la ripresa'. Il torneo continua senza di te, ma le bistecche sono ottime."
Scena: pet ammaccato a bordo ring, un inserviente che gli porge del cibo

**Super successo** (condizione: Forza 32+; auto anche con perk Street Fighter [Combattimento] o Sabotatore [gara]) — +5 Forza, −10 Salute, +60 monete, Cintura Mondiale (indossabile, +3 Forza)
Dati: cond= forza>=32 ; reward= forza+5, ferite+10, monete+60, indossabile:Cintura Mondiale, fel+10
Testo: "Li stendi uno a uno con una facilità che imbarazza gli organizzatori. Sul podio più alto ti allacciano la cintura mondiale, pesante come un tombino e lucida il doppio."
Scena: [DEDICATA] pet trionfante con la cintura mondiale sollevata sopra la testa, folla in delirio

## Missione 34: Il Mostro del Lago Vaporoso
Brief: Qualcosa di grosso e viscido riemerge dal Lago Vaporoso, e ha decisamente troppi denti per essere amichevole.
- Luogo: 📍 Lago Vaporoso
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: mostro, natura
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=mostro,natura,companion ; stadio=adulto

**Standard** — +3 Forza, −18 Salute (Ferite +18), +25 monete, Trofeo Pinna (arredo bagno, +1 Forza +1 Felicità)
Dati: reward= forza+3, ferite+18, monete+25, arredo:Trofeo Pinna, fel+5
Testo: "Dal lago che ribolle emerge qualcosa di grosso, viscido e con troppi denti. Lo respingi a fatica, ne esci gonfio d'acqua e di lividi, ma con una pinna-trofeo strappata alla mischia."
Scena: pet che affronta una sagoma mostruosa tra i vapori del lago, spruzzi ovunque

**Fallimento** (condizione: Nerd + talento Idrofobico) — +1 Int, Sushi (cibo, Velocità+2)
Dati: priorita=1 ; cond= nerd & talento:idrofobico ; reward= int+1, cibo:Sushi, fel+5
Testo: "L'acqua? Assolutamente no: certe linee non si superano nemmeno per la gloria. Ti pianti sulla riva a braccia conserte e osservi il mostro col taccuino, prendendo appunti come un critico a teatro. Alla fine non lo combatti, ma sai tutto di lui: abitudini, orari, perfino il verso che fa quando sbadiglia. E soprattutto ti sei tenuto asciutto, che è già una vittoria."
Scena: pet sulla riva che prende appunti mentre il mostro sbuffa in acqua

**Fallimento** (condizione: Forza ≤15) — Ferite +28, Pesce alla griglia (cibo, Velocità+1), Collarone della Vergogna (indossabile, For+2 Car−2)
Dati: priorita=2 ; cond= forza<=15 ; reward= ferite+28, cibo:Pesce alla griglia, indossabile:Collarone della Vergogna, fel-5
Testo: "Il mostro ti afferra con un tentacolo annoiato, ti fa fare un giro di giostra panoramico sul lago e ti risputa sulla riva come un nocciolo d'oliva. Atterri con un rumore poco eroico, davanti a testimoni. Un pescatore, tra il divertito e il dispiaciuto, ti offre del pesce già cotto: 'tanto oggi il lago ha già pescato te'. Non hai battute pronte per rispondergli."
Scena: pet fradicio e stordito sulla riva, un pescatore che ride

**Super successo** (condizione: Forza 32+; auto anche con perk Cacciatore di Mostri [mostro]; via alt Gentile + talento Sussurra-Mostri) — +4 Forza, +40 monete, Mostro del Lago companion (arredo bagno, +2 Forza fisso)
Dati: cond= forza>=32 | (gentile & talento:sussurramostri) ; reward= forza+4, monete+40, arredo:Mostro del Lago, fel+10
Testo: "Non lo sconfiggi: lo CONVINCI. Tra una presa e uno sguardo (o due paroline dolci, se sei fatto così) il mostro capisce che con te non si scherza, e decide che gli stai pure simpatico. Torna a casa con te."
Scena: [DEDICATA] pet e mostro del lago che tornano insieme, il mostro che gli tiene l'ombrello

## Missione 35: Sparring col Campione in Ritiro
Brief: Il vecchio campione ritirato sul Monte non parla molto. Mena. E oggi tocca a te salire sul ring con lui.
- Luogo: 📍 Palestra sul Monte
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Durata: 2h
- Costo: 10 monete
- Dati: durata=2h ; costo=10 ; categoria=combattimento ; stat=forza ; stadio=adulto

**Standard** — +3 Forza, −15 Salute (Ferite +15), Guantoni Consumati (indossabile, +2 Forza)
Dati: reward= forza+3, ferite+15, indossabile:Guantoni Consumati, fel+5
Testo: "Il vecchio campione non parla molto: mena. Sei ore di sacco, corda e schivate, e alla fine ti lascia i suoi guantoni consumati con un cenno che vale più di un discorso."
Scena: pet che si allena col sacco, un vecchio pugile robusto che osserva a braccia conserte

**Fallimento** (condizione: Forza ≤15) — Ferite +25, Barretta proteica (cibo, Forza+1)
Dati: cond= forza<=15 ; reward= ferite+25, cibo:Barretta proteica, fel-5
Testo: "Al primo round sei convinto, al secondo speranzoso, al terzo capisci che 'in ritiro' non vuol dire 'debole': vuol dire che ha più tempo per allenarsi. Passi il resto della sessione a raccogliere i suoi asciugamani più che a combattere. Il campione ti congeda con una pacca che quasi ti ribalta e una barretta come unico premio. Da mangiare con dignità, se ne è rimasta."
Scena: pet spelacchiato che raccoglie asciugamani, il campione che si asciuga la fronte

**Super successo** (condizione: Forza 32+; via alt Nerd + talento Mente Analitica) — +5 Forza, Accappatoio del Campione (indossabile, +3 Forza)
Dati: cond= forza>=32 | (nerd & talento:menteanalitica) ; reward= forza+5, indossabile:Accappatoio del Campione, fel+10
Testo: "Lo studi colpo per colpo (o lo pareggi a forza bruta) finché il campione, per la prima volta da anni, incassa sul serio. Si toglie l'accappatoio e te lo lancia: 'tienilo. Te lo sei guadagnato'."
Scena: [DEDICATA] pet con l'accappatoio del campione sulle spalle, il vecchio pugile che annuisce con rispetto

## Missione 36: I Bulli del Racket
Brief: In Via del Mercato una banda spilla soldi ai negozianti banco per banco, e nessuno ha ancora osato fermarli.
- Luogo: 📍 Via del Mercato
- Razza: entrambe
- Categoria: Combattimento
- Stat coinvolta: Forza
- Tag: rapina
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=combattimento ; stat=forza ; tag=rapina ; stadio=adulto

**Standard** — +3 Forza, −15 Salute (Ferite +15), +35 monete (colletta dei negozianti)
Dati: reward= forza+3, ferite+15, monete+35, fel+5
Testo: "I bulli del racket spillano soldi a ogni banco del mercato. Tu li convinci a cambiare quartiere, a mani nude. I negozianti, riconoscenti, fanno una colletta al volo."
Scena: pet che affronta un gruppo di teppisti tra le bancarelle, negozianti che sbirciano

**Fallimento** (condizione: Forza ≤15) — Ferite +25, Torta intera (cibo, Carisma+3)
Dati: cond= forza<=15 ; reward= ferite+25, cibo:Torta intera, fel-5
Testo: "Sono in cinque e tu in uno: fai due conti veloci e la matematica ti consiglia caldamente la ritirata. Provi comunque a fare la voce grossa, e la voce ti esce piccolissima. Ti ritiri malconcio ma tutto intero, che coi bulli è già un risultato. La pasticciera del mercato ti consola con una torta intera 'per il coraggio' — il coraggio di esserci andato, precisa lei."
Scena: pet malconcio che si allontana, una fornaia che gli porge una torta

**Super successo** (condizione: Forza 32+; via alt Maleducato + talento Boss di Quartiere) — +4 Forza, +70 monete, Chiavi del Quartiere (arredo salone, +2 Carisma)
Dati: cond= forza>=32 | (maleducato & talento:bossdiquartiere) ; reward= forza+4, monete+70, arredo:Chiavi del Quartiere, fel+10
Testo: "Non li scacci: te li ASSUMI. Con la maniera forte (o con un'offerta che non possono rifiutare) il racket passa sotto di te, ma d'ora in poi protegge il quartiere invece di spennarlo. Ti danno pure le chiavi della città, simbolicamente."
Scena: [DEDICATA] pet al centro dei bulli ora rispettosi, chiavi del quartiere in mano

## Missione 37: Maratona dei Cinque Distretti
Brief: Quaranta chilometri, cinque distretti, zero scorciatoie: la maratona cittadina aspetta solo il colpo di pistola.
- Luogo: 📍 Città intera
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara
- Durata: 2h
- Costo: 10 monete
- Dati: durata=2h ; costo=10 ; categoria=sport ; stat=velocita ; tag=gara ; stadio=adulto

**Standard** — +3 Velocità, +30 monete, Medaglia del Finisher (arredo camera, +1 Velocità +1 Felicità)
Dati: reward= velocita+3, monete+30, arredo:Medaglia del Finisher, fel+5
Testo: "Quaranta chilometri, cinque distretti, un muro al trentesimo e la volontà di mollare a ogni incrocio. Ma tagli il traguardo, e la medaglia del finisher pesa come un'onorificenza."
Scena: pet stremato ma sorridente che taglia il traguardo, folla ai lati

**Fallimento** (condizione: Velocità ≤15) — +10 monete, Sushi (cibo, Velocità+2)
Dati: cond= velocita<=15 ; reward= monete+10, cibo:Sushi, fel-5
Testo: "Partenza da manuale, ritmo da campione... per due distretti. Al terzo le gambe presentano le dimissioni con effetto immediato, giusto davanti al ristoro. La buona notizia: quel ristoro ha un buffet leggendario, e tu ci rimani un tempo che nessuna classifica registrerà mai. La maratona finisce senza di te; il buffet, quasi."
Scena: pet accasciato accanto a un tavolo del ristoro pieno di cibo

**Super successo** (condizione: Velocità 32+; auto anche con Sabotatore [gara]; via alt Sportivo + talento Energico) — +5 Velocità, +60 monete, Scarpe d'Oro (indossabile, +3 Velocità)
Dati: cond= velocita>=32 | (sportivo & talento:energico) ; reward= velocita+5, monete+60, indossabile:Scarpe d'Oro, fel+10
Testo: "Non corri: fluttui. Superi il muro dei maratoneti come fosse un cartello stradale e tagli il traguardo con un vantaggio che imbarazza il secondo. Scarpe d'oro e un posto negli annali cittadini."
Scena: [DEDICATA] pet primo al traguardo con le scarpe dorate, cronometro con tempo record

## Missione 38: Olimpiadi di Quartiere
Brief: Corsa, salto, quiz, karaoke: le Olimpiadi di Quartiere sono un pentathlon assurdo che non perdona la fiacca.
- Luogo: 📍 Stadio Comunale
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: qualsiasi (tutte le prove)
- Tag: gara
- Durata: 2h
- Costo: 20 monete
- Nota: BOSS a gate (serve statMax alto)
- Dati: durata=2h ; costo=20 ; categoria=sport ; stat=qualsiasi ; tag=gara ; stadio=adulto ; ritenta=1

**Standard** (condizione: statMax 40+) — +2 a tutte le stat, +40 monete, Torcia Olimpica (arredo salone, +2 Felicità)
Dati: cond= statMax>=40 ; reward= forza+2, velocita+2, int+2, carisma+2, monete+40, arredo:Torcia Olimpica, fel+5
Testo: "Corsa, salto, quiz, karaoke: le Olimpiadi di quartiere sono un pentathlon assurdo. Chiudi tra i primi in tutto, versatile e sfiancato, e accendi la torcia olimpica sul balcone di casa."
Scena: pet multitasking tra più prove sportive, torcia olimpica accesa

**Fallimento** (condizione: statMax <40) — +15 monete, Scorta di Panini (cibo, 5 porzioni, +2 stat casuale), la missione resta in rosa
Dati: cond= statMax<40 ; reward= monete+15, cibo:Scorta di Panini, fel-5
Testo: "Eliminato alle qualifiche di ogni singola disciplina: tecnicamente è un record anche questo, solo in negativo. Persino nel lancio del peso, dove bastava lasciarlo cadere. Ma il buffet olimpico è leggendario, nessuno controlla il pass e tu hai ancora la tuta addosso: la giornata si chiude comunque da medaglia, almeno a tavola."
Scena: pet eliminato che si consola davanti a un tavolo del buffet olimpico

**Super successo** (condizione: statMax 65+; via alt Sportivo + talento Predestinato) — +3 a tutte le stat, +80 monete, Podio d'Oro (arredo salone, +2 a una stat RPG casuale ogni giorno), Mela Dorata Blocchettosa (cibo, +2 stat casuale)
Dati: cond= statMax>=65 | (sportivo & talento:predestinato) ; reward= forza+3, velocita+3, int+3, carisma+3, monete+80, arredo:Podio d'Oro, cibo:Mela Dorata Blocchettosa, fel+10
Testo: "Fai incetta di medaglie in ogni disciplina, dal sollevamento pesi al quiz di cultura generale. Il quartiere ti dedica un podio d'oro permanente in piazza — e in casa te ne tocca una copia che ti carica ogni mattina. Sul gradino più alto ti aspetta anche il premio dei premi: una mela d'oro tutta squadrata, di quelle che si mangiano solo quando si vince."
Scena: [DEDICATA] pet sul gradino più alto di un podio dorato coperto di medaglie

## Missione 39: Half-Pipe Contest
Brief: Rampa e aria allo Skatepark del Porto: gli sboroni locali aspettano solo la tua caduta per farsi due risate.
- Luogo: 📍 Skatepark del Porto
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sport ; stat=velocita ; tag=gara ; stadio=adulto

**Standard** — +3 Velocità, Skateboard Pro (arredo camera, +2 Velocità)
Dati: reward= velocita+3, arredo:Skateboard Pro, fel+5
Testo: "Rampa, aria, atterraggio (quasi) pulito: fai il tuo run tra applausi e qualche 'ohhh'. Non vinci, ma ti guadagni una tavola pro e il rispetto degli sboroni del porto."
Scena: pet a mezz'aria sopra la rampa dell'half-pipe, skater che guardano

**Fallimento** (condizione: Velocità ≤15) — Ferite +15, Sushi (cibo, Velocità+2)
Dati: cond= velocita<=15 ; reward= ferite+15, cibo:Sushi, fel-5
Testo: "Rincorsa perfetta, salto ambizioso, atterraggio... di faccia. Il faceplant è così epico che verrà clippato, rallentato e musicato per anni. Ti raccolgono dal fondo della rampa, ti spolverano con gentilezza e ti offrono del sushi 'per il coraggio (e per la faccia)'. La faccia ringrazierà, appena può."
Scena: pet lungo disteso sulla rampa dopo un capitombolo, skater che accorrono

**Super successo** (condizione: Velocità 32+; auto anche con perk Tony Hawk [Sport]; via alt Nerd + talento Roombo) — +5 Velocità, +50 monete, Tavola Leggendaria (indossabile, +3 Velocità)
Dati: cond= velocita>=32 | (nerd & talento:roombo) ; reward= velocita+5, monete+50, indossabile:Tavola Leggendaria, fel+10
Testo: "Il 900 ti riesce al primo colpo (o, se sei un tipo pratico, prima lucidi la rampa a specchio col robottino). Lo skatepark ammutolisce, poi esplode. Ti portano a casa in trionfo con la tavola leggendaria."
Scena: [DEDICATA] pet in posa vittoriosa sulla tavola sopra la rampa, folla in delirio

## Missione 40: Speedrun World Record
Brief: Cronometro acceso e chat mondiale sintonizzata: stanotte in sala giochi si tenta il record dello speedrun.
- Luogo: 📍 Sala Giochi (diretta mondiale)
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Velocità
- Tag: gara, social
- Durata: 2h
- Costo: 5 monete
- Dati: durata=2h ; costo=5 ; categoria=videogioco ; stat=velocita ; tag=gara,social ; stadio=adulto

**Standard** — +3 Velocità, +25 monete
Dati: reward= velocita+3, monete+25, fel+5
Testo: "Sei ore di tentativi, glitch cercati al frame e mani che tremano: sfiori il world record e ti fermi al personal best. La chat, però, ti adora."
Scena: pet con cuffie e controller davanti a uno schronometro che scorre, chat che scrolla

**Fallimento** (condizione: Velocità ≤15, oppure Maleducato + talento Bad Loser) — Sushi (cibo, Velocità+2)
Dati: cond= velocita<=15 | (maleducato & talento:badloser) ; reward= cibo:Sushi, fel-5
Testo: "Sbagli il trick al minuto tre e resetti. Poi di nuovo. E di nuovo, mentre la chat mondiale passa dal tifo alle battutine (o, se sei un Bad Loser, spacchi la tastiera in diretta planetaria). Il record resta lì dov'era, imbattuto e sarcastico. A fine serata ti restano solo del sushi, gli occhi rossi e un po' di vergogna da smaltire dormendo."
Scena: pet frustrato davanti allo schermo "RESET", chat piena di faccine

**Super successo** (condizione: Velocità 32+; auto anche con perk Player One [Videogioco] o Sabotatore [gara]; via alt Nerd + talento Overclock) — +5 Velocità, +60 monete, Tastiera d'Oro (arredo camera, +2 Velocità)
Dati: cond= velocita>=32 | (nerd & talento:overclock) ; reward= velocita+5, monete+60, arredo:Tastiera d'Oro, fel+10
Testo: "Run perfetta, frame perfetti, world record polverizzato in diretta mondiale (surriscaldandoti fino a fumare, se hai l'Overclock). La chat esplode, gli sponsor pure. Ti spedicono una tastiera d'oro massiccio."
Scena: [DEDICATA] pet trionfante col cronometro fermo su un tempo record, tastiera d'oro accanto

## Missione 41: La Notte del Cabinato Maledetto
Brief: A mezzanotte il cabinato che 'nessuno finisce vivo' si accende da solo, e il retro-arcade trattiene il fiato.
- Luogo: 📍 Retro-Arcade "Il Gettone Nero"
- Razza: entrambe
- Categoria: Videogioco
- Stat coinvolta: Intelligenza
- Tag: paranormale, mistero
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=videogioco ; stat=int ; tag=paranormale,mistero ; stadio=adulto

**Standard** — +3 Int, +25 monete, Gettone Nero (arredo salone, +1 Int +1 Felicità)
Dati: reward= int+3, monete+25, arredo:Gettone Nero, fel+5
Testo: "Il cabinato che 'nessuno finisce vivo' ti aspetta a mezzanotte. Scopri il segreto: il fantasma era un firmware corrotto. Risolvi il bug e ti tieni il gettone nero portafortuna."
Scena: pet illuminato dallo schermo di un cabinato inquietante in un arcade buio

**Fallimento** (condizione: Intelligenza ≤15) — Zuppa di verdure (cibo, Int+2), −5 Felicità
Dati: cond= int<=15 ; reward= cibo:Zuppa di verdure, fel-5
Testo: "Alle tre di notte il cabinato fa un rumore che NON dovrebbe fare, lo schermo si accende da solo, e qualcosa dentro di te decide per entrambi. Esci dall'arcade a velocità doppia senza voltarti mai, stabilendo il vero record della nottata. Il gestore, che evidentemente ne ha viste tante, ti manda a casa con della zuppa e tante scuse. Il cabinato, giurano i presenti, ride ancora."
Scena: pet che scappa dall'arcade nel buio, il cabinato che sfarfalla alle sue spalle

**Super successo** (condizione: Intelligenza 32+; auto anche con perk Player One [Videogioco]; via alt Nerd + talento Galaxy Brain) — +5 Int, +50 monete, Cabinato Maledetto (arredo salone, +2 Int; ogni tanto si accende da solo)
Dati: cond= int>=32 | (nerd & talento:galaxybrain) ; reward= int+5, monete+50, arredo:Cabinato Maledetto, fel+10
Testo: "Non solo lo finisci: decompili la maledizione riga per riga finché il fantasma, sconfitto e impressionato, ti lascia il cabinato in eredità. Ogni tanto, in salotto, si accende da solo. Ma ormai siete amici."
Scena: [DEDICATA] pet trionfante davanti al cabinato con la scritta "YOU WIN", un fantasmino pixel che applaude

## Missione 42: Scavo Archeologico Proibito
Brief: Sotto i binari della metro dorme una città sepolta che nessuno dovrebbe toccare — hai la torcia già in mano.
- Luogo: 📍 Rovine sotto la Metro
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: mistero
- Durata: 2h
- Costo: 10 monete
- Dati: durata=2h ; costo=10 ; categoria=studio ; stat=int ; tag=mistero ; stadio=adulto

**Standard** — +3 Int, +30 monete, Vaso Antico (arredo salone, +2 Int), Elmo del Centurione da Selfie (indossabile, Car+3 Int−1)
Dati: reward= int+3, monete+30, arredo:Vaso Antico, indossabile:Elmo del Centurione da Selfie, fel+5
Testo: "Sotto i binari della metro c'è una città sepolta che non dovresti toccare. Tu la tocchi con criterio: mappi, cataloghi, e riemergi con un vaso millenario e nessun crollo sulla coscienza."
Scena: pet con torcia e pennello tra rovine sotterranee, un vaso antico in primo piano

**Fallimento** (condizione: Intelligenza ≤15) — −10 monete (danni), Insalatona (cibo, Int+1)
Dati: cond= int<=15 ; reward= monete-10, cibo:Insalatona, fel-5
Testo: "Prendi in mano il reperto sbagliato — quello luccicante, ovviamente — e tutto il soffitto decide di scendere di livello, con te sotto. Esci strisciando, coperto di polvere millenaria e rimpianti recentissimi. Ti aspettano una multa per i danni e un'insalata di scuse, servita fredda quanto lo sguardo dell'archeologa capo. Il reperto, ironia della sorte, era un fermacarte."
Scena: pet impolverato che scappa da un crollo, un vaso rotto a terra

**Super successo** (condizione: Intelligenza 32+; auto anche con perk Doc Brown [Studio]; via alt Maleducato + talento Cleptomane) — +5 Int, +60 monete, Idolo Dorato (arredo salone, +3 Int, alto valore di rivendita)
Dati: cond= int>=32 | (maleducato & talento:cleptomane) ; reward= int+5, monete+60, arredo:Idolo Dorato, fel+10
Testo: "Decifri la mappa perduta e trovi la camera del tesoro (o, semplicemente, l'idolo dorato 'ti cade' nello zaino nel trambusto). Millenni di storia, e adesso illumina il tuo salotto."
Scena: [DEDICATA] pet che solleva un idolo dorato luminoso in una camera sepolta

## Missione 43: Il Razzo del Cortile
Brief: Lattine, colla e ambizione smisurata: nel cortile il conto alla rovescia per il lancio è già partito.
- Luogo: 📍 Cortile-Base di Lancio
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: invenzione, spazio
- Durata: 2h
- Costo: 20 monete
- Dati: durata=2h ; costo=20 ; categoria=studio ; stat=int ; tag=invenzione,spazio ; stadio=adulto

**Standard** — +3 Int, +30 monete (sponsor di quartiere), Modellino Razzo (arredo camera, +2 Int)
Dati: reward= int+3, monete+30, arredo:Modellino Razzo, fel+5
Testo: "Costruisci un razzo con lattine, colla e ambizione smisurata. Decolla storto ma decolla, e gli sponsor del quartiere ti pagano lo spettacolo. Il modellino resta in cameretta."
Scena: pet accanto a un razzo artigianale che sputa fumo, vicini che guardano dalle finestre

**Fallimento** (condizione: Intelligenza ≤15) — Ferite +15, Zuppa di verdure (cibo, Int+2)
Dati: cond= int<=15 ; reward= ferite+15, cibo:Zuppa di verdure, fel-5
Testo: "Countdown perfetto, accensione perfetta, e il razzo esplode sulla rampa in un fungo di fumo e coriandoli. Che spettacolo, però: i vicini applaudono il disastro dai balconi come fosse capodanno. Ti sciacquano la faccia annerita, ti sistemano le antenne bruciacchiate e ti offrono una zuppa. Il cortile profuma di polvere da sparo e di gloria mancata."
Scena: pet annerito e spettinato davanti a una rampa fumante, vicini che applaudono

**Super successo** (condizione: Intelligenza 32+; auto anche con talento Inventore [invenzione]; via alt Sportivo + talento Montaggio alla Rocky) — +5 Int, +70 monete, perk Astronauta (tag spazio: niente fallimento + sempre super successo nelle missioni tag spazio), Casco Spaziale (indossabile, +2 Int)
Dati: cond= int>=32 | (sportivo & talento:montaggioallarocky) ; reward= int+5, monete+70, perk:astronauta, indossabile:Casco Spaziale, fel+10
Testo: "Il razzo decolla dritto come un fuso e sfiora l'orbita (l'hai costruito in una notte di montaggio epico, se sei un tipo tenace). La città ti guarda dal basso a bocca aperta. Da oggi lo spazio è casa tua."
Scena: [DEDICATA] pet col casco spaziale accanto a un razzo perfetto che decolla verso le stelle

## Missione 44: Il Caso dei Gatti Scomparsi
Brief: Dodici gatti scomparsi e un quartiere in panico: il tuo pet indossa il trench da detective e parte a caccia di indizi.
- Luogo: 📍 Quartiere (indagine)
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: mistero, natura
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=studio ; stat=int ; tag=mistero,natura ; stadio=adulto

**Standard** — +3 Int, +30 monete (la gratitudine di 12 gatti)
Dati: reward= int+3, monete+30, fel+5
Testo: "Dodici gatti spariti, un quartiere in panico e un solo colpevole: il piccione cyborg, che li nascondeva per gelosia. Caso chiuso, gatti a casa, ricompensa incassata."
Scena: pet detective con lente d'ingrandimento tra gatti che tornano a casa

**Fallimento** (condizione: Intelligenza ≤15) — Biscotto (cibo, Carisma+1)
Dati: cond= int<=15 ; reward= cibo:Biscotto, fel-5
Testo: "Segui la pista sbagliata per cinque ore, con appostamenti, deduzioni e uno schema di fili rossi degno di un film. Poi arresti (metaforicamente) un cespuglio: aveva l'alibi di ferro di essere un cespuglio. I gatti intanto tornano a casa da soli, come da tradizione felina. I padroni, comunque grati per l'impegno, ti riempiono di biscotti e ti chiamano 'detective' senza ridere. Quasi."
Scena: pet perplesso davanti a una lavagna di indizi che non tornano

**Super successo** (condizione: Intelligenza 32+; auto anche con talento Amante della Natura [natura]; via alt Nerd + talento Mente Analitica) — +5 Int, +50 monete, Cappello da Detective (indossabile, +2 Int +1 Carisma)
Dati: cond= int>=32 | (nerd & talento:menteanalitica) ; reward= int+5, monete+50, indossabile:Cappello da Detective, fel+10
Testo: "Ricostruisci moventi, alibi e traiettorie (o semplicemente CHIEDI ai gatti dove sono stati). Sveli l'intera cospirazione felina e ti guadagni il cappello da detective ufficiale del quartiere."
Scena: [DEDICATA] pet col cappello da detective che indica il colpevole, gatti testimoni intorno

## Missione 45: La Laurea
Brief: Aula magna gremita, commissione arcigna, una tesi da difendere: il giorno della laurea è arrivato, e non si torna indietro.
- Luogo: 📍 Università di Città
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Durata: 2h
- Costo: 20 monete
- Nota: BOSS a gate (ritentabile dopo un fallimento)
- Dati: durata=2h ; costo=20 ; categoria=studio ; stat=int ; stadio=adulto ; ritenta=1

**Standard** (condizione: Intelligenza 45+) — +3 Int, Pergamena di Laurea (arredo salone, +3 Int), +30 monete (dai parenti)
Dati: cond= int>=45 ; reward= int+3, arredo:Pergamena di Laurea, monete+30, fel+5
Testo: "Aula magna piena, commissione arcigna, domande a tradimento. Discuti la tesi sudando bulloni e la porti a casa: la pergamena è tua, e nessuno potrà più dirti niente."
Scena: pet con toga tra i banchi dell'aula magna, commissione solenne

**Fallimento** (condizione: Intelligenza <45) — Cacio e Pepe Quantistica (cibo, Int+3), la missione resta in rosa
Dati: cond= int<45 ; reward= cibo:Cacio e Pepe Quantistica, fel-5
Testo: "Prime due domande: impeccabile. Terza domanda: il vuoto assoluto, di quelli che si sentono ronzare nella stanza. Balbetti qualcosa sulla fotosintesi dei robot — che non esiste, e adesso lo sanno tutti — e il relatore ti congeda con un mite 'ci rivediamo al prossimo appello'. Fuori i parenti ti aspettano comunque in festa, con una cacio e pepe scientificamente perfetta: la laurea può attendere, la cena no."
Scena: pet a capo chino fuori dall'aula, parenti che lo consolano

**Super successo** (condizione: Intelligenza 65+; via alt Maleducato + talento Lavoro in Nero) — 110 e lode: +5 Int, Pergamena di Laurea, +60 monete, Corona d'Alloro (indossabile, +2 Int +1 Carisma)
Dati: cond= int>=65 | (maleducato & talento:lavoroinnero) ; reward= int+5, arredo:Pergamena di Laurea, monete+60, indossabile:Corona d'Alloro, fel+10
Testo: "Reciti la tesi a memoria e correggi un refuso nel libro del presidente di commissione (con garbo). O, se sei un tipo pratico, l'ha scritta 'un amico' di notte, in nero. In ogni caso: 110 e lode, corona d'alloro, coscienza variabile."
Scena: [DEDICATA] pet con corona d'alloro sul podio dell'aula, commissione in piedi che applaude

## Missione 46: Ambasciatore delle Due Razze
Brief: Robot e alieni non si parlano da una generazione, e qualcuno deve fare da ponte diplomatico al Palazzo del Concilio.
- Luogo: 📍 Palazzo del Concilio
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=adulto

**Standard** — +3 Carisma, +35 monete
Dati: reward= carisma+3, monete+35, fel+5
Testo: "Robot e alieni non si parlano da una generazione, e tocca a te fare da ponte. Tra un brindisi e un fraintendimento diplomatico, il trattato di pace si firma anche grazie a te."
Scena: pet tra due delegazioni (robot e alieni) che si stringono la mano

**Fallimento** (condizione: Carisma ≤15) — Torta intera (cibo, Carisma+3)
Dati: cond= carisma<=15 ; reward= cibo:Torta intera, fel-5
Testo: "Confondi il saluto cerimoniale robot con l'insulto rituale alieno — un dettaglio, tipo dire 'buongiorno' e invece dichiarare guerra — e in tre secondi hai quasi riacceso una guerra fredda. Le delegazioni si alzano, i traduttori sudano, tu continui a sorridere nel modo sbagliato. Ti mandano a casa con una torta di scuse e un divieto d'ingresso a tempo indeterminato. La diplomazia non è il tuo forte; la torta sì."
Scena: pet imbarazzato tra due delegazioni offese, guardie che lo accompagnano fuori

**Super successo** (condizione: Carisma 32+; via alt Gentile + talento Pacifista; via alt flag pulito) — +5 Carisma, +70 monete, Medaglione del Concilio (indossabile, +3 Carisma)
Dati: cond= carisma>=32 | (gentile & talento:pacifista) | flag:pulito ; reward= carisma+5, monete+70, indossabile:Medaglione del Concilio, fel+10
Testo: "Con una frase giusta al momento giusto (o con una dolcezza disarmante) sciogli trent'anni di gelo. Le due razze firmano un'alleanza storica e ti appendono al collo il medaglione del Concilio."
Scena: [DEDICATA] pet col medaglione al collo tra le due delegazioni festanti, bandiere di pace

## Missione 47: Ospite al Talk Show di Prima Serata
Brief: Luci in sala, pubblico pronto e un conduttore che vive di battute: il tuo pet è ospite d'onore al talk show di prima serata.
- Luogo: 📍 Studi TV
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=adulto

**Standard** — +3 Carisma, +30 monete
Dati: reward= carisma+3, monete+30, fel+5
Testo: "Riflettori, applausi finti e un conduttore che vive di battutine. Tu regggi il gioco, piazzi un paio di aneddoti perfetti e la clip diventa virale entro sera."
Scena: pet sul divano di un talk show sotto le luci, conduttore che ride

**Fallimento** (condizione: Carisma ≤15) — Alette dell'Intervista Infuocata (cibo, Forza+2 Carisma+2)
Dati: cond= carisma<=15 ; reward= cibo:Alette dell'Intervista Infuocata, fel-5
Testo: "Il conduttore ti coccola per venti minuti e poi ti massacra con la domanda a tradimento, in diretta nazionale. Tu ti impappini con una grazia rara: sottotitoli impossibili, regia nel panico, un tecnico che ride fuori campo. Il pubblico, impietosito, ti fa portare il vassoio di alette incendiarie del segmento finale: se le domande non sai reggerle, almeno reggi il piccante. Domani sarai un meme, ma un meme che non ha pianto."
Scena: pet sudato sul divano mentre il conduttore sogghigna, pubblico che mormora

**Super successo** (condizione: Carisma 32+; auto anche con perk Influencer [social]; via alt Maleducato + talento Chissenefrega) — +5 Carisma, +60 monete, Poltrona del Talk (arredo salone, +2 Carisma)
Dati: cond= carisma>=32 | (maleducato & talento:chissenefrega) ; reward= carisma+5, monete+60, arredo:Poltrona del Talk, fel+10
Testo: "Prendi in mano la trasmissione: rispondi al conduttore con più carisma di lui (o, se non te ne frega niente del giudizio altrui, con una sfacciataggine che il pubblico ADORA). Ti regalano la poltrona dello studio."
Scena: [DEDICATA] pet che domina il talk show tra applausi scroscianti, conduttore spiazzato

## Missione 48: Elezioni di Quartiere
Brief: Comizi, strette di mano e promesse a raffica: è giorno di elezioni in piazza, e il tuo pet si candida a sindaco di quartiere.
- Luogo: 📍 Piazza Municipale
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: social
- Durata: 2h
- Costo: 20 monete
- Nota: BOSS a gate
- Dati: durata=2h ; costo=20 ; categoria=sociale ; stat=carisma ; tag=social ; stadio=adulto ; ritenta=1

**Standard** (condizione: Carisma 45+) — eletto: +3 Carisma, +50 monete, Fascia da Sindaco (indossabile, +2 Carisma +1 Int)
Dati: cond= carisma>=45 ; reward= carisma+3, monete+50, indossabile:Fascia da Sindaco, fel+5
Testo: "Comizi, baci ai cuccioli e promesse ragionevoli: la campagna funziona e ti eleggono sindaco di quartiere. La fascia tricolore ti sta pure bene."
Scena: pet su un palco elettorale con la fascia da sindaco, folla di sostenitori

**Fallimento** (condizione: Carisma <45) — Torta intera (cibo, Carisma+3), la missione resta in rosa
Dati: cond= carisma<45 ; reward= cibo:Torta intera, fel-5
Testo: "Perdi le elezioni contro il piccione cyborg, candidato a sorpresa con un programma monotematico sulle briciole. Il popolo ha parlato, e ha detto 'briciole'. È umiliante in un modo che nemmeno i libri di storia del quartiere sapranno raccontare. Ma c'è sempre il prossimo turno, e intanto il tuo comitato elettorale (tu) si consola con una torta."
Scena: pet sconfitto accanto a un manifesto del piccione cyborg vincitore

**Super successo** (condizione: Carisma 65+; via alt Maleducato + talento Faccia di Bronzo) — plebiscito: +5 Carisma, +80 monete, Fascia da Sindaco, Statua in Piazza (arredo salone, +3 Carisma)
Dati: cond= carisma>=65 | (maleducato & talento:facciadibronzo) ; reward= carisma+5, monete+80, indossabile:Fascia da Sindaco, arredo:Statua in Piazza, fel+10
Testo: "Vinci per plebiscito con un carisma travolgente (o con una campagna talmente spudorata, a promesse impossibili, che il quartiere ci casca in massa). Ti dedicano una statua in piazza, ancora calda."
Scena: [DEDICATA] pet che inaugura la propria statua in piazza, folla oceanica che acclama

## Missione 49: Headliner al Festival Rock
Brief: Un mare di telefoni accesi, un palco enorme e il nome del tuo pet in cima alla scaletta: stanotte si suona da headliner.
- Luogo: 📍 Palco Principale del Festival
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: musica, gara, social
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=musica,gara,social ; stadio=adulto

**Standard** — +3 Carisma, +40 monete, Chitarra Elettrica (arredo camera, +2 Carisma)
Dati: reward= carisma+3, monete+40, arredo:Chitarra Elettrica, fel+5
Testo: "Sei l'headliner del festival, davanti a uno stadio di lucine dei telefoni. Il concerto fila, la folla salta, e ti porti a casa una chitarra elettrica ancora fumante di assoli."
Scena: pet che suona su un palco enorme, mare di spettatori con luci alzate

**Fallimento** (condizione: Carisma ≤15) — Torta intera (cibo, Carisma+3), −5 Felicità
Dati: cond= carisma<=15 ; reward= cibo:Torta intera, fel-5
Testo: "Steccatura al primo pezzo, feedback assassino del microfono al secondo, fischi dal prato al terzo: una scaletta perfetta, del disastro. Scendi dal palco tra lanci di verdura assortita, schivandone giusto la metà. Nel backstage qualcuno ti allunga una torta, unico bottino della serata. Il rock è crudele; il catering, per fortuna, no."
Scena: pet mortificato che lascia il palco tra i fischi, un pubblico deluso

**Super successo** (condizione: Carisma 32+; auto anche con perk Singer [musica] o Sabotatore [gara]) — +5 Carisma, +80 monete, Chitarra Fiammante (indossabile, +3 Carisma)
Dati: cond= carisma>=32 ; reward= carisma+5, monete+80, indossabile:Chitarra Fiammante, fel+10
Testo: "L'assolo del secolo, il pubblico che canta il tuo nome, un bis dopo l'altro fino all'alba. Distruggi la chitarra sul palco per tradizione, e te ne regalano una fiammante ancora più bella."
Scena: [DEDICATA] pet rockstar in posa iconica con una chitarra fiammeggiante, stadio in delirio

## Missione 50: La Cucina dello Chef Urlante
Brief: Pentole che volano, uno chef che urla come fosse in guerra: il turno nella cucina del ristorante Bestiale non perdona.
- Luogo: 📍 Ristorante "Bestiale"
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Intelligenza
- Tag: cucina
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=int ; tag=cucina ; stadio=adulto

**Standard** — +3 Int, +35 monete, Set di Coltelli (arredo cucina, +2 Int)
Dati: reward= int+3, monete+35, arredo:Set di Coltelli, fel+5
Testo: "Lo chef urla, i piatti volano, il servizio è una trincea. Sopravvivi al turno mantenendo le dita al loro posto e ti guadagni un set di coltelli professionali."
Scena: pet in divisa da cuoco tra fiamme e pentole, uno chef enorme che urla sullo sfondo

**Fallimento** (condizione: Intelligenza ≤15, oppure Sportivo + talento Fissato con la Dieta) — Sganassone di Parmigiano (cibo, Forza+2)
Dati: cond= int<=15 | (sportivo & talento:fissatoconladieta) ; reward= cibo:Sganassone di Parmigiano, fel-5
Testo: "Bruci il burro nel burro, un'impresa che lo chef definisce 'scientificamente impossibile' un attimo prima di passare agli improperi (o ti rifiuti categoricamente di cucinare 'quella roba grassa', con identico risultato). Vieni cacciato dalla cucina a suon di padellate d'aria e sinonimi creativi di 'incapace'. Prima di sbatterti fuori, però, lo chef ti molla una pacca da spostare i mobili e una scaglia di parmigiano grossa come una mano aperta: 'e mo' impara, va'."
Scena: pet cacciato dalla cucina con un arrosto sottobraccio, chef paonazzo che urla

**Super successo** (condizione: Intelligenza 32+; via alt Nerd + talento Roombo) — +5 Int, +70 monete, perk Masterchef (tag cucina: niente fallimento + sempre super successo nelle missioni tag cucina), Cappello da Chef (indossabile, +2 Int)
Dati: cond= int>=32 | (nerd & talento:roombo) ; reward= int+5, monete+70, perk:masterchef, indossabile:Cappello da Chef, fel+10
Testo: "Servizio impeccabile, piatti da stella, postazione chirurgicamente pulita (col robottino aspiratutto lo chef si COMMUOVE). Il tiranno dei fornelli ti abbraccia in lacrime e ti incorona suo erede."
Scena: [DEDICATA] pet col cappello da chef che riceve l'abbraccio commosso dello chef urlante, cucina scintillante

## Missione 51: La Villa Infestata
Brief: La villa sulla collina ulula da trent'anni e il vicinato ne ha abbastanza: qualcuno deve salire lassù, di notte, e bussare.
- Luogo: 📍 Villa Abbandonata sulla Collina
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Carisma
- Tag: paranormale, mistero
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=carisma ; tag=paranormale,mistero,companion ; stadio=adulto

**Standard** — +3 Carisma, +35 monete
Dati: reward= carisma+3, monete+35, fel+5
Testo: "La villa ulula da trent'anni e il vicinato non ne può più. Sali, bussi (educato), e scopri che i fantasmi sono solo annoiati. Due chiacchiere, un regolamento condominiale, e la collina torna a dormire."
Scena: pet al tavolo con tre fantasmi lenzuolati che firmano un regolamento

**Fallimento** (condizione: Carisma ≤15) — Frullaviola del Malaugurio (cibo, Carisma+2 ma Ferite+5), −5 Felicità
Dati: cond= carisma<=15 ; reward= cibo:Frullaviola del Malaugurio, fel-5
Testo: "Il piano regge benissimo fino al primo BUUUH dal camino: a quel punto scendi la collina a una velocità che non sapevi di avere e che nessuno potrà certificare, perché era buio e urlavi. La villa resta infestata, tu resti scosso, pari e patta. La mattina dopo, sul tuo portone, un frullato viola ancora freddo e un bigliettino: 'scusa. — i fantasmi'. Educati, per essere fantasmi (il frullato, però, ti stende per dieci minuti buoni)."
Scena: pet in fuga scomposta dalla villa, fantasmi affacciati con aria colpevole

**Super successo** (condizione: Carisma 32+; via alt Gentile + talento Santo Subito) — +5 Carisma, +70 monete, perk Acchiappafantasmi (tag paranormale: niente fallimento + sempre super successo nelle missioni tag paranormale), Fantasmino companion (arredo camera, +2 Carisma fisso)
Dati: cond= carisma>=32 | (gentile & talento:santosubito) ; reward= carisma+5, monete+70, perk:acchiappafantasmi, arredo:Fantasmino, fel+10
Testo: "Non li convinci: li conquisti (o li esorcizzi con puro amore). A fine serata i fantasmi ti eleggono ospite d'onore, e il più piccolo fa le valigie (trasparenti) e si trasferisce da te."
Scena: [DEDICATA] pet che esce dalla villa all'alba con un fantasmino raggiante che gli svolazza intorno

## Missione 52: Rapina al Treno Blindato
Brief: Un treno blindato carico di lingotti sfreccia verso ponente, e il tuo pet è già sul tetto, pronto al colpo della vita.
- Luogo: 📍 Ferrovia di Ponente
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: rapina, inseguimento
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=rapina,inseguimento ; stadio=adulto

**Standard** — +3 Velocità, +50 monete
Dati: reward= velocita+3, monete+50, fel+5
Testo: "Un treno blindato pieno di lingotti, un tetto in corsa e un tempismo da orologiaio: il colpo riesce e la via di fuga è pulita. Nessuno saprà mai che eri tu."
Scena: pet che corre sul tetto di un treno in movimento al tramonto

**Fallimento** (condizione: Velocità ≤15) — −20 monete (multa), Fetta di Panino Gigante (cibo, +2 stat casuale)
Dati: cond= velocita<=15 ; reward= monete-20, cibo:Fetta di Panino Gigante, fel-5
Testo: "Piano studiato al millimetro, tempistiche perfette: peccato che sali sul vagone sbagliato — quello del buffet — e la tua determinazione si sciolga davanti agli antipasti. Ti beccano con la bocca piena e le briciole addosso come prova regina. Multa salata, orgoglio sotto i tacchi, carriera criminale finita sul nascere. Ma il panino, va detto a verbale, era buono davvero."
Scena: pet ammanettato con mezzo panino gigante in mano, controllori intorno

**Super successo** (condizione: Velocità 32+; auto anche con perk GTB [rapina] o Parkour Master [inseguimento]; via alt Maleducato + talento Mani Leste) — +5 Velocità, +100 monete, Sacco di Refurtiva (arredo salone, +1 Velocità, altissimo valore di rivendita)
Dati: cond= velocita>=32 | (maleducato & talento:manileste) ; reward= velocita+5, monete+100, arredo:Sacco di Refurtiva, fel+10
Testo: "Non solo svaligi il vagone blindato: ripulisci anche quello postale nel tempo che il macchinista impiega a starnutire. Sparisci nel nulla con un sacco di refurtiva grosso quanto te."
Scena: [DEDICATA] pet che salta giù dal treno in corsa con un enorme sacco di bottino, guardie beffate

## Missione 53: Demolizione Controllata
Brief: Un palazzo condannato aspetta solo una mazza e tanta cattiveria: oggi tocca al tuo pet tirarlo giù, mattone dopo mattone.
- Luogo: 📍 Palazzo Condannato
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=forza ; stadio=adulto

**Standard** — +3 Forza, +40 monete, −10 Igiene, Pettorina Catarifrangente (indossabile, Car+2 Int+1)
Dati: reward= forza+3, monete+40, igiene-10, indossabile:Pettorina Catarifrangente, fel+5
Testo: "Un palazzo condannato, una mazza e il permesso di sfogarti: lo tiri giù mattone dopo mattone in una nuvola di polvere. Paga bene, sporca peggio."
Scena: pet che abbatte un muro con una mazza enorme, polvere ovunque

**Fallimento** (condizione: Forza ≤15) — Ferite +20, −15 Igiene, Bistecca (cibo, Forza+2)
Dati: cond= forza<=15 ; reward= ferite+20, igiene-15, cibo:Bistecca, fel-5
Testo: "Studi i pilastri, scegli con cura, colpisci... quello sbagliato. Il palazzo decide di demolirsi da solo, in anticipo sul programma e con te dentro il programma. Ne esci da sotto una montagna di calcinacci, tossendo polvere e mezze scuse. I colleghi ti offrono una bistecca riparatrice: 'capita a tutti', mentono. Non capita a tutti."
Scena: pet che spunta da un cumulo di macerie, colleghi che accorrono

**Super successo** (condizione: Forza 32+; via alt perk Weapon Wielder con un'arma equipaggiata; via alt Sportivo + talento Veterano del Ring) — +5 Forza, +80 monete, Palla da Demolizione (arredo salone, +3 Forza)
Dati: cond= forza>=32 | (perk:weaponwielder & arma) | (sportivo & talento:veteranodelring) ; reward= forza+5, monete+80, arredo:Palla da Demolizione, fel+10
Testo: "Tiri giù l'intero palazzo con un pugno ben piazzato (senza prendere un graffio, se il corpo è temprato da una vita di botte). L'impresa ti regala la palla da demolizione come souvenir. Enorme."
Scena: [DEDICATA] pet in posa da eroe davanti al palazzo che crolla dietro, palla da demolizione al fianco

## Missione 54: I Gemelli Terribili
Brief: Fionde, colla nei capelli e un criceto scomparso: i gemelli terribili dell'attico di sopra aspettano solo la prossima vittima.
- Luogo: 📍 Attico dei Vicini Ricchi
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Carisma
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=carisma ; stadio=adulto

**Standard** — +3 Carisma, +40 monete
Dati: reward= carisma+3, monete+40, fel+5
Testo: "Fare da babysitter ai gemelli terribili del piano di sopra è una missione di guerra: fionde, colla nei capelli, un criceto scomparso. Ma li fai addormentare e la casa è (quasi) intera."
Scena: pet stremato tra due cuccioli scatenati che finalmente dormono

**Fallimento** (condizione: Carisma ≤15) — −10 monete (danni), Biscotto (cibo, Carisma+1)
Dati: cond= carisma<=15 ; reward= monete-10, cibo:Biscotto, fel-5
Testo: "In un'ora l'attico diventa un campo di battaglia: lampadario a terra, divano capovolto, gatto sul soffitto — non chiedere come, non lo sa nemmeno il gatto. I gemelli, freschi come rose, ti guardano con l'aria di chi ha appena iniziato. I genitori rientrano, valutano i danni, te li trattengono dalla paga e ti liquidano con un biscotto. Il gatto, per la cronaca, è ancora lassù."
Scena: pet sepolto sotto giocattoli e caos in un attico devastato, due cuccioli che ridono

**Super successo** (condizione: Carisma 32+; via alt Gentile + talento La Nonna Ti Vede; via alt Gentile + talento Coccolone) — +5 Carisma, +80 monete, Trofeo "Miglior Babysitter" (arredo camera, +2 Carisma), Maglione della Nonna Renna (indossabile, Car+2 Vel−1)
Dati: cond= carisma>=32 | (gentile & talento:lanonnativede) | (gentile & talento:coccolone) ; reward= carisma+5, monete+80, arredo:Trofeo Miglior Babysitter, indossabile:Maglione della Nonna Renna, fel+10
Testo: "Li ammansisci con un misto di autorità e dolcezza (o la nonna misteriosa appare e li doma in quattro minuti netti). Al rientro i genitori trovano casa perfetta e cuccioli angelici: sei una leggenda del babysitteraggio."
Scena: [DEDICATA] pet che riceve un trofeo dai genitori increduli, gemelli composti e sorridenti

## Missione 55: Consegna Orbitale
Brief: L'ascensore spaziale è rotto, ma il pacco in orbita va consegnato lo stesso, gravità zero compresa.
- Luogo: 📍 Stazione Orbitante
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Tag: spazio
- Durata: 2h
- Costo: 20 monete
- Dati: durata=2h ; costo=20 ; categoria=consegne ; stat=velocita ; tag=spazio ; stadio=adulto

**Standard** — +3 Velocità, +50 monete
Dati: reward= velocita+3, monete+50, fel+5
Testo: "Il pacco va consegnato in orbita, e l'ascensore spaziale è fuori uso. Ci arrivi con mezzi di fortuna, firma ritirata a gravità zero, e torni giù con le vertigini e la paga."
Scena: pet in tuta spaziale che consegna un pacco a una stazione orbitante, Terra sullo sfondo

**Fallimento** (condizione: Velocità ≤15) — −10 monete, Sushi (cibo, Velocità+2)
Dati: cond= velocita<=15 ; reward= monete-10, cibo:Sushi, fel-5
Testo: "Molli la presa per un istante — UN istante — e il pacco fluttua via nello spazio profondo, con l'eleganza lenta delle cose perdute per sempre. Lo guardi rimpicciolire e giureresti che ti stia salutando. Torni giù a mani vuote e con una multa che invece è arrivata puntualissima. Però da lassù hai visto il pianeta intero: quella vista non te la trattiene nessuno dalla paga."
Scena: pet che guarda impotente un pacco allontanarsi tra le stelle

**Super successo** (condizione: Velocità 32+; auto anche con perk Astronauta [spazio]) — +5 Velocità, +80 monete, perk Pony Express Galattico (categoria Consegne: niente fallimento + sempre super successo nelle missioni Consegne), Casco da Corriere Spaziale (indossabile, +2 Velocità)
Dati: cond= velocita>=32 ; reward= velocita+5, monete+80, perk:ponyexpressgalattico, indossabile:Casco da Corriere Spaziale, fel+10
Testo: "Schivi detriti orbitali, sfrutti la gravità come una fionda e consegni il pacco con dieci minuti d'anticipo sul record galattico. Ti nominano corriere ufficiale del sistema solare."
Scena: [DEDICATA] pet che sfreccia tra le stelle col pacco, stazione orbitante che applaude

## Missione 56: Il Pacco Maledetto
Brief: Un pacco che vibra e sussurra ti aspetta all'ultimo indirizzo della mappa: aprirlo o no, decidi tu.
- Luogo: 📍 Ultimo Indirizzo della Mappa
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Tag: paranormale
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=consegne ; stat=velocita ; tag=paranormale,companion ; stadio=adulto

**Standard** — +3 Velocità, +40 monete
Dati: reward= velocita+3, monete+40, fel+5
Testo: "Un pacco che vibra, sussurra e sconsiglia caldamente di essere aperto. Tu fai il tuo lavoro e lo consegni SENZA aprirlo, come un professionista. Bravissimo."
Scena: pet che consegna un pacco inquietante e pulsante a una porta buia

**Fallimento** (condizione: Velocità ≤15) — Biscotto (cibo, Carisma+1), −10 Felicità
Dati: cond= velocita<=15 ; reward= cibo:Biscotto, fel-10
Testo: "Lo apri. Ovviamente lo apri: c'era scritto NON APRIRE, che per te equivale a un invito con tanto di conferma richiesta. Ciò che ne esce ti fissa, ti cataloga e decide di seguirti a casa ogni notte per tre giorni — solo per fare rumore alle tre, comunque: maledizioni di provincia. Ti restano un biscotto, un brivido lungo la schiena e la certezza assoluta che lo riapriresti."
Scena: pet terrorizzato mentre un'ombra esce dal pacco aperto

**Super successo** (condizione: Velocità 32+; auto anche con perk Acchiappafantasmi [paranormale]; via alt Maleducato + talento Il Sonno degli Ingiusti) — +5 Velocità, +70 monete, Pacco Maledetto addomesticato (arredo camera, +2 a una stat RPG casuale ogni giorno)
Dati: cond= velocita>=32 | (maleducato & talento:ilsonnodegliingiusti) ; reward= velocita+5, monete+70, arredo:Pacco Maledetto, fel+10
Testo: "Consegni in tempo record senza un tremito (o ci dormi sopra così serenamente che la maledizione, offesa, se ne va da sola). Alla fine il pacco decide che gli piaci e si addomestica: ogni giorno ti regala energie diverse."
Scena: [DEDICATA] pet che tiene in braccio un pacco ora docile e luminoso, che gli fa le fusa

## Missione 57: Sagra del Peperoncino Esplosivo
Brief: La sagra del peperoncino esplosivo ti aspetta in piazza: fuoco in bocca, lacrime vere, pubblico assetato di dramma.
- Luogo: 📍 Piazza della Sagra
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Tag: cucina, gara
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=forza ; tag=cucina,gara ; stadio=adulto

**Standard** — +3 Forza, +25 monete, Salsa Infernale (cibo, Forza+2)
Dati: reward= forza+3, monete+25, cibo:Salsa Infernale, fel+5
Testo: "La gara di mangiatori di peperoncino esplosivo è un rito di passaggio doloroso. Reggi fino alla semifinale a suon di lacrime e boccate d'aria, e ti tieni una scorta di salsa infernale."
Scena: pet paonazzo che addenta un peperoncino gigante, pubblico che soffia via il fumo

**Fallimento** (condizione: Forza ≤15, oppure Sportivo + talento Fissato con la Dieta) — latte + Biscotto (cibo, Carisma+1)
Dati: cond= forza<=15 | (sportivo & talento:fissatoconladieta) ; reward= cibo:Latte, cibo:Biscotto, fel-5
Testo: "Primo peperoncino: sorridi fiero. Secondo peperoncino: vedi gli antenati, e gli antenati ti consigliano di smettere (o, se badi alla linea, ti rifiuti dal via: 'quello NON è cibo, è un'arma con lo stelo'). La sagra prosegue mentre tu respiri fuoco in un angolo, tra gli applausi. Ti spengono l'incendio interiore con un litro di latte e un biscotto. Il campione in carica, un nonnino, ti fa l'occhiolino."
Scena: pet con la lingua di fuori che tracanna latte, pubblico che ride

**Super successo** (condizione: Forza 32+; auto anche con perk Masterchef [cucina] o Sabotatore [gara]; via alt Maleducato + talento Chissenefrega) — +5 Forza, +60 monete, Cintura del Peperoncino (indossabile, +2 Forza)
Dati: cond= forza>=32 | (maleducato & talento:chissenefrega) ; reward= forza+5, monete+60, indossabile:Cintura del Peperoncino, fel+10
Testo: "Divori il peperoncino più letale della sagra senza battere ciglio (per te il dolore è un concetto astratto). Il pubblico ti incorona campione e ti allaccia la cintura del peperoncino, rossa come i tuoi avversari."
Scena: [DEDICATA] pet trionfante con la cintura del peperoncino, avversari sconfitti a bocca aperta

## Missione 58: Il Fantasma del Teatro dell'Opera
Brief: Da un secolo un fantasma sabota ogni recita del teatro dell'opera, e stasera tocca a te salire sul palco maledetto.
- Luogo: 📍 Teatro dell'Opera
- Razza: entrambe
- Categoria: Sociale
- Stat coinvolta: Carisma
- Tag: paranormale, musica
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sociale ; stat=carisma ; tag=paranormale,musica ; stadio=adulto

**Standard** — +3 Carisma, +35 monete
Dati: reward= carisma+3, monete+35, fel+5
Testo: "Un fantasma sabota ogni recita del teatro dell'opera da un secolo. Tu sali sul palco maledetto, canti la sua aria e lo convinci a fare pace col pubblico. Sipario, applausi."
Scena: pet che canta su un palco d'opera mentre un fantasma lo osserva dal loggione

**Fallimento** (condizione: Carisma ≤15) — Torta intera (cibo, Carisma+3)
Dati: cond= carisma<=15 ; reward= cibo:Torta intera, fel-5
Testo: "Il Do di petto ti esce come un citofono rotto, e dal loggione il fantasma ti fischia: umiliato da un morto, davanti a un teatro intero. Persino il suggeritore si nasconde nella buca. Scappi dietro le quinte inseguito da un'eco di risate d'oltretomba. Qualcuno, pietoso, ti ha lasciato una torta sul baule di scena: il teatro sarà crudele, ma ha stile."
Scena: pet mortificato sul palco mentre un fantasma fischia dall'alto

**Super successo** (condizione: Carisma 32+; auto anche con perk Acchiappafantasmi [paranormale] o Singer [musica]; via alt Nerd + talento Galaxy Brain) — +5 Carisma, +70 monete, Spartito Maledetto (arredo camera, +2 Carisma)
Dati: cond= carisma>=32 | (nerd & talento:galaxybrain) ; reward= carisma+5, monete+70, arredo:Spartito Maledetto, fel+10
Testo: "Impari l'aria maledetta a memoria in una notte e la duetti col fantasma in un finale da brividi veri. Il teatro trema di applausi (vivi e non), e il fantasma ti dona il suo spartito, ormai in pace."
Scena: [DEDICATA] pet e fantasma che cantano insieme sul palco, teatro in piedi ad applaudire

## Missione 59: Tour de Pizza
Brief: Venti pizze, mezza città, trenta minuti sul cronometro: il tour de pizza non aspetta nessuno.
- Luogo: 📍 Pizzeria del Porto
- Razza: entrambe
- Categoria: Consegne
- Stat coinvolta: Velocità
- Tag: cucina
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=consegne ; stat=velocita ; tag=cucina ; stadio=adulto

**Standard** — +3 Velocità, +40 monete, Pizza (cibo, +1 stat casuale)
Dati: reward= velocita+3, monete+40, cibo:Pizza, fel+5
Testo: "Venti pizze, mezza città, trenta minuti o è gratis: il tour de pizza è una corsa contro il forno che si raffredda. Le consegni quasi tutte calde, e una te la tieni."
Scena: pet in motorino carico di pizze che sfreccia per la città al tramonto

**Fallimento** (condizione: Velocità ≤15) — −10 monete, Pizza Ananassa (cibo, +40 Fame ma Carisma−2)
Dati: cond= velocita<=15 ; reward= monete-10, cibo:Pizza Ananassa, fel-5
Testo: "Parti sparato, ma il traffico, un cane molesto e una scorciatoia bugiarda ti mangiano tutto il vantaggio. Arrivi con le pizze fredde e mosce come cartoni bagnati: i clienti le sollevano, le guardano afflosciarsi e non pagano. Ti mangi la delusione, che almeno è calda. Una pizza (fredda) te la porti comunque a casa: è quella che nessuno ha reclamato, con l'ananas sopra. Riscaldata, quasi commestibile."
Scena: pet mogio con una torre di scatole di pizza floscia, cliente contrariato sulla porta

**Super successo** (condizione: Velocità 32+; auto anche con perk Pony Express Galattico [Consegne]; via alt perk Masterchef) — +5 Velocità, +80 monete, Portapizze d'Oro (arredo cucina, +2 Velocità)
Dati: cond= velocita>=32 ; reward= velocita+5, monete+80, arredo:Portapizze d'Oro, fel+10
Testo: "Consegni tutte le venti pizze bollenti in tempo record, ricuocendo al volo sul motorino quelle che si raffreddavano (se te ne intendi di cucina). La pizzeria ti nomina fattorino dell'anno e ti dà un portapizze d'oro."
Scena: [DEDICATA] pet trionfante col portapizze d'oro, clienti felici con pizze fumanti

## Missione 60: Allerta Meteorite
Brief: Il conto alla rovescia dell'osservatorio è già partito: un meteorite punta dritto sul quartiere.
- Luogo: 📍 Osservatorio del Colle
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: spazio, invenzione
- Durata: 2h
- Costo: 20 monete
- Dati: durata=2h ; costo=20 ; categoria=studio ; stat=int ; tag=spazio,invenzione ; stadio=adulto

**Standard** — +3 Int, +50 monete, Frammento di Meteorite (arredo salone, +2 Int)
Dati: reward= int+3, monete+50, arredo:Frammento di Meteorite, fel+5
Testo: "Un meteorite punta dritto sul quartiere e tocca a te calcolare come deviarlo. Traiettoria corretta all'ultimo secondo: il sasso cosmico manca la città per un pelo e te ne lascia un frammento."
Scena: pet all'osservatorio davanti a calcoli e a un meteorite in avvicinamento nel cielo

**Fallimento** (condizione: Intelligenza ≤15) — Ferite +10, Zuppa di verdure (cibo, Int+2)
Dati: cond= int<=15 ; reward= ferite+10, cibo:Zuppa di verdure, fel-5
Testo: "Sbagli il calcolo della traiettoria con la sicurezza dei grandi: una virgola di qua, una catastrofe di là. Per fortuna sbaglia anche il meteorite, che snobba il quartiere e finisce in mare con un tonfo da applausi. Il tuo contributo alla salvezza planetaria: zero, ma lo spavento è tutto vero. Ne esci con qualche graffio e una zuppa per calmare i nervi: salvo per fortuna, non per merito. Succede ai migliori."
Scena: pet che si copre la testa mentre un meteorite sfreccia via, calcoli sbagliati sparsi

**Super successo** (condizione: Intelligenza 32+; auto anche con perk Astronauta [spazio] o talento Inventore [invenzione]; via alt Sportivo + talento Furia Cieca con Felicità <30) — +5 Int, +90 monete, Nucleo del Meteorite (arredo salone, +2 a una stat RPG casuale ogni giorno)
Dati: cond= int>=32 | (sportivo & talento:furiacieca & fel<30) ; reward= int+5, monete+90, arredo:Nucleo del Meteorite, fel+10
Testo: "Calcoli la deviazione perfetta con margine di sicurezza da manuale (o, se sei incavolato abbastanza, sali sul tetto e lo RESPINGI A PUGNI). Il quartiere è salvo e tu ti tieni il nucleo del meteorite, che pulsa di energia aliena."
Scena: [DEDICATA] pet eroe che tiene in mano un nucleo di meteorite luminoso, cittadini che esultano

## Missione 61: Caccia al Tesoro Cittadina
Brief: Cento concorrenti, una città intera, un solo tesoro: la caccia parte ora e nessuno gioca pulito.
- Luogo: 📍 Città intera
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Velocità
- Tag: mistero, inseguimento
- Durata: 1h30
- Costo: gratis
- Dati: durata=1.5h ; costo=0 ; categoria=lavoretti ; stat=velocita ; tag=mistero,inseguimento ; stadio=adulto

**Standard** — +3 Velocità, +35 monete, Mappa Incorniciata (arredo salone, +1 Velocità +1 Int)
Dati: reward= velocita+3, monete+35, arredo:Mappa Incorniciata, fel+5
Testo: "Una caccia al tesoro per tutta la città, con altri cento concorrenti sui tuoi tacchi. Corri da un indizio all'altro e chiudi sul podio, con una mappa da incorniciare come ricordo."
Scena: pet che corre con una mappa in mano tra i vicoli, altri concorrenti alle spalle

**Fallimento** (condizione: Velocità ≤15) — Sushi (cibo, Velocità+2)
Dati: cond= velocita<=15 ; reward= cibo:Sushi, fel-5
Testo: "Secondo sul primo indizio, secondo sul terzo, secondo su TUTTI: sempre lo stesso rivale, sempre di un soffio, una tortura sportiva progettata da qualche divinità dispettosa. Al traguardo il tesoro se lo prende lui, con un sorrisetto che ti porterai dentro a lungo. A te restano del sushi, tanta frustrazione e la mappa ormai più inutile della città. Il secondo posto è il primo dei... no, lascia stare."
Scena: pet col fiatone che arriva a un indizio già preso da un rivale che esulta

**Super successo** (condizione: Velocità 32+; auto anche con perk Parkour Master [inseguimento]; via alt perk Doc Brown) — +5 Velocità, +70 monete, Forziere del Tesoro (arredo salone, +2 Velocità), Berrettone a Punta dell'Eroe Muto (indossabile, Int+2 Vel+1)
Dati: cond= velocita>=32 ; reward= velocita+5, monete+70, arredo:Forziere del Tesoro, indossabile:Berrettone a Punta dell'Eroe Muto, fel+10
Testo: "Sfrecci da un indizio all'altro anticipando tutti (o decifri l'ULTIMO enigma ancora prima di leggere il primo, se hai la testa giusta). Il forziere è tuo, e i cento concorrenti mangiano la polvere."
Scena: [DEDICATA] pet che apre un forziere luminoso per primo, rivali distanti che arrancano

## Missione 62: La Colonia in Cantina
Brief: Qualcosa si è insediato in cantina: una colonia di micro-mostri di spazzatura che nessuno sa ancora spiegare.
- Luogo: 📍 Cantina Condominiale
- Razza: entrambe
- Categoria: Studio
- Stat coinvolta: Intelligenza
- Tag: mostro
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=studio ; stat=int ; tag=mostro,companion ; stadio=adulto

**Standard** — +3 Int, +30 monete
Dati: reward= int+3, monete+30, fel+5
Testo: "In cantina è nata una colonia di micro-mostri di spazzatura, e prima di sfrattarli va capito cosa sono. Li cataloghi con metodo scientifico, poi li reindirizzi gentilmente altrove."
Scena: pet con lente e taccuino che studia minuscole creaturine tra i rottami di una cantina

**Fallimento** (condizione: Intelligenza ≤15) — −10 monete (danni), Biscotto (cibo, Carisma+1)
Dati: cond= int<=15 ; reward= monete-10, cibo:Biscotto, fel-5
Testo: "Li studi con pazienza scientifica; loro studiano te con pazienza superiore. Mentre prendi appunti, la colonia trasloca in massa nel tuo frigo, che ora ronza di vita propria e non si apre più senza negoziato. I condomini ti trattengono i danni e ti pregano gentilmente di smettere di 'aiutare'. Ti danno anche dei biscotti, a patto che tu li mangi lontano dalla cantina."
Scena: pet sconcertato che apre un frigo brulicante di micro-mostri

**Super successo** (condizione: Intelligenza 32+; auto anche con perk Cacciatore di Mostri [mostro] o Doc Brown [Studio]) — +5 Int, +60 monete, Micro-Mostro Regina companion (arredo camera, +2 Int fisso)
Dati: cond= int>=32 ; reward= int+5, monete+60, arredo:Micro-Mostro Regina, fel+10
Testo: "Riconosci ogni specie a occhio nudo, ne mappi la gerarchia e comunichi con la Regina della colonia, che decide di adottarti. Se la porti a casa: è brutta, ma tiene lucida la cantina e ti fa compagnia."
Scena: [DEDICATA] pet con una piccola creatura-regina sulla spalla, cantina ordinata alle spalle

## Missione 63: Il Grande Blackout
Brief: Blackout totale, quartiere al buio: il generatore va rimesso in moto stanotte, a forza di braccia.
- Luogo: 📍 Centrale del Quartiere
- Razza: entrambe
- Categoria: Lavoretti
- Stat coinvolta: Forza
- Durata: 2h (notturna)
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=lavoretti ; stat=forza ; stadio=adulto

**Standard** — +3 Forza, +45 monete, −10 Igiene
Dati: reward= forza+3, monete+45, igiene-10, fel+5
Testo: "Blackout totale, quartiere al buio, generatore da rimettere in moto a forza di braccia. Manovri ingranaggi arrugginiti tutta la notte finché le luci non tornano, unto fino ai gomiti."
Scena: pet che gira una manovella gigante di un generatore, quartiere buio sullo sfondo

**Fallimento** (condizione: Forza ≤15) — Ferite +15, Arrosto (cibo multi-porzione, ×3 Forza+1)
Dati: cond= forza<=15 ; reward= ferite+15, cibo:Arrosto, fel-5
Testo: "Il volano del generatore è più testardo di te, e alla terza spinta ti scaraventa contro un muro con disinvoltura meccanica. Il quartiere resta al buio, tu resti al tappeto, il generatore resta fermo: tre sconfitte al prezzo di una. Ma i vicini accendono le candele, ti raccolgono e ti rimettono in sesto con un arrosto della nonna. Al buio, sa ancora di più di casa."
Scena: pet steso accanto a un generatore fermo, vicini con candele e un arrosto

**Super successo** (condizione: Forza 32+; via alt Gentile + talento Cuore di Casa) — +5 Forza, +80 monete, Generatore di Scorta (arredo salone, +2 Forza)
Dati: cond= forza>=32 | (gentile & talento:cuoredicasa) ; reward= forza+5, monete+80, arredo:Generatore di Scorta, fel+10
Testo: "Rimetti in moto il generatore con uno strappo erculeo e le luci esplodono di vita (o, se sei un tipo caloroso, apri casa a tutti e il blackout diventa la festa dell'anno). Il quartiere ti regala un generatore di scorta tutto tuo."
Scena: [DEDICATA] pet eroe illuminato dalle luci tornate, quartiere che esulta alle finestre

## Missione 64: Regata dei Rottami
Brief: Al Porto Vecchio si gareggia con barche di rottami: l'unica regola è che nessuna dovrebbe davvero galleggiare.
- Luogo: 📍 Porto Vecchio
- Razza: entrambe
- Categoria: Sport
- Stat coinvolta: Velocità
- Tag: gara, invenzione, natura
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=sport ; stat=velocita ; tag=gara,invenzione,natura ; stadio=adulto

**Standard** — +3 Velocità, +35 monete, Timone di Fortuna (arredo bagno, +2 Velocità)
Dati: reward= velocita+3, monete+35, arredo:Timone di Fortuna, fel+5
Testo: "Regola unica della Regata dei Rottami: la barca te la costruisci coi rifiuti. La tua — mezza vasca e un'anta d'armadio — galleggia per miracolo e chiude a metà classifica. Il timone te lo tieni."
Scena: pet al timone di una barca fatta di rottami, altre imbarcazioni ridicole intorno

**Fallimento** (condizione: Velocità ≤15) — Sushi (cibo, Velocità+2)
Dati: cond= velocita<=15 ; reward= cibo:Sushi, fel-5
Testo: "La tua barca ha un difetto di progettazione minuscolo, quasi un dettaglio: non galleggia. Lo scopri a tre metri dal molo, davanti a tutti, affondando con l'eleganza di un sasso. La regata prosegue senza di te mentre fai amicizia con le alghe del porto. Ti ripescano col retino grande — quello per i casi speciali — e ti avvolgono in un asciugamano col sushi. La barca riposa sul fondale, imbattuta."
Scena: pet zuppo avvolto in un asciugamano sul molo, la sua barca che affonda dietro

**Super successo** (condizione: Velocità 32+; auto anche con Sabotatore [gara] o talento Inventore [invenzione]; via alt perk Popeye) — +5 Velocità, +70 monete, Vela Leggendaria (arredo salone, +2 Velocità +1 Felicità), Cappellone di Paglietta (indossabile, For+1 Car+2)
Dati: cond= velocita>=32 ; reward= velocita+5, monete+70, arredo:Vela Leggendaria, indossabile:Cappellone di Paglietta, fel+10
Testo: "La tua carretta non dovrebbe galleggiare e invece VOLA, tagliando ogni boa al pelo (o, a metà gara col vento morto, apri la scorta di spinaci e la fai RISALIRE remando come un fuoribordo). Il porto racconta ancora di quel giorno."
Scena: [DEDICATA] pet che taglia il traguardo in piedi sulla sua carretta, vela rattoppata gonfia, porto in delirio

---

# GRANDI IMPRESE — il finale della run (P3; 1 estratta a caso tra le 2 della personalità, pin fisso sulla mappa da adulto)

## Missione 65: La Palestra degli Dei
Brief: In cima al Monte Mascellone c'è LUI: Giga Ciad, mascella al vento, pronto a giudicarti con un solo sguardo.
- Luogo: 📍 Monte Mascellone
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Forza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=forza ; stadio=adulto ; impresa=1 ; personalita=sportivo ; ritenta=1

**Fallimento** (condizione: Forza <50) — Bistecca ×2
Dati: cond= forza<50 ; reward= cibo:Bistecca, cibo:Bistecca, fel-5
Testo: "In cima al Monte Mascellone c'è LUI: Giga Ciad, mascella al vento, che solleva un macigno col mignolo. Provi a imitarlo e il macigno non si muove di un millimetro. Giga Ciad ti guarda, annuisce lento, e ti porge due bistecche: 'Torna quando sei pronto, piccolo re.'"
Scena: pet minuscolo che spinge un macigno immobile, Giga Ciad gigantesco in controluce che annuisce

**Standard** — +5 Forza, +150 monete, Medaglia dell'Impresa
Dati: reward= forza+5, monete+150, fel+5
Testo: "Sollevi il macigno. Non con eleganza, non senza rumori preoccupanti della schiena, ma lo sollevi. Giga Ciad versa una lacrima virile e ti dichiara 'degno della Palestra degli Dei'. La mascella, giura, un giorno arriverà."
Scena: pet che regge un macigno sopra la testa al tramonto, Giga Ciad che applaude lento

**Super successo** (condizione: Forza 70+; via alt Carisma 45+ — la gara di pose) — +5 Forza, +150 monete, Giga Ciad companion (+3 Forza fisso), Bistecca Salabraccio d'Oro (cibo, Forza+4 Carisma+1)
Dati: cond= forza>=70 | carisma>=45 ; reward= forza+5, monete+150, arredo:Giga Ciad, cibo:Bistecca Salabraccio d'Oro, fel+10
Testo: "O sollevi il macigno CON UNA MANO, o lo batti sul suo terreno: la gara di pose. Profilo, tre quarti, sguardo all'orizzonte. Giga Ciad si commuove in bianco e nero: 'Non vedevo una posa così dal 1987.' Per festeggiare taglia una bistecca ricoperta d'oro facendo scivolare il sale lungo l'avambraccio, con una lentezza che sembra una preghiera. Da oggi si allena a casa tua."
Scena: [DEDICATA] pet in posa plastica su un piedistallo, Giga Ciad in bianco e nero che si asciuga una lacrima

## Missione 66: L'Ultimo Round
Brief: Rocco Baldoria ha novant'anni e guantoni più vecchi di te: sul ring del Porto Vecchio non conosce sconti.
- Luogo: 📍 Arena del Porto Vecchio
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Forza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=forza ; stadio=adulto ; impresa=1 ; personalita=sportivo ; ritenta=1

**Fallimento** (condizione: Forza <50) — Ferite +12, Zuppa ×2
Dati: cond= forza<50 ; reward= ferite+12, cibo:Zuppa della Nonna, cibo:Zuppa della Nonna, fel-5
Testo: "Rocco Baldoria ha novant'anni e i guantoni più vecchi di te. Al terzo round sei al tappeto che conti i lampadari. Lui ti tira su, ti mette una zuppa in mano: 'Non è questione di quanto forte colpisci, ragazzino. Riprova.'"
Scena: pet al tappeto che vede le stelle, Rocco anziano chinato su di lui col guantone teso

**Standard** — +5 Forza, +150 monete, Medaglia dell'Impresa
Dati: reward= forza+5, monete+150, fel+5
Testo: "Ultimo round. Le gambe tremano, l'arena urla, Rocco picchia come un treno d'epoca. Ma stavolta resti in piedi fino alla campana. Lui abbassa i guantoni e sorride: 'Hai un bel destro. Ma soprattutto hai un bel PERCHÉ.'"
Scena: pet e Rocco al centro del ring alla campana finale, folla in delirio

**Super successo** (condizione: Forza 70+; via alt talento Veterano del Ring — incassare, non colpire) — +5 Forza, +150 monete, Rocco Baldoria companion (+3 Forza fisso)
Dati: cond= forza>=70 | talento:veteranodelring ; reward= forza+5, monete+150, arredo:Rocco Baldoria, fel+10
Testo: "Non vinci ai punti: vinci alla LEGGENDA. Incassi tutto quello che ha, round dopo round, senza mai arretrare — e alla fine è LUI a togliersi i guantoni. 'In sessant'anni non ho mai visto nessuno incassare così. Ti alleno io, a casa tua.'"
Scena: [DEDICATA] Rocco che alza il braccio del pet al cielo, guantoni appesi alle corde

## Missione 67: L'Esorcismo del Grattacielo
Brief: Il Grattacielo Maledetto urla dal quarantesimo piano in su, e Padre Maronno ti aspetta sul portone.
- Luogo: 📍 Grattacielo Maledetto
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Carisma
- Tag: paranormale
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=carisma ; tag=paranormale ; stadio=adulto ; impresa=1 ; personalita=gentile ; ritenta=1

**Fallimento** (condizione: Carisma <50) — Biscotto ×3
Dati: cond= carisma<50 ; reward= cibo:Biscotto, cibo:Biscotto, cibo:Biscotto, fel-5
Testo: "Padre Maronno ti squadra: 'MARONN'! Tu vuoi parlare coi demoni del quarantesimo piano? Loro non parlano: URLANO.' Al decimo piano scappi con le orecchie che fischiano. I fantasmi, dispiaciuti, ti lasciano dei biscotti sull'ascensore."
Scena: pet che schizza fuori dal portone del grattacielo, finestre che lampeggiano viola

**Standard** — +5 Carisma, +150 monete, Medaglia dell'Impresa
Dati: reward= carisma+5, monete+150, fel+5
Testo: "Piano per piano, demone per demone: ascolti, annuisci, offri il tè. All'ultimo piano il Demone Capo firma la pace e Padre Maronno resta senza parole (quasi): 'MARONN'... in trent'anni di mestiere, mai visto un esorcismo A PAROLE BUONE.'"
Scena: pet che serve il tè a un demone enorme all'attico, Padre Maronno a bocca aperta sulla porta

**Super successo** (condizione: Carisma 70+; via alt talento Santo Subito — un miracolo al momento giusto) — +5 Carisma, +150 monete, Padre Maronno companion (+3 Carisma fisso)
Dati: cond= carisma>=70 | talento:santosubito ; reward= carisma+5, monete+150, arredo:Padre Maronno, fel+10
Testo: "I demoni non se ne vanno: SI TRASFERISCONO, con le buone maniere e un contratto d'affitto regolare al piano -1. Padre Maronno si fa il segno della croce due volte: 'Questo non è un esorcismo, è un MIRACOLO condominiale. Io e te, d'ora in poi, lavoriamo insieme.'"
Scena: [DEDICATA] Padre Maronno e pet davanti al grattacielo pacificato, demoni che salutano dalle finestre

## Missione 68: La Corsa Infinita
Brief: Da tre anni Forrest Gampo corre senza fermarsi sulla Statale del Tramonto: oggi tocca a te tenergli il passo.
- Luogo: 📍 Strada Statale del Tramonto
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Carisma
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=carisma ; stadio=adulto ; impresa=1 ; personalita=gentile ; ritenta=1

**Fallimento** (condizione: Carisma <50) — Scatola di Cioccolatini
Dati: cond= carisma<50 ; reward= cibo:Scatola di Cioccolatini, fel-5
Testo: "Forrest Gampo corre da tre anni e la gente lo segue perché... boh, perché è Forrest. Provi a unirti al gruppo ma dopo dieci chilometri nessuno si ricorda il tuo nome. Forrest rallenta, ti allunga una scatola: 'La vita è come una scatola di cioccolatini. Riprova domani.'"
Scena: pet piegato in due sul ciglio della statale, il gruppo di corridori che si allontana nel tramonto

**Standard** — +5 Carisma, +150 monete, Medaglia dell'Impresa
Dati: reward= carisma+5, monete+150, fel+5
Testo: "Corri accanto a Forrest per un giorno intero, e la cosa strana succede: la gente comincia a seguire TE. Alla fine della statale c'è una piccola folla che scandisce il tuo nome. Forrest annuisce: 'Corri bene. Ma soprattutto, la gente ti CREDE.'"
Scena: pet in testa a un gruppo di corridori al tramonto, Forrest che sorride in seconda fila

**Super successo** (condizione: Carisma 70+; via alt Velocità 45+ — la build del corridore) — +5 Carisma, +150 monete, Forrest Gampo companion (+3 Velocità fisso)
Dati: cond= carisma>=70 | velocita>=45 ; reward= carisma+5, monete+150, arredo:Forrest Gampo, fel+10
Testo: "A metà strada Forrest si ferma di colpo, come quel giorno famoso. Si volta verso la folla, poi verso di te: 'Sono un po' stanchino. Continua tu.' E la corsa infinita, da oggi, ha il tuo nome. Forrest ti segue a casa: dice che gli ricordi qualcuno."
Scena: [DEDICATA] Forrest che passa idealmente il testimone al pet in mezzo alla statale, folla commossa

## Missione 69: La Foto del Secolo
Brief: Una foto vale un tesoro: Fabrice The Crown si è murato nella Suite Reale e la scorta non scherza.
- Luogo: 📍 Suite Reale dell'Hotel Splendido
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Velocità
- Tag: inseguimento, social
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=velocita ; tag=inseguimento,social ; stadio=adulto ; impresa=1 ; personalita=maleducato ; ritenta=1

**Fallimento** (condizione: Velocità <50) — multa −20 monete, Foto Autografata di Fabrice (arredo, +1 Carisma)
Dati: cond= velocita<50 ; reward= monete-20, arredo:Foto Autografata di Fabrice, fel-5
Testo: "Fabrice The Crown vuole LA foto: la star più irraggiungibile del pianeta, nella Suite Reale. Ti butti nell'inseguimento ma la scorta ti becca al secondo corridoio. Fabrice, per consolazione, ti autografa una foto SUA: 'Paurina, eh? Capita ai migliori.'"
Scena: pet trascinato via da due buttafuori giganti, Fabrice che firma una foto con ghigno da paparazzo

**Standard** — +5 Velocità, +150 monete, Medaglia dell'Impresa
Dati: reward= velocita+5, monete+150, fel+5
Testo: "Scale di servizio, condotto dell'aria, carrello della biancheria: arrivi alla Suite Reale da una direzione che non esiste nemmeno nelle planimetrie. CLICK. La foto del secolo è tua e Fabrice ti guarda con rispetto professionale: 'Paurina. PAURINA VERA.'"
Scena: pet appeso al lampadario della suite con la macchina fotografica, flash che illumina tutto

**Super successo** (condizione: Velocità 70+; via alt talento Faccia di Bronzo — bussa alla suite e chiede un selfie) — +5 Velocità, +150 monete, Fabrice The Crown companion (+3 Carisma fisso)
Dati: cond= velocita>=70 | talento:facciadibronzo ; reward= velocita+5, monete+150, arredo:Fabrice The Crown, fel+10
Testo: "O sei un fulmine che nessuna scorta può fermare, o fai la cosa più assurda di tutte: BUSSI. 'Salve, sono qui per il selfie.' La star è così spiazzata che dice sì. Fabrice ti guarda fare, e qualcosa in lui si spezza: 'Tu sei il mio erede. PAURINA!' Da oggi lavora con te."
Scena: [DEDICATA] selfie a tre — pet, la star misteriosa e Fabrice che fa le corna dietro, flash dorato

## Missione 70: Oltre il Novemila
Brief: 'Vediamo questo power level' — Veggeta ti aspetta nel Cratere in Periferia con lo scouter già acceso.
- Luogo: 📍 Cratere in Periferia
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: la più alta (statMax)
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=qualsiasi ; stadio=adulto ; impresa=1 ; personalita=maleducato ; ritenta=1

**Fallimento** (condizione: statMax <50) — Insalatona ×2
Dati: cond= statMax<50 ; reward= cibo:Insalatona, cibo:Insalatona, fel-5
Testo: "Veggeta ti aspetta nel cratere col visore acceso: 'Vediamo questo livello di potenza.' BIP. Il visore mostra un numero così basso che Veggeta lo ripete tre volte, ridendo da solo. 'Mangia. TANTO. E torna quando il visore smette di ridere anche lui.'"
Scena: pet nel cratere, Veggeta di spalle che ride col visore in mano

**Standard** — +5 alla stat più alta, +150 monete, Medaglia dell'Impresa
Dati: reward= statmax+5, monete+150, fel+5
Testo: "Il visore sale, sale, SALE. Veggeta smette di ridere. 'Impossibile. IMPOSSIBILE!' Lo schiaccia con la mano guantata, come da tradizione. 'Non sei male, insetto. Non male AFFATTO.' Detto da lui, è una dichiarazione d'amore."
Scena: Veggeta che frantuma il visore, pet in posa da combattimento tra i detriti

**Super successo** (condizione: statMax 70+; via alt talento Bad Loser — perde il 1° round ed esplode di rabbia: visore in errore) — +5 alla stat più alta, +150 monete, Veggeta companion (+3 Forza fisso)
Dati: cond= statMax>=70 | talento:badloser ; reward= statmax+5, monete+150, arredo:Veggeta, fel+10
Testo: "OLTRE NOVEMILA. Il visore esplode, il cratere si allarga, Veggeta resta in silenzio per la prima volta nella sua vita. Poi incrocia le braccia e guarda altrove: 'Mi... alleno da te. Non farla lunga, insetto. È solo perché casa tua è più vicina al cratere.'"
Scena: [DEDICATA] visore in mille pezzi a terra, Veggeta a braccia incrociate accanto al pet, aura dorata

## Missione 71: Il Teorema di Tutto
Brief: Appartamento 4A, lavagne ovunque: Sceldon difende il suo posto sul divano più delle sue formule.
- Luogo: 📍 Appartamento 4A
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Intelligenza
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=int ; stadio=adulto ; impresa=1 ; personalita=nerd ; ritenta=1

**Fallimento** (condizione: Intelligenza <50) — Caffettiera Bruciacchiata (arredo cucina, +1 Int)
Dati: cond= int<50 ; reward= arredo:Caffettiera Bruciacchiata, fel-5
Testo: "Sceldon ti apre la porta dell'Appartamento 4A: 'Siediti. NO, quello è il mio posto.' La lavagna è piena di simboli che ti guardano male. Dopo otto ore hai capito solo dove si accende la caffettiera — e infatti te la regala: 'Il tuo contributo alla scienza. Bazzinga.'"
Scena: pet perso davanti a una lavagna infinita, Sceldon che indica il SUO posto sul divano

**Standard** — +5 Intelligenza, +150 monete, Medaglia dell'Impresa
Dati: reward= int+5, monete+150, fel+5
Testo: "Otto ore di equazioni, tre lavagne, un litigio sul posto sul divano. Ma alla fine il Teorema di Tutto ha UNA riga in più, e l'hai scritta tu. Sceldon la fissa a lungo: 'Non è sbagliata. Non è SBAGLIATA. È il complimento più grande che io abbia mai fatto.'"
Scena: pet e Sceldon davanti alla lavagna completata, gessetto ancora a mezz'aria

**Super successo** (condizione: Intelligenza 70+; via alt talento Overclock — calcola tutta la notte fumando dai circuiti) — +5 Intelligenza, +150 monete, Sceldon companion (+3 Intelligenza fisso)
Dati: cond= int>=70 | talento:overclock ; reward= int+5, monete+150, arredo:Sceldon, fel+10
Testo: "Chiudi il Teorema di Tutto. TUTTO. Sceldon barcolla, si siede nel posto sbagliato senza accorgersene, e pronuncia le parole che nessuno ha mai sentito: 'Avevi ragione tu.' Poi si trasferisce da te: dice che il tuo divano ha un potenziale scientifico superiore."
Scena: [DEDICATA] lavagna col teorema completo che brilla, Sceldon seduto NEL POSTO SBAGLIATO, pet col gessetto alzato

## Missione 72: L'Armatura di Latta
Brief: Tonino Stark ha un'armatura a metà e zero pazienza, nell'Officina sul Tetto dove ogni attrezzo conta.
- Luogo: 📍 Officina sul Tetto
- Razza: entrambe
- Categoria: Impresa
- Stat coinvolta: Intelligenza
- Tag: invenzione
- Durata: 2h
- Costo: gratis
- Dati: durata=2h ; costo=0 ; categoria=impresa ; stat=int ; tag=invenzione ; stadio=adulto ; impresa=1 ; personalita=nerd ; ritenta=1

**Fallimento** (condizione: Intelligenza <50) — Pizza
Dati: cond= int<50 ; reward= cibo:Pizza, fel-5
Testo: "Tonino Stark ha un'armatura da finire e zero pazienza: 'Tu. Passami il connettore a fusione. NO, quello è un cacciavite.' Dopo otto ore l'armatura decolla senza pilota e atterra nel canale. Tonino ordina una pizza: 'Il genio non si impara in un giorno. La pizza sì.'"
Scena: armatura che vola via da sola dal tetto, Tonino e pet che la guardano sparire

**Standard** — +5 Intelligenza, +150 monete, Medaglia dell'Impresa
Dati: reward= int+5, monete+150, fel+5
Testo: "Saldature, circuiti, un reattore che fa un rumore preoccupante ma AFFASCINANTE. L'Armatura di Latta si accende e stavolta resta a terra finché non glielo dici tu. Tonino ti guarda da sopra gli occhiali scuri: 'Non male. Io a modo mio, tu a modo tuo... siamo pari.'"
Scena: armatura in piedi sul tetto che si illumina, Tonino e pet con le braccia incrociate davanti

**Super successo** (condizione: Intelligenza 70+; via alt Forza 45+ — piega i pezzi a mani nude) — +5 Intelligenza, +150 monete, Tonino Stark companion (+3 Intelligenza fisso)
Dati: cond= int>=70 | forza>=45 ; reward= int+5, monete+150, arredo:Tonino Stark, fel+10
Testo: "O riprogetti il reattore da zero, o pieghi la corazza A MANI NUDE mentre Tonino ti guarda in silenzio religioso. L'armatura vola, atterra, fa l'inchino. 'Ok, lo ammetto: mi serve un socio. Il tetto di casa tua com'è messo?' Tonino Stark si trasferisce da te."
Scena: [DEDICATA] armatura in volo col tramonto dietro, Tonino e pet sul tetto con due bibite, brindisi di latta

---

## Backlog — concetti sviluppati ma non scelti (da riprendere in una sessione futura)

### Il Controllore Ti Ha Visto
- Luogo: 📍 Mercato Coperto · Categoria: Marachelle · Stat: Velocità · Durata: 1h
- Standard: +1 Velocità, +5 monete, Sushi (cibo, Velocità+2) — "Un assaggio gratis da un banco del mercato, giusto per curiosità — e il controllore di zona non la prende bene. Scatti tra la folla, giri due angoli a caso, e quando ti volti lui non c'è più. Adrenalina a mille, bottino intascato, nessun rimorso."
- Fallimento (Velocità 0 O Nerd): niente Velocità, −5 monete, Scarpe da corsa consumate (arredo, +1 Velocità passivo) — "Ti blocchi a leggere il cartello dei prezzi invece di scappare, e il controllore ti raggiunge senza nemmeno correre. Multa salata — ma il vecchio dietro al banco ti allunga comunque un paio di scarpe dimenticate lì: 'la prossima volta usale prima di leggere'."
- Super successo (Velocità 3+ O Maleducato): +2 Velocità, +15 monete, Scarpe da corsa professionali (arredo, +2 Velocità passivo) — "Non solo scappi — lo fai passando esattamente sotto il naso del controllore, con un ghigno che dice tutto. Nella confusione racimoli pure il doppio del bottino."

### Grand Prix di Città Bassa
- Luogo: 📍 Circuito Metropolitano · Categoria: Sport · Stat: Velocità · Durata: 1h30
- Standard: +1 Velocità, +10 monete, Pesce alla griglia (cibo, Velocità+1) — "Bandiera a scacchi, motori ruggenti, tribune piene. Non lotti per il podio, ma chiudi a metà classifica con onore."
- Fallimento (Velocità 0 O Nerd): niente Velocità, Casco da corsa (arredo, +1 Velocità passivo) — "Passi l'intera gara a calcolare la traiettoria perfetta invece di correre. Ultimo posto, ma un casco di consolazione 'per la prossima volta'."
- Super successo (Velocità 3+ O Sportivo): +2 Velocità, +25 monete, Coppa Grand Prix (arredo, +2 Velocità passivo), perk Sport — "Prendi il comando al primo giro e non lo molli più. Podio, coppa vera, sponsor già in coda."

---

## Linee guida di progetto (dal GDD, verificate su queste 20 schede)
- 1-2 stat RPG coinvolte per missione; tutte e 4 servono: Velocità (M1, M5, M8, M15, M16), Carisma (M2, M6, M11, M19), Forza (M3, M5, M7, M13, M14, M20), Intelligenza (M4, M9, M10, M12); M17 (mod a scelta) e M18 (colpo) toccano qualsiasi stat ✓
- Durate tra 1 e 6 ore reali, con una corta ~1h (M1) ✓
- Reward misti: monete, cibo, arredi, XP stat — mai solo monete ✓
- Rischio igiene (M5) e salute (M3, M7) per far girare la loop di cura ✓
- Rosa di 3 missioni/giorno su 10+ disponibili + tutorial fuori rosa: varietà per i giorni baby con rotazione e cooldown 3 giorni ✓
