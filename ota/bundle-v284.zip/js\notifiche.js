window.PETQ = window.PETQ || {};

(function () {

  // Notifiche LOCALI (v1, design del regista): l'app le pianifica quando va in BACKGROUND e le
  // cancella tutte quando torna in FOREGROUND (v. main.js registraRipresa/avviaTicking, i due
  // hook che chiamano pianifica()/cancella()/richiediPermesso() sotto). Plugin Capacitor
  // (@capacitor/local-notifications v8): se non disponibile (browser, file://, o sync non
  // ancora fatto dal regista) LN resta null e OGNI funzione qui e' un no-op silenzioso — mai
  // un throw, il gioco deve restare identico senza il plugin.
  var LN = (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) || null;

  // ID fissi delle notifiche (usati sia per schedule che per cancel).
  var ID_MISSIONE = 1;
  var ID_FAME = 2;
  var ID_VALIGIA = 3;
  var ID_ALLENAMENTO = 4;
  var ID_STREAK = 5;
  var ID_SILENZIO = 6;
  var TITOLO = 'Hatch a Legend';

  // ---------- Regole anti-molestia (doc Retention 2.0, A1) ----------
  // Max 2 al giorno, mai fra le 21 e le 9, mai due dello stesso tipo di fila. Sono numeri di
  // design, quindi stanno qui in cima come costanti e non sparsi nel codice.
  var SILENZIO_DA_ORA = 21;   // dalle 21:00...
  var SILENZIO_A_ORA = 9;     // ...alle 09:00 non si disturba
  var MAX_AL_GIORNO = 2;
  var MS_MINUTO = 60000;

  // Chi vince quando in una giornata ce ne sarebbero piu' di due. La valigia sta in cima perche'
  // e' l'unica in cui non rispondere ha una conseguenza vera (il pet se ne va); la nostalgia sta
  // in fondo perche' e' la piu' rinunciabile di tutte.
  var PRIORITA = { valigia: 5, missione: 4, allenamento: 3, fame: 2, streak: 1, silenzio: 0 };

  // ---------- Testi fissi bilingue ----------
  // NON passano da PETQ.i18n.t()/traduci(): questo file NON tocca i18n.js (ci lavora un altro
  // agente in parallelo). Stesso contratto di lettura lingua di i18n.js (petq_lingua via
  // PETQ.i18n.lingua()), ma il dizionario EN per queste stringhe vive qui, hardcoded.
  function enAttivo() {
    return !!(PETQ.i18n && PETQ.i18n.lingua && PETQ.i18n.lingua() === 'en');
  }

  // Sceglie IT o EN in base alla lingua corrente: stesso pattern per tutti i testi fissi sotto.
  function bilingue(it, en) {
    return enAttivo() ? en : it;
  }

  function nomePet(pet) {
    var nome = pet && pet.nome;
    if (nome) return nome;
    return bilingue('Il pet', 'The pet');
  }

  // Notifica 1 (missione finita): fallback SOLO se il pool 'notifica_missione' (content, nuova
  // sezione "## Notifica missione finita" per personalita', in scrittura al socio) e' vuoto.
  function corpoMissioneFallback(pet) {
    return nomePet(pet) + bilingue(
      ' è tornato dalla missione: vieni a vedere com\'è andata!',
      ' is back from the mission: come see how it went!'
    );
  }

  // Notifica 4 (allenamento finito): stesso schema, pool 'notifica_allenamento' (sezione
  // "## Notifica allenamento finito") con fallback fisso bilingue.
  function corpoAllenamentoFallback(pet) {
    return nomePet(pet) + bilingue(
      ' ha finito l\'allenamento: vieni a vedere che muscoli!',
      ' finished training: come check out those gains!'
    );
  }

  // Notifica 2 (fame bassa): fallback SOLO se il pool 'notifica' (content, sezione "## Notifica
  // push", per personalita') e' vuoto/assente (PETQ.dialog.say ritorna '...').
  function corpoFameFallback(pet) {
    return nomePet(pet) + bilingue(
      ' ti pensa: passa a trovarlo!',
      ' misses you: come say hi!'
    );
  }

  // Notifica 3 (valigia): fallback SOLO se il pool 'notifica_valigia' e' vuoto/assente, stesso
  // schema della 2. Tono d'allarme (ultimo avvertimento prima che il pet se ne vada).
  function corpoValigiaFallback(pet) {
    return nomePet(pet) + bilingue(
      ' sta preparando la valigia: rimedia prima che se ne vada!',
      ' is packing their bags: fix things before they leave!'
    );
  }

  // ---------- Tasso di decadimento Fame (per prevedere quando scende sotto 25) ----------
  // Letto a runtime da content/bilanciamento.md (stessa fonte di pet.js applyDecay, dec.fame);
  // costante locale di fallback = stesso default usato li' se il bundle contenuti non e' pronto.
  var TASSO_FAME_DEFAULT = 6; // punti/ora di gioco

  function tassoFame() {
    var data = PETQ.content && PETQ.content.data;
    var dec = data && data.bilanciamento && data.bilanciamento.decadimento;
    if (dec && typeof dec.fame === 'number' && dec.fame > 0) return dec.fame;
    return TASSO_FAME_DEFAULT;
  }

  var MS_ORA = 3600000;
  var MAX_FAME_MS = 24 * MS_ORA;        // cap richiesto dal brief: mai oltre 24h
  var FAME_GIA_BASSA_MS = 30 * 60000;   // fame gia' <25 in questo istante: avviso a +30 min
  var VALIGIA_MS = 30 * 60000;          // valigia: sempre +30 min (ultimo avvertimento)

  // Richiede il permesso di sistema (Android 13+ mostra il prompt): va chiamato in FOREGROUND
  // (i prompt non si possono mostrare da background), v. main.js avviaTicking.
  function richiediPermesso() {
    if (!LN) return;
    LN.requestPermissions().catch(function () { /* permesso negato o non disponibile: silenzioso */ });
  }

  // Cancella le tre notifiche pianificate (stessi ID fissi). Chiamata sia da pianifica() prima
  // di ripianificare da zero, sia da main.js al ritorno in foreground.
  // Elenco UNICO degli id: cancella() lo deriva da qui invece di riscriverli a mano. Con la lista
  // duplicata, i due tipi nuovi (carica a rischio, silenzio lungo) erano gia' rimasti fuori dalla
  // cancellazione — e una notifica "sei sparito da tre giorni" che arriva a chi e' appena tornato
  // e' peggio che non averla affatto.
  var TUTTI_GLI_ID = [ID_MISSIONE, ID_FAME, ID_VALIGIA, ID_ALLENAMENTO, ID_STREAK, ID_SILENZIO];

  function cancella() {
    if (!LN) return;
    var lista = [];
    for (var i = 0; i < TUTTI_GLI_ID.length; i++) lista.push({ id: TUTTI_GLI_ID[i] });
    LN.cancel({ notifications: lista }).catch(function () { /* silenzioso */ });
  }

  // Pianifica SOLO le notifiche pertinenti allo stato corrente (missione in corso / fame in
  // discesa verso la soglia / fase valigia). Chiamata all'uscita in background (v. main.js).
  // Notifica 5 (carica a rischio, la sera): fallback se il pool 'notifica_streak' e' vuoto.
  function corpoStreakFallback(pet) {
    return nomePet(pet) + bilingue(
      ' tiene viva la carica: manca solo te, oggi.',
      ' has kept the charge going: you are the only thing missing today.'
    );
  }

  // Notifica 6 (silenzio lungo, 3+ giorni): fallback se il pool 'notifica_silenzio' e' vuoto.
  // Tono leggero anche nel ripiego: mai colpevolizzare, e' la regola del doc.
  function corpoSilenzioFallback(pet) {
    return nomePet(pet) + bilingue(
      ' se la cava benissimo. Lo dice sempre più spesso.',
      ' is doing just fine. It keeps saying so, more and more often.'
    );
  }

  /* Regole anti-molestia, in un punto SOLO (doc A1: max 2 al giorno, mai fra le 21 e le 9, mai
   * due dello stesso tipo di fila). Stanno qui e non dentro i singoli rami perche' ogni tipo
   * nuovo che qualcuno aggiungera' fra sei mesi le eredita gratis: se le mettessi accanto a
   * ciascuna notifica, la prima aggiunta distratta le salterebbe e nessuno se ne accorgerebbe
   * finche' non se ne lamenta un giocatore.
   *
   * Nota su cosa NON possiamo sapere: le notifiche partono ad app chiusa e il plugin non ci dice
   * quali siano state davvero consegnate o viste. Quindi queste regole valgono su cio' che
   * PIANIFICHIAMO — che e' comunque tutto cio' che l'utente puo' ricevere, visto che ad ogni
   * ritorno in foreground cancelliamo e ripianifichiamo da zero. */
  function applicaRegoleAntiMolestia(state, lista) {
    if (!lista.length) return lista;

    // 1) Fuori dalla fascia di silenzio: chi cadrebbe fra le 21 e le 9 slitta alle 9 del mattino
    // successivo. Slittare e non buttare: la notifica ha ancora senso, e' l'orario a non averlo.
    for (var i = 0; i < lista.length; i++) {
      var d = new Date(lista[i].quando);
      var h = d.getHours();
      if (h >= SILENZIO_DA_ORA || h < SILENZIO_A_ORA) {
        if (h >= SILENZIO_DA_ORA) d.setDate(d.getDate() + 1); // dopo le 21 -> domani mattina
        d.setHours(SILENZIO_A_ORA, 0, 0, 0);
        lista[i].quando = d.getTime();
      }
    }

    lista.sort(function (a, b) { return a.quando - b.quando; });

    /* 2) Mai due dello stesso tipo di fila.
     *
     * Dentro il gruppo e' facile. Il caso difficile e' il confine fra una sessione e l'altra:
     * ad ogni ritorno in foreground cancelliamo e ripianifichiamo tutto, quindi la sequenza che
     * il giocatore vive davvero e' "un pezzo del gruppo di ieri, poi un pezzo di quello di oggi",
     * e due uguali possono capitare proprio li'.
     *
     * Il plugin non ci dice cosa sia stato consegnato. Il segnale migliore che abbiamo e' la
     * PRIMA del gruppo precedente: e' quella che aveva piu' probabilita' di scattare prima che
     * l'utente riaprisse. Un'approssimazione, e va trattata come tale — per questo la regola
     * cede se il gruppo di oggi ha una voce sola: meglio ripetere un tipo che restare muti per
     * giorni perche' un'euristica ha indovinato male.
     */
    var out = [];
    var ultimoScorso = state.ultimoTipoNotifica || null;
    var diversiDisponibili = false;
    for (var d0 = 0; d0 < lista.length; d0++) {
      if (lista[d0].tipo !== ultimoScorso) { diversiDisponibili = true; break; }
    }
    var precedente = diversiDisponibili ? ultimoScorso : null;
    for (var j = 0; j < lista.length; j++) {
      if (lista[j].tipo === precedente) continue;
      out.push(lista[j]);
      precedente = lista[j].tipo;
    }

    // 3) Max 2 per giornata di calendario, tenendo le piu' importanti (v. PRIORITA sopra) e
    // rimettendole poi in ordine di orario.
    var perGiorno = {};
    for (var k = 0; k < out.length; k++) {
      var g = new Date(out[k].quando);
      var chiave = g.getFullYear() + '-' + g.getMonth() + '-' + g.getDate();
      if (!perGiorno[chiave]) perGiorno[chiave] = [];
      perGiorno[chiave].push(out[k]);
    }
    var finali = [];
    for (var ch in perGiorno) {
      if (!Object.prototype.hasOwnProperty.call(perGiorno, ch)) continue;
      var giorno = perGiorno[ch];
      giorno.sort(function (a, b) { return (PRIORITA[b.tipo] || 0) - (PRIORITA[a.tipo] || 0); });
      finali = finali.concat(giorno.slice(0, MAX_AL_GIORNO));
    }
    finali.sort(function (a, b) { return a.quando - b.quando; });

    // Memoria per la prossima pianificazione: la PRIMA che partira', non l'ultima — e' quella
    // che ha davvero la possibilita' di essere arrivata prima che il giocatore riapra l'app.
    if (finali.length) state.ultimoTipoNotifica = finali[0].tipo;
    return finali;
  }

  function pianifica(state) {
    if (!LN || !state || !state.pet) return;

    cancella(); // si ripianifica sempre da zero ad ogni ingresso in background

    var ora = Date.now();
    var notifications = [];

    // Le voci si accumulano con {id, tipo, quando} e diventano il formato del plugin SOLO in
    // fondo, dopo il filtro anti-molestia: cosi' non esiste un percorso che salti le regole.
    function aggiungi(id, tipo, corpo, quandoMs) {
      notifications.push({ id: id, tipo: tipo, body: corpo, quando: quandoMs });
    }
    // Corpo dal pool del socio per quella personalita', ripiego fisso se il pool e' vuoto.
    function corpo(pool, ripiego) {
      var c = (PETQ.dialog && PETQ.dialog.say) ? PETQ.dialog.say(state.pet, pool, state) : '...';
      return (!c || c === '...') ? ripiego(state.pet) : c;
    }

    // 1) Missione finita: 30s dopo l'orario di fine gia' fissato (wall-clock, v. missions.js).
    // Corpo dal pool 'notifica_missione' (catch phrase del socio, per personalita'), fallback fisso.
    if (state.missione && typeof state.missione.fine === 'number') {
      aggiungi(ID_MISSIONE, 'missione', corpo('notifica_missione', corpoMissioneFallback), state.missione.fine + 30000);
    }

    // 1b) Allenamento finito: l'allenamento avanza in ORE DI GIOCO (state.allenamento.oreFatte
    // accumulate dai tick, v. care.js) ma a velocita' normale 1 ora di gioco = 1 ora reale,
    // quindi la fine prevista e' now + (oreTot - oreFatte) ore reali (+30s di margine).
    // Corpo dal pool 'notifica_allenamento', fallback fisso.
    if (state.allenamento && typeof state.allenamento.oreTot === 'number') {
      var oreRimaste = state.allenamento.oreTot - (state.allenamento.oreFatte || 0);
      if (oreRimaste > 0.02) {
        aggiungi(ID_ALLENAMENTO, 'allenamento', corpo('notifica_allenamento', corpoAllenamentoFallback),
          ora + oreRimaste * MS_ORA + 30000);
      }
    }

    // 2) Fame bassa: niente se il pet dorme (in sonno il decadimento e' in pausa, v. pet.js
    // applyDecay -> nessuna previsione ha senso finche' non si sveglia).
    if (!state.sonno && state.pet.stats && typeof state.pet.stats.fame === 'number') {
      var fame = state.pet.stats.fame;
      var atFameMs = null;

      if (fame < 25) {
        atFameMs = FAME_GIA_BASSA_MS; // gia' sotto soglia adesso: avviso ravvicinato
      } else {
        var ore = (fame - 25) / tassoFame();
        if (ore > 0.1) {
          var ms = ore * MS_ORA;
          if (ms > MAX_FAME_MS) ms = MAX_FAME_MS;
          atFameMs = ms;
        }
      }

      if (atFameMs !== null) {
        aggiungi(ID_FAME, 'fame', corpo('notifica', corpoFameFallback), ora + atFameMs);
      }
    }

    // 3) Valigia: il pet sta per andarsene, ultimo avvertimento fisso a 30 minuti.
    if (state.valigia) {
      aggiungi(ID_VALIGIA, 'valigia', corpo('notifica_valigia', corpoValigiaFallback), ora + VALIGIA_MS);
    }

    // 4) Carica a rischio (doc A1: "streak-saver serale"): SOLO con una serie gia' avviata
    // (>= 3 giorni, cioe' qualcosa che vale la pena non perdere) e SOLO se oggi non c'e' ancora
    // stata una cura. Sotto i 3 giorni sarebbe una sollecitazione a costruire un'abitudine che
    // il giocatore non ha ancora scelto di avere.
    if (PETQ.streak && PETQ.streak.stato) {
      var st = PETQ.streak.stato(state);
      if (st.giorni >= 3 && !st.curatoOggi) {
        // Le 20:00 di oggi: l'ultima ora utile prima del silenzio delle 21. Se sono gia' passate,
        // il filtro la sposta a domattina da solo, che e' comunque il momento giusto.
        var sera = new Date();
        sera.setHours(SILENZIO_DA_ORA - 1, 0, 0, 0);
        // Ripiego di 2 minuti e non 30: con 30, chi mette l'app in background dopo le 20:30 si
        // vedeva spostare la notifica a 21:00+, cioe' DENTRO la finestra di silenzio, e il filtro
        // anti-molestia la rimandava a domani mattina alle 9 — quando la carica di IERI e' gia'
        // stata persa. Uno streak-saver che arriva dopo il funerale non salva niente. Con 2 minuti
        // il confine si sposta dalle 20:30 alle 20:58: resta un buco di due minuti, ma e' il piu'
        // piccolo ottenibile senza toccare l'ora del silenzio, che e' una scelta di design.
        if (sera.getTime() <= ora) sera = new Date(ora + 2 * MS_MINUTO);
        aggiungi(ID_STREAK, 'streak', corpo('notifica_streak', corpoStreakFallback), sera.getTime());
      }
    }

    // 5) Silenzio lungo (3+ giorni): pianificata SEMPRE a tre giorni da adesso. Non serve
    // nessun controllo sull'assenza — se il giocatore torna prima, il ritorno in foreground
    // cancella tutto (v. main.js), quindi puo' partire solo se e' davvero sparito tre giorni.
    aggiungi(ID_SILENZIO, 'silenzio', corpo('notifica_silenzio', corpoSilenzioFallback), ora + 3 * 24 * MS_ORA);

    var finali = applicaRegoleAntiMolestia(state, notifications);
    if (finali.length === 0) return;

    var payload = [];
    for (var n = 0; n < finali.length; n++) {
      payload.push({
        id: finali[n].id,
        title: TITOLO,
        body: finali[n].body,
        schedule: { at: new Date(finali[n].quando) }
      });
    }
    LN.schedule({ notifications: payload }).catch(function () { /* silenzioso */ });
  }

  window.PETQ.notifiche = {
    richiediPermesso: richiediPermesso,
    pianifica: pianifica,
    cancella: cancella,
    // Esposta per il collaudo: le regole anti-molestia sono la parte che nessuno puo' verificare
    // giocando (le notifiche partono ad app chiusa), quindi devono essere ispezionabili da fuori.
    _regole: applicaRegoleAntiMolestia
  };

})();
