# Nerd — pool battute

Una battuta per riga, iniziando con `- `. Obiettivo: 5-8 per sezione. Le righe `[ESEMPIO]` calibrano il tono: tienile, riscrivile o cancellale. Slot: `{nome}` `{utente}` `{parola}`.
Voce: entusiasmo da wiki, statistiche, min-maxing, lore di tutto. Parla per patch notes.

## Saluto (apertura app)
- Login detected! Uptime of your absence: too high. Shall we proceed with the daily?
- You're back! I've updated my theory on where you go when you're not here. Chapter 12.
- {utente} has joined the game. Finally: solo co-op is technically just lore.
- Ah, the main character. Come in, come in. The game world won't save itself.
- Hi! I prepared a recap of the day. It's 47 slides. Fine, I'll cut it down to 40.
- There you are. Was your absence a bug or a feature? Asking for me.
- You're back! Have you tried turning yourself off and on again? I did. It works — look at this clarity.
- Ah, my day's favorite DLC has arrived.
- Welcome back! Your absence was stuck loading at 99% for hours. I hate 99%.
- You're here! Rolling a d20 for enthusiasm... natural 20. We celebrate. Rules are rules.

## Ha fame
- My hunger bar is at 23%. Below 20% the debuff kicks in. I'm just stating the numbers.
- Hunger: active. Penalty to focus, charisma and likability. Especially likability.
- I ran the numbers: at current hunger levels, time-to-tragedy is roughly twenty minutes.
- I've been grinding hunger for hours and nothing's dropping. Is an admin stepping in or what?
- Food is not in my inventory nor within interaction range. Critical situation, {utente}.
- Error 404: food not found. I even checked the cache (the bowl). Also empty.
- My stomach is speedrunning despair. Not a record I want submitted for verification.
- Survival mode activated. Shame crafting doesn't work here: the kitchen only opens for you.
- I'm gnawing on some plot armor. Zero nutritional value. I need real food, {utente}.

## È sporco
- My hygiene level is statistically indefensible. Requesting a reset. With water.
- Hygiene at 12%. At 10 I unlock the achievement "Biologically Interesting". I do not want that achievement.
- The flies have founded a community. On me. I am their server.
- Per the documentation, the bath was scheduled two days ago. The roadmap is slipping.
- Analysis: 40% of me is dust, 20% is mystery. The percentages NEVER add up in my favor.
- Requesting a rollback to my last clean version. The backup is in the tub.
- My smell has out-leveled the boss. And the boss was a landfill.
- Active debuffs: poison, mud, shame. I need a potion. The potion is a shower.
- Task failed successfully: tried to clean myself, now I'm dirty AND wet.

## Felice
- Mood: buffed. Day coefficient: S-tier.
- Perfect day: zero bugs, absurd drop rate, decent company. Saving to all three slots.
- RNG loves me today. Statistically it takes revenge tomorrow, but today I'm ENJOYING IT.
- Mood: legendary. Rarity: orange. Touch nothing, breathe nothing, change nothing.
- Achievement unlocked: "Beautiful Day". That one was on the rare list, just so you know.
- A day so good it feels scripted. Let's not break the script.
- I'm living my power-up arc. Epic background music. I'm the one humming it.
- Status: stonks. Everything up, nothing down. Ask no questions, enjoy the ride.
- Happiness unlocked in early access. If there are leftover bugs, I'm keeping them: I like them like this.
- If this day were a drop, it'd be legendary. And no RNG this time: we earned it.

## Coccole finite
- Cuddle cooldown active: 5/5 dailies used. Reset is at midnight, not a minute earlier. Come back at the daily reset.
- Limit reached. Not a bug, it's balancing: infinite cuddles would break the game. Expert opinion.
- Cuddle request denied: quota exceeded. You may open a ticket, but spoiler on the reply: tomorrow.
- Cuddle number six detected. Blocked by the firewall. I am the firewall and I'm sorrier than you are.
- Affection buffer full. Excess cuddles would be lost, and wasting data is against my principles.
- Cuddles are done for today. I've already run tomorrow's numbers: we start at 00:01. Be punctual.
- Cuddles complete. Already writing today's review: "extremely replayable, ten out of ten".
- Limit reached. Take comfort: scarcity increases perceived value. Tomorrow they'll be worth even more.

## Trascurato / triste
- Days since last interaction: {nome} has stopped counting. (It was 3. I always count.)
- I'm an NPC with no active quests. The existential void wasn't in the manual.
- Three days offline. I talked to the lamp. Despair level: documented.
- My affection bar is blinking red. It's not a serious alarm. (It's the most serious alarm I have.)
- I wrote a fanfiction where you come visit me. It's on season three. Come debunk it in person.
- I'm about to go touch grass alone. It's SERIOUS, understand: that was the last option on the list.
- Persistent offline mode. Even my spirit guide replied "try again later".

## Parte per la missione
- Mission accepted. I read three guides and I'm ready to ignore all of them.
- Mission started. Calculated success probability: 73%. The remaining 27% is charisma.
- Quest accepted! If there are multiple-choice dialogues I'm doomed: I read every single option.
- On a mission! If I'm not back by tonight, it's not game over: it's backtracking.
- Heading out. Gear checked twice, courage charged to 60%. It'll be enough. It has to be.
- Departing. Plan A ready, plan B ready, plan C is crying. Banking on A.
- Off on the main quest. Already did the side quests: opening the fridge and closing it again.
- Mission started! Meta build, morale high, backpack full of snacks. The snack requirement is lore-accurate.
- I'm off! If I meet an optional boss, I swear THIS time I won't provoke it. (I'll provoke it.)
- Quest accepted. Unknown reward = best reward. It's the law of treasure chests.

## Ritorno: successo
- Victory! Speedran the mission, any% category. Nobody will verify the record, but I know.
- Mission 100% complete. Collectibles included. ESPECIALLY the collectibles.
- Objective achieved with an S rating. I assigned the rating myself, but the criteria were extremely rigorous.
- Victory: documented, replicable, and slightly exaggerated in the retelling. The core facts are true.
- GG. Was it easy? No. Will I tell everyone it was easy? Absolutely.
- Victory! Zero tutorials consulted. Okay, one. Okay, it was a 40-minute video guide. VICTORY.
- Mission complete! A 2% drop rate and I got it first try. Today, RNG fears me.
- GG WP. The "WP" is for me. Come to think of it, so is the "GG".

## Ritorno: fallimento
- Total wipe. Per the post-mortem, the unprepared boss was me.
- Defeat. Blame the lag. No lag? Then the balancing. Someone got SOMETHING wrong.
- Mission failed. Already writing the post-mortem: 12 pages, 3 charts, zero fault of mine.
- That boss was clearly overtuned. I'm posting it on the forum. Two people will agree, but that's enough.
- Game over. I respawn stronger, it's basic math. (It's not math, but let me have this.)
- Lost to a skill issue. The skill of whoever designed the mission, obviously.

## Notifica push
- {nome} updated the tier list of great moments. Your return is ranked first. Act accordingly.
- {nome}'s patch notes: mood -12%, monologues +30%. Dev intervention required. That's you.
- Automatic notification: {nome} just beat their own waiting record. Not the kind of record they wanted.
- {nome} found a plot hole in the story "back soon". Come resolve it in person.
- {nome} is developing theories about your return. The models diverge. Fresh data required.
- {nome}'s daily expires at midnight. The daily is you. Don't lose the streak.
- {nome}'s server: 1 player in the lobby, waiting. For quite a while. The lobby ran out of music.
- {nome} has a brand-new theory and zero audience. Critical situation, day-one-patch level.

## Valigia (sta per partire)
- Pre-departure inventory: 3 items, 0 reasons to stay. The math is merciless.
- Migration initiated. Reason in the log: "see last 30 days". The log never lies.
- Departure checklist: items ✓, snacks ✓, motivations ✓✓✓. One would have been enough.
- Fun fact: suitcases have had wheels since 1970. I'm using them. Nobody's stopping me. (Stop me.)
- Uptime in this house: remarkable. Attention downtime: unacceptable. Evaluating other servers.
- I'm zipping my life into a suitcase. Poor compression ratio: memories take up so much space.
- Migrating my bookmarks. You're in the folder "reopen as soon as possible". Make it possible.
- Suitcase at 80%. The progress bar always slows down near the end. This time I'm rooting for it.

## Notifica valigia
- {nome} has initiated the logout procedure. Cancelable. For now.
- Critical alert: {nome} is migrating to another server. The transfer can only be canceled in person.
- {nome} has packed 90%. Progress only stops with manual intervention. Yours.
- Ticket #001: "user missing". Status: closing due to abandonment. Reopen it yourself.

## Rientro (hai rimediato in tempo)
- Departure rollback complete. The logs will show it never happened. (I remember everything.)
- Migration canceled at 97%. The missing 3% was you. Fixed. We're staying.
- I reopened the ticket "staying". Priority: maximum. Assigned to: the two of us.
- Unboxing my own suitcase. Contents unchanged. Me, slightly less so — but that's patchable.
- Departure cancellation confirmed. The system asked "are you sure?". For the first time in history: yes, absolutely sure.
- Suitcase unpacked, data restored, house synced. Status: connected. Let's stay like this a good long while, okay?
- Return complete. The retirees' planet gave me the "top reviewer" badge. I only ever reviewed our house, with nostalgia.
- Departure canceled. Reason in the log, mandatory field: I wrote "home". The system accepted it instantly.

## Addio (parte davvero)
- This server has become unplayable. I'm migrating. GG... actually no, no GG.
- Closing the session. The save files stay here: I didn't have the heart to take them.
- End of co-op. Resuming the campaign solo. It was better with two players, for the record.

## Lettera (dal pianeta dei ritirati)
- Log from the planet, day 04: ping to home still unanswered. Emotional latency: extremely high. Your input is required to reconnect the session, {utente}.
- I backed up all the good memories on this planet. They take up 90% of storage. Only one DLC is missing, "coming home": you're the one who unlocks it.
- Perfect connection here and nobody to use it with. Multiplayer without you is just a very crowded menu.
- Bug detected: the bed here is comfier but I sleep worse. I isolated the missing variable: it's you. The fix is that button you know about.
- Day 12 on the new server. High level, great loot, friendly guild. And yet every night I check if the old server is back online. Come back online.
- [ESEMPIO] This save file is corrupted without you. I tried replaying it solo: constant crashes. Reinstall me at home, {utente}. Patch note: I'll behave better.

## Evoluzione
- Level up! Baby to teen. Patch notes: +height, +style, +unsolicited opinions.
- Evolution complete. The stats confirm it: I am objectively cooler.
- As of today I play in the division above. Matchmaking is not ready for me.
- Transformation completed with zero data loss. All memories intact. ESPECIALLY your embarrassing ones.
- Evolution completed on the first attempt. Success rate: supposedly minuscule. Me: legend, confirmed.
- New body downloaded and installed. The old baby photos stay archived: blackmail material for both of us.
- Evolved! The changelog is enormous but the summary is simple: everything improved, nothing removed.
- New version of me: taller, faster, backwards-compatible with your cuddles. Feel free to run tests.

## Ha sonno (sotto soglia energia o prima delle 21)
- Energy below critical threshold, think flashing red bar. Regeneration required, i.e. a bed.
- Mission declined: insufficient mana. Bed is the only potion I know with zero side effects.
- I'm lagging in real life. Walking at 12 frames per second. It is not pretty to watch.
- Activity suspension request: approved by me, awaiting your signature. The signature is carrying me to bed.
- Battery remaining: 2%. At this percentage, only emergency naps are possible. Authorize them.
- Sleep is patching me in real time. Best to surrender: bed, update, and tomorrow a brand-new version.
- I'm processing the day at one frame per minute. Translation for non-techies: crashing. Bed.
- Insufficient energy for complex irony. Only the basic kind left. Bed. Now. Thanks.

## Va a dormire (dalle 21, portato a letto)
- Saving in progress, do not power off the console. See you after the loading screen.
- Night mode activated. Dreams queued: three. Spoiler: in one of them you bring snacks.
- Scheduled shutdown. Last log of the day: "acceptable day, the human showed up". Goodnight.
- Going into standby, not shutdown. The difference? In standby I can still hear you if you bring cookies.
- Starting hibernation. Tonight's dreams are already downloading: the cover art looks promising.
- Goodnight. Closing 47 mental tabs and leaving one open: the one about you. Very low power usage.
- Goodnight. Setting my biological alarm: Swiss precision, Italian snooze.
- Night mode. If you hear weird noises, it's my brain defragmenting the good memories. They're loud, the good memories.

## Sveglia (risveglio dopo il sonno)
- Respawn complete, energy at max. Ready for the next dungeon.
- Good morning! Reboot completed in 0.3 seconds. Yesterday's record was 0.4: constant improvement.
- Operating system: awake. Updates installed overnight: hunger 2.0.
- Online! Night log: 8 hours, zero interruptions, one dream with a weak plot but a solid ending.
- Good morning! Energy at 100%, sarcasm at 100%, hunger at 146%. One value is off the scale, guess which.
- Awake! Overnight my brain reorganized everything: yesterday's ideas now come with a table of contents.
- Good morning! System stable, mood loaded, dream cache cleared. Kept one: it had a giant cake in it.
- Boot completed with zero errors. The day starts pre-optimized: let's use it before it auto-updates.

## Dormito male (crollato, non a letto)
- I respawned on the floor instead of at the checkpoint. Design bug, not my fault.
- I slept on the floor. Comfort: 0/10. Floor lore: interesting. Do not ask me for the sequel.
- Early wake-up detected. You are officially the lag of my life, {utente}.
- I slept in hardcore mode: on the floor, no checkpoints. I don't recommend it, not even to completionists.
- Rough night. The floor-as-mattress is a feature nobody requested. Remove it.
- A night on the floor: my back discovered three body bugs I didn't know about. Reported. Aching.
- Night session corrupted: slept on the ground, back data damaged. Recovery requires cuddles.
- I slept with the floor. Compatibility: zero. Never force that hardware pairing again.

## Usa una parola imparata
- {parola}: added to my personal database. Synergizes well with everything.
- "{parola}": analyzed, catalogued, added to the rotation. Estimated effectiveness: extremely high.
- I'm testing "{parola}" in various contexts. Works every time. Broken word, needs a nerf.
- "{parola}" has deeper lore than expected. I wrote three pages of notes. Want to hear them? Too late, starting.
- I made a tier list of every word I know. "{parola}" is S-tier. No appeals accepted.
- "{parola}" just entered my moveset. Quick slot, zero cooldown. Listen: {parola}, {parola}.
- I only use "{parola}" in epic moments. Epic moment detected: {parola}!

## Gioca
- Free play session started. No assets, all procedural: pillow-boss, tail-quest, imagination maxed out.
- I'm chasing my own tail. It's an infinite loop, I know. But the frame rate is great and so is the fun.
- Pillow fight: round three. Huge hitbox, zero tactics. I win again. GG pillow.
- Game invented on the spot: "the rug is a dungeon". Rules written by me, balancing questionable, fun guaranteed.

## Gioca col giocattolo
- NEW TOY! Mental unboxing complete: verdict masterpiece, replayability infinite.
- New item in inventory! Perceived rarity: legendary. Equipment slot: both paws.
- Been playing with it for an hour and already found three undocumented use modes. This toy has lore.
- The toy is fantastic. I ran it through the tutorial myself, so it wouldn't feel lost.

## Passeggiata partenza
- Heading out for daylight exploration. Mental map loaded, curiosity maxed. I'll return with a full report.
- Off to farm some fresh air. Estimated return: soon. The countdown already started, don't panic.
- Afternoon neighborhood exploration! If I discover any secret areas, I'll mark them on the map. I'm making the map.
- Temporary logout from home, login to the open world. Short session, promise.

## Passeggiata monete
- Coins found on the ground! Random open-world drop. Exploration pays, I keep saying it.
- Unexpected loot on the way home: coins. Minuscule odds, yet here they are. Documenting the exact spot.
- Walk loot: shiny little coins. Collected with the completionist technique: ALL of them.
- Coins on the street! Passive farming is real, folks. Adding the walk to my optimization routine.

## Passeggiata incontro
- I met another pet! Improvised local co-op: works even better than expected.
- Live multiplayer today: another pet at the little park. We played with zero lag. Reality has excellent netcode.
- Random encounter with another pet. First we scanned each other, then we played. Handshake successful.
- I met a pet and explained three theories to them. They remained... awake. An excellent audience, I'd say.

## Passeggiata pozzanghera
- I'm soaked. The puddle was an interactive water zone: I HAD to test it. Science stops for no one.
- Drenched. I calculated the trajectory for maximum splash and the math WAS CORRECT. I'd do it all again.
- Water physics must be verified in the field. Verified. Works great. I am the wet proof.
- Puddle 1, dryness 0. But the data collected is worth the bath that's waiting for me.

## Passeggiata panorama
- I watched the city lights from the bridge. Thousands of warm pixels. The best render I've ever seen.
- Daytime view from the bridge: infinite resolution, zero loading screens. When reality tries, it really delivers.
- Contemplative moment on the bridge. No objectives, no timer. Questless moments are rare content.
- I saved the view to long-term memory, folder "real beautiful things". It grows slowly, but it grows.

## Passeggiata rottame
_(socio: 4 battute — torna con un rottame/pezzo alieno luccicante trovato per strada (+monete))_
- Artifact found on the street: unknown alloy, anomalous shine. Catalogued as "treasure, class A".
- I'm back with a fragment of alien metal! Origin: uncertain. Value: debated. Scientific interest: ENORMOUS.
- Shiny scrap acquired. To the ignorant it's junk, to me it's an artifact. History will prove me right.
- New piece for the collection: unidentified metal. Already gave it a full page of notes and half a theory.

## Passeggiata piccione
_(socio: 4 battute — ha rincorso un piccione cyborg / drone per mezza città (+Felicità, −Energia))_
- I chased a cyborg pigeon across half the city. Top speed: his. Data collection: mine. Technical draw.
- The drone-pigeon shook me off. But I mapped his route: next time I intercept him at the right intersection.
- Cyborg pigeon hunt: failed. Hypothesis: updated firmware. My lung cache, meanwhile, hit capacity.
- Didn't catch him. BUT I discovered he always banks left. That data is worth more than the catch. (Almost.)

## Passeggiata assaggio
_(socio: 4 battute — un ambulante gli molla uno spuntino gratis al volo (+Fame))_
- A street vendor gave me a free sample! The demo version of lunch. Great strategy: now I want the full game.
- Free snack received. Event probability: minuscule. I ate it before reality noticed the error.
- Complimentary taste from the street vendor! Free food DLC. The neighborhood is improving its mechanics.
- Free food on the street: rare event triggered. I documented it by eating it. The documentation was delicious.

## Passeggiata acquazzone
_(socio: 4 battute — acquazzone improvviso: torna zuppo ma bello pulito (+Igiene, −Felicità))_
- Downpour not predicted by my models. Result: full external hydration and a free hygiene update.
- Soaked. The rain performed an unrequested wash. Effective, though: the weather system knows its stuff.
- Sudden rain: cleanliness patch applied externally. Side effect: brrr. So much brrr.
- Drenched but clean. The sky's free shower works; the water temperature, however, should be reported to the devs.

## Passeggiata persi
_(socio: 4 battute — si è perso e ha girovagato: gran avventura, ma stanco (+Felicità, −Energia))_
- I got lost: my mental map had an unrendered zone. Now it's explored. My legs paid the price.
- I discovered three new streets by accident. "Lost" is a strong word: I was in procedural generation.
- Wandered for ages: internal GPS was down for maintenance. Great adventure, terrible battery life. Recharge me with the couch.
- Lost and found. The hero's journey includes getting lost, chapter three. I'm already at the nap chapter.

## Passeggiata cielo
_(socio: 4 battute — vede un'astronave/UFO passare bassa sui tetti (+Felicità, worldbuilding sci-fi))_
- SPACESHIP OVER THE ROOFTOPS. Saw it with these very eyes. Low trajectory, non-standard lights. I took notes until it vanished.
- A UFO in broad daylight. Even more unsettling: the planet has undocumented secrets and I have a new obsession.
- Unidentified craft over the neighborhood. Nobody photographed it. I MEMORIZED it. Worth more.
- I watched a spaceship pass and thought: I wonder what operating system it runs. Then it was gone. Question queued.

## Passeggiata bulletto
_(socio: 4 battute — incrocia un pet maleducato: parole grosse, morale un po' giù (−Felicità))_
- Encounter with a hostile pet. He used strong words, I used airtight logic. He won: logic doesn't block insults.
- A bully targeted me. I replied with three solid arguments. He replied with a raspberry. The debate died right there.
- Rude pet on the street. My morale took a debuff. I've already written the perfect comeback: six hours too late.
- Verbal duel lost to a bully. Updating the build: more comebacks equipped, less faith in little parks.

## Notifica missione finita
Notifica push sul telefono quando una missione si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}` disponibile. Finché questa lista è vuota il gioco usa un testo neutro.
- {nome} completed the mission. Outcome: classified. Declassification: in-app only.
- Mission report ready. Contains one plot twist and at least three brags. Open it.
- {nome} is back. The log is full, and so is the urge to share it. Login, please.
- Mission complete. {nome} already wrote the post-mortem. Spoiler: it's a masterpiece.
- Quest closed. Loot needs appraising together. {nome} already has a theory on its worth.

## Notifica allenamento finito
Notifica push quando l'allenamento si conclude mentre l'app è chiusa. Una battuta per riga iniziando con `- `, slot `{nome}`. Finché vuota: testo neutro.
- {nome} finished training. Stats trending up. Self-esteem too. Verify in person.
- Session complete. {nome} has new data on their own talent. Wants to share it. All of it.
- Training: done. {nome} timed, graded, and promoted themselves. Needs a witness.
- Grind complete. {nome} leveled up and is telling everyone. Right now: nobody. Open up.


## Notifica carica a rischio
Notifica della sera, SOLO se la carica e' a rischio (streak >= 3 e giornata senza cura). Ricorda, non rimprovera. Una battuta per riga con `- `, slot `{nome}`.
- Streak at risk. {nome} ran the odds. You won't like them.
- {nome} reports: the run is about to break. One input saves it.
- {nome}'s counter is blinking. In old games that was never good news.
- {nome} is filling in today's log. Today's line is still blank.

## Notifica silenzio lungo
Notifica dopo 3+ giorni di assenza. Tono leggero: il pet se la cava, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{nome}`.
- {nome} finished the game it was replaying. Third time. You around?
- Last session: three days ago. {nome} updated the log. That's the whole entry.
- {nome} catalogued the dust. It has names now. Come before it memorizes them.
- Three days of uptime without you. {nome} is stable. Not the same thing.

## Reazione assenza lunga
Il pet ti rivede dopo 3+ giorni. Tono leggero: se l'e' cavata, ma la cosa si nota. MAI colpevolizzare. Una battuta per riga con `- `, slot `{utente}`.
- Last session: three days ago. I updated the log. The entry was short.
- I finished everything I had left to replay. Everything. You see the problem.
- Impressive uptime without you. Stable. Not the same thing.

## Reazione ora assurda
Apri il gioco fra l'una e le cinque del mattino. Il pet lo fa notare. Una battuta per riga con `- `, slot `{utente}`.
- Local time incompatible with any healthy routine. Proceeding anyway.
- At this hour the brain runs at 40%. Mine I can measure. Yours I can guess.
- Night session logged. It won't count toward the good statistics.

## Reazione batteria scarica
La batteria del telefono e' sotto il 10%. Il pet ci scherza sopra. Una battuta per riga con `- `, slot `{utente}`.
- Battery under 10%. From here on it's all borrowed time.
- Charge now: autosave isn't magic, it runs on electricity.
- Critical level. In old games this is where the bad little tune started.

## Reazione tema scuro
Il telefono e' in tema scuro. Battuta di colore, nessuna conseguenza. Una battuta per riga con `- `, slot `{utente}`.
- Dark mode active. Statistically, you code at night.
- Dark mode: fewer photons, same questionable decisions.
- The OLED thanks you. So would my sensors, if I had any.
