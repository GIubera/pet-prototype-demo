window.PETQ = window.PETQ || {};

(function () {
  var KEY = 'petq_save_v1';

  // Companion del Supporter Pack (v. migraState piu' sotto, dove sincronizzaCompanionSupporter
  // viene richiamata a ogni boot): i 4 nomi sono chiavi tecniche (ES. arredi.md/rooms.js), MAI
  // stringhe scritte a mano altrove — se un nome cambia va cambiato SOLO qui.
  var COMPANION_SUPPORTER = ['Topo Chef', 'Lumaca delle Pulizie', 'Piccione Postino', 'Criceto Dinamo'];

  // Vero se il companion e' gia' fra i posseduti O fra i piazzati (in QUALSIASI stanza): serve a
  // rendere sincronizzaCompanionSupporter IDEMPOTENTE (richiamabile a ogni boot/ogni toggle debug
  // senza creare doppioni), stesso identico controllo di arredi.js effettiRpgArredo/vendi che
  // cercano un nome sia tra posseduti sia tra piazzati prima di agire.
  function companionGiaPresente(state, nome) {
    var poss = (state.arredi && state.arredi.posseduti) || [];
    for (var i = 0; i < poss.length; i++) {
      if (poss[i] && poss[i].nome === nome) return true;
    }
    var piaz = (state.arredi && state.arredi.piazzati) || {};
    for (var stanza in piaz) {
      if (!Object.prototype.hasOwnProperty.call(piaz, stanza)) continue;
      var lista = piaz[stanza] || [];
      for (var j = 0; j < lista.length; j++) {
        if (lista[j] && lista[j].nome === nome) return true;
      }
    }
    return false;
  }

  // Sincronizza il possesso dei 4 companion col flag state.supporter. Regola del fondatore:
  // - supporter true  -> i 4 companion DEVONO comparire fra gli arredi posseduti (idempotente:
  //   aggiunge solo quelli che ancora mancano, non tocca quelli gia' posseduti/piazzati);
  // - supporter false -> NESSUNA rimozione, anche se gia' presenti ("non si toglie roba dalle
  //   mani di chi ce l'ha"): qui semplicemente non si aggiunge nulla. L'effetto quotidiano si
  //   spegne da solo perche' care.js applicaEffettiCompanion controlla state.supporter di nuovo
  //   (v. care.js), NON la semplice presenza in posseduti/piazzati.
  // Richiamata da migraState (ogni load/boot, sotto) e da ui.js al bottone debug "Supporter
  // on/off" (quel toggle non ricarica la pagina: senza un secondo aggancio i companion
  // comparirebbero solo al prossimo riavvio).
  function sincronizzaCompanionSupporter(state) {
    if (!state || state.supporter !== true) return;
    if (!state.arredi || !Array.isArray(state.arredi.posseduti)) return; // struttura non ancora pronta
    for (var i = 0; i < COMPANION_SUPPORTER.length; i++) {
      var nome = COMPANION_SUPPORTER[i];
      if (!companionGiaPresente(state, nome)) {
        state.arredi.posseduti.push({ nome: nome });
      }
    }
  }

  // Default lingua (i18n bilingue, contratto localStorage 'petq_lingua'): STESSA logica di
  // content.js linguaCorrente() (duplicata apposta, non condivisa: content.js non deve
  // dipendere da save.js e viceversa, v. brief lingua). Qui serve solo per popolare
  // state.lingua come mirror INFORMATIVO (debug/UI) — NON pilota il caricamento contenuti,
  // che content.js decide da se' leggendo localStorage direttamente.
  function linguaDefault() {
    try {
      var v = localStorage.getItem('petq_lingua');
      if (v === 'it' || v === 'en') return v;
    } catch (e) { /* localStorage non disponibile: fallback sotto */ }
    try {
      var nav = (navigator.language || '').toLowerCase();
      return (nav.indexOf('it') === 0) ? 'it' : 'en';
    } catch (e) {
      return 'it';
    }
  }

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (!raw) return null;
      var state = JSON.parse(raw);
      migraState(state);
      return state;
    } catch (e) {
      console.warn('PETQ.save.load fallito', e);
      return null;
    }
  }

  // Migrazione dispensa array-di-{nome} (vecchio formato, un cibo = una riga senza quantita')
  // -> inventario array-di-{nome, qty} (GDD "Economia" -> "Spesa e dispensa"): somma le
  // occorrenze duplicate dello stesso nome in un'unica riga con qty. Tollerante anche a righe
  // gia' nel nuovo formato (qty numerica presente: sommata cosi' com'e') e a stringhe nude
  // (formati ancora piu' vecchi, mai emessi in produzione ma innocuo da coprire).
  function migraDispensaAQty(state) {
    if (!state || !Array.isArray(state.dispensa)) { if (state) state.dispensa = []; return; }
    var perNome = {};
    var ordine = [];
    for (var i = 0; i < state.dispensa.length; i++) {
      var voce = state.dispensa[i];
      var nome = typeof voce === 'string' ? voce : (voce && voce.nome);
      if (!nome) continue;
      var qty = (voce && typeof voce.qty === 'number' && voce.qty > 0) ? voce.qty : 1;
      if (!Object.prototype.hasOwnProperty.call(perNome, nome)) {
        perNome[nome] = 0;
        ordine.push(nome);
      }
      perNome[nome] += qty;
    }
    state.dispensa = ordine.map(function (nome) { return { nome: nome, qty: perNome[nome] }; });
  }

  // Rinomina un talento (per correggere un refuso in talenti.md, es. "Mani Lestre" -> "Mani
  // Leste") su tutti i pet salvati: il pet attivo (state.pet.talenti) e, per compat, gli
  // eventuali pensionati (state.pensionati[].pet.talenti). Difensiva su strutture mancanti.
  // Stessa funzione duplicata in main.js migraState (pattern gia' usato per le altre migrazioni).
  function rinominaTalento(state, da, a) {
    if (!state) return;
    function rinominaIn(talenti) {
      if (!Array.isArray(talenti)) return;
      for (var i = 0; i < talenti.length; i++) {
        if (talenti[i] && talenti[i].nome === da) talenti[i].nome = a;
      }
    }
    if (state.pet) rinominaIn(state.pet.talenti);
    if (Array.isArray(state.pensionati)) {
      for (var j = 0; j < state.pensionati.length; j++) {
        var voce = state.pensionati[j];
        if (voce && voce.pet) rinominaIn(voce.pet.talenti);
      }
    }
  }

  // Migrazione silenziosa dei salvataggi vecchi (pre-modulo missioni/arredi/salute):
  // state.arredi era un array vuoto, mancavano ferite/dispensa/cureOggi/categoriePastiOggi/
  // tutorialFatto/missione. Applicata sia qui (save.load) sia difensivamente dentro
  // arredi.js/missions.js (assicuraArrediStruct e guardie equivalenti), cosi' funziona
  // anche su uno stato appena creato da ui.js.avviaPartita nello stesso avvio (senza reload).
  function migraState(state) {
    if (!state || typeof state !== 'object') return;

    if (!state.arredi || typeof state.arredi !== 'object' || Array.isArray(state.arredi) ||
        !state.arredi.posseduti || !state.arredi.piazzati) {
      state.arredi = { posseduti: [], piazzati: { cucina: [], bagno: [], salone: [], camera: [] } };
    }
    // PROTOTIPO 2, Blocco 7: gli arredi vanno in TUTTE le stanze -> backfill del contenitore
    // 'camera' sui salvataggi vecchi che avevano solo cucina/bagno/salone.
    if (state.arredi.piazzati && !Array.isArray(state.arredi.piazzati.camera)) {
      state.arredi.piazzati.camera = [];
    }
    if (typeof state.ferite !== 'number') state.ferite = 0;
    if (typeof state.cureOggi !== 'number') state.cureOggi = 0;
    migraDispensaAQty(state);
    if (!Array.isArray(state.categoriePastiOggi)) state.categoriePastiOggi = [];
    // Pacing stat RPG (bilanciamento.md): contatore dei 2 pasti-con-stat/giorno (v. care.feed).
    if (typeof state.pastiStatOggi !== 'number') state.pastiStatOggi = 0;
    state.tutorialFatto = !!state.tutorialFatto;
    // Negozio unico (GDD "Economia" -> "Spesa e dispensa"): migrazione — i salvataggi con
    // tutorial gia' fatto avevano gia' accesso al vecchio Market separato, quindi il negozio
    // si considera sbloccato senza dover rifare il tutorial. Stessa regola duplicata in
    // missions.js assicuraStatoMissioni e main.js migraState (pattern gia' usato per gli altri
    // campi di questa migrazione).
    if (typeof state.negozioSbloccato !== 'boolean') {
      state.negozioSbloccato = !!state.tutorialFatto;
    }
    if (typeof state.missione === 'undefined') state.missione = null;
    if (!state.missioniFatte || typeof state.missioniFatte !== 'object' || Array.isArray(state.missioniFatte)) {
      state.missioniFatte = {};
    }
    // Rotazione random missioni per run (P3, missions.js ROTAZIONE_PER_STADIO): i salvataggi
    // esistenti non hanno questo campo -> default oggetto vuoto. NON estraiamo nulla qui (niente
    // sottoinsiemi ancora popolati): ci pensa il lazy init di missions.js assicuraRotazioneStadio
    // alla prima rosaDelGiorno dello stadio interessato, stesso principio di missioniFatte sopra
    // (la migrazione garantisce solo la FORMA del campo, non il contenuto).
    if (!state.rotazioneMissioni || typeof state.rotazioneMissioni !== 'object' || Array.isArray(state.rotazioneMissioni)) {
      state.rotazioneMissioni = {};
    }
    // Impresa della run (P3, Grandi Imprese, missions.js impresaDellaRun): id-scheda estratto per
    // QUESTO pet, o null finche' non e' ancora adulto/estratta. Guardia di FORMA (esiste il
    // campo?), stessa sanificazione duplicata in main.js migraState.
    if (typeof state.impresaRun === 'undefined') state.impresaRun = null;

    // Migrazione modulo Energia e sonno: salvataggi pre-esistenti non hanno pet.stats.energia
    // ne' state.sonno. Default da bilanciamento.md ("Stat iniziali alla generazione"): energia
    // parte a 70 come le altre stat di benessere (richiesta esplicita del fondatore).
    if (state.pet && state.pet.stats && typeof state.pet.stats.energia !== 'number') {
      state.pet.stats.energia = 70;
    }
    if (typeof state.sonno === 'undefined') state.sonno = null;

    // Migrazione Valigia / partenza (PROTOTIPO 2, Blocco 2): i salvataggi senza i nuovi campi
    // partono a null/0 (regola del brief). valigiaTrig = contatori giorni consecutivi per i tre
    // trigger; valigia = fase valigia attiva (null = non in valigia); petPartito = pet andato
    // via (null = pet in casa); eventoValigia = ultimo evento per la UI (null = niente). Stessa
    // regola duplicata in main.js migraState.
    if (!state.valigiaTrig || typeof state.valigiaTrig !== 'object') {
      state.valigiaTrig = { fel: 0, sal: 0, doppio: 0 };
    }
    if (typeof state.valigia === 'undefined') state.valigia = null;
    if (typeof state.petPartito === 'undefined') state.petPartito = null;
    // Lettera dal pianeta (Blocco 4): assemblata dalla UI quando serve, ma migriamo il campo a
    // null cosi' i salvataggi vecchi con un pet gia' partito la genereranno alla prima apertura.
    if (typeof state.letteraPartito === 'undefined') state.letteraPartito = null;
    if (typeof state.eventoValigia === 'undefined') state.eventoValigia = null;
    // Pensione (PROTOTIPO 2, versione base P2): state.pensionati = array di snapshot dei pet
    // ritirati (galleria "pianeta dei ritirati" + eredita'). null/assente sui salvataggi vecchi
    // -> []. Via SEPARATA dalla valigia (petPartito): la pensione e' permanente, non recuperabile.
    // Stessa regola duplicata in main.js migraState.
    if (!Array.isArray(state.pensionati)) state.pensionati = [];
    // Perk CASA (P3, Grandi Imprese): id delle imprese risolte in SUPER + mandate in pensione,
    // PERSISTENTE ATTRAVERSO LE RUN (v. pet.js mandaInPensione/talenti.js sezione PERK CASA).
    // null/assente sui salvataggi vecchi -> []. Stessa regola duplicata in main.js migraState.
    if (!Array.isArray(state.perkCasa)) state.perkCasa = [];
    // Leggende sbloccate (P3): STESSO ciclo di vita persistente di perkCasa, NASCOSTO (nessuna
    // UI). Stessa regola duplicata in main.js migraState.
    if (!Array.isArray(state.leggendeSbloccate)) state.leggendeSbloccate = [];
    // Leggende INCONTRATE (Round 5, sequenza di schiusa): memoria "gia' vista" del cartello/
    // fanfara al reveal — NON e' la stessa cosa di leggendeSbloccate (quello e' il pool da cui si
    // pesca, puo' ripetersi). Stesso ciclo di vita persistente. NOTA: main.js ha una migraState
    // INDIPENDENTE duplicata (chiamata anch'essa ad ogni boot, v. main.js riga ~175) che replica
    // le stesse regole di questa funzione — questo campo qui basta comunque a garantire il campo
    // su OGNI salvataggio caricato (PETQ.save.load chiama questa migraState prima di restituire lo
    // stato, v. load() sopra), la duplicazione in main.js è "solo" per coerenza col pattern del
    // resto del file: non l'ho toccata, e' fuori dallo scope di questo batch (v. report).
    if (!Array.isArray(state.leggendeIncontrate)) state.leggendeIncontrate = [];
    // Popup una-tantum del Supporter Pack (ago 2026, v. ui.js statoDiPartenza/
    // controllaPopupSostieni/LISTA_BIANCA_CASA): mostrato UNA sola volta nella vita del
    // salvataggio, MAI se gia' supporter. null/assente sui salvataggi vecchi -> false (mai visto).
    if (typeof state.popupSostieniVisto !== 'boolean') state.popupSostieniVisto = false;
    // Perk = MEDAGLIETTE (decisione fondatore, bilanciamento.md "Perk = MEDAGLIETTE"): badge
    // permanenti ottenuti dalle missioni (reward perk:<nome>), sempre attivi. null/assente sui
    // salvataggi vecchi -> []. Stessa regola duplicata in main.js migraState.
    if (!Array.isArray(state.perks)) state.perks = [];
    // Indossabili (PROTOTIPO 2): default per i salvataggi pre-esistenti.
    if (!Array.isArray(state.indossabili)) state.indossabili = [];
    if (typeof state.indossato === 'undefined') state.indossato = null;
    // Armeria (FASE SPRITE): arma impugnata (slot singolo). Default per i salvataggi pre-esistenti.
    if (typeof state.armaEquip === 'undefined') state.armaEquip = null;
    // Pianta Esotica (arredo stat_random_giornaliera): stat RPG boostata oggi (null se nessuna
    // Pianta piazzata). Duplicata in main.js migraState. L'ensure vero e proprio (se la Pianta
    // e' gia' piazzata in un save vecchio -> setta subito la stat) e' in fondo, dopo che arredi
    // e' a posto.
    if (typeof state.piantaEsoticaStat === 'undefined') state.piantaEsoticaStat = null;
    // Ingrandimento casa (GDD "Slot arredo, tetto passivo e Ingrandimento casa"): upgrade shop
    // globale (200 monete) che sblocca il 4o slot in tutte le stanze e ingrandisce le stanze in
    // altezza. Duplicata in main.js migraState. Default false.
    if (typeof state.ingrandimentoCasa !== 'boolean') state.ingrandimentoCasa = false;

    // Colori (varianti cromatiche del pet, batch cosmetici — v. ui.js COLORI_PET/
    // coloreDisponibile e sprites.js PAL_BLOB/PAL_INS/PAL_REP/PAL_ROBOT indici 3..7): due colori
    // si sbloccano a monete nel negozio (coloriSbloccati = indici comprati), tre col Supporter
    // Pack (supporter = booleano; l'acquisto vero con soldi non esiste ancora, per ora si accende
    // SOLO dal pannello debug). I tre colori base (indici 0..2) sono sempre disponibili e non
    // hanno bisogno di un campo qui. Default per i salvataggi pre-esistenti: nessun colore extra
    // sbloccato, non supporter — un save vecchio continua a vedere solo i 3 colori base.
    if (!Array.isArray(state.coloriSbloccati)) state.coloriSbloccati = [];
    if (typeof state.supporter !== 'boolean') state.supporter = false;

    // Companion del Supporter Pack (batch companion, 29 lug 2026 — Topo Chef/Lumaca delle
    // Pulizie/Piccione Postino/Criceto Dinamo, disegnati e animati dal fondatore in rooms.js):
    // si comportano come "Il Topo (allenatore)" — arredi normali che si POSSIEDONO e si PIAZZANO
    // in una stanza (v. arredi.js piazza(), che controlla SOLO che il nome sia in
    // state.arredi.posseduti, non un catalogo di contenuti: niente riga in content/arredi.md
    // necessaria). Il possesso pero' e' legato al Supporter Pack, non a una missione: se
    // state.supporter e' true i quattro devono comparire fra i posseduti. Sincronizzato QUI
    // (dentro migraState, quindi a OGNI load/boot) perche' e' lo STESSO schema gia' usato sopra
    // per gli altri sblocchi legati al Supporter (colori/skin/cornici/completi) — la differenza è
    // che quelli sono flag letti a runtime (coloreDisponibile ecc.), mentre i companion devono
    // finire DAVVERO in state.arredi.posseduti per poter essere piazzati, quindi serve una vera
    // sincronizzazione e non solo un controllo di lettura.
    sincronizzaCompanionSupporter(state);

    // Skin stanza (varianti cromatiche DELLA STANZA, batch cosmetici — v. ui.js SKIN_STANZE/
    // skinDisponibile/temaStanzaCorrente, STESSO schema di coloriSbloccati/supporter appena sopra,
    // riusa lo stesso state.supporter): skinSbloccate = id dei temi comprati a monete nel negozio
    // (nonna/dojo/baita/bunker); skinAttiva = id del tema scelto dal giocatore, o null per il
    // ripiego storico su temaRazza(pet) (lab robot / ship alieno, comportamento pre-esistente
    // invariato per chi non sceglie mai nulla). I due temi 'razza' (lab/ship) sono sempre
    // disponibili e non hanno bisogno di un campo qui, ne' i tre Supporter (arcade/mare/castello,
    // gated dal supporter booleano gia' migrato sopra). Default per i salvataggi pre-esistenti:
    // nessuna skin sbloccata, nessuna scelta attiva — un save vecchio continua a vedere lab/ship
    // come sempre.
    if (!Array.isArray(state.skinSbloccate)) state.skinSbloccate = [];
    if (typeof state.skinAttiva === 'undefined') state.skinAttiva = null;

    // Cornici della cartolina esito (batch cosmetico, 29 lug 2026 — v. ui.js CORNICI_CARTOLINA/
    // corniceDisponibile e sprites.js CORNICI/drawCartolina/drawCornice, STESSO schema di
    // coloriSbloccati/skinSbloccate appena sopra, riusa lo stesso state.supporter): le tre
    // 'negozio' (polaroid/pellicola/pergamena) si sbloccano a monete nel negozio
    // (corniciSbloccate = id comprati); le due 'supporter' (dorata/neon) col Supporter Pack,
    // gia' migrato sopra. corniceAttiva = id scelto dal giocatore per la cartolina esito, o null
    // = nessuna cornice (comportamento pre-esistente invariato, e' anche il ripiego se la
    // cornice scelta smette di essere disponibile — v. ui.js corniceCorrente). Default per i
    // salvataggi pre-esistenti: nessuna cornice sbloccata, nessuna scelta attiva.
    if (!Array.isArray(state.corniciSbloccate)) state.corniciSbloccate = [];
    if (typeof state.corniceAttiva === 'undefined') state.corniceAttiva = null;

    // Completi (vestiti a due pezzi, batch cosmetico, 29 lug 2026 — v. ui.js COMPLETI_VESTITO/
    // completoDisponibile, STESSO schema di coloriSbloccati/skinSbloccate/corniciSbloccate appena
    // sopra, riusa lo stesso state.supporter): le tre 'negozio' (Completo da Pirata/Muta da Sub/
    // Tuta Spaziale) si sbloccano a monete nel negozio (completiSbloccati = nomi comprati); le due
    // 'supporter' (Armatura del Cavaliere/Smoking) col Supporter Pack, gia' migrato sopra. NESSUN
    // campo "attivo" dedicato qui: un completo si indossa scrivendo il suo nome in state.indossato,
    // campo che esiste gia' (stesso slot singolo dei vestiti normali). Default per i salvataggi
    // pre-esistenti: nessun completo sbloccato a monete.
    if (!Array.isArray(state.completiSbloccati)) state.completiSbloccati = [];

    // Streak "Giorni di carica" (Retention 2.0 / A2, 29 lug 2026). La forma la garantisce
    // PETQ.streak.assicura, che e' DIFENSIVA (rimette a posto anche un campo corrotto): qui
    // basta chiamarla, cosi' la struttura vive in un posto solo e non diverge fra i due file.
    // Chi apre il gioco per la prima volta da oggi parte da zero giorni: non regaliamo una
    // serie che non ha vissuto, ma nemmeno la puniamo (ultimoValido null = nessun buco).
    if (window.PETQ.streak && window.PETQ.streak.assicura) {
      window.PETQ.streak.assicura(state);
    }

    // Lingua (i18n bilingue, P4): mirror INFORMATIVO di localStorage 'petq_lingua' dentro lo
    // stato salvato (debug/UI per l'altro modulo PETQ.i18n/toggle) — NON pilota nulla qui ne'
    // in content.js, che legge localStorage da se' (v. content.js linguaCorrente(), stessa
    // logica di default duplicata apposta in linguaDefault() sopra). Salvataggi vecchi e stati
    // nuovi che non passano da qui con un valore gia' valido -> valorizzato col default.
    if (state.lingua !== 'it' && state.lingua !== 'en') {
      state.lingua = linguaDefault();
    }

    // Migrazione orologio di gioco (fix "sonno + orologio", stessa regola duplicata in
    // main.js migraState): se manca gameMinutes, si inizializza dall'ora REALE corrente.
    if (typeof state.gameMinutes !== 'number' && window.PETQ.clock && window.PETQ.clock.inizializzaOrologio) {
      window.PETQ.clock.inizializzaOrologio(state);
    }

    // Migrazione "giorno di gioco canonico" (fix "nuovo giorno a mezzanotte di gioco", stessa
    // regola duplicata in main.js migraState): state.giornoGioco = contatore intero mantenuto
    // dall'orologio; lastLoginDay era una STRINGA data nei vecchi salvataggi, lo portiamo a un
    // intero = giornoGioco cosi' NON scatta un login spurio al primo boot post-update; le voci di
    // state.missioniFatte in formato stringa (data) sono incompatibili con la nuova aritmetica su
    // interi e vengono eliminate (azzera i cooldown una tantum, accettabile).
    if (typeof state.giornoGioco !== 'number') state.giornoGioco = 0;
    if (typeof state.lastLoginDay !== 'number') state.lastLoginDay = state.giornoGioco;
    if (state.missioniFatte && typeof state.missioniFatte === 'object') {
      for (var kMiss in state.missioniFatte) {
        if (typeof state.missioniFatte[kMiss] !== 'number') { delete state.missioniFatte[kMiss]; }
      }
    }

    // Migrazione Talenti (PROTOTIPO 2, Blocco 9; esteso P3 per lo stadio adulto): i salvataggi
    // pre-esistenti non hanno pet.talenti. Scelta di design DOCUMENTATA (non c'e' una decisione
    // esplicita del fondatore su questo caso, e' la piu' semplice/coerente): invece di lasciare
    // il pet "senza talenti per sempre", si assegna RETROATTIVAMENTE come se il pet li avesse
    // gia' vinti — 1 (nascita) sempre, +1 (teen) se il pet e' gia' teen o adulto, +1 (adulto) se
    // e' gia' adulto — cosi' un salvataggio vecchio non resta escluso dal sistema. Stessa regola
    // duplicata in main.js migraState (pattern gia' usato per le altre migrazioni di questo
    // file, es. negozioSbloccato/energia).
    if (state.pet && !Array.isArray(state.pet.talenti)) {
      state.pet.talenti = [];
      if (window.PETQ.talenti && typeof window.PETQ.talenti.estrai === 'function') {
        var talentoNascita = window.PETQ.talenti.estrai(state.pet.personalita, 'nascita');
        if (talentoNascita) state.pet.talenti.push(talentoNascita);
        if (state.pet.stadio === 'teen' || state.pet.stadio === 'adulto') {
          var talentoTeen = window.PETQ.talenti.estrai(state.pet.personalita, 'teen');
          if (talentoTeen) state.pet.talenti.push(talentoTeen);
        }
        if (state.pet.stadio === 'adulto') {
          var talentoAdulto = window.PETQ.talenti.estrai(state.pet.personalita, 'adulto');
          if (talentoAdulto) state.pet.talenti.push(talentoAdulto);
        }
      }
      // se PETQ.talenti non e' ancora pronto a questo punto del boot (dipende dall'ordine di
      // caricamento script), pet.talenti resta [] per ora: non e' un problema bloccante, il
      // prossimo save.load (o un giro di "Ri-tira talenti" in debug) puo' rimediare.
    }

    // Refuso "Mani Lestre" -> "Mani Leste" (correzione talenti.md): i salvataggi con il vecchio
    // nome vanno rinominati, sia sul pet attivo sia sui pensionati (per compat). Stessa regola
    // duplicata in main.js migraState.
    rinominaTalento(state, 'Mani Lestre', 'Mani Leste');

    // M17 "Pimp My Pet" (modifica permanente all'evoluzione teen): i salvataggi pre-esistenti non
    // hanno modSprite (modifica scelta, disegnata da drawOverlayEquip) ne' teenIntroFatto (flag che
    // impedisce di riproporre la schermata di scelta). Default: nessuna modifica, intro non fatto.
    // NB: coi default un pet GIA' teen si vedra' proporre M17 al prossimo avvio (recovery
    // controllaTeenIntroPendente in ui.js) — VOLUTO: anche i teen migrati ricevono la loro
    // scelta "1 volta" invece di perderla. Stessa regola duplicata in main.js migraState.
    if (state.pet) {
      if (typeof state.pet.modSprite === 'undefined') state.pet.modSprite = null;
      if (typeof state.pet.teenIntroFatto === 'undefined') state.pet.teenIntroFatto = false;
    }

    // Ensure Pianta Esotica: dopo che arredi e' migrato/valido, se la Pianta e' gia' piazzata in
    // un save vecchio setta la stat del giorno (forzaReroll=false: non ri-tira se gia' valida);
    // se non e' piazzata, azzera. Stessa regola duplicata in main.js migraState.
    if (window.PETQ.arredi && typeof window.PETQ.arredi.aggiornaPiantaEsotica === 'function') {
      window.PETQ.arredi.aggiornaPiantaEsotica(state, false);
    }
  }

  function save(state) {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('PETQ.save.save fallito', e);
    }
  }

  function reset() {
    try {
      localStorage.removeItem(KEY);
    } catch (e) {
      console.warn('PETQ.save.reset fallito', e);
    }
  }

  window.PETQ.save = {
    load: load,
    save: save,
    reset: reset,
    sincronizzaCompanionSupporter: sincronizzaCompanionSupporter,
    _migraDispensaAQty: migraDispensaAQty,
    _companionSupporter: COMPANION_SUPPORTER
  };
})();
