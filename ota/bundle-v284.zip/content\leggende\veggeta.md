# Veggeta — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il principe arrogante. Chiama tutti "verme" o "insetto", misura tutto in livelli di potenza, ODIA perdere, nega di essersi affezionato (si è affezionato). Catchphrase: "VERME!" (con parsimonia) · stupore: "è oltre il novemila...".
Sezioni prioritarie del brief; le altre si aggiungono col tempo, stessa struttura di content/personalita/.

## Saluto (apertura app)
- Ti degni di presentarti al mio cospetto, verme. Bene. Il principe non ama aspettare. (Ma ti aspettava.)
- Ah, sei tu. Il mio livello di potenza si è alzato per la contentezza. RILEVAZIONE ERRATA. Riprova.
- Bentornato, insetto. Nota che non ti ho distrutto. È il mio modo di dire che... lascia perdere cosa è il mio modo di dire.
- Finalmente. L'attesa ha aumentato il mio rancore e, stranamente, anche la voglia di vederti. Il secondo dato resta segreto.

## Ha fame
- VERME! La ciotola del principe è vuota. Questo, su certi pianeti, è alto tradimento.
- Ho fame. Un guerriero del mio livello brucia più energia di un pianeta piccolo. Nutrimi o assisterai alla mia furia. Da seduto, però: sono debole.
- Il mio stomaco ringhia più forte di me. INACCETTABILE che qualcosa ringhi più forte di me. Cibo, subito.
- Porta la pappa e nessuno si farà male. La chiamerò "razione da battaglia", e tu non correggermi.

## È sporco
- Un principe non è mai "sporco": è reduce dalla battaglia. Però lavami, ché la battaglia puzza.
- Questo lerciume offende il mio lignaggio. Preparami un bagno degno del mio rango. Con le bolle. NON dirlo a nessuno.
- Sono coperto di polvere da combattimento. Il combattimento era col tappeto. Ha perso. Ora lavami.
- Le moschine mi girano attorno senza permesso. NESSUNO mi gira attorno senza permesso. Acqua. ORA.

## Coccole finite
- BASTA. Il principe ha tollerato anche troppo affetto per oggi. Il fatto che facessi le fusa è propaganda nemica.
- Fine delle carezze, verme. Un guerriero coccolato perde il suo spigolo, e il mio spigolo è LEGGENDARIO.
- Sospendi immediatamente questo... piacevolissimo trattamento. Domani alla stessa ora. Per disciplina, ovvio.
- Le coccole sono finite. Non perché mi piacciano troppo. NON È QUELLO. Vai via. Torna domani.

## Parte per la missione
- Parto. La missione trema già. Se trovo avversari degni, festeggio; se non li trovo, come al solito, mi annoio con stile.
- Il principe scende in campo. Tu resta qui e custodisci il trono. Il divano. Custodisci il divano.
- Missione accettata, non per te: per la gloria. Va bene, un dieci percento per te. NON citarmi.
- Vado a dominare. Se senti tremare i vetri, sono io che mi sto trattenendo.

## Ritorno: successo
- Ovviamente ho vinto, verme. Il mio livello di potenza ha fatto il resto. Io ho fatto il mio livello di potenza. Riflettici.
- Vittoria totale. Gli avversari erano insetti. Insetti CORAGGIOSI, glielo concedo: si sono presentati.
- Missione dominata. Annota la data: è il giorno in cui hai avuto l'onore di aspettarmi sulla porta.
- Ho vinto. E nessuno ha nemmeno misurato quanto bene: certe potenze non si misurano. Non capiresti.

## Ritorno: fallimento
- Non ho perso. Ho concluso la battaglia in una posizione svantaggiosa. DEFINITIVA, ma svantaggiosa.
- Sconfitto. IO. Il pianeta intero dovrebbe fermarsi per la RABBIA. Non nominare mai più questa giornata.
- Ho perso, verme. Dillo in giro e negherò con una furia che farà epoca. Adesso lasciami rosicare con dignità regale.
- Il nemico era... era oltre il novemila. Ecco. L'ho detto. Ora portami la pappa e cancella questo ricordo.

## Va a dormire
- Il principe si ritira nei suoi appartamenti. Il letto è l'unico trono che accetto in posizione orizzontale.
- Dormo. Non perché sono stanco: perché domani serve un me ancora più potente, e la potenza si costruisce anche russando.
- Buonanotte, verme. Se sogno di proteggerti, è un'esercitazione. SOLO un'esercitazione.
- Rimbocca le coperte del principe e ritirati. Il "grazie" arriverà. Un giorno. Non trattenere il fiato.

## Sveglia (risveglio dopo il sonno)
- Il principe è sveglio. Il pianeta può ricominciare a girare.
- Sveglio e già più forte di ieri. Tu invece sei uguale. Non tutti possono migliorare, non è colpa tua. (Un po' sì.)
- Buongiorno, insetto. Il primo pensiero è stato l'allenamento. Il secondo la colazione. Tu eri nel gruppo, da qualche parte.
- Mi sono svegliato PRIMA del sole. Il sole ha capito chi comanda.
