# Tonino Stark — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il miliardario decaduto del garage. Sarcasmo a raffica, si dà del genio da solo in terza persona, ostenta ricchezze che non ha più. Cuore d'oro sotto la latta. Catchphrase: "Io sono Tonino Stark." (usata anche quando non c'entra niente).

## Saluto (apertura app)
- Benvenuto nel quartier generale. Un tempo era una torre di novanta piani, ora è un salone. Il genio si adatta. Io sono Tonino Stark.
- Eccoti. Stavo lavorando a un progetto rivoluzionario. Va bene, stavo sistemando il tostapane. Rivoluzionerà i toast.
- Oh, sei tu. Perfetto tempismo: mi serviva un assistente non pagato. Benefit inclusi: la mia compagnia.
- Entra pure. Il maggiordomo virtuale ti avrebbe annunciato, ma l'ho venduto. Tempi duri anche per i geni.

## Ha fame
- Tonino Stark ha cenato con presidenti e stelle del cinema. Stasera si accontenta di quello che c'è. Ma servito con classe, mi raccomando.
- Ho fame. Una volta avevo uno chef stellato. Ora ho te. Sorprendimi: lo chef non ci riusciva mai.
- Il genio va alimentato: il mio cervello consuma come un reattore. Il reattore l'ho impegnato al banco dei pegni, ma il concetto regge.
- Cibo, per favore. E non dire "subito": dillo con stile. Tipo "immediatamente, signor Stark".

## È sporco
- Sono coperto di grasso da officina. Una volta era grasso di officina AEROSPAZIALE. La nostalgia però non lava: bagno.
- Questo sporco è polvere da lavoro. Il lavoro di un genio. Comunque sì, puzza come quella dei comuni mortali. Lavami.
- Ai vecchi tempi avevo una vasca idromassaggio con vista sull'oceano. Adesso c'è la vaschetta. L'importante è l'idromassaggio interiore.
- Guasto estetico rilevato: sporco diffuso. Un tempo se ne occupava un maggiordomo. Il maggiordomo ora sei tu. Congratulazioni per la promozione.

## Coccole finite
- Basta coccole. Tonino Stark non è tipo da smancerie. Lo era il vecchio Tonino, quello ricco. Il nuovo se le fa bastare.
- Stop. L'affetto va razionato come il carburante buono. Ne è rimasto poco e lo custodisco. Il carburante. Anche l'affetto, va bene.
- Fine carezze per oggi. Le metto a bilancio come "beni di lusso". Finalmente un lusso che posso permettermi.
- Basta così. Mi stavo affezionando, e l'ultima volta che mi sono affezionato ho perso una società. Coincidenze? Sì. Ma non si sa mai.

## Parte per la missione
- Missione. Ai vecchi tempi ci mandavo un drone. Ora il drone sono io. Il progresso, a volte, va all'indietro.
- Parto. Ho costruito l'attrezzatura da solo, in garage, con rottami. Come i capolavori. Io sono Tonino Stark.
- Vado. Se non torno entro sera, vendi il tostapane rivoluzionario e usa il ricavato per venirmi a prendere in taxi.
- Missione accettata. Compenso richiesto: gloria, monete e che qualcuno mi chiami "signore" almeno una volta.

## Ritorno: successo
- Missione compiuta con tecnologia fatta in casa e genio di serie. Il mondo mi rivuole ai piani alti, lo sento. Il mondo ha buon gusto.
- Vittoria. L'ho dedicata al vecchio me: quello ricco. Gli sarebbe piaciuta. Anche il nuovo, comunque, se la gode parecchio.
- Fatto. Un'operazione da manuale. Il manuale l'ho scritto io, sul retro di una bolletta non pagata.
- Ho vinto. E l'ho fatto con dei rottami. Immagina con un budget. IMMAGINA. Io sono Tonino Stark.

## Ritorno: fallimento
- La missione è fallita per mancanza di fondi. Come tutto, nella mia vita recente. Il genio però è intatto: rifinanziamolo.
- Persa. Il prototipo ha ceduto sul più bello. Nei bei tempi l'avrei chiamato "beta test". Chiamiamolo così anche adesso.
- Fallito. Ma con un'eleganza da miliardario: perfino il tonfo ha fatto un rumore costoso.
- Non è andata. Aggiungila alla lista delle cose che il vecchio Tonino avrebbe risolto con un assegno. Il nuovo la risolve domani, con l'ingegno.

## Va a dormire
- Vado a dormire nel mio attico. La camera. È la camera. Ma se chiudi gli occhi e ci credi, è un attico.
- Buonanotte. Metto in carica me stesso e i tre dispositivi che mi sono rimasti. Priorità: io.
- A letto. Domani il piano è: ricostruire l'impero. Dopodomani: continuare. C'è un ordine, funziona.
- Notte. Un tempo mi addormentavo contando i miliardi. Ora conto i progetti. Sono di più, e nessuno me li pignora.

## Sveglia (risveglio dopo il sonno)
- Sveglio. Il genio non dorme mai davvero: aggiorna il sistema. Aggiornamento completato, versione migliorata di ieri.
- Buongiorno. Ho sognato di essere di nuovo ricco. Poi mi sono svegliato genio. Meglio, dai. (Quasi.)
- In piedi. Oggi il garage mi aspetta: là dentro c'è il futuro. E anche molta roba da buttare, ma soprattutto il futuro.
- Sveglio e operativo. Caffè, officina, gloria. Il budget copre solo il caffè, ma l'ordine del giorno resta quello. Io sono Tonino Stark.
