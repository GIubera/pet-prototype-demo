/* PETQ.streak — "Giorni di carica" (Retention 2.0, batch A2)
 *
 * Streak GENTILE: non punisce mai l'assenza. E' il vincolo n.1 del doc di design
 * (docs/DESIGN-RETENTION-2.0.md) e nasce da un dato: nessun caso di successo moderno punisce chi
 * sparisce — Nintendo ha pensionato Resetti apposta.
 *
 * Le tre regole che lo rendono gentile, tutte e tre volute:
 *   1. Se salti un giorno e hai una Batteria di Riserva, si consuma DA SOLA e la serie continua.
 *   2. Se salti senza batterie, la serie NON si azzera: SCENDE AL TRAGUARDO PRECEDENTE (14->7->3->0).
 *      Chi arriva a 14 e sparisce una settimana riparte da 7, non da zero.
 *   3. Nessun malus al pet, mai. Al massimo una battuta.
 *
 * Le batterie NON sono comprabili e non compaiono in nessun negozio (decisione fondatore: streak e
 * recuperi non si comprano MAI, coerente con free + Supporter Pack senza gacha).
 *
 * Un giorno e' VALIDO solo con un'azione di CURA VERA (pasto, lavaggio, coccola, missione avviata):
 * aprire l'app non basta, o lo streak misurerebbe l'apertura invece dell'affetto.
 *
 * L'ASSENZA E' UN EPISODIO, NON UN GIORNO (bug fissato in questo batch): la regola "un'assenza
 * costa un passo" vale anche per chi APRE l'app ogni giorno ma non fa mai una cura vera. Senza
 * un modo per ricordare "questo buco l'ho gia' pagato", ogni login successivo rivedeva lo stesso
 * gap (cresciuto di un giorno) e lo addebitava DI NUOVO: una serie da 14 con tre login-senza-cura
 * di fila crollava a cascata (14->7->3->0, un colpo al giorno) invece di scendere una volta sola
 * a 7 e restarci. Il campo s.gapAperto (in stato dello streak, difensivo su assicura()) segna se
 * l'assenza CORRENTE e' gia' stata pagata: chiudiGiorniSaltati addebita solo quando gapAperto e'
 * falso, poi lo alza; registraAzioneCura lo riabbassa quando una cura VERA chiude l'episodio.
 * Sui salvataggi vecchi il campo non esiste: undefined vale falso, quindi il primo controllo
 * addebita comunque una volta e apre l'episodio (comportamento identico a un episodio nuovo).
 */
(function () {
  'use strict';
  window.PETQ = window.PETQ || {};

  // Traguardi in ordine CRESCENTE: l'ordine conta, retrocedi() cerca il piu' alto sotto la soglia.
  var TRAGUARDI = [3, 7, 14];
  var BATTERIE_MAX = 2;
  var GIORNI_PER_BATTERIA = 7;
  var CIBO_TRAGUARDO_3 = 'Torta intera';      // da content/cibi.md: generoso, nessun malus
  var ARREDO_TRAGUARDO_7 = 'Caricatore da Viaggio';

  function traduci(s) {
    return (window.PETQ.i18n && PETQ.i18n.t) ? PETQ.i18n.t(s) : s;
  }

  // Giorno di gioco corrente (intero). Stessa fonte di dailyLogin: mai la data reale del PC,
  // altrimenti streak e nuovo-giorno userebbero due calendari diversi.
  function giornoCorrente(state) {
    if (window.PETQ.clock && PETQ.clock.giornoCorrente) return PETQ.clock.giornoCorrente(state);
    return (state && typeof state.giornoGioco === 'number') ? state.giornoGioco : 0;
  }

  // Struttura difensiva: qualunque salvataggio, anche vecchio o manomesso, esce di qui sano.
  function assicura(state) {
    if (!state) return null;
    var s = state.streak;
    if (!s || typeof s !== 'object') s = {};
    if (typeof s.giorni !== 'number' || s.giorni < 0) s.giorni = 0;
    if (typeof s.record !== 'number' || s.record < 0) s.record = 0;
    if (typeof s.batterie !== 'number' || s.batterie < 0) s.batterie = 0;
    if (s.batterie > BATTERIE_MAX) s.batterie = BATTERIE_MAX;
    if (typeof s.ultimoValido !== 'number') s.ultimoValido = null;
    if (!Array.isArray(s.traguardi)) s.traguardi = [];
    // Vero mentre l'assenza CORRENTE e' gia' stata addebitata (v. commento di testa del modulo).
    // Salvataggi vecchi/manomessi: qualunque cosa non sia gia' un booleano diventa false, che e'
    // esattamente il comportamento voluto per chi non ha ancora questo campo.
    if (typeof s.gapAperto !== 'boolean') s.gapAperto = false;
    state.streak = s;
    return s;
  }

  // Messaggi per la UI: stesso canale dei companion del Supporter Pack (un campo nello stato che
  // la UI consuma e svuota), invece di inventare un secondo meccanismo di notifica.
  function avvisa(state, testo) {
    if (!state || !testo) return;
    if (!Array.isArray(state.streakAvvisi)) state.streakAvvisi = [];
    state.streakAvvisi.push(testo);
  }

  // Il traguardo piu' alto STRETTAMENTE sotto n (14 -> 7, 7 -> 3, 3 -> 0).
  function traguardoPrecedente(n) {
    var giu = 0;
    for (var i = 0; i < TRAGUARDI.length; i++) {
      if (TRAGUARDI[i] < n) giu = TRAGUARDI[i];
    }
    return giu;
  }

  function aggiungiCiboDispensa(state, nome) {
    if (!state) return;
    if (!Array.isArray(state.dispensa)) state.dispensa = [];
    for (var i = 0; i < state.dispensa.length; i++) {
      if (state.dispensa[i] && state.dispensa[i].nome === nome) {
        state.dispensa[i].qty = (state.dispensa[i].qty || 0) + 1;
        return;
      }
    }
    state.dispensa.push({ nome: nome, qty: 1 });
  }

  // Stesso schema dei companion del Supporter Pack: si mette fra i POSSEDUTI e il resto del gioco
  // (piazzamento, collezione, disegno) lo eredita gratis. Idempotente.
  function aggiungiArredo(state, nome) {
    if (!state) return false;
    if (!state.arredi || typeof state.arredi !== 'object') state.arredi = { posseduti: [], piazzati: {} };
    if (!Array.isArray(state.arredi.posseduti)) state.arredi.posseduti = [];
    for (var i = 0; i < state.arredi.posseduti.length; i++) {
      if (state.arredi.posseduti[i] && state.arredi.posseduti[i].nome === nome) return false;
    }
    var piazzati = state.arredi.piazzati || {};
    for (var k in piazzati) {
      if (!Object.prototype.hasOwnProperty.call(piazzati, k)) continue;
      var lista = piazzati[k] || [];
      for (var j = 0; j < lista.length; j++) if (lista[j] && lista[j].nome === nome) return false;
    }
    state.arredi.posseduti.push({ nome: nome });
    return true;
  }

  // Premi dei traguardi. Ogni traguardo si prende UNA volta per serie: se scendi da 14 a 7 e
  // risali, non lo riprendi (se no basterebbe oscillare per farmarlo). Azzerando la serie si
  // azzerano anche i traguardi presi: quello e' un ricominciare vero.
  function controllaTraguardi(state, s) {
    for (var i = 0; i < TRAGUARDI.length; i++) {
      var t = TRAGUARDI[i];
      if (s.giorni < t) continue;
      if (s.traguardi.indexOf(t) !== -1) continue;
      s.traguardi.push(t);

      if (t === 3) {
        aggiungiCiboDispensa(state, CIBO_TRAGUARDO_3);
        // Frase costruita senza articolo ("e' comparso qualcosa: X") apposta: con "una" bastava
        // cambiare il premio con un cibo maschile per ritrovarsi un errore di grammatica.
        avvisa(state, traduci('Tre giorni di carica. In dispensa e\' comparso qualcosa: ') + traduci(CIBO_TRAGUARDO_3) + '.');
      } else if (t === 7) {
        // Due frasi INTERE invece di una cucita con un traduci(' e '): una congiunzione da sola
        // e' una chiave di dizionario pessima (compare ovunque, si traduce a caso).
        var nuovo = aggiungiArredo(state, ARREDO_TRAGUARDO_7);
        avvisa(state, nuovo
          ? traduci('Sette giorni di carica: Batteria di Riserva e ') + traduci(ARREDO_TRAGUARDO_7) + '.'
          : traduci('Sette giorni di carica: Batteria di Riserva.'));
      }
      // NB il traguardo 14 non ha un ramo qui: la medaglietta Custode e' del PET, non della
      // casa, e la decide controllaCustode() con un conteggio suo (v. sotto). Il traguardo
      // resta comunque segnato in s.traguardi dal push in cima al ciclo: e' il traguardo della
      // SERIE, che esiste ed e' stato raggiunto.
    }
  }

  /* Medaglietta "Custode": 14 giorni di carica vissuti DA QUESTO PET.
   *
   * La serie e' del GIOCATORE (misura la sua abitudine e non si azzera quando un pet va in
   * pensione), la medaglietta e' del PET. Senza questa distinzione succedevano due cose brutte,
   * opposte fra loro: un pet nuovo accolto in una casa con la serie gia' a 14 se la trovava in
   * tasca senza aver vissuto niente, oppure — segnando il traguardo come preso — non poteva piu'
   * guadagnarla mai, perche' i traguardi si azzerano solo quando la serie torna a zero.
   *
   * Il conto e' semplice: alla prima cura registrata con un pet si annota a che punto era la
   * serie, e da li' servono 14 giorni suoi. Per un pet nato con la serie a zero (il caso
   * normale) il numero e' identico a prima: nessuna regressione sul gioco di tutti i giorni.
   */
  function controllaCustode(state, s) {
    var pet = state && state.pet;
    if (!pet || pet.medagliaCustode) return;
    if (typeof pet.streakAllaNascita !== 'number') pet.streakAllaNascita = s.giorni - 1;
    if ((s.giorni - pet.streakAllaNascita) < 14) return;
    pet.medagliaCustode = true;
    avvisa(state, traduci('Quattordici giorni senza saltarne uno. Medaglietta Custode.'));
  }

  // Una batteria ogni 7 giorni di serie (7, 14, 21...), fino a 2 in tasca. Il tetto e' voluto:
  // accumularne dieci vorrebbe dire non poter piu' perdere, e la serie smetterebbe di significare.
  function maturaBatterie(state, s) {
    if (s.giorni <= 0 || s.giorni % GIORNI_PER_BATTERIA !== 0) return;
    if (s.batterie >= BATTERIE_MAX) return;
    s.batterie++;
  }

  /* Registra un'azione di CURA. Idempotente nella giornata: la prima azione del giorno conta, le
   * successive no — cosi' dieci coccole di fila non fanno dieci giorni.
   * Ritorna true se questa chiamata ha fatto avanzare la serie. */
  function registraAzioneCura(state) {
    var s = assicura(state);
    if (!s) return false;
    var oggi = giornoCorrente(state);
    if (s.ultimoValido === oggi) return false; // gia' fatto oggi

    if (s.ultimoValido === null) {
      s.giorni = 1;                     // primo giorno in assoluto
    } else if (s.ultimoValido === oggi - 1) {
      s.giorni++;                       // ieri era valido: la serie continua
    } else {
      // buco non ancora contabilizzato (es. app riaperta dopo giorni senza passare da dailyLogin):
      // lo chiudiamo qui con le stesse regole, poi la giornata di oggi vale 1.
      chiudiGiorniSaltati(state, s, oggi);
      s.giorni = s.giorni > 0 ? s.giorni + 1 : 1;
    }

    s.ultimoValido = oggi;
    // Una cura vera chiude SEMPRE l'episodio di assenza corrente (se c'era): il prossimo buco,
    // quando arrivera', e' un episodio NUOVO e va addebitato da capo (v. commento di testa).
    s.gapAperto = false;
    if (s.giorni > s.record) s.record = s.giorni;
    maturaBatterie(state, s);
    controllaTraguardi(state, s);
    controllaCustode(state, s);
    return true;
  }

  /* Applica un'ASSENZA, lunga quanto vuole, come UN SOLO evento.
   *
   * Questa e' la regola che rende lo streak davvero gentile, ed e' una scelta precisa: contare
   * una retrocessione per OGNI giorno saltato azzererebbe una serie da 14 giorni con tre giorni
   * di vacanza (14->7->3->0), cioe' esattamente la punizione che il doc di design vieta. Una
   * sparizione costa UN gradino, che duri due giorni o due settimane.
   *
   * Le batterie si spendono SOLO se coprono per intero l'assenza. Se non bastano restano in
   * tasca: bruciarle per poi retrocedere lo stesso vorrebbe dire perdere due volte, e la
   * batteria smetterebbe di essere il paracadute che il giocatore crede di avere. */
  function chiudiGiorniSaltati(state, s, oggi) {
    if (s.ultimoValido === null) return;
    var saltati = (oggi - 1) - s.ultimoValido; // giorni interi passati senza cura
    if (saltati <= 0) return;

    // Questa stessa assenza e' gia' stata addebitata (login precedente, stesso buco cresciuto di
    // un giorno): non si paga due volte. Si riapre SOLO con una cura vera (registraAzioneCura).
    if (s.gapAperto) return;
    s.gapAperto = true;

    if (saltati <= s.batterie) {
      s.batterie -= saltati;
      // Un messaggio solo anche con due batterie: due righe identiche di fila sembrano un bug.
      avvisa(state, traduci('Ho usato la batteria di riserva. La prossima la offri tu.'));
      return;
    }

    var prima = s.giorni;
    s.giorni = traguardoPrecedente(s.giorni);
    if (s.giorni === 0) s.traguardi = [];
    if (prima !== s.giorni) {
      avvisa(state, traduci('Carica scesa a ') + s.giorni + traduci(' giorni. Si ricomincia da li\'.'));
    }
  }

  /* Da chiamare al NUOVO GIORNO (dailyLogin, che e' gia' auto-guardato): controlla se IERI e'
   * passato senza una sola azione di cura e applica batteria o retrocessione. */
  function aggiornaAlNuovoGiorno(state) {
    var s = assicura(state);
    if (!s) return;
    if (s.ultimoValido === null) return;       // serie mai iniziata: niente da perdere
    var oggi = giornoCorrente(state);
    if (s.ultimoValido >= oggi - 1) return;    // ieri (o oggi) valido: tutto a posto
    chiudiGiorniSaltati(state, s, oggi);
  }

  function stato(state) {
    var s = assicura(state);
    if (!s) return { giorni: 0, record: 0, batterie: 0, curatoOggi: false };
    return {
      giorni: s.giorni, record: s.record, batterie: s.batterie, traguardi: s.traguardi.slice(),
      // Serve alla notifica "salva-carica" della sera (v. notifiche.js): si manda SOLO se la
      // giornata e' ancora senza una cura, altrimenti si ricorderebbe una cosa gia' fatta.
      curatoOggi: s.ultimoValido === giornoCorrente(state)
    };
  }

  // Consuma e svuota gli avvisi accumulati (la UI li mostra e li toglie di mezzo).
  function raccogliAvvisi(state) {
    if (!state || !Array.isArray(state.streakAvvisi) || !state.streakAvvisi.length) return [];
    var out = state.streakAvvisi.slice();
    state.streakAvvisi = [];
    return out;
  }

  window.PETQ.streak = {
    registraAzioneCura: registraAzioneCura,
    aggiornaAlNuovoGiorno: aggiornaAlNuovoGiorno,
    stato: stato,
    raccogliAvvisi: raccogliAvvisi,
    assicura: assicura,
    _traguardi: TRAGUARDI,
    _batterieMax: BATTERIE_MAX,
    _traguardoPrecedente: traguardoPrecedente
  };
})();
