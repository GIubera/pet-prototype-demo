/* PETQ.quartaParete — "Quarta parete" (Retention 2.0, batch A3)
 *
 * Il pet nota il mondo-telefono attorno a se': l'ora assurda a cui lo stai guardando, la
 * batteria scarica, il tema scuro, i giorni che sei sparito. E' un vincolo esplicito del doc di
 * design (docs/DESIGN-RETENTION-2.0.md riga 10): "il pet nota il SUO mondo-telefono, MAI
 * sorvegliare la persona" — quindi solo segnali del DISPOSITIVO (ora, batteria, tema, assenza
 * DAL gioco), mai dati personali, mai nulla che assomigli a una notifica di sistema finta.
 *
 * QUESTO FILE E' SOLO IL MOTORE: decide QUALE reazione scatta e COSA riassumere, non le
 * aggancia alla UI e non scrive le battute definitive (quelle sono contenuto, in scrittura al
 * socio — qui c'e' solo il nome del pool da usare).
 */
(function () {
  'use strict';
  window.PETQ = window.PETQ || {};

  var MS_ORA = 3600000;
  var MS_GIORNO = 24 * MS_ORA;

  // Soglie di design (docs/DESIGN-RETENTION-2.0.md riga 44): numeri in cima come costanti,
  // cosi' un domani il fondatore li ritara senza andare a caccia nel corpo delle funzioni.
  var GIORNI_ASSENZA = 3;
  var ORA_ASSURDA_DA = 1;   // "le 2 di notte. Io DORMIVO." — fascia [1,4] ore locali REALI
  var ORA_ASSURDA_A = 4;    // inclusiva
  var BATTERIA_SOGLIA = 0.10;
  var ORE_RECAP_MIN = 3;    // il recap "dall'ultima volta" scatta solo da 3h reali in su

  // Anti-ripetizione: la STESSA reazione non riparte piu' di una volta ogni 20h, cosi' non si
  // rischia di sentirsi dire "le 2 di notte" ad ogni apertura durante la stessa notte insonne.
  var ORE_ANTI_RIPETIZIONE = 20;

  // Stesso identico ripiego di app/js/streak.js: se il modulo i18n non e' ancora caricato (o e'
  // stato tolto) il testo resta quello italiano invece di rompere, mai un buco a schermo.
  function traduci(s) {
    return (window.PETQ.i18n && PETQ.i18n.t) ? PETQ.i18n.t(s) : s;
  }

  // ---------- struttura difensiva (stesso schema di streak.js assicura()) ----------
  // Qualunque salvataggio, anche vecchio o manomesso, deve uscire di qui sano: 'ultime' e' la
  // memoria {tipo: timestampMs} per l'anti-ripetizione, e non deve mai far esplodere reazione().
  function assicura(state) {
    if (!state) return null;
    var q = state.quartaParete;
    if (!q || typeof q !== 'object') q = {};
    if (!q.ultime || typeof q.ultime !== 'object') q.ultime = {};
    state.quartaParete = q;
    return q;
  }

  // ---------- batteria (asincrona, MAI la reazione) ----------
  // navigator.getBattery() e' una Promise e puo' non esistere affatto (iOS Safari, molti
  // desktop): niente di tutto questo puo' rendere asincrona reazione(), quindi il livello letto
  // viene messo in cache qui a livello di modulo e reazione() legge SOLO questa variabile.
  // null = "non lo sappiamo" (API assente o non ancora risolta): la reazione 'batteria' in quel
  // caso non scatta MAI, no-op silenzioso identico al contratto di notifiche.js quando manca il
  // plugin Capacitor (v. app/js/notifiche.js, commento in cima).
  var batteriaLivello = null;   // 0..1
  var batteriaInCarica = null;  // bool
  var batteriaAgganciata = false; // il listener sui cambi si registra UNA sola volta

  function aggiornaBatteria() {
    if (!(window.navigator && typeof window.navigator.getBattery === 'function')) return; // no-op: API assente
    window.navigator.getBattery().then(function (batteria) {
      if (!batteria) return;
      batteriaLivello = batteria.level;
      batteriaInCarica = batteria.charging;

      if (!batteriaAgganciata) {
        batteriaAgganciata = true;
        // La spec BatteryManager e' un oggetto stabile per pagina: agganciare qui, una volta
        // sola, basta a tenere la cache aggiornata per tutta la sessione senza ripetere polling.
        batteria.addEventListener('levelchange', function () { batteriaLivello = batteria.level; });
        batteria.addEventListener('chargingchange', function () { batteriaInCarica = batteria.charging; });
      }
    }).catch(function () { /* permesso negato o API rimossa a runtime: silenzioso, mai un throw */ });
  }

  // ---------- reazione() ----------
  function scattataDiRecente(q, tipo) {
    var t = q.ultime[tipo];
    if (typeof t !== 'number') return false;
    return (Date.now() - t) < ORE_ANTI_RIPETIZIONE * MS_ORA;
  }

  function segnaScattata(q, tipo) {
    q.ultime[tipo] = Date.now();
  }

  /* Valuta le reazioni in ordine di priorita' e ritorna la PRIMA che scatta davvero (condizione
   * vera E non gia' scattata nelle ultime 20h). Se una condizione e' vera ma soppressa dal
   * anti-ripetizione non blocca le altre: si passa alla prossima in ordine, cosi' una notte
   * insonne non spegne anche la battuta sulla batteria scarica. */
  function reazione(state, daMs) {
    if (!state) return null;
    var q = assicura(state);
    if (!q) return null;

    // 1) assenza: >= 3 giorni REALI dall'ultima volta vista. Il timestamp arriva da fuori per lo
    // stesso motivo spiegato in recap(): al boot state.lastSeen e' gia' stato riportato ad
    // "adesso", quindi leggerlo da qui vorrebbe dire non accorgersi MAI di un'assenza.
    var visto = (typeof daMs === 'number') ? daMs : state.lastSeen;
    if (typeof visto === 'number' && (Date.now() - visto) >= GIORNI_ASSENZA * MS_GIORNO) {
      if (!scattataDiRecente(q, 'assenza')) {
        segnaScattata(q, 'assenza');
        return { tipo: 'assenza', chiave: 'reazione_assenza' };
      }
    }

    // 2) ora assurda: orologio REALE locale, non quello di gioco (e' il pet che nota TE davanti
    // allo schermo a quell'ora, non il suo orario interno).
    var oraReale = new Date().getHours();
    if (oraReale >= ORA_ASSURDA_DA && oraReale <= ORA_ASSURDA_A) {
      if (!scattataDiRecente(q, 'oraassurda')) {
        segnaScattata(q, 'oraassurda');
        return { tipo: 'oraassurda', chiave: 'reazione_oraassurda' };
      }
    }

    // 3) batteria: solo se SAPPIAMO per certo che e' sotto soglia E non in carica (=== false,
    // non solo "falsy"), cosi' un valore ancora sconosciuto (null) non fa mai scattare nulla.
    if (batteriaLivello !== null && batteriaLivello < BATTERIA_SOGLIA && batteriaInCarica === false) {
      if (!scattataDiRecente(q, 'batteria')) {
        segnaScattata(q, 'batteria');
        return { tipo: 'batteria', chiave: 'reazione_batteria' };
      }
    }

    // 4) tema scuro: matchMedia puo' mancare su WebView vecchie, quindi va controllato prima di
    // chiamarlo (guardia difensiva, non un dettaglio).
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      if (!scattataDiRecente(q, 'temascuro')) {
        segnaScattata(q, 'temascuro');
        return { tipo: 'temascuro', chiave: 'reazione_temascuro' };
      }
    }

    return null;
  }

  // ---------- recap() ----------
  // "Ho fatto la cacca N volte": costruita per concatenazione di pezzi tradotti separatamente
  // (stesso pattern di streak.js traguardoPrecedente/chiudiGiorniSaltati) invece di un
  // template literal, che qui non esiste (ES5) e comunque sarebbe una chiave di dizionario
  // pessima (una stringa diversa per ogni numero).
  function fraseCacca(n) {
    if (n === 1) return traduci('Ho fatto la cacca una volta.');
    return traduci('Ho fatto la cacca ') + n + traduci(' volte.');
  }

  /* Riassume cosa e' successo mentre il giocatore era via. Scatta solo da 3 ore reali di
   * assenza in su (sotto le 3 ore non e' "via", e' una sessione interrotta) e ritorna al
   * massimo i primi 3 fatti disponibili, nell'ordine di rilevanza dato dal brief. */
  /* opts.daMs  : quando il giocatore e' stato visto l'ultima volta.
   * opts.dormiva: se il pet stava dormendo al momento del rientro.
   *
   * Sono ESPLICITI e non letti dallo stato per un motivo preciso, trovato agganciando: al boot
   * main.js chiama applicaDecadimentoOffline, che SOVRASCRIVE state.lastSeen con "adesso" e fa
   * scendere le stat di colpo. Il recap ha bisogno delle due cose in tempi diversi — il
   * timestamp com'era PRIMA, le stat come sono DOPO — e leggendo tutto dallo stato la finestra
   * risulterebbe sempre azzerata e il recap non comparirebbe mai. Stesso discorso per il sonno:
   * il ciclo sonno al boot puo' aver gia' svegliato il pet. */
  function recap(state, opts) {
    if (!state) return [];
    opts = opts || {};
    var daMs = (typeof opts.daMs === 'number') ? opts.daMs : state.lastSeen;
    if (typeof daMs !== 'number') return [];
    if ((Date.now() - daMs) < ORE_RECAP_MIN * MS_ORA) return [];

    var fatti = [];

    // missione conclusa mentre era via
    if (state.missione && typeof state.missione.fine === 'number' && state.missione.fine <= Date.now()) {
      fatti.push(traduci('Ho finito la missione.'));
    }

    // dormiva: chi aggancia sa se il pet stava dormendo al rientro (lo cattura PRIMA del ciclo
    // sonno del boot, che puo' averlo gia' svegliato); se non lo passa, ripieghiamo sull'adesso.
    var dormiva = (typeof opts.dormiva === 'boolean') ? opts.dormiva : !!state.sonno;
    if (dormiva) {
      fatti.push(traduci('Stavo dormendo.'));
    }

    // cacca in stanza (state.poop, root dello state, 0..3, v. app/js/pet.js e app/js/ui.js)
    if (typeof state.poop === 'number' && state.poop > 0) {
      fatti.push(fraseCacca(state.poop));
    }

    // fame scesa sotto soglia
    if (state.pet && state.pet.stats && typeof state.pet.stats.fame === 'number' && state.pet.stats.fame < 25) {
      fatti.push(traduci('Ho avuto fame.'));
    }

    // igiene scesa sotto soglia
    if (state.pet && state.pet.stats && typeof state.pet.stats.igiene === 'number' && state.pet.stats.igiene < 25) {
      fatti.push(traduci('Mi sono sporcato.'));
    }

    return fatti.slice(0, 3);
  }

  window.PETQ.quartaParete = {
    reazione: reazione,
    recap: recap,
    assicura: assicura,
    aggiornaBatteria: aggiornaBatteria,
    // Esposta per il collaudo: l'anti-ripetizione e' la parte che nessuno puo' verificare
    // giocando in tempo reale (servirebbero 20 ore vere), quindi deve essere ispezionabile.
    _ORE_ANTI_RIPETIZIONE: ORE_ANTI_RIPETIZIONE
  };
})();
