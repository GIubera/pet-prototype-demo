/* PETQ.carte — il mazzo dei DILEMMI (Batch B, docs/DESIGN-DILEMMI-LAVORI.md §3 e §5.4/§5.5)
 *
 * Una carta al giorno, a un'ora semi-casuale diurna, mai la stessa due volte nella run. Le carte
 * danno effetti piccoli e piantano FLAG: non sbloccano feature — quelle sono solo delle 4 porte
 * (v. porte.js). E' il vincolo che tiene il mazzo espandibile senza sbilanciare il gioco.
 *
 * I TESTI E I NUMERI NON SONO QUI: vivono in content/carte.md e li legge il parser (content.js
 * parseCarte -> data.carte). Questo file decide solo QUALE carta e QUANDO, e applica gli esiti
 * passandoli all'applicatore di token del motore missioni — mai riscrivendolo, o due copie della
 * stessa logica divergerebbero al primo token nuovo.
 */
(function () {
  'use strict';
  window.PETQ = window.PETQ || {};

  // Finestra diurna in cui la carta puo' presentarsi. La sera e' del lavoretto e la notte si
  // dorme: una carta che arriva alle 23 non la vedrebbe nessuno.
  var ORA_MIN = 9;
  var ORA_MAX = 18;

  function giornoCorrente(state) {
    if (window.PETQ.clock && PETQ.clock.giornoCorrente) return PETQ.clock.giornoCorrente(state);
    return (state && typeof state.giornoGioco === 'number') ? state.giornoGioco : 0;
  }

  function oraCorrente(state) {
    if (window.PETQ.clock && PETQ.clock.oraGioco) {
      var og = PETQ.clock.oraGioco(state);
      return (og && typeof og.ore === 'number') ? og.ore : 12;
    }
    return 12;
  }

  // Struttura difensiva, stesso schema di streak.js: qualunque salvataggio, anche vecchio o
  // manomesso, esce di qui sano.
  function assicura(state) {
    if (!state) return null;
    var s = state.carte;
    if (!s || typeof s !== 'object') s = {};
    if (!Array.isArray(s.fatte)) s.fatte = [];
    if (typeof s.id !== 'string') s.id = null;
    if (typeof s.giorno !== 'number') s.giorno = null;
    if (typeof s.ora !== 'number') s.ora = null;
    s.risolta = !!s.risolta;
    state.carte = s;
    return s;
  }

  function mazzo() {
    var d = window.PETQ.content && PETQ.content.data;
    return (d && Array.isArray(d.carte)) ? d.carte : [];
  }

  function trovaCarta(id) {
    var m = mazzo();
    for (var i = 0; i < m.length; i++) if (m[i].id === id) return m[i];
    return null;
  }

  function haFlag(state, nome) {
    return !!(nome && Array.isArray(state.flags) && state.flags.indexOf(nome) !== -1);
  }

  function haPerk(state, nome) {
    return !!(nome && Array.isArray(state.perks) && state.perks.indexOf(nome) !== -1);
  }

  function carrieraCorrente(state) {
    var l = state.lavoro;
    if (!l) return null;
    // Il gate lavoro= vale sia per il lavoretto teen sia per la carriera adulta: una carta scritta
    // per "chi fa le consegne" deve valere anche per chi da quelle consegne e' diventato rider.
    return l.carriera || l.id || null;
  }

  /* Carte giocabili ADESSO. Cinque cancelli, dal doc §5.4: stadio, personalita', flag, perk,
   * lavoro. Piu' "mai giocata in questa run". */
  function eleggibili(state) {
    var s = assicura(state);
    if (!s || !state.pet) return [];
    var stadio = state.pet.stadio;
    var personalita = state.pet.personalita;
    var lavoro = carrieraCorrente(state);
    var out = [];
    var m = mazzo();
    for (var i = 0; i < m.length; i++) {
      var c = m[i];
      if (s.fatte.indexOf(c.id) !== -1) continue;
      if (c.stadio && c.stadio !== stadio) continue;
      if (c.personalita && c.personalita !== personalita) continue;
      if (c.richiedeFlag && !haFlag(state, c.richiedeFlag)) continue;
      if (c.richiedePerk && !haPerk(state, c.richiedePerk)) continue;
      if (c.lavoro && c.lavoro !== lavoro) continue;
      out.push(c);
    }
    return out;
  }

  /* La carta di oggi, o null. Estrae al cambio giorno e la tiene da parte: senza memoria, ogni
   * chiamata avrebbe pescato una carta diversa e il giocatore avrebbe visto il mazzo cambiargli
   * sotto gli occhi ad ogni battito. */
  function cartaDiOggi(state) {
    var s = assicura(state);
    if (!s || !state.pet) return null;
    var oggi = giornoCorrente(state);

    if (s.giorno !== oggi) {
      s.giorno = oggi;
      s.id = null;
      s.ora = null;
      s.risolta = false;
      var pool = eleggibili(state);
      if (pool.length > 0) {
        var scelta = (window.PETQ.rng && PETQ.rng.pick) ? PETQ.rng.pick(pool) : pool[0];
        if (scelta) {
          s.id = scelta.id;
          // Ora semi-casuale (doc §5.5): due run non hanno la carta sempre alla stessa ora, e la
          // giornata non diventa una tabella.
          s.ora = (window.PETQ.rng && PETQ.rng.randInt) ? PETQ.rng.randInt(ORA_MIN, ORA_MAX) : 12;
        }
      }
    }

    if (!s.id || s.risolta) return null;
    if (typeof s.ora === 'number' && oraCorrente(state) < s.ora) return null; // non e' ancora ora
    return trovaCarta(s.id);
  }

  // Titolo da mostrare: con la variante attiva cambia (doc §5.5). Se il testo alternativo non e'
  // ancora stato scritto, cambia SOLO il titolo — meglio un callback parziale che nessuno.
  function titoloCarta(state, carta) {
    if (!carta) return '';
    if (carta.varianteFlag && carta.varianteTitolo && haFlag(state, carta.varianteFlag)) {
      return carta.varianteTitolo;
    }
    return carta.titolo;
  }

  // Opzioni davvero offribili: quelle con un flag richiesto compaiono solo se ce l'hai (es. C29-C,
  // "delega al mostro dell'armadio", che senza il coinquilino non avrebbe senso).
  function opzioniVisibili(state, carta) {
    if (!carta || !Array.isArray(carta.opzioni)) return [];
    var out = [];
    for (var i = 0; i < carta.opzioni.length; i++) {
      var o = carta.opzioni[i];
      if (o.richiedeFlag && !haFlag(state, o.richiedeFlag)) continue;
      out.push(o);
    }
    return out;
  }

  /* Sceglie il ramo di esito di un'opzione. Precedenza dal doc: la clausola sulla PERSONALITA'
   * vince, e i due rami 50/50 sono l'"altrimenti" — non un tiro che le si somma. */
  function ramoEsito(state, opzione) {
    if (!opzione) return { token: [], tipo: 'vuoto' };
    if (opzione.esitoPersonalita && state.pet &&
        opzione.esitoPersonalita.personalita === state.pet.personalita) {
      return { token: opzione.esitoPersonalita.token.slice(), tipo: 'personalita' };
    }
    if (opzione.esiti5050.length >= 2) {
      var testa = (window.PETQ.rng && PETQ.rng.rand) ? (PETQ.rng.rand() < 0.5) : true;
      var idx = testa ? 0 : 1;
      return { token: opzione.esiti5050[idx].slice(), tipo: '5050', ramo: idx };
    }
    if (opzione.esiti5050.length === 1) {
      return { token: opzione.esiti5050[0].slice(), tipo: '5050', ramo: 0 };
    }
    return { token: opzione.esito.slice(), tipo: 'certo' };
  }

  /* Applica la scelta. I token passano dall'applicatore del motore missioni: e' l'unico posto in
   * cui un token viene tradotto in effetto, quindi un token nuovo funziona qui il giorno stesso
   * in cui viene aggiunto la' — e non esistono due tabelle che possono divergere. */
  function scegli(state, lettera) {
    var s = assicura(state);
    if (!s) return { ok: false, msg: 'errore interno' };
    var carta = trovaCarta(s.id);
    if (!carta || s.risolta) return { ok: false, msg: 'nessuna carta da giocare' };

    var opzioni = opzioniVisibili(state, carta);
    var opzione = null;
    for (var i = 0; i < opzioni.length; i++) if (opzioni[i].lettera === lettera) opzione = opzioni[i];
    if (!opzione) return { ok: false, msg: 'scelta non valida' };

    var ramo = ramoEsito(state, opzione);
    var rewards = [];
    if (window.PETQ.missions && PETQ.missions._applicaRewardToken) {
      for (var t = 0; t < ramo.token.length; t++) {
        PETQ.missions._applicaRewardToken(state, ramo.token[t], rewards);
      }
    }

    s.risolta = true;
    if (s.fatte.indexOf(carta.id) === -1) s.fatte.push(carta.id);

    return {
      ok: true, carta: carta.id, lettera: lettera, tipo: ramo.tipo,
      token: ramo.token, rewards: rewards, coda: opzione.coda || ''
    };
  }

  window.PETQ.carte = {
    assicura: assicura,
    cartaDiOggi: cartaDiOggi,
    titoloCarta: titoloCarta,
    opzioniVisibili: opzioniVisibili,
    scegli: scegli,
    _eleggibili: eleggibili,
    _ramoEsito: ramoEsito,
    _finestra: function () { return { min: ORA_MIN, max: ORA_MAX }; }
  };
})();
