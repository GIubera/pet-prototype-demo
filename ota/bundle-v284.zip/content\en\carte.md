# Dilemma Cards - EN transcreation

This file is the English transcreation of `content/carte.md`: same 41 cards, same ids (C01-C41), same order, same option letters.
The card format and every engine key (Dati / Esito / Esito 50/50 / Esito se personalita / Cond / flag / perk / arredo / cibo tokens) are documented in the Italian file - this file follows that same structure without changing it.
Only player-facing text (titles, Situazione, option buttons, Coda, and variant titles) is transcreated; everything the engine reads stays identical to the Italian source.

## C01 · The Cyborg Pigeon's Scratch Card
Dati: stadio=baby
Situazione: The cyborg pigeon won 20 coins on a scratch card and has no thumbs to cash them in. It offers the pet a 50-50 split. The pet cannot do percentages.

### A · Cash it in, split it fair
Esito: monete+10, flag:socio_del_piccione

### B · "What scratch card?"
Esito: monete+15, fel-3
Coda: The pigeon stares at you through the window. For three days.

### C · Never do business with pigeons
Esito: int+1

## C02 · There's a Monster in the Closet (Does It Pay Rent?)
Dati: stadio=baby
Situazione: There is, for real, a tiny monster living in the closet. Small, polite, and it has already color-sorted the socks.

### A · It can stay if it cleans
Esito: igiene+10, flag:coinquilino

### B · Evicted, effective immediately
Esito: forza+1
Coda: Dragging it out was basically a workout.

### C · Rent: three nights up front, now
Esito: monete+9
Coda: The pet sleeps without a closet now. Choices.

## C03 · The Roommate Brought Friends
Dati: stadio=baby ; richiedeFlag=coinquilino
Situazione: The closet now houses THREE tiny monsters. There was music last night. Coming from the CLOSET.

### A · Party allowed, but you're invited too
Esito: fel+8, igiene-5

### B · Strict house rules, effective now
Esito: int+1, fel-2
Coda: The roommate sulks about it.

### C · Rent starts today: all three of them
Esito: monete+9, flag:padrone_di_casa

## C04 · The Great Snack Swap
Dati: stadio=baby
Situazione: A shady puppy makes an offer: your snack for "a surprise." The surprise is in a box. The box is moving.

### A · Take the deal
Esito 50/50: cibo:Fetta di Panino Gigante
Esito 50/50: fel-3, flag:fregato_una_volta

### B · My snack, my rules
Esito: cibo:Biscotto
Coda: You eat it right there. On principle.

## C05 · The Forbidden Cartoon
Dati: stadio=baby
Situazione: The "for teens only" cartoon is on TV. The pet stares at you, remote in hand.

### A · Fine, but we watch it together
Esito: fel+8, energia-10
Coda: It doesn't sleep a wink tonight: "what if the cartoon monster lives HERE?"

### B · Absolutely not
Esito: fel+3, flag:ribelle
Coda: It watches it in secret anyway.

### C · You watch it first, "for quality control"
Esito: int+1
Coda: You now know things about cartoons you never wanted to know.

## C06 · The Perfect Puddle
Dati: stadio=baby
Situazione: It rained. Right outside the house sits THE puddle: deep, muddy, perfect. The pet is already taking a running start.

### A · Unleash the cannonball
Esito: fel+10, igiene-20

### B · Stop it just in time
Esito: fel-5, flag:pulito_dentro

### C · You toss a toy in "for testing"
Esito: fel+6, igiene-8
Coda: The splash reaches you anyway.

## C07 · The "Adopted" Plushie
Dati: stadio=baby
Situazione: The pet came back from the park with a plushie that isn't its own. It claims the plushie "followed it home."

### A · Take it back to the park
Esito: carisma+1, flag:onesto
Coda: The owner becomes its friend.

### B · It's family now
Esito: fel+8, flag:furbetto

### C · Put up "PLUSHIE FOUND" flyers around the block
Esito: int+1, monete+5
Coda: Reward money.

## C08 · The First Bad Word
Dati: stadio=baby
Situazione: The pet learned a new word from the trucker parked outside. It repeats the word. Often. Proudly.

### A · Laugh (don't)
Esito: fel+8, flag:boccaccia
Coda: It will say it again at the worst possible moment.

### B · Straight face, swap in a substitute word
Esito: int+1
Coda: Now it yells "CARROT!" with the exact same fury.

### C · Ignore it
Esito: fel+5, carisma+1
Coda: Two days later it says it TO A COP. The cop laughs, and the story becomes neighborhood legend.

## C09 · Pups Got Talent
Dati: stadio=baby
Situazione: The park is hosting "Pups Got Talent." The pet has no talent. The pet is CONVINCED it has one.

### A · Sign it up, whatever happens happens
Esito: carisma+1, fel+8
Coda: Dead last, standing ovation for effort.

### B · "You're still little for this"
Esito: fel-3, flag:rivincita_talent
Coda: We'll revisit this as a teen.

### C · Intensive training first
Esito: forza+1, fel+3
Coda: The act is still terrible, but athletically terrible.

## C10 · The Great Food Strike
Dati: stadio=baby
Situazione: The pet has crossed its arms in front of the kibble: it wants "whatever you're eating." You eat pixels.

### A · Let it taste your plate
Esito: fel+8, flag:palato_fino

### B · Kibble or nothing
Esito: int+1, fel-3
Coda: It learns the word "principles."

### C · PLATED kibble with a mint leaf garnish
Esito: carisma+1, fel+5
Coda: Presentation is everything.

## C11 · The Big Test
Dati: stadio=teen
Situazione: Math test tomorrow. The class nerd is selling "the right notes" for 10 coins. Suspiciously right.

### A · Study together tonight
Esito: int+2, energia-10

### B · Buy the "notes"
Esito: monete-10, flag:copione

### C · Whatever happens, happens
Esito: fel+3
Coda: Living dangerously.

## C12 · The Summons
Dati: stadio=teen ; richiedeFlag=copione
Situazione: The teacher figured it all out: the "right notes" were the stolen answer key. The pet is summoned. With you.

### A · Confess - with a 12-slide apology presentation
Esito: int+1, fel-3, flag:-copione
Coda: The teacher tears up on slide 9: "no one has ever apologized with a pie chart before."

### B · Deny. Always deny.
Esito se personalita=Maleducato: carisma+2
Esito 50/50: fel+5, flag:faccia_tosta
Esito 50/50: fel-8
Coda: If Rude, this becomes legend.

## C13 · The Shady Sponsor
Dati: stadio=teen
Situazione: A guy wearing too many rings offers 30 coins to advertise "SPLORF, the drink that changes you" at the neighborhood race. The last spokesperson was a traffic cone. You can tell it was a cone in the ad.

### A · Turn it down with class
Esito: carisma+1, flag:pulito

### B · Take the deal
Esito: monete+25, flag:venduto
Coda: At the next race-tag mission, no tips: the crowd remembers the SPLORF.

### C · Counter-offer: double or nothing
Esito 50/50: monete+40, flag:venduto
Esito 50/50: —
Coda: The guy either takes it, or gets offended and storms off with his rings.

## C14 · The Pigeon Comes Back Around
Dati: stadio=teen ; richiedeFlag=socio_del_piccione
Situazione: The cyborg pigeon returns with a proposal: a "crumb investment scheme." Returns 300%. In crumbs.

### A · Invest 10 coins
Esito: monete+25
Coda: The pigeon vanishes, then comes back. Zero explanations.

### B · "Get lost, partner"
Esito: fel+3, flag:occhio_lungo
Coda: The pigeon nods, respectfully.

### C · Report it to park security
Esito: int+1, fel-2
Coda: The pigeon stops acknowledging you exist.

## C15 · The "Upgraded" Scooter
Dati: stadio=teen ; lavoro=consegnepizza
Situazione: A friend from the garage offers to "fix up" the delivery scooter. Free of charge. "Trust me."

### A · Trust him
Esito: rendita:+3, flag:motorino_truccato
Coda: Coins every night, for the rest of the run (see C41).

### B · The scooter stays as it is
Esito: int+1
Coda: The word "free" always makes you suspicious.

## C16 · The Garage Band
Dati: stadio=teen
Situazione: The pet's friends are starting a band. They need a garage. You have one. They don't. See the problem?

### A · Garage granted, hours enforced
Esito: fel+8, carisma+1, energia-5
Coda: The "acoustic rehearsal" was not acoustic.

### B · No: my collection lives in there
Esito: int+1, fel-3

### C · Yes, but the pet is the manager
Esito: monete+15, flag:manager
Coda: First "concert," pay what you want.

## C17 · The First Date
Dati: stadio=teen
Situazione: The pet has a date. It has no idea what to wear. It has tried on the ENTIRE closet. Twice. The floor has vanished under the pile.

### A · Recommend the most ridiculous outfit it owns
Esito: carisma+2
Coda: If it owns an outfit, the scene features it.

### B · "You look fine as you are"
Esito: fel+8
Coda: It was the right answer. For once, the cliche actually works.

### C · Ironic 90s onesie
Esito: fel+6, flag:stile_discutibile
Coda: The photos will outlive us all.

## C18 · The Weird Substitute Teacher
Dati: stadio=teen
Situazione: A substitute teacher showed up teaching "alternative subjects": today it's budget-cutting and tram trivia.

### A · The pet follows along, thrilled
Esito: int+2
Coda: Surprisingly useful.

### B · Skip class
Esito: fel+5, flag:ribelle

### C · Invite the substitute over for dinner
Esito: carisma+1, cibo:Zuppa di verdure
Coda: He tears up and returns the favor.

## C19 · The Dance-Off
Dati: stadio=teen ; varianteFlag=rivincita_talent ; varianteTitolo=The Rematch
# DA SCRIVERE (fondatore): con flag:rivincita_talent questa carta diventa "The Rematch" (EN
# di "La Rivincita") - il doc dichiara la variante ma non ne scrive il testo. Finche' manca,
# con il flag presente cambia solo il TITOLO e la situazione resta questa.
Situazione: There's a dance-battle mat set up at the mall. A crowd forming. A local champion. The pet, cracking its knuckles.

### A · Challenge him
Esito: velocita+2, fel+5
Coda: Loses on points, but with a move that's entirely its own: the champion shakes its paw.

### B · Just film it
Esito: int+1, monete+8
Coda: The clip of the champion messing up is worth gold.

### C · YOU dance... well, the pet dances "its own way"
Esito: fel+8, carisma+1
Coda: Dignity: all of it, gone.

## C20 · The Study Group
Dati: stadio=teen
Situazione: Group test coming up: either with the nerds ("we'll actually study") or with the friends ("we'll study, promise, come on").

### A · The nerds
Esito: int+2, fel-3

### B · The friends
Esito: fel+8
Coda: You ordered pizza and talked about everything except the test.

### C · Solo
Esito: int+1, flag:lupo_solitario

## C21 · The Designer Backpack
Dati: stadio=teen
Situazione: Everyone at school has the "Guccino" backpack. The pet wants one. Costs 25 coins. It is IDENTICAL to the one it already has, except for the logo.

### A · Buy it for it
Esito: monete-25, fel+10, carisma+1
Coda: Social acceptance has a price. Literally.

### B · Write "Guccino" on its own with a highlighter
Esito 50/50: fel+5, flag:tarocco
Esito 50/50: fel+5, flag:tarocco, fel-5
Coda: Either nobody notices, or EVERYONE notices but it becomes legend anyway.

### C · "The backpack doesn't make the pet"
Esito: int+1, fel-3
Coda: The pet quotes the line to everyone as if it came up with it.

## C22 · The Trading Card Tournament
Dati: stadio=teen
Situazione: The pet discovered the "Battle Critters" card game. The janitor, rumor has it, owns the complete set. And shows no mercy.

### A · Buy it a pack
Esito: monete-8, fel+8, arredo:Carta Olografica del Drago

### B · Train it to trade its duplicates
Esito: carisma+1, monete+5
Coda: The card market is ruthless and it has a knack for it.

### C · Challenge the janitor, straight to the boss fight
Esito 50/50: fel+10, flag:grinder
Esito 50/50: fel-5, arredo:Carta Olografica del Drago
Coda: Either it wins and earns eternal respect, or it loses badly and the janitor gifts it a card "for the courage."

## C23 · The Secret Diary
Dati: stadio=teen
Situazione: Cleaning the bedroom, you find the pet's diary. OPEN. On the page titled "things I don't tell the boss."

### A · Don't read it. Just close it
Esito: fel+8, flag:fiducia
Coda: The pet notices, because the bookmark never moved.

### B · Just one line...
Esito: int+1, fel-3
Coda: It says "the boss reads my diary." IT KNEW.

### C · Leave a sticky note: "nice handwriting"
Esito: carisma+1, fel+5
Coda: Psychological warfare: won.

## C24 · The Big Night Out
Dati: stadio=teen ; personalita=Maleducato
Situazione: Friends propose sneaking out after curfew. The plan is "genius": a mannequin in the bed.

### A · Pretend you never saw the mannequin
Esito: fel+10, energia-15
Coda: It comes home at dawn walking like a crab.

### B · Flashlight to the face at 11:01 PM
Esito: int+1, carisma+1
Coda: The pet respects you. And fears you.

### C · Go WITH them ("someone has to keep watch")
Esito: fel+8, carisma+1, energia-10

## C25 · The Difficult Cases Shift
Dati: stadio=teen ; personalita=Gentile
Situazione: The shelter needs volunteers for the "difficult" critters: the one that bites, the one that explodes if it sneezes, and the one that quotes movies that don't exist. No volunteer has ever come back twice. The pet already has its vest on.

### A · Take on all three
Esito: fel+10, carisma+1, igiene-10, flag:cuore_doro
Coda: The biter now bites ONLY the bad guys. Success.

### B · Just the fake-movie one
Esito: int+1, fel+5
Coda: As Rocky said in Titanic 4... - now the pet quotes it too.

### C · Front desk shift: zero risk
Esito: monete+8, fel+3
Coda: Token pay. The explosive one still sneezes in your direction anyway.

## C26 · Comic Con
Dati: stadio=teen ; personalita=Nerd
Situazione: The convention is on Sunday. Its hero's costume doesn't come in pet size. "We're making it OURSELVES."

### A · A weekend of cardboard and glue
Esito: int+2, fel+10, flag:cosplayer
Coda: Hideous. And beautiful.

### B · Buy the "official" one
Esito: fel+5, carisma+1
Coda: It's SOLD OUT in its size: settles for the costume of a character it HATES, and wears it with magnetic resentment.

### C · Goes dressed as "itself, future version"
Esito: carisma+1, fel+5
Coda: Conceptual. Nobody gets it. It's proud anyway.

## C27 · The Sunrise Run
Dati: stadio=teen ; personalita=Sportivo
Situazione: The park running club meets at 5:30 AM. FIVE THIRTY. The pet has already set its alarm.

### A · Join it (in spirit)
Esito: velocita+2, energia-10, flag:alba_runner

### B · "At 5:30 we sleep"
Esito: energia+5, velocita+1
Coda: It goes alone and comes back UNBEARABLY energetic.

### C · Negotiate 7 AM with the group
Esito: carisma+1, velocita+1
Coda: You just reformed neighborhood running culture.

## C28 · The Rival Company Interview
Dati: stadio=adulto
Situazione: A rival company is courting the pet: same job, "more coins." The interview is at 3 PM. On the sly.

### A · Go hear them out
Esito: monete+20, flag:ambizioso
Coda: The current boss counter-offers to keep it.

### B · Total loyalty
Esito: carisma+1, fel+5
Coda: The boss finds out anyway, and gets choked up.

### C · Send the pigeon to ask around
Esito: int+1
Coda: It comes back with the org chart. Don't ask how.

## C29 · The Homeowners' Meeting
Dati: stadio=adulto
Situazione: The building wants to elect the pet as representative: "you're the only one who replies to texts."

### A · Accept the position
Esito: carisma+2, fel-3, flag:rappresentante
Coda: The first crisis hits DURING the inauguration speech.

### B · Decline gracefully
Esito: carisma+1, fel+5
Coda: Freedom has no price.

### C · Delegate everything to the closet monster
Cond: richiedeFlag=coinquilino
Esito: fel+8
Coda: The building approves: extremely efficient.

## C30 · The Crater-View Condo
Dati: stadio=adulto
Situazione: An agency is pitching "the deal of a lifetime": three-bedroom, crater view, "a neighborhood on the rise." The crater is THE one, from the challenges.

### A · Go see it in person
Esito: int+1, fel+5
Coda: The "crater view" is LITERAL: at night you can see the yellow glow. Atmospheric. Unsellable.

### B · Toss the flyer
Esito: fel+3, energia+3
Coda: The flyer COMES BACK. In the fridge. Three times. Before it finally stops.

### C · Resell it to a scam collector
Esito: monete+10, flag:occhio_lungo

## C31 · The Broke Ex-Rival
Dati: stadio=adulto
Situazione: The pet's longtime rival - the one from the park showdowns - shows up at the door. Needs a loan. Stares at his own shoes the whole time he asks.

### A · Lend it to him (20 coins)
Esito: monete-20, flag:creditore

### B · "No, but dinner's on me"
Esito: monete-8, carisma+1, fel+5
Coda: Both of their dignities: intact.

### C · "Remember when you pushed me in the puddle?"
Esito: fel+8, flag:vendicativo

## C32 · The "Big Pet Brother" Reality Show
Dati: stadio=adulto
Situazione: Citywide casting for the reality show: 3 days locked in a house with 7 other pets and the cameras rolling.

### A · Sign it up
Esito: carisma+2, fel+5, flag:reality
Coda: Voted out in round one, but the meltdown clip goes everywhere.

### B · "TV eats your soul"
Esito: int+1

### C · YOU go to casting as "the overprotective owner"
Esito: carisma+1, fel+8
Coda: They want you as the comic-relief duo. You decline, with honor.

## C33 · The Alien Prince Email
Dati: stadio=adulto
Situazione: Email: "I AM AN ALIEN PRINCE, I only need a small advance to unlock my 9000-coin inheritance."

### A · It's OBVIOUSLY a scam
Esito: int+2

### B · Reply just to waste his time
Esito: fel+8, flag:troll
Coda: After three emails the scammer gets attached and sends you the family recipe.

### C · "But what if it's REAL?"
Esito: monete-10, arredo:Mazzetta Finta, fel+5
Coda: 9000 MONOPOLY coins arrive in the mail. (The pet counts them anyway. Twice.)

## C34 · The Closet B&B
Dati: stadio=adulto ; richiedeFlag=coinquilino
Situazione: The tiny closet monster has grown up: it wants to open a B&B "for traveling monsters." In YOUR closet.

### A · 50-50 partner: first payout right now
Esito: monete+12, fel-2
Coda: The guests snore standing UP.

### B · Weekends only
Esito: monete+6
Coda: Weekday peace and quiet.

### C · "The closet goes back to being a closet"
Esito: fel+3
Coda: It opens the B&B AT THE NEIGHBOR'S, with a view of your living room. Waves at you every morning.

## C35 · The Old Gym Is Closing
Dati: stadio=adulto
Situazione: The gym where it trained for the first time is closing down: in its place, an "energy bowls and good vibrations" place. The owner is selling off EVERYTHING - a line of nostalgic regulars, each wanting a piece of history.

### A · Buy the legendary punching bag (15 coins)
Esito: monete-15, arredo:Sacco della Vecchia Palestra, fel+5
Esito se personalita=Sportivo: monete-15, arredo:Sacco della Vecchia Palestra, fel+10
Coda: It still has the sticker from its very first workout.

### B · Organize the farewell night
Esito: carisma+2, energia-10
Coda: The owner cries. The new place's "vibrations" are already embarrassed.

### C · Go sniff the energy bowls
Esito: int+1, fel+3
Coda: "Smells like cut grass with a side of ambition." The pet is weirdly won over.

## C36 · The Food Blogger They Call "The Grease"
Dati: stadio=adulto ; richiedePerk=corso_cucina
Situazione: The most feared food blogger in the city - known as "The Grease" for how she fries restaurants alive - has heard about your Home Cook. She invites herself to dinner. TONIGHT.

### A · Improvised tasting menu
Esito: int+2, monete+20
Coda: Review: "greasy, just right. FIVE PANS."

### B · Order takeout and plate it yourself
Esito 50/50: carisma+2
Esito 50/50: fel-5, carisma+1
Coda: Either she doesn't notice (the review praises "the simplicity"), or she catches the takeout box in the bin (and the takedown is so funny it goes viral).

### C · "The kitchen is closed"
Esito: carisma+1
Coda: "The Grease" respects someone who can say no. "I'll be back." It sounds like a threat.

## C37 · The Gallery Calls
Dati: stadio=adulto ; richiedePerk=corso_disegno
Situazione: A gallery wants to exhibit the pet's drawings. Including the portrait where you look like "an angry potato."

### A · Show everything, potato included
Esito: carisma+2, monete+20, fel+8
Coda: The potato is the most photographed piece in the room.

### B · Solo exhibition: JUST the potato
Esito: fel+10, carisma+1
Coda: Twelve visitors get emotional in front of the potato. One waves at it.

### C · The potato goes to auction
Esito: monete+35, flag:mecenate_involontario
Coda: You will never see your portrait again.

## C38 · Karaoke Night at the Office
Dati: stadio=adulto ; richiedePerk=corso_musica
Situazione: Work dinner for the side job. There's karaoke. The boss already wrote down the pet's name. For a duet. WITH HIM.

### A · Duet, no fear
Esito: carisma+2, fel+8, monete+15
Coda: The boss, moved to tears, rounds up the night's pay.

### B · "Only if I pick the song"
Esito: carisma+1, fel+5
Coda: The boss agrees: it's going to be a power ballad. The boss CANNOT sing power ballads.

### C · Escape through the bathroom window
Esito: fel+3, energia+5, flag:fantasma_del_karaoke
Coda: They still talk about it at the office.

## C39 · The Debtor Returns
Dati: stadio=adulto ; richiedeFlag=creditore
Situazione: The ex-rival is back. He has the 20 coins. And also an idea: "what if, instead of paying you back... we invested it TOGETHER?"

### A · Just give me my money
Esito: monete+20

### B · Hear the idea out
Esito 50/50: monete+40
Esito 50/50: monete+0, carisma+1
Coda: Either it was a good idea, or it was a snow-cone stand in December (but the handshake still counts).

### C · Forgive the debt
Esito: carisma+2, flag:cuore_doro
Coda: He won't forget it: word travels, even into retirement.

## C40 · The Day Off
Dati: stadio=adulto
Situazione: The boss grants a paid day off: "you've earned it." The pet has ZERO plans, and it is glorious.

### A · Pajama day and toys
Esito: fel+10, energia+10

### B · "While we're at it": extra gym session
Esito: forza+1

### C · Fishing trip with the retirees down at the harbor
Esito: fel+8, cibo:Pesce alla griglia
Coda: They come back with ONE fish between the seven of them. The pet caught it. Nobody talks about anything else for a week.

## C41 · The Police Checkpoint
Dati: stadio=adulto ; richiedeFlag=motorino_truccato
Situazione: Checkpoint outside the pizza place. The cop circles the "upgraded" scooter with a notepad and one raised eyebrow.

### A · Confess to the tune-up
Esito: monete-15, flag:-motorino_truccato, int+1

### B · "It's stock, I swear"
Esito 50/50: —
Esito 50/50: monete-15, rendita:-3, flag:-motorino_truccato
Coda: He either buys it ("nice model"), or doesn't: the scooter goes back to stock.

### C · Distract him with the showstopper: the silent burnout
Esito 50/50: flag:-motorino_truccato
Esito 50/50: monete-25, flag:-motorino_truccato
Coda: The cop turns out to be an ex-mechanic and gets EMOTIONAL, the tune-up becomes "certified" (payout stays), or double the fine.
