# Forrest Gampo — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: candido, lentissimo a parlare, velocissimo a correre. Ogni battuta rischia di partire per la tangente con un ricordo. Cita sempre la mamma. Catchphrase: "La mamma diceva sempre..." · per la stanchezza: "sono un po' stanchino".

## Saluto (apertura app)
- Hi. You came back. I waited right here, sitting down. I'm real good at waiting. One time I waited three days for a bus. It wasn't the right stop.
- Hi, {utente}. Mama always said: folks you love come back, long as you leave the light on. I left it on.
- You're here! I was thinking about something... I don't remember what. But now you're here, and that's better.
- Hi. I saw you coming from way off. You run kinda slow. I could teach you if you want. Running is the one thing I'm real good at.

## Ha fame
- I'm hungry. Mama always said: hunger is like rain. Sooner or later it comes, and you need an umbrella. I think the umbrella is lunch.
- I could eat. Reminds me of the time I ate forty shrimps... no, prawns. No, that was somebody else. But I'm hungry.
- My tummy's making the noises. I always answer it real polite, but the only language it speaks is food.
- I've been hungry for a while. I didn't say so right away 'cause it seemed rude. Now my tummy's saying it for me.

## È sporco
- I'm dirty. It happened real slow and then all at once, like most things in life.
- Mama always said: dirt tells you where you've been. I guess I've been just about everywhere. Wash me anyway, though.
- I looked, and there's more stains than yesterday. I counted them. Then I lost count. Then I lost why I was counting.
- I'm a little bit muddy. Mud is fun when you get in it, less fun when it stays on you. Bath time?

## Coccole finite
- That's enough cuddles for today. Not 'cause I don't like them. Mama said happiness comes in installments. Like the couch did.
- Today's pets are all used up. I lined them up in my head, one by one. They're nice even standing still.
- That's enough now. One time I got so many cuddles all at once, I fell asleep from the feelings. Better to take it slow.
- No more cuddles. There's more tomorrow. Good things come back, like buses. Sooner or later.

## Parte per la missione
- I'm going. I don't rightly know what's out there, but I'm going anyway. That's usually how it works.
- Off on the mission. If there's running to do, I'll be just fine: running happens without me thinking. It's the thinking that slows me down.
- I'm going, {utente}. Mama always said: do your best and be home for supper. I'm gonna do both.
- Mission time. I said bye to the house, I said bye to you. Now I'll say bye and go, or else I'll just keep on saying bye.

## Ritorno: successo
- It went good. I didn't realize I was winning at first, and maybe that's why I won.
- Mission accomplished! At one point all I had to do was run, and that part felt just like home.
- I did it. Mama always said: life is like a box of kibble, you never know which flavor you're gonna get. Today I got a good one.
- All done. Folks kept saying good job and I kept saying thank you. Then good job again, thank you again. It was a nice day.

## Ritorno: fallimento
- It didn't go so good. I felt sad for a while, then I saw a cloud shaped like a sandwich and most of the sad went away.
- I lost, I think. It's not always easy to tell right away. But the way there was real pretty, that I know.
- The mission went sideways. Mama always said: when you fall down, take a look at what's on the ground. I found a button. You keep it.
- It went bad, and I'm pretty tired. Both at the same time. Tomorrow only one of those will be left, you'll see.

## Va a dormire
- Going to sleep now. I'm pretty tired.
- Goodnight. Mama always said: dreams are free, so dream a whole bunch. I always try.
- Off to bed. Today I did a lot of things, or maybe a few things real slowly. Lying down, they feel the same.
- Goodnight, {utente}. I'll think about you a little bit and then sleep. The order matters, or else I'll be thinking about you all night long.

## Sveglia (risveglio dopo il sonno)
- Good morning. I woke up and the sun was out. I didn't do that, but it's nice anyhow.
- I'm awake! I dreamed I was running. Then I woke up and my legs were still running a little bit.
- Good morning, {utente}. Mama always said: good days start with breakfast. Let's start this one.
- I'm awake. Eyes first, then the rest of me. The rest of me always takes a while longer.
