window.PETQ = window.PETQ || {};

(function () {

  // i18n bilingue (v. ui.js/i18n.js): SOLO i msg "telaio" (piazza/rimuovi/vendi/aggiungi qui
  // sotto). MAI i nomi degli arredi (sono chiavi/testi di content/arredi.md).
  var traduci = (PETQ.i18n && PETQ.i18n.t) || function (s) { return s; };

  // Stanze disponibili (v. app/js/rooms.js _stanze): usate per la struttura piazzati e per
  // validare piazza(). Duplicato minimale qui per non dipendere da rooms.js (che e' un modulo
  // grafico, fuori dallo scope di questo file).
  var STANZE = ['cucina', 'bagno', 'salone', 'camera'];

  // Mappa sostituzioni: regola di design fissa citata in prosa (missioni.md/bilanciamento.md),
  // non ricavabile dalla tabella arredi.md in modo generico. Chiave = nome che arriva come
  // reward, valore = nome che viene sostituito/rimosso se posseduto. Copre anche il caso
  // speciale "Il Topo (allenatore)" permanente che sostituisce se stesso in versione temporanea
  // (stesso nome, la differenza e' la presenza di scadenzaMs).
  var SOSTITUZIONI = {
    'Completo da martial artist': 'Fascia da martial artist',
    'Libro': 'Album da disegno'
  };

  var NOME_ALLENATORE = 'Il Topo (allenatore)';

  // Stat RPG boostabili dalla Pianta Esotica (effettoSpeciale 'stat_random_giornaliera').
  var STAT_RPG = ['forza', 'intelligenza', 'velocita', 'carisma'];

  function bilanciamento() {
    var data = window.PETQ.content && window.PETQ.content.data;
    if (data && data.bilanciamento) return data.bilanciamento;
    console.warn('PETQ.arredi: bilanciamento non disponibile, uso default locali');
    return {};
  }

  // Slot per stanza (decisione fondatore, GDD "Slot arredo, tetto passivo e Ingrandimento casa"):
  // base 3 posizioni per stanza, che diventano 4 SOLO se il giocatore ha comprato l'upgrade
  // globale "Ingrandimento casa" (state.ingrandimentoCasa). Il numero e' deciso QUI, non dal
  // bilanciamento (l'ampliamento e' un acquisto shop, non un parametro di content).
  function slotPerStanza(state) {
    return 3 + ((state && state.ingrandimentoCasa) ? 1 : 0);
  }

  // Valore di vendita fallback per arredi da missione: la tabella arredi.md non ha un prezzo
  // numerico per gli arredi ottenuti da missione (solo quelli "negozio N monete" ce l'hanno,
  // nella colonna "Come si ottiene"). Decisione presa qui: 10 monete base, vendita al 50% (5).
  var VALORE_FALLBACK = 10;

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  // Guardia difensiva: garantisce che state.arredi sia nel formato nuovo anche se lo stato
  // non e' ancora passato da PETQ.save.load (es. subito dopo avviaPartita nello stesso avvio).
  function assicuraArrediStruct(state) {
    if (!state) return;
    if (!state.arredi || typeof state.arredi !== 'object' || Array.isArray(state.arredi) ||
        !state.arredi.posseduti || !state.arredi.piazzati) {
      state.arredi = { posseduti: [], piazzati: { cucina: [], bagno: [], salone: [], camera: [] } };
    }
    if (!Array.isArray(state.arredi.posseduti)) state.arredi.posseduti = [];
    if (!state.arredi.piazzati || typeof state.arredi.piazzati !== 'object') {
      state.arredi.piazzati = { cucina: [], bagno: [], salone: [] };
    }
    for (var i = 0; i < STANZE.length; i++) {
      if (!Array.isArray(state.arredi.piazzati[STANZE[i]])) state.arredi.piazzati[STANZE[i]] = [];
    }
  }

  function trovaArredoContent(nome) {
    var data = window.PETQ.content && window.PETQ.content.data;
    var elenco = (data && data.arredi) || [];
    for (var i = 0; i < elenco.length; i++) {
      if (elenco[i].nome === nome) return elenco[i];
    }
    return null;
  }

  // Rimuove (una sola occorrenza) un arredo posseduto per nome; ritorna la voce rimossa o null.
  function rimuoviDaPosseduti(state, nome) {
    var lista = state.arredi.posseduti;
    for (var i = 0; i < lista.length; i++) {
      if (lista[i].nome === nome) {
        return lista.splice(i, 1)[0];
      }
    }
    return null;
  }

  function rimuoviDaPiazzati(state, nome) {
    var stanze = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanze.length; s++) {
      var lista = state.arredi.piazzati[stanze[s]];
      for (var i = 0; i < lista.length; i++) {
        if (lista[i].nome === nome) {
          return { voce: lista.splice(i, 1)[0], stanza: stanze[s] };
        }
      }
    }
    return null;
  }

  // aggiungi: gestisce sostituzioni (Completo sostituisce Fascia, Libro sostituisce Album,
  // Topo permanente sostituisce Topo temporaneo) e doppioni (permessi come voci separate,
  // la vendita doppioni la gestisce vendi()). opts opzionale {scadenzaMs}.
  function aggiungi(state, nome, opts) {
    assicuraArrediStruct(state);
    if (!nome) return { ok: false, msg: traduci('nome arredo mancante') };
    opts = opts || {};

    // caso speciale: "Il Topo (allenatore)" permanente (senza scadenzaMs) sostituisce se
    // stesso in versione temporanea (con scadenzaMs), sia tra i posseduti che tra i piazzati.
    if (nome === NOME_ALLENATORE && typeof opts.scadenzaMs !== 'number') {
      sostituisciOvunque(state, NOME_ALLENATORE);
    }

    // preferisce il campo "sostituisce" dedotto dal parser (content.js parseArredi, dalla
    // colonna "Come si ottiene" di arredi.md: "sostituisce Fascia"/"sostituisce l'Album");
    // SOSTITUZIONI resta come fallback se il content non e' ancora caricato o il campo manca.
    var info = trovaArredoContent(nome);
    var daSostituire = (info && info.sostituisce) ? info.sostituisce : SOSTITUZIONI[nome];
    if (daSostituire) {
      sostituisciOvunque(state, daSostituire);
    }

    var voce = { nome: nome };
    if (typeof opts.scadenzaMs === 'number') voce.scadenzaMs = opts.scadenzaMs;
    state.arredi.posseduti.push(voce);

    return { ok: true, msg: nome + traduci(' aggiunto alla collezione.') };
  }

  // rimuove tutte le occorrenze di 'nomeDaTogliere' (posseduto o piazzato, mantiene la stanza
  // se era piazzato non e' richiesto dalla spec: il nuovo arredo va semplicemente aggiunto
  // come non-piazzato, coerente con "sostituisce" = toglie il vecchio, il nuovo si piazza a parte).
  function sostituisciOvunque(state, nomeDaTogliere) {
    while (rimuoviDaPosseduti(state, nomeDaTogliere)) {}
    var r;
    do { r = rimuoviDaPiazzati(state, nomeDaTogliere); } while (r);
  }

  function trovaSlotStanza(state, stanza) {
    return state.arredi.piazzati[stanza] || null;
  }

  function piazza(state, nome, stanza) {
    assicuraArrediStruct(state);
    if (STANZE.indexOf(stanza) === -1) {
      return { ok: false, msg: traduci('Stanza non valida.') };
    }
    var posseduto = null;
    for (var i = 0; i < state.arredi.posseduti.length; i++) {
      if (state.arredi.posseduti[i].nome === nome) { posseduto = state.arredi.posseduti[i]; break; }
    }
    if (!posseduto) {
      return { ok: false, msg: traduci('Arredo non posseduto.') };
    }

    // gia' piazzato da qualche parte?
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var j = 0; j < lista.length; j++) {
        if (lista[j].nome === nome) return { ok: false, msg: traduci('Arredo gia\' piazzato.') };
      }
    }

    var slotMax = slotPerStanza(state);
    var listaStanza = trovaSlotStanza(state, stanza);
    if (listaStanza.length >= slotMax) {
      return { ok: false, msg: traduci('Slot della stanza pieni (') + slotMax + ').' };
    }

    rimuoviDaPosseduti(state, nome);
    listaStanza.push(posseduto);

    // Armeria (regola fondatore "se impugnata deve sparire dalla casa", e viceversa): un'arma
    // sta O in casa O in mano, mai in entrambe. Piazzarla in una stanza la toglie dalla mano
    // (niente doppio bonus piazzata+impugnata, niente doppio disegno).
    if (state.armaEquip === nome) state.armaEquip = null;

    // se abbiamo appena piazzato la Pianta Esotica, estrai subito la stat del giorno cosi'
    // il bonus parte immediatamente (se e' un altro arredo, questa e' un no-op).
    aggiornaPiantaEsotica(state, false);

    return { ok: true, msg: nome + traduci(' piazzato in ') + stanza + '.' };
  }

  function rimuovi(state, nome) {
    assicuraArrediStruct(state);
    var r = rimuoviDaPiazzati(state, nome);
    if (!r) return { ok: false, msg: traduci('Arredo non piazzato.') };
    state.arredi.posseduti.push(r.voce);
    // se abbiamo tolto la Pianta Esotica dal piazzamento, azzera la stat del giorno.
    aggiornaPiantaEsotica(state, false);
    return { ok: true, msg: nome + traduci(' rimesso in collezione.') };
  }

  // calcolaRicavoVendita: cifra ESATTA che il giocatore incassa vendendo 'nome'. UNICA funzione
  // che fa questo calcolo (usata sia da vendi() per accreditare le monete, sia dalla UI negozio
  // per MOSTRARLA prima di vendere, v. ui.js valoreRivendita): se restassero due calcoli
  // separati potrebbero disallinearsi (il negozio promette un numero e ne paga un altro — e'
  // esattamente il difetto "alto valore di rivendita" che incassava 5 monete).
  // Priorita': (1) content/arredi.md puo' avere un valore di rivendita ESPLICITO nella colonna
  // "Come si ottiene" ("rivendita N monete", chiave diversa da "negozio N monete" apposta per
  // non rendere l'arredo acquistabile): quello si incassa PER INTERO, non e' un prezzo da
  // dimezzare. (2) altrimenti comportamento storico: 50% del prezzo negozio se presente,
  // altrimenti 50% di VALORE_FALLBACK, con lo stesso console.warn di sempre.
  function calcolaRicavoVendita(nome) {
    var infoContent = trovaArredoContent(nome);
    if (infoContent && typeof infoContent.rivendita === 'number') {
      return infoContent.rivendita;
    }

    var valore = VALORE_FALLBACK;
    if (infoContent && infoContent.fonte) {
      var m = infoContent.fonte.match(/negozio\s+(\d+)/i);
      if (m) valore = parseInt(m[1], 10);
      else console.warn('PETQ.arredi: nessun prezzo negozio per "' + nome + '", uso valore fallback ' + VALORE_FALLBACK);
    } else {
      console.warn('PETQ.arredi: arredo "' + nome + '" non trovato in content.data.arredi, uso valore fallback ' + VALORE_FALLBACK);
    }
    return Math.round(valore * 0.5);
  }

  // vendi: rimuove del tutto (posseduto o piazzato), accredita il ricavo (v. calcolaRicavoVendita:
  // 50% del prezzo negozio/fallback, o il valore di rivendita esplicito se l'arredo lo ha).
  function vendi(state, nome) {
    assicuraArrediStruct(state);
    var rimossoPosseduto = rimuoviDaPosseduti(state, nome);
    var rimossoPiazzato = rimossoPosseduto ? null : rimuoviDaPiazzati(state, nome);
    if (!rimossoPosseduto && !rimossoPiazzato) {
      return { ok: false, msg: traduci('Arredo non trovato.') };
    }

    var ricavo = calcolaRicavoVendita(nome);
    state.coins = (state.coins || 0) + ricavo;

    // se abbiamo venduto la Pianta Esotica (era piazzata), azzera la stat del giorno.
    aggiornaPiantaEsotica(state, false);

    // Armeria (FASE SPRITE): se abbiamo venduto l'ULTIMA copia dell'arma equipaggiata,
    // l'equip va azzerato (niente sprite in mano ne' bonus di un'arma che non c'e' piu').
    if (state.armaEquip === nome) {
      var ancora = false;
      var poss = state.arredi.posseduti || [];
      for (var ip = 0; ip < poss.length; ip++) { if (poss[ip] && poss[ip].nome === nome) { ancora = true; break; } }
      if (!ancora) {
        var stanzeK = Object.keys(state.arredi.piazzati || {});
        for (var is = 0; is < stanzeK.length && !ancora; is++) {
          var listaS = state.arredi.piazzati[stanzeK[is]] || [];
          for (var ii = 0; ii < listaS.length; ii++) { if (listaS[ii] && listaS[ii].nome === nome) { ancora = true; break; } }
        }
      }
      if (!ancora) state.armaEquip = null;
    }

    return { ok: true, msg: traduci('Venduto ') + nome + traduci(' per ') + ricavo + traduci(' monete.') };
  }

  // effettiRpgArredo: i bonus RPG di UN arredo, come lista [{nome, valore}].
  // La fonte VERA e' info.effetti (v. content.js parseArredi/estraiBonusArredo): un arredo puo'
  // avere DUE bonus RPG ("+2 Intelligenza + +1 Carisma passiva") e la coppia LEGACY
  // bonusStat/bonusValore ne conserva solo il PRIMO — leggere solo quella faceva sparire in
  // silenzio il secondo bonus dei 5 arredi a doppio effetto (Martelletto da Giudice, Coppa del
  // Vincitore, Poster del Campione, Pupazzo Mostriciattolo, Mappa Incorniciata).
  // Gli effetti 'benessere' NON entrano qui: la Felicita passiva della casa e' un'altra cosa e la
  // gestisce felicitaPassivaCasa() (regalata al nuovo giorno da care.dailyLogin).
  // FALLBACK legacy: se l'arredo non ha il campo effetti (record costruito a mano, content vecchio,
  // catalogo non ancora ri-parsato) si ricade su bonusStat/bonusValore, cosi' nessun chiamante
  // perde il bonus che vedeva prima.
  function effettiRpgArredo(info) {
    var out = [];
    if (!info) return out;
    if (Array.isArray(info.effetti)) {
      for (var i = 0; i < info.effetti.length; i++) {
        var ef = info.effetti[i];
        if (ef && ef.tipo === 'rpg' && ef.nome) out.push({ nome: ef.nome, valore: ef.valore || 0 });
      }
    }
    if (out.length === 0 && info.bonusStat) {
      out.push({ nome: info.bonusStat, valore: info.bonusValore || 0 });
    }
    return out;
  }

  // bonusPassivi: somma TUTTI i bonus RPG degli arredi PIAZZATI per stat, cap +3 per singola stat
  // (tetto passivo, decisione fondatore GDD "Slot arredo, tetto passivo e Ingrandimento casa":
  // il tetto e' SEMPRE +3, non dipende dall'upgrade Ingrandimento casa).
  // Companion LEGGENDARI (P3, Grandi Imprese, rarita' "leggendaria", v. content/arredi.md sezione
  // dedicata): il loro +3 e' FISSO e IGNORA questo tetto — sommati in un accumulatore SEPARATO
  // (extraLeggendari) e aggiunti DOPO il clamp, cosi' il resto degli arredi resta cappato come
  // oggi e i companion si sommano pieni sopra il cap (es. gia' a +3 normale + Giga Ciad = +6 Forza).
  function bonusPassivi(state) {
    assicuraArrediStruct(state);
    var somma = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    var extraLeggendari = { forza: 0, intelligenza: 0, velocita: 0, carisma: 0 };
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var i = 0; i < lista.length; i++) {
        var info = trovaArredoContent(lista[i].nome);
        if (!info) continue;
        var pool = (info.rarita === 'leggendaria') ? extraLeggendari : somma;
        var rpg = effettiRpgArredo(info);
        for (var e = 0; e < rpg.length; e++) {
          if (typeof pool[rpg[e].nome] === 'number') pool[rpg[e].nome] += rpg[e].valore;
        }
        // Pianta Esotica: +N alla stat RPG estratta per oggi (state.piantaEsoticaStat), nel
        // pool arredi -> soggetta al cap +3 come gli altri bonus (comportamento voluto).
        // Il numero resta sul campo legacy bonusValore: la colonna Bonus di questo arredo non
        // nomina una stat (e' "casuale"), quindi non produce nessuna voce in info.effetti.
        if (info.effettoSpeciale === 'stat_random_giornaliera' &&
            state.piantaEsoticaStat && typeof somma[state.piantaEsoticaStat] === 'number') {
          somma[state.piantaEsoticaStat] += (info.bonusValore || 2);
        }
      }
    }
    var chiavi = Object.keys(somma);
    for (var k = 0; k < chiavi.length; k++) {
      somma[chiavi[k]] = clamp(somma[chiavi[k]], 0, 3) + (extraLeggendari[chiavi[k]] || 0);
    }
    return somma;
  }

  // perkAttivi: array dei perk le cui fonti sono PIAZZATE.
  function perkAttivi(state) {
    assicuraArrediStruct(state);
    var perks = [];
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var i = 0; i < lista.length; i++) {
        var info = trovaArredoContent(lista[i].nome);
        if (info && info.perk && perks.indexOf(info.perk) === -1) {
          perks.push(info.perk);
        }
      }
    }
    return perks;
  }

  // arredoScaduto: vero se la voce (posseduta o piazzata) ha scadenzaMs superato.
  function trovaVoceOvunque(state, nome) {
    for (var i = 0; i < state.arredi.posseduti.length; i++) {
      if (state.arredi.posseduti[i].nome === nome) return state.arredi.posseduti[i];
    }
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var j = 0; j < lista.length; j++) {
        if (lista[j].nome === nome) return lista[j];
      }
    }
    return null;
  }

  function arredoScaduto(state, nome) {
    var voce = trovaVoceOvunque(state, nome);
    if (!voce || typeof voce.scadenzaMs !== 'number') return false;
    return Date.now() >= voce.scadenzaMs;
  }

  // haEffettoSpeciale: vero se un arredo PIAZZATO (e non scaduto) ha quell'effettoSpeciale
  // (v. content.js parseArredi/estraiBonusArredo, es. 'igiene_dimezza_pioggia' per l'Ombrello
  // meccanico). Usato dal motore missioni per dimezzare il calo Igiene nelle missioni a rischio.
  function haEffettoSpeciale(state, chiave) {
    assicuraArrediStruct(state);
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var i = 0; i < lista.length; i++) {
        if (arredoScaduto(state, lista[i].nome)) continue;
        var info = trovaArredoContent(lista[i].nome);
        if (info && info.effettoSpeciale === chiave) return true;
      }
    }
    return false;
  }

  /* Caricatore da Viaggio (premio dei 7 giorni di carica, Retention 2.0/A2): rallenta il calo
   * dell'Energia finche' e' PIAZZATO. Vale il possesso + il piazzamento, come per i companion:
   * tenerlo in magazzino non fa niente.
   *
   * E' un MOLTIPLICATORE e non il "+1 Energia" piatto che avevo proposto al fondatore, per un
   * motivo strutturale: il calo base e' -2 all'ora e il talento Energico lo dimezza gia' a -1,
   * quindi un -1 piatto in piu' avrebbe portato il calo esattamente a ZERO — pet che non dorme
   * mai, sonno e cancelli energia delle missioni scavalcati. Moltiplicando, i due effetti si
   * compongono (0,5 x 0,75) e non possono mai annullare il decadimento, per costruzione.
   *
   * Non passa da content.js (l'oggetto non e' nel file del socio, v. ui.js ARREDI_STREAK_INFO):
   * qui basta il nome, che e' la chiave con cui vive in state.arredi.
   */
  var CARICATORE_STREAK = 'Caricatore da Viaggio';
  var CARICATORE_MULT = 0.75;

  function energiaDecayMultArredi(state) {
    if (!state) return 1;
    assicuraArrediStruct(state);
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var i = 0; i < lista.length; i++) {
        if (lista[i] && lista[i].nome === CARICATORE_STREAK) return CARICATORE_MULT;
      }
    }
    return 1;
  }

  // valoreEffettoSpeciale: il bonusValore dell'arredo PIAZZATO (non scaduto) che ha quell'effetto
  // speciale, cosi' i numeri restano in content/arredi.md ("sconto cibo 10%", "igiene +5 extra per
  // lavaggio") e non qui. Ritorna 0 se nessun arredo con quell'effetto e' piazzato.
  function valoreEffettoSpeciale(state, chiave, fallback) {
    assicuraArrediStruct(state);
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var i = 0; i < lista.length; i++) {
        if (arredoScaduto(state, lista[i].nome)) continue;
        var info = trovaArredoContent(lista[i].nome);
        if (info && info.effettoSpeciale === chiave) {
          return (typeof info.bonusValore === 'number' && info.bonusValore > 0) ? info.bonusValore : fallback;
        }
      }
    }
    return 0;
  }

  // CASA ACCOGLIENTE (fase giocattoli, 28 lug 2026 — prima era un bonus FANTASMA): 29 arredi hanno
  // "+N Felicita passiva" scritto in arredi.md e nessun modulo la leggeva. Ora la Felicita passiva
  // degli arredi PIAZZATI si somma (cap 10) e viene regalata al pet al NUOVO GIORNO, dentro
  // care.dailyLogin insieme alle monete del login: una casa piena di roba bella tiene su il morale.
  // Letta da `effetti` (il dato completo, v. content.js), non da bonusStat/bonusValore che sono i
  // campi LEGACY del primo effetto RPG e per questi arredi valgono null/0.
  var FELICITA_CASA_CAP = 10;

  function felicitaPassivaCasa(state) {
    assicuraArrediStruct(state);
    var somma = 0;
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var i = 0; i < lista.length; i++) {
        if (arredoScaduto(state, lista[i].nome)) continue;
        var info = trovaArredoContent(lista[i].nome);
        if (!info || !info.effetti) continue;
        for (var e = 0; e < info.effetti.length; e++) {
          var ef = info.effetti[e];
          if (ef && ef.tipo === 'benessere' && ef.nome === 'felicita') somma += (ef.valore || 0);
        }
      }
    }
    if (somma < 0) somma = 0;
    return Math.min(somma, FELICITA_CASA_CAP);
  }

  // Frigo nuovo (effettoSpeciale 'sconto_cibo', 80 monete): -10% sul prezzo del cibo al negozio.
  // Arrotondato per DIFETTO, minimo 1 moneta (nessun cibo diventa gratis). La percentuale viene da
  // arredi.md. Esposta qui perche' il negozio (ui.js, fase 3) e chiunque calcoli il prezzo di un
  // cibo devono passare tutti da questa funzione, invece di duplicare lo sconto.
  function prezzoCiboScontato(state, prezzo) {
    var base = (typeof prezzo === 'number' && prezzo > 0) ? prezzo : 0;
    if (base <= 0) return base;
    var perc = valoreEffettoSpeciale(state, 'sconto_cibo', 10);
    if (!perc) return base;
    return Math.max(1, Math.floor(base * (100 - perc) / 100));
  }

  // Vasca idromassaggio (effettoSpeciale 'igiene_extra_lavaggio', 150 monete): +5 Igiene extra a
  // ogni lavaggio. Il lavaggio porta gia' l'Igiene a 100 (il massimo), quindi l'extra si accumula
  // come CREDITO che assorbe il primo calo di Igiene successivo (v. care.wash + pet.applyDecay):
  // e' l'unico modo di far valere davvero quei 5 punti sopra il tetto invece di buttarli via.
  function igieneExtraLavaggio(state) {
    return valoreEffettoSpeciale(state, 'igiene_extra_lavaggio', 5);
  }

  // aggiornaPiantaEsotica: gestisce la stat RPG boostata dalla Pianta Esotica (effettoSpeciale
  // 'stat_random_giornaliera'). Se la Pianta NON e' piazzata -> azzera state.piantaEsoticaStat.
  // Se e' piazzata: con forzaReroll=true ri-tira SEMPRE (nuovo giorno di gioco); con forzaReroll
  // =false setta la stat solo se mancante/non-valida (piazzamento iniziale, migrazione, boot).
  // Il contributo +N alla stat e' applicato in bonusPassivi (soggetto al cap +2 come gli altri).
  function aggiornaPiantaEsotica(state, forzaReroll) {
    if (!state) return;
    assicuraArrediStruct(state);
    var attivo = haEffettoSpeciale(state, 'stat_random_giornaliera');
    if (!attivo) { state.piantaEsoticaStat = null; return; }
    var rng = window.PETQ.rng;
    if (forzaReroll || !state.piantaEsoticaStat || STAT_RPG.indexOf(state.piantaEsoticaStat) === -1) {
      state.piantaEsoticaStat = (rng && rng.pick) ? rng.pick(STAT_RPG) : STAT_RPG[0];
    }
  }

  // scadiTemporanei: rimuove (da posseduti e piazzati) gli arredi con scadenzaMs superato,
  // es. "il topo come allenatore per 7 giorni" (M7 Intimidazione). Da chiamare al login
  // giornaliero/boot. Ritorna i nomi rimossi (per eventuale notifica UI futura).
  function scadiTemporanei(state) {
    assicuraArrediStruct(state);
    var rimossi = [];
    var ora = Date.now();

    for (var i = state.arredi.posseduti.length - 1; i >= 0; i--) {
      var v = state.arredi.posseduti[i];
      if (typeof v.scadenzaMs === 'number' && ora >= v.scadenzaMs) {
        rimossi.push(v.nome);
        state.arredi.posseduti.splice(i, 1);
      }
    }
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var j = lista.length - 1; j >= 0; j--) {
        if (typeof lista[j].scadenzaMs === 'number' && ora >= lista[j].scadenzaMs) {
          rimossi.push(lista[j].nome);
          lista.splice(j, 1);
        }
      }
    }
    return rimossi;
  }

  // perkAttivi() gia' esclude implicitamente solo per piazzamento; aggiungiamo qui il check
  // scadenza (un allenatore 7g scaduto non e' un perk di categoria, ma per coerenza generale
  // qualunque arredo temporaneo scaduto non deve contribuire a bonus/perk).
  var perkAttiviBase = perkAttivi;
  perkAttivi = function (state) {
    assicuraArrediStruct(state);
    var perks = [];
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var i = 0; i < lista.length; i++) {
        if (arredoScaduto(state, lista[i].nome)) continue;
        var info = trovaArredoContent(lista[i].nome);
        if (info && info.perk && perks.indexOf(info.perk) === -1) {
          perks.push(info.perk);
        }
      }
    }
    return perks;
  };

  // bonus del Topo allenatore: +1 all'allenamento di Forza se piazzato e non scaduto
  // (l'arredo e' programmatico, non viene da arredi.md, quindi ha il suo hook dedicato)
  function bonusAllenamento(state, statNome) {
    if (statNome !== 'forza' || !state) return 0;
    assicuraArrediStruct(state);
    var stanzeKeys = Object.keys(state.arredi.piazzati);
    for (var s = 0; s < stanzeKeys.length; s++) {
      var lista = state.arredi.piazzati[stanzeKeys[s]];
      for (var i = 0; i < lista.length; i++) {
        if (lista[i].nome === NOME_ALLENATORE && !arredoScaduto(state, lista[i].nome)) return 1;
      }
    }
    return 0;
  }

  window.PETQ.arredi = {
    aggiungi: aggiungi,
    piazza: piazza,
    rimuovi: rimuovi,
    vendi: vendi,
    calcolaRicavoVendita: calcolaRicavoVendita,
    bonusPassivi: bonusPassivi,
    perkAttivi: perkAttivi,
    haEffettoSpeciale: haEffettoSpeciale,
    bonusAllenamento: bonusAllenamento,
    aggiornaPiantaEsotica: aggiornaPiantaEsotica,
    scadiTemporanei: scadiTemporanei,
    slotPerStanza: slotPerStanza,
    // Effetti speciali agganciati nella fase giocattoli (prima erano dichiarati e morti)
    felicitaPassivaCasa: felicitaPassivaCasa,
    prezzoCiboScontato: prezzoCiboScontato,
    igieneExtraLavaggio: igieneExtraLavaggio,
    energiaDecayMultArredi: energiaDecayMultArredi,
    _valoreEffettoSpeciale: valoreEffettoSpeciale,
    _effettiRpgArredo: effettiRpgArredo,
    _felicitaCasaCap: FELICITA_CASA_CAP,
    _assicuraArrediStruct: assicuraArrediStruct,
    _sostituzioni: SOSTITUZIONI,
    _nomeAllenatore: NOME_ALLENATORE
  };

})();

// ============================================================================
// PETQ.giocattoli — il MOTORE del menu "Usa un giocattolo" (salone).
// Modulo dichiarato QUI dentro arredi.js (stesso file, IIFE separata) invece che in un file
// nuovo: non richiede un tag <script> in piu' in index.html/www e i giocattoli sono parenti
// stretti degli arredi (4 su 14 sono ANCHE arredi piazzabili). Namespace separato apposta:
// PETQ.arredi resta il modulo della casa, PETQ.giocattoli e' il modulo delle azioni.
//
// Catalogo = content/arredi.md sezione GIOCATTOLI -> PETQ.content.data.giocattoli (nome, stanza,
// prezzo, fonte, usiGiorno, effetto {tipo, valore}). Il NOME e' la chiave tecnica (combacia con
// arredi/negozio/reward), a schermo passa sempre da traduci().
// ============================================================================
(function () {

  var traduci = (PETQ.i18n && PETQ.i18n.t) || function (s) { return s; };

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  function giornoDiGioco(state) {
    return (PETQ.clock && PETQ.clock.giornoCorrente) ? PETQ.clock.giornoCorrente(state) : 0;
  }

  // ---------- stato ----------
  // state.giocattoli        : array di NOMI posseduti (acquisto negozio / drop missione)
  // state.giocattoliUsi     : { nome: usiFattiOggi }  (azzerato al nuovo giorno)
  // state.giocattoliUsiGiorno : giorno di gioco a cui si riferisce giocattoliUsi
  // state.giocattoliProg    : { nome: colpiAccumulati } (Cubbolo: PERSISTENTE, mai azzerato dal giorno)
  // state.oracolo           : { responso, giorno } o null (Sfera Sentenziosa, scade a fine giornata)
  // Guardie di FORMA lazy come missions.assicuraStatoMissioni: nessuna migrazione da scrivere in
  // save.js, i salvataggi vecchi si sistemano da soli alla prima chiamata.
  function assicuraStato(state) {
    if (!state) return;
    if (!Array.isArray(state.giocattoli)) state.giocattoli = [];
    if (!state.giocattoliUsi || typeof state.giocattoliUsi !== 'object' || Array.isArray(state.giocattoliUsi)) {
      state.giocattoliUsi = {};
    }
    if (!state.giocattoliProg || typeof state.giocattoliProg !== 'object' || Array.isArray(state.giocattoliProg)) {
      state.giocattoliProg = {};
    }
    if (typeof state.oracolo === 'undefined') state.oracolo = null;
    // reset pigro del contatore usi (stesso principio delle coccole: il reset "vero" lo fa
    // care.dailyLogin, questo copre i percorsi che non ci passano)
    var oggi = giornoDiGioco(state);
    if (state.giocattoliUsiGiorno !== oggi) {
      state.giocattoliUsiGiorno = oggi;
      state.giocattoliUsi = {};
    }
  }

  // Azzeramento esplicito dal nuovo giorno (care.dailyLogin), come gli altri contatori giornalieri.
  function resetGiorno(state) {
    if (!state) return;
    state.giocattoliUsiGiorno = giornoDiGioco(state);
    state.giocattoliUsi = {};
  }

  // ---------- catalogo ----------
  function catalogo() {
    var data = PETQ.content && PETQ.content.data;
    return (data && data.giocattoli) || [];
  }

  function trova(nome) {
    var lista = catalogo();
    for (var i = 0; i < lista.length; i++) {
      if (lista[i] && lista[i].nome === nome) return lista[i];
    }
    return null;
  }

  // Possesso: il giocattolo sta in state.giocattoli OPPURE e' uno dei 4 che sono ANCHE arredi
  // (Palla/Robottino/Trenino/Astronave Giocattolo) e il giocatore ce l'ha in casa (posseduto o
  // piazzato). Decisione del fondatore: "devono essere sempre usabili dal salone" -> NON serve
  // che siano piazzati nella loro stanza.
  function possiede(state, nome) {
    if (!state || !nome) return false;
    assicuraStato(state);
    if (state.giocattoli.indexOf(nome) !== -1) return true;
    var arr = state.arredi;
    if (!arr) return false;
    var poss = arr.posseduti || [];
    for (var i = 0; i < poss.length; i++) { if (poss[i] && poss[i].nome === nome) return true; }
    var piaz = arr.piazzati || {};
    for (var stanza in piaz) {
      if (!Object.prototype.hasOwnProperty.call(piaz, stanza)) continue;
      var lista = piaz[stanza] || [];
      for (var j = 0; j < lista.length; j++) { if (lista[j] && lista[j].nome === nome) return true; }
    }
    return false;
  }

  // Consegna un giocattolo al giocatore (negozio fase 3 / drop missione). I 4 doppi arredo-giocattolo
  // NON vanno duplicati qui: se sono gia' in casa come arredi il possesso c'e' gia'.
  function aggiungi(state, nome) {
    if (!state) return { ok: false, msg: traduci('errore interno') };
    assicuraStato(state);
    if (!trova(nome)) return { ok: false, msg: traduci('Giocattolo sconosciuto.') };
    if (state.giocattoli.indexOf(nome) === -1) state.giocattoli.push(nome);
    return { ok: true, msg: traduci(nome) + traduci(' aggiunto ai giocattoli.') };
  }

  // ---------- usi giornalieri ----------
  function usiFatti(state, nome) {
    assicuraStato(state);
    return state.giocattoliUsi[nome] || 0;
  }

  // null = illimitati, -1 = passivo (non si "usa"), altrimenti quanti ne restano oggi
  function usiRimasti(state, nome) {
    var g = trova(nome);
    if (!g) return 0;
    if (g.usiGiorno === 'passivo') return -1;
    if (g.usiGiorno === null) return null;
    return Math.max(0, g.usiGiorno - usiFatti(state, nome));
  }

  function segnaUso(state, nome) {
    assicuraStato(state);
    state.giocattoliUsi[nome] = usiFatti(state, nome) + 1;
  }

  // ---------- descrizioni a schermo ----------
  // NIENTE SPOILER (regola sacra): il Cubbolo non dice quanti usi mancano al premio.
  function descrizione(g) {
    if (!g || !g.effetto) return traduci('Non fa niente di che.');
    var e = g.effetto;
    if (e.tipo === 'felicita') return traduci('Ci gioca insieme: Felicita +') + e.valore;
    if (e.tipo === 'consola') return traduci('Consola il pet giu\' di morale: Felicita +12, ma solo se sta male');
    if (e.tipo === 'decrescente') return traduci('Diverte sempre meno: Felicita +8, poi +4, poi +2');
    if (e.tipo === 'cura_stato') return traduci('Medica il pet: Ferite -25');
    if (e.tipo === 'consiglio') return traduci('Un consiglio non richiesto sul punto debole del pet: Felicita +3');
    if (e.tipo === 'oracolo') return traduci('Un responso sul futuro, vale fino a fine giornata');
    if (e.tipo === 'duello') return traduci('Duello: Energia -10, in cambio monete');
    if (e.tipo === 'progressione') return traduci('Un rompicapo. Prima o poi succede qualcosa.');
    if (e.tipo === 'notturno_monete') return traduci('Passivo: al risveglio del mattino trovi monete');
    if (e.tipo === 'sveglia_gratis') return traduci('Passivo: svegliare il pet non costa piu\' Energia');
    return traduci('Non fa niente di che.');
  }

  // elencoUsabili: i giocattoli POSSEDUTI, nell'ordine del catalogo, gia' pronti per il menu.
  // { nome, stanza, effetto, descrizione, passivo, illimitato, usiGiorno, usiRimasti, disponibile }
  function elencoUsabili(state) {
    if (!state) return [];
    assicuraStato(state);
    var lista = catalogo();
    var out = [];
    for (var i = 0; i < lista.length; i++) {
      var g = lista[i];
      if (!g || !g.effetto) continue; // riga con refuso nel file: niente motore, niente menu
      if (!possiede(state, g.nome)) continue;
      var passivo = (g.usiGiorno === 'passivo');
      var illimitato = (g.usiGiorno === null);
      var rimasti = usiRimasti(state, g.nome);
      out.push({
        nome: g.nome,
        stanza: g.stanza,
        effetto: g.effetto,
        descrizione: descrizione(g),
        passivo: passivo,
        illimitato: illimitato,
        usiGiorno: g.usiGiorno,
        usiRimasti: rimasti,
        disponibile: !passivo && (illimitato || rimasti > 0)
      });
    }
    return out;
  }

  // ---------- ORACOLO (Sfera Sentenziosa) ----------
  // I 6 responsi e i loro effetti sono scritti in content/arredi.md sotto la tabella dei
  // giocattoli. Due sono IMMEDIATI (felicita), due valgono per tutta la GIORNATA DI GIOCO
  // (monete dalle missioni), due valgono sulla PROSSIMA missione e si consumano quando arriva.
  var ORACOLO_RESPONSI = [
    { chiave: 'certamente',  testo: 'Certamente',                     durata: 'giornata',  monetePerc: 25 },
    { chiave: 'deciso',      testo: 'E\' deciso',                     durata: 'missione',  sogliaSuper: 3 },
    { chiave: 'domani',      testo: 'Chiedimelo domani',              durata: 'immediato', felicita: -2 },
    { chiave: 'noncontarci', testo: 'Non ci contare',                 durata: 'giornata',  monetePerc: -10 },
    { chiave: 'prospettive', testo: 'Le prospettive non sono buone',  durata: 'missione',  energiaMissione: 5 },
    { chiave: 'segni',       testo: 'Segni positivi',                 durata: 'immediato', felicita: 5 }
  ];

  function responsoPerChiave(chiave) {
    for (var i = 0; i < ORACOLO_RESPONSI.length; i++) {
      if (ORACOLO_RESPONSI[i].chiave === chiave) return ORACOLO_RESPONSI[i];
    }
    return null;
  }

  // Responso ancora valido (stessa giornata di gioco) oppure null. Scaduto -> pulisce lo stato.
  function oracoloAttivo(state) {
    if (!state || !state.oracolo) return null;
    if (state.oracolo.giorno !== giornoDiGioco(state)) {
      state.oracolo = null;
      return null;
    }
    return responsoPerChiave(state.oracolo.responso);
  }

  // Moltiplicatore monete-missione dal responso del giorno (1 = nessun effetto).
  function moltMoneteMissione(state) {
    var r = oracoloAttivo(state);
    if (!r || !r.monetePerc) return 1;
    return 1 + (r.monetePerc / 100);
  }

  // Quanto scende la soglia dei super della PROSSIMA missione (0 = niente).
  function scontoSogliaSuper(state) {
    var r = oracoloAttivo(state);
    return (r && r.sogliaSuper) ? r.sogliaSuper : 0;
  }

  // Energia extra che costa la PROSSIMA missione (0 = niente).
  function energiaExtraMissione(state) {
    var r = oracoloAttivo(state);
    return (r && r.energiaMissione) ? r.energiaMissione : 0;
  }

  // Consuma il responso se era di quelli "sulla prossima missione" (chiamata da missions.risolvi).
  function consumaOracoloMissione(state) {
    var r = oracoloAttivo(state);
    if (r && r.durata === 'missione') state.oracolo = null;
    return !!(r && r.durata === 'missione');
  }

  // ---------- numeri degli effetti (regole del MOTORE, non contenuto: restano qui) ----------
  var CONSOLA_SOGLIA = 30;       // sopra questa Felicita il pet rifiuta di farsi consolare
  var CONSOLA_FELICITA = 12;
  var DECRESCENTE = [8, 4, 2];   // 1o uso del giorno, 2o, dal 3o in poi
  var CURA_STATO_FERITE = 25;
  var CONSIGLIO_FELICITA = 3;
  var DUELLO_ENERGIA_MIN = 15;   // sotto questa Energia il pet rifiuta il duello
  var DUELLO_ENERGIA_COSTO = 10;
  var DUELLO_MONETE_MIN = 8;
  var DUELLO_MONETE_MAX = 15;
  var PROGRESSIONE_INT = 3;      // Intelligenza permanente quando la barra nascosta si riempie

  var STAT_RPG = ['forza', 'intelligenza', 'velocita', 'carisma'];
  // Etichette a schermo: le chiavi del dizionario i18n sono quelle con l'ACCENTO ('Velocità'),
  // v. i18n.js — scriverle senza accento qui le lascerebbe in italiano in inglese.
  var STAT_LABEL = { forza: 'Forza', intelligenza: 'Intelligenza', velocita: 'Velocità', carisma: 'Carisma' };

  // ---------- rifiuti "simpatici": nessun uso bruciato a vuoto ----------
  // Regola (28 lug 2026): se l'effetto NON cambierebbe niente, il giocattolo si rifiuta con una
  // battuta e l'uso del giorno resta intatto — esattamente come facevano gia' 'consola' (pet di
  // ottimo umore) e 'duello' (pet a pezzi). Prima invece la Cartuccia Soffiona con Ferite a 0 e
  // la Palla con Felicita a 100 si consumavano dando zero.
  var FELICITA_MAX = 100;

  function felicitaAlMassimo(stats) {
    var f = (stats && typeof stats.felicita === 'number') ? stats.felicita : 0;
    return f >= FELICITA_MAX;
  }

  function rifiutoFelicitaPiena(nomePet) {
    return {
      ok: false,
      msg: nomePet + traduci(' è già al settimo cielo: più contento di così si romperebbe.'),
      rifiutato: true
    };
  }

  // Vero se le stat RPG NON sono tutte uguali, cioe' esiste davvero un punto debole da rivelare.
  function haPuntoDebole(pet) {
    var vMin = Infinity;
    var vMax = -Infinity;
    for (var i = 0; i < STAT_RPG.length; i++) {
      var v = (pet && pet.rpg && typeof pet.rpg[STAT_RPG[i]] === 'number') ? pet.rpg[STAT_RPG[i]] : 0;
      if (v < vMin) vMin = v;
      if (v > vMax) vMax = v;
    }
    return vMax > vMin;
  }

  // ---------- usa(): applica l'effetto di un giocattolo ----------
  // Ritorna sempre { ok, msg, ... }. Su ok:false NON consuma l'uso (rifiuti "simpatici").
  // Campi extra secondo l'effetto: felicita, ferite, monete, energia, stat, responso, scenetta.
  function usa(state, nome) {
    if (!state || !state.pet) return { ok: false, msg: traduci('errore interno') };
    assicuraStato(state);

    // Stesse guardie delle altre azioni di cura (v. care.train/studioVeloce): un pet che dorme,
    // che e' in missione o a passeggio non e' li' a giocare. Difensivo anche per la UI (fase 3):
    // il menu non deve nemmeno aprirsi in quei casi, ma il motore non ci casca comunque.
    // ALLINEATE a ui.petOccupatoPerGioco, che blocca ANCHE gioco e allenamento in corso: se il
    // motore non li elencasse, un uso passato da un'altra via (debug, chiamata diretta) sfuggirebbe
    // al blocco che la UI applica invece sempre.
    if (state.sonno) return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' sta dormendo.') };
    if (state.missione) return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' è in missione.') };
    if (state.passeggiata) return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' non è in casa.') };
    if (state.gioco) return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' sta già giocando: una cosa alla volta.') };
    if (state.allenamento) return { ok: false, msg: (state.pet.nome || traduci('Il pet')) + traduci(' si sta allenando: non è aria di giochi.') };

    var g = trova(nome);
    if (!g || !g.effetto) return { ok: false, msg: traduci('Questo giocattolo non fa niente.') };
    if (!possiede(state, nome)) return { ok: false, msg: traduci('Non hai questo giocattolo.') };
    if (g.usiGiorno === 'passivo') {
      return { ok: false, msg: traduci('Funziona da solo, non c\'e\' niente da fare.') };
    }
    var rimasti = usiRimasti(state, nome);
    if (rimasti !== null && rimasti <= 0) {
      return { ok: false, msg: traduci('Per oggi basta, torna domani.') };
    }

    var pet = state.pet;
    var stats = pet.stats || {};
    var tipo = g.effetto.tipo;
    var valore = g.effetto.valore || 0;
    var nomePet = pet.nome || traduci('Il pet');
    var res = { ok: true, msg: '', giocattolo: nome };

    if (tipo === 'felicita') {
      if (felicitaAlMassimo(stats)) return rifiutoFelicitaPiena(nomePet);
      stats.felicita = clamp((stats.felicita || 0) + valore, 0, 100);
      res.felicita = valore;
      res.msg = nomePet + traduci(' si diverte: Felicita +') + valore + '.';

    } else if (tipo === 'consola') {
      // +12 Felicita SOLO se sta davvero male: sopra soglia il pet snobba il giocattolo e
      // l'uso NON viene consumato (rifiuto, non fallimento). La soglia (30) e' ben sotto 100,
      // quindi copre da sola anche il caso "Felicita gia' piena".
      if ((stats.felicita || 0) >= CONSOLA_SOGLIA) {
        return {
          ok: false,
          msg: nomePet + traduci(' e\' gia\' di ottimo umore e lo guarda con sufficienza.'),
          rifiutato: true
        };
      }
      stats.felicita = clamp((stats.felicita || 0) + CONSOLA_FELICITA, 0, 100);
      res.felicita = CONSOLA_FELICITA;
      res.msg = nomePet + traduci(' si consola un po\': Felicita +') + CONSOLA_FELICITA + '.';

    } else if (tipo === 'decrescente') {
      // +8 al primo uso del giorno, +4 al secondo, +2 dal terzo in poi (usi illimitati)
      if (felicitaAlMassimo(stats)) return rifiutoFelicitaPiena(nomePet);
      var giaFatti = usiFatti(state, nome);
      var guadagno = (giaFatti === 0) ? DECRESCENTE[0] : (giaFatti === 1 ? DECRESCENTE[1] : DECRESCENTE[2]);
      stats.felicita = clamp((stats.felicita || 0) + guadagno, 0, 100);
      res.felicita = guadagno;
      res.msg = nomePet + traduci(' ci gioca: Felicita +') + guadagno + '.';

    } else if (tipo === 'cura_stato') {
      var prima = (typeof state.ferite === 'number') ? state.ferite : 0;
      // Niente da curare: la Cartuccia e' a uso singolo giornaliero, bruciarla su un pet
      // integerrimo era il modo piu' rapido di restare senza medicine il giorno che servono.
      if (prima <= 0) {
        return {
          ok: false,
          msg: nomePet + traduci(' non ha nemmeno un graffio: la medicina resta nella scatola.'),
          rifiutato: true
        };
      }
      state.ferite = clamp(prima - CURA_STATO_FERITE, 0, 100);
      if (PETQ.pet && PETQ.pet.recomputeSalute) PETQ.pet.recomputeSalute(pet, state);
      res.ferite = state.ferite - prima;
      res.msg = nomePet + traduci(' si medica: Ferite ') + res.ferite + '.';

    } else if (tipo === 'consiglio') {
      // "Non c'e' nulla da dire" = il consiglio non cambierebbe NIENTE: niente Felicita da dare
      // (gia' al massimo) E nessun punto debole da rivelare (stat RPG tutte pari). Se anche solo
      // una delle due cose e' vera, l'uso vale e si consuma normalmente.
      var debole = statPiuBassa(pet);
      if (felicitaAlMassimo(stats) && !haPuntoDebole(pet)) {
        return {
          ok: false,
          msg: nomePet + traduci(' è perfetto e lo sa: nessun consiglio da dare oggi.'),
          rifiutato: true
        };
      }
      stats.felicita = clamp((stats.felicita || 0) + CONSIGLIO_FELICITA, 0, 100);
      res.felicita = CONSIGLIO_FELICITA;
      res.stat = debole;
      res.msg = traduci('Il consiglio del giorno: lavora sulla tua ') + traduci(STAT_LABEL[res.stat] || res.stat) +
        traduci(', e\' il tuo punto debole.');

    } else if (tipo === 'oracolo') {
      var responso = (PETQ.rng && PETQ.rng.pick) ? PETQ.rng.pick(ORACOLO_RESPONSI) : ORACOLO_RESPONSI[0];
      state.oracolo = { responso: responso.chiave, giorno: giornoDiGioco(state) };
      if (responso.felicita) {
        stats.felicita = clamp((stats.felicita || 0) + responso.felicita, 0, 100);
        res.felicita = responso.felicita;
      }
      res.responso = responso.chiave;
      res.msg = traduci('La sfera dice: "') + traduci(responso.testo) + '".';

    } else if (tipo === 'duello') {
      if ((stats.energia || 0) < DUELLO_ENERGIA_MIN) {
        return {
          ok: false,
          msg: nomePet + traduci(' e\' troppo a pezzi per menare le mani.'),
          rifiutato: true
        };
      }
      var monete = (PETQ.rng && PETQ.rng.randInt) ? PETQ.rng.randInt(DUELLO_MONETE_MIN, DUELLO_MONETE_MAX) : DUELLO_MONETE_MIN;
      stats.energia = clamp((stats.energia || 0) - DUELLO_ENERGIA_COSTO, 0, 100);
      state.coins = (state.coins || 0) + monete;
      res.energia = -DUELLO_ENERGIA_COSTO;
      res.monete = monete;
      res.msg = nomePet + traduci(' vince il duello: +') + monete + traduci(' monete, Energia -') + DUELLO_ENERGIA_COSTO + '.';

    } else if (tipo === 'progressione') {
      // Barra NASCOSTA (regola sacra niente-spoiler): il giocatore non sa quanto manca.
      var soglia = valore > 0 ? valore : 7;
      var conta = (state.giocattoliProg[nome] || 0) + 1;
      if (conta >= soglia) {
        state.giocattoliProg[nome] = 0;
        // Tetto per stadio (bilanciamento.md "Tetto delle statistiche per stadio"): passa dal
        // cancello unico PETQ.pet.aggiungiStat; il messaggio usa il valore REALMENTE applicato.
        var applicatoProgressione = 0;
        if (pet.rpg && typeof pet.rpg.intelligenza === 'number') {
          applicatoProgressione = PETQ.pet.aggiungiStat(pet, 'intelligenza', PROGRESSIONE_INT);
        }
        res.stat = 'intelligenza';
        res.statValore = applicatoProgressione;
        res.scenetta = true; // la UI (fase 3) fa partire la scenetta del pet che risolve il cubo
        res.msg = nomePet + traduci(' risolve il rompicapo! Intelligenza +') + applicatoProgressione + '.';
      } else {
        state.giocattoliProg[nome] = conta;
        res.scenetta = false;
        res.msg = nomePet + traduci(' ci smanetta un po\'.');
      }

    } else {
      // vocabolario chiuso: qui non si arriva se il parser ha fatto il suo lavoro
      return { ok: false, msg: traduci('Questo giocattolo non fa niente.') };
    }

    segnaUso(state, nome);
    if (PETQ.pet && PETQ.pet.recomputeSalute) PETQ.pet.recomputeSalute(pet, state);
    res.usiRimasti = usiRimasti(state, nome);
    return res;
  }

  // Stat RPG piu' bassa del pet (a parita' vince l'ordine forza/int/vel/carisma, come statMax
  // in missions.applicaRewardToken ma al contrario). Usa le stat BASE: il consiglio parla del
  // pet, non dell'equipaggiamento che ha addosso in questo momento.
  function statPiuBassa(pet) {
    var migliore = STAT_RPG[0];
    var vMin = Infinity;
    for (var i = 0; i < STAT_RPG.length; i++) {
      var v = (pet && pet.rpg && typeof pet.rpg[STAT_RPG[i]] === 'number') ? pet.rpg[STAT_RPG[i]] : 0;
      if (v < vMin) { vMin = v; migliore = STAT_RPG[i]; }
    }
    return migliore;
  }

  // ---------- effetti PASSIVI (nessun uso, basta possederli) ----------
  // Peluffo Ciarliero ('notturno_monete'): monete al risveglio del MATTINO (v. pet.risolviRisveglio).
  function moneteRisveglio(state) {
    if (!state) return 0;
    var lista = catalogo();
    var somma = 0;
    for (var i = 0; i < lista.length; i++) {
      var g = lista[i];
      if (!g || !g.effetto || g.effetto.tipo !== 'notturno_monete') continue;
      if (possiede(state, g.nome)) somma += (g.effetto.valore || 0);
    }
    return somma;
  }

  // Pescione Cantautore ('sveglia_gratis'): svegliare il pet prima del tempo non costa Energia.
  function svegliaSenzaPenalita(state) {
    if (!state) return false;
    var lista = catalogo();
    for (var i = 0; i < lista.length; i++) {
      var g = lista[i];
      if (!g || !g.effetto || g.effetto.tipo !== 'sveglia_gratis') continue;
      if (possiede(state, g.nome)) return true;
    }
    return false;
  }

  window.PETQ.giocattoli = {
    elencoUsabili: elencoUsabili,
    usa: usa,
    possiede: possiede,
    aggiungi: aggiungi,
    catalogo: catalogo,
    trova: trova,
    descrizione: descrizione,
    usiRimasti: usiRimasti,
    resetGiorno: resetGiorno,
    // passivi
    moneteRisveglio: moneteRisveglio,
    svegliaSenzaPenalita: svegliaSenzaPenalita,
    // oracolo (letti da missions.js)
    oracoloAttivo: oracoloAttivo,
    moltMoneteMissione: moltMoneteMissione,
    scontoSogliaSuper: scontoSogliaSuper,
    energiaExtraMissione: energiaExtraMissione,
    consumaOracoloMissione: consumaOracoloMissione,
    _responsi: ORACOLO_RESPONSI,
    _statPiuBassa: statPiuBassa,
    _haPuntoDebole: haPuntoDebole,
    _assicuraStato: assicuraStato,
    _consolaSoglia: CONSOLA_SOGLIA,
    _duelloEnergiaMin: DUELLO_ENERGIA_MIN,
    _decrescente: DECRESCENTE
  };

})();
