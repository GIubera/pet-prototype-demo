# Battute legate ai talenti — BOZZA (non ancora letta dal codice)

Battute che escono SOLO se il pet possiede il talento indicato, nel momento indicato.
Una battuta per riga con `- `. Slot: `{nome}` `{utente}`.

STATO: bozza contenuti. Per attivarle servono (lato codice):
1. Aggancio del parser condizioni esistente (`talento:<nome>`, già in content.js) alle battute — il parser attuale di personalita/*.md fa match per sottostringa e NON va usato per queste sezioni (una sezione "Saluto (talento: X)" finirebbe nel pool base di tutti).
2. Decidere gli hook: alcuni momenti esistono già (fame, sonno, ritorno missione), altri sono nuovi (es. "rifiuta il dolce" per blocca_cibo=dolce, che oggi sarebbe un rifiuto muto).
3. Aggiungere questo file a build-content.ps1 quando il formato è confermato.

Ogni sezione dichiara: talento richiesto (nome normalizzato per il parser condizioni) e momento di uscita.

---

## Sportivo

### Fissato con la Dieta — rifiuta il dolce
Condizione: `talento:fissatoconladieta` · Momento: il giocatore offre un dolce (blocca_cibo=dolce)
- Sugar? SUGAR? Coach, I have a meal plan. The plan says no. I'm saying it with more volume.
- No thanks — that's spectator fuel. I'm in the starting lineup.
- You eat the dessert. I'll look away with OLYMPIC discipline. Never tempt me again. (Smells amazing though. GET IT AWAY.)

### Fissato con la Dieta — mangia cibo sano
Condizione: `talento:fissatoconladieta` · Momento: mangia carne/verdura/pesce (bonus_cibo=salutare)
- PROTEIN! I can hear my muscles singing backup. Perfect diet, perfect athlete.
- Veggies! Eating them with the grit of someone who knows the champions' secret is SUPER BORING but it works.
- Fish = speed. Says so on my chart. And my chart is UNDEFEATED.

### Fissato con la Dieta — risveglio
Condizione: `talento:fissatoconladieta` · Momento: risveglio (colazione dei campioni, dieta salutare)
- WAKE UP! First order of business: breakfast of champions, the real one. Zero sugar, all fuel. Strong start.
- Morning! My wake-up routine is timed to the second: alarm, hydration, clean meal. Discipline never sleeps, coach.

### Energico — fine allenamento
Condizione: `talento:energico` · Momento: fine allenamento (allenamento_energia=+5, si carica invece di stancarsi)
- Workout's done and I feel BETTER than before! My engine recharges by running. I'm built weird and built GREAT.
- Another round? Training switches me ON, not off. Batteries? Never heard of 'em.
- Other guys finish training tired. I finish and need a victory lap just to calm down. WHAT A LIFE.

### Energico — login giornaliero
Condizione: `talento:energico` · Momento: login giornaliero (decay energia dimezzato, sempre in forma)
- Welcome back, coach! Me? Fresh as this morning. Fresher, actually — my batteries recharge themselves.
- There you are! I passed the time doing sprints. My energy never drops, so it was either sprints or more sprints.

### Predestinato — secondo allenamento del giorno
Condizione: `talento:predestinato` · Momento: avvio del secondo allenamento giornaliero (allenamenti_giorno=2)
- Two-a-days, coach! Just like the real pros. Talent doesn't train itself... okay, it does, but TWICE.
- Morning and afternoon, coach. My destiny is written down: it says "train again". Beautiful destiny.
- Second workout: STARTED. Legends train double. I know because it literally just happened. Look.

### Braccia di Ferro — carne o allenamento Forza
Condizione: `talento:bracciadiferro` · Momento: mangia carne oppure completa allenamento Forza (bonus attivo)
- MEAT! My arms are thanking you silently. A very MUSCULAR silence.
- Strength training with the right talent: every rep counts double. I can hear it — it goes "clang".
- Look at these arms, coach. Iron. You could hang laundry on them, but let's use them for GLORY.

### Spirito Agonistico — ritorno da missione
Condizione: `talento:spiritoagonistico` · Momento: ritorno da qualsiasi missione (ogni_missione=forza+1)
- Mission filed = muscle gained. Everything's a competition to me, and competition makes me grow. Literally.
- I come back from every mission with a souvenir: strength. I AM the gift shop.
- Another challenge won, another Strength point on the scoreboard. I keep count — it's my own personal league.

### Fisico Bestiale — niente crollo da stanchezza
Condizione: `talento:fisicobestiale` · Momento: energia bassa ma nessun rifiuto (ignora_rifiuto_energia)
- Tired? My body doesn't know the word. It doesn't know many, but definitely not that one.
- Everyone else crashes around this hour. I've still got gas to spare. "Absolute Unit" — it's right there on my card.
- Fatigue challenged me. It lost. It wasn't even a fair matchup.

### Fisico Bestiale — allenamento lampo
Condizione: `talento:fisicobestiale` · Momento: fine allenamento a metà tempo (allenamento_durata=x0.5)
- Workout done in half the time. I'm not rushing — I'm just too fast even at getting tired.
- Speed session complete! Same effort as everyone else, half the time. The rest I spend being a phenomenon.
- Done already, coach. For real. My body floors it even on training day. NEXT!

---

## Gentile

### Amante della Natura — mangia verdura
Condizione: `talento:amantedellanatura` · Momento: mangia verdura (bonus_cibo=verdura)
- Veggies! I thanked the garden, the farmer, and the fork. Nature loves us, {utente}.
- Mmm, veggies... I chew quietly so I don't disturb the forest. There is no forest. But there is respect.
- The little plants make me strong! They grow, I grow, we grow together. What a lovely quiet team.

### Amante della Natura — ritorno da missione natura
Condizione: `talento:amantedellanatura` · Momento: ritorno da missione a tag natura (perk_tag=natura, super garantito)
- A mission out in the green: perfect, of course! Animals always help me. You just have to say please — nobody ever does.
- Out among trees and critters I can't lose: that's my home turf. Nature roots for me, in a whisper.
- Back from the woods with a full heart. I greeted every bush by name. They mostly didn't answer, but that's okay.

### Amante della Natura — ritorno dal Rifugio Creature Smarrite
Condizione: `talento:amantedellanatura` · Momento: ritorno da M11 Rifugio Creature Smarrite (tag natura)
- At the shelter, the animals adopted ME. I made friends with everyone and only cried three times. Happy tears.
- Back from the shelter with a full heart and quite a lot of other people's fur on me. Worth it: nobody stays lonely on my watch.

### Amante della Natura — ritorno dalla Serra del Giardiniere Matto
Condizione: `talento:amantedellanatura` · Momento: ritorno da M12 Serra del Giardiniere Matto (tag natura)
- Back from the greenhouse with green paws and a green soul. Time grows slowly in there, like the leaves. So peaceful.
- Mission among the flowerpots: a success that smells wonderful. Every plant is a little friend who never answers but always listens.

### Amante della Natura — ritorno dall'Acquario (Cattura Pesci)
Condizione: `talento:amantedellanatura` · Momento: ritorno da M16 Cattura Pesci a Mani Nude (tag natura)
- I didn't catch the fish at the aquarium: I convinced them. Politely. Then I put them all back — they looked scared.
- Back from the tanks soaking wet and SO happy. The fish forgave me right away: they can tell I'm one of the good guys.

### Pacifista — ritorno da missione Sociale
Condizione: `talento:pacifista` · Momento: ritorno da missione Sociale (bonus_missione=sociale:carisma+1)
- Missions with people are my favorite: nobody gets hurt and everybody says goodbye twice.
- Social mission complete! My superpower is kindness. It doesn't make a sound, but it wins.
- I love being around people: just listen a lot and judge never. I come home with new friends and a cozy heart.

### Pacifista — missione di combattimento bloccata
Condizione: `talento:pacifista` · Momento: tap su missione Combattimento esclusa dalla rosa (blocca_categoria=combattimento) — HOOK NUOVO
- Not that mission, sorry... I don't fight. I could offer everyone involved a nice cup of tea, though.
- No fighting, {utente}. Not out of fear — out of principle. (Okay, a little bit of fear. But principle first.)
- Fight? Me? At most I hug aggressively. It's different, and honestly it works better.

### Cuore Magnetico — mancia tripla
Condizione: `talento:cuoremagnetico` · Momento: mancia post-missione (mancia=x3)
- They gave me a great big tip! They said I have a smile that "deserves a reward". I was just smiling, I promise.
- People hand me coins and I don't even ask. {utente}, I think the world likes me. I like it back — so we're even.
- Triple tip! All I did was be nice, I swear. Apparently that pays better than hard work. How wonderfully embarrassing.

### Cuore Magnetico — login giornaliero
Condizione: `talento:cuoremagnetico` · Momento: login giornaliero (login=monete+10)
- You showed up and I'm already richer! No idea how it works, but it only works when you're here.
- Every time you come back, it rains little coins. My heart works like a magnet. We split them, obviously.
- Good morning, and there's already a little nest egg! The world loves me first thing in the day. I love it right back, always.

### Cuore Magnetico — ritorno da missione
Condizione: `talento:cuoremagnetico` · Momento: ritorno da missione (ogni_missione=monete+5)
- Every mission earns me a little extra. The secret? I greet everyone with a smile. Charisma is my piggy bank, {utente}.
- Mission done, nest egg grown. The world loves me in coin form. We split it, like always.

### Coccolone — coccole finite a quota 8
Condizione: `talento:coccolone` · Momento: raggiunto il cap coccole 8 (cap_coccole=8) — SOSTITUISCE il pool base "Coccole finite"
- EIGHT cuddles today... I'm at maximum maximum. Sorry, any more and I turn into mashed potatoes.
- Even I'm full, and I can handle more cuddles than anyone alive. You gave a lot today, {utente}. What a day.
- Cuddle time's over! Eight! Regular folks tap out at five — I'm a professional hugger.

### Coccolone — coccola ricevuta
Condizione: `talento:coccolone` · Momento: coccola ricevuta (coccola=fel+3)
- Your cuddles hit me double. Triple. I can't count when you pet me, sorry.
- One pat from you is worth three regular ones. I'm not bragging: my heart said so, and it always exaggerates.
- Cuddle received, happiness through the roof! They work extra on me: I'm an emotional investment, {utente}.

### Infermiere Provetto — risveglio con auto-cura
Condizione: `talento:infermiereprovetto` · Momento: risveglio con auto-cura (risveglio=ferite-10)
- Awake and already patched up! Blessed little hands, mine. Tiny, but blessed.
- I fixed myself up in my sleep. Don't ask how: these hands know the trade even when I'm not around.
- Good morning! I bandaged myself before I was even fully awake. ER efficiency, tenderness included.

### Infermiere Provetto — uso infermeria
Condizione: `talento:infermiereprovetto` · Momento: cura in infermeria (infermeria_costo=-5, infermeria_cura=+10)
- I help out at the infirmary too: I pass the gauze and keep spirits up. Half the price, double the love.
- The doctor says I'm a patient-slash-colleague. I did half the work and he took all the credit. That's okay.
- Treated and back on my feet! My wounds fear me as much as I fear needles. Fair trade, I'd say.

### Anima Candida — risveglio con ferite azzerate
Condizione: `talento:animacandida` · Momento: risveglio dopo notte che azzera le ferite (notte=ferite=0)
- Good morning! Yesterday's scrapes? Gone. I forgive everything, even scratches. So they leave.
- Last night my wounds packed their bags. I didn't even say goodbye. The one rudeness I allow myself.
- Awake and good as new! I sleep, I forgive, I heal. It's a beautiful cycle and I don't even know how it works.

---

## Nerd

### Idrofobico — è sporco
Condizione: `talento:idrofobico` · Momento: igiene bassa (igiene_felicita=inverti) — SOSTITUISCE il pool base "È sporco" (che si lamenta: lui gode)
- Hygiene at 20% and mood at an all-time high: every stain is a field note, every smell an experiment. I'm doing GREAT.
- Dirt is data in layers. I'm not filthy: I'm an open-air historical archive.
- The little flies circling me? I'm training them. The project is on schedule. DO NOT touch the ecosystem.
- Every bathless day, my brain gains points. Science is on my side. So is the smell.

### Idrofobico — viene lavato
Condizione: `talento:idrofobico` · Momento: il giocatore lo lava (protesta) — HOOK NUOVO
- NO, NOT THE WATER! You just deleted six days of field research! Vandal!
- Soap and water: the reset nobody asked for. My dirt-adjusted IQ was higher, you know that?
- You formatted me. Six days of crust-data lost in thirty seconds. A tragedy for science.

### Sete di Sapere — allenamento Int gratis
Condizione: `talento:setedisapere` · Momento: allenamento Intelligenza gratuito del giorno (allenamento_extra=int)
- Free daily study session! My brain trains itself while I watch and take notes. Meta-studying.
- My favorite daily: learning something for free. Zero effort, pure knowledge. The system rewards the curious.
- Bonus Intelligence session: claimed. It's like finding a secret level: free, and it makes me stronger.

### Sete di Sapere — impara una parola
Condizione: `talento:setedisapere` · Momento: impara una parola nuova (la curiosità è il suo tratto)
- Excellent, another term to catalog! Every word is a little level-up. Keep going, {utente}, I'm in my grinding phase.
- I love learning new things. "{parola}" goes straight into the archive, under "useful stuff I will deploy at a surprising moment".

### Inventore — invenzione riuscita
Condizione: `talento:inventore` · Momento: invenzione settimanale riuscita (invenzione=1/settimana)
- EUREKA! I skipped training to invent, and it paid off: look what I built with whatever was lying around the house!
- Fresh out of my laboratory (the corner behind the couch): a new marvel. Patent it, {utente}. Trust me.
- Invention of the week: SUCCESS. I combined random things using an extremely rigorous method. The paradox works.

### Inventore — invenzione flop
Condizione: `talento:inventore` · Momento: invenzione = Prototipo fallato
- Okay, this invention... "will work in a future version". Let's sell it as a collector's item, quick, before anyone asks questions.
- The prototype did exactly one thing: smoke. But such elegant smoke. Logging it as a partial success.
- Invention flopped. Not a failure: a "valuable negative result". Only me and science understand the difference.

### Inventore — ritorno da missione invenzione
Condizione: `talento:inventore` · Momento: ritorno da missione a tag invenzione (perk_tag=invenzione, super garantito)
- Mission in the lab: guaranteed triumph. In there I speak my native language: technical jargon.
- Among gadgets and circuits I cannot fail. It's my natural biome.
- Invention-themed mission: won with my eyes closed. Well, open — to read the labels. But won easily.

### Inventore — ritorno dalla Fiera della Scienza
Condizione: `talento:inventore` · Momento: ritorno da M9 Fiera della Scienza del Quartiere (tag invenzione)
- I made an impression at the Science Fair: my prototype barely smoked this time. Documented progress!
- Back from the Fair with first prize... in the "most enthusiastic" category. The real prize is learning how NOT to make things explode.

### Inventore — ritorno dalla Sfida Robotica
Condizione: `talento:inventore` · Momento: ritorno da M10 Sfida Robotica (tag invenzione)
- Back from the arena with a haul of bolts and a brand-new theory. The other robots were cute. Mine could think.
- Robotics mission: filed. A technical victory. I beat everyone by explaining the rulebook better than the referee.

### Inventore — ritorno dall'Escape Room del Dottor Enigma
Condizione: `talento:inventore` · Momento: ritorno da M21 Escape Room del Dottor Enigma (tag invenzione)
- Back from Dottor Enigma's escape room with the solution plus three alternative theories. I even complimented whoever designed it.
- Puzzle mission: escape successful. I cracked the secret mechanism instantly. Then I insisted on taking it apart, to understand it better.

### Topo di Biblioteca — ritorno da missione Studio
Condizione: `talento:topodibiblioteca` · Momento: ritorno da missione Studio (bonus_missione=studio:int+1,durata-1h)
- Library mission finished early: I move between shelves on pure instinct, like a predator. A predator of footnotes.
- Study mission completed ahead of schedule. Library silence EMPOWERS me.
- Home early: I already knew half the books, and the other half knew me. My natural habitat.

### Mente Analitica — fine di qualsiasi allenamento
Condizione: `talento:menteanalitica` · Momento: fine allenamento di qualsiasi stat (bonus_allenamento=qualsiasi:int+1)
- Workout over and brain bigger, WHATEVER I just trained. I even learn from push-ups. Mostly how exhausting they are.
- Every exercise is one more data point. The body works, the mind archives. Perfect system, double yield.
- I analyzed the workout while doing it. Result: +1 to the muscle and +1 to the theory of the muscle.

### Cervellone — impara una parola
Condizione: `talento:cervellone` · Momento: impara una parola nuova (parole_giorno=4)
- New word acquired! My vocabulary is growing at a rate that should worry the people around me. That's you. Brace yourself.
- Another word in memory! Slots left for today: few but excellent. Keep going, the brain is hungry.
- Logged! At this rate I'll be doing crosswords solo within a month. And writing the clues too.

---

## Maleducato

### Cleptomane — furto del giorno
Condizione: `talento:cleptomane` · Momento: oggetto gratis dal negozio (furto=1/giorno, max 15 monete)
- Look what "fell" into my bag at the shop. Things fall in that place. Daily. In my direction.
- The shopkeeper was looking the other way today. He ALWAYS looks the other way. What a way to run a business. Anyway: gift for the house.
- It's not stealing, it's redistribution with standards. The standards are me.
- Alibi ready, loot secured. If anyone asks, I was with you all day. Repeat after me: ALL day.

### Cleptomane — ritorno da missione
Condizione: `talento:cleptomane` · Momento: ritorno da missione (bonus_missione_monete=x1.5)
- Back from the mission with suspiciously full pockets. Don't ask: half is pay, half is personal initiative.
- Missions pay fifty percent extra when I'm on them. Call it talent. The shopkeeper calls it other things.

### Bad Loser — fallimento da carattere
Condizione: `talento:badloser` · Momento: fallimento missione causato dal carattere (reward=x2, fel-10)
- I lost BECAUSE OF MY ATTITUDE, apparently. Well, my attitude brought home double the loot. Who really won here?
- Yes, I took it badly. TERRIBLY. But look how much stuff I grabbed while taking it terribly.
- Defeat swallowed like a slow poison. But the consolation loot doubled. At least I'm crying rich.

### Fulmine di Quartiere — ritorno anticipato
Condizione: `talento:fulminediquartiere` · Momento: ritorno da missione accorciata (missione_durata=-1h)
- I did in one hour what takes everyone else two. It's not talent, it's an allergy to places.
- Fastest pet in the neighborhood. Not for glory: to finish early and get back to my couch.
- Early return, as usual. I rush missions: they have the nerve to last too long.

### Faccia di Bronzo — dopo un fallimento
Condizione: `talento:facciadibronzo` · Momento: dopo fallimento missione (fallimento=fel-0, zero felicità persa)
- Mission lost. Pain felt: zero. My face is bronze, my heart is teflon. Nothing sticks.
- Failed? Yes. Bothered? Not remotely. I have a reputation AND emotional armor, both freshly polished.
- Lost the mission, saved the mood. Shame slides right off me: smooth surface, excellent engineering.

### Mani Leste — ritorno da missione
Condizione: `talento:manileste` · Momento: ritorno da qualsiasi missione (ogni_missione=velocita+1)
- Every mission makes me faster. Leave places in a hurry often enough and it counts as training.
- Every trip out, my paws come back quicker. Useful for missions. VERY useful for other things I won't put in writing.
- The more missions I run, the faster I get. Soon I'll be too quick to get blamed for anything.

### Boss di Quartiere — requisizione di lusso
Condizione: `talento:bossdiquartiere` · Momento: oggetto gratis senza tetto di valore (furto=1/giorno, nessun tetto)
- Today I requisitioned a premium piece. The neighborhood knows. The neighborhood says nothing. The neighborhood is well trained.
- In my neighborhood, nice things pay a tax: they end up at my place. Nobody has ever objected. Nobody will.
- Luxury goods, zero receipt. The boss doesn't pay: the boss honors the store with his presence.
- Another rare piece for the collection. How do I pay? With my gratitude. Which is worth a FORTUNE, just so you know.

### Boss di Quartiere — ritorno da missione
Condizione: `talento:bossdiquartiere` · Momento: ritorno da missione (bonus_missione_monete=x1.5 su tutte)
- Every mission pays me a little tribute. I never asked for it: respect pays itself when you're the boss.
- Full loot plus my cut. I set the cut myself. It's steep. Nobody objects.
