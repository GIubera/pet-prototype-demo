# Carte dilemma — il mazzo giornaliero

Fonte: `docs/DESIGN-DILEMMI-LAVORI.md` sezione 3 (sessione design fondatore+Claude, 29 lug 2026).
Trascritte qui perche' il codice non hardcoda mai testi ne' numeri: li legge da questo file.

FORMATO (lo legge `PETQ.content` -> `data.carte`):
- `## <id> · <titolo>` apre una carta.
- `Dati:` coppie chiave=valore separate da " ; ". Chiavi: `stadio=` (obbligatoria) · `personalita=`
  · `richiedeFlag=` · `richiedePerk=` · `lavoro=` · `varianteFlag=` + `varianteTitolo=`.
- `Situazione:` il testo che il giocatore legge.
- `### <LETTERA> · <testo del bottone>` apre un'opzione. Puo' avere `richiedeFlag=` sulla riga
  `Cond:` subito sotto: l'opzione compare SOLO con quel flag.
- `Esito:` lista di token (esito certo). Oppure DUE righe `Esito 50/50:` (equiprobabili, un
  trattino lungo = non succede niente). Oppure `Esito se personalita=<nome>:` che vale solo per
  quella personalita' e ha la PRECEDENZA sulle righe 50/50, che diventano l'"altrimenti".
- `Coda:` la battuta di colore, opzionale.

NOTA SUL 50/50 CON UNA PARTE CERTA (es. C21-B): si scrivono i token comuni in ENTRAMBE le righe
50/50 e si aggiunge la differenza in una delle due. Il risultato e' esattamente "questo e' certo,
piu' un tiro" senza aggiungere una quarta forma al formato.

## C01 · Il Gratta e Vinci del Piccione
Dati: stadio=baby
Situazione: Il piccione cyborg ha vinto 20 monete a un gratta e vinci e non ha i pollici per riscuoterle. Offre al pet il 50%. Il pet non sa fare le percentuali.

### A · Riscuoti e fai 50/50 onesto
Esito: monete+10, flag:socio_del_piccione

### B · "Quale gratta e vinci?"
Esito: monete+15, fel-3
Coda: il piccione ti fissa dalla finestra. Per tre giorni.

### C · Mai fare affari coi piccioni
Esito: int+1

## C02 · C'è un Mostro nell'Armadio (e paga l'affitto?)
Dati: stadio=baby
Situazione: Nell'armadio c'è DAVVERO un micro-mostro. Piccolo, educato, ha già sistemato i calzini per colore.

### A · Può restare se pulisce
Esito: igiene+10, flag:coinquilino

### B · Sfratto immediato
Esito: forza+1
Coda: trascinarlo fuori è stato un allenamento

### C · Affitto: tre notti anticipate, subito
Esito: monete+9
Coda: il pet dorme senza armadio. Scelte.

## C03 · Gli Amici del Coinquilino
Dati: stadio=baby ; richiedeFlag=coinquilino
Situazione: L'armadio ora ospita TRE micro-mostri. Stanotte c'era musica. Dall'ARMADIO.

### A · Festa consentita, ma vi invitano
Esito: fel+8, igiene-5

### B · Regolamento condominiale severo
Esito: int+1, fel-2
Coda: il coinquilino mette il broncio

### C · Da oggi si paga l'affitto: tutti e tre
Esito: monete+9, flag:padrone_di_casa

## C04 · Lo Scambio di Merende
Dati: stadio=baby
Situazione: Un cucciolo losco propone: la tua merenda contro "una sorpresa". La sorpresa è in una scatola che si muove.

### A · Accetta lo scambio
Esito 50/50: cibo:Fetta di Panino Gigante
Esito 50/50: fel-3, flag:fregato_una_volta

### B · Merenda mia
Esito: cibo:Biscotto
Coda: te la mangi lì, per principio

## C05 · Il Cartone Proibito
Dati: stadio=baby
Situazione: In TV c'è il cartone "da grandi" che guardano i teen. Il pet ti fissa col telecomando in mano.

### A · Va bene, ma insieme
Esito: fel+8, energia-10
Coda: stanotte non chiude occhio: "e se il mostro del cartone abita QUI?"

### B · Assolutamente no
Esito: fel+3, flag:ribelle
Coda: lo guarda di nascosto comunque

### C · Lo guardi prima tu, "per controllo qualità"
Esito: int+1
Coda: ora sai cose sui cartoni che non volevi sapere

## C06 · La Pozzanghera Perfetta
Dati: stadio=baby
Situazione: Ha piovuto. Davanti casa c'è LA pozzanghera: profonda, fangosa, perfetta. Il pet ha già la rincorsa.

### A · Libera il cannone
Esito: fel+10, igiene-20

### B · Fermalo in extremis
Esito: fel-5, flag:pulito_dentro

### C · Lanci dentro un giocattolo "per test"
Esito: fel+6, igiene-8
Coda: la schizzata arriva comunque

## C07 · Il Peluche "Adottato"
Dati: stadio=baby
Situazione: Il pet è tornato dal parco con un peluche che non è suo. Dice che "lo seguiva".

### A · Si riporta al parco
Esito: carisma+1, flag:onesto
Coda: il proprietario diventa suo amico

### B · Ormai è di famiglia
Esito: fel+8, flag:furbetto

### C · Cartelli "PELUCHE TROVATO" per il quartiere
Esito: int+1, monete+5
Coda: di ricompensa

## C08 · La Prima Parolaccia
Dati: stadio=baby
Situazione: Il pet ha imparato una parola nuova dal camionista sotto casa. La ripete. Spesso. Con orgoglio.

### A · Ridi (non farlo)
Esito: fel+8, flag:boccaccia
Coda: la ridirà nel momento peggiore

### B · Faccia seria e parola sostitutiva
Esito: int+1
Coda: ora dice "CAROTA!" con la stessa rabbia

### C · Ignora
Esito: fel+5, carisma+1
Coda: dopo due giorni la dice AL VIGILE. Il vigile ride, e la storia diventa leggenda di quartiere.

## C09 · Il Talent dei Cuccioli
Dati: stadio=baby
Situazione: Al parco organizzano "Cuccioli Got Talent". Il pet non ha un talento. Il pet è CONVINTISSIMO di averne uno.

### A · Iscrivilo, e sia quel che sia
Esito: carisma+1, fel+8
Coda: ultimo posto, standing ovation per l'impegno

### B · "Sei ancora piccolo"
Esito: fel-3, flag:rivincita_talent
Coda: ne riparleremo da teen

### C · Allenamento intensivo prima
Esito: forza+1, fel+3
Coda: il numero resta orrendo ma atletico

## C10 · Lo Sciopero della Pappa
Dati: stadio=baby
Situazione: Il pet ha incrociato le braccia davanti alle crocchette: vuole "quello che mangi tu". Tu mangi pixel.

### A · Assaggia dal tuo piatto
Esito: fel+8, flag:palato_fino

### B · Le crocchette o niente
Esito: int+1, fel-3
Coda: impara la parola "principi"

### C · Crocchette IMPIATTATE con foglia di menta
Esito: carisma+1, fel+5
Coda: l'estetica è tutto

## C11 · Il Compito in Classe
Dati: stadio=teen
Situazione: Domani verifica di matematica. Il compagno secchione vende "gli appunti giusti" a 10 monete. Troppo giusti.

### A · Studiate insieme stasera
Esito: int+2, energia-10

### B · Compra gli "appunti"
Esito: monete-10, flag:copione

### C · Vada come vada
Esito: fel+3
Coda: vivere pericolosamente

## C12 · La Convocazione
Dati: stadio=teen ; richiedeFlag=copione
Situazione: Il prof ha capito tutto: gli "appunti giusti" erano le soluzioni rubate. Il pet è convocato. Con te.

### A · Confessa — con una presentazione di scuse in 12 slide
Esito: int+1, fel-3, flag:-copione
Coda: il prof si commuove alla slide 9: "nessuno si era mai scusato con un grafico a torta"

### B · Negare. Sempre negare
Esito se personalita=Maleducato: carisma+2
Esito 50/50: fel+5, flag:faccia_tosta
Esito 50/50: fel-8
Coda: se Maleducato, ne esce da leggenda

## C13 · Lo Sponsor Losco
Dati: stadio=teen
Situazione: Un tizio con troppi anelli propone 30 monete per pubblicizzare "SBLORF, la bibita che ti cambia" alla gara del quartiere. L'ultimo testimonial era un cono stradale. Si vede che era un cono nello spot.

### A · Rifiuta con classe
Esito: carisma+1, flag:pulito

### B · Accetta
Esito: monete+25, flag:venduto
Coda: alla prossima missione tag gara, niente mancia: il pubblico ricorda lo SBLORF

### C · Contro-offerta: il doppio
Esito 50/50: monete+40, flag:venduto
Esito 50/50: —
Coda: il tizio accetta, oppure si offende e se ne va coi suoi anelli

## C14 · Il Piccione Ripassa
Dati: stadio=teen ; richiedeFlag=socio_del_piccione
Situazione: Il piccione cyborg torna con una proposta: uno "schema di investimento in briciole". Rende il 300%. Di briciole.

### A · Investi 10 monete
Esito: monete+25
Coda: il piccione sparisce, poi torna: zero spiegazioni

### B · "Sparisci, socio"
Esito: fel+3, flag:occhio_lungo
Coda: il piccione annuisce con rispetto

### C · Denuncialo alla guardia del parco
Esito: int+1, fel-2
Coda: il piccione ti toglie il saluto

## C15 · Il Motorino "Migliorato"
Dati: stadio=teen ; lavoro=consegnepizza
Situazione: Un amico dell'officina offre di "sistemare" il motorino delle consegne. Gratis. "Fidati."

### A · Fidati
Esito: rendita:+3, flag:motorino_truccato
Coda: monete a notte, per il resto della run (v. C41)

### B · Il motorino resta com'è
Esito: int+1
Coda: la parola "gratis" ti insospettisce sempre

## C16 · La Band in Garage
Dati: stadio=teen
Situazione: Gli amici del pet fondano una band. Serve un garage. Voi ce l'avete. Loro no. Capito il problema?

### A · Garage concesso, orari da rispettare
Esito: fel+8, carisma+1, energia-5
Coda: le "prove acustiche" non erano acustiche

### B · No: lì c'è la mia collezione
Esito: int+1, fel-3

### C · Sì, ma il pet è il manager
Esito: monete+15, flag:manager
Coda: primo "concerto" a offerta libera

## C17 · Il Primo Appuntamento
Dati: stadio=teen
Situazione: Il pet ha un appuntamento. Non sa cosa mettersi. Ha provato TUTTO l'armadio. Due volte. Il pavimento è scomparso.

### A · Consiglia il capo più assurdo che possiede
Esito: carisma+2
Coda: se ha un indossabile, la scena lo cita

### B · "Stai bene come sei"
Esito: fel+8
Coda: era la risposta giusta. Per una volta la frase fatta funziona

### C · Tutina anni 90 ironica
Esito: fel+6, flag:stile_discutibile
Coda: le foto resteranno

## C18 · Il Supplente Strambo
Dati: stadio=teen
Situazione: A scuola è arrivato un supplente che insegna "materie alternative": oggi, taglio delle spese e memoria dei tram.

### A · Il pet segue tutto entusiasta
Esito: int+2
Coda: sorprendentemente utile

### B · Marina la lezione
Esito: fel+5, flag:ribelle

### C · Invita il supplente a cena
Esito: carisma+1, cibo:Zuppa di verdure
Coda: si commuove e ricambia

## C19 · La Sfida di Ballo
Dati: stadio=teen ; varianteFlag=rivincita_talent ; varianteTitolo=La Rivincita
# DA SCRIVERE (fondatore): con flag:rivincita_talent questa carta diventa "La Rivincita" —
# il doc dichiara la variante ma non ne scrive il testo. Finche' manca, con il flag presente
# cambia solo il TITOLO e la situazione resta questa.
Situazione: Al centro commerciale c'è il tappeto della sfida di ballo. Un capannello. Un campione locale. Il pet che si scrocchia le dita.

### A · Sfidalo
Esito: velocita+2, fel+5
Coda: perde ai punti, ma con un passo tutto suo: il campione gli stringe la zampa

### B · Registra e basta
Esito: int+1, monete+8
Coda: la clip del campione che sbaglia vale oro

### C · Balla TU... cioè, il pet balla "a modo suo"
Esito: fel+8, carisma+1
Coda: dignità -tutta

## C20 · Il Gruppo di Studio
Dati: stadio=teen
Situazione: Verifica di gruppo: o coi secchioni ("studiamo davvero") o con gli amici ("studiamo, giuro, dai").

### A · Secchioni
Esito: int+2, fel-3

### B · Amici
Esito: fel+8
Coda: avete ordinato pizze e parlato di tutto tranne la verifica

### C · Da solo
Esito: int+1, flag:lupo_solitario

## C21 · Lo Zaino Firmato
Dati: stadio=teen
Situazione: Tutti a scuola hanno lo zaino "Guccino". Il pet lo vuole. Costa 25 monete. È IDENTICO al suo, ma con la scritta.

### A · Compraglielo
Esito: monete-25, fel+10, carisma+1
Coda: l'accettazione sociale ha un prezzo, letteralmente

### B · Scrivi "Guccino" sul suo con l'evidenziatore
Esito 50/50: fel+5, flag:tarocco
Esito 50/50: fel+5, flag:tarocco, fel-5
Coda: nessuno se ne accorge, oppure se ne accorgono TUTTI ma passa alla storia

### C · "Lo zaino non fa il pet"
Esito: int+1, fel-3
Coda: il pet cita la frase a tutti come sua

## C22 · Il Torneo di Carte Collezionabili
Dati: stadio=teen
Situazione: Il pet ha scoperto le carte "Mostriciattoli da Battaglia". Il bidello, si mormora, ha la collezione completa. E nessuna pietà.

### A · Comprigli un pacchetto
Esito: monete-8, fel+8, arredo:Carta Olografica del Drago

### B · Lo alleni a scambiare le doppie
Esito: carisma+1, monete+5
Coda: il mercato delle figurine è spietato e lui è portato

### C · Sfida il bidello, direttamente il boss
Esito 50/50: fel+10, flag:grinder
Esito 50/50: fel-5, arredo:Carta Olografica del Drago
Coda: vince e ottiene rispetto eterno, oppure perde malissimo e il bidello gli regala una carta "per il coraggio"

## C23 · Il Diario Segreto
Dati: stadio=teen
Situazione: Pulendo la cameretta trovi il diario del pet. APERTO. Alla pagina "cose che non dico al capo".

### A · Non leggere. Chiudi e basta
Esito: fel+8, flag:fiducia
Coda: il pet se ne accorge dal segnalibro intatto

### B · Solo una riga...
Esito: int+1, fel-3
Coda: c'è scritto "il capo legge il mio diario". SAPEVA.

### C · Lascia un post-it: "bella grafia"
Esito: carisma+1, fel+5
Coda: guerra psicologica vinta

## C24 · La Notte Brava
Dati: stadio=teen ; personalita=Maleducato
Situazione: Gli amici propongono di uscire DI NASCOSTO dopo il coprifuoco. Il piano è "geniale": un manichino nel letto.

### A · Fingi di non aver visto il manichino
Esito: fel+10, energia-15
Coda: rientra all'alba camminando come un granchio

### B · Faretto in faccia alle 23:01
Esito: int+1, carisma+1
Coda: il pet ti rispetta e ti teme

### C · Esci CON loro ("qualcuno deve vigilare")
Esito: fel+8, carisma+1, energia-10

## C25 · Il Turno dei Difficili
Dati: stadio=teen ; personalita=Gentile
Situazione: Il rifugio cerca volontari per i mostriciattoli "difficili": quello che morde, quello che esplode se starnutisce, e quello che cita film che non esistono. Nessun volontario è mai tornato due volte. Il pet ha già la pettorina.

### A · Dentro tutti e tre
Esito: fel+10, carisma+1, igiene-10, flag:cuore_doro
Coda: il morsicatore ora morde SOLO i cattivi: successo

### B · Solo quello dei film finti
Esito: int+1, fel+5
Coda: "Come disse Rocky in Titanic 4..." — il pet ora lo cita pure lui

### C · Turno in reception: zero rischi
Esito: monete+8, fel+3
Coda: paga simbolica; l'esplosivo starnutisce comunque in direzione tua

## C26 · La Fiera del Fumetto
Dati: stadio=teen ; personalita=Nerd
Situazione: La fiera è domenica. Il costume del suo eroe non esiste in taglia pet. "Lo facciamo NOI."

### A · Weekend di cartone e colla
Esito: int+2, fel+10, flag:cosplayer
Coda: orrendo e bellissimo

### B · Compra l'"ufficiale"
Esito: fel+5, carisma+1
Coda: è ESAURITO nella sua taglia: ripiega sul costume di un personaggio che ODIA e lo indossa con un rancore magnetico

### C · Ci va "vestito da se stesso, versione futura"
Esito: carisma+1, fel+5
Coda: concettuale. Nessuno capisce. Lui è fiero

## C27 · La Corsa dell'Alba
Dati: stadio=teen ; personalita=Sportivo
Situazione: Il gruppo dei runner del parco si trova alle 5:30. CINQUE E TRENTA. Il pet ha già messo la sveglia.

### A · Accompagnalo (in spirito)
Esito: velocita+2, energia-10, flag:alba_runner

### B · "Alle 5:30 si dorme"
Esito: energia+5, velocita+1
Coda: ci va da solo e torna INSOPPORTABILMENTE energico

### C · Negozia le 7:00 col gruppo
Esito: carisma+1, velocita+1
Coda: hai riformato il running di quartiere

## C28 · Il Colloquio della Concorrenza
Dati: stadio=adulto
Situazione: Un'azienda rivale corteggia il pet: stesso lavoro, "più monete". Il colloquio è alle 15, di nascosto.

### A · Vai a sentire
Esito: monete+20, flag:ambizioso
Coda: controfferta del capo attuale per tenerlo

### B · Lealtà totale
Esito: carisma+1, fel+5
Coda: il capo lo scopre comunque e si commuove

### C · Manda il piccione a fare domande
Esito: int+1
Coda: torna con l'organigramma. Non chiedere come

## C29 · La Riunione di Condominio
Dati: stadio=adulto
Situazione: Il condominio vuole eleggere il pet rappresentante: "sei l'unico che risponde ai messaggi".

### A · Accetta la carica
Esito: carisma+2, fel-3, flag:rappresentante
Coda: la prima grana arriva DURANTE il discorso di insediamento

### B · Rifiuta con eleganza
Esito: carisma+1, fel+5
Coda: la libertà non ha prezzo

### C · Delega tutto al mostro dell'armadio
Cond: richiedeFlag=coinquilino
Esito: fel+8
Coda: il condominio approva: è efficientissimo

## C30 · Il Trilocale Vista Cratere
Dati: stadio=adulto
Situazione: Un'agenzia propone "l'affare della vita": trilocale vista cratere, "zona in fortissima crescita". Il cratere è QUELLO delle sfide.

### A · Sopralluogo
Esito: int+1, fel+5
Coda: la "vista cratere" è LETTERALE: la sera si vede l'aura gialla. Suggestivo, invendibile

### B · Cestina il volantino
Esito: fel+3, energia+3
Coda: il volantino RITORNA. Nel frigo. Tre volte. Quando finalmente smette

### C · Rivendilo a un collezionista di truffe
Esito: monete+10, flag:occhio_lungo

## C31 · L'Ex Rivale in Bolletta
Dati: stadio=adulto
Situazione: Il rivale storico del pet — quello delle sfide al parco — si presenta alla porta. Gli serve un prestito. Guarda le scarpe mentre lo chiede.

### A · Prestaglieli (20 monete)
Esito: monete-20, flag:creditore

### B · "No, ma cena pagata"
Esito: monete-8, carisma+1, fel+5
Coda: la dignità di entrambi è salva

### C · "Ti ricordi quando mi hai spinto nella pozzanghera?"
Esito: fel+8, flag:vendicativo

## C32 · Il Reality "Pet Fratello"
Dati: stadio=adulto
Situazione: Casting cittadino per il reality: 3 giorni chiuso in una casa con altri 7 pet e le telecamere.

### A · Iscrivilo
Esito: carisma+2, fel+5, flag:reality
Coda: fuori al primo televoto, ma la clip dello sbrocco fa il giro

### B · "La TV ti mangia l'anima"
Esito: int+1

### C · Vai TU al casting come "il capo apprensivo"
Esito: carisma+1, fel+8
Coda: vi prendono come coppia comica, rifiutate con onore

## C33 · La Mail del Principe Alieno
Dati: stadio=adulto
Situazione: Mail: "SONO UN PRINCIPE ALIENO, mi serve solo un piccolo anticipo per sbloccare la mia eredità di 9000 monete".

### A · È OVVIAMENTE una truffa
Esito: int+2

### B · Rispondi per fargli perdere tempo
Esito: fel+8, flag:troll
Coda: dopo tre mail il truffatore si affeziona e vi manda la ricetta di famiglia

### C · "E se fosse VERO?"
Esito: monete-10, arredo:Mazzetta Finta, fel+5
Coda: per posta arrivano 9000 monete DEL MONOPOLI (il pet le conta comunque. Due volte.)

## C34 · Il B&B dell'Armadio
Dati: stadio=adulto ; richiedeFlag=coinquilino
Situazione: Il micro-mostro dell'armadio è cresciuto: vuole aprire un B&B "per mostri di passaggio". Nel VOSTRO armadio.

### A · Socio al 50%: primo incasso subito
Esito: monete+12, fel-2
Coda: gli ospiti russano IN VERTICALE

### B · Solo weekend
Esito: monete+6
Coda: pace infrasettimanale

### C · "L'armadio torna armadio"
Esito: fel+3
Coda: apre il B&B DAL VICINO, con vista sul vostro salone. Vi saluta ogni mattina

## C35 · Chiude la Palestra Storica
Dati: stadio=adulto
Situazione: La palestra del primo allenamento chiude: al suo posto, un locale di "bowl energetiche e vibrazioni". Il gestore svende TUTTO: c'è la fila dei nostalgici e ognuno vuole un pezzo di storia.

### A · Compra il sacco da boxe storico (15 monete)
Esito: monete-15, arredo:Sacco della Vecchia Palestra, fel+5
Esito se personalita=Sportivo: monete-15, arredo:Sacco della Vecchia Palestra, fel+10
Coda: c'è ancora l'adesivo del suo primo allenamento

### B · Organizza la serata d'addio
Esito: carisma+2, energia-10
Coda: il gestore piange, le "vibrazioni" del nuovo locale sono già in imbarazzo

### C · Vai ad annusare le bowl energetiche
Esito: int+1, fel+3
Coda: "sa di erba tagliata con l'ambizione." Il pet ne è stranamente conquistato

## C36 · La Food Blogger UNTA
Dati: stadio=adulto ; richiedePerk=corso_cucina
Situazione: La food blogger più temuta della città — nota come "l'UNTA" per come stronca — ha saputo del tuo Cuoco di Casa. Si autoinvita a cena. STASERA.

### A · Menù degustazione improvvisato
Esito: int+2, monete+20
Coda: recensione: "unto il giusto. CINQUE PADELLE."

### B · Ordini da fuori e impiatti
Esito 50/50: carisma+2
Esito 50/50: fel-5, carisma+1
Coda: non se ne accorge (la recensione loda "la semplicità"), oppure ti sgama dal cartone nel bidone (e la stroncatura è così divertente che diventa virale)

### C · "La cucina è chiusa"
Esito: carisma+1
Coda: l'UNTA rispetta chi sa dire no. "Tornerò." Suona come una minaccia

## C37 · La Galleria Chiama
Dati: stadio=adulto ; richiedePerk=corso_disegno
Situazione: Una galleria vuole esporre i disegni del pet. Compreso il ritratto in cui sembri "un tubero arrabbiato".

### A · Esponi tutto, anche il tubero
Esito: carisma+2, monete+20, fel+8
Coda: il tubero è il pezzo più fotografato

### B · Mostra monografica: SOLO il tubero
Esito: fel+10, carisma+1
Coda: dodici visitatori si commuovono davanti al tubero. Uno lo saluta

### C · Il tubero si vende all'asta
Esito: monete+35, flag:mecenate_involontario
Coda: non rivedrai mai più il tuo ritratto

## C38 · Il Karaoke Aziendale
Dati: stadio=adulto ; richiedePerk=corso_musica
Situazione: Cena aziendale del lavoretto. C'è il karaoke. Il capo ha già scritto il nome del pet. Per un duetto. CON LUI.

### A · Duetto senza paura
Esito: carisma+2, fel+8, monete+15
Coda: il capo commosso arrotonda la paga della serata

### B · "Solo se scelgo io il pezzo"
Esito: carisma+1, fel+5
Coda: il capo accetta: sarà una power ballad. Il capo NON sa cantare le power ballad

### C · Fuga dal bagno
Esito: fel+3, energia+5, flag:fantasma_del_karaoke
Coda: in azienda se ne parla ancora

## C39 · Il Ritorno del Debitore
Dati: stadio=adulto ; richiedeFlag=creditore
Situazione: L'ex rivale torna. Ha le 20 monete. E anche un'idea: "e se invece di ridartele... le investissimo INSIEME?"

### A · Ridammi i soldi e basta
Esito: monete+20

### B · Ascolta l'idea
Esito 50/50: monete+40
Esito 50/50: monete+0, carisma+1
Coda: era buona, oppure era un chiosco di granite in dicembre (ma la stretta di mano vale)

### C · Condona il debito
Esito: carisma+2, flag:cuore_doro
Coda: non lo dimenticherà: eco alla pensione

## C40 · Il Giorno Libero
Dati: stadio=adulto
Situazione: Il capo del lavoretto dà un giorno pagato: "te lo sei meritato". Il pet ha ZERO piani ed è bellissimo.

### A · Giornata pigiama e giocattoli
Esito: fel+10, energia+10

### B · "Già che ci siamo": palestra extra
Esito: forza+1

### C · Gita a pesca coi pensionati del porto
Esito: fel+8, cibo:Pesce alla griglia
Coda: tornano con UN pesce in sette. Il pesce l'ha pescato il pet. Non si parla d'altro

## C41 · Il Controllo dei Vigili
Dati: stadio=adulto ; richiedeFlag=motorino_truccato
Situazione: Posto di blocco davanti alla pizzeria. Il vigile gira intorno al motorino "migliorato" con un taccuino e un sopracciglio.

### A · Confessa il ritocco
Esito: monete-15, flag:-motorino_truccato, int+1

### B · "È di serie, giuro"
Esito 50/50: —
Esito 50/50: monete-15, rendita:-3, flag:-motorino_truccato
Coda: ci crede ("bel modello"), oppure non ci crede: il motorino torna di serie

### C · Distrailo col pezzo forte: la sgommata silenziosa
Esito 50/50: flag:-motorino_truccato
Esito 50/50: monete-25, flag:-motorino_truccato
Coda: il vigile è un ex meccanico e si COMMUOVE, il ritocco diventa "certificato" (rendita resta), oppure multa doppia
