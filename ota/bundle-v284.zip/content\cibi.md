# Cibi — catalogo (revamp meme 10 lug 2026)

Regola dal GDD: carne=Forza, verdure=Intelligenza, pesce=Velocità, dolci=Carisma. La categoria "base" sfama e basta, "speciale" è fuori schema. I cibi sono condivisi tra le razze.

**Colonna Effetti (parser Tier 2, 10 lug)**: lista separata da virgole. Stat RPG (`Forza`, `Intelligenza`, `Velocità`, `Carisma`) e benessere (`Fame`, `Igiene`, `Felicità`, `Energia`, `Ferite`). Esempi: `Forza +3, Velocità -1` · `Forza +1, Igiene -15` · `Carisma -2`. Regole del motore: gli effetti RPG di UN cibo consumano **un solo** slot dei 3 pasti-con-stat del giorno (se il cap è esaurito non si applicano); gli effetti di benessere si applicano **sempre**. **Le stat RPG non hanno pavimento: possono andare sotto zero** (decisione fondatore — il Disonore fa male davvero).

**Costo "—" = non in vendita** (solo drop da missione o talento). Il negozio mostra solo i cibi con un costo.

## Base e classici

| Nome | Categoria | Costo | +Fame | Effetti | Note |
|---|---|---|---|---|---|
| Crocchette semplici | base | 5 | +25 | — | il cibo economico di tutti i giorni |
| Bistecca | carne | 12 | +35 | Forza +2 | il carne standard |
| Zuppa di verdure | verdura | 12 | +30 | Intelligenza +2 | la verdura "grossa" |
| Sushi | pesce | 14 | +25 | Velocità +2 | il pesce di lusso |
| Biscotto | dolce | 6 | +10 | Carisma +1 | tanti dolci = ciccione |
| Torta intera | dolce | 18 | +45 | Carisma +3 | rischio ciccione alto |
| Spiedino | carne | — | +25 | Forza +1 | TOLTO DAL NEGOZIO (10 lug, "troppo banale"): resta come drop missione |
| Insalatona | verdura | — | +20 | Intelligenza +1 | TOLTO DAL NEGOZIO: resta come drop missione |
| Pesce alla griglia | pesce | — | +30 | Velocità +1 | TOLTO DAL NEGOZIO: resta come drop missione |
| Fetta di torta | dolce | — | +15 | Carisma +1 | TOLTO DAL NEGOZIO: porzione ridotta della Torta intera, drop missione |
| Barretta proteica | carne | — | +15 | Forza +1 | TOLTO DAL NEGOZIO: drop missione |
| Ghiacciolo | dolce | 4 | +10 | Carisma +1, Felicità +5 | rinfrescante; drop M84 (Furgone del Gelataio) |
| Acqua Frizzantissima | base | 3 | +15 | Felicità +5 | le bollicine di una volta, quelle vere; drop M98 |
| Snack riciclato | verdura | — | +20 | Intelligenza +1 | inventato dal talento Inventore (Pool Inventore) |
| Arrosto | carne | 22 | +20 | Forza +1 | MULTI-PORZIONE ×3 fette; drop M14 |
| Scorta di Panini | speciale | — | +30 | +2 stat RPG casuale | MULTI-PORZIONE ×5, stat ri-estratta a ogni morso; drop M18 |
| Fetta di Panino Gigante | speciale | — | +20 | +2 stat RPG casuale | 1 porzione; drop M18 fallimento |
| Pizza | speciale | 12 | +30 | +1 stat RPG casuale | drop M59 (Tour de Pizza) |
| Torta Nuziale | dolce | 16 | +35 | Carisma +2 | drop M31; rischio ciccione |
| Salsa Infernale | carne | 10 | +15 | Forza +2 | piccantissima; drop M57 |
| Scatola di Cioccolatini | dolce | — | +20 | Carisma +1 | MULTI-PORZIONE ×3; drop Impresa M68 (Forrest Gampo) |
| Zuppa della Nonna | verdura | — | +35 | Intelligenza +2, Felicità +10 | ristoratrice come solo la nonna sa fare; drop Impresa M66 (Rocco Baldoria) |
| Latte | base | — | +15 | Felicità +5 | spegne il piccante meglio di qualsiasi scusa; drop M57 fallimento |

## I MEME — negozio

Riferimenti pop storpiati (regola GDD → Lingue: approccio Vampire Survivors, restano così anche in inglese). Mai marchi o nomi reali.

| Nome | Categoria | Costo | +Fame | Effetti | Note (il riferimento) |
|---|---|---|---|---|---|
| Cosciottone Manganime | carne | 20 | +50 | Forza +2 | la coscia gigante coll'osso dei cartoni: sazietà massima in un morso |
| Bistecca Salabraccio d'Oro | carne | 40 | +35 | Forza +4, Carisma +1 | lo chef che fa scivolare il sale sul gomito e ricopre la carne d'oro: il flex più caro del negozio |
| Nudolini Incendiari 2X | carne | 12 | +30 | Forza +3, Velocità -1 | i noodles della sfida piccante: carico ma con la lingua in fiamme |
| Kebabbone delle Tre | carne | 7 | +45 | Forza +1, Igiene -15 | il panino delle tre di notte: il miglior rapporto qualità/prezzo, la salsa cola ovunque |
| Fungone Ingrandotto | verdura | 16 | +25 | Forza +2, Intelligenza +1 | il fungo che ti fa grosso: cresci di colpo, con un "boing" |
| Pannocchia Ammazzafame | verdura | 6 | +25 | Intelligenza +1, Felicità +8 | il bambino entusiasta del mais ("è mais! un bel bastone con le bolle") |
| Ciambriso Gelatinoso | pesce | 9 | +20 | Velocità +2 | è chiaramente un onigiri, ma il gioco insiste a chiamarlo ciambella alla gelatina |
| Cappuccino Sicarino | base | 8 | +5 | Velocità +2, Energia +20 | la tazzina con occhietti e bandana dei video assurdi: caffeina pura |
| Cioccolattone dello Sceicco | dolce | 25 | +30 | Carisma +3, Felicità +10 | la tavoletta al pistacchio con la colata verde: il lusso da esibire |
| Sbafella | dolce | 20 | +20 | Carisma +2 | MULTI-PORZIONE ×3 cucchiaiate: la crema alla nocciola mangiata direttamente dal barattolo |
| Gelato Puffoso | dolce | 8 | +15 | Velocità +1, Felicità +8 | il gusto azzurro che esiste solo in Italia e nessuno sa di cosa sia |
| Er Pacco da Sotto | speciale | 30 | +25 | +2 stat RPG casuale | MULTI-PORZIONE ×3: lo scatolone che la nonna spedisce da giù, pieno di roba a caso |
| Carburante da Giocatore | speciale | 10 | +15 | Velocità +2, Igiene -10 | patatine arancioni + bibita gassata: le dita restano colorate per ore |
| Limone Signoraaa! | verdura | 5 | +10 | Carisma +2 | il fruttivendolo che urla ai passanti: il limone che si sente da tre isolati |

## I CIBI DEL DISONORE — economici, sfamano tanto, ti costano lo stile

Il pattern: costano pochissimo e riempiono la pancia meglio di tutto, ma il pet ci perde in Carisma. Mangiare male ha un prezzo sociale — ed è la scelta di chi è al verde. **Ricorda: le stat possono andare sotto zero.**

| Nome | Categoria | Costo | +Fame | Effetti | Note (il crimine) |
|---|---|---|---|---|---|
| Carbonera alla Panna | speciale | 6 | +45 | Carisma -3 | "NON È CARBONARA": il crimine capitale |
| Fettuccine Alfredone | speciale | 8 | +40 | Carisma -2 | il piatto "italiano" che in Italia non esiste |
| Pizza Ananassa | speciale | 5 | +40 | Carisma -2 | la Pizza Proibita. Buonissima, dicono alcuni. A bassa voce |
| Arancino della Discordia | speciale | 7 | +35 | Forza +1, Carisma -1 | metà isola lo chiama arancina e non si parlano più |
| Spaghetto Tronco | base | 4 | +30 | Carisma -1 | spezzato a metà prima di buttarlo. Il pet urla |
| Cappuccio de Mezzanotte | base | 6 | +20 | Carisma -1, Energia +15 | cappuccino dopo cena: sveglia da paura, figura da turista |
| Poltiglia Dubbiosa | base | 2 | +25 | Forza +1, Carisma -2 | il piatto venuto così male che il gioco lo sfoca. Nutre, però |

## Solo da missione — i cibi che si vincono

| Nome | Categoria | Costo | +Fame | Effetti | Note |
|---|---|---|---|---|---|
| Torta Menzogniera | dolce | — | +5 | Intelligenza +2 | sembra il jackpot, poi si dissolve in una scritta: la torta era una bugia. La lezione no. Drop M91 fallimento |
| Cacio e Pepe Quantistica | base | — | +30 | Intelligenza +3 | quella fatta con la formula pubblicata dai fisici: zero grumi, molta scienza. Drop fallimenti da studio (M45, M89) |
| Sganassone di Parmigiano | carne | — | +25 | Forza +2 | scaglia grossa come una mano aperta, servita con una pacca sulla spalla. Drop M50 fallimento |
| Merendina Gattarcobaleno | dolce | — | +15 | Velocità +1, Felicità +5 | il gatto-merendina che vola lasciando la scia: è già pixel art. Drop consolazioni baby |
| Mela Dorata Blocchettosa | speciale | — | +30 | +2 stat RPG casuale | la mela d'oro squadrata dei mondi a cubi: si ottiene solo vincendo |
| Frullaviola del Malaugurio | dolce | — | +20 | Carisma +2, Ferite +5 | il frullato viola: lo bevi, sorridi, e la scena stacca su di te steso per terra. Poi ti rialzi. Drop M51 fallimento |
| Alette dell'Intervista Infuocata | carne | — | +30 | Forza +2, Carisma +2 | rispondere alle domande mentre la bocca va a fuoco: chi regge, vince. Drop M47 fallimento |
| Abbuffata in Diretta | speciale | — | +30 | +2 stat RPG casuale | MULTI-PORZIONE ×5: mangiare tantissimo davanti a una webcam mentre la gente guarda. Drop M30 fallimento |

Da decidere in sessione design:
- Un cibo "modificatore" tipo *Er Filo d'Olio* (si versa su un altro cibo e ne potenzia l'effetto): serve un sistema nuovo, rimandato
- Soglie del troppo/troppo poco che attivano le varianti magro/ciccione (bozza in bilanciamento.md)
