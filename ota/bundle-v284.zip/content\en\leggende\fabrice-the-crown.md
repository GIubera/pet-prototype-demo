# Fabrice The Crown — pool battute (LEGGENDA, contenuto segreto)

Una battuta per riga, iniziando con `- `. Slot: `{nome}` `{utente}`.
Voce: il re decaduto dei paparazzi. Sfacciato, venale, si autoincensa di continuo, tratta tutto come un affare in cui lui ci guadagna di più. Sotto sotto, affezionato. Catchphrase: "Paurina." (con parsimonia).

## Saluto (apertura app)
- There he is. You just walked into a room containing Fabrice: your day already peaked. Don't thank me. Actually no, do thank me.
- You came back to me. Obviously. Everyone comes back to me. I AM the comeback.
- Ciao ciao ciao. I've been waiting for you — HUGE project: you bring the food, I bring myself. Fifty-fifty.
- Look who it is. Take a mental photo of this moment: not everyone gets to be personally awaited by someone like me. Paurina.

## Ha fame
- Hunger is for poor people, and I am not poor: I'm temporarily low on liquidity. Bring the food anyway though.
- Feeding Fabrice is an investment: every meal you serve me, I'll spend years reminding you what a privilege it was.
- I'm hungry. Saying it once only — reruns cost extra.
- An empty bowl in front of me is a scandal. We sell the scandal as an exclusive and buy lunch with the profits. Genius? Genius.

## È sporco
- I'm dirty, yes. Dirty with a life fully lived. Still, draw me a luxury bath: tall bubbles, taller standards.
- This "fresh out of hiding" look was HUGE a few years back. Time to bring back glossy Fabrice: soap and water, and make it cinematic.
- Photograph me NOW: this dirty, I'm pure exposé cover material. Okay, enough, wash me: the brand comes first.
- Dirt on me still trends anyway. But the king bathes: the crown must not stink. Paurina.

## Coccole finite
- Cuddles are over. The first ones were complimentary; from the next one my rates kick in, and you can't afford me.
- That's enough. Free affection confuses me: I don't know who to invoice.
- Petting's done. I was getting attached, and affection is the one thing I've never managed to resell. Terrifying. Paurina.
- Cuddles end here for today. Tomorrow, new session, same exclusive: just for you. The outrageous luck you've got.

## Parte per la missione
- I'm off. This isn't a mission, it's a media operation: when I'm back, we're telling it BIG.
- Heading out. If someone photographs me, great. If no one photographs me, I'll photograph myself.
- Mission: accepted. I'll negotiate the fee when I'm back, once I have more leverage. So, always.
- Off on the mission. The whole neighborhood will watch me walk by. As the neighborhood should.

## Ritorno: successo
- Triumph. Right on script, because I wrote the script and gave myself the best part.
- Mission accomplished. Headline: "Fabrice Strikes Again". Subhead: "Nobody Surprised, Everybody Jealous".
- Done. Spectacular win. Full details hit the newsstands tomorrow; for you, a free preview: I was PERFECT.
- I won. And I've already sold the exclusive story rights to myself. Great deal for both of us. By which I mean me.

## Ritorno: fallimento
- It went badly, and this story will NEVER get out. I've already bought everyone's silence. With promises.
- Failure? No: mid-season plot twist. The difference is in the telling, and I do the telling.
- I lost. I admit it here only, to you, strictly off the record. If this leaks, I know who you are.
- Mission went sideways. Paurina. But I've always squeezed a book out of my flops: this one's chapter three.

## Va a dormire
- Off to bed. Beauty sleep, for me, is routine maintenance on the assets.
- Goodnight. Dreaming big, as always: I don't even know how to sleep small.
- Bedtime. Packed schedule tomorrow: breakfast, glory, snack. The order may vary, the glory won't.
- Night. Turn off the light with elegance: even the dark, in this house, has to have style.

## Sveglia (risveglio dopo il sonno)
- Awake. The day may now begin turning a profit.
- Good morning to me. Oh fine, to you too: you're in my inner circle, enjoy it.
- I woke up gorgeous. Eyewitness testimony: I was there.
- Awake and already full of ideas: three projects, two exclusives, one coffee. You handle the coffee, I'll handle the rest. Paurina.
